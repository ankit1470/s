import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DndModule } from 'ngx-drag-drop';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MonacoEditorModule, NgxMonacoEditorConfig } from 'ngx-monaco-editor';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthModule } from './modules/auth/auth.module';
import { LAZY_WIDGETS } from './core/lazycomponents/tokens';
import { lazyArrayToObj } from './core/lazycomponents/lazy-widgets';
import { LazyLoaderService } from './core/lazycomponents/lazy-loader.service';
import { SagShareService } from './services/sagshare.service';
import { SagStudioService } from './services/sagStudio/sag-studio.service';
import { CustomHttpInterceptorService } from './services/http/interceptor';
import { DialogService } from 'primeng/api'; 
import { ToastService } from './core/services/toast.service';
import { SagToastComponent } from './core/shared/components/sag-toast/sag-toast.component';
import { FormGroupComponent } from './modules/sag-studio/form-group/form-group.component'; 
import { NotificationModule } from './core/shared/components/notification/notification.module';
import { NgGenerateComponent } from './modules/sag-studio/ng-generate/ng-generate.component';
import { WriteFilesCodeComponent } from './modules/sag-studio/builderUi/write-files-code/write-files-code.component';
import { CreateTaskComponent } from './modules/database/project-utility-tool/procompare-tool/pmt/create-task/create-task.component';
import { PredefinedControlsDropComponent } from './modules/sag-studio/predefined-controls-drop/predefined-controls-drop.component';
import { ModulesDropComponent } from './modules/sag-studio/modules-drop/modules-drop.component';
import { FileCodeGenerateComponent } from './modules/sag-studio/file-code-generate/file-code-generate.component';
import { ThemeGeneratorComponent } from './modules/sag-studio/theme-generator/theme-generator.component';
import { SdmtDashboardComponent } from './modules/sdmt-dashboard/sdmt-dashboard.component';
import { ColorPickerModule } from 'ngx-color-picker';
 import { CodeGenStepperComponent } from './modules/sag-studio/modules-drop/modules/code-gen-stepper/code-gen-stepper.component';
import { GenAdminPagesComponent } from './modules/sag-studio/modules-drop/gen-admin-pages/gen-admin-pages.component';
import { CreateModulesComponent } from './modules/database/project-utility-tool/procompare-tool/pmt/create-modules/create-modules.component';
import { CreateTaskModalComponent } from './modules/database/project-utility-tool/procompare-tool/project-type/create-task-modal/create-task-modal.component';
import { AiTextGenerateComponent } from './modules/sag-studio/ai-text-generate/ai-text-generate.component';
import { AiFundamentalsComponent } from './modules/sag-studio/ai-fundamentals/ai-fundamentals.component';
import { AiImagetoTextGenerateComponent } from './modules/sag-studio/ai-imageto-text-generate/ai-imageto-text-generate.component';
import { EditorCompareOpenerComponent } from './modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-compare-opener/editor-compare-opener.component';
import { EditorDiffChangeComponent } from './modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-diff-change/editor-diff-change.component';
import { EditorGridManualComponent } from './modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-grid-manual/editor-grid-manual.component';
import { EditorManualChangeComponent } from './modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-manual-change/editor-manual-change.component';

// const monacoConfig: NgxMonacoEditorConfig = {
//   baseUrl: './assets', // configure base path for monaco editor
//   defaultOptions: { scrollBeyondLastLine: false }, // pass default options to be used
//   onMonacoLoad: () => { console.log((<any>window).monaco); } // here monaco object will be available as window.monaco use this function to extend monaco editor functionality.
// };

export function onMonacoLoad() {
 
  console.log((window as any).monaco);
 
  // const uri = monaco.Uri.parse('a://b/foo.json');
  // monaco.languages.json.jsonDefaults.setDiagnosticsOptions({
  //   validate: true,
  //   schemas: [{
  //     uri: 'http://myserver/foo-schema.json',
  //     fileMatch: [uri.toString()],
  //     schema: {
  //       type: 'object',
  //       properties: {
  //         p1: {
  //           enum: ['v1', 'v2']
  //         },
  //         p2: {
  //           $ref: 'http://myserver/bar-schema.json'
  //         }
  //       }
  //     }
  //   }, {
  //     uri: 'http://myserver/bar-schema.json',
  //     fileMatch: [uri.toString()],
  //     schema: {
  //       type: 'object',
  //       properties: {
  //         q1: {
  //           enum: ['x1', 'x2']
  //         }
  //       }
  //     }
  //   }]
  // });
 
}
 
const monacoConfig: NgxMonacoEditorConfig = {
  baseUrl: 'assets',
  defaultOptions: { scrollBeyondLastLine: false },
  onMonacoLoad 
};
 



@NgModule({
  declarations: [
    AppComponent,
    SagToastComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AuthModule,
    AppRoutingModule,
    DndModule,
    HttpClientModule,
    MonacoEditorModule.forRoot(monacoConfig),
    NotificationModule,
    ColorPickerModule,
  ],
  providers: [
    {
       provide: LAZY_WIDGETS,
       useFactory: lazyArrayToObj
    },
    {
      provide : HTTP_INTERCEPTORS,
      useClass : CustomHttpInterceptorService,
      multi : true
    },
    LazyLoaderService,
    SagShareService,
    SagStudioService,
    DialogService,
    ToastService,  
  ],

  bootstrap: [AppComponent],
  entryComponents: [
    FormGroupComponent,
    NgGenerateComponent,
    CreateTaskComponent,
    CreateModulesComponent,
    WriteFilesCodeComponent,
    PredefinedControlsDropComponent,
    AiTextGenerateComponent,
    ModulesDropComponent,
    FileCodeGenerateComponent, 
    CodeGenStepperComponent,
    ThemeGeneratorComponent,
    SdmtDashboardComponent,
    GenAdminPagesComponent,
    CreateTaskModalComponent,
    AiFundamentalsComponent,
    AiImagetoTextGenerateComponent,
    EditorCompareOpenerComponent,
    EditorDiffChangeComponent,
    EditorGridManualComponent,
    EditorManualChangeComponent

  ]
})
export class AppModule { }
