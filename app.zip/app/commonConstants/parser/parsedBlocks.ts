export const fetchDataFromApi: any = {
    "type": "ExpressionStatement",
    "expression": {
        "type": "CallExpression",
        "callee": {
            "type": "MemberExpression",
            "object": {
                "type": "CallExpression",
                "callee": {
                    "type": "MemberExpression",
                    "object": {
                        "type": "MemberExpression",
                        "object": {
                            "type": "ThisExpression"
                        },
                        "property": {
                            "type": "Identifier",
                            "name": `diShortName`
                        },
                        "computed": false
                    },
                    "property": {
                        "type": "Identifier",
                        "name": `name`
                    },
                    "computed": false
                },
                "arguments": [
                    {
                        "type": "Identifier",
                        "name": "postData"
                    }
                ]
            },
            "property": {
                "type": "Identifier",
                "name": "subscribe"
            },
            "computed": false
        },
        "arguments": [
            {
                "type": "ArrowFunctionExpression",
                "generator": false,
                "id": null,
                "params": [
                    {
                        "type": "Identifier",
                        "name": "(res:any)"
                    }
                ],
                "body": {
                    "type": "BlockStatement",
                    "body": [

                    ]
                },
                "async": false,
                "expression": false
            }
        ]
    }
};

export const formValuePatch: any = {
    "type": "ExpressionStatement",
    "expression": {
        "type": "CallExpression",
        "callee": {
            "type": "MemberExpression",
            "object": {
                "type": "CallExpression",
                "callee": {
                    "type": "MemberExpression",
                    "object": {
                        "type": "MemberExpression",
                        "object": {
                            "type": "ThisExpression",
                        },
                        "property": {
                            "type": "Identifier",
                            "name": "formgroup",
                        },
                        "computed": false,
                        "optional": false,
                    },
                    "property": {
                        "type": "Identifier",
                        "name": "get",
                    },
                    "computed": false,
                    "optional": false,
                },
                "arguments": [
                    {
                        "type": "Literal",
                        "value": "fcontrolname",
                        "raw": "'fcontrolname'",
                    }
                ],
                "optional": false,
            },
            "property": {
                "type": "Identifier",
                "name": "patchValue",
            },
            "computed": false,
            "optional": false,
        },
        "arguments": [
          {
            "type": "Identifier",
            "name": "res",
          }
            // {
            //     "type": "MemberExpression",
            //     "object": {
            //         "type": "Identifier",
            //         "name": "res",
            //     },
            //     "property": {
            //         "type": "Literal",
            //         "value": "data",
            //         "raw": "'data'",
            //     },
            //     "computed": true,
            //     "optional": false,
            // },

        ],
        "optional": false,
    },
};
 
export const initFormCall : any = {
    "type": "ExpressionStatement",
    "expression": {
      "type": "CallExpression",
      "callee": {
        "type": "MemberExpression",
        "object": {
          "type": "ThisExpression",
          
        },
        "property": {
          "type": "Identifier",
          "name": "initializeForm",
          
        },
        "computed": false,
        "optional": false,
        
      },
      "arguments": [
        
      ],
      "optional": false,
      
    },
    
  };
 
export const assignValueBlock : object ={
    "type": "ExpressionStatement",
    "expression": {
      "type": "AssignmentExpression",
      "operator": "=",
      "left": {
        "type": "MemberExpression",
        "object": {
          "type": "ThisExpression", 
        },
        "property": {
          "type": "Identifier",
          "name": "listOfValidation", 
        },
        "computed": false,
        "optional": false, 
      },
      "right": {
        "type": "Identifier",
        "name": "res", 
      }, 
    }, 
  };

  export const globelVarDeclareBlock : object = {
    "type": "ClassProperty",
    "key": {
      "type": "Identifier",
      "name": `declarename`,
    },
    "value": null,
    "computed": false,
    "static": false,
    "declare": false,
    "override": false,
    "typeAnnotation": {
      "type": "TSTypeAnnotation",
      "typeAnnotation": {
        "type": "TSAnyKeyword",
      }
    }
  };


  export const callMethodGridBlock :object = {
    "type": "ExpressionStatement",
    "expression": {
      "type": "CallExpression",
      "callee": {
        "type": "MemberExpression",
        "object": {
          "type": "ThisExpression", 
        },
        "property": {
          "type": "Identifier",
          "name": "sagGrid21", 
        },
        "computed": false,
        "optional": false, 
      },
      "arguments": [
        {
          "type": "MemberExpression",
          "object": {
            "type": "ThisExpression", 
          },
          "property": {
            "type": "Identifier",
            "name": "responseRows", 
          },
          "computed": false,
          "optional": false, 
        }
      ],
      "optional": false, 
    }, 
  };

  export const templateElementBlock : object = {
    "type": "ExpressionStatement",
    "expression": {
        "type": "TemplateLiteral",
        "quasis": [
            {
                "type": "TemplateElement",
                "value": {
                    "raw": "templateliteral",
                    "cooked": "templateliteral"
                },
                "tail": true
            }
        ],
        "expressions": []
    }
}
  export const setDataInShareService :any = {
    "expression": {
        "arguments": [
            {
                "raw": "'clientId'",
                "type": "Literal",
                "value": "clientId"
            },
            {
                "computed": true,
                "object": {
                    "name": "res",
                    "type": "Identifier"
                },
                "optional": false,
                "property": {
                    "raw": "'data'",
                    "type": "Literal",
                    "value": "data"
                },
                "type": "MemberExpression"
            }
        ],
        "callee": {
            "computed": false,
            "object": {
                "computed": false,
                "object": {
                    "type": "ThisExpression"
                },
                "optional": false,
                "property": {
                    "name": "_apiService",
                    "type": "Identifier"
                },
                "type": "MemberExpression"
            },
            "optional": false,
            "property": {
                "name": "setData",
                "type": "Identifier"
            },
            "type": "MemberExpression"
        },
        "optional": false,
        "type": "CallExpression"
    },
    "type": "ExpressionStatement"
};

  export const setToastMsgBlock:any={
    "type": "ExpressionStatement",
    "expression": {
      "type": "CallExpression",
      "callee": {
        "type": "MemberExpression",
        "object": {
          "type": "MemberExpression",
          "object": {
            "type": "ThisExpression",
            
          },
          "property": {
            "type": "Identifier",
            "name": "common",
            
          },
          "computed": false,
          "optional": false,
          
        },
        "property": {
          "type": "Identifier",
          "name": "setProjectCustomizedData",
          
        },
        "computed": false,
        "optional": false,
        
      },
      "arguments": [
        {
          "type": "ObjectExpression",
          "properties": [
            {
              "type": "Property",
              "key": {
                "type": "Identifier",
                "name": "type",
                
              },
              "value": {
                "type": "Literal",
                "value": "success",
                "raw": "'success'",
                
              },
              "computed": false,
              "method": false,
              "shorthand": false,
              "kind": "init",
              
            },
            {
              "type": "Property",
              "key": {
                "type": "Identifier",
                "name": "position",
                
              },
              "value": {
                "type": "Literal",
                "value": "top-right",
                "raw": "'top-right'",
                
              },
              "computed": false,
              "method": false,
              "shorthand": false,
              "kind": "init",
              
            },
            {
              "type": "Property",
              "key": {
                "type": "Identifier",
                "name": "message",
                
              },
              "value": {
                "type": "Literal",
                "value": "Changes Updated !!!",
                "raw": "'Changes Updated !!!'",
                
              },
              "computed": false,
              "method": false,
              "shorthand": false,
              "kind": "init",
              
            }
          ],
          
        }
      ],
      "optional": false,
      
    },
    
  };

  export const setDynamicToast :any = 
  {
    "type": "ExpressionStatement",
    "expression": {
      "type": "CallExpression",
      "callee": {
        "type": "MemberExpression",
        "object": {
          "type": "MemberExpression",
          "object": {
            "type": "ThisExpression",
            
          },
          "property": {
            "type": "Identifier",
            "name": "_toast",
            
          },
          "computed": false,
          "optional": false,
          
        },
        "property": {
          "type": "Identifier",
          "name": "launch_toast",
          
        },
        "computed": false,
        "optional": false,
        
      },
      "arguments": [
        {
          "type": "ObjectExpression",
          "properties": [
            {
              "type": "Property",
              "key": {
                "type": "Identifier",
                "name": "type",
                
              },
              "value": {
                "type": "TemplateLiteral",
                "quasis": [
                  {
                    "type": "TemplateElement",
                    "value": {
                      "raw": "",
                      "cooked": ""
                    },
                    "tail": false, 
                  },
                  {
                    "type": "TemplateElement",
                    "value": {
                      "raw": "",
                      "cooked": ""
                    },
                    "tail": true, 
                  }
                ],
                "expressions": [
                  {
                    "type": "Identifier",
                    "name": "res['status']",
                  }
                ],
                
              },
              "computed": false,
              "method": false,
              "shorthand": false,
              "kind": "init",
              
            },
            {
              "type": "Property",
              "key": {
                "type": "Identifier",
                "name": "position",
                
              },
              "value": {
                "type": "Literal",
                "value": "bottom-right",
                "raw": "'bottom-right'",
                
              },
              "computed": false,
              "method": false,
              "shorthand": false,
              "kind": "init",
              
            },
            {
              "type": "Property",
              "key": {
                "type": "Identifier",
                "name": "message",
                
              },
              "value": {
                "type": "TemplateLiteral",
                "quasis": [
                  {
                    "type": "TemplateElement",
                    "value": {
                      "raw": "",
                      "cooked": ""
                    },
                    "tail": false, 
                  },
                  {
                    "type": "TemplateElement",
                    "value": {
                      "raw": "",
                      "cooked": ""
                    },
                    "tail": true, 
                  }
                ],
                "expressions": [
                  {
                    "type": "Identifier",
                    "name": "this.response['data']",
                  }
                ],
                
              },
              "computed": false,
              "method": false,
              "shorthand": false,
              "kind": "init",
              
            }
          ],
          
        }
      ],
      "optional": false,
      
    },
    
  };

  export const forLoopBlock : Object  = {
    "type": "ForStatement",
    "init": {
      "type": "VariableDeclaration",
      "declarations": [
        {
          "type": "VariableDeclarator",
          "id": {
            "type": "Identifier",
            "name": "index"
          },
          "init": {
            "type": "Literal",
            "value": 0,
            "raw": "0"
          }
        }
      ],
      "kind": "let"
    },
    "test": {
      "type": "BinaryExpression",
      "operator": "<",
      "left": {
        "type": "Identifier",
        "name": "index"
      },
      "right": {
        "type": "MemberExpression",
        "object": {
          "type": "MemberExpression",
          "object": {
            "type": "MemberExpression",
            "object": {
              "type": "ThisExpression"
            },
            "property": {
              "type": "Identifier",
              "name": "resForGrid5804"
            },
            "computed": false,
            "optional": false
          },
          "property": {
            "type": "Literal",
            "value": "colarray",
            "raw": "'colarray'"
          },
          "computed": true,
          "optional": false
        },
        "property": {
          "type": "Identifier",
          "name": "length"
        },
        "computed": false,
        "optional": false
      }
    },
    "update": {
      "type": "UpdateExpression",
      "operator": "++",
      "prefix": false,
      "argument": {
        "type": "Identifier",
        "name": "index"
      }
    },
    "body": {
      "type": "BlockStatement",
      "body": [
        {
          "type": "VariableDeclaration",
          "declarations": [
            {
              "type": "VariableDeclarator",
              "id": {
                "type": "Identifier",
                "name": "dymColumn"
              },
              "init": {
                "type": "CallExpression",
                "callee": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "Identifier",
                    "name": "JSON"
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "parse"
                  },
                  "computed": false,
                  "optional": false
                },
                "arguments": [
                  {
                    "type": "CallExpression",
                    "callee": {
                      "type": "MemberExpression",
                      "object": {
                        "type": "Identifier",
                        "name": "JSON"
                      },
                      "property": {
                        "type": "Identifier",
                        "name": "stringify"
                      },
                      "computed": false,
                      "optional": false
                    },
                    "arguments": [
                      {
                        "type": "MemberExpression",
                        "object": {
                          "type": "MemberExpression",
                          "object": {
                            "type": "ThisExpression"
                          },
                          "property": {
                            "type": "Identifier",
                            "name": "columnData_countrydatalist"
                          },
                          "computed": false,
                          "optional": false
                        },
                        "property": {
                          "type": "Literal",
                          "value": 0,
                          "raw": "0"
                        },
                        "computed": true,
                        "optional": false
                      }
                    ],
                    "optional": false
                  }
                ],
                "optional": false
              }
            }
          ],
          "kind": "let"
        },
        {
          "type": "ExpressionStatement",
          "expression": {
            "type": "SequenceExpression",
            "expressions": [
              {
                "type": "AssignmentExpression",
                "operator": "=",
                "left": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "Identifier",
                    "name": "dymColumn"
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "field"
                  },
                  "computed": false,
                  "optional": false
                },
                "right": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "MemberExpression",
                    "object": {
                      "type": "MemberExpression",
                      "object": {
                        "type": "MemberExpression",
                        "object": {
                          "type": "ThisExpression"
                        },
                        "property": {
                          "type": "Identifier",
                          "name": "resForGrid5804"
                        },
                        "computed": false,
                        "optional": false
                      },
                      "property": {
                        "type": "Literal",
                        "value": "colarray",
                        "raw": "'colarray'"
                      },
                      "computed": true,
                      "optional": false
                    },
                    "property": {
                      "type": "Identifier",
                      "name": "index"
                    },
                    "computed": true,
                    "optional": false
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "name"
                  },
                  "computed": false,
                  "optional": false
                }
              },
              {
                "type": "AssignmentExpression",
                "operator": "=",
                "left": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "Identifier",
                    "name": "dymColumn"
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "header"
                  },
                  "computed": false,
                  "optional": false
                },
                "right": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "MemberExpression",
                    "object": {
                      "type": "MemberExpression",
                      "object": {
                        "type": "MemberExpression",
                        "object": {
                          "type": "ThisExpression"
                        },
                        "property": {
                          "type": "Identifier",
                          "name": "resForGrid5804"
                        },
                        "computed": false,
                        "optional": false
                      },
                      "property": {
                        "type": "Literal",
                        "value": "colarray",
                        "raw": "'colarray'"
                      },
                      "computed": true,
                      "optional": false
                    },
                    "property": {
                      "type": "Identifier",
                      "name": "index"
                    },
                    "computed": true,
                    "optional": false
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "caption"
                  },
                  "computed": false,
                  "optional": false
                }
              },
              {
                "type": "AssignmentExpression",
                "operator": "=",
                "left": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "Identifier",
                    "name": "dymColumn"
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "columnMultiGroup"
                  },
                  "computed": false,
                  "optional": false
                },
                "right": {
                  "type": "ArrayExpression",
                  "elements": []
                }
              }
            ]
          }
        },
        {
          "type": "ExpressionStatement",
          "expression": {
            "type": "CallExpression",
            "callee": {
              "type": "MemberExpression",
              "object": {
                "type": "MemberExpression",
                "object": {
                  "type": "Identifier",
                  "name": "dymColumn"
                },
                "property": {
                  "type": "Identifier",
                  "name": "columnMultiGroup"
                },
                "computed": false,
                "optional": false
              },
              "property": {
                "type": "Identifier",
                "name": "push"
              },
              "computed": false,
              "optional": false
            },
            "arguments": [
              {
                "type": "MemberExpression",
                "object": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "MemberExpression",
                    "object": {
                      "type": "MemberExpression",
                      "object": {
                        "type": "ThisExpression"
                      },
                      "property": {
                        "type": "Identifier",
                        "name": "resForGrid5804"
                      },
                      "computed": false,
                      "optional": false
                    },
                    "property": {
                      "type": "Literal",
                      "value": "colarray",
                      "raw": "'colarray'"
                    },
                    "computed": true,
                    "optional": false
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "index"
                  },
                  "computed": true,
                  "optional": false
                },
                "property": {
                  "type": "Identifier",
                  "name": "name"
                },
                "computed": false,
                "optional": false
              },
              {
                "type": "MemberExpression",
                "object": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "MemberExpression",
                    "object": {
                      "type": "MemberExpression",
                      "object": {
                        "type": "ThisExpression"
                      },
                      "property": {
                        "type": "Identifier",
                        "name": "resForGrid5804"
                      },
                      "computed": false,
                      "optional": false
                    },
                    "property": {
                      "type": "Literal",
                      "value": "colarray",
                      "raw": "'colarray'"
                    },
                    "computed": true,
                    "optional": false
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "index"
                  },
                  "computed": true,
                  "optional": false
                },
                "property": {
                  "type": "Identifier",
                  "name": "tname"
                },
                "computed": false,
                "optional": false
              }
            ],
            "optional": false
          }
        },
        {
          "type": "ExpressionStatement",
          "expression": {
            "type": "CallExpression",
            "callee": {
              "type": "MemberExpression",
              "object": {
                "type": "MemberExpression",
                "object": {
                  "type": "ThisExpression"
                },
                "property": {
                  "type": "Identifier",
                  "name": "columnData_countrydatalist"
                },
                "computed": false,
                "optional": false
              },
              "property": {
                "type": "Identifier",
                "name": "push"
              },
              "computed": false,
              "optional": false
            },
            "arguments": [
              {
                "type": "Identifier",
                "name": "dymColumn"
              }
            ],
            "optional": false
          }
        }
      ]
    }
  }
  export const forLoopBlock1 : object = {
    "type": "ForStatement",
    "init": {
      "type": "VariableDeclaration",
      "declarations": [
        {
          "type": "VariableDeclarator",
          "id": {
            "type": "Identifier",
            "name": "index"
          },
          "init": {
            "type": "Literal",
            "value": 0,
            "raw": "0"
          }
        }
      ],
      "kind": "let"
    },
    "test": {
      "type": "BinaryExpression",
      "operator": "<",
      "left": {
        "type": "Identifier",
        "name": "index"
      },
      "right": {
        "type": "MemberExpression",
        "object": {
          "type": "MemberExpression",
          "object": {
            "type": "MemberExpression",
            "object": {
              "type": "ThisExpression"
            },
            "property": {
              "type": "Identifier",
              "name": "resForGrid5956"
            },
            "computed": false,
            "optional": false
          },
          "property": {
            "type": "Literal",
            "value": "colarray",
            "raw": "'colarray'"
          },
          "computed": true,
          "optional": false
        },
        "property": {
          "type": "Identifier",
          "name": "length"
        },
        "computed": false,
        "optional": false
      }
    },
    "update": {
      "type": "UpdateExpression",
      "operator": "++",
      "prefix": false,
      "argument": {
        "type": "Identifier",
        "name": "index"
      }
    },
    "body": {
      "type": "BlockStatement",
      "body": [
        {
          "type": "VariableDeclaration",
          "declarations": [
            {
              "type": "VariableDeclarator",
              "id": {
                "type": "Identifier",
                "name": "dymColumn"
              },
              "init": {
                "type": "CallExpression",
                "callee": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "Identifier",
                    "name": "JSON"
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "parse"
                  },
                  "computed": false,
                  "optional": false
                },
                "arguments": [
                  {
                    "type": "CallExpression",
                    "callee": {
                      "type": "MemberExpression",
                      "object": {
                        "type": "Identifier",
                        "name": "JSON"
                      },
                      "property": {
                        "type": "Identifier",
                        "name": "stringify"
                      },
                      "computed": false,
                      "optional": false
                    },
                    "arguments": [
                      {
                        "type": "MemberExpression",
                        "object": {
                          "type": "MemberExpression",
                          "object": {
                            "type": "ThisExpression"
                          },
                          "property": {
                            "type": "Identifier",
                            "name": "columnData_sagGrid_1706173478025"
                          },
                          "computed": false,
                          "optional": false
                        },
                        "property": {
                          "type": "Literal",
                          "value": 0,
                          "raw": "0"
                        },
                        "computed": true,
                        "optional": false
                      }
                    ],
                    "optional": false
                  }
                ],
                "optional": false
              }
            }
          ],
          "kind": "let"
        },
        {
          "type": "ExpressionStatement",
          "expression": {
            "type": "SequenceExpression",
            "expressions": [
              {
                "type": "AssignmentExpression",
                "operator": "=",
                "left": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "Identifier",
                    "name": "dymColumn"
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "field"
                  },
                  "computed": false,
                  "optional": false
                },
                "right": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "MemberExpression",
                    "object": {
                      "type": "MemberExpression",
                      "object": {
                        "type": "MemberExpression",
                        "object": {
                          "type": "ThisExpression"
                        },
                        "property": {
                          "type": "Identifier",
                          "name": "resForGrid5956"
                        },
                        "computed": false,
                        "optional": false
                      },
                      "property": {
                        "type": "Literal",
                        "value": "colarray",
                        "raw": "'colarray'"
                      },
                      "computed": true,
                      "optional": false
                    },
                    "property": {
                      "type": "Identifier",
                      "name": "index"
                    },
                    "computed": true,
                    "optional": false
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "name"
                  },
                  "computed": false,
                  "optional": false
                }
              },
              {
                "type": "AssignmentExpression",
                "operator": "=",
                "left": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "Identifier",
                    "name": "dymColumn"
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "header"
                  },
                  "computed": false,
                  "optional": false
                },
                "right": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "MemberExpression",
                    "object": {
                      "type": "MemberExpression",
                      "object": {
                        "type": "MemberExpression",
                        "object": {
                          "type": "ThisExpression"
                        },
                        "property": {
                          "type": "Identifier",
                          "name": "resForGrid5956"
                        },
                        "computed": false,
                        "optional": false
                      },
                      "property": {
                        "type": "Literal",
                        "value": "colarray",
                        "raw": "'colarray'"
                      },
                      "computed": true,
                      "optional": false
                    },
                    "property": {
                      "type": "Identifier",
                      "name": "index"
                    },
                    "computed": true,
                    "optional": false
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "name"
                  },
                  "computed": false,
                  "optional": false
                }
              },
              {
                "type": "CallExpression",
                "callee": {
                  "type": "MemberExpression",
                  "object": {
                    "type": "MemberExpression",
                    "object": {
                      "type": "ThisExpression"
                    },
                    "property": {
                      "type": "Identifier",
                      "name": "columnData_sagGrid_1706173478025"
                    },
                    "computed": false,
                    "optional": false
                  },
                  "property": {
                    "type": "Identifier",
                    "name": "push"
                  },
                  "computed": false,
                  "optional": false
                },
                "arguments": [
                  {
                    "type": "Identifier",
                    "name": "dymColumn"
                  }
                ],
                "optional": false
              }
            ]
          }
        }
      ]
    }
  }