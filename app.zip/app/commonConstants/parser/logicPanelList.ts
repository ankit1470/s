export const logicPaneBlock = [
    {
        panelType: "logic",
        panelData: [
            {
                name: "IF ELSE IF IF Block",
                type: "IfStatement",
                id: null,
                body: {
                    "type": "IfStatement",
                    "test": {
                        "type": "AssignmentExpression",
                        "operator": "=",
                        "left": {
                            "type": "Identifier",
                            "name": "cc"
                        },
                        "right": {
                            "type": "Literal",
                            "value": 0,
                            "raw": "0"
                        }
                    },
                    "consequent": {
                        "type": "BlockStatement",
                        "body": [
                            {
                                "type": "ExpressionStatement",
                                "expression": {
                                    "type": "CallExpression",
                                    "callee": {
                                        "type": "MemberExpression",
                                        "object": {
                                            "type": "Identifier",
                                            "name": "console"
                                        },
                                        "property": {
                                            "type": "Identifier",
                                            "name": "log"
                                        },
                                        "computed": false
                                    },
                                    "arguments": [
                                        {
                                            "type": "Identifier",
                                            "name": "cc"
                                        }
                                    ]
                                }
                            }
                        ]
                    },
                    "alternate": {
                        "type": "IfStatement",
                        "test": {
                            "type": "BinaryExpression",
                            "operator": ">=",
                            "left": {
                                "type": "Identifier",
                                "name": "cc"
                            },
                            "right": {
                                "type": "Literal",
                                "value": 0,
                                "raw": "0"
                            }
                        },
                        "consequent": {
                            "type": "BlockStatement",
                            "body": [
                                {
                                    "type": "ExpressionStatement",
                                    "expression": {
                                        "type": "CallExpression",
                                        "callee": {
                                            "type": "MemberExpression",
                                            "object": {
                                                "type": "Identifier",
                                                "name": "console"
                                            },
                                            "property": {
                                                "type": "Identifier",
                                                "name": "log"
                                            },
                                            "computed": false
                                        },
                                        "arguments": [
                                            {
                                                "type": "Identifier",
                                                "name": "cc"
                                            }
                                        ]
                                    }
                                }
                            ]
                        },
                        "alternate": {
                            "type": "BlockStatement",
                            "body": [
                                {
                                    "type": "ExpressionStatement",
                                    "expression": {
                                        "type": "CallExpression",
                                        "callee": {
                                            "type": "MemberExpression",
                                            "object": {
                                                "type": "Identifier",
                                                "name": "console"
                                            },
                                            "property": {
                                                "type": "Identifier",
                                                "name": "error"
                                            },
                                            "computed": false
                                        },
                                        "arguments": [
                                            {
                                                "type": "Identifier",
                                                "name": "cc"
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                }
            },
        ],
        panelName: "logic"
    },
    {
        panelType: "loops",
        panelData: [
            {
                name: "for Loop",
                type: "forLoop",
                id: null,
                body: {
                    "type": "ForStatement",
                    "init": {
                        "type": "VariableDeclaration",
                        "declarations": [
                            {
                                "type": "VariableDeclarator",
                                "id": {
                                    "type": "Identifier",
                                    "name": "index"
                                },
                                "init": {
                                    "type": "Literal",
                                    "value": 0,
                                    "raw": "0"
                                }
                            }
                        ],
                        "kind": "let"
                    },
                    "test": {
                        "type": "BinaryExpression",
                        "operator": "<",
                        "left": {
                            "type": "Identifier",
                            "name": "index"
                        },
                        "right": {
                            "type": "MemberExpression",
                            "object": {
                                "type": "Identifier",
                                "name": "array"
                            },
                            "property": {
                                "type": "Identifier",
                                "name": "length"
                            },
                            "computed": false
                        }
                    },
                    "update": {
                        "type": "UpdateExpression",
                        "operator": "++",
                        "prefix": false,
                        "argument": {
                            "type": "Identifier",
                            "name": "index"
                        }
                    },
                    "body": {
                        "type": "BlockStatement",
                        "body": [
                            {
                                "type": "VariableDeclaration",
                                "declarations": [
                                    {
                                        "type": "VariableDeclarator",
                                        "id": {
                                            "type": "Identifier",
                                            "name": "element"
                                        },
                                        "init": {
                                            "type": "MemberExpression",
                                            "object": {
                                                "type": "Identifier",
                                                "name": "array"
                                            },
                                            "property": {
                                                "type": "Identifier",
                                                "name": "index"
                                            },
                                            "computed": true
                                        }
                                    }
                                ],
                                "kind": "const"
                            },
                            {
                                "type": "ExpressionStatement",
                                "expression": {
                                    "type": "CallExpression",
                                    "callee": {
                                        "type": "MemberExpression",
                                        "object": {
                                            "type": "Identifier",
                                            "name": "console"
                                        },
                                        "property": {
                                            "type": "Identifier",
                                            "name": "log"
                                        },
                                        "computed": false
                                    },
                                    "arguments": [
                                        {
                                            "type": "Identifier",
                                            "name": "element"
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                },
            },
            {
                name: "while Loop",
                type: "whileStatement",
                id: null,
                body: {
                    "type": "whileStatement",
                    "test": {
                        "type": "BinaryExpression",
                        "operator": "<=",
                        "left": {
                            "type": "Identifier",
                            "name": "count"
                        },
                        "right": {
                            "type": "Literal",
                            "value": 5,
                            "raw": "5"
                        }
                    },
                    "body": {
                        "type": "BlockStatement",
                        "body": [
                            {
                                "type": "ExpressionStatement",
                                "expression": {
                                    "type": "CallExpression",
                                    "callee": {
                                        "type": "MemberExpression",
                                        "object": {
                                            "type": "Identifier",
                                            "name": "console"
                                        },
                                        "property": {
                                            "type": "Identifier",
                                            "name": "log"
                                        },
                                        "computed": false
                                    },
                                    "arguments": [
                                        {
                                            "type": "Identifier",
                                            "name": "count"
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                }
            },
            {
                name: "Do While Loop",
                type: "DoWhileStatement",
                id: null,
                body: {
                    "type": "DoWhileStatement",
                    "test": {
                        "type": "BinaryExpression",
                        "operator": "<=",
                        "left": {
                            "type": "Identifier",
                            "name": "count"
                        },
                        "right": {
                            "type": "Literal",
                            "value": 5,
                            "raw": "5"
                        }
                    },
                    "body": {
                        "type": "BlockStatement",
                        "body": [
                            {
                                "type": "ExpressionStatement",
                                "expression": {
                                    "type": "CallExpression",
                                    "callee": {
                                        "type": "MemberExpression",
                                        "object": {
                                            "type": "Identifier",
                                            "name": "console"
                                        },
                                        "property": {
                                            "type": "Identifier",
                                            "name": "log"
                                        },
                                        "computed": false
                                    },
                                    "arguments": [
                                        {
                                            "type": "Identifier",
                                            "name": "count"
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                }
            },
            {
                name: "For Each Loop",
                type: "ForEachStatement",
                id: null,
                body: {
                    "type": "ForEachStatement",
                    "test": {
                        "type": "BinaryExpression",
                        "operator": "<=",
                        "left": {
                            "type": "Identifier",
                            "name": "count"
                        },
                        "right": {
                            "type": "Literal",
                            "value": 5,
                            "raw": "5"
                        }
                    },
                    "body": {
                        "type": "BlockStatement",
                        "body": [
                            {
                                "type": "ExpressionStatement",
                                "expression": {
                                    "type": "CallExpression",
                                    "callee": {
                                        "type": "MemberExpression",
                                        "object": {
                                            "type": "Identifier",
                                            "name": "console"
                                        },
                                        "property": {
                                            "type": "Identifier",
                                            "name": "log"
                                        },
                                        "computed": false
                                    },
                                    "arguments": [
                                        {
                                            "type": "Identifier",
                                            "name": "count"
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                }
            }
        ],
        panelName: "loops"
    },
    {
        panelType: "variables",
        panelData: [
            {
                name: "Declare Variable(Const)",
                type: "variable",
                id: null,
                body: {
                    "type": "VariableDeclaration",
                    "declarations": [
                        {
                            "type": "VariableDeclarator",
                            "id": {
                                "type": "Identifier",
                                "name": "myVal",
                                "typeAnnotation": {
                                    "type": "TSTypeAnnotation",
                                    "typeAnnotation": {
                                        "type": "TSStringKeyword"
                                    }
                                }
                            },
                            "init": {
                                "type": "Literal",
                                "raw": "'anyval'",
                                "value": "anyval"
                            }
                        }
                    ],
                    "kind": "const"
                },
            },
            {
                name: "Declare Variable(Let)",
                type: "variable",
                id: null,
                body: {
                    "type": "VariableDeclaration",
                    "declarations": [
                        {
                            "type": "VariableDeclarator",
                            "id": {
                                "type": "Identifier",
                                "name": "myVal",
                                "typeAnnotation": {
                                    "type": "TSTypeAnnotation",
                                    "typeAnnotation": {
                                        "type": "TSStringKeyword"
                                    }
                                }
                            },
                            "init": {
                                "type": "Literal",
                                "raw": "'anyval'",
                                "value": "anyval"
                            }
                        }
                    ],
                    "kind": "let"
                },
            },
            {
                name: "Declare Variable(var)",
                type: "variable",
                id: null,
                body: {
                    "type": "VariableDeclaration",
                    "declarations": [
                        {
                            "type": "VariableDeclarator",
                            "id": {
                                "type": "Identifier",
                                "name": "myVal",
                                "typeAnnotation": {
                                    "type": "TSTypeAnnotation",
                                    "typeAnnotation": {
                                        "type": "TSStringKeyword"
                                    }
                                }
                            },
                            "init": {
                                "type": "Literal",
                                "raw": "'anyval'",
                                "value": "anyval"
                            }
                        }
                    ],
                    "kind": "var"
                },
            },
        ],
        panelName: "variables"
    },
    {
        panelType: "globelDeclare",
        panelData: [
            {
                name: "Globel Variable",
                type: "globelVar",
                id: null,
                body: {
                    "type": "ClassProperty",
                    "key": {
                        "type": "Identifier",
                        "name": "countryList",
                    },
                    "value": null,
                    "computed": false,
                    "static": false,
                    "declare": false,
                    "override": false,
                    "typeAnnotation": {
                        "type": "TSTypeAnnotation",
                        "typeAnnotation": {
                            "type": "TSAnyKeyword",
                        }
                    }
                }
            },
            {
                name: "Globel Variable",
                type: "globelVar",
                id: null,
                body: {
                    "type": "ClassProperty",
                    "key": {
                        "type": "Identifier",
                        "name": "objValueList"
                    },
                    "value": {
                        "type": "ObjectExpression",
                        "properties": [

                        ]
                    },
                    "computed": false,
                    "static": false,
                    "typeAnnotation": {
                        "type": "TSTypeAnnotation",
                        "typeAnnotation": {
                            "type": "TSAnyKeyword"
                        }
                    }
                },
            },
            {
                name: "Globel Variable",
                type: "globelVar",
                id: null,
                body: {
                    "type": "ClassProperty",
                    "key": {
                        "type": "Identifier",
                        "name": "arrValueList"
                    },
                    "value": {
                        "type": "ArrayExpression",
                        "elements": [

                        ]
                    },
                    "computed": false,
                    "static": false,
                    "typeAnnotation": {
                        "type": "TSTypeAnnotation",
                        "typeAnnotation": {
                            "type": "TSAnyKeyword"
                        }
                    }
                },
            },
            {
                name: "Globel Variable",
                type: "globelVar",
                id: null,
                body: {
                    "type": "ClassProperty",
                    "key": {
                        "type": "Identifier",
                        "name": "strValueList"
                    },
                    "value": {
                        "type": "Literal",
                        "raw": "'string'",
                        "value": "string"
                    },
                    "computed": false,
                    "static": false,
                    "typeAnnotation": {
                        "type": "TSTypeAnnotation",
                        "typeAnnotation": {
                            "type": "TSAnyKeyword"
                        }
                    }
                },
            },
            {
                name: "Globel Variable",
                type: "globelVar",
                id: null,
                body: {
                    "type": "ClassProperty",
                    "key": {
                        "type": "Identifier",
                        "name": "booleanValueList"
                    },
                    "value": {
                        "type": "Literal",
                        "value": true,
                        "raw": "true"
                    },
                    "computed": false,
                    "static": false,
                    "typeAnnotation": {
                        "type": "TSTypeAnnotation",
                        "typeAnnotation": {
                            "type": "TSAnyKeyword"
                        }
                    }
                },
            },
            {
                name: "Globel Variable",
                type: "globelVar",
                id: null,
                body: {
                    "type": "ClassProperty",
                    "key": {
                        "type": "Identifier",
                        "name": "numValueList"
                    },
                    "value": {
                        "type": "Literal",
                        "value": 2,
                        "raw": "2"
                    },
                    "computed": false,
                    "static": false,
                    "typeAnnotation": {
                        "type": "TSTypeAnnotation",
                        "typeAnnotation": {
                            "type": "TSAnyKeyword"
                        }
                    }
                },
            }
        ],
        panelName: "Globel Declarations"
    },
    {
        panelType: "predefined",
        panelData: [
            {
                name: "Fetch Data From Api",
                type: "fetchDataFromApi",
                id: 4,
                body: [
                    {
                        "type": "VariableDeclaration",
                        "declarations": [
                            {
                                "type": "VariableDeclarator",
                                "id": {
                                    "type": "Identifier",
                                    "name": "myval",
                                    "typeAnnotation": {
                                        "type": "TSTypeAnnotation",
                                        "typeAnnotation": {
                                            "type": "TSAnyKeyword"
                                        }
                                    }
                                },
                                "init": {
                                    "type": "Literal",
                                    "value": null,
                                    "raw": "null"
                                }
                            }
                        ],
                        "kind": "let"
                    },
                    {
                        "type": "ExpressionStatement",
                        "expression": {
                            "type": "AssignmentExpression",
                            "operator": "=",
                            "left": {
                                "type": "Identifier",
                                "name": "myval"
                            },
                            "right": {
                                "type": "MemberExpression",
                                "object": {
                                    "type": "MemberExpression",
                                    "object": {
                                        "type": "ThisExpression"
                                    },
                                    "property": {
                                        "type": "Identifier",
                                        "name": "myForm"
                                    },
                                    "computed": false
                                },
                                "property": {
                                    "type": "Identifier",
                                    "name": "value"
                                },
                                "computed": false
                            }
                        }
                    },
                    {
                        "type": "ExpressionStatement",
                        "expression": {
                            "type": "CallExpression",
                            "callee": {
                                "type": "MemberExpression",
                                "object": {
                                    "type": "CallExpression",
                                    "callee": {
                                        "type": "MemberExpression",
                                        "object": {
                                            "type": "MemberExpression",
                                            "object": {
                                                "type": "ThisExpression"
                                            },
                                            "property": {
                                                "type": "Identifier",
                                                "name": "dbcomparetoolService"
                                            },
                                            "computed": false
                                        },
                                        "property": {
                                            "type": "Identifier",
                                            "name": "runCommandApi"
                                        },
                                        "computed": false
                                    },
                                    "arguments": [
                                        {
                                            "type": "Identifier",
                                            "name": "path"
                                        },
                                        {
                                            "type": "Identifier",
                                            "name": "command"
                                        }
                                    ]
                                },
                                "property": {
                                    "type": "Identifier",
                                    "name": "subscribe"
                                },
                                "computed": false
                            },
                            "arguments": [
                                {
                                    "type": "ArrowFunctionExpression",
                                    "generator": false,
                                    "id": null,
                                    "params": [
                                        {
                                            "type": "Identifier",
                                            "name": "response",
                                            "typeAnnotation": {
                                                "type": "TSTypeAnnotation",
                                                "typeAnnotation": {
                                                    "type": "TSAnyKeyword"
                                                }
                                            }
                                        }
                                    ],
                                    "body": {
                                        "type": "BlockStatement",
                                        "body": [
                                            {
                                                "type": "ExpressionStatement",
                                                "expression": {
                                                    "type": "CallExpression",
                                                    "callee": {
                                                        "type": "MemberExpression",
                                                        "object": {
                                                            "type": "Identifier",
                                                            "name": "console"
                                                        },
                                                        "property": {
                                                            "type": "Identifier",
                                                            "name": "log"
                                                        },
                                                        "computed": false
                                                    },
                                                    "arguments": [
                                                        {
                                                            "type": "Identifier",
                                                            "name": "response"
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    },
                                    "async": false,
                                    "expression": false
                                },
                                {
                                    "type": "ArrowFunctionExpression",
                                    "generator": false,
                                    "id": null,
                                    "params": [
                                        {
                                            "type": "Identifier",
                                            "name": "error",
                                            "typeAnnotation": {
                                                "type": "TSTypeAnnotation",
                                                "typeAnnotation": {
                                                    "type": "TSAnyKeyword"
                                                }
                                            }
                                        }
                                    ],
                                    "body": {
                                        "type": "BlockStatement",
                                        "body": [
                                            {
                                                "type": "ExpressionStatement",
                                                "expression": {
                                                    "type": "CallExpression",
                                                    "callee": {
                                                        "type": "MemberExpression",
                                                        "object": {
                                                            "type": "Identifier",
                                                            "name": "console"
                                                        },
                                                        "property": {
                                                            "type": "Identifier",
                                                            "name": "log"
                                                        },
                                                        "computed": false
                                                    },
                                                    "arguments": [
                                                        {
                                                            "type": "Identifier",
                                                            "name": "error"
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    },
                                    "async": false,
                                    "expression": false
                                },
                                {
                                    "type": "ArrowFunctionExpression",
                                    "generator": false,
                                    "id": null,
                                    "params": [

                                    ],
                                    "body": {
                                        "type": "BlockStatement",
                                        "body": [
                                            {
                                                "type": "ExpressionStatement",
                                                "expression": {
                                                    "type": "CallExpression",
                                                    "callee": {
                                                        "type": "MemberExpression",
                                                        "object": {
                                                            "type": "Identifier",
                                                            "name": "console"
                                                        },
                                                        "property": {
                                                            "type": "Identifier",
                                                            "name": "log"
                                                        },
                                                        "computed": false
                                                    },
                                                    "arguments": [
                                                        {
                                                            "type": "Literal",
                                                            "raw": "'completed'",
                                                            "value": "completed"
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    },
                                    "async": false,
                                    "expression": false
                                }
                            ]
                        }
                    }
                ]
            },
            {
                name: "Model Open/Close",
                type: "modelOpenClose",
                id: 4,
                body: {}
            },
            {
                name: "Assign Values",
                type: "assignValues",
                id: null,
                body: [
                    {
                        "type": "ExpressionStatement",
                        "expression": {
                            "type": "AssignmentExpression",
                            "operator": "=",
                            "left": {
                                "type": "Identifier",
                                "name": "myval"
                            },
                            "right": {
                                "type": "MemberExpression",
                                "object": {
                                    "type": "MemberExpression",
                                    "object": {
                                        "type": "ThisExpression"
                                    },
                                    "property": {
                                        "type": "Identifier",
                                        "name": "myForm"
                                    },
                                    "computed": false
                                },
                                "property": {
                                    "type": "Identifier",
                                    "name": "value"
                                },
                                "computed": false
                            }
                        }
                    },
                ]
            },
            {
                name: "Api Statment",
                type: "apiStatement",
                id: null,
                body: [
                    {
                        "type": "ReturnStatement",
                        "argument": {
                            "type": "CallExpression",
                            "callee": {
                                "type": "MemberExpression",
                                "object": {
                                    "type": "MemberExpression",
                                    "object": {
                                        "type": "ThisExpression"
                                    },
                                    "property": {
                                        "type": "Identifier",
                                        "name": "http"
                                    },
                                    "computed": false,
                                    "optional": false
                                },
                                "property": {
                                    "type": "Identifier",
                                    "name": "get"
                                },
                                "computed": false,
                                "optional": false
                            },
                            "arguments": [
                                {
                                    "type": "TemplateLiteral",
                                    "quasis": [
                                        {
                                            "type": "TemplateElement",
                                            "value": {
                                                "raw": "",
                                                "cooked": ""
                                            },
                                            "tail": false
                                        },
                                        {
                                            "type": "TemplateElement",
                                            "value": {
                                                "raw": "/url",
                                                "cooked": "/url"
                                            },
                                            "tail": true
                                        }
                                    ],
                                    "expressions": [
                                        {
                                            "type": "MemberExpression",
                                            "object": {
                                                "type": "ThisExpression"
                                            },
                                            "property": {
                                                "type": "Identifier",
                                                "name": "baseURL"
                                            },
                                            "computed": false,
                                            "optional": false
                                        }
                                    ]
                                },
                                {
                                    "type": "ObjectExpression",
                                    "properties": [
                                        {
                                            "type": "Property",
                                            "key": {
                                                "type": "Literal",
                                                "value": "headers",
                                                "raw": "'headers'"
                                            },
                                            "value": {
                                                "type": "Identifier",
                                                "name": "headers"
                                            },
                                            "computed": false,
                                            "method": false,
                                            "shorthand": false,
                                            "kind": "init"
                                        }
                                    ]
                                }
                            ],
                            "optional": false
                        }
                    }
                ]
            },
            // Call an methods -------- callExpression
            {
                name: "Call an methods",
                type: "callExpression",
                id: null,
                body: [
                    {
                        "type": "ExpressionStatement",
                        "expression": {
                            "type": "CallExpression",
                            "callee": {
                                "type": "MemberExpression",
                                "object": {
                                    "type": "ThisExpression",
                                },
                                "property": {
                                    "type": "Identifier",
                                    "name": "getCountryList",
                                },
                                "computed": false,
                                "optional": false,
                            },
                            "arguments": [

                            ],
                            "optional": false,
                        },
                    },
                ]
            },

        ],
        panelName: "predefined"
    },
    {
        panelType: "customCode",
        panelData: [
            {
                id: null,
                name: "Custom Code",
                type: "customCode",
                subType: "customCode",
                code: "let newVar = null;",
                dataType: "NA",
                subDataArray: [
                ]
            },
        ],
        panelName: "customCode"
    },
    {
        panelType: "math",
        panelData: [],
        panelName: "math"
    },
    {
        panelType: "text",
        panelData: [],
        panelName: "text"
    },
    {
        panelType: "lists",
        panelData: [],
        panelName: "lists"
    },
    {
        panelType: "function",
        panelData: [],
        panelName: "function"
    },

];
