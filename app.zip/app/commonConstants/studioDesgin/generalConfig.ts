export let generalConfigBlock = [
  {
    "id": "general",
    "label": "General Configuration",
    "child": [
      {
        "type": "apiTool",
        "subtype": "apiTool",
        "properties": {
          "label": "API Integration"
        }
      },
      // {
      //   "type": "sagMultiLang",
      //   "subtype": "sagMultiLang",
      //   "properties": {
      //     "label": "Multi Language"
      //   }
      // },
      // {
      //   "type": "theme",
      //   "subtype": "theme",
      //   "properties": {
      //     "label": "Web/Mobile Theme"
      //   }
      // },
      // {
      //   "type": "sagVoice",
      //   "subtype": "sagVoice",
      //   "properties": {
      //     "label": "Voice Command"
      //   }
      // },
    ]
  },
  {
    "id": "controls",
    "label": "Default Control Property",
    "child":[]
  },
  {
    "id": "userRoles",
    "label": "User Role",
    "child": []
  },
  {
    "id": "tree",
    "label": "Tree",
    "child": []
  }
  // ,{
  //   "id": "usermodule",
  //   "label": "User Permission",
  //   "child": [
  //     {
  //       "type": "moduleList",
  //       "icon": "fa-font",
  //       "label": "Module List",
  //       "description": "Module List",
  //       "placeholder": "Module List",
  //       "className": "form-control",
  //       "subtype": "moduleList",
  //       "regex": "",
  //       "handle": true,
  //       "classValue": null,
  //       "labelClasses": "",
  //       "angular": {
  //         "appliedEvents": [

  //         ],
  //         "events": [

  //         ],
  //         "validators": [

  //         ],
  //         "selectedValidatorsForControls": [

  //         ],
  //         "selectFormGroupItem": {
  //           "formGroupName": ""
  //         },
  //         "formType": "none",
  //         "validationMsg": ""
  //       },
  //       "database": {
  //         "databaseName": "",
  //         "tableName": "",
  //         "columnName": "",
  //         "dbMappingState": "none",
  //         "dbMappingMsg": ""
  //       },
  //       "properties": {
  //         "innerStyles": {

  //         },
  //         "innerlabel": "",
  //         "classes": "",
  //         "innerStylesString": "",
  //         "propertyOption2": null,
  //         "propertyOption3": null,
  //         "propertyOption4": null,
  //         "propertyOption5": null
  //       },
  //       "subDataArray": [

  //       ],
  //       "elementId": null,
  //       "values": [
  //         {
  //           "label": "Option 1",
  //           "value": "option-1"
  //         },
  //         {
  //           "label": "Option 2",
  //           "value": "option-2"
  //         }
  //       ],
  //       "attribute": [
  //         {
  //           "label": "Option 1",
  //           "value": "option-1"
  //         },
  //         {
  //           "label": "Option 2",
  //           "value": "option-2"
  //         }
  //       ],
  //       "id": null,
  //       "parentId": null,
  //       "isCurrentlySelected": false,
  //       "option5": null,
  //       "disable": false,
  //       "starSymbol": false,
  //       "required": false,
  //       "errorlabel": "Please enter a valid Value",
  //       "globelClasses": "",
  //       "selectedGlobalClassArray": [

  //       ],
  //       "additionGlobelClasses": "",
  //       "defaultGlobelCls": "",
  //       "windowProperties": [
  //         "moduleList"
  //       ],
  //       "projectConfigProperties": [
  //         "moduleList"
  //       ]
  //     }
  //   ]
  // }
];
