export const moreWebComponents = [
    {
        "type": "headerCompItem",
        "subtype": "headerCompItem",
        "studioDevClasses": "d-block",
        "selectedTab": true,
        "loadChildrenMod": "",
        "linkedAssoMatchableId": null,
        "matchableId": null,
        "fullPath": null,
        "children": [],
        "appSelectorName": null,
        "properties": {
            "label": "",
            "name": "",
            "visibility": true,
            "iconClass": "",
            "iconPosition": "before",
            "defaultLabelCls": "nav-link",
            "defaultElementCls": "tab-pane fade",
        },
        "subDataArray": [

        ],
    },
    {
        "type": "column",
        "subtype": "column",
        "studioDevClasses": "",
        "properties": {
            "label": "Column",
            "name": "",
            "visibility": true,
            "colClass": "col-sm-6",
        },
        "subDataArray": [
        ],

    },
    // {
    //     "type": "dynamicColumn",
    //     "subtype": "column",
    //     "studioDevClasses": "",
    //     "properties": {
    //         "label": "Column",
    //         "name": "",
    //         "visibility": true,
    //         "colClass": "col-sm-6",
    //     },
    //     "subDataArray": [
    //     ],
    // }
]