export let astTypesListBlock = [
    {
        "name": "TSAbstractClassDeclaration",
        "value": "TSAbstractClassDeclaration"
    },
    {
        "name": "TSAbstractClassProperty",
        "value": "TSAbstractClassProperty"
    },
    {
        "name": "TSAbstractKeyword",
        "value": "TSAbstractKeyword"
    },
    {
        "name": "TSAbstractMethodDefinition",
        "value": "TSAbstractMethodDefinition"
    },
    {
        "name": "TSAnyKeyword",
        "value": "TSAnyKeyword"
    },
    {
        "name": "TSArrayType",
        "value": "TSArrayType"
    },
    {
        "name": "TSAsExpression",
        "value": "TSAsExpression"
    },
    {
        "name": "TSAsyncKeyword",
        "value": "TSAsyncKeyword"
    },
    {
        "name": "TSBooleanKeyword",
        "value": "TSBooleanKeyword"
    },
    {
        "name": "TSBigIntKeyword",
        "value": "TSBigIntKeyword"
    },
    {
        "name": "TSConditionalType",
        "value": "TSConditionalType"
    },
    {
        "name": "TSConstructorType",
        "value": "TSConstructorType"
    },
    {
        "name": "TSCallSignatureDeclaration",
        "value": "TSCallSignatureDeclaration"
    },
    {
        "name": "TSClassImplements",
        "value": "TSClassImplements"
    },
    {
        "name": "TSConstructSignatureDeclaration",
        "value": "TSConstructSignatureDeclaration"
    },
    {
        "name": "TSDeclareKeyword",
        "value": "TSDeclareKeyword"
    },
    {
        "name": "TSDeclareFunction",
        "value": "TSDeclareFunction"
    },
    {
        "name": "TSEnumDeclaration",
        "value": "TSEnumDeclaration"
    },
    {
        "name": "TSEnumMember",
        "value": "TSEnumMember"
    },
    {
        "name": "TSExportAssignment",
        "value": "TSExportAssignment"
    },
    {
        "name": "TSExportKeyword",
        "value": "TSExportKeyword"
    },
    {
        "name": "TSExternalModuleReference",
        "value": "TSExternalModuleReference"
    },
    {
        "name": "TSImportType",
        "value": "TSImportType"
    },
    {
        "name": "TSInferType",
        "value": "TSInferType"
    },
    {
        "name": "TSLiteralType",
        "value": "TSLiteralType"
    },
    {
        "name": "TSIndexedAccessType",
        "value": "TSIndexedAccessType"
    },
    {
        "name": "TSIndexSignature",
        "value": "TSIndexSignature"
    },
    {
        "name": "TSInterfaceBody",
        "value": "TSInterfaceBody"
    },
    {
        "name": "TSInterfaceDeclaration",
        "value": "TSInterfaceDeclaration"
    },
    {
        "name": "TSInterfaceHeritage",
        "value": "TSInterfaceHeritage"
    },
    {
        "name": "TSImportEqualsDeclaration",
        "value": "TSImportEqualsDeclaration"
    },
    {
        "name": "TSFunctionType",
        "value": "TSFunctionType"
    },
    {
        "name": "TSMethodSignature",
        "value": "TSMethodSignature"
    },
    {
        "name": "TSModuleBlock",
        "value": "TSModuleBlock"
    },
    {
        "name": "TSModuleDeclaration",
        "value": "TSModuleDeclaration"
    },
    {
        "name": "TSNamespaceExportDeclaration",
        "value": "TSNamespaceExportDeclaration"
    },
    {
        "name": "TSNonNullExpression",
        "value": "TSNonNullExpression"
    },
    {
        "name": "TSNeverKeyword",
        "value": "TSNeverKeyword"
    },
    {
        "name": "TSNullKeyword",
        "value": "TSNullKeyword"
    },
    {
        "name": "TSNumberKeyword",
        "value": "TSNumberKeyword"
    },
    {
        "name": "TSMappedType",
        "value": "TSMappedType"
    },
    {
        "name": "TSObjectKeyword",
        "value": "TSObjectKeyword"
    },
    {
        "name": "TSParameterProperty",
        "value": "TSParameterProperty"
    },
    {
        "name": "TSPrivateKeyword",
        "value": "TSPrivateKeyword"
    },
    {
        "name": "TSPropertySignature",
        "value": "TSPropertySignature"
    },
    {
        "name": "TSProtectedKeyword",
        "value": "TSProtectedKeyword"
    },
    {
        "name": "TSPublicKeyword",
        "value": "TSPublicKeyword"
    },
    {
        "name": "TSQualifiedName",
        "value": "TSQualifiedName"
    },
    {
        "name": "TSQuestionToken",
        "value": "TSQuestionToken"
    },
    {
        "name": "TSReadonlyKeyword",
        "value": "TSReadonlyKeyword"
    },
    {
        "name": "TSRestType",
        "value": "TSRestType"
    },
    {
        "name": "TSStaticKeyword",
        "value": "TSStaticKeyword"
    },
    {
        "name": "TSStringKeyword",
        "value": "TSStringKeyword"
    },
    {
        "name": "TSSymbolKeyword",
        "value": "TSSymbolKeyword"
    },
    {
        "name": "TSThisType",
        "value": "TSThisType"
    },
    {
        "name": "TSTypeAnnotation",
        "value": "TSTypeAnnotation"
    },
    {
        "name": "TSTypeAliasDeclaration",
        "value": "TSTypeAliasDeclaration"
    },
    {
        "name": "TSTypeAssertion",
        "value": "TSTypeAssertion"
    },
    {
        "name": "TSTypeLiteral",
        "value": "TSTypeLiteral"
    },
    {
        "name": "TSTypeOperator",
        "value": "TSTypeOperator"
    },
    {
        "name": "TSTypeParameter",
        "value": "TSTypeParameter"
    },
    {
        "name": "TSTypeParameterDeclaration",
        "value": "TSTypeParameterDeclaration"
    },
    {
        "name": "TSTypeParameterInstantiation",
        "value": "TSTypeParameterInstantiation"
    },
    {
        "name": "TSTypePredicate",
        "value": "TSTypePredicate"
    },
    {
        "name": "TSTypeReference",
        "value": "TSTypeReference"
    },
    {
        "name": "TSTypeQuery",
        "value": "TSTypeQuery"
    },
    {
        "name": "TSIntersectionType",
        "value": "TSIntersectionType"
    },
    {
        "name": "TSTupleType",
        "value": "TSTupleType"
    },
    {
        "name": "TSOptionalType",
        "value": "TSOptionalType"
    },
    {
        "name": "TSParenthesizedType",
        "value": "TSParenthesizedType"
    },
    {
        "name": "TSUnionType",
        "value": "TSUnionType"
    },
    {
        "name": "TSUndefinedKeyword",
        "value": "TSUndefinedKeyword"
    },
    {
        "name": "TSUnknownKeyword",
        "value": "TSUnknownKeyword"
    },
    {
        "name": "TSVoidKeyword",
        "value": "TSVoidKeyword"
    }
];
  //