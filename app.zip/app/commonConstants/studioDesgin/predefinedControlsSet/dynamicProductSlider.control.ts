export function dynamicProductcardSliderFn (){

   const pageCount =   localStorage.getItem("totalPageCount")|| new Date().getTime();

   const dynamicProductcardSlider = {
    "type": "dynamicPredefinedCtrl",
    "icon": "fas fa-tags",
    "description": "Row Here",
    "subtype": "productcardslider",
    "handle": true,
    "studioDevClasses": "d-block",
    "angular": {
      
    },
    "database": {
      
    },
    "events": {
      "selectedEventList": [
        
      ],
      "eventData": [
        
      ]
    },
    "properties": {
      "name": "",
      "label": "customTag",
      "visibility": true,
      "customTagType":"div",
      "placeholder": "Custom Tag Area",
      "animationCss": "",
      "selectedAnimationArray": [
        
      ],
      "elementClass": "",
      "selectedElementClassArray": [
        
      ],
      "additionElementClass": "",
      "defaultElementCls": "",
      "elementInnerStyles": {
        
      },
      "globelAttrLogic": "",
      "controlBindingType": "static"
    },
    "subDataArray": [
      { 
        "type": "predefinedNode",
        "subtype": "predefinedPage",
        "ngGenerate": {
          "ngType": "page",
          "ngName": "productcardslider" + pageCount,
          "ngAuthor": "Ravinder Singh",
          "ngDesc": "Product Sliders",
          "ngServiceType": "providedInRoot",
        },
        "creationPath": "/src/app/custommodules",
        "data": {
          "htmlData": [
            {
              "sag_G_Index": 2,
              "bindFromResponseVariable": null,
              "attributeLogiclayer": [
                {
                  "name": "Globel AttrLogic",
                  "selAttrs": [
                    "*ngIf"
                  ],
                  "label": "globelAttrLogic",
                  "id": null,
                  "type": "globelAttrLogics",
                  "value": "globelLogic",
                  "attrList": [
                    {
                      "optValue": "methodResponse1666091933366?.data",
                      "name": "If Block",
                      "selKeyForBindValue": "methodResponse1666091933366?.data",
                      "label": "*ngIf",
                      "id": null,
                      "type": "ifBlock",
                      "finalValue": "",
                      "value": "*ngIf",
                      "subDataArray": [
                        
                      ]
                    }
                  ]
                },
                {
                  "name": "Element AttrLogic",
                  "selAttrs": [
                    
                  ],
                  "label": "elemAttrLogic",
                  "id": null,
                  "type": "elemAttrLogics",
                  "value": "elemAttrLogic",
                  "attrList": [
                    
                  ]
                }
              ],
              "icon": "fas fa-bandcamp",
              "description": "",
              "globelAttrLogic": {
                "selAttrs": [
                  
                ],
                "attrList": [
                  
                ]
              },
              "parseCtrl": {
                "subData": false,
                "layerCount": "2",
                "layerTopId": "owlCarousel~owlCarousel#Globel",
                "layerCtrls": [
                  "owlCarousel~owlCarousel#Globel",
                  "owlCarousel~owlCarousel#Element"
                ]
              },
              "type": "owlCarousel",
              "projectConfigProperties": [
                "label",
                "name",
                "disable",
                "visibility"
              ],
              "database": {
                
              },
              "subtype": "owlCarousel",
              "children": [
                {
                  "sag_G_Index": 3,
                  "attributeLogiclayer": [
                    {
                      "name": "Globel AttrLogic",
                      "selAttrs": [
                        "*ngFor"
                      ],
                      "label": "globelAttrLogic",
                      "id": null,
                      "type": "globelAttrLogics",
                      "value": "globelLogic",
                      "attrList": [
                        {
                          "name": "forEach Loop",
                          "selOptionsList": [
                            {
                              "optValue": "",
                              "attrArrIndex": "_index",
                              "attrItemName": "_item",
                              "name": "*ngFor",
                              "moreAttributes": {
                                "selOptionsList": [
                                  
                                ],
                                "selOptions": [
                                  
                                ]
                              },
                              "attrInterface": "",
                              "attrArrType": "",
                              "label": "Loop",
                              "id": null,
                              "attrArrName": "methodResponse1666091933366?.data",
                              "type": "",
                              "value": "*ngFor"
                            }
                          ],
                          "label": "Loop",
                          "id": null,
                          "type": "forEachLoop",
                          "finalValue": "",
                          "value": "*ngFor",
                          "subDataArray": [
                            
                          ],
                          "selOptions": [
                            "*ngFor"
                          ]
                        }
                      ]
                    },
                    {
                      "name": "Element AttrLogic",
                      "selAttrs": [
                        
                      ],
                      "label": "elemAttrLogic",
                      "id": null,
                      "type": "elemAttrLogics",
                      "value": "elemAttrLogic",
                      "attrList": [
                        
                      ]
                    }
                  ],
                  "icon": "fas fa-bandcamp",
                  "description": "owl carousel loop on",
                  "parseCtrl": {
                    "subData": false,
                    "layerCount": "2",
                    "layerTopId": "owlCarouselItem~owlCarouselItem#Globel",
                    "layerCtrls": [
                      "owlCarouselItem~owlCarouselItem#Globel",
                      "owlCarouselItem~owlCarouselItem#Element"
                    ]
                  },
                  "type": "owlCarouselItem",
                  "projectConfigProperties": [
                    "changeType",
                    "name",
                    "label",
                    "title",
                    "src",
                    "description",
                    "width",
                    "height",
                    "visibility",
                    "imgBlob",
                    "typeSlider",
                    "sections",
                    "globelAttrLogic",
                    "controlBindingType"
                  ],
                  "database": {
                    "onExcessLoad": false,
                    "databaseName": "",
                    "dbMappingState": "none",
                    "columnInfo": {
                      
                    },
                    "tableName": "",
                    "columnName": "",
                    "dbMappingMsg": "",
                    "master": false
                  },
                  "subtype": "owlCarouselItem",
                  "children": [
                    
                  ],
                  "id": null,
                  "events": {
                    "selectedEventList": [
                      
                    ],
                    "eventData": [
                      
                    ]
                  },
                  "bindingType": "*ngFor",
                  "isCurrentlySelected": true,
                  "handle": true,
                  "label": "owlCarousel",
                  "studioDevClasses": "d-block",
                  "parentId": null,
                  "angular": {
                    "tooltipTitle": "",
                    "formType": "none",
                    "validationMsg": "",
                    "toolTipPosition": "top",
                    "formGroupName": "",
                    "toolTipEvent": "mouseenter",
                    "validators": [
                      
                    ],
                    "toolTip": "i am Toop Tip",
                    "selectedValidatorsForControls": [
                      
                    ],
                    "toolTipShow": false
                  },
                  "applicableAttributeLogic": [
                    "globelLogic",
                    "elemAttrLogic"
                  ],
                  "takeNodeBinding": "optFromService",
                  "sno": 4,
                  "name": "lightBox",
                  "subDataArray": [
                    {
                      "sag_G_Index": 4,
                      "attributeLogiclayer": [
                        {
                          "name": "Globel AttrLogic",
                          "selAttrs": [
                            
                          ],
                          "label": "globelAttrLogic",
                          "id": null,
                          "type": "globelAttrLogics",
                          "value": "globelLogic",
                          "attrList": [
                            
                          ]
                        },
                        {
                          "name": "Element AttrLogic",
                          "selAttrs": [
                            "label",
                            "tooltip"
                          ],
                          "label": "elemAttrLogic",
                          "id": null,
                          "type": "elemAttrLogics",
                          "value": "elemAttrLogic",
                          "attrList": [
                            {
                              "optValue": "",
                              "name": "label",
                              "label": "label",
                              "id": null,
                              "type": "label",
                              "value": "label",
                              "subDataArray": [
                                
                              ]
                            },
                            {
                              "optValue": "",
                              "name": "tooltip",
                              "label": "tooltip",
                              "id": null,
                              "type": "tooltip",
                              "value": "tooltip",
                              "subDataArray": [
                                
                              ]
                            }
                          ]
                        }
                      ],
                      "icon": "fa-columns",
                      "isCurrentlySelected": true,
                      "description": "htmlTag Here",
                      "handle": true,
                      "parseCtrl": {
                        "subData": false,
                        "layerCount": "1",
                        "layerTopId": "htmlTag~div#Element",
                        "layerCtrls": [
                          "htmlTag~div#Element"
                        ]
                      },
                      "label": "",
                      "type": "htmlTag",
                      "studioDevClasses": "",
                      "projectConfigProperties": [
                        "name",
                        "label",
                        "visibility",
                        "textContent",
                        "animationCss",
                        "hoverClasses",
                        "attributeLogiclayer",
                        "formType",
                        "formGroupName",
                        "expandCollapseForCtrl",
                        "selectedEventList",
                        "combineAllModel",
                        "globelAttrLogic",
                        "controlBindingType"
                      ],
                      "parentId": null,
                      "angular": {
                        "tooltipTitle": "",
                        "formType": "none",
                        "validationMsg": "",
                        "toolTipPosition": "top",
                        "formGroupName": "",
                        "toolTipEvent": "mouseenter",
                        "validators": [
                          
                        ],
                        "toolTip": "i am Toop Tip",
                        "selectedValidatorsForControls": [
                          
                        ],
                        "appliedEvents": [
                          
                        ],
                        "toolTipShow": false
                      },
                      "errorText": "Please select a valid Div",
                      "applicableAttributeLogic": [
                        "globelLogic",
                        "elemAttrLogic"
                      ],
                      "database": {
                        "onExcessLoad": false,
                        "databaseName": "",
                        "dbMappingState": "none",
                        "columnInfo": {
                          
                        },
                        "tableName": "",
                        "columnName": "",
                        "dbMappingMsg": "",
                        "master": false
                      },
                      "subtype": "div",
                      "sno": 5,
                      "name": "htmlTag_1666091085215",
                      "id": "htmlTag_1666091085215",
                      "subDataArray": [
                        {
                          "sag_G_Index": 6,
                          "attributeLogiclayer": [
                            {
                              "name": "Globel AttrLogic",
                              "selAttrs": [
                                
                              ],
                              "label": "globelAttrLogic",
                              "id": null,
                              "type": "globelAttrLogics",
                              "value": "globelLogic",
                              "attrList": [
                                
                              ]
                            },
                            {
                              "name": "Element AttrLogic",
                              "selAttrs": [
                                "label",
                                "tooltip"
                              ],
                              "label": "elemAttrLogic",
                              "id": null,
                              "type": "elemAttrLogics",
                              "value": "elemAttrLogic",
                              "attrList": [
                                {
                                  "optValue": "",
                                  "name": "label",
                                  "label": "label",
                                  "id": null,
                                  "type": "label",
                                  "value": "label",
                                  "subDataArray": [
                                    
                                  ]
                                },
                                {
                                  "optValue": "",
                                  "name": "tooltip",
                                  "label": "tooltip",
                                  "id": null,
                                  "type": "tooltip",
                                  "value": "tooltip",
                                  "subDataArray": [
                                    
                                  ]
                                }
                              ]
                            }
                          ],
                          "icon": "fa-columns",
                          "isCurrentlySelected": false,
                          "description": "htmlTag Here",
                          "handle": true,
                          "parseCtrl": {
                            "subData": false,
                            "layerCount": "1",
                            "layerTopId": "htmlTag~div#Element",
                            "layerCtrls": [
                              "htmlTag~div#Element"
                            ]
                          },
                          "label": "",
                          "type": "htmlTag",
                          "studioDevClasses": "",
                          "projectConfigProperties": [
                            "name",
                            "label",
                            "visibility",
                            "textContent",
                            "animationCss",
                            "hoverClasses",
                            "attributeLogiclayer",
                            "formType",
                            "formGroupName",
                            "expandCollapseForCtrl",
                            "selectedEventList",
                            "combineAllModel",
                            "globelAttrLogic",
                            "controlBindingType"
                          ],
                          "parentId": "htmlTag_1665142507517",
                          "angular": {
                            "tooltipTitle": "",
                            "formType": "none",
                            "validationMsg": "",
                            "toolTipPosition": "top",
                            "formGroupName": "",
                            "toolTipEvent": "mouseenter",
                            "validators": [
                              
                            ],
                            "toolTip": "i am Toop Tip",
                            "selectedValidatorsForControls": [
                              
                            ],
                            "appliedEvents": [
                              
                            ],
                            "toolTipShow": false
                          },
                          "errorText": "Please select a valid Div",
                          "applicableAttributeLogic": [
                            "globelLogic",
                            "elemAttrLogic"
                          ],
                          "database": {
                            "onExcessLoad": false,
                            "databaseName": "",
                            "dbMappingState": "none",
                            "columnInfo": {
                              
                            },
                            "tableName": "",
                            "columnName": "",
                            "dbMappingMsg": "",
                            "master": false
                          },
                          "subtype": "div",
                          "sno": 7,
                          "name": "htmlTag_1665142799144",
                          "id": "htmlTag_1665142799144",
                          "subDataArray": [
                            {
                              "type": "image",
                              "icon": "fa fa-camera",
                              "description": " img Description ",
                              "subtype": "image",
                              "handle": true,
                              "studioDevClasses": "d-inline-block",
                              "angular": {
                                "formType": "none",
                                "formGroupName": "",
                                "validationMsg": "",
                                "validators": [
                                  
                                ],
                                "selectedValidatorsForControls": [
                                  
                                ],
                                "tooltipTitle": "",
                                "toolTipShow": false,
                                "toolTipPosition": "top",
                                "toolTipEvent": "mouseenter"
                              },
                              "events": {
                                "selectedEventList": [
                                  
                                ],
                                "eventData": [
                                  
                                ]
                              },
                              "database": {
                                "databaseName": "codedb",
                                "tableName": "product_card",
                                "columnName": "productImage",
                                "columnInfo": {
                                  "entitylabel": "productImage",
                                  "size": "2147483647",
                                  "pentity": null,
                                  "fkey": "N",
                                  "name": "product_image",
                                  "pkey": "N",
                                  "type": "LONGTEXT"
                                },
                                "dbMappingState": "invalid",
                                "dbMappingMsg": "Type : LONGTEXT\\n     Size : 2147483647\\n     PrimaryKey :No\\n     ForeignKey :No\\n     ParentEntity: null \\n    ",
                                "onExcessLoad": false,
                                "master": false
                              },
                              "properties": {
                                "label": "Image",
                                "placeholder": "Your Image",
                                "name": "image_1669007253999",
                                "animationCss": "",
                                "visibility": true,
                                "disable": false,
                                "srcType": "online",
                                "base64Src": "",
                                "src": "https://m.media-amazon.com/images/W/WEBP_402378-T1/images/I/71026UgOrML._SY679_.jpg",
                                "width": "150",
                                "height": "200",
                                "selectedAnimationArray": [
                                  
                                ],
                                "elementClass": "",
                                "selectedElementClassArray": [
                                  
                                ],
                                "additionElementClass": "",
                                "defaultElementCls": "image~image#Element p-2",
                                "elementInnerStyles": {
                                  
                                },
                                "globelAttrLogic": "",
                                "controlBindingType": "static"
                              },
                              "parseCtrl": {
                                "subData": false,
                                "layerTopId": "image~image#Element",
                                "layerCount": "2",
                                "layerCtrls": [
                                  "image~image#Element"
                                ]
                              },
                              "subDataArray": [
                                
                              ],
                              "id": "image_1669007253999",
                              "parentId": "htmlTag_1665142799144",
                              "isCurrentlySelected": false,
                              "errorText": "Please enter a valid Value",
                              "projectConfigProperties": [
                                "name",
                                "src",
                                "width",
                                "height",
                                "animationCss",
                                "imgBlob",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ],
                              "windowProperties": [
                                "name",
                                "srcType",
                                "src",
                                "width",
                                "height",
                                "visibility",
                                "animationCss",
                                "imgBlob",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "databaseName",
                                "tableName",
                                "columnName",
                                "onExcessLoad",
                                "master",
                                "globelAttrLogic",
                                "controlBindingType"
                              ],
                              "attributeLogiclayer": [
                                {
                                  "label": "globelAttrLogic",
                                  "name": "Globel AttrLogic",
                                  "value": "globelLogic",
                                  "type": "globelAttrLogics",
                                  "id": null,
                                  "selAttrs": [
                                    
                                  ],
                                  "attrList": [
                                    
                                  ]
                                },
                                {
                                  "label": "elemAttrLogic",
                                  "name": "Element AttrLogic",
                                  "value": "elemAttrLogic",
                                  "type": "elemAttrLogics",
                                  "id": null,
                                  "selAttrs": [
                                    "src"
                                  ],
                                  "attrList": [
                                    
                                  ]
                                }
                              ]
                            },
                            {
                              "sag_G_Index": 7,
                              "attributeLogiclayer": [
                                {
                                  "name": "Globel AttrLogic",
                                  "selAttrs": [
                                    
                                  ],
                                  "label": "globelAttrLogic",
                                  "id": null,
                                  "type": "globelAttrLogics",
                                  "value": "globelLogic",
                                  "attrList": [
                                    
                                  ]
                                },
                                {
                                  "name": "Element AttrLogic",
                                  "selAttrs": [
                                    "[hidden]"
                                  ],
                                  "label": "elemAttrLogic",
                                  "id": null,
                                  "type": "elemAttrLogics",
                                  "value": "elemAttrLogic",
                                  "attrList": [
                                    {
                                      "optValue": "!apiData?.headings_1665142836496",
                                      "name": "[hidden]",
                                      "label": "[hidden]",
                                      "id": null,
                                      "type": "[hidden]",
                                      "finalValue": "!apiData?.headings_1665142836496",
                                      "value": "[hidden]",
                                      "subDataArray": [
                                        
                                      ]
                                    }
                                  ]
                                }
                              ],
                              "icon": "fas fa-heading",
                              "description": "Enter your heading",
                              "parseCtrl": {
                                "subData": false,
                                "layerCount": "2",
                                "layerTopId": "headings~headings#Globel",
                                "layerCtrls": [
                                  "headings~headings#Element"
                                ]
                              },
                              "bindedFromService_label": "{{_item.caption}}",
                              "type": "headings",
                              "projectConfigProperties": [
                                "headingType",
                                "name",
                                "label",
                                "visibility",
                                "iconPosition",
                                "iconClass",
                                "animationCss",
                                "expandCollapseForCtrl",
                                "globelAttrLogic",
                                "controlBindingType",
                                "formType",
                                "formGroupName",
                                "custom_msgAdd",
                                "allValidationList",
                                "tooltip",
                                "selectedEventList",
                                "combineAllModel",
                                "databaseName",
                                "tableName",
                                "columnName",
                                "onExcessLoad",
                                "master"
                              ],
                              "database": {
                                "onExcessLoad": false,
                                "databaseName": "codedb",
                                "dbMappingState": "invalid",
                                "tableName": "product_card",
                                "columnName": "productCaption",
                                "dbMappingMsg": "Type : VARCHAR\\n     Size : 100\\n     PrimaryKey :No\\n     ForeignKey :No\\n     ParentEntity: null \\n    ",
                                "master": false,
                                "columnInfo": {
                                  "entitylabel": "productCaption",
                                  "size": "100",
                                  "pentity": null,
                                  "fkey": "N",
                                  "name": "product_caption",
                                  "pkey": "N",
                                  "type": "VARCHAR"
                                }
                              },
                              "subtype": "headings",
                              "id": "headings_1665142836496",
                              "events": {
                                "selectedEventList": [
                                  
                                ],
                                "eventData": [
                                  
                                ]
                              },
                              "isCurrentlySelected": false,
                              "handle": true,
                              "label": "Lorem Ipsum is simply dummy text of the printing industry.",
                              "studioDevClasses": "d-block",
                              "parentId": "htmlTag_1665142799144",
                              "angular": {
                                "tooltipTitle": "",
                                "formType": "none",
                                "validationMsg": "",
                                "toolTipPosition": "top",
                                "formGroupName": "",
                                "toolTipEvent": "mouseenter",
                                "validators": [
                                  
                                ],
                                "selectedValidatorsForControls": [
                                  
                                ],
                                "toolTipShow": false
                              },
                              "errorText": "Please enter a valid Value",
                              "applicableAttributeLogic": [
                                "globelLogic",
                                "elemAttrLogic"
                              ],
                              "takeNodeBinding": "optFromService",
                              "sno": 8,
                              "name": "caption",
                              "subDataArray": [
                                
                              ],
                              "properties": {
                                "visibility": 0,
                                "selectedElementClassArray": [
                                  
                                ],
                                "headingValue": "5",
                                "animationCss": "",
                                "globelAttrLogic": "",
                                "label": "Lorem Ipsum is simply dummy text of the printing industry.",
                                "required": false,
                                "iconClass": "",
                                "additionElementClass": "",
                                "name": "caption",
                                "iconPosition": "before",
                                "defaultElementCls": "",
                                "elementInnerStyles": {
                                  
                                },
                                "controlBindingType": "static",
                                "placeholder": null,
                                "elementClass": "",
                                "starSymbol": false,
                                "selectedAnimationArray": [
                                  
                                ]
                              },
                              "windowProperties": [
                                "headingType",
                                "name",
                                "label",
                                "visibility",
                                "iconPosition",
                                "iconClass",
                                "animationCss",
                                "expandCollapseForCtrl",
                                "globelAttrLogic",
                                "controlBindingType",
                                "formType",
                                "formGroupName",
                                "custom_msgAdd",
                                "allValidationList",
                                "tooltip",
                                "selectedEventList",
                                "combineAllModel",
                                "databaseName",
                                "tableName",
                                "columnName",
                                "onExcessLoad",
                                "master"
                              ]
                            },
                            {
                              "attributeLogiclayer": [
                                {
                                  "name": "Globel AttrLogic",
                                  "selAttrs": [
                                    
                                  ],
                                  "label": "globelAttrLogic",
                                  "id": null,
                                  "type": "globelAttrLogics",
                                  "value": "globelLogic",
                                  "attrList": [
                                    
                                  ]
                                },
                                {
                                  "name": "Element AttrLogic",
                                  "selAttrs": [
                                    "label",
                                    "tooltip"
                                  ],
                                  "label": "elemAttrLogic",
                                  "id": null,
                                  "type": "elemAttrLogics",
                                  "value": "elemAttrLogic",
                                  "attrList": [
                                    {
                                      "optValue": "",
                                      "name": "label",
                                      "label": "label",
                                      "id": null,
                                      "type": "label",
                                      "value": "label",
                                      "subDataArray": [
                                        
                                      ]
                                    },
                                    {
                                      "optValue": "",
                                      "name": "tooltip",
                                      "label": "tooltip",
                                      "id": null,
                                      "type": "tooltip",
                                      "value": "tooltip",
                                      "subDataArray": [
                                        
                                      ]
                                    }
                                  ]
                                }
                              ],
                              "icon": "fa-columns",
                              "isCurrentlySelected": false,
                              "description": "htmlTag Here",
                              "handle": true,
                              "parseCtrl": {
                                "subData": false,
                                "layerCount": "1",
                                "layerTopId": "htmlTag~div#Element",
                                "layerCtrls": [
                                  "htmlTag~div#Element"
                                ]
                              },
                              "type": "htmlTag",
                              "studioDevClasses": "",
                              "projectConfigProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ],
                              "parentId": "htmlTag_1665142799144",
                              "angular": {
                                "tooltipTitle": "",
                                "formType": "none",
                                "validationMsg": "",
                                "toolTipPosition": "top",
                                "formGroupName": "",
                                "toolTipEvent": "mouseenter",
                                "validators": [
                                  
                                ],
                                "toolTip": "i am Toop Tip",
                                "selectedValidatorsForControls": [
                                  
                                ],
                                "appliedEvents": [
                                  
                                ],
                                "toolTipShow": false
                              },
                              "errorText": "Please select a valid Div",
                              "applicableAttributeLogic": [
                                "globelLogic",
                                "elemAttrLogic"
                              ],
                              "database": {
                                "onExcessLoad": false,
                                "databaseName": "",
                                "dbMappingState": "none",
                                "columnInfo": {
                                  
                                },
                                "tableName": "",
                                "columnName": "",
                                "dbMappingMsg": "",
                                "master": false
                              },
                              "subtype": "ul",
                              "id": "htmlTag_1665142947816",
                              "subDataArray": [
                                {
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "label",
                                        "tooltip"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "",
                                          "name": "label",
                                          "label": "label",
                                          "id": null,
                                          "type": "label",
                                          "value": "label",
                                          "subDataArray": [
                                            
                                          ]
                                        },
                                        {
                                          "optValue": "",
                                          "name": "tooltip",
                                          "label": "tooltip",
                                          "id": null,
                                          "type": "tooltip",
                                          "value": "tooltip",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": true,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "type": "htmlTag",
                                  "studioDevClasses": "",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665142947816",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "columnInfo": {
                                      
                                    },
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "li",
                                  "id": "htmlTag_1665143055515",
                                  "subDataArray": [
                                    {
                                      "sag_G_Index": 8,
                                      "attributeLogiclayer": [
                                        {
                                          "name": "Globel AttrLogic",
                                          "selAttrs": [
                                            
                                          ],
                                          "label": "globelAttrLogic",
                                          "id": null,
                                          "type": "globelAttrLogics",
                                          "value": "globelLogic",
                                          "attrList": [
                                            
                                          ]
                                        },
                                        {
                                          "name": "Element AttrLogic",
                                          "selAttrs": [
                                            "label",
                                            "tooltip"
                                          ],
                                          "label": "elemAttrLogic",
                                          "id": null,
                                          "type": "elemAttrLogics",
                                          "value": "elemAttrLogic",
                                          "attrList": [
                                            {
                                              "optValue": "",
                                              "name": "label",
                                              "label": "label",
                                              "id": null,
                                              "type": "label",
                                              "value": "label",
                                              "subDataArray": [
                                                
                                              ]
                                            },
                                            {
                                              "optValue": "",
                                              "name": "tooltip",
                                              "label": "tooltip",
                                              "id": null,
                                              "type": "tooltip",
                                              "value": "tooltip",
                                              "subDataArray": [
                                                
                                              ]
                                            }
                                          ]
                                        }
                                      ],
                                      "icon": "fa fa-bookmark",
                                      "isCurrentlySelected": false,
                                      "description": "fontIcon Description",
                                      "handle": true,
                                      "parseCtrl": {
                                        "subData": false,
                                        "layerCount": "2",
                                        "layerTopId": "fontIcon~fontIcon#Element",
                                        "layerCtrls": [
                                          "fontIcon~fontIcon#Element"
                                        ]
                                      },
                                      "label": "Font Awesome Icon",
                                      "type": "fontIcon",
                                      "studioDevClasses": "d-inline-block",
                                      "projectConfigProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility"
                                      ],
                                      "parentId": "htmlTag_1665142963785",
                                      "angular": {
                                        "tooltipTitle": "",
                                        "formType": "none",
                                        "validationMsg": "",
                                        "toolTipPosition": "top",
                                        "formGroupName": "",
                                        "toolTipEvent": "mouseenter",
                                        "validators": [
                                          
                                        ],
                                        "selectedValidatorsForControls": [
                                          
                                        ],
                                        "toolTipShow": false
                                      },
                                      "errorText": "Please enter a valid Value",
                                      "database": {
                                        "onExcessLoad": false,
                                        "databaseName": "",
                                        "dbMappingState": "none",
                                        "columnInfo": {
                                          
                                        },
                                        "tableName": "",
                                        "columnName": "",
                                        "dbMappingMsg": "",
                                        "master": false
                                      },
                                      "subtype": "fontIcon",
                                      "sno": 9,
                                      "name": "fontIcon10_1665143055561",
                                      "id": "fontIcon10_1665143055561",
                                      "subDataArray": [
                                        
                                      ],
                                      "events": {
                                        "selectedEventList": [
                                          
                                        ],
                                        "eventData": [
                                          
                                        ]
                                      },
                                      "properties": {
                                        "visibility": true,
                                        "selectedElementClassArray": [
                                          
                                        ],
                                        "animationCss": "",
                                        "globelAttrLogic": "",
                                        "label": "Font Awesome Icon",
                                        "iconClass": "fa fa-star",
                                        "additionElementClass": "icon",
                                        "disable": false,
                                        "name": "fontIcon10_1665143055561",
                                        "defaultElementCls": "text-warning",
                                        "elementInnerStyles": {
                                          "font-size": "20px"
                                        },
                                        "controlBindingType": "static",
                                        "placeholder": "Font Icon ",
                                        "elementClass": "",
                                        "selectedAnimationArray": [
                                          
                                        ]
                                      },
                                      "windowProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility",
                                        "animationCss",
                                        "expandCollapseForCtrl",
                                        "globelAttrLogic",
                                        "controlBindingType",
                                        "selectedEventList",
                                        "combineAllModel"
                                      ]
                                    }
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": true,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "htmlTag_1665143055515",
                                    "defaultElementCls": "p-0   d-inline    list-unstyled",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "label",
                                        "tooltip"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "",
                                          "name": "label",
                                          "label": "label",
                                          "id": null,
                                          "type": "label",
                                          "value": "label",
                                          "subDataArray": [
                                            
                                          ]
                                        },
                                        {
                                          "optValue": "",
                                          "name": "tooltip",
                                          "label": "tooltip",
                                          "id": null,
                                          "type": "tooltip",
                                          "value": "tooltip",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": true,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "type": "htmlTag",
                                  "studioDevClasses": "",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665142947816",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "columnInfo": {
                                      
                                    },
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "li",
                                  "id": "htmlTag_1665143200755",
                                  "subDataArray": [
                                    {
                                      "sag_G_Index": 9,
                                      "attributeLogiclayer": [
                                        {
                                          "name": "Globel AttrLogic",
                                          "selAttrs": [
                                            
                                          ],
                                          "label": "globelAttrLogic",
                                          "id": null,
                                          "type": "globelAttrLogics",
                                          "value": "globelLogic",
                                          "attrList": [
                                            
                                          ]
                                        },
                                        {
                                          "name": "Element AttrLogic",
                                          "selAttrs": [
                                            "label",
                                            "tooltip"
                                          ],
                                          "label": "elemAttrLogic",
                                          "id": null,
                                          "type": "elemAttrLogics",
                                          "value": "elemAttrLogic",
                                          "attrList": [
                                            {
                                              "optValue": "",
                                              "name": "label",
                                              "label": "label",
                                              "id": null,
                                              "type": "label",
                                              "value": "label",
                                              "subDataArray": [
                                                
                                              ]
                                            },
                                            {
                                              "optValue": "",
                                              "name": "tooltip",
                                              "label": "tooltip",
                                              "id": null,
                                              "type": "tooltip",
                                              "value": "tooltip",
                                              "subDataArray": [
                                                
                                              ]
                                            }
                                          ]
                                        }
                                      ],
                                      "icon": "fa fa-bookmark",
                                      "isCurrentlySelected": false,
                                      "description": "fontIcon Description",
                                      "handle": true,
                                      "parseCtrl": {
                                        "subData": false,
                                        "layerCount": "2",
                                        "layerTopId": "fontIcon~fontIcon#Element",
                                        "layerCtrls": [
                                          "fontIcon~fontIcon#Element"
                                        ]
                                      },
                                      "label": "Font Awesome Icon",
                                      "type": "fontIcon",
                                      "studioDevClasses": "d-inline-block",
                                      "projectConfigProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility"
                                      ],
                                      "parentId": "htmlTag_1665142963785",
                                      "angular": {
                                        "tooltipTitle": "",
                                        "formType": "none",
                                        "validationMsg": "",
                                        "toolTipPosition": "top",
                                        "formGroupName": "",
                                        "toolTipEvent": "mouseenter",
                                        "validators": [
                                          
                                        ],
                                        "selectedValidatorsForControls": [
                                          
                                        ],
                                        "toolTipShow": false
                                      },
                                      "errorText": "Please enter a valid Value",
                                      "database": {
                                        "onExcessLoad": false,
                                        "databaseName": "",
                                        "dbMappingState": "none",
                                        "columnInfo": {
                                          
                                        },
                                        "tableName": "",
                                        "columnName": "",
                                        "dbMappingMsg": "",
                                        "master": false
                                      },
                                      "subtype": "fontIcon",
                                      "sno": 10,
                                      "name": "fontIcon10_1665143200812",
                                      "id": "fontIcon10_1665143200812",
                                      "subDataArray": [
                                        
                                      ],
                                      "events": {
                                        "selectedEventList": [
                                          
                                        ],
                                        "eventData": [
                                          
                                        ]
                                      },
                                      "properties": {
                                        "visibility": true,
                                        "selectedElementClassArray": [
                                          
                                        ],
                                        "animationCss": "",
                                        "globelAttrLogic": "",
                                        "label": "Font Awesome Icon",
                                        "iconClass": "fa fa-star",
                                        "additionElementClass": "icon",
                                        "disable": false,
                                        "name": "fontIcon10_1665143200812",
                                        "defaultElementCls": "text-warning",
                                        "elementInnerStyles": {
                                          "font-size": "20px"
                                        },
                                        "controlBindingType": "static",
                                        "placeholder": "Font Icon ",
                                        "elementClass": "",
                                        "selectedAnimationArray": [
                                          
                                        ]
                                      },
                                      "windowProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility",
                                        "animationCss",
                                        "expandCollapseForCtrl",
                                        "globelAttrLogic",
                                        "controlBindingType",
                                        "selectedEventList",
                                        "combineAllModel"
                                      ]
                                    }
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": true,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "htmlTag_1665143200755",
                                    "defaultElementCls": "d-inline     list-unstyled ",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "label",
                                        "tooltip"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "",
                                          "name": "label",
                                          "label": "label",
                                          "id": null,
                                          "type": "label",
                                          "value": "label",
                                          "subDataArray": [
                                            
                                          ]
                                        },
                                        {
                                          "optValue": "",
                                          "name": "tooltip",
                                          "label": "tooltip",
                                          "id": null,
                                          "type": "tooltip",
                                          "value": "tooltip",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": true,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "type": "htmlTag",
                                  "studioDevClasses": "",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665142947816",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "columnInfo": {
                                      
                                    },
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "li",
                                  "id": "htmlTag_1665143202031",
                                  "subDataArray": [
                                    {
                                      "sag_G_Index": 10,
                                      "attributeLogiclayer": [
                                        {
                                          "name": "Globel AttrLogic",
                                          "selAttrs": [
                                            
                                          ],
                                          "label": "globelAttrLogic",
                                          "id": null,
                                          "type": "globelAttrLogics",
                                          "value": "globelLogic",
                                          "attrList": [
                                            
                                          ]
                                        },
                                        {
                                          "name": "Element AttrLogic",
                                          "selAttrs": [
                                            "label",
                                            "tooltip"
                                          ],
                                          "label": "elemAttrLogic",
                                          "id": null,
                                          "type": "elemAttrLogics",
                                          "value": "elemAttrLogic",
                                          "attrList": [
                                            {
                                              "optValue": "",
                                              "name": "label",
                                              "label": "label",
                                              "id": null,
                                              "type": "label",
                                              "value": "label",
                                              "subDataArray": [
                                                
                                              ]
                                            },
                                            {
                                              "optValue": "",
                                              "name": "tooltip",
                                              "label": "tooltip",
                                              "id": null,
                                              "type": "tooltip",
                                              "value": "tooltip",
                                              "subDataArray": [
                                                
                                              ]
                                            }
                                          ]
                                        }
                                      ],
                                      "icon": "fa fa-bookmark",
                                      "isCurrentlySelected": false,
                                      "description": "fontIcon Description",
                                      "handle": true,
                                      "parseCtrl": {
                                        "subData": false,
                                        "layerCount": "2",
                                        "layerTopId": "fontIcon~fontIcon#Element",
                                        "layerCtrls": [
                                          "fontIcon~fontIcon#Element"
                                        ]
                                      },
                                      "label": "Font Awesome Icon",
                                      "type": "fontIcon",
                                      "studioDevClasses": "d-inline-block",
                                      "projectConfigProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility"
                                      ],
                                      "parentId": "htmlTag_1665142963785",
                                      "angular": {
                                        "tooltipTitle": "",
                                        "formType": "none",
                                        "validationMsg": "",
                                        "toolTipPosition": "top",
                                        "formGroupName": "",
                                        "toolTipEvent": "mouseenter",
                                        "validators": [
                                          
                                        ],
                                        "selectedValidatorsForControls": [
                                          
                                        ],
                                        "toolTipShow": false
                                      },
                                      "errorText": "Please enter a valid Value",
                                      "database": {
                                        "onExcessLoad": false,
                                        "databaseName": "",
                                        "dbMappingState": "none",
                                        "columnInfo": {
                                          
                                        },
                                        "tableName": "",
                                        "columnName": "",
                                        "dbMappingMsg": "",
                                        "master": false
                                      },
                                      "subtype": "fontIcon",
                                      "sno": 11,
                                      "name": "fontIcon10_1665143202031",
                                      "id": "fontIcon10_1665143202031",
                                      "subDataArray": [
                                        
                                      ],
                                      "events": {
                                        "selectedEventList": [
                                          
                                        ],
                                        "eventData": [
                                          
                                        ]
                                      },
                                      "properties": {
                                        "visibility": true,
                                        "selectedElementClassArray": [
                                          
                                        ],
                                        "animationCss": "",
                                        "globelAttrLogic": "",
                                        "label": "Font Awesome Icon",
                                        "iconClass": "fa fa-star",
                                        "additionElementClass": "icon",
                                        "disable": false,
                                        "name": "fontIcon10_1665143202031",
                                        "defaultElementCls": "text-warning",
                                        "elementInnerStyles": {
                                          "font-size": "20px"
                                        },
                                        "controlBindingType": "static",
                                        "placeholder": "Font Icon ",
                                        "elementClass": "",
                                        "selectedAnimationArray": [
                                          
                                        ]
                                      },
                                      "windowProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility",
                                        "animationCss",
                                        "expandCollapseForCtrl",
                                        "globelAttrLogic",
                                        "controlBindingType",
                                        "selectedEventList",
                                        "combineAllModel"
                                      ]
                                    }
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": true,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "htmlTag_1665143202031",
                                    "defaultElementCls": "d-inline     list-unstyled ",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "label",
                                        "tooltip"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "",
                                          "name": "label",
                                          "label": "label",
                                          "id": null,
                                          "type": "label",
                                          "value": "label",
                                          "subDataArray": [
                                            
                                          ]
                                        },
                                        {
                                          "optValue": "",
                                          "name": "tooltip",
                                          "label": "tooltip",
                                          "id": null,
                                          "type": "tooltip",
                                          "value": "tooltip",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": true,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "type": "htmlTag",
                                  "studioDevClasses": "",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665142947816",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "columnInfo": {
                                      
                                    },
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "li",
                                  "id": "htmlTag_1665143203446",
                                  "subDataArray": [
                                    {
                                      "sag_G_Index": 11,
                                      "attributeLogiclayer": [
                                        {
                                          "name": "Globel AttrLogic",
                                          "selAttrs": [
                                            
                                          ],
                                          "label": "globelAttrLogic",
                                          "id": null,
                                          "type": "globelAttrLogics",
                                          "value": "globelLogic",
                                          "attrList": [
                                            
                                          ]
                                        },
                                        {
                                          "name": "Element AttrLogic",
                                          "selAttrs": [
                                            "label",
                                            "tooltip"
                                          ],
                                          "label": "elemAttrLogic",
                                          "id": null,
                                          "type": "elemAttrLogics",
                                          "value": "elemAttrLogic",
                                          "attrList": [
                                            {
                                              "optValue": "",
                                              "name": "label",
                                              "label": "label",
                                              "id": null,
                                              "type": "label",
                                              "value": "label",
                                              "subDataArray": [
                                                
                                              ]
                                            },
                                            {
                                              "optValue": "",
                                              "name": "tooltip",
                                              "label": "tooltip",
                                              "id": null,
                                              "type": "tooltip",
                                              "value": "tooltip",
                                              "subDataArray": [
                                                
                                              ]
                                            }
                                          ]
                                        }
                                      ],
                                      "icon": "fa fa-bookmark",
                                      "isCurrentlySelected": false,
                                      "description": "fontIcon Description",
                                      "handle": true,
                                      "parseCtrl": {
                                        "subData": false,
                                        "layerCount": "2",
                                        "layerTopId": "fontIcon~fontIcon#Element",
                                        "layerCtrls": [
                                          "fontIcon~fontIcon#Element"
                                        ]
                                      },
                                      "label": "Font Awesome Icon",
                                      "type": "fontIcon",
                                      "studioDevClasses": "d-inline-block",
                                      "projectConfigProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility"
                                      ],
                                      "parentId": "htmlTag_1665142963785",
                                      "angular": {
                                        "tooltipTitle": "",
                                        "formType": "none",
                                        "validationMsg": "",
                                        "toolTipPosition": "top",
                                        "formGroupName": "",
                                        "toolTipEvent": "mouseenter",
                                        "validators": [
                                          
                                        ],
                                        "selectedValidatorsForControls": [
                                          
                                        ],
                                        "toolTipShow": false
                                      },
                                      "errorText": "Please enter a valid Value",
                                      "database": {
                                        "onExcessLoad": false,
                                        "databaseName": "",
                                        "dbMappingState": "none",
                                        "columnInfo": {
                                          
                                        },
                                        "tableName": "",
                                        "columnName": "",
                                        "dbMappingMsg": "",
                                        "master": false
                                      },
                                      "subtype": "fontIcon",
                                      "sno": 12,
                                      "name": "fontIcon10_1665143203446",
                                      "id": "fontIcon10_1665143203446",
                                      "subDataArray": [
                                        
                                      ],
                                      "events": {
                                        "selectedEventList": [
                                          
                                        ],
                                        "eventData": [
                                          
                                        ]
                                      },
                                      "properties": {
                                        "visibility": true,
                                        "selectedElementClassArray": [
                                          
                                        ],
                                        "animationCss": "",
                                        "globelAttrLogic": "",
                                        "label": "Font Awesome Icon",
                                        "iconClass": "fa fa-star",
                                        "additionElementClass": "icon",
                                        "disable": false,
                                        "name": "fontIcon10_1665143203446",
                                        "defaultElementCls": "text-warning",
                                        "elementInnerStyles": {
                                          "font-size": "20px"
                                        },
                                        "controlBindingType": "static",
                                        "placeholder": "Font Icon ",
                                        "elementClass": "",
                                        "selectedAnimationArray": [
                                          
                                        ]
                                      },
                                      "windowProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility",
                                        "animationCss",
                                        "expandCollapseForCtrl",
                                        "globelAttrLogic",
                                        "controlBindingType",
                                        "selectedEventList",
                                        "combineAllModel"
                                      ]
                                    }
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": true,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "htmlTag_1665143203446",
                                    "defaultElementCls": "d-inline     list-unstyled ",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "label",
                                        "tooltip"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "",
                                          "name": "label",
                                          "label": "label",
                                          "id": null,
                                          "type": "label",
                                          "value": "label",
                                          "subDataArray": [
                                            
                                          ]
                                        },
                                        {
                                          "optValue": "",
                                          "name": "tooltip",
                                          "label": "tooltip",
                                          "id": null,
                                          "type": "tooltip",
                                          "value": "tooltip",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": true,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "type": "htmlTag",
                                  "studioDevClasses": "",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665142947816",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "columnInfo": {
                                      
                                    },
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "li",
                                  "id": "htmlTag_1665143227605",
                                  "subDataArray": [
                                    {
                                      "sag_G_Index": 12,
                                      "attributeLogiclayer": [
                                        {
                                          "name": "Globel AttrLogic",
                                          "selAttrs": [
                                            
                                          ],
                                          "label": "globelAttrLogic",
                                          "id": null,
                                          "type": "globelAttrLogics",
                                          "value": "globelLogic",
                                          "attrList": [
                                            
                                          ]
                                        },
                                        {
                                          "name": "Element AttrLogic",
                                          "selAttrs": [
                                            "label",
                                            "tooltip"
                                          ],
                                          "label": "elemAttrLogic",
                                          "id": null,
                                          "type": "elemAttrLogics",
                                          "value": "elemAttrLogic",
                                          "attrList": [
                                            {
                                              "optValue": "",
                                              "name": "label",
                                              "label": "label",
                                              "id": null,
                                              "type": "label",
                                              "value": "label",
                                              "subDataArray": [
                                                
                                              ]
                                            },
                                            {
                                              "optValue": "",
                                              "name": "tooltip",
                                              "label": "tooltip",
                                              "id": null,
                                              "type": "tooltip",
                                              "value": "tooltip",
                                              "subDataArray": [
                                                
                                              ]
                                            }
                                          ]
                                        }
                                      ],
                                      "icon": "fa fa-bookmark",
                                      "isCurrentlySelected": false,
                                      "description": "fontIcon Description",
                                      "handle": true,
                                      "parseCtrl": {
                                        "subData": false,
                                        "layerCount": "2",
                                        "layerTopId": "fontIcon~fontIcon#Element",
                                        "layerCtrls": [
                                          "fontIcon~fontIcon#Element"
                                        ]
                                      },
                                      "label": "Font Awesome Icon",
                                      "type": "fontIcon",
                                      "studioDevClasses": "d-inline-block",
                                      "projectConfigProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility"
                                      ],
                                      "parentId": "htmlTag_1665142963785",
                                      "angular": {
                                        "tooltipTitle": "",
                                        "formType": "none",
                                        "validationMsg": "",
                                        "toolTipPosition": "top",
                                        "formGroupName": "",
                                        "toolTipEvent": "mouseenter",
                                        "validators": [
                                          
                                        ],
                                        "selectedValidatorsForControls": [
                                          
                                        ],
                                        "toolTipShow": false
                                      },
                                      "errorText": "Please enter a valid Value",
                                      "database": {
                                        "onExcessLoad": false,
                                        "databaseName": "",
                                        "dbMappingState": "none",
                                        "columnInfo": {
                                          
                                        },
                                        "tableName": "",
                                        "columnName": "",
                                        "dbMappingMsg": "",
                                        "master": false
                                      },
                                      "subtype": "fontIcon",
                                      "sno": 13,
                                      "name": "fontIcon10_1665143227605",
                                      "id": "fontIcon10_1665143227605",
                                      "subDataArray": [
                                        
                                      ],
                                      "events": {
                                        "selectedEventList": [
                                          
                                        ],
                                        "eventData": [
                                          
                                        ]
                                      },
                                      "properties": {
                                        "visibility": true,
                                        "selectedElementClassArray": [
                                          
                                        ],
                                        "animationCss": "",
                                        "globelAttrLogic": "",
                                        "label": "Font Awesome Icon",
                                        "iconClass": "fa fa-star",
                                        "additionElementClass": "icon",
                                        "disable": false,
                                        "name": "fontIcon10_1665143227605",
                                        "defaultElementCls": "text-warning",
                                        "elementInnerStyles": {
                                          "font-size": "20px"
                                        },
                                        "controlBindingType": "static",
                                        "placeholder": "Font Icon ",
                                        "elementClass": "",
                                        "selectedAnimationArray": [
                                          
                                        ]
                                      },
                                      "windowProperties": [
                                        "name",
                                        "iconClass",
                                        "visibility",
                                        "animationCss",
                                        "expandCollapseForCtrl",
                                        "globelAttrLogic",
                                        "controlBindingType",
                                        "selectedEventList",
                                        "combineAllModel"
                                      ]
                                    }
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": true,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "htmlTag_1665143227605",
                                    "defaultElementCls": "d-inline     list-unstyled ",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "bindedFromService_src": "{{_item.rating}}",
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag_1665142963785",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag_1665142963785",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": true,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "label": "4.5",
                                  "type": "htmlTag",
                                  "studioDevClasses": "",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665142947816",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "takeNodeBinding": "optFromService",
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "codedb",
                                    "dbMappingState": "invalid",
                                    "tableName": "product_card",
                                    "columnName": "productRating",
                                    "dbMappingMsg": "Type : DECIMAL\\n     Size : 10,2\\n     PrimaryKey :No\\n     ForeignKey :No\\n     ParentEntity: null \\n    ",
                                    "master": false,
                                    "columnInfo": {
                                      "entitylabel": "productRating",
                                      "size": "10,2",
                                      "pentity": null,
                                      "fkey": "N",
                                      "name": "product_rating",
                                      "pkey": "N",
                                      "type": "DECIMAL"
                                    }
                                  },
                                  "subtype": "li",
                                  "name": "rating",
                                  "id": "htmlTag_1665142963785",
                                  "subDataArray": [
                                    
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "4.30",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "rating",
                                    "defaultElementCls": "text-success  d-inline     list-unstyled ",
                                    "elementInnerStyles": {
                                      "font-size": "12px"
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType",
                                    "databaseName",
                                    "tableName",
                                    "columnName",
                                    "onExcessLoad",
                                    "master"
                                  ]
                                }
                              ],
                              "events": {
                                "selectedEventList": [
                                  
                                ],
                                "eventData": [
                                  
                                ]
                              },
                              "properties": {
                                "visibility": true,
                                "hoverClasses": "",
                                "selectedElementClassArray": [
                                  
                                ],
                                "animationCss": "",
                                "globelAttrLogic": "",
                                "textContent": "",
                                "label": "",
                                "required": false,
                                "additionElementClass": "",
                                "name": "htmlTag_1665142947816",
                                "defaultElementCls": "p-0 m-0",
                                "elementInnerStyles": {
                                  
                                },
                                "controlBindingType": "static",
                                "elementClass": "",
                                "starSymbol": false,
                                "selectedAnimationArray": [
                                  
                                ]
                              },
                              "windowProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ]
                            },
                            {
                              "attributeLogiclayer": [
                                {
                                  "name": "Globel AttrLogic",
                                  "selAttrs": [
                                    
                                  ],
                                  "label": "globelAttrLogic",
                                  "id": null,
                                  "type": "globelAttrLogics",
                                  "value": "globelLogic",
                                  "attrList": [
                                    
                                  ]
                                },
                                {
                                  "name": "Element AttrLogic",
                                  "selAttrs": [
                                    "label",
                                    "tooltip"
                                  ],
                                  "label": "elemAttrLogic",
                                  "id": null,
                                  "type": "elemAttrLogics",
                                  "value": "elemAttrLogic",
                                  "attrList": [
                                    {
                                      "optValue": "",
                                      "name": "label",
                                      "label": "label",
                                      "id": null,
                                      "type": "label",
                                      "value": "label",
                                      "subDataArray": [
                                        
                                      ]
                                    },
                                    {
                                      "optValue": "",
                                      "name": "tooltip",
                                      "label": "tooltip",
                                      "id": null,
                                      "type": "tooltip",
                                      "value": "tooltip",
                                      "subDataArray": [
                                        
                                      ]
                                    }
                                  ]
                                }
                              ],
                              "icon": "fa-columns",
                              "isCurrentlySelected": false,
                              "description": "htmlTag Here",
                              "handle": true,
                              "parseCtrl": {
                                "subData": false,
                                "layerCount": "1",
                                "layerTopId": "htmlTag~div#Element",
                                "layerCtrls": [
                                  "htmlTag~div#Element"
                                ]
                              },
                              "type": "htmlTag",
                              "studioDevClasses": "",
                              "projectConfigProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ],
                              "parentId": "htmlTag_1665142799144",
                              "angular": {
                                "tooltipTitle": "",
                                "formType": "none",
                                "validationMsg": "",
                                "toolTipPosition": "top",
                                "formGroupName": "",
                                "toolTipEvent": "mouseenter",
                                "validators": [
                                  
                                ],
                                "toolTip": "i am Toop Tip",
                                "selectedValidatorsForControls": [
                                  
                                ],
                                "appliedEvents": [
                                  
                                ],
                                "toolTipShow": false
                              },
                              "errorText": "Please select a valid Div",
                              "applicableAttributeLogic": [
                                "globelLogic",
                                "elemAttrLogic"
                              ],
                              "database": {
                                "onExcessLoad": false,
                                "databaseName": "",
                                "dbMappingState": "none",
                                "columnInfo": {
                                  
                                },
                                "tableName": "",
                                "columnName": "",
                                "dbMappingMsg": "",
                                "master": false
                              },
                              "subtype": "p",
                              "id": "htmlTag_1665143588756",
                              "subDataArray": [
                                {
                                  "sag_G_Index": 13,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag_1666091277529",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag_1666091277529",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": false,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "label": "₹",
                                  "type": "htmlTag",
                                  "studioDevClasses": "d-inline-block",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "span",
                                  "sno": 14,
                                  "name": "htmlTag_1666091277529",
                                  "id": "htmlTag_1666091277529",
                                  "subDataArray": [
                                    
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "₹",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "RupeeSymbol",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      "font-size": "34px"
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "sag_G_Index": 14,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag10_1665143588811",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag10_1665143588811",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "description": "htmlTag Here",
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "bindedFromService_label": "{{_item.price}}",
                                  "type": "htmlTag",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "codedb",
                                    "dbMappingState": "invalid",
                                    "tableName": "product_card",
                                    "columnName": "price",
                                    "dbMappingMsg": "Type : DECIMAL\\n     Size : 10,2\\n     PrimaryKey :No\\n     ForeignKey :No\\n     ParentEntity: null \\n    ",
                                    "master": false,
                                    "columnInfo": {
                                      "entitylabel": "price",
                                      "size": "10,2",
                                      "pentity": null,
                                      "fkey": "N",
                                      "name": "price",
                                      "pkey": "N",
                                      "type": "DECIMAL"
                                    }
                                  },
                                  "subtype": "span",
                                  "id": "htmlTag10_1665143588811",
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "isCurrentlySelected": true,
                                  "handle": true,
                                  "label": "627",
                                  "studioDevClasses": "d-inline-block",
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "takeNodeBinding": "optFromService",
                                  "sno": 15,
                                  "name": "price",
                                  "subDataArray": [
                                    
                                  ],
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "627",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "RupeeSymbol",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      "font-size": "34px"
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType",
                                    "databaseName",
                                    "tableName",
                                    "columnName",
                                    "onExcessLoad",
                                    "master"
                                  ]
                                },
                                {
                                  "sag_G_Index": 15,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag_1666091358553",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag_1666091358553",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": true,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "label": "₹",
                                  "type": "htmlTag",
                                  "studioDevClasses": "d-inline-block",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "del",
                                  "sno": 16,
                                  "name": "htmlTag_1666091358553",
                                  "id": "htmlTag_1666091358553",
                                  "subDataArray": [
                                    
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "₹",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "Rupeesymbol",
                                    "defaultElementCls": "me-2",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "sag_G_Index": 16,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag12_1665143588811",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag12_1665143588811",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "description": "htmlTag Here",
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "bindedFromService_label": "{{_item.mrp}}",
                                  "type": "htmlTag",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "codedb",
                                    "dbMappingState": "invalid",
                                    "tableName": "product_card",
                                    "columnName": "maxRetailprice",
                                    "dbMappingMsg": "Type : DECIMAL\\n     Size : 10,2\\n     PrimaryKey :No\\n     ForeignKey :No\\n     ParentEntity: null \\n    ",
                                    "master": false,
                                    "columnInfo": {
                                      "entitylabel": "maxRetailprice",
                                      "size": "10,2",
                                      "pentity": null,
                                      "fkey": "N",
                                      "name": "max_retail_price",
                                      "pkey": "N",
                                      "type": "DECIMAL"
                                    }
                                  },
                                  "subtype": "del",
                                  "id": "htmlTag12_1665143588811",
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "isCurrentlySelected": true,
                                  "handle": true,
                                  "label": "675",
                                  "studioDevClasses": "d-inline-block",
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "takeNodeBinding": "optFromService",
                                  "sno": 17,
                                  "name": "mrp",
                                  "subDataArray": [
                                    
                                  ],
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "675",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "mrp",
                                    "defaultElementCls": "me-2",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType",
                                    "databaseName",
                                    "tableName",
                                    "columnName",
                                    "onExcessLoad",
                                    "master"
                                  ]
                                },
                                {
                                  "sag_G_Index": 17,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag13_1665143588811",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag13_1665143588811",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "description": "htmlTag Here",
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "bindedFromService_label": "{{_item.deal}}",
                                  "type": "htmlTag",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "codedb",
                                    "dbMappingState": "invalid",
                                    "tableName": "product_card",
                                    "columnName": "deal",
                                    "dbMappingMsg": "Type : VARCHAR\\n     Size : 100\\n     PrimaryKey :No\\n     ForeignKey :No\\n     ParentEntity: null \\n    ",
                                    "master": false,
                                    "columnInfo": {
                                      "entitylabel": "deal",
                                      "size": "100",
                                      "pentity": null,
                                      "fkey": "N",
                                      "name": "deal",
                                      "pkey": "N",
                                      "type": "VARCHAR"
                                    }
                                  },
                                  "subtype": "span",
                                  "id": "htmlTag13_1665143588811",
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "isCurrentlySelected": true,
                                  "handle": true,
                                  "label": "(7% off)",
                                  "studioDevClasses": "d-inline-block",
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "sno": 18,
                                  "name": "deal",
                                  "subDataArray": [
                                    
                                  ],
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "(7% off)",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "deal",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType",
                                    "databaseName",
                                    "tableName",
                                    "columnName",
                                    "onExcessLoad",
                                    "master"
                                  ]
                                }
                              ],
                              "events": {
                                "selectedEventList": [
                                  
                                ],
                                "eventData": [
                                  
                                ]
                              },
                              "properties": {
                                "visibility": true,
                                "hoverClasses": "",
                                "selectedElementClassArray": [
                                  
                                ],
                                "animationCss": "",
                                "globelAttrLogic": "",
                                "textContent": "",
                                "label": "",
                                "required": false,
                                "additionElementClass": "",
                                "name": "htmlTag_1665143588756",
                                "defaultElementCls": "",
                                "elementInnerStyles": {
                                  
                                },
                                "controlBindingType": "static",
                                "elementClass": "",
                                "starSymbol": false,
                                "selectedAnimationArray": [
                                  
                                ]
                              },
                              "windowProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ]
                            },
                            {
                              "attributeLogiclayer": [
                                {
                                  "name": "Globel AttrLogic",
                                  "selAttrs": [
                                    
                                  ],
                                  "label": "globelAttrLogic",
                                  "id": null,
                                  "type": "globelAttrLogics",
                                  "value": "globelLogic",
                                  "attrList": [
                                    
                                  ]
                                },
                                {
                                  "name": "Element AttrLogic",
                                  "selAttrs": [
                                    "label",
                                    "tooltip"
                                  ],
                                  "label": "elemAttrLogic",
                                  "id": null,
                                  "type": "elemAttrLogics",
                                  "value": "elemAttrLogic",
                                  "attrList": [
                                    {
                                      "optValue": "",
                                      "name": "label",
                                      "label": "label",
                                      "id": null,
                                      "type": "label",
                                      "value": "label",
                                      "subDataArray": [
                                        
                                      ]
                                    },
                                    {
                                      "optValue": "",
                                      "name": "tooltip",
                                      "label": "tooltip",
                                      "id": null,
                                      "type": "tooltip",
                                      "value": "tooltip",
                                      "subDataArray": [
                                        
                                      ]
                                    }
                                  ]
                                }
                              ],
                              "icon": "fa-columns",
                              "isCurrentlySelected": false,
                              "description": "htmlTag Here",
                              "handle": true,
                              "parseCtrl": {
                                "subData": false,
                                "layerCount": "1",
                                "layerTopId": "htmlTag~div#Element",
                                "layerCtrls": [
                                  "htmlTag~div#Element"
                                ]
                              },
                              "type": "htmlTag",
                              "studioDevClasses": "",
                              "projectConfigProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ],
                              "parentId": "htmlTag_1665142799144",
                              "angular": {
                                "tooltipTitle": "",
                                "formType": "none",
                                "validationMsg": "",
                                "toolTipPosition": "top",
                                "formGroupName": "",
                                "toolTipEvent": "mouseenter",
                                "validators": [
                                  
                                ],
                                "toolTip": "i am Toop Tip",
                                "selectedValidatorsForControls": [
                                  
                                ],
                                "appliedEvents": [
                                  
                                ],
                                "toolTipShow": false
                              },
                              "errorText": "Please select a valid Div",
                              "applicableAttributeLogic": [
                                "globelLogic",
                                "elemAttrLogic"
                              ],
                              "database": {
                                "onExcessLoad": false,
                                "databaseName": "",
                                "dbMappingState": "none",
                                "columnInfo": {
                                  
                                },
                                "tableName": "",
                                "columnName": "",
                                "dbMappingMsg": "",
                                "master": false
                              },
                              "subtype": "p",
                              "id": "htmlTag_1665143650252",
                              "subDataArray": [
                                {
                                  "sag_G_Index": 18,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag10_1665143650252",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag10_1665143650252",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": false,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "label": "Get it by",
                                  "type": "htmlTag",
                                  "studioDevClasses": "d-inline-block",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "span",
                                  "sno": 19,
                                  "name": "htmlTag10_1665143650252",
                                  "id": "htmlTag10_1665143650252",
                                  "subDataArray": [
                                    
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "Get it by",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "getItbyLabel",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "sag_G_Index": 19,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag11_1665143650252",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag11_1665143650252",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "description": "htmlTag Here",
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "bindedFromService_label": "{{_item.deliverydate}}",
                                  "type": "htmlTag",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "codedb",
                                    "dbMappingState": "invalid",
                                    "tableName": "product_card",
                                    "columnName": "deliveryDate",
                                    "dbMappingMsg": "Type : VARCHAR\\n     Size : 50\\n     PrimaryKey :No\\n     ForeignKey :No\\n     ParentEntity: null \\n    ",
                                    "master": false,
                                    "columnInfo": {
                                      "entitylabel": "deliveryDate",
                                      "size": "50",
                                      "pentity": null,
                                      "fkey": "N",
                                      "name": "delivery_date",
                                      "pkey": "N",
                                      "type": "VARCHAR"
                                    }
                                  },
                                  "subtype": "span",
                                  "id": "htmlTag11_1665143650252",
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "isCurrentlySelected": true,
                                  "handle": true,
                                  "label": "Sunday, September 30",
                                  "studioDevClasses": "d-inline-block",
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "takeNodeBinding": "optFromService",
                                  "sno": 20,
                                  "name": "deliverydate",
                                  "subDataArray": [
                                    
                                  ],
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "Sunday, September 30",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "deliverydate",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      "font-weight": "700"
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType",
                                    "databaseName",
                                    "tableName",
                                    "columnName",
                                    "onExcessLoad",
                                    "master"
                                  ]
                                }
                              ],
                              "events": {
                                "selectedEventList": [
                                  
                                ],
                                "eventData": [
                                  
                                ]
                              },
                              "properties": {
                                "visibility": true,
                                "hoverClasses": "",
                                "selectedElementClassArray": [
                                  
                                ],
                                "animationCss": "",
                                "globelAttrLogic": "",
                                "textContent": "",
                                "label": "",
                                "required": false,
                                "additionElementClass": "",
                                "name": "htmlTag_1665143650252",
                                "defaultElementCls": "",
                                "elementInnerStyles": {
                                  
                                },
                                "controlBindingType": "static",
                                "elementClass": "",
                                "starSymbol": false,
                                "selectedAnimationArray": [
                                  
                                ]
                              },
                              "windowProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ]
                            },
                            {
                              "attributeLogiclayer": [
                                {
                                  "name": "Globel AttrLogic",
                                  "selAttrs": [
                                    
                                  ],
                                  "label": "globelAttrLogic",
                                  "id": null,
                                  "type": "globelAttrLogics",
                                  "value": "globelLogic",
                                  "attrList": [
                                    
                                  ]
                                },
                                {
                                  "name": "Element AttrLogic",
                                  "selAttrs": [
                                    "label",
                                    "tooltip"
                                  ],
                                  "label": "elemAttrLogic",
                                  "id": null,
                                  "type": "elemAttrLogics",
                                  "value": "elemAttrLogic",
                                  "attrList": [
                                    {
                                      "optValue": "",
                                      "name": "label",
                                      "label": "label",
                                      "id": null,
                                      "type": "label",
                                      "value": "label",
                                      "subDataArray": [
                                        
                                      ]
                                    },
                                    {
                                      "optValue": "",
                                      "name": "tooltip",
                                      "label": "tooltip",
                                      "id": null,
                                      "type": "tooltip",
                                      "value": "tooltip",
                                      "subDataArray": [
                                        
                                      ]
                                    }
                                  ]
                                }
                              ],
                              "icon": "fa-columns",
                              "isCurrentlySelected": true,
                              "description": "htmlTag Here",
                              "handle": true,
                              "parseCtrl": {
                                "subData": false,
                                "layerCount": "1",
                                "layerTopId": "htmlTag~div#Element",
                                "layerCtrls": [
                                  "htmlTag~div#Element"
                                ]
                              },
                              "type": "htmlTag",
                              "studioDevClasses": "",
                              "projectConfigProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ],
                              "parentId": "htmlTag_1665142799144",
                              "angular": {
                                "tooltipTitle": "",
                                "formType": "none",
                                "validationMsg": "",
                                "toolTipPosition": "top",
                                "formGroupName": "",
                                "toolTipEvent": "mouseenter",
                                "validators": [
                                  
                                ],
                                "toolTip": "i am Toop Tip",
                                "selectedValidatorsForControls": [
                                  
                                ],
                                "appliedEvents": [
                                  
                                ],
                                "toolTipShow": false
                              },
                              "errorText": "Please select a valid Div",
                              "applicableAttributeLogic": [
                                "globelLogic",
                                "elemAttrLogic"
                              ],
                              "database": {
                                "onExcessLoad": false,
                                "databaseName": "",
                                "dbMappingState": "none",
                                "columnInfo": {
                                  
                                },
                                "tableName": "",
                                "columnName": "",
                                "dbMappingMsg": "",
                                "master": false
                              },
                              "subtype": "p",
                              "id": "htmlTag_1665143688094",
                              "subDataArray": [
                                {
                                  "sag_G_Index": 20,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag10_1665143688094",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag10_1665143688094",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": true,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "label": "More Buying Choices",
                                  "type": "htmlTag",
                                  "studioDevClasses": "d-inline-block",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "span",
                                  "sno": 21,
                                  "name": "htmlTag10_1665143688094",
                                  "id": "htmlTag10_1665143688094",
                                  "subDataArray": [
                                    
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "More Buying Choices",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "morebuyingchoices",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      "color": "#737373"
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                }
                              ],
                              "events": {
                                "selectedEventList": [
                                  
                                ],
                                "eventData": [
                                  
                                ]
                              },
                              "properties": {
                                "visibility": true,
                                "hoverClasses": "",
                                "selectedElementClassArray": [
                                  
                                ],
                                "animationCss": "",
                                "globelAttrLogic": "",
                                "textContent": "",
                                "label": "",
                                "required": false,
                                "additionElementClass": "",
                                "name": "htmlTag_1665143688094",
                                "defaultElementCls": "",
                                "elementInnerStyles": {
                                  
                                },
                                "controlBindingType": "static",
                                "elementClass": "",
                                "starSymbol": false,
                                "selectedAnimationArray": [
                                  
                                ]
                              },
                              "windowProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ]
                            },
                            {
                              "attributeLogiclayer": [
                                {
                                  "name": "Globel AttrLogic",
                                  "selAttrs": [
                                    
                                  ],
                                  "label": "globelAttrLogic",
                                  "id": null,
                                  "type": "globelAttrLogics",
                                  "value": "globelLogic",
                                  "attrList": [
                                    
                                  ]
                                },
                                {
                                  "name": "Element AttrLogic",
                                  "selAttrs": [
                                    "label",
                                    "tooltip"
                                  ],
                                  "label": "elemAttrLogic",
                                  "id": null,
                                  "type": "elemAttrLogics",
                                  "value": "elemAttrLogic",
                                  "attrList": [
                                    {
                                      "optValue": "",
                                      "name": "label",
                                      "label": "label",
                                      "id": null,
                                      "type": "label",
                                      "value": "label",
                                      "subDataArray": [
                                        
                                      ]
                                    },
                                    {
                                      "optValue": "",
                                      "name": "tooltip",
                                      "label": "tooltip",
                                      "id": null,
                                      "type": "tooltip",
                                      "value": "tooltip",
                                      "subDataArray": [
                                        
                                      ]
                                    }
                                  ]
                                }
                              ],
                              "icon": "fa-columns",
                              "isCurrentlySelected": true,
                              "description": "htmlTag Here",
                              "handle": true,
                              "parseCtrl": {
                                "subData": false,
                                "layerCount": "1",
                                "layerTopId": "htmlTag~div#Element",
                                "layerCtrls": [
                                  "htmlTag~div#Element"
                                ]
                              },
                              "type": "htmlTag",
                              "studioDevClasses": "",
                              "projectConfigProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ],
                              "parentId": "htmlTag_1665142799144",
                              "angular": {
                                "tooltipTitle": "",
                                "formType": "none",
                                "validationMsg": "",
                                "toolTipPosition": "top",
                                "formGroupName": "",
                                "toolTipEvent": "mouseenter",
                                "validators": [
                                  
                                ],
                                "toolTip": "i am Toop Tip",
                                "selectedValidatorsForControls": [
                                  
                                ],
                                "appliedEvents": [
                                  
                                ],
                                "toolTipShow": false
                              },
                              "errorText": "Please select a valid Div",
                              "applicableAttributeLogic": [
                                "globelLogic",
                                "elemAttrLogic"
                              ],
                              "database": {
                                "onExcessLoad": false,
                                "databaseName": "",
                                "dbMappingState": "none",
                                "columnInfo": {
                                  
                                },
                                "tableName": "",
                                "columnName": "",
                                "dbMappingMsg": "",
                                "master": false
                              },
                              "subtype": "p",
                              "id": "htmlTag_1665143436913",
                              "subDataArray": [
                                {
                                  "sag_G_Index": 21,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag_1666091569763",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag_1666091569763",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "description": "htmlTag Here",
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "bindedFromService_label": "{{_item.perqtyprice}}",
                                  "type": "htmlTag",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "codedb",
                                    "dbMappingState": "invalid",
                                    "tableName": "product_card",
                                    "columnName": "perQtyprice",
                                    "dbMappingMsg": "Type : DECIMAL\\n     Size : 10,2\\n     PrimaryKey :No\\n     ForeignKey :No\\n     ParentEntity: null \\n    ",
                                    "master": false,
                                    "columnInfo": {
                                      "entitylabel": "perQtyprice",
                                      "size": "10,2",
                                      "pentity": null,
                                      "fkey": "N",
                                      "name": "per_qty_price",
                                      "pkey": "N",
                                      "type": "DECIMAL"
                                    }
                                  },
                                  "subtype": "span",
                                  "id": "htmlTag_1666091569763",
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "isCurrentlySelected": false,
                                  "handle": true,
                                  "label": "1000",
                                  "studioDevClasses": "d-inline-block",
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "takeNodeBinding": "optFromService",
                                  "sno": 22,
                                  "name": "perqtyprice",
                                  "subDataArray": [
                                    
                                  ],
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "1000",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "perqtyprice",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType",
                                    "databaseName",
                                    "tableName",
                                    "columnName",
                                    "onExcessLoad",
                                    "master"
                                  ]
                                },
                                {
                                  "sag_G_Index": 22,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "[hidden]"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "!apiData?.htmlTag_1665143704373",
                                          "name": "[hidden]",
                                          "label": "[hidden]",
                                          "id": null,
                                          "type": "[hidden]",
                                          "finalValue": "!apiData?.htmlTag_1665143704373",
                                          "value": "[hidden]",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": false,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "label": "Rs/Qty",
                                  "type": "htmlTag",
                                  "studioDevClasses": "d-inline-block",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "span",
                                  "sno": 23,
                                  "name": "htmlTag_1665143704373",
                                  "id": "htmlTag_1665143704373",
                                  "subDataArray": [
                                    
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": 0,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "Rs/Qty",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "rsperqty",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                },
                                {
                                  "sag_G_Index": 23,
                                  "attributeLogiclayer": [
                                    {
                                      "name": "Globel AttrLogic",
                                      "selAttrs": [
                                        
                                      ],
                                      "label": "globelAttrLogic",
                                      "id": null,
                                      "type": "globelAttrLogics",
                                      "value": "globelLogic",
                                      "attrList": [
                                        
                                      ]
                                    },
                                    {
                                      "name": "Element AttrLogic",
                                      "selAttrs": [
                                        "label",
                                        "tooltip"
                                      ],
                                      "label": "elemAttrLogic",
                                      "id": null,
                                      "type": "elemAttrLogics",
                                      "value": "elemAttrLogic",
                                      "attrList": [
                                        {
                                          "optValue": "",
                                          "name": "label",
                                          "label": "label",
                                          "id": null,
                                          "type": "label",
                                          "value": "label",
                                          "subDataArray": [
                                            
                                          ]
                                        },
                                        {
                                          "optValue": "",
                                          "name": "tooltip",
                                          "label": "tooltip",
                                          "id": null,
                                          "type": "tooltip",
                                          "value": "tooltip",
                                          "subDataArray": [
                                            
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  "icon": "fa-columns",
                                  "isCurrentlySelected": false,
                                  "description": "htmlTag Here",
                                  "handle": true,
                                  "parseCtrl": {
                                    "subData": false,
                                    "layerCount": "1",
                                    "layerTopId": "htmlTag~div#Element",
                                    "layerCtrls": [
                                      "htmlTag~div#Element"
                                    ]
                                  },
                                  "label": "",
                                  "type": "htmlTag",
                                  "studioDevClasses": "d-inline-block",
                                  "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ],
                                  "parentId": "htmlTag_1665143436913",
                                  "angular": {
                                    "tooltipTitle": "",
                                    "formType": "none",
                                    "validationMsg": "",
                                    "toolTipPosition": "top",
                                    "formGroupName": "",
                                    "toolTipEvent": "mouseenter",
                                    "validators": [
                                      
                                    ],
                                    "toolTip": "i am Toop Tip",
                                    "selectedValidatorsForControls": [
                                      
                                    ],
                                    "appliedEvents": [
                                      
                                    ],
                                    "toolTipShow": false
                                  },
                                  "errorText": "Please select a valid Div",
                                  "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                  ],
                                  "database": {
                                    "onExcessLoad": false,
                                    "databaseName": "",
                                    "dbMappingState": "none",
                                    "columnInfo": {
                                      
                                    },
                                    "tableName": "",
                                    "columnName": "",
                                    "dbMappingMsg": "",
                                    "master": false
                                  },
                                  "subtype": "span",
                                  "sno": 24,
                                  "name": "htmlTag_1665143462650",
                                  "id": "htmlTag_1665143462650",
                                  "subDataArray": [
                                    {
                                      "sag_G_Index": 24,
                                      "attributeLogiclayer": [
                                        {
                                          "name": "Globel AttrLogic",
                                          "selAttrs": [
                                            
                                          ],
                                          "label": "globelAttrLogic",
                                          "id": null,
                                          "type": "globelAttrLogics",
                                          "value": "globelLogic",
                                          "attrList": [
                                            
                                          ]
                                        },
                                        {
                                          "name": "Element AttrLogic",
                                          "selAttrs": [
                                            "[hidden]"
                                          ],
                                          "label": "elemAttrLogic",
                                          "id": null,
                                          "type": "elemAttrLogics",
                                          "value": "elemAttrLogic",
                                          "attrList": [
                                            {
                                              "optValue": "!apiData?.anchor_1665143720344",
                                              "name": "[hidden]",
                                              "label": "[hidden]",
                                              "id": null,
                                              "type": "[hidden]",
                                              "finalValue": "!apiData?.anchor_1665143720344",
                                              "value": "[hidden]",
                                              "subDataArray": [
                                                
                                              ]
                                            }
                                          ]
                                        }
                                      ],
                                      "icon": "fa fa-bookmark",
                                      "isCurrentlySelected": true,
                                      "description": "anchor Description",
                                      "handle": true,
                                      "label": "(5 new offers)",
                                      "type": "anchor",
                                      "studioDevClasses": "d-inline-block",
                                      "projectConfigProperties": [
                                        "name",
                                        "label",
                                        "disable",
                                        "visibility",
                                        "href",
                                        "iconClass",
                                        "hoverClasses",
                                        "target",
                                        "anchorType",
                                        "iconSize",
                                        "combineAllModel",
                                        "expandCollapseForCtrl",
                                        "globelAttrLogic",
                                        "controlBindingType"
                                      ],
                                      "parentId": "htmlTag_1665143462650",
                                      "angular": {
                                        "tooltipTitle": "",
                                        "formType": "none",
                                        "validationMsg": "",
                                        "toolTipPosition": "top",
                                        "formGroupName": "",
                                        "toolTipEvent": "mouseenter",
                                        "validators": [
                                          
                                        ],
                                        "selectedValidatorsForControls": [
                                          
                                        ],
                                        "toolTipShow": false
                                      },
                                      "errorText": "Please enter a valid Value",
                                      "applicableAttributeLogic": [
                                        "globelLogic",
                                        "elemAttrLogic"
                                      ],
                                      "database": {
                                        "onExcessLoad": false,
                                        "databaseName": "",
                                        "dbMappingState": "none",
                                        "tableName": "",
                                        "columnName": "",
                                        "dbMappingMsg": "",
                                        "master": false
                                      },
                                      "subtype": "anchor",
                                      "sno": 25,
                                      "name": "anchor_1665143720343",
                                      "id": "anchor_1665143720344",
                                      "subDataArray": [
                                        
                                      ],
                                      "events": {
                                        "selectedEventList": [
                                          
                                        ],
                                        "eventData": [
                                          
                                        ]
                                      },
                                      "properties": {
                                        "visibility": 0,
                                        "hoverClasses": "",
                                        "selectedElementClassArray": [
                                          
                                        ],
                                        "globelAttrLogic": "",
                                        "label": "(5 new offers)",
                                        "iconClass": "",
                                        "target": "_self",
                                        "additionElementClass": "",
                                        "disable": false,
                                        "name": "offeranchor",
                                        "defaultElementCls": "",
                                        "elementInnerStyles": {
                                          "color": "#4ba6fb"
                                        },
                                        "controlBindingType": "static",
                                        "iconSize": "20",
                                        "href": "JavaScript:Void(0)",
                                        "elementClass": "",
                                        "anchorType": "text/html"
                                      },
                                      "windowProperties": [
                                        "name",
                                        "label",
                                        "disable",
                                        "visibility",
                                        "href",
                                        "iconClass",
                                        "hoverClasses",
                                        "target",
                                        "anchorType",
                                        "iconSize",
                                        "combineAllModel",
                                        "expandCollapseForCtrl",
                                        "globelAttrLogic",
                                        "controlBindingType"
                                      ]
                                    }
                                  ],
                                  "events": {
                                    "selectedEventList": [
                                      
                                    ],
                                    "eventData": [
                                      
                                    ]
                                  },
                                  "properties": {
                                    "visibility": true,
                                    "hoverClasses": "",
                                    "selectedElementClassArray": [
                                      
                                    ],
                                    "animationCss": "",
                                    "globelAttrLogic": "",
                                    "textContent": "",
                                    "label": "",
                                    "required": false,
                                    "additionElementClass": "",
                                    "name": "htmlTag_1665143462650",
                                    "defaultElementCls": "",
                                    "elementInnerStyles": {
                                      
                                    },
                                    "controlBindingType": "static",
                                    "elementClass": "",
                                    "starSymbol": false,
                                    "selectedAnimationArray": [
                                      
                                    ]
                                  },
                                  "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "textContent",
                                    "animationCss",
                                    "hoverClasses",
                                    "attributeLogiclayer",
                                    "formType",
                                    "formGroupName",
                                    "expandCollapseForCtrl",
                                    "selectedEventList",
                                    "combineAllModel",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                  ]
                                }
                              ],
                              "events": {
                                "selectedEventList": [
                                  
                                ],
                                "eventData": [
                                  
                                ]
                              },
                              "properties": {
                                "visibility": true,
                                "hoverClasses": "",
                                "selectedElementClassArray": [
                                  
                                ],
                                "animationCss": "",
                                "globelAttrLogic": "",
                                "textContent": "",
                                "label": "",
                                "required": false,
                                "additionElementClass": "",
                                "name": "htmlTag_1665143436913",
                                "defaultElementCls": "",
                                "elementInnerStyles": {
                                  
                                },
                                "controlBindingType": "static",
                                "elementClass": "",
                                "starSymbol": false,
                                "selectedAnimationArray": [
                                  
                                ]
                              },
                              "windowProperties": [
                                "name",
                                "label",
                                "visibility",
                                "textContent",
                                "animationCss",
                                "hoverClasses",
                                "attributeLogiclayer",
                                "formType",
                                "formGroupName",
                                "expandCollapseForCtrl",
                                "selectedEventList",
                                "combineAllModel",
                                "globelAttrLogic",
                                "controlBindingType"
                              ]
                            }
                          ],
                          "events": {
                            "selectedEventList": [
                              
                            ],
                            "eventData": [
                              
                            ]
                          },
                          "properties": {
                            "visibility": true,
                            "hoverClasses": "",
                            "selectedElementClassArray": [
                              
                            ],
                            "animationCss": "",
                            "globelAttrLogic": "",
                            "textContent": "",
                            "label": "",
                            "required": false,
                            "additionElementClass": "",
                            "name": "htmlTag_1665142799144",
                            "defaultElementCls": "px-3 py-3",
                            "elementInnerStyles": {
                              
                            },
                            "controlBindingType": "static",
                            "elementClass": "",
                            "starSymbol": false,
                            "selectedAnimationArray": [
                              
                            ]
                          },
                          "windowProperties": [
                            "name",
                            "label",
                            "visibility",
                            "textContent",
                            "animationCss",
                            "hoverClasses",
                            "attributeLogiclayer",
                            "formType",
                            "formGroupName",
                            "expandCollapseForCtrl",
                            "selectedEventList",
                            "combineAllModel",
                            "globelAttrLogic",
                            "controlBindingType"
                          ]
                        }
                      ],
                      "events": {
                        "selectedEventList": [
                          
                        ],
                        "eventData": [
                          
                        ]
                      },
                      "properties": {
                        "visibility": true,
                        "hoverClasses": "",
                        "selectedElementClassArray": [
                          
                        ],
                        "animationCss": "",
                        "globelAttrLogic": "",
                        "textContent": "",
                        "label": "",
                        "required": false,
                        "additionElementClass": "",
                        "name": "htmlTag_1666091085215",
                        "defaultElementCls": "bg-light   shadow p-4  d-flex flex-column justify-content-center align-items-center",
                        "elementInnerStyles": {
                          
                        },
                        "controlBindingType": "static",
                        "elementClass": "",
                        "starSymbol": false,
                        "selectedAnimationArray": [
                          
                        ]
                      },
                      "windowProperties": [
                        "name",
                        "label",
                        "visibility",
                        "textContent",
                        "animationCss",
                        "hoverClasses",
                        "attributeLogiclayer",
                        "formType",
                        "formGroupName",
                        "expandCollapseForCtrl",
                        "selectedEventList",
                        "combineAllModel",
                        "globelAttrLogic",
                        "controlBindingType"
                      ]
                    }
                  ],
                  "properties": {
                    "labelClass": "",
                    "selectedElementClassArray": [
                      
                    ],
                    "typeSlider": "static",
                    "defaultLabelPrntCls": "item",
                    "globelAttrLogic": "",
                    "selectedTagClassArray": [
                      
                    ],
                    "title": "owl carousel loop on",
                    "required": false,
                    "additionElementClass": "",
                    "additionLabelClass": "",
                    "defaultElementCls": "xzoom-gallery",
                    "controlBindingType": "dynamic",
                    "elementClass": "",
                    "height": "100",
                    "star_Symbol": false,
                    "visibility": true,
                    "src": "https://picsum.photos/id/239/300/300",
                    "labelPrntClass": "",
                    "defaultLabelCls": "d-block w-100",
                    "additionLabelPrntClass": "",
                    "label": "owlCarousel",
                    "sections": "1",
                    "errorText": "Please select a valid Div",
                    "disable": false,
                    "name": "lightBox",
                    "width": "100",
                    "elementInnerStyles": {
                      
                    },
                    "selectedParentClassArray": [
                      
                    ],
                    "labelInnerStyles": {
                      
                    }
                  },
                  "windowProperties": [
                    "changeType",
                    "name",
                    "label",
                    "title",
                    "src",
                    "description",
                    "width",
                    "height",
                    "visibility",
                    "imgBlob",
                    "typeSlider",
                    "sections",
                    "globelAttrLogic",
                    "controlBindingType"
                  ]
                },
                {
                  "sag_G_Index": 25,
                  "attributeLogiclayer": [
                    {
                      "name": "Globel AttrLogic",
                      "selAttrs": [
                        
                      ],
                      "label": "globelAttrLogic",
                      "id": null,
                      "type": "globelAttrLogics",
                      "value": "globelLogic",
                      "attrList": [
                        
                      ]
                    },
                    {
                      "name": "Element AttrLogic",
                      "selAttrs": [
                        
                      ],
                      "label": "elemAttrLogic",
                      "id": null,
                      "type": "elemAttrLogics",
                      "value": "elemAttrLogic",
                      "attrList": [
                        
                      ]
                    }
                  ],
                  "icon": "fas fa-bandcamp",
                  "isCurrentlySelected": true,
                  "description": "owl carousel loop on",
                  "handle": true,
                  "parseCtrl": {
                    "subData": false,
                    "layerCount": "2",
                    "layerTopId": "owlCarouselItem~owlCarouselItem#Globel",
                    "layerCtrls": [
                      "owlCarouselItem~owlCarouselItem#Globel",
                      "owlCarouselItem~owlCarouselItem#Element"
                    ]
                  },
                  "label": "owlCarousel",
                  "type": "owlCarouselItem",
                  "studioDevClasses": "d-block",
                  "projectConfigProperties": [
                    "changeType",
                    "name",
                    "label",
                    "title",
                    "src",
                    "description",
                    "width",
                    "height",
                    "visibility",
                    "imgBlob",
                    "typeSlider",
                    "sections",
                    "globelAttrLogic",
                    "controlBindingType"
                  ],
                  "parentId": null,
                  "angular": {
                    "tooltipTitle": "",
                    "formType": "none",
                    "validationMsg": "",
                    "toolTipPosition": "top",
                    "formGroupName": "",
                    "toolTipEvent": "mouseenter",
                    "validators": [
                      
                    ],
                    "toolTip": "i am Toop Tip",
                    "selectedValidatorsForControls": [
                      
                    ],
                    "toolTipShow": false
                  },
                  "applicableAttributeLogic": [
                    "globelLogic",
                    "elemAttrLogic"
                  ],
                  "database": {
                    "onExcessLoad": false,
                    "databaseName": "",
                    "dbMappingState": "none",
                    "columnInfo": {
                      
                    },
                    "tableName": "",
                    "columnName": "",
                    "dbMappingMsg": "",
                    "master": false
                  },
                  "subtype": "owlCarouselItem",
                  "children": [
                    
                  ],
                  "sno": 26,
                  "name": "lightBox",
                  "id": null,
                  "subDataArray": [
                    
                  ],
                  "events": {
                    "selectedEventList": [
                      
                    ],
                    "eventData": [
                      
                    ]
                  },
                  "properties": {
                    "labelClass": "",
                    "selectedElementClassArray": [
                      
                    ],
                    "typeSlider": "static",
                    "defaultLabelPrntCls": "item",
                    "globelAttrLogic": "",
                    "selectedTagClassArray": [
                      
                    ],
                    "title": "owl carousel loop on",
                    "required": false,
                    "additionElementClass": "",
                    "additionLabelClass": "",
                    "defaultElementCls": "xzoom-gallery",
                    "controlBindingType": "static",
                    "elementClass": "",
                    "height": "100",
                    "star_Symbol": false,
                    "visibility": true,
                    "src": "https://picsum.photos/id/239/300/300",
                    "labelPrntClass": "",
                    "defaultLabelCls": "d-block w-100",
                    "additionLabelPrntClass": "",
                    "label": "owlCarousel",
                    "sections": "1",
                    "errorText": "Please select a valid Div",
                    "disable": false,
                    "name": "lightBox",
                    "width": "100",
                    "elementInnerStyles": {
                      
                    },
                    "selectedParentClassArray": [
                      
                    ],
                    "labelInnerStyles": {
                      
                    }
                  },
                  "windowProperties": [
                    "changeType",
                    "name",
                    "label",
                    "title",
                    "src",
                    "description",
                    "width",
                    "height",
                    "visibility",
                    "imgBlob",
                    "typeSlider",
                    "sections",
                    "globelAttrLogic",
                    "controlBindingType"
                  ]
                },
                {
                  "sag_G_Index": 26,
                  "attributeLogiclayer": [
                    {
                      "name": "Globel AttrLogic",
                      "selAttrs": [
                        
                      ],
                      "label": "globelAttrLogic",
                      "id": null,
                      "type": "globelAttrLogics",
                      "value": "globelLogic",
                      "attrList": [
                        
                      ]
                    },
                    {
                      "name": "Element AttrLogic",
                      "selAttrs": [
                        
                      ],
                      "label": "elemAttrLogic",
                      "id": null,
                      "type": "elemAttrLogics",
                      "value": "elemAttrLogic",
                      "attrList": [
                        
                      ]
                    }
                  ],
                  "icon": "fas fa-bandcamp",
                  "isCurrentlySelected": false,
                  "description": "owl carousel loop on",
                  "handle": true,
                  "parseCtrl": {
                    "subData": false,
                    "layerCount": "2",
                    "layerTopId": "owlCarouselItem~owlCarouselItem#Globel",
                    "layerCtrls": [
                      "owlCarouselItem~owlCarouselItem#Globel",
                      "owlCarouselItem~owlCarouselItem#Element"
                    ]
                  },
                  "label": "owlCarousel",
                  "type": "owlCarouselItem",
                  "studioDevClasses": "d-block",
                  "projectConfigProperties": [
                    "changeType",
                    "name",
                    "label",
                    "title",
                    "src",
                    "description",
                    "width",
                    "height",
                    "visibility",
                    "imgBlob",
                    "typeSlider",
                    "sections",
                    "globelAttrLogic",
                    "controlBindingType"
                  ],
                  "parentId": null,
                  "angular": {
                    "tooltipTitle": "",
                    "formType": "none",
                    "validationMsg": "",
                    "toolTipPosition": "top",
                    "formGroupName": "",
                    "toolTipEvent": "mouseenter",
                    "validators": [
                      
                    ],
                    "toolTip": "i am Toop Tip",
                    "selectedValidatorsForControls": [
                      
                    ],
                    "toolTipShow": false
                  },
                  "applicableAttributeLogic": [
                    "globelLogic",
                    "elemAttrLogic"
                  ],
                  "database": {
                    "onExcessLoad": false,
                    "databaseName": "",
                    "dbMappingState": "none",
                    "columnInfo": {
                      
                    },
                    "tableName": "",
                    "columnName": "",
                    "dbMappingMsg": "",
                    "master": false
                  },
                  "subtype": "owlCarouselItem",
                  "children": [
                    
                  ],
                  "sno": 27,
                  "name": "lightBox",
                  "id": null,
                  "subDataArray": [
                    
                  ],
                  "events": {
                    "selectedEventList": [
                      
                    ],
                    "eventData": [
                      
                    ]
                  },
                  "properties": {
                    "labelClass": "",
                    "selectedElementClassArray": [
                      
                    ],
                    "typeSlider": "static",
                    "defaultLabelPrntCls": "item",
                    "globelAttrLogic": "",
                    "selectedTagClassArray": [
                      
                    ],
                    "title": "owl carousel loop on",
                    "required": false,
                    "additionElementClass": "",
                    "additionLabelClass": "",
                    "defaultElementCls": "xzoom-gallery",
                    "controlBindingType": "static",
                    "elementClass": "",
                    "height": "100",
                    "star_Symbol": false,
                    "visibility": true,
                    "src": "https://picsum.photos/id/239/300/300",
                    "labelPrntClass": "",
                    "defaultLabelCls": "d-block w-100",
                    "additionLabelPrntClass": "",
                    "label": "owlCarousel",
                    "sections": "1",
                    "errorText": "Please select a valid Div",
                    "disable": false,
                    "name": "lightBox",
                    "width": "100",
                    "elementInnerStyles": {
                      
                    },
                    "selectedParentClassArray": [
                      
                    ],
                    "labelInnerStyles": {
                      
                    }
                  },
                  "windowProperties": [
                    "changeType",
                    "name",
                    "label",
                    "title",
                    "src",
                    "description",
                    "width",
                    "height",
                    "visibility",
                    "imgBlob",
                    "typeSlider",
                    "sections",
                    "globelAttrLogic",
                    "controlBindingType"
                  ]
                },
                {
                  "sag_G_Index": 27,
                  "attributeLogiclayer": [
                    {
                      "name": "Globel AttrLogic",
                      "selAttrs": [
                        
                      ],
                      "label": "globelAttrLogic",
                      "id": null,
                      "type": "globelAttrLogics",
                      "value": "globelLogic",
                      "attrList": [
                        
                      ]
                    },
                    {
                      "name": "Element AttrLogic",
                      "selAttrs": [
                        
                      ],
                      "label": "elemAttrLogic",
                      "id": null,
                      "type": "elemAttrLogics",
                      "value": "elemAttrLogic",
                      "attrList": [
                        
                      ]
                    }
                  ],
                  "icon": "fas fa-bandcamp",
                  "isCurrentlySelected": false,
                  "description": "owl carousel loop on",
                  "handle": true,
                  "parseCtrl": {
                    "subData": false,
                    "layerCount": "2",
                    "layerTopId": "owlCarouselItem~owlCarouselItem#Globel",
                    "layerCtrls": [
                      "owlCarouselItem~owlCarouselItem#Globel",
                      "owlCarouselItem~owlCarouselItem#Element"
                    ]
                  },
                  "label": "owlCarousel",
                  "type": "owlCarouselItem",
                  "studioDevClasses": "d-block",
                  "projectConfigProperties": [
                    "changeType",
                    "name",
                    "label",
                    "title",
                    "src",
                    "description",
                    "width",
                    "height",
                    "visibility",
                    "imgBlob",
                    "typeSlider",
                    "sections",
                    "globelAttrLogic",
                    "controlBindingType"
                  ],
                  "parentId": null,
                  "angular": {
                    "tooltipTitle": "",
                    "formType": "none",
                    "validationMsg": "",
                    "toolTipPosition": "top",
                    "formGroupName": "",
                    "toolTipEvent": "mouseenter",
                    "validators": [
                      
                    ],
                    "toolTip": "i am Toop Tip",
                    "selectedValidatorsForControls": [
                      
                    ],
                    "toolTipShow": false
                  },
                  "applicableAttributeLogic": [
                    "globelLogic",
                    "elemAttrLogic"
                  ],
                  "database": {
                    "onExcessLoad": false,
                    "databaseName": "",
                    "dbMappingState": "none",
                    "columnInfo": {
                      
                    },
                    "tableName": "",
                    "columnName": "",
                    "dbMappingMsg": "",
                    "master": false
                  },
                  "subtype": "owlCarouselItem",
                  "children": [
                    
                  ],
                  "sno": 28,
                  "name": "lightBox",
                  "id": null,
                  "subDataArray": [
                    
                  ],
                  "events": {
                    "selectedEventList": [
                      
                    ],
                    "eventData": [
                      
                    ]
                  },
                  "properties": {
                    "labelClass": "",
                    "selectedElementClassArray": [
                      
                    ],
                    "typeSlider": "static",
                    "defaultLabelPrntCls": "item",
                    "globelAttrLogic": "",
                    "selectedTagClassArray": [
                      
                    ],
                    "title": "owl carousel loop on",
                    "required": false,
                    "additionElementClass": "",
                    "additionLabelClass": "",
                    "defaultElementCls": "xzoom-gallery",
                    "controlBindingType": "static",
                    "elementClass": "",
                    "height": "100",
                    "star_Symbol": false,
                    "visibility": true,
                    "src": "https://picsum.photos/id/239/300/300",
                    "labelPrntClass": "",
                    "defaultLabelCls": "d-block w-100",
                    "additionLabelPrntClass": "",
                    "label": "owlCarousel",
                    "sections": "1",
                    "errorText": "Please select a valid Div",
                    "disable": false,
                    "name": "lightBox",
                    "width": "100",
                    "elementInnerStyles": {
                      
                    },
                    "selectedParentClassArray": [
                      
                    ],
                    "labelInnerStyles": {
                      
                    }
                  },
                  "windowProperties": [
                    "changeType",
                    "name",
                    "label",
                    "title",
                    "src",
                    "description",
                    "width",
                    "height",
                    "visibility",
                    "imgBlob",
                    "typeSlider",
                    "sections",
                    "globelAttrLogic",
                    "controlBindingType"
                  ]
                }
              ],
              "id": "owlCarousel_1666090580157",
              "events": {
                "selectedEventList": [
                  
                ],
                "eventData": [
                  
                ]
              },
              "bindingType": "*ngIf",
              "isCurrentlySelected": false,
              "dynamicOptions": [
                {
                  "label": "1",
                  "value": "1"
                }
              ],
              "handle": true,
              "label": "owlCarousel",
              "studioDevClasses": "d-block",
              "parentId": null,
              "angular": {
                "tooltipTitle": "",
                "formType": "none",
                "validationMsg": "",
                "toolTipPosition": "top",
                "formGroupName": "",
                "toolTipEvent": "mouseenter",
                "validators": [
                  
                ],
                "toolTip": "i am Toop Tip",
                "selectedValidatorsForControls": [
                  
                ],
                "toolTipShow": false
              },
              "applicableAttributeLogic": [
                "globelLogic",
                "elemAttrLogic"
              ],
              "takeNodeBinding": "optFromService",
              "sno": 3,
              "name": "owlCarousel_1666090580157",
              "subDataArray": [
                
              ],
              "properties": {
                "selectedGlobalClassArray": [
                  
                ],
                "typeSlider": "static",
                "lazyLoadEager": 1,
                "totalSections": 4,
                "defaultGlobelCls": "owl-carousel owl-theme",
                "animateIn": "flipInX",
                "smartSpeed": 2000,
                "globelClasses": "",
                "loop": true,
                "owlNav": "owlCarouselSquare",
                "controlBindingType": "static",
                "owlDots": true,
                "currentSlide": "1",
                "animateOut": "slideOutDown",
                "additionGlobelClasses": "",
                "nav": true,
                "autoHeight": true,
                "visibility": true,
                "label": "owlCarousel",
                "sectionsPerSlide": 4,
                "autoplayHoverPause": true,
                "totalSlides": 1,
                "disable": false,
                "name": "owlCarousel_1666090580157",
                "stagePadding": 50,
                "tabletSection": 2,
                "slideMargin": "20",
                "mobileSection": 1,
                "globalInnerStyles": {
                  
                }
              },
              "windowProperties": [
                "changeType",
                "owlNav",
                "typeSlider",
                "totalSlides",
                "sectionsPerSlide",
                "totalSections",
                "currentSlide",
                "label",
                "name",
                "itemDataList",
                "visibility",
                "loop",
                "autoHeight",
                "slideMargin",
                "center",
                "navRewind",
                "URLhashListener",
                "autoplayHoverPause",
                "nav",
                "rtl",
                "owlDots",
                "responsiveClass",
                "merge",
                "lazyLoad",
                "autoWidth",
                "stagePadding",
                "lazyLoadEager",
                "smartSpeed",
                "animateOut",
                "animateIn",
                "tabletSection",
                "mobileSection",
                "globelAttrLogic",
                "controlBindingType"
              ]
            }
          ],
          "cssData": {},
          "tsData": {
            "diInConstructor": [
              {
                "diName": "Productcardslider"+ pageCount+"Service",
                "diType": "public",
                "diShortName": "productcardslider"+ pageCount,
                "diImportPath": `src/app/custommodules/productcardslider${pageCount}/productcardslider${pageCount}.share.service`
              }
            ],
            "varAndMethodList": [
              {
                name: `methodResponse1666091933366`,
                type: 'ClassProperty'
              }, 
              {
                name: `ngOnInit`,
                type: 'MethodDefinition'
              },
              {
                name: `loadImages`,
                type: 'MethodDefinition'
              }
  
            ],
            "writeTsCode": `\n 
           @Input() apiData;
            ngOnInit() {

              this.initializeForm();
              this.loadImages();
            };
            methodResponse1666091933366: any;
            loadImages() {
                this.productcardslider${pageCount}.getProductSliderData(this.apiData).subscribe(res => {
                this.methodResponse1666091933366 = res; 
              });
            }; 
            `,
          },
          "routingData": {},
          "moduleData": {}
        },
        "activeCompData": {
          "htmlData": {
            /***SELECTOR***/
            "selectorObj": {
              "type": "hiddenContainerOnStudio",
              "icon": "fa-columns",
              "description": "Ng Container",
              "subtype": "ng-container",
              "handle": true,
              "studioDevClasses": "d-block",
              "angular": {
      
              },
              "events": {
                "selectedEventList": [
      
                ],
                "eventData": [
      
                ]
              },
              "database": {
      
              },
              "properties": {
                "label": "Ng Container",
                "name": "",
                "visibility": true,
                "elementClass": "",
                "selectedElementClassArray": [
      
                ],
                "additionElementClass": "",
                "defaultElementCls": "d-flex flex-column full-modal pageContainer#Globel",
                "elementInnerStyles": {
      
                },
                "globelAttrLogic": "",
                "controlBindingType": "static"
              },
              "parseCtrl": {
                "subData": true,
                "layerTopId": "hiddenContainerOnStudio#Globel",
                "layerCount": "5",
                "layerCtrls": [
                  "hiddenContainerOnStudio#Globel"
                ]
              },
              "subDataArray": [
                {
                  "type": "customCode",
                  "icon": "fas fa-laptop-code",
                  "description": "Custom Code",
                  "subtype": "customCode",
                  "studioDevClasses": "d-block",
                  "angular": {
      
                  },
                  "events": {
                    "selectedEventList": [
      
                    ],
                    "eventData": [
      
                    ]
                  },
                  "database": {
                    "databaseName": "",
                    "tableName": "",
                    "columnName": "",
                    "columnInfo": {
      
                    },
                    "dbMappingState": "none",
                    "dbMappingMsg": "",
                    "onExcessLoad": false,
                    "master": false
                  },
                  "properties": {
                    "label": "Type your Custom Code here only",
                    "placeholder": null,
                    "name": "customCode_1655446732102",
                    "visibility": true
                  },
                  "parseCtrl": {
                    "subData": false,
                    "layerTopId": "customCode~customCode#Globel",
                    "layerCount": "2",
                    "layerCtrls": [
                      "customCode~customCode#Globel",
                      "customCode~customCode#Element"
                    ]
                  },
                  "subDataArray": [
      
                  ],
                  "id": "customCode_1655446732102",
                  "parentId": null,
                  "isCurrentlySelected": true,
                  "errorText": "Please enter a valid Value",
                  "customCodeBody": `<app-productcardslider${pageCount} ></app-productcardslider${pageCount}>`,
                  "projectConfigProperties": [
                    "name",
                    "label",
                    "visibility",
                    "selectedEventList",
                    "combineAllModel",
                    "databaseName",
                    "tableName",
                    "columnName",
                    "onExcessLoad",
                    "master"
                  ],
                  "windowProperties": [
                    "name",
                    "label",
                    "visibility",
                    "selectedEventList",
                    "combineAllModel",
                    "databaseName",
                    "tableName",
                    "columnName",
                    "onExcessLoad",
                    "master"
                  ],
                  "attributeLogiclayer": [
                    {
                      "label": "globelAttrLogic",
                      "name": "Globel AttrLogic",
                      "value": "globelLogic",
                      "type": "globelAttrLogics",
                      "id": null,
                      "selAttrs": [
      
                      ],
                      "attrList": [
      
                      ]
                    },
                    {
                      "label": "elemAttrLogic",
                      "name": "Element AttrLogic",
                      "value": "elemAttrLogic",
                      "type": "elemAttrLogics",
                      "id": null,
                      "selAttrs": [
                        "label",
                        "tooltip"
                      ],
                      "attrList": [
      
                      ]
                    }
                  ]
                }
              ],
              "id": null,
              "parentId": null,
              "isCurrentlySelected": false,
              "errorText": "Please select a valid Div",
              "projectConfigProperties": [
                "name",
                "label",
                "visibility",
                "expandCollapseForCtrl",
                "globelAttrLogic",
                "controlBindingType",
                "selectedEventList",
                "combineAllModel"
              ],
              "windowProperties": [
                "name",
                "label",
                "visibility",
                "expandCollapseForCtrl",
                "globelAttrLogic",
                "controlBindingType",
                "selectedEventList",
                "combineAllModel"
              ],
              "attributeLogiclayer": [
                {
                  "label": "globelAttrLogic",
                  "name": "Globel AttrLogic",
                  "value": "globelLogic",
                  "type": "globelAttrLogics",
                  "id": null,
                  "selAttrs": [
      
                  ],
                  "attrList": [
      
                  ]
                },
                {
                  "label": "elemAttrLogic",
                  "name": "Element AttrLogic",
                  "value": "elemAttrLogic",
                  "type": "elemAttrLogics",
                  "id": null,
                  "selAttrs": [
                    "label",
                    "tooltip"
                  ],
                  "attrList": [
      
                  ]
                }
              ],
              "applicableAttributeLogic": [
                "globelLogic",
                "elemAttrLogic"
              ]
            },
            /****SEND MAIL BUTTON****/
            "subDataObj": {
              "appSelectorName": `productcardslider${pageCount}`,
              "attributeLogiclayer": [
                {
                  "name": "Globel AttrLogic",
                  "selAttrs": [
                    
                  ],
                  "label": "globelAttrLogic",
                  "id": null,
                  "type": "globelAttrLogics",
                  "value": "globelLogic",
                  "attrList": [
                    
                  ]
                },
                {
                  "name": "Element AttrLogic",
                  "selAttrs": [
                    "label",
                    "tooltip",
                    "[apiData]"
                  ],
                  "label": "elemAttrLogic",
                  "id": null,
                  "type": "elemAttrLogics",
                  "value": "elemAttrLogic",
                  "attrList": [
                    {
                      "label": "[cardcode]",
                      "value": "[cardcode]",
                      "name": "[cardcode]",
                      "type": "[cardcode]",
                      "id": null,
                      "finalValue": "{cardcode : 'fe3a74e4-f340-457d-943a-331d747e50f3'}",
                      "subDataArray": [
                        
                      ],
                      "optValue": ""
                    }
                  ] 
                }
              ],
              "icon": "fas fa-clipboard-check",
              "isCurrentlySelected": true,
              "description": "Row Here",
              "handle": true,
              "parseCtrl": {
                "subData": false,
                "layerCount": "2",
                "layerTopId": "paragraph~paragraph#Globel",
                "layerCtrls": [
                  "paragraph~paragraph#Globel",
                  "paragraph~paragraph#Element"
                ]
              },
              "type": "angular_selector",
              "studioDevClasses": "d-block",
              "projectConfigProperties": [
                "name",
                "label",
                "visibility",
                "addExitsComponent",
                "expandCollapseForCtrl",
                "globelAttrLogic",
                "controlBindingType",
                "selectedEventList",
                "combineAllModel"
              ],
              "appSelectorId": `defaultProject$src$app$custommodules$productcardslider${pageCount}$productcardslider${pageCount}.module.ts`,
              "parentId": null,
              "angular": {
                
              },
              "errorText": "Please select a valid Div",
              "database": {
                
              },
              "subtype": "selector",
              "id": "angular_selector_1665494223",
              "subDataArray": [ 
              ],
              "events": {
                "selectedEventList": [
                  
                ],
                "eventData": [
                  
                ]
              },
              "properties": {
                "additionElementClass": "",
                "visibility": true,
                "selectedElementClassArray": [
                  
                ],
                "name": "angular_selector_1665494223",
                "defaultElementCls": "",
                "elementInnerStyles": {
                  
                },
                "controlBindingType": "static",
                "globelAttrLogic": "",
                "label": "angular_selector",
                "elementClass": ""
              },
              "windowProperties": [
                "name",
                "label",
                "visibility",
                "addExitsComponent",
                "expandCollapseForCtrl",
                "globelAttrLogic",
                "controlBindingType",
                "selectedEventList",
                "combineAllModel"
              ]
            }
          },
          "cssData": {},
          "tsData": {
            "diInConstructor": [],
            "varAndMethodList": [
              {
                name: `openSendMailModal`,
                type: 'MethodDefinition'
              },
            ],
            "writeTsCode": ` 
              //newData 
            `,
          },
          "routingData": {},
          "moduleData": {}
         }
      },
      {
        "type": "predefinedNode",
        "subtype": "predefinedNode",
        "ngGenerate": {
          "ngType": "service",
          "ngName": "productcardslider"+ pageCount,
          "ngAuthor": "sagDev",
          "ngDesc": "send Mail Service File",
          "ngServiceType": "provideAsShareService",
        },
        "creationPath": "/src/app/custommodules/productcardslider"+ pageCount,
        "data": {
          "serviceData": {
            "varAndMethodList": [
              {
                name: `showPage`,
                type: 'ClassProperty'
              },
            ],
            "writeTsCode": `showPage: boolean = false;`,
            "sharedData": [
              { "varName": "receiverEmailId" },
              { "varName": "messageSubject" },
              { "varName": "messageBody" }
            ],
            "subDataArray": [
              {
                "type": "customCode",
                "icon": "fas fa-laptop-code",
                "label": "custom Code",
                "description": "Code Here",
                "placeholder": "Custom Code Here..",
                "className": "",
                "classValue": "",
                "SMclassValue": "",
                "MDclassValue": "",
                "LGclassValue": "",
                "XLclassValue": "",
                "labelClasses": "",
                "angular": {
                  "appliedEvents": [
  
                  ],
                  "events": [
  
                  ]
                },
                "properties": {
                  "innerStyles": {},
                  "globalInnerStyles": {},
                  "elementInnerStyles": {},
                  "labelInnerStyles": {},
                  "innerText": "",
                  "classes": "",
                  "innerStylesString": "",
                  "propertyOption2": null,
                  "propertyOption3": null,
                  "propertyOption4": null,
                  "propertyOption5": null
                },
                "subtype": "customCode",
                "subDataArray": [
  
                ],
                //"customCodeBody": "showPage: boolean = false;",
                //"customCodeBody": "public data = {}; \n setData(key: any, data: any) { \n this.data[key] = data; \n} \n getData(key: any) {\n return this.data[key]; \n } \n showPage: boolean = false;   \n\n\n // save profile mail \n saveProfile (body,queryparams:any = '') { \n return this._http.post(`${apiConstant.projectBaseUrl}templatesetup/saveServerProfile` + queryparams,body); \n} \n\n\n // user data save \n userSave (body,queryparams:any = '') { \n return this._http.post(`${apiConstant.projectBaseUrl}mailsms/getmailinfo` + queryparams,body); \n} \n\n\n moduleListData(queryparams: any = ''){\nreturn this._http.get(`${apiConstant.projectBaseUrl}/templatesetup/getModules` + queryparams);\n}\n\n\n subModuleList(moduleId?: any, queryparams: any = ''){\nreturn this._http.get(`${apiConstant.projectBaseUrl}/templatesetup/getSubmodules/${moduleId}` + queryparams);\n} \n\n\n getFormData(formId?: any, queryparams: any = '') {\nreturn this._http.get(`${apiConstant.projectBaseUrl}templatesetup/getForms/${formId}` + queryparams);\n} \n\n\n templateSave(body, queryparams: any = '') {\n return this._http.post(`${apiConstant.projectBaseUrl}templatesetup/saveMailSmsTemplate` + queryparams, body);\n} \n\n\n templateForm(moduleId?: any, submoduleId?: any, formId?: any, queryparams: any = '') { \n return this._http.get(`${apiConstant.projectBaseUrl}templatesetup/getTemplateForm/${moduleId}/${submoduleId}/${formId}` + queryparams); \n } \n\n\n getTemplateData(templateId?: any, queryparams: any = '') {\n return this._http.get(`${apiConstant.projectBaseUrl}templatesetup/getTemplateData/${templateId}` + queryparams);\n}",
                "customCodeBody": "public data = {}; \n setData(key: any, data: any) { \n this.data[key] = data; \n} \n getData(key: any) {\n return this.data[key]; \n } \n showPage: boolean = false; \n\n\n formData = { \ntype : '',\n data : []\n }   \n\n\n ",
                "domNodeTag": [
  
                ],
                "regex": null,
                "handle": true,
                "elementId": null,
                "id": "customCode_1655446732102",
                "parentId": null,
                "isCurrentlySelected": false,
                "option5": null,
                "star_Symbol": false,
                "required": false,
                "toolTip": "i am Toop Tip",
                "toolTipShow": false,
                "errorText": "Please select a valid Div",
                "globelClasses": "",
                "selectedGlobalClassArray": [
  
                ],
                "additionGlobelClasses": "",
                "defaultGlobelCls": "sagFieldSet",
                "elementClass": "",
                "selectedElementClassArray": [
  
                ],
                "additionElementClass": "",
                "defaultElementCls": "",
                "visibility": false,
                "windowProperties": [
                  "label",
                  "name",
                  "defaultGlobelCls",
                  "additionGlobelClasses",
                  "globelClasses",
                  "expandCollapseIcon",
                  "extraElementClass",
                  "innerStyles"
                ],
                "name": "customCode_1655446732102"
              }
            ],
            "details": [
              {
                "diName": "sendmailService",
                "ROW_INDEX": 1,
                "sag_G_Index": 1,
                "author": "RAVINDRA RATHORE",
                "link": "productcard/get-product-catcode",
                "RG_INDEX": 1,
                "RG_P_REF_ID": 0,
                "RG_Level": 1,
                "sno": 2,
                "name": "getProductSliderData",
                "RG_HasChild": false,
                "apiId": "1663935832313",
                "desc": "custome api call"
              }, 
            ],
            "apiList": [
              {
                "msg": "",
                "request": "",
                "expectedReq": "",
                "argument": "",
                "sag_G_Index": 0,
                "fullUrl": "",
                "failedMsg": "error",
                "methodName": "getProductSliderData",
                "errorCode": "",
                "run": false,
                "excutionTime": 0,
                "numberOfReq": 1,
                "url": "productcard/get-product-catcode",
                "expectedRes": "",
                "baseUrl": "apiConstant.restProjectUrl",
                "expand": false,
                "apiResType": null,
                "sno": 1,
                "response": "",
                "uniqId": "1663935832313",
                "successMsg": "scccessfull fetch",
                "apiType": "post",
                "apiList": [],
                "desc": ""
              },
            ] 
          }
        },
  
      }
    ], 
    "globelAttrLogic": {
      "selAttrs": [
        
      ],
      "attrList": [
        
      ]
    },
    "id": null,
    "parentId": null,
    "isCurrentlySelected": false,
    "errorText": "Please select a valid Div",
    "projectConfigProperties": [
      "customTagType",
      "name",
      "label",
      "placeholder",
      "visibility",
      "animationCss",
      "expandCollapseForCtrl",
      "globelAttrLogic",
      "controlBindingType",
      "selectedEventList",
      "combineAllModel"
    ],
    "windowProperties": [
      "customTagType",
      "name",
      "label",
      "placeholder",
      "visibility",
      "animationCss",
      "expandCollapseForCtrl",
      "globelAttrLogic",
      "controlBindingType",
      "selectedEventList",
      "combineAllModel"
    ],
    "attributeLogiclayer": [
      {
        "label": "globelAttrLogic",
        "name": "Globel AttrLogic",
        "value": "globelLogic",
        "type": "globelAttrLogics",
        "id": null,
        "selAttrs": [
          
        ],
        "attrList": [
          
        ]
      },
      {
        "label": "elemAttrLogic",
        "name": "Element AttrLogic",
        "value": "elemAttrLogic",
        "type": "elemAttrLogics",
        "id": null,
        "selAttrs": [
          "label",
          "tooltip"
        ],
        "attrList": [
          
        ]
      }
    ]
  }
    
   return dynamicProductcardSlider;
}
 