export function dynamicContactusFn(){
    // const pageCount =   localStorage.getItem("totalPageCount")|| new Date().getTime(); 
    const dynamicContactus = {
      "data": [
        {
          "creationPath": "",
          "data": {
            "cssData": {
              
            },
            "serviceData": [
              {
                "type": "predefinedNode",
                "subtype": "predefinedNode",
                "ngGenerate": {
                  "ngType": "service",
                  "ngName": "country",
                  "ngAuthor": "CP",
                  "ngDesc": "send Mail Service File",
                  "ngServiceType": "providedInRoot",
                },
                "creationPath": "/country",
                "data": { 
                    "varAndMethodList": [
                      {
                        name: `showPage`,
                        type: 'ClassProperty'
                      },
                    ],
                    "writeTsCode": `showPage: boolean = false;`,
                    "sharedData": [
                      { "varName": "receiverEmailId" },
                      { "varName": "messageSubject" },
                      { "varName": "messageBody" }
                    ],
                    "subDataArray": [
                        {
                            "type": "customCode",
                            "icon": "fas fa-laptop-code",
                            "description": "Custom Code",
                            "subtype": "customCode",
                            "studioDevClasses": "d-block",
                            "angular": {
                              
                            },
                            "events": {
                              "selectedEventList": [
                                
                              ],
                              "eventData": [
                                
                              ]
                            },
                            "database": {
                              "databaseName": "",
                              "tableName": "",
                              "columnName": "",
                              "columnInfo": {
                                
                              },
                              "dbMappingState": "none",
                              "dbMappingMsg": "",
                              "onExcessLoad": false,
                              "master": false
                            },
                            "properties": {
                              "label": "Type your text to display here only",
                              "placeholder": null,
                              "name": "customCode_1667197449102",
                              "visibility": true
                            },
                            "parseCtrl": {
                              "subData": false,
                              "layerTopId": "customCode~customCode#Globel",
                              "layerCount": "2",
                              "layerCtrls": [
                                "customCode~customCode#Globel",
                                "customCode~customCode#Element"
                              ]
                            },
                            "subDataArray": [
                              
                            ],
                            "id": "customCode_1667197449102",
                            "parentId": null,
                            "isCurrentlySelected": true,
                            "errorText": "Please enter a valid Value",
                            "customCodeBody": "",
                            "projectConfigProperties": [
                              "name",
                              "label",
                              "visibility",
                              "selectedEventList",
                              "combineAllModel",
                              "databaseName",
                              "tableName",
                              "columnName",
                              "onExcessLoad",
                              "master"
                            ],
                            "windowProperties": [
                              "name",
                              "label",
                              "visibility",
                              "selectedEventList",
                              "combineAllModel",
                              "databaseName",
                              "tableName",
                              "columnName",
                              "onExcessLoad",
                              "master"
                            ],
                            "attributeLogiclayer": [
                              {
                                "label": "globelAttrLogic",
                                "name": "Globel AttrLogic",
                                "value": "globelLogic",
                                "type": "globelAttrLogics",
                                "id": null,
                                "selAttrs": [
                                  
                                ],
                                "attrList": [
                                  
                                ]
                              },
                              {
                                "label": "elemAttrLogic",
                                "name": "Element AttrLogic",
                                "value": "elemAttrLogic",
                                "type": "elemAttrLogics",
                                "id": null,
                                "selAttrs": [
                                  "label",
                                  "tooltip"
                                ],
                                "attrList": [
                                  
                                ]
                              }
                            ]
                        }
                    ],
                    "details": [
                      {
                        "diName": "sendmailService",
                        "ROW_INDEX": 1,
                        "sag_G_Index": 1,
                        "author": "CP",
                        "link": "country/get-product-catcode",
                        "RG_INDEX": 1,
                        "RG_P_REF_ID": 0,
                        "RG_Level": 1,
                        "sno": 2,
                        "name": "getcountryData",
                        "RG_HasChild": false,
                        "apiId": "1663935832313",
                        "desc": "custome api call"
                      }, 
                    ],
                    "apiList": [
                      {
                        "msg": "",
                        "request": "",
                        "expectedReq": "",
                        "argument": "",
                        "sag_G_Index": 0,
                        "fullUrl": "",
                        "failedMsg": "error",
                        "methodName": "getcountryData",
                        "errorCode": "",
                        "run": false,
                        "excutionTime": 0,
                        "numberOfReq": 1,
                        "url": "country/get-product-catcode",
                        "expectedRes": "",
                        "baseUrl": "apiConstant.restProjectUrl",
                        "expand": false,
                        "apiResType": null,
                        "sno": 1,
                        "response": "",
                        "uniqId": "1663935832313",
                        "successMsg": "scccessfull fetch",
                        "apiType": "post",
                        "apiList": [],
                        "desc": ""
                      },
                    ]  
                },
          
              }
            ],
            "htmlData": [
              {
                "subtype": "div",
                "isCurrentlySelected": true,
                "type": "pageContainer",
                "studioDevClasses": "d-block",
                "subDataArray": [
                  {
                    "subtype": "div",
                    "isCurrentlySelected": false,
                    "id": "htmlTag_1670387515371",
                    "type": "htmlTag",
                    "studioDevClasses": "",
                    "subDataArray": [
                      {
                        "subtype": "row",
                        "isCurrentlySelected": false,
                        "id": "row_1670387531497",
                        "type": "row",
                        "studioDevClasses": "",
                        "subDataArray": [
                          {
                            "subtype": "column",
                            "isCurrentlySelected": false,
                            "type": "column",
                            "studioDevClasses": "",
                            "subDataArray": [
                              {
                                "studiodevclasses": "d-block",
                                "isCurrentlySelected": false,
                                "label": "Text",
                                "type": "input",
                                "required": true,
                                "angular": {
                                  "tooltipTitle": "",
                                  "formType": "reactiveForm",
                                  "toolTipPosition": "bottom",
                                  "validationMsg": "",
                                  "formGroupName": "countryform",
                                  "selectFormGroupItem": "countryform",
                                  "toolTipEvent": "click",
                                  "validators": [],
                                  "selectedValidatorsForControls": [],
                                  "toolTipShow": true
                                },
                                "database": {
                                  "databaseName": "svn_db",
                                  "dbMappingState": "valid",
                                  "columnInfo": {
                                    "entitylabel": "countryName",
                                    "size": "100",
                                    "pentity": null,
                                    "fkey": "N",
                                    "name": "country_name",
                                    "pkey": "N",
                                    "type": "VARCHAR"
                                  },
                                  "dbMappingMsg": "Type : VARCHAR\n     Size : 100\n     PrimaryKey :No\n     ForeignKey :No\n     ParentEntity: null \n    ",
                                  "tableName": "mst_country",
                                  "columnName": "countryName"
                                },
                                "subtype": "text",
                                "name": "input_1670387677710",
                                "id": "input_1670387677710",
                                "placeholder": "Enter Country Name",
                                "subDataArray": [],
                                "properties": {
                                  "labelClass": " inputlabel_90",
                                  "visibility": true,
                                  "selectedGlobalClassArray": [],
                                  "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                  "disable": false,
                                  "defaultLabelCls": "input~text#Label",
                                  "defaultElementCls": "form-control input~text#Element",
                                  "name": "countryName",
                                  "selectedTagClassArray": [
                                    "inputlabel_90"
                                  ],
                                  "placeholder": "Enter your text",
                                  "label": "Country Name",
                                  "globelClasses": ""
                                },
                                "events": {}
                              },
                              {
                                "angular": {
                                  "tooltipTitle": "",
                                  "formType": "reactiveForm",
                                  "toolTipPosition": "",
                                  "validationMsg": "",
                                  "formGroupName": "countryform",
                                  "selectFormGroupItem": "countryform",
                                  "toolTipEvent": "",
                                  "toolTipShow": false
                                },
                                "database": {
                                  "databaseName": "svn_db",
                                  "dbMappingState": "valid",
                                  "columnInfo": {
                                    "entitylabel": "countryCode",
                                    "size": "20",
                                    "pentity": null,
                                    "fkey": "N",
                                    "name": "country_code",
                                    "pkey": "N",
                                    "type": "VARCHAR"
                                  },
                                  "dbMappingMsg": "Type : VARCHAR\n     Size : 20\n     PrimaryKey :No\n     ForeignKey :No\n     ParentEntity: null \n    ",
                                  "tableName": "mst_country",
                                  "columnName": "countryCode"
                                },
                                "subtype": "text",
                                "studiodevclasses": "d-block",
                                "isCurrentlySelected": false,
                                "name": "countryCode",
                                "id": "input_1670387683061",
                                "label": "Text",
                                "type": "input",
                                "subDataArray": [],
                                "properties": {
                                  "labelClass": " inputlabel_90",
                                  "visibility": true,
                                  "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                  "disable": false,
                                  "defaultLabelCls": "input~text#Label",
                                  "defaultElementCls": "form-control input~text#Element",
                                  "name": "countryCode",
                                  "selectedTagClassArray": [
                                    "inputlabel_90"
                                  ],
                                  "placeholder": "Enter your text",
                                  "label": "Country Code"
                                },
                                "events": {}
                              },
                              {
                                "angular": {
                                  "tooltipTitle": "",
                                  "formType": "reactiveForm",
                                  "toolTipPosition": "",
                                  "validationMsg": "",
                                  "formGroupName": "countryform",
                                  "selectFormGroupItem": "countryform",
                                  "toolTipEvent": "",
                                  "validators": [],
                                  "selectedValidatorsForControls": [],
                                  "toolTipShow": false
                                },
                                "database": {
                                  "databaseName": "svn_db",
                                  "dbMappingState": "invalid",
                                  "columnInfo": {
                                    "entitylabel": "countryId",
                                    "size": "11",
                                    "pentity": null,
                                    "fkey": "N",
                                    "name": "country_id",
                                    "pkey": "Y",
                                    "type": "INT"
                                  },
                                  "dbMappingMsg": "Type : INT\n     Size : 11\n     PrimaryKey :Yes\n     ForeignKey :Yes\n     ParentEntity: null \n    ",
                                  "tableName": "mst_country",
                                  "columnName": "countryId"
                                },
                                "subtype": "number",
                                "studiodevclasses": "d-block",
                                "isCurrentlySelected": false,
                                "name": "countryId",
                                "id": "input_1670387704644",
                                "label": "Country Id",
                                "type": "input",
                                "subDataArray": [],
                                "properties": {
                                  "labelClass": " inputlabel_90",
                                  "visibility": false,
                                  "defaultGlobelCls": "form_group_label form-group input~number#Globel ",
                                  "disable": false,
                                  "defaultLabelCls": "input~number#Label",
                                  "defaultElementCls": "form-control input~number#Element",
                                  "name": "countryId",
                                  "globelAttrLogic": "",
                                  "selectedTagClassArray": [
                                    "inputlabel_90"
                                  ],
                                  "placeholder": "Enter Numeric Value",
                                  "label": "Country Id"
                                },
                                "events": {}
                              },
                              {
                                "angular": {
                                  "formType": "reactiveForm",
                                  "formGroupName": "countryform"
                                },
                                "database": {},
                                "selectedEventList": " click ",
                                "subtype": "button",
                                "isCurrentlySelected": false,
                                "id": "input_1670387694054",
                                "type": "input",
                                "studioDevClasses": "d-inline-block",
                                "subDataArray": [],
                                "properties": {
                                  "visibility": true,
                                  "name": "save",
                                  "defaultElementCls": "btn btn-primary input~button#Element m-1",
                                  "label": "Save"
                                },
                                "events": {
                                  "selectedEventList": [
                                    "click"
                                  ],
                                  "eventData": [
                                    {
                                      "args": "",
                                      "nodeName": "onclicksave",
                                      "nodeSubType": "method",
                                      "descr": "",
                                      "authorName": "",
                                      "methodState": {
                                        "components": {
                                          "requestBodyModel": {
                                            "title": "Request Modal",
                                            "isActive": true
                                          },
                                          "requestUrlModel": {
                                            "title": "Path/Param Modal",
                                            "isActive": false
                                          },
                                          "selectedItem": "requestBodyModel",
                                          "service": {
                                            "title": "Service File",
                                            "isActive": true,
                                            "serviceListShow": true
                                          },
                                          "response": {
                                            "title": "Response File",
                                            "isActive": false
                                          },
                                          "pageMethodList": {
                                            "title": "page Method List",
                                            "isActive": false
                                          },
                                          "pageNavigate": {
                                            "title": "Page Navigate",
                                            "isActive": false
                                          },
                                          "selectedTitle": "Request Modal",
                                          "validation": {
                                            "title": "Validation",
                                            "isActive": false
                                          },
                                          "finalDetails": {
                                            "title": "Final Details",
                                            "isActive": true
                                          },
                                          "globalDataSet": {
                                            "title": "Globel Data Set",
                                            "isActive": false
                                          }
                                        },
                                        "pageMappingModelDataObject": {
                                          "activeBreadCrumInfo": {
                                            "layerNodeType": "typeObject",
                                            "parent": null,
                                            "selectedRowIndex": null,
                                            "iterateOver": "none",
                                            "activeClass": true,
                                            "name": "Main Request",
                                            "activePageModalData": [
                                              {
                                                "minlength": "",
                                                "dValue": "",
                                                "sag_G_Index": 0,
                                                "formGroupName": "countryform",
                                                "maxlength": "",
                                                "colTypeSize": "",
                                                "label": "Country Name",
                                                "type": "input",
                                                "javaDType": "",
                                                "javaVName": "countryName",
                                                "subtype": "text",
                                                "sno": 1,
                                                "getValueAs": "default",
                                                "setValue": "this.countryform.controls['countryName'].value",
                                                "name": "countryName",
                                                "checkboxcolumnsForFormData": true,
                                                "id": "input_1670387677710"
                                              },
                                              {
                                                "minlength": "",
                                                "dValue": "",
                                                "sag_G_Index": 1,
                                                "formGroupName": "countryform",
                                                "maxlength": "",
                                                "colTypeSize": "",
                                                "label": "Country Code",
                                                "type": "input",
                                                "javaDType": "",
                                                "javaVName": "countryCode",
                                                "subtype": "text",
                                                "sno": 2,
                                                "getValueAs": "default",
                                                "setValue": "this.countryform.controls['countryCode'].value",
                                                "name": "countryCode",
                                                "checkboxcolumnsForFormData": true,
                                                "id": "input_1670387683061"
                                              },
                                              {
                                                "minlength": "",
                                                "dValue": "",
                                                "sag_G_Index": 2,
                                                "formGroupName": "countryform",
                                                "maxlength": "",
                                                "colTypeSize": " country_id / INT / 11",
                                                "label": "Country Id",
                                                "type": "input",
                                                "tableName": "mst_country",
                                                "javaDType": "",
                                                "javaVName": "countryId",
                                                "subtype": "number",
                                                "sno": 3,
                                                "getValueAs": "default",
                                                "setValue": "this.countryform.controls['countryId'].value",
                                                "name": "countryId",
                                                "checkboxcolumnsForFormData": true,
                                                "id": "input_1670387704644"
                                              }
                                            ],
                                            "id": "1001"
                                          },
                                          "allLayerPageModelData": {
                                            "1001": {
                                              "layerNodeType": "typeObject",
                                              "parent": null,
                                              "selectedRowIndex": null,
                                              "iterateOver": "none",
                                              "activeClass": true,
                                              "name": "Main Request",
                                              "activePageModalData": [
                                                {
                                                  "minlength": "",
                                                  "dValue": "",
                                                  "sag_G_Index": 0,
                                                  "formGroupName": "countryform",
                                                  "maxlength": "",
                                                  "colTypeSize": "",
                                                  "label": "Country Name",
                                                  "type": "input",
                                                  "javaDType": "",
                                                  "javaVName": "countryName",
                                                  "subtype": "text",
                                                  "sno": 1,
                                                  "getValueAs": "default",
                                                  "setValue": "this.countryform.controls['countryName'].value",
                                                  "name": "countryName",
                                                  "checkboxcolumnsForFormData": true,
                                                  "id": "input_1670387677710"
                                                },
                                                {
                                                  "minlength": "",
                                                  "dValue": "",
                                                  "sag_G_Index": 1,
                                                  "formGroupName": "countryform",
                                                  "maxlength": "",
                                                  "colTypeSize": "",
                                                  "label": "Country Code",
                                                  "type": "input",
                                                  "javaDType": "",
                                                  "javaVName": "countryCode",
                                                  "subtype": "text",
                                                  "sno": 2,
                                                  "getValueAs": "default",
                                                  "setValue": "this.countryform.controls['countryCode'].value",
                                                  "name": "countryCode",
                                                  "checkboxcolumnsForFormData": true,
                                                  "id": "input_1670387683061"
                                                },
                                                {
                                                  "minlength": "",
                                                  "dValue": "",
                                                  "sag_G_Index": 2,
                                                  "formGroupName": "countryform",
                                                  "maxlength": "",
                                                  "colTypeSize": " country_id / INT / 11",
                                                  "label": "Country Id",
                                                  "type": "input",
                                                  "tableName": "mst_country",
                                                  "javaDType": "",
                                                  "javaVName": "countryId",
                                                  "subtype": "number",
                                                  "sno": 3,
                                                  "getValueAs": "default",
                                                  "setValue": "this.countryform.controls['countryId'].value",
                                                  "name": "countryId",
                                                  "checkboxcolumnsForFormData": true,
                                                  "id": "input_1670387704644"
                                                }
                                              ],
                                              "id": "1001"
                                            }
                                          },
                                          "breadCrumbArray": {
                                            "1001": {
                                              "layerNodeType": "typeObject",
                                              "parent": null,
                                              "selectedRowIndex": null,
                                              "iterateOver": "none",
                                              "activeClass": true,
                                              "name": "Main Request",
                                              "activePageModalData": [
                                                {
                                                  "minlength": "",
                                                  "dValue": "",
                                                  "sag_G_Index": 0,
                                                  "formGroupName": "countryform",
                                                  "maxlength": "",
                                                  "colTypeSize": "",
                                                  "label": "Country Name",
                                                  "type": "input",
                                                  "javaDType": "",
                                                  "javaVName": "countryName",
                                                  "subtype": "text",
                                                  "sno": 1,
                                                  "getValueAs": "default",
                                                  "setValue": "this.countryform.controls['countryName'].value",
                                                  "name": "countryName",
                                                  "checkboxcolumnsForFormData": true,
                                                  "id": "input_1670387677710"
                                                },
                                                {
                                                  "minlength": "",
                                                  "dValue": "",
                                                  "sag_G_Index": 1,
                                                  "formGroupName": "countryform",
                                                  "maxlength": "",
                                                  "colTypeSize": "",
                                                  "label": "Country Code",
                                                  "type": "input",
                                                  "javaDType": "",
                                                  "javaVName": "countryCode",
                                                  "subtype": "text",
                                                  "sno": 2,
                                                  "getValueAs": "default",
                                                  "setValue": "this.countryform.controls['countryCode'].value",
                                                  "name": "countryCode",
                                                  "checkboxcolumnsForFormData": true,
                                                  "id": "input_1670387683061"
                                                },
                                                {
                                                  "minlength": "",
                                                  "dValue": "",
                                                  "sag_G_Index": 2,
                                                  "formGroupName": "countryform",
                                                  "maxlength": "",
                                                  "colTypeSize": " country_id / INT / 11",
                                                  "label": "Country Id",
                                                  "type": "input",
                                                  "tableName": "mst_country",
                                                  "javaDType": "",
                                                  "javaVName": "countryId",
                                                  "subtype": "number",
                                                  "sno": 3,
                                                  "getValueAs": "default",
                                                  "setValue": "this.countryform.controls['countryId'].value",
                                                  "name": "countryId",
                                                  "checkboxcolumnsForFormData": true,
                                                  "id": "input_1670387704644"
                                                }
                                              ],
                                              "id": "1001"
                                            }
                                          },
                                          "pageMappingModelFrom": "requestBodyModel",
                                          "activePageModalData": [
                                            {
                                              "minlength": "",
                                              "dValue": "",
                                              "sag_G_Index": 0,
                                              "formGroupName": "countryform",
                                              "maxlength": "",
                                              "colTypeSize": "",
                                              "label": "Country Name",
                                              "type": "input",
                                              "javaDType": "",
                                              "javaVName": "countryName",
                                              "subtype": "text",
                                              "sno": 1,
                                              "getValueAs": "default",
                                              "setValue": "this.countryform.controls['countryName'].value",
                                              "name": "countryName",
                                              "checkboxcolumnsForFormData": true,
                                              "id": "input_1670387677710"
                                            },
                                            {
                                              "minlength": "",
                                              "dValue": "",
                                              "sag_G_Index": 1,
                                              "formGroupName": "countryform",
                                              "maxlength": "",
                                              "colTypeSize": "",
                                              "label": "Country Code",
                                              "type": "input",
                                              "javaDType": "",
                                              "javaVName": "countryCode",
                                              "subtype": "text",
                                              "sno": 2,
                                              "getValueAs": "default",
                                              "setValue": "this.countryform.controls['countryCode'].value",
                                              "name": "countryCode",
                                              "checkboxcolumnsForFormData": true,
                                              "id": "input_1670387683061"
                                            },
                                            {
                                              "minlength": "",
                                              "dValue": "",
                                              "sag_G_Index": 2,
                                              "formGroupName": "countryform",
                                              "maxlength": "",
                                              "colTypeSize": " country_id / INT / 11",
                                              "label": "Country Id",
                                              "type": "input",
                                              "tableName": "mst_country",
                                              "javaDType": "",
                                              "javaVName": "countryId",
                                              "subtype": "number",
                                              "sno": 3,
                                              "getValueAs": "default",
                                              "setValue": "this.countryform.controls['countryId'].value",
                                              "name": "countryId",
                                              "checkboxcolumnsForFormData": true,
                                              "id": "input_1670387704644"
                                            }
                                          ]
                                        },
                                        "responseBindedList": [],
                                        "requestForm": {
                                          "msg": "",
                                          "expectedReq": "",
                                          "request": "",
                                          "argument": "",
                                          "fullUrl": "",
                                          "methodName": "saveCountry",
                                          "failedMsg": "error",
                                          "errorCode": "",
                                          "run": false,
                                          "excutionTime": 0,
                                          "numberOfReq": 1,
                                          "url": "saveCountry",
                                          "expectedRes": "",
                                          "descr": "",
                                          "baseUrl": "http://localhost:7778/",
                                          "expand": false,
                                          "apiResType": null,
                                          "response": "",
                                          "uniqId": "1670392950713",
                                          "successMsg": "scccessfully fetch",
                                          "apiType": "post",
                                          "apiList": []
                                        },
                                        "selectedMethodFromService": {
                                          "descr": null,
                                          "diImportPath": "src/app/sag/contact/contact.service",
                                          "diName": "ContactService",
                                          "diShortName": "contact",
                                          "author": null,
                                          "link": "saveCountry",
                                          "name": "saveCountry",
                                          "diType": "public",
                                          "apiId": "1670392950713"
                                        }
                                      },
                                      "bodyInfo": [
                                        {
                                          "expression": {
                                            "callee": {
                                              "computed": false,
                                              "property": {
                                                "name": "subscribe",
                                                "type": "Identifier"
                                              },
                                              "type": "MemberExpression",
                                              "object": {
                                                "callee": {
                                                  "computed": false,
                                                  "property": {
                                                    "name": "saveCountry",
                                                    "type": "Identifier"
                                                  },
                                                  "type": "MemberExpression",
                                                  "object": {
                                                    "computed": false,
                                                    "property": {
                                                      "name": "contact",
                                                      "type": "Identifier"
                                                    },
                                                    "type": "MemberExpression",
                                                    "object": {
                                                      "type": "ThisExpression"
                                                    }
                                                  }
                                                },
                                                "arguments": [
                                                  {
                                                    "name": "postData",
                                                    "type": "Identifier"
                                                  }
                                                ],
                                                "type": "CallExpression"
                                              }
                                            },
                                            "arguments": [
                                              {
                                                "async": false,
                                                "expression": false,
                                                "generator": false,
                                                "id": null,
                                                "type": "ArrowFunctionExpression",
                                                "params": [
                                                  {
                                                    "name": "res",
                                                    "type": "Identifier"
                                                  }
                                                ],
                                                "body": {
                                                  "type": "BlockStatement",
                                                  "body": []
                                                }
                                              }
                                            ],
                                            "type": "CallExpression"
                                          },
                                          "type": "ExpressionStatement"
                                        }
                                      ],
                                      "methodName": "onclicksave",
                                      "eventType": "click",
                                      "id": "click_1670393004249",
                                      "nodeType": "",
                                      "params": ""
                                    }
                                  ]
                                }
                              }
                            ],
                            "properties": {
                              "visibility": true,
                              "name": "",
                              "label": "Column",
                              "colClass": "col-sm-12"
                            }
                          }
                        ],
                        "properties": {
                          "visibility": true,
                          "name": "row_1670387531497",
                          "defaultElementCls": "row mb-2",
                          "label": "Row"
                        },
                        "parentId": "htmlTag_1670387515371"
                      }
                    ],
                    "properties": {
                      "name": "htmlTag_1670387515371",
                      "elementInnerStyles": {
                        "left": "%"
                      },
                      "label": ""
                    }
                  }
                ],
                "properties": {
                  "additionElementClass": "",
                  "visibility": true,
                  "selectedElementClassArray": [],
                  "name": "",
                  "defaultElementCls": "d-flex flex-column full-modal h-100 pageContainer#Globel",
                  "elementInnerStyles": {},
                  "label": "Page Container",
                  "elementClass": ""
                }
              }
            ],
            "moduleData": {
              
            },
            "javaApiData": {
              
            },
            "routingData": {
              
            },
            "tsData": {
              "writeTsCode": "",
              "varAndMethodList": [
                
              ],
              "diInConstructor": [
                {
                  "diImportPath": "src/app/sag/contact/contact.service",
                  "diName": "ContactService",
                  "diShortName": "contact",
                  "diType": "public"
                }
              ],
              "externalMethods": [
                {
                  "args": "",
                  "nodeName": "onclicksave",
                  "nodeSubType": "method",
                  "descr": "",
                  "authorName": "",
                  "methodState": {
                    "components": {
                      "requestBodyModel": {
                        "title": "Request Modal",
                        "isActive": true
                      },
                      "requestUrlModel": {
                        "title": "Path/Param Modal",
                        "isActive": false
                      },
                      "selectedItem": "requestBodyModel",
                      "service": {
                        "title": "Service File",
                        "isActive": true,
                        "serviceListShow": true
                      },
                      "response": {
                        "title": "Response File",
                        "isActive": false
                      },
                      "pageMethodList": {
                        "title": "page Method List",
                        "isActive": false
                      },
                      "pageNavigate": {
                        "title": "Page Navigate",
                        "isActive": false
                      },
                      "selectedTitle": "Request Modal",
                      "validation": {
                        "title": "Validation",
                        "isActive": false
                      },
                      "finalDetails": {
                        "title": "Final Details",
                        "isActive": true
                      },
                      "globalDataSet": {
                        "title": "Globel Data Set",
                        "isActive": false
                      }
                    },
                    "pageMappingModelDataObject": {
                      "activeBreadCrumInfo": {
                        "layerNodeType": "typeObject",
                        "parent": null,
                        "selectedRowIndex": null,
                        "iterateOver": "none",
                        "activeClass": true,
                        "name": "Main Request",
                        "activePageModalData": [
                          {
                            "minlength": "",
                            "dValue": "",
                            "sag_G_Index": 0,
                            "formGroupName": "countryform",
                            "maxlength": "",
                            "colTypeSize": "",
                            "label": "Country Name",
                            "type": "input",
                            "javaDType": "",
                            "javaVName": "countryName",
                            "subtype": "text",
                            "sno": 1,
                            "getValueAs": "default",
                            "setValue": "this.countryform.controls['countryName'].value",
                            "name": "countryName",
                            "checkboxcolumnsForFormData": true,
                            "id": "input_1670387677710"
                          },
                          {
                            "minlength": "",
                            "dValue": "",
                            "sag_G_Index": 1,
                            "formGroupName": "countryform",
                            "maxlength": "",
                            "colTypeSize": "",
                            "label": "Country Code",
                            "type": "input",
                            "javaDType": "",
                            "javaVName": "countryCode",
                            "subtype": "text",
                            "sno": 2,
                            "getValueAs": "default",
                            "setValue": "this.countryform.controls['countryCode'].value",
                            "name": "countryCode",
                            "checkboxcolumnsForFormData": true,
                            "id": "input_1670387683061"
                          },
                          {
                            "minlength": "",
                            "dValue": "",
                            "sag_G_Index": 2,
                            "formGroupName": "countryform",
                            "maxlength": "",
                            "colTypeSize": " country_id / INT / 11",
                            "label": "Country Id",
                            "type": "input",
                            "tableName": "mst_country",
                            "javaDType": "",
                            "javaVName": "countryId",
                            "subtype": "number",
                            "sno": 3,
                            "getValueAs": "default",
                            "setValue": "this.countryform.controls['countryId'].value",
                            "name": "countryId",
                            "checkboxcolumnsForFormData": true,
                            "id": "input_1670387704644"
                          }
                        ],
                        "id": "1001"
                      },
                      "allLayerPageModelData": {
                        "1001": {
                          "layerNodeType": "typeObject",
                          "parent": null,
                          "selectedRowIndex": null,
                          "iterateOver": "none",
                          "activeClass": true,
                          "name": "Main Request",
                          "activePageModalData": [
                            {
                              "minlength": "",
                              "dValue": "",
                              "sag_G_Index": 0,
                              "formGroupName": "countryform",
                              "maxlength": "",
                              "colTypeSize": "",
                              "label": "Country Name",
                              "type": "input",
                              "javaDType": "",
                              "javaVName": "countryName",
                              "subtype": "text",
                              "sno": 1,
                              "getValueAs": "default",
                              "setValue": "this.countryform.controls['countryName'].value",
                              "name": "countryName",
                              "checkboxcolumnsForFormData": true,
                              "id": "input_1670387677710"
                            },
                            {
                              "minlength": "",
                              "dValue": "",
                              "sag_G_Index": 1,
                              "formGroupName": "countryform",
                              "maxlength": "",
                              "colTypeSize": "",
                              "label": "Country Code",
                              "type": "input",
                              "javaDType": "",
                              "javaVName": "countryCode",
                              "subtype": "text",
                              "sno": 2,
                              "getValueAs": "default",
                              "setValue": "this.countryform.controls['countryCode'].value",
                              "name": "countryCode",
                              "checkboxcolumnsForFormData": true,
                              "id": "input_1670387683061"
                            },
                            {
                              "minlength": "",
                              "dValue": "",
                              "sag_G_Index": 2,
                              "formGroupName": "countryform",
                              "maxlength": "",
                              "colTypeSize": " country_id / INT / 11",
                              "label": "Country Id",
                              "type": "input",
                              "tableName": "mst_country",
                              "javaDType": "",
                              "javaVName": "countryId",
                              "subtype": "number",
                              "sno": 3,
                              "getValueAs": "default",
                              "setValue": "this.countryform.controls['countryId'].value",
                              "name": "countryId",
                              "checkboxcolumnsForFormData": true,
                              "id": "input_1670387704644"
                            }
                          ],
                          "id": "1001"
                        }
                      },
                      "breadCrumbArray": {
                        "1001": {
                          "layerNodeType": "typeObject",
                          "parent": null,
                          "selectedRowIndex": null,
                          "iterateOver": "none",
                          "activeClass": true,
                          "name": "Main Request",
                          "activePageModalData": [
                            {
                              "minlength": "",
                              "dValue": "",
                              "sag_G_Index": 0,
                              "formGroupName": "countryform",
                              "maxlength": "",
                              "colTypeSize": "",
                              "label": "Country Name",
                              "type": "input",
                              "javaDType": "",
                              "javaVName": "countryName",
                              "subtype": "text",
                              "sno": 1,
                              "getValueAs": "default",
                              "setValue": "this.countryform.controls['countryName'].value",
                              "name": "countryName",
                              "checkboxcolumnsForFormData": true,
                              "id": "input_1670387677710"
                            },
                            {
                              "minlength": "",
                              "dValue": "",
                              "sag_G_Index": 1,
                              "formGroupName": "countryform",
                              "maxlength": "",
                              "colTypeSize": "",
                              "label": "Country Code",
                              "type": "input",
                              "javaDType": "",
                              "javaVName": "countryCode",
                              "subtype": "text",
                              "sno": 2,
                              "getValueAs": "default",
                              "setValue": "this.countryform.controls['countryCode'].value",
                              "name": "countryCode",
                              "checkboxcolumnsForFormData": true,
                              "id": "input_1670387683061"
                            },
                            {
                              "minlength": "",
                              "dValue": "",
                              "sag_G_Index": 2,
                              "formGroupName": "countryform",
                              "maxlength": "",
                              "colTypeSize": " country_id / INT / 11",
                              "label": "Country Id",
                              "type": "input",
                              "tableName": "mst_country",
                              "javaDType": "",
                              "javaVName": "countryId",
                              "subtype": "number",
                              "sno": 3,
                              "getValueAs": "default",
                              "setValue": "this.countryform.controls['countryId'].value",
                              "name": "countryId",
                              "checkboxcolumnsForFormData": true,
                              "id": "input_1670387704644"
                            }
                          ],
                          "id": "1001"
                        }
                      },
                      "pageMappingModelFrom": "requestBodyModel",
                      "activePageModalData": [
                        {
                          "minlength": "",
                          "dValue": "",
                          "sag_G_Index": 0,
                          "formGroupName": "countryform",
                          "maxlength": "",
                          "colTypeSize": "",
                          "label": "Country Name",
                          "type": "input",
                          "javaDType": "",
                          "javaVName": "countryName",
                          "subtype": "text",
                          "sno": 1,
                          "getValueAs": "default",
                          "setValue": "this.countryform.controls['countryName'].value",
                          "name": "countryName",
                          "checkboxcolumnsForFormData": true,
                          "id": "input_1670387677710"
                        },
                        {
                          "minlength": "",
                          "dValue": "",
                          "sag_G_Index": 0,
                          "formGroupName": "countryform",
                          "maxlength": "",
                          "colTypeSize": "",
                          "label": "Country Code",
                          "type": "input",
                          "javaDType": "",
                          "javaVName": "countryCode",
                          "subtype": "text",
                          "sno": 1,
                          "getValueAs": "default",
                          "setValue": "this.countryform.controls['countryCode'].value",
                          "name": "countryCode",
                          "checkboxcolumnsForFormData": true,
                          "id": "input_1670387683061"
                        },
                        {
                          "minlength": "",
                          "dValue": "",
                          "sag_G_Index": 0,
                          "formGroupName": "countryform",
                          "maxlength": "",
                          "colTypeSize": " country_id / INT / 11",
                          "label": "Country Id",
                          "type": "input",
                          "tableName": "mst_country",
                          "javaDType": "",
                          "javaVName": "countryId",
                          "subtype": "number",
                          "sno": 1,
                          "getValueAs": "default",
                          "setValue": "this.countryform.controls['countryId'].value",
                          "name": "countryId",
                          "checkboxcolumnsForFormData": true,
                          "id": "input_1670387704644"
                        }
                      ]
                    },
                    "responseBindedList": [],
                    "requestForm": {
                      "msg": "",
                      "expectedReq": "",
                      "request": "",
                      "argument": "",
                      "fullUrl": "",
                      "methodName": "saveCountry",
                      "failedMsg": "error",
                      "errorCode": "",
                      "run": false,
                      "excutionTime": 0,
                      "numberOfReq": 1,
                      "url": "saveCountry",
                      "expectedRes": "",
                      "descr": "",
                      "baseUrl": "http://localhost:7778/",
                      "expand": false,
                      "apiResType": null,
                      "response": "",
                      "uniqId": "1670392950713",
                      "successMsg": "scccessfully fetch",
                      "apiType": "post",
                      "apiList": []
                    },
                    "selectedMethodFromService": {
                      "descr": null,
                      "diImportPath": "src/app/sag/contact/contact.service",
                      "diName": "ContactService",
                      "diShortName": "contact",
                      "author": null,
                      "link": "saveCountry",
                      "name": "saveCountry",
                      "diType": "public",
                      "apiId": "1670392950713"
                    }
                  },
                  "bodyInfo": [
                    {
                      "expression": {
                        "callee": {
                          "computed": false,
                          "property": {
                            "name": "subscribe",
                            "type": "Identifier"
                          },
                          "type": "MemberExpression",
                          "object": {
                            "callee": {
                              "computed": false,
                              "property": {
                                "name": "saveCountry",
                                "type": "Identifier"
                              },
                              "type": "MemberExpression",
                              "object": {
                                "computed": false,
                                "property": {
                                  "name": "contact",
                                  "type": "Identifier"
                                },
                                "type": "MemberExpression",
                                "object": {
                                  "type": "ThisExpression"
                                }
                              }
                            },
                            "arguments": [
                              {
                                "name": "postData",
                                "type": "Identifier"
                              }
                            ],
                            "type": "CallExpression"
                          }
                        },
                        "arguments": [
                          {
                            "async": false,
                            "expression": false,
                            "generator": false,
                            "id": null,
                            "type": "ArrowFunctionExpression",
                            "params": [
                              {
                                "name": "res",
                                "type": "Identifier"
                              }
                            ],
                            "body": {
                              "type": "BlockStatement",
                              "body": []
                            }
                          }
                        ],
                        "type": "CallExpression"
                      },
                      "type": "ExpressionStatement"
                    }
                  ],
                  "methodName": "onclicksave",
                  "eventType": "click",
                  "id": "click_1670393004249",
                  "nodeType": "",
                  "params": ""
                }
              ]
            }
          },
          "subtype": "predefinedNode",
          "ngGenerate": {
            "ngName": "country",
            "ngAuthor": "Ravinder Singh",
            "ngServiceType": "providedInRoot",
            "ngDesc": "country",
            "menuName": "Country",
            "ngType": "page"
          },
          "activeCompData": {
            "cssData": {
              
            },
            "htmlData": {
              "subDataObj": {
                
              },
              "selectorObj": {
                
              }
            },
            "moduleData": {
              
            },
            "routingData": {
              
            },
            "tsData": {
              "writeTsCode": "",
              "varAndMethodList": [
                
              ],
              "diInConstructor": [
                
              ]
            }
          },
          "type": "predefinedNode"
        }
      ]
    };

    return dynamicContactus;
 }
  