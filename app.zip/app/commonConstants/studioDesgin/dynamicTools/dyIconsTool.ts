export const dynamicIconObj = {
    "imageUrl": '<div class="icon"><i class="fa fa-home animated flash" style="font-size: 20px;"></i></div>',
    "label": '',
    viewColumn: '2',
    "data": [
        {
            "type": "fontIcon",
            "subtype": "fontIcon",
            "studioDevClasses": "d-inline-block",
            "properties": {
                "label": "Font Awesome Icon",
                "name": "",
                "iconClass": "fa fa-home",
                "disable": false,
                "visibility": true,
                "visibleOnlyOn":''
            },
            "subDataArray": [],
        }
    ]
}