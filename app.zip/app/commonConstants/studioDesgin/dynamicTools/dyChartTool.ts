export const dynamicChartObj = {
    imageUrl: '',
    label: 'Chars',
    viewColumn: '12',
    data: [
        {
            "type": "chart",
            "subtype": "chartModule",
            "studioDevClasses": "d-block",
            "properties": {
              "name": "",
              "label": "Chart",
              "chartType": "bar",
              "width": "715px",
              "height": "357px",
              "visibility": true,
            },
            "subDataArray": []
          }
    ],
    children: []
}