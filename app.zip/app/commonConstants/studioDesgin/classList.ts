export let classListBlock = {
  "container": [
    {
      "label": "text-start",
      "value": "text-start"
    },
    {
      "label": "text-sm-start",
      "value": "text-sm-start"
    },
    {
      "label": "text-md-start",
      "value": "text-md-start"
    },
    {
      "label": "text-lg-start",
      "value": "text-lg-start"
    },
    {
      "label": "text-xl-start",
      "value": "text-xl-start"
    },
    {
      "label": "text-center",
      "value": "text-center"
    },
    {
      "label": "text-end",
      "value": "text-end"
    },
    {
      "label": "label-left",
      "value": "label-left"
    },
    {
      "label": "label-right",
      "value": "label-right"
    },
    {
      "label": "label-top-left",
      "value": "label-top-left"
    },
    {
      "label": "label-top-right",
      "value": "label-top-right"
    },
    {
      "label": "label-top-center",
      "value": "label-top-center"
    },
    {
      "label": "label-off",
      "value": "label-off"
    },
    {
      "label": "label-on",
      "value": "label-on"
    }
  ],
  "row": {
    'globelClasses': [{
      "label": "text-start",
      "value": "text-start",
    },
    {
      "label": "text-sm-start",
      "value": "text-sm-start"
    },
    {
      "label": "text-md-start",
      "value": "text-md-start"
    },
    {
      "label": "text-lg-start",
      "value": "text-lg-start"
    },
    {
      "label": "text-xl-start",
      "value": "text-xl-start"
    },
    {
      "label": "text-center",
      "value": "text-center",

    },
    {
      "label": "text-end",
      "value": "text-end"
    },
    {
      "label": "label-left",
      "value": "label-left"
    },
    {
      "label": "label-right",
      "value": "label-right"
    },
    {
      "label": "label-top-left",
      "value": "label-top-left"
    },
    {
      "label": "label-top-right",
      "value": "label-top-right"
    },
    {
      "label": "label-top-center",
      "value": "label-top-center"
    },
    {
      "label": "label-off",
      "value": "label-off"
    },
    {
      "label": "label-on",
      "value": "label-on"
    },
    // Background color add
    {
      "label": "bg-secondary",
      "value": "bg-secondary"
    },
    {
      "label": "bg-danger",
      "value": "bg-danger"
    },
    {
      "label": "bg-success",
      "value": "bg-success"
    },
    {
      "label": "bg-info",
      "value": "bg-info"
    },
    {
      "label": "bg-warning",
      "value": "bg-warning"
    },
    {
      "label": "bg-light",
      "value": "bg-light"
    },
    {
      "label": "bg-dark",
      "value": "bg-dark"
    },
    {
      "label": "justify-content-center",
      "value": "justify-content-center"
    },



    ],

  },
  "input": {
    'globelClasses': [
      {
        "label": "text-primary",
        "value": "text-primary"
      },
      {
        "label": "text-secondary",
        "value": "text-secondary"
      },
      {
        "label": "text-success",
        "value": "text-success"
      },
      {
        "label": "text-danger",
        "value": "text-danger"
      },
      {
        "label": "text-warning",
        "value": "text-warning"
      },
      {
        "label": "text-info",
        "value": "text-info"
      },
      {
        "label": "text-light bg-dark",
        "value": "text-light bg-dark"
      },
      {
        "label": "text-dark",
        "value": "text-dark"
      },
      {
        "label": "text-muted",
        "value": "text-muted"
      },
      {
        "label": "text-white bg-dark",
        "value": "text-white bg-dark"
      },
      {
        "label": "font-weight-bold",
        "value": "font-weight-bold",
      },
      {
        "label": "font-weight-normal",
        "value": "font-weight-normal",
      },
      {
        "label": "font-weight-light",
        "value": "font-weight-light",
      },
      {
        "label": "font-italic",
        "value": "font-italic",
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-wrap",
        "value": "text-wrap"
      },
      {
        "label": "fs-1",
        "value": "fs-1"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },
      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "labelElem",
        "value": "labelElem"
      },
      {
        "label": "required",
        "value": "required",
      }
    ],
    // label
    'labelClass': [
      {
        "label": "inputlabel_0",
        "value": "inputlabel_0"
      },
      {
        "label": "inputlabel_60",
        "value": "inputlabel_60"
      },
      {
        "label": "inputlabel_90",
        "value": "inputlabel_90"
      },
      {
        "label": "inputlabel_120",
        "value": "inputlabel_120"
      },
      {
        "label": "inputlabel_150",
        "value": "inputlabel_150"
      },
      {
        "label": "inputlabel_180",
        "value": "inputlabel_180"
      },
      {
        "label": "inputlabel_210",
        "value": "inputlabel_210"
      },
      {
        "label": "inputlabel_240",
        "value": "inputlabel_240"
      },
      {
        "label": "inputlabel_280",
        "value": "inputlabel_280"
      },
      {
        "label": "inputlabel_300",
        "value": "inputlabel_300"
      },
      {
        "label": "inputlabel_350",
        "value": "inputlabel_350"
      },
      {
        "label": "inputlabel_400",
        "value": "inputlabel_400"
      },
      {
        "label": "inputlabel_450",
        "value": "inputlabel_450"
      },
      {
        "label": "inputlabel_500",
        "value": "inputlabel_500"
      },
      {
        "label": "text-primary",
        "value": "text-primary"
      },
      {
        "label": "text-secondary",
        "value": "text-secondary"
      },
      {
        "label": "text-success",
        "value": "text-success"
      },
      {
        "label": "text-danger",
        "value": "text-danger"
      },
      {
        "label": "text-warning",
        "value": "text-warning"
      },
      {
        "label": "text-info",
        "value": "text-info"
      },
      {
        "label": "text-light bg-dark",
        "value": "text-light bg-dark"
      },
      {
        "label": "text-dark",
        "value": "text-dark"
      },
      {
        "label": "text-muted",
        "value": "text-muted"
      },
      {
        "label": "text-white bg-dark",
        "value": "text-white bg-dark"
      },
      {
        "label": "font-weight-bold",
        "value": "font-weight-bold",
      },
      {
        "label": "font-weight-normal",
        "value": "font-weight-normal",
      },
      {
        "label": "font-weight-light",
        "value": "font-weight-light",
      },
      {
        "label": "font-italic",
        "value": "font-italic",
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-wrap",
        "value": "text-wrap"
      },
      {
        "label": "fs-1",
        "value": "fs-1"
      },

    ],
    "text": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },

    ],
    "password": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "form-control-lg",
        "value": "form-control-lg"
      },
      {
        "label": "rounded-0",
        "value": "rounded-0"
      }


    ],
    "phone": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "form-control-lg",
        "value": "form-control-lg"
      },
      {
        "label": "rounded-0",
        "value": "rounded-0"
      }


    ],
    "number": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "form-control-lg",
        "value": "form-control-lg"
      },
      {
        "label": "rounded-0",
        "value": "rounded-0"
      }

    ],
    "amount": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "primeng-lg",
        "value": " primeng-lg"
      },
      {
        "label": " primeng-sm",
        "value": " primeng-sm"
      },
      {
        "label": "primeng-rounded",
        "value": "primeng-rounded"
      },
      {
        "label": "primeng-rounded-0",
        "value": "primeng-rounded-0"
      },
      {
        "label": "primeng-rounded-1",
        "value": "primeng-rounded-1"
      }
    ],
    "email": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "form-control-lg",
        "value": "form-control-lg"
      },
      {
        "label": "rounded-0",
        "value": "rounded-0"
      }
    ],

    "textarea": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "form-control-lg",
        "value": "form-control-lg"
      },
      {
        "label": "rounded-0",
        "value": "rounded-0"
      }
    ],

    "select": [
      {
        "label": "form-select-lg",
        "value": "form-select-lg"
      },
      {
        "label": "form-select-sm",
        "value": "form-select-sm"
      },
      {
        "label": "rounded-0",
        "value": "rounded-0"
      }
    ],

    "checkbox": [

    ],

    "radio": [

    ],
    "button": [
      {
        "label": "dropdown-toggle",
        "value": "dropdown-toggle"
      },
      {
        "label": "btn-lg",
        "value": "btn-lg"
      },
      {
        "label": "btn-sm",
        "value": "btn-sm"
      },
      {
        "label": "rounded-0",
        "value": "rounded-0"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "button-hover",
        "value": "btnArea"
      },
    ]

  },
  "column": {
    'globelClasses': [
      {
        "label": "col-md-1",
        "value": "col-md-1"
      },
      {
        "label": "col-md-2",
        "value": "col-md-2"
      },
      {
        "label": "col-md-3",
        "value": "col-md-3"
      },
      {
        "label": "col-md-4",
        "value": "col-md-4"
      },
      {
        "label": "col-md-5",
        "value": "col-md-5"
      },
      {
        "label": "col-md-6",
        "value": "col-md-6"
      },
      {
        "label": "col-md-7",
        "value": "col-md-7"
      },
      {
        "label": "col-md-8",
        "value": "col-md-8"
      },
      {
        "label": "col-md-9",
        "value": "col-md-9"
      },
      {
        "label": "col-md-10",
        "value": "col-md-10"
      },
      {
        "label": "col-md-11",
        "value": "col-md-11"
      },
      {
        "label": "col-md-12",
        "value": "col-md-12"
      },
      {
        "label": "col-lg-1",
        "value": "col-lg-1"
      },
      {
        "label": "col-lg-2",
        "value": "col-lg-2"
      },
      {
        "label": "col-lg-3",
        "value": "col-lg-3"
      },
      {
        "label": "col-lg-4",
        "value": "col-lg-4"
      },
      {
        "label": "col-lg-5",
        "value": "col-lg-5"
      },
      {
        "label": "col-lg-6",
        "value": "col-lg-6"
      },
      {
        "label": "col-lg-7",
        "value": "col-lg-7"
      },
      {
        "label": "col-lg-8",
        "value": "col-lg-8"
      },
      {
        "label": "col-lg-9",
        "value": "col-lg-9"
      },
      {
        "label": "col-lg-10",
        "value": "col-lg-10"
      },
      {
        "label": "col-lg-11",
        "value": "col-lg-11"
      },
      {
        "label": "col-lg-12",
        "value": "col-lg-12"
      },
      {
        "label": "col-xl-1",
        "value": "col-xl-1"
      },
      {
        "label": "col-xl-2",
        "value": "col-xl-2"
      },
      {
        "label": "col-xl-3",
        "value": "col-xl-3"
      },
      {
        "label": "col-xl-4",
        "value": "col-xl-4"
      },
      {
        "label": "col-xl-5",
        "value": "col-xl-5"
      },
      {
        "label": "col-xl-6",
        "value": "col-xl-6"
      },
      {
        "label": "col-xl-7",
        "value": "col-xl-7"
      },
      {
        "label": "col-xl-8",
        "value": "col-xl-8"
      },
      {
        "label": "col-xl-9",
        "value": "col-xl-9"
      },
      {
        "label": "col-xl-10",
        "value": "col-xl-10"
      },
      {
        "label": "col-xl-11",
        "value": "col-xl-11"
      },
      {
        "label": "col-xl-12",
        "value": "col-xl-12"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "offset-1",
        "value": "offset-1"
      },
      {
        "label": "offset-2",
        "value": "offset-2"
      },
      {
        "label": "offset-3",
        "value": "offset-3"
      },
      {
        "label": "offset-4",
        "value": "offset-4"
      },
      {
        "label": "offset-5",
        "value": "offset-5"
      },
      {
        "label": "offset-6",
        "value": "offset-6"
      },
      {
        "label": "offset-sm-1",
        "value": "offset-sm-1"
      },
      {
        "label": "offset-sm-2",
        "value": "offset-sm-2"
      },
      {
        "label": "offset-sm-3",
        "value": "offset-sm-3"
      },
      {
        "label": "offset-sm-4",
        "value": "offset-sm-4"
      },
      {
        "label": "offset-sm-5",
        "value": "offset-sm-5"
      },
      {
        "label": "offset-sm-6",
        "value": "offset-sm-6"
      },
      {
        "label": "offset-md-1",
        "value": "offset-md-1"
      },
      {
        "label": "offset-md-2",
        "value": "offset-md-2"
      },
      {
        "label": "offset-md-3",
        "value": "offset-md-3"
      },
      {
        "label": "offset-md-4",
        "value": "offset-md-4"
      },
      {
        "label": "offset-md-5",
        "value": "offset-md-5"
      },
      {
        "label": "offset-md-6",
        "value": "offset-md-6"
      },
      {
        "label": "offset-lg-1",
        "value": "offset-lg-1"
      },
      {
        "label": "offset-lg-2",
        "value": "offset-lg-2"
      },
      {
        "label": "offset-lg-3",
        "value": "offset-lg-3"
      },
      {
        "label": "offset-lg-4",
        "value": "offset-lg-4"
      },
      {
        "label": "offset-lg-5",
        "value": "offset-lg-5"
      },
      {
        "label": "offset-lg-6",
        "value": "offset-lg-6"
      },

    ],
    'elementClass': [
      {
        "label": "col-auto",
        "value": "col-auto"
      },
      {
        "label": "col",
        "value": "col"
      },
      {
        "label": "col-1",
        "value": "col-1"
      },
      {
        "label": "col-2",
        "value": "col-2"
      },
      {
        "label": "col-3",
        "value": "col-3"
      },
      {
        "label": "col-4",
        "value": "col-4"
      },
      {
        "label": "col-5",
        "value": "col-5"
      },
      {
        "label": "col-6",
        "value": "col-6"
      },
      {
        "label": "col-7",
        "value": "col-7"
      },
      {
        "label": "col-8",
        "value": "col-8"
      },
      {
        "label": "col-9",
        "value": "col-9"
      },
      {
        "label": "col-10",
        "value": "col-10"
      },
      {
        "label": "col-11",
        "value": "col-11"
      },
      {
        "label": "col-12",
        "value": "col-12"
      },
      {
        "label": "offset-1",
        "value": "offset-1"
      },
      {
        "label": "offset-2",
        "value": "offset-2"
      },
      {
        "label": "offset-3",
        "value": "offset-3"
      },
      {
        "label": "offset-4",
        "value": "offset-4"
      },
      {
        "label": "offset-5",
        "value": "offset-5"
      },
      {
        "label": "offset-6",
        "value": "offset-6"
      },
    ],
  },

  "customControl": {

    "text": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },

      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      }
    ],
    // label
    'label': [
      {
        "label": "inputlabel_0",
        "value": "inputlabel_0"
      },
      {
        "label": "inputlabel_60",
        "value": "inputlabel_60"
      },
      {
        "label": "inputlabel_90",
        "value": "inputlabel_90"
      },
      {
        "label": "inputlabel_120",
        "value": "inputlabel_120"
      },
      {
        "label": "inputlabel_150",
        "value": "inputlabel_150"
      },
      {
        "label": "inputlabel_180",
        "value": "inputlabel_180"
      },
      {
        "label": "inputlabel_210",
        "value": "inputlabel_210"
      },
      {
        "label": "inputlabel_240",
        "value": "inputlabel_240"
      },
      {
        "label": "inputlabel_280",
        "value": "inputlabel_280"
      },
      {
        "label": "inputlabel_300",
        "value": "inputlabel_300"
      },
      {
        "label": "inputlabel_350",
        "value": "inputlabel_350"
      },
      {
        "label": "inputlabel_400",
        "value": "inputlabel_400"
      },
      {
        "label": "inputlabel_450",
        "value": "inputlabel_450"
      },
      {
        "label": "inputlabel_500",
        "value": "inputlabel_500"
      },
      {
        "label": "text-primary",
        "value": "text-primary",
      },
      {
        "label": "text-secondary",
        "value": "text-secondary",
      },
      {
        "label": "text-success",
        "value": "text-success",
      },
      {
        "label": "text-danger",
        "value": "text-danger",
      },
      {
        "label": "text-warning",
        "value": "text-warning",
      },
      {
        "label": "text-info",
        "value": "text-info",
      },
      {
        "label": "text-light",
        "value": "text-light",
      },
      {
        "label": "text-dark",
        "value": "text-dark",
      },
      {
        "label": "text-muted",
        "value": "text-muted",
      },
      {
        "label": "text-white",
        "value": "text-white",
      }

    ],

    //icon color add
    "icon": [
      {
        "label": "text-primary",
        "value": "text-primary",
      },
      {
        "label": "text-secondary",
        "value": "text-secondary",
      },
      {
        "label": "text-success",
        "value": "text-success",
      },
      {
        "label": "text-danger",
        "value": "text-danger",
      },
      {
        "label": "text-warning",
        "value": "text-warning",
      },
      {
        "label": "text-info",
        "value": "text-info",
      },
      {
        "label": "text-light",
        "value": "text-light",
      },
      {
        "label": "text-dark",
        "value": "text-dark",
      },
      {
        "label": "text-muted",
        "value": "text-muted",
      },
      {
        "label": "text-white",
        "value": "text-white",
      }
    ],

    "headings": [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "text-primary",
        "value": "text-primary",
      },
      {
        "label": "text-secondary",
        "value": "text-secondary",
      },
      {
        "label": "text-success",
        "value": "text-success",
      },
      {
        "label": "text-danger",
        "value": "text-danger",
      },
      {
        "label": "text-warning",
        "value": "text-warning",
      },
      {
        "label": "text-info",
        "value": "text-info",
      },
      {
        "label": "text-light",
        "value": "text-light",
      },
      {
        "label": "text-dark",
        "value": "text-dark",
      },
      {
        "label": "text-muted",
        "value": "text-muted",
      },
      {
        "label": "text-white",
        "value": "text-white",
      },
      {
        "label": "HoverWithTitle",
        "value": "title"
      },

    ],
    "img": [],
    // label
    'labelClass': [
      {
        "label": "inputlabel_0",
        "value": "inputlabel_0"
      },
      {
        "label": "inputlabel_60",
        "value": "inputlabel_60"
      },
      {
        "label": "inputlabel_90",
        "value": "inputlabel_90"
      },
      {
        "label": "inputlabel_120",
        "value": "inputlabel_120"
      },
      {
        "label": "inputlabel_150",
        "value": "inputlabel_150"
      },
      {
        "label": "inputlabel_180",
        "value": "inputlabel_180"
      },
      {
        "label": "inputlabel_210",
        "value": "inputlabel_210"
      },
      {
        "label": "inputlabel_240",
        "value": "inputlabel_240"
      },
      {
        "label": "inputlabel_280",
        "value": "inputlabel_280"
      },
      {
        "label": "inputlabel_300",
        "value": "inputlabel_300"
      },
      {
        "label": "inputlabel_350",
        "value": "inputlabel_350"
      },
      {
        "label": "inputlabel_400",
        "value": "inputlabel_400"
      },
      {
        "label": "inputlabel_450",
        "value": "inputlabel_450"
      },
      {
        "label": "inputlabel_500",
        "value": "inputlabel_500"
      },
      {
        "label": "text-primary",
        "value": "text-primary"
      },
      {
        "label": "text-secondary",
        "value": "text-secondary"
      },
      {
        "label": "text-success",
        "value": "text-success"
      },
      {
        "label": "text-danger",
        "value": "text-danger"
      },
      {
        "label": "text-warning",
        "value": "text-warning"
      },
      {
        "label": "text-info",
        "value": "text-info"
      },
      {
        "label": "text-light bg-dark",
        "value": "text-light bg-dark"
      },
      {
        "label": "text-dark",
        "value": "text-dark"
      },
      {
        "label": "text-muted",
        "value": "text-muted"
      },
      {
        "label": "text-white bg-dark",
        "value": "text-white bg-dark"
      },
      {
        "label": "font-weight-bold",
        "value": "font-weight-bold",
      },
      {
        "label": "font-weight-normal",
        "value": "font-weight-normal",
      },
      {
        "label": "font-weight-light",
        "value": "font-weight-light",
      },
      {
        "label": "font-italic",
        "value": "font-italic",
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-wrap",
        "value": "text-wrap"
      },
      {
        "label": "fs-1",
        "value": "fs-1"
      },

    ],
    "phone": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },

    ],
    "number": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },

    ],
    "textarea": [
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
    ],

    "select": [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      }
    ],

    "checkbox": [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "form-inline",
        "value": "form-inline"
      },
      {
        "label": "align-items-start",
        "value": "align-items-start"
      }
    ],

    "radio": [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "form-inline",
        "value": "form-inline"
      },
      {
        "label": "align-items-start",
        "value": "align-items-start"
      }
    ],
    "button": [
      {
        "label": "dropdown-toggle",
        "value": "dropdown-toggle"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "button-hover",
        "value": "btnArea"
      },
    ],
    "animationCss": [
      {
        "label": "bounce",
        "value": "bounce",
      },
      {
        "label": "flash",
        "value": "flash",
      },
      {
        "label": "pulse",
        "value": "pulse",
      },

      {
        "label": "rubberBand",
        "value": "rubberBand",
      },
      {
        "label": "shake",
        "value": "shake",
      },
      {
        "label": "headShake",
        "value": "headShake",
      },
      {
        "label": "swing",
        "value": "swing",
      },
      {
        "label": "tada",
        "value": "tada",
      },
      {
        "label": "wobble",
        "value": "wobble",
      },
      {
        "label": "jello",
        "value": "jello",
      },
      {
        "label": "jackInTheBox",
        "value": "jackInTheBox",
      },
      {
        "label": "heartBeat",
        "value": "heartBeat",
      },
      {
        "label": "bounceIn",
        "value": "bounceIn",
      },
      {
        "label": "bounceInDown",
        "value": "bounceInDown",
      },
      {
        "label": "bounceInLeft",
        "value": "bounceInLeft",
      },
      {
        "label": "bounceInRight",
        "value": "bounceInRight",
      },
      {
        "label": "bounceInUp",
        "value": "bounceInUp",
      },
      {
        "label": "bounceOut",
        "value": "bounceOut",
      },
      {
        "label": "bounceOutDown",
        "value": "bounceOutDown",
      },
      {
        "label": "bounceOutLeft",
        "value": "bounceOutLeft",
      },
      {
        "label": "bounceOutRight",
        "value": "bounceOutRight",
      },
      {
        "label": "bounceOutUp",
        "value": "bounceOutUp",
      },
      {
        "label": "fadeIn",
        "value": "fadeIn",
      },
      {
        "label": "fadeInDown",
        "value": "fadeInDown",
      },
      {
        "label": "fadeInDownBig",
        "value": "fadeInDownBig",
      },
      {
        "label": "fadeInLeft",
        "value": "fadeInLeft",
      },
      {
        "label": "fadeInLeftBig",
        "value": "fadeInLeftBig",
      },
      {
        "label": "fadeInRight",
        "value": "fadeInRight",
      },
      {
        "label": "fadeInRightBig",
        "value": "fadeInRightBig",
      },
      {
        "label": "fadeInUp",
        "value": "fadeInUp",
      },
      {
        "label": "fadeInUpBig",
        "value": "fadeInUpBig",
      },
      {
        "label": "fadeOut",
        "value": "fadeOut",
      },
      {
        "label": "fadeOutDown",
        "value": "fadeOutDown",
      },
      {
        "label": "fadeOutDownBig",
        "value": "fadeOutDownBig",
      },
      {
        "label": "fadeOutLeft",
        "value": "fadeOutLeft",
      },
      {
        "label": "fadeOutLeftBig",
        "value": "fadeOutLeftBig",
      },
      {
        "label": "fadeOutRight",
        "value": "fadeOutRight",
      },
      {
        "label": "fadeOutRightBig",
        "value": "fadeOutRightBig",
      },
      {
        "label": "fadeOutUp",
        "value": "fadeOutUp",
      },
      {
        "label": "fadeOutUpBig",
        "value": "fadeOutUpBig",
      },
      {
        "label": "rotateIn",
        "value": "rotateIn",
      },
      {
        "label": "rotateInDownLeft",
        "value": "rotateInDownLeft",
      },
      {
        "label": "rotateInDownRight",
        "value": "rotateInDownRight",
      },
      {
        "label": "rotateInUpLeft",
        "value": "rotateInUpLeft",
      },
      {
        "label": "rotateInUpRight",
        "value": "rotateInUpRight",
      },
      {
        "label": "rotateOut",
        "value": "rotateOut",
      },
      {
        "label": "rotateOutDownLeft",
        "value": "rotateOutDownLeft",
      },
      {
        "label": "rotateOutDownRight",
        "value": "rotateOutDownRight",
      },
      {
        "label": "rotateOutUpLeft",
        "value": "rotateOutUpLeft",
      },
      {
        "label": "rotateOutUpRight",
        "value": "rotateOutUpRight",
      },
      {
        "label": "hinge",
        "value": "hinge",
      }, {
        "label": "simple-shape",
        "value": "simple-shape"
      },
      {
        "label": "textAnim",
        "value": "textAnim"
      },
      {
        "label": "animate-charcter",
        "value": "animate-charcter"
      },
      {
        "label": "focusEffect",
        "value": "focusEffect"
      },
      {
        "label": "comingsoon-loading",
        "value": "comingsoon-loading"
      },
      {
        "label": "rotateAnimation",
        "value": "rotateAnimation"
      },
      {
        "label": "zoomInOutAnimation",
        "value": "zoomInOutAnimation"
      },
      {
        "label": "upDownAnimation",
        "value": "upDownAnimation"
      },
      {
        "label": "elemLeftRightAnimation",
        "value": "elemLeftRightAnimation"
      }
    ],
  },

  "paragraph": {
    'globelClasses': [{}],

    // element Parent div css
    'elementClass': [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "HoverWithTitle",
        "value": "title"
      },
      {
        "label": "text-lowercase",
        "value": "text-lowercase"
      },
      {
        "label": "text-uppercase",
        "value": "text-uppercase"
      },
      {
        "label": "text-capitalize",
        "value": "text-capitalize"
      },
      {
        "label": "fs-1",
        "value": "fs-1"
      },
      {
        "label": "fs-2",
        "value": "fs-2"
      },
      {
        "label": "fs-3",
        "value": "fs-3"
      },
      {
        "label": "fs-4",
        "value": "fs-4"
      },
      {
        "label": "fs-5",
        "value": "fs-5"
      },
      {
        "label": "fs-6",
        "value": "fs-6"
      },
      {
        "label": "fw-bold",
        "value": "fw-bold"
      },
      {
        "label": "fw-bolder",
        "value": "fw-bolder"
      },
      {
        "label": "fw-normal",
        "value": "fw-normal"
      },
      {
        "label": "fw-light",
        "value": "fw-light"
      },
      {
        "label": "fw-lighter",
        "value": "fw-lighter"
      },
      {
        "label": "fst-italic",
        "value": "fst-italic"
      },
      {
        "label": "fst-normal",
        "value": "fst-normal"
      },
      {
        "label": "lh-1",
        "value": "lh-1"
      },
      {
        "label": "lh-sm",
        "value": "lh-sm"
      },
      {
        "label": "lh-base",
        "value": "lh-base"
      },
      {
        "label": "lh-lg",
        "value": "lh-lg"
      },
      {
        "label": "text-decoration-underline",
        "value": "text-decoration-underline"
      },
      {
        "label": "text-decoration-line-through",
        "value": "text-decoration-line-through"
      },
      {
        "label": "text-decoration-none",
        "value": "text-decoration-none"
      }
    ],
    "animationCss": [
      {
        "label": "bounce",
        "value": "bounce",
      },
      {
        "label": "flash",
        "value": "flash",
      },
      {
        "label": "pulse",
        "value": "pulse",
      },

      {
        "label": "rubberBand",
        "value": "rubberBand",
      },
      {
        "label": "shake",
        "value": "shake",
      },
      {
        "label": "headShake",
        "value": "headShake",
      },
      {
        "label": "swing",
        "value": "swing",
      },
      {
        "label": "tada",
        "value": "tada",
      },
      {
        "label": "wobble",
        "value": "wobble",
      },
      {
        "label": "jello",
        "value": "jello",
      },
      {
        "label": "jackInTheBox",
        "value": "jackInTheBox",
      },
      {
        "label": "heartBeat",
        "value": "heartBeat",
      },
      {
        "label": "bounceIn",
        "value": "bounceIn",
      },
      {
        "label": "bounceInDown",
        "value": "bounceInDown",
      },
      {
        "label": "bounceInLeft",
        "value": "bounceInLeft",
      },
      {
        "label": "bounceInRight",
        "value": "bounceInRight",
      },
      {
        "label": "bounceInUp",
        "value": "bounceInUp",
      },
      {
        "label": "bounceOut",
        "value": "bounceOut",
      },
      {
        "label": "bounceOutDown",
        "value": "bounceOutDown",
      },
      {
        "label": "bounceOutLeft",
        "value": "bounceOutLeft",
      },
      {
        "label": "bounceOutRight",
        "value": "bounceOutRight",
      },
      {
        "label": "bounceOutUp",
        "value": "bounceOutUp",
      },
      {
        "label": "fadeIn",
        "value": "fadeIn",
      },
      {
        "label": "fadeInDown",
        "value": "fadeInDown",
      },
      {
        "label": "fadeInDownBig",
        "value": "fadeInDownBig",
      },
      {
        "label": "fadeInLeft",
        "value": "fadeInLeft",
      },
      {
        "label": "fadeInLeftBig",
        "value": "fadeInLeftBig",
      },
      {
        "label": "fadeInRight",
        "value": "fadeInRight",
      },
      {
        "label": "fadeInRightBig",
        "value": "fadeInRightBig",
      },
      {
        "label": "fadeInUp",
        "value": "fadeInUp",
      },
      {
        "label": "fadeInUpBig",
        "value": "fadeInUpBig",
      },
      {
        "label": "fadeOut",
        "value": "fadeOut",
      },
      {
        "label": "fadeOutDown",
        "value": "fadeOutDown",
      },
      {
        "label": "fadeOutDownBig",
        "value": "fadeOutDownBig",
      },
      {
        "label": "fadeOutLeft",
        "value": "fadeOutLeft",
      },
      {
        "label": "fadeOutLeftBig",
        "value": "fadeOutLeftBig",
      },
      {
        "label": "fadeOutRight",
        "value": "fadeOutRight",
      },
      {
        "label": "fadeOutRightBig",
        "value": "fadeOutRightBig",
      },
      {
        "label": "fadeOutUp",
        "value": "fadeOutUp",
      },
      {
        "label": "fadeOutUpBig",
        "value": "fadeOutUpBig",
      },
      {
        "label": "rotateIn",
        "value": "rotateIn",
      },
      {
        "label": "rotateInDownLeft",
        "value": "rotateInDownLeft",
      },
      {
        "label": "rotateInDownRight",
        "value": "rotateInDownRight",
      },
      {
        "label": "rotateInUpLeft",
        "value": "rotateInUpLeft",
      },
      {
        "label": "rotateInUpRight",
        "value": "rotateInUpRight",
      },
      {
        "label": "rotateOut",
        "value": "rotateOut",
      },
      {
        "label": "rotateOutDownLeft",
        "value": "rotateOutDownLeft",
      },
      {
        "label": "rotateOutDownRight",
        "value": "rotateOutDownRight",
      },
      {
        "label": "rotateOutUpLeft",
        "value": "rotateOutUpLeft",
      },
      {
        "label": "rotateOutUpRight",
        "value": "rotateOutUpRight",
      },
      {
        "label": "hinge",
        "value": "hinge",
      }, {
        "label": "simple-shape",
        "value": "simple-shape"
      },
      {
        "label": "textAnim",
        "value": "textAnim"
      },
      {
        "label": "animate-charcter",
        "value": "animate-charcter"
      },
      {
        "label": "focusEffect",
        "value": "focusEffect"
      },
      {
        "label": "comingsoon-loading",
        "value": "comingsoon-loading"
      },
      {
        "label": "rotateAnimation",
        "value": "rotateAnimation"
      },
      {
        "label": "zoomInOutAnimation",
        "value": "zoomInOutAnimation"
      },
      {
        "label": "upDownAnimation",
        "value": "upDownAnimation"
      },
      {
        "label": "elemLeftRightAnimation",
        "value": "elemLeftRightAnimation"
      }
    ],


  },
  "headings": {
    'globelClasses': [{}],

    // element Parent div css
    'elementClass': [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "HoverWithTitle",
        "value": "title"
      },
      {
        "label": "text-lowercase",
        "value": "text-lowercase"
      },
      {
        "label": "text-uppercase",
        "value": "text-uppercase"
      },
      {
        "label": "text-capitalize",
        "value": "text-capitalize"
      },
      {
        "label": "fs-1",
        "value": "fs-1"
      },
      {
        "label": "fs-2",
        "value": "fs-2"
      },
      {
        "label": "fs-3",
        "value": "fs-3"
      },
      {
        "label": "fs-4",
        "value": "fs-4"
      },
      {
        "label": "fs-5",
        "value": "fs-5"
      },
      {
        "label": "fs-6",
        "value": "fs-6"
      },
      {
        "label": "fw-bold",
        "value": "fw-bold"
      },
      {
        "label": "fw-bolder",
        "value": "fw-bolder"
      },
      {
        "label": "fw-normal",
        "value": "fw-normal"
      },
      {
        "label": "fw-light",
        "value": "fw-light"
      },
      {
        "label": "fw-lighter",
        "value": "fw-lighter"
      },
      {
        "label": "fst-italic",
        "value": "fst-italic"
      },
      {
        "label": "fst-normal",
        "value": "fst-normal"
      },
      {
        "label": "lh-1",
        "value": "lh-1"
      },
      {
        "label": "lh-sm",
        "value": "lh-sm"
      },
      {
        "label": "lh-base",
        "value": "lh-base"
      },
      {
        "label": "lh-lg",
        "value": "lh-lg"
      },
      {
        "label": "text-decoration-underline",
        "value": "text-decoration-underline"
      },
      {
        "label": "text-decoration-line-through",
        "value": "text-decoration-line-through"
      },
      {
        "label": "text-decoration-none",
        "value": "text-decoration-none"
      }
    ],

    "animationCss": [
      {
        "label": "bounce",
        "value": "bounce",
      },
      {
        "label": "flash",
        "value": "flash",
      },
      {
        "label": "pulse",
        "value": "pulse",
      },

      {
        "label": "rubberBand",
        "value": "rubberBand",
      },
      {
        "label": "shake",
        "value": "shake",
      },
      {
        "label": "headShake",
        "value": "headShake",
      },
      {
        "label": "swing",
        "value": "swing",
      },
      {
        "label": "tada",
        "value": "tada",
      },
      {
        "label": "wobble",
        "value": "wobble",
      },
      {
        "label": "jello",
        "value": "jello",
      },
      {
        "label": "jackInTheBox",
        "value": "jackInTheBox",
      },
      {
        "label": "heartBeat",
        "value": "heartBeat",
      },
      {
        "label": "bounceIn",
        "value": "bounceIn",
      },
      {
        "label": "bounceInDown",
        "value": "bounceInDown",
      },
      {
        "label": "bounceInLeft",
        "value": "bounceInLeft",
      },
      {
        "label": "bounceInRight",
        "value": "bounceInRight",
      },
      {
        "label": "bounceInUp",
        "value": "bounceInUp",
      },
      {
        "label": "bounceOut",
        "value": "bounceOut",
      },
      {
        "label": "bounceOutDown",
        "value": "bounceOutDown",
      },
      {
        "label": "bounceOutLeft",
        "value": "bounceOutLeft",
      },
      {
        "label": "bounceOutRight",
        "value": "bounceOutRight",
      },
      {
        "label": "bounceOutUp",
        "value": "bounceOutUp",
      },
      {
        "label": "fadeIn",
        "value": "fadeIn",
      },
      {
        "label": "fadeInDown",
        "value": "fadeInDown",
      },
      {
        "label": "fadeInDownBig",
        "value": "fadeInDownBig",
      },
      {
        "label": "fadeInLeft",
        "value": "fadeInLeft",
      },
      {
        "label": "fadeInLeftBig",
        "value": "fadeInLeftBig",
      },
      {
        "label": "fadeInRight",
        "value": "fadeInRight",
      },
      {
        "label": "fadeInRightBig",
        "value": "fadeInRightBig",
      },
      {
        "label": "fadeInUp",
        "value": "fadeInUp",
      },
      {
        "label": "fadeInUpBig",
        "value": "fadeInUpBig",
      },
      {
        "label": "fadeOut",
        "value": "fadeOut",
      },
      {
        "label": "fadeOutDown",
        "value": "fadeOutDown",
      },
      {
        "label": "fadeOutDownBig",
        "value": "fadeOutDownBig",
      },
      {
        "label": "fadeOutLeft",
        "value": "fadeOutLeft",
      },
      {
        "label": "fadeOutLeftBig",
        "value": "fadeOutLeftBig",
      },
      {
        "label": "fadeOutRight",
        "value": "fadeOutRight",
      },
      {
        "label": "fadeOutRightBig",
        "value": "fadeOutRightBig",
      },
      {
        "label": "fadeOutUp",
        "value": "fadeOutUp",
      },
      {
        "label": "fadeOutUpBig",
        "value": "fadeOutUpBig",
      },
      {
        "label": "rotateIn",
        "value": "rotateIn",
      },
      {
        "label": "rotateInDownLeft",
        "value": "rotateInDownLeft",
      },
      {
        "label": "rotateInDownRight",
        "value": "rotateInDownRight",
      },
      {
        "label": "rotateInUpLeft",
        "value": "rotateInUpLeft",
      },
      {
        "label": "rotateInUpRight",
        "value": "rotateInUpRight",
      },
      {
        "label": "rotateOut",
        "value": "rotateOut",
      },
      {
        "label": "rotateOutDownLeft",
        "value": "rotateOutDownLeft",
      },
      {
        "label": "rotateOutDownRight",
        "value": "rotateOutDownRight",
      },
      {
        "label": "rotateOutUpLeft",
        "value": "rotateOutUpLeft",
      },
      {
        "label": "rotateOutUpRight",
        "value": "rotateOutUpRight",
      },
      {
        "label": "hinge",
        "value": "hinge",
      }, {
        "label": "simple-shape",
        "value": "simple-shape"
      },
      {
        "label": "textAnim",
        "value": "textAnim"
      },
      {
        "label": "animate-charcter",
        "value": "animate-charcter"
      },
      {
        "label": "focusEffect",
        "value": "focusEffect"
      },
      {
        "label": "comingsoon-loading",
        "value": "comingsoon-loading"
      },
      {
        "label": "rotateAnimation",
        "value": "rotateAnimation"
      },
      {
        "label": "zoomInOutAnimation",
        "value": "zoomInOutAnimation"
      },
      {
        "label": "upDownAnimation",
        "value": "upDownAnimation"
      },
      {
        "label": "elemLeftRightAnimation",
        "value": "elemLeftRightAnimation"
      }
    ],


  },

  "fieldset": {
    'globelClasses': [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },

    ],


    "fieldset": [{
      "label": "text-primary",
      "value": "text-primary",
    },
    {
      "label": "text-secondary",
      "value": "text-secondary",
    },
    {
      "label": "text-success",
      "value": "text-success",
    },
    {
      "label": "text-danger",
      "value": "text-danger",
    },
    {
      "label": "text-warning",
      "value": "text-warning",
    },
    {
      "label": "text-info",
      "value": "text-info",
    },
    {
      "label": "text-light",
      "value": "text-light",
    },
    {
      "label": "text-dark",
      "value": "text-dark",
    },
    {
      "label": "text-muted",
      "value": "text-muted",
    },
    {
      "label": "text-white",
      "value": "text-white",
    }],
  },
  "sagPage": {
    'globelClasses': [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
    ]
  },

  "sagFormArea": {
    'globelClasses': [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },

    ],

  },
  "sagGridArea": {
    'globelClasses': [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },

    ],

  },
  "sagGrid": {
    'elementClass': [
      {
        "label": "Dark Theme",
        "value": "dark"
      },
      {
        "label": "Light Theme",
        "value": "light"
      },
      {
        "label": "Classic Theme",
        "value": "classic"
      },
      {
        "label": "Solarized Theme",
        "value": "gridDesignOne"
      },
      {
        "label": "Kimbie Theme",
        "value": "gridDesignTwo"
      },
      {
        "label": "Quite Theme",
        "value": "gridDesignThree"
      },
      {
        "label": "Search Theme",
        "value": "searchCtrl"
      },
      {
        "label": "Form Theme",
        "value": "outerBorder"
      },
    ]
  },
  "sagFooterArea": {
    'globelClasses': [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      },
      {
        "label": "footer-area-right",
        "value": "footer-area-right"
      },
      {
        "label": "footer-area-left",
        "value": "footer-area-left"
      }
    ],

  },

  "bootstrapPills": {
    "globelClasses": [{
      "label": "ml-auto",
      "value": "ml-auto"
    },
    {
      "label": "mr-auto",
      "value": "mr-auto"
    },
    {
      "label": "Dropdown RTL",
      "value": "dropzone_bot_right"
    },
    {
      "label": "Dropdown LTR",
      "value": "dropzone_bot_left"
    }],

    // element Parent div css
    'elementPrntClass': [{
      "label": "parent1",
      "value": "parent1"
    }],
    'bootpillBtn': [{
      "label": "btn-primary",
      "value": "btn-primary"
    },
    {
      "label": "btn-success",
      "value": "btn-success"
    },
    {
      "label": "btn-danger",
      "value": "btn-danger"
    },
    {
      "label": "btn-warning",
      "value": "btn-warning"
    },
    {
      "label": "btn-secondary",
      "value": "btn-secondary"
    },
    {
      "label": "btn-default",
      "value": "btn-default"
    },
    {
      "label": "btn-sm",
      "value": "btn-sm"
    },
    {
      "label": "text-primary",
      "value": "text-primary",
    },
    {
      "label": "text-secondary",
      "value": "text-secondary",
    },
    {
      "label": "text-success",
      "value": "text-success",
    },
    {
      "label": "text-danger",
      "value": "text-danger",
    },
    {
      "label": "text-warning",
      "value": "text-warning",
    },
    {
      "label": "text-info",
      "value": "text-info",
    },
    {
      "label": "text-light",
      "value": "text-light",
    },
    {
      "label": "text-dark",
      "value": "text-dark",
    },
    {
      "label": "text-muted",
      "value": "text-muted",
    },
    {
      "label": "text-white",
      "value": "text-white",
    }],
    'bootpillAnchor': [{
      "label": "btn-primary",
      "value": "btn-primary"
    },
    {
      "label": "btn-success",
      "value": "btn-success"
    },
    {
      "label": "btn-danger",
      "value": "btn-danger"
    },
    {
      "label": "btn-warning",
      "value": "btn-warning"
    },
    {
      "label": "btn-secondary",
      "value": "btn-secondary"
    },
    {
      "label": "btn-default",
      "value": "btn-default"
    },
    {
      "label": "btn-sm",
      "value": "btn-sm"
    }],
  },

  //menuBar
  "itemMenu": {
    "globelClasses": [
      /* {
        "label": "ml-auto",
        "value": "ml-auto"
      },
      {
        "label": "mr-auto",
        "value": "mr-auto"
      },
      {
        "label": "Dropdown RTL",
        "value": "dropzone_bot_right"
      },
      {
        "label": "Dropdown LTR",
        "value": "dropzone_bot_left"
      } */
      {
        "label": "bg-transparent",
        "value": "bg-transparent",
      },
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },

      {
        "label": "m-auto",
        "value": "m-auto"
      },
      {
        "label": "ms-auto",
        "value": "ms-auto"
      },
      {
        "label": "me-auto",
        "value": "me-auto"
      },

      {
        "label": "wi_160",
        "value": "min_width160"
      },
      {
        "label": "wi_180",
        "value": "min_width180"
      },
      {
        "label": "wi_200",
        "value": "min_width200"
      },
      {
        "label": "wi_220",
        "value": "min_width220"
      },
      {
        "label": "wi_240",
        "value": "min_width240"
      },
      {
        "label": "wi_260",
        "value": "min_width260"
      },
      {
        "label": "wi_280",
        "value": "min_width280"
      },
      {
        "label": "wi_300",
        "value": "min_width300"
      },
      {
        "label": "wi_320",
        "value": "min_width320"
      },
      {
        "label": "wi_340",
        "value": "min_width340"
      },
      {
        "label": "wi_360",
        "value": "min_width360"
      },
      {
        "label": "wi_380",
        "value": "min_width380"
      },
      {
        "label": "wi_400",
        "value": "min_width400"
      },
      {
        "label": "wi_420",
        "value": "min_width420"
      },
      {
        "label": "wi_440",
        "value": "min_width440"
      },
      {
        "label": "wi_460",
        "value": "min_width460"
      },
      {
        "label": "wi_480",
        "value": "min_width480"
      },
      {
        "label": "wi_500",
        "value": "min_width500"
      }
    ],


  },
  "menu": {
    "globelClasses": [
      {
        "label": "bg-transparent",
        "value": "bg-transparent",
      },
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      }
    ],


  },

  //leftMenu
  "leftmenu": {
    "globelClasses": [{
      "label": "ml-auto",
      "value": "ml-auto"
    },
    {
      "label": "mr-auto",
      "value": "mr-auto"
    },
    {
      "label": "Dropdown RTL",
      "value": "dropzone_bot_right"
    },
    {
      "label": "Dropdown LTR",
      "value": "dropzone_bot_left"
    }],

    // element Parent div css
    'elementPrntClass': [{
      "label": "parent1",
      "value": "parent1"
    }],
    'bootpillBtn': [{
      "label": "btn-primary",
      "value": "btn-primary"
    },
    {
      "label": "btn-success",
      "value": "btn-success"
    },
    {
      "label": "btn-danger",
      "value": "btn-danger"
    },
    {
      "label": "btn-warning",
      "value": "btn-warning"
    },
    {
      "label": "btn-secondary",
      "value": "btn-secondary"
    },
    {
      "label": "btn-default",
      "value": "btn-default"
    },
    {
      "label": "btn-sm",
      "value": "btn-sm"
    },
    {
      "label": "text-primary",
      "value": "text-primary",
    },
    {
      "label": "text-secondary",
      "value": "text-secondary",
    },
    {
      "label": "text-success",
      "value": "text-success",
    },
    {
      "label": "text-danger",
      "value": "text-danger",
    },
    {
      "label": "text-warning",
      "value": "text-warning",
    },
    {
      "label": "text-info",
      "value": "text-info",
    },
    {
      "label": "text-light",
      "value": "text-light",
    },
    {
      "label": "text-dark",
      "value": "text-dark",
    },
    {
      "label": "text-muted",
      "value": "text-muted",
    },
    {
      "label": "text-white",
      "value": "text-white",
    }],
    'bootpillAnchor': [{
      "label": "btn-primary",
      "value": "btn-primary"
    },
    {
      "label": "btn-success",
      "value": "btn-success"
    },
    {
      "label": "btn-danger",
      "value": "btn-danger"
    },
    {
      "label": "btn-warning",
      "value": "btn-warning"
    },
    {
      "label": "btn-secondary",
      "value": "btn-secondary"
    },
    {
      "label": "btn-default",
      "value": "btn-default"
    },
    {
      "label": "btn-sm",
      "value": "btn-sm"
    }],
  },

  //HtmlTag
  "htmlTag": {
    'elementClass': [
      {
        "label": "dropdown",
        "value": "dropdown"
      },
      {
        "label": "btn-group",
        "value": "btn-group"
      },
      {
        "label": "dropdown-center",
        "value": "dropdown-center"
      },
      {
        "label": "dropup",
        "value": "dropup"
      },
      {
        "label": "dropup-center",
        "value": "dropup-center"
      },
      {
        "label": "dropend",
        "value": "dropend"
      },
      {
        "label": "dropstart",
        "value": "dropstart"
      },
      {
        "label": "sticky-top",
        "value": "sticky-top"
      },
      {
        "label": "socialIconDesign1",
        "value": "socialIconDesign1"
      },
      {
        "label": "socialIconDesign2",
        "value": "socialIconDesign2"
      },
      {
        "label": "socialIconDesign3",
        "value": "socialIconDesign3"
      },
      {
        "label": "socialIconDesign4",
        "value": "socialIconDesign4"
      },
      {
        "label": "media",
        "value": "media"
      },
      {
        "label": "container-fluid",
        "value": "container-fluid"
      },
      {
        "label": "container",
        "value": "container"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },

      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "text-lowercase",
        "value": "text-lowercase"
      },
      {
        "label": "text-uppercase",
        "value": "text-uppercase"
      },
      {
        "label": "text-capitalize",
        "value": "text-capitalize"
      },
      {
        "label": "fs-1",
        "value": "fs-1"
      },
      {
        "label": "fs-2",
        "value": "fs-2"
      },
      {
        "label": "fs-3",
        "value": "fs-3"
      },
      {
        "label": "fs-4",
        "value": "fs-4"
      },
      {
        "label": "fs-5",
        "value": "fs-5"
      },
      {
        "label": "fs-6",
        "value": "fs-6"
      },
      {
        "label": "fw-bold",
        "value": "fw-bold"
      },
      {
        "label": "fw-bolder",
        "value": "fw-bolder"
      },
      {
        "label": "fw-normal",
        "value": "fw-normal"
      },
      {
        "label": "fw-light",
        "value": "fw-light"
      },
      {
        "label": "fw-lighter",
        "value": "fw-lighter"
      },
      {
        "label": "fst-italic",
        "value": "fst-italic"
      },
      {
        "label": "fst-normal",
        "value": "fst-normal"
      },
      {
        "label": "lh-1",
        "value": "lh-1"
      },
      {
        "label": "lh-sm",
        "value": "lh-sm"
      },
      {
        "label": "lh-base",
        "value": "lh-base"
      },
      {
        "label": "lh-lg",
        "value": "lh-lg"
      },
      {
        "label": "text-decoration-underline",
        "value": "text-decoration-underline"
      },
      {
        "label": "text-decoration-line-through",
        "value": "text-decoration-line-through"
      },
      {
        "label": "text-decoration-none",
        "value": "text-decoration-none"
      },
      {
        "label": "top",
        "value": "topToBottom"
      },
      {
        "label": "Bottom",
        "value": "bottomToTop"
      },
      {
        "label": "left",
        "value": "leftToRight"
      },
      {
        "label": "Right",
        "value": "rightToLeft"
      },

    ],
    "animationCss": [
      {
        "label": "bounce",
        "value": "bounce",
      },
      {
        "label": "flash",
        "value": "flash",
      },
      {
        "label": "pulse",
        "value": "pulse",
      },

      {
        "label": "rubberBand",
        "value": "rubberBand",
      },
      {
        "label": "shake",
        "value": "shake",
      },
      {
        "label": "headShake",
        "value": "headShake",
      },
      {
        "label": "swing",
        "value": "swing",
      },
      {
        "label": "tada",
        "value": "tada",
      },
      {
        "label": "wobble",
        "value": "wobble",
      },
      {
        "label": "jello",
        "value": "jello",
      },
      {
        "label": "jackInTheBox",
        "value": "jackInTheBox",
      },
      {
        "label": "heartBeat",
        "value": "heartBeat",
      },
      {
        "label": "bounceIn",
        "value": "bounceIn",
      },
      {
        "label": "bounceInDown",
        "value": "bounceInDown",
      },
      {
        "label": "bounceInLeft",
        "value": "bounceInLeft",
      },
      {
        "label": "bounceInRight",
        "value": "bounceInRight",
      },
      {
        "label": "bounceInUp",
        "value": "bounceInUp",
      },
      {
        "label": "bounceOut",
        "value": "bounceOut",
      },
      {
        "label": "bounceOutDown",
        "value": "bounceOutDown",
      },
      {
        "label": "bounceOutLeft",
        "value": "bounceOutLeft",
      },
      {
        "label": "bounceOutRight",
        "value": "bounceOutRight",
      },
      {
        "label": "bounceOutUp",
        "value": "bounceOutUp",
      },
      {
        "label": "fadeIn",
        "value": "fadeIn",
      },
      {
        "label": "fadeInDown",
        "value": "fadeInDown",
      },
      {
        "label": "fadeInDownBig",
        "value": "fadeInDownBig",
      },
      {
        "label": "fadeInLeft",
        "value": "fadeInLeft",
      },
      {
        "label": "fadeInLeftBig",
        "value": "fadeInLeftBig",
      },
      {
        "label": "fadeInRight",
        "value": "fadeInRight",
      },
      {
        "label": "fadeInRightBig",
        "value": "fadeInRightBig",
      },
      {
        "label": "fadeInUp",
        "value": "fadeInUp",
      },
      {
        "label": "fadeInUpBig",
        "value": "fadeInUpBig",
      },
      {
        "label": "fadeOut",
        "value": "fadeOut",
      },
      {
        "label": "fadeOutDown",
        "value": "fadeOutDown",
      },
      {
        "label": "fadeOutDownBig",
        "value": "fadeOutDownBig",
      },
      {
        "label": "fadeOutLeft",
        "value": "fadeOutLeft",
      },
      {
        "label": "fadeOutLeftBig",
        "value": "fadeOutLeftBig",
      },
      {
        "label": "fadeOutRight",
        "value": "fadeOutRight",
      },
      {
        "label": "fadeOutRightBig",
        "value": "fadeOutRightBig",
      },
      {
        "label": "fadeOutUp",
        "value": "fadeOutUp",
      },
      {
        "label": "fadeOutUpBig",
        "value": "fadeOutUpBig",
      },
      {
        "label": "rotateIn",
        "value": "rotateIn",
      },
      {
        "label": "rotateInDownLeft",
        "value": "rotateInDownLeft",
      },
      {
        "label": "rotateInDownRight",
        "value": "rotateInDownRight",
      },
      {
        "label": "rotateInUpLeft",
        "value": "rotateInUpLeft",
      },
      {
        "label": "rotateInUpRight",
        "value": "rotateInUpRight",
      },
      {
        "label": "rotateOut",
        "value": "rotateOut",
      },
      {
        "label": "rotateOutDownLeft",
        "value": "rotateOutDownLeft",
      },
      {
        "label": "rotateOutDownRight",
        "value": "rotateOutDownRight",
      },
      {
        "label": "rotateOutUpLeft",
        "value": "rotateOutUpLeft",
      },
      {
        "label": "rotateOutUpRight",
        "value": "rotateOutUpRight",
      },
      {
        "label": "hinge",
        "value": "hinge",
      }, {
        "label": "simple-shape",
        "value": "simple-shape"
      },
      {
        "label": "textAnim",
        "value": "textAnim"
      },
      {
        "label": "animate-charcter",
        "value": "animate-charcter"
      },
      {
        "label": "focusEffect",
        "value": "focusEffect"
      },
      {
        "label": "comingsoon-loading",
        "value": "comingsoon-loading"
      },
      {
        "label": "rotateAnimation",
        "value": "rotateAnimation"
      },
      {
        "label": "zoomInOutAnimation",
        "value": "zoomInOutAnimation"
      },
      {
        "label": "upDownAnimation",
        "value": "upDownAnimation"
      },
      {
        "label": "elemLeftRightAnimation",
        "value": "elemLeftRightAnimation"
      }
    ],
  },
  //fontIcon
  "fontIcon": {
    'fontIcon': [
      {
        "label": "bg-transparent",
        "value": "bg-transparent",
      },
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },
      {
        "label": "text-primary",
        "value": "text-primary",
      },
      {
        "label": "text-secondary",
        "value": "text-secondary",
      },
      {
        "label": "text-success",
        "value": "text-success",
      },
      {
        "label": "text-danger",
        "value": "text-danger",
      },
      {
        "label": "text-warning",
        "value": "text-warning",
      },
      {
        "label": "text-info",
        "value": "text-info",
      },
      {
        "label": "text-light",
        "value": "text-light",
      },
      {
        "label": "text-dark",
        "value": "text-dark",
      },
      {
        "label": "text-muted",
        "value": "text-muted",
      },
      {
        "label": "text-white",
        "value": "text-white",
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "container-fluid",
        "value": "container-fluid"
      },
      {
        "label": "container",
        "value": "container"
      }

    ],
    "globelClasses": [{
      "label": "ml-auto",
      "value": "ml-auto"
    },
    {
      "label": "mr-auto",
      "value": "mr-auto"
    },
    {
      "label": "Dropdown RTL",
      "value": "dropzone_bot_right"
    },
    {
      "label": "Dropdown LTR",
      "value": "dropzone_bot_left"
    }],
    "animationCss": [
      {
        "label": "bounce",
        "value": "bounce",
      },
      {
        "label": "flash",
        "value": "flash",
      },
      {
        "label": "pulse",
        "value": "pulse",
      },

      {
        "label": "rubberBand",
        "value": "rubberBand",
      },
      {
        "label": "shake",
        "value": "shake",
      },
      {
        "label": "headShake",
        "value": "headShake",
      },
      {
        "label": "swing",
        "value": "swing",
      },
      {
        "label": "tada",
        "value": "tada",
      },
      {
        "label": "wobble",
        "value": "wobble",
      },
      {
        "label": "jello",
        "value": "jello",
      },
      {
        "label": "jackInTheBox",
        "value": "jackInTheBox",
      },
      {
        "label": "heartBeat",
        "value": "heartBeat",
      },
      {
        "label": "bounceIn",
        "value": "bounceIn",
      },
      {
        "label": "bounceInDown",
        "value": "bounceInDown",
      },
      {
        "label": "bounceInLeft",
        "value": "bounceInLeft",
      },
      {
        "label": "bounceInRight",
        "value": "bounceInRight",
      },
      {
        "label": "bounceInUp",
        "value": "bounceInUp",
      },
      {
        "label": "bounceOut",
        "value": "bounceOut",
      },
      {
        "label": "bounceOutDown",
        "value": "bounceOutDown",
      },
      {
        "label": "bounceOutLeft",
        "value": "bounceOutLeft",
      },
      {
        "label": "bounceOutRight",
        "value": "bounceOutRight",
      },
      {
        "label": "bounceOutUp",
        "value": "bounceOutUp",
      },
      {
        "label": "fadeIn",
        "value": "fadeIn",
      },
      {
        "label": "fadeInDown",
        "value": "fadeInDown",
      },
      {
        "label": "fadeInDownBig",
        "value": "fadeInDownBig",
      },
      {
        "label": "fadeInLeft",
        "value": "fadeInLeft",
      },
      {
        "label": "fadeInLeftBig",
        "value": "fadeInLeftBig",
      },
      {
        "label": "fadeInRight",
        "value": "fadeInRight",
      },
      {
        "label": "fadeInRightBig",
        "value": "fadeInRightBig",
      },
      {
        "label": "fadeInUp",
        "value": "fadeInUp",
      },
      {
        "label": "fadeInUpBig",
        "value": "fadeInUpBig",
      },
      {
        "label": "fadeOut",
        "value": "fadeOut",
      },
      {
        "label": "fadeOutDown",
        "value": "fadeOutDown",
      },
      {
        "label": "fadeOutDownBig",
        "value": "fadeOutDownBig",
      },
      {
        "label": "fadeOutLeft",
        "value": "fadeOutLeft",
      },
      {
        "label": "fadeOutLeftBig",
        "value": "fadeOutLeftBig",
      },
      {
        "label": "fadeOutRight",
        "value": "fadeOutRight",
      },
      {
        "label": "fadeOutRightBig",
        "value": "fadeOutRightBig",
      },
      {
        "label": "fadeOutUp",
        "value": "fadeOutUp",
      },
      {
        "label": "fadeOutUpBig",
        "value": "fadeOutUpBig",
      },
      {
        "label": "rotateIn",
        "value": "rotateIn",
      },
      {
        "label": "rotateInDownLeft",
        "value": "rotateInDownLeft",
      },
      {
        "label": "rotateInDownRight",
        "value": "rotateInDownRight",
      },
      {
        "label": "rotateInUpLeft",
        "value": "rotateInUpLeft",
      },
      {
        "label": "rotateInUpRight",
        "value": "rotateInUpRight",
      },
      {
        "label": "rotateOut",
        "value": "rotateOut",
      },
      {
        "label": "rotateOutDownLeft",
        "value": "rotateOutDownLeft",
      },
      {
        "label": "rotateOutDownRight",
        "value": "rotateOutDownRight",
      },
      {
        "label": "rotateOutUpLeft",
        "value": "rotateOutUpLeft",
      },
      {
        "label": "rotateOutUpRight",
        "value": "rotateOutUpRight",
      },
      {
        "label": "hinge",
        "value": "hinge",
      }, {
        "label": "simple-shape",
        "value": "simple-shape"
      },
      {
        "label": "textAnim",
        "value": "textAnim"
      },
      {
        "label": "animate-charcter",
        "value": "animate-charcter"
      },
      {
        "label": "focusEffect",
        "value": "focusEffect"
      },
      {
        "label": "comingsoon-loading",
        "value": "comingsoon-loading"
      },
      {
        "label": "rotateAnimation",
        "value": "rotateAnimation"
      },
      {
        "label": "zoomInOutAnimation",
        "value": "zoomInOutAnimation"
      },
      {
        "label": "upDownAnimation",
        "value": "upDownAnimation"
      },
      {
        "label": "elemLeftRightAnimation",
        "value": "elemLeftRightAnimation"
      }
    ],
    'elementClass': [

    ]
  },

  "bootstrapModals": {
    "globelClasses": [
      {
        "label": "modal-sm",
        "value": "modal-sm"
      },
      {
        "label": "modal-lg",
        "value": "modal-lg"
      },
      {
        "label": "modal-xl",
        "value": "modal-xl"
      },
      {
        "label": "modal-fullscreen",
        "value": "modal-fullscreen"
      },
      {
        "label": "modal-dialog-centered",
        "value": "modal-dialog-centered"
      },
      {
        "label": "modal-dialog-scrollable",
        "value": "modal-dialog-scrollable"
      },
    ],
  },

  "modelHeader": {
    "globelClasses": [{
      "label": "ml-auto",
      "value": "ml-auto"
    }],
  },

  "modelBody": {
    "globelClasses": [{
      "label": "mr-auto",
      "value": "mr-auto"
    }],
  },
  "modelFooter": {
    "globelClasses": [{
      "label": "mr-auto",
      "value": "mr-auto"
    },
    {
      "label": "bg-transparent",
      "value": "bg-transparent"
    },
    ],
  },



  "button-group": [
    {
      "label": "text-start",
      "value": "text-start"
    },
    {
      "label": "text-sm-start",
      "value": "text-sm-start"
    },
    {
      "label": "text-md-start",
      "value": "text-md-start"
    },
    {
      "label": "text-lg-start",
      "value": "text-lg-start"
    },
    {
      "label": "text-xl-start",
      "value": "text-xl-start"
    },
    {
      "label": "text-center",
      "value": "text-center"
    },
    {
      "label": "text-end",
      "value": "text-end"
    },
    {
      "label": "dropdown-menu-left",
      "value": "dropdown-menu-left"
    },
    {
      "label": "dropdown-menu-right",
      "value": "dropdown-menu-right"
    }
  ],


  //adding prime ng css
  "primeNg": {
    'globelClasses': [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },

      {
        "label": "form-control-sm",
        "value": "form-control-sm"
      }
    ],
    // label parent div
    'labelPrntClass': [
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
    ],
    // label
    'labelClass': [
      {
        "label": "inputlabel_0",
        "value": "inputlabel_0"
      },
      {
        "label": "inputlabel_60",
        "value": "inputlabel_60"
      },
      {
        "label": "inputlabel_90",
        "value": "inputlabel_90"
      },
      {
        "label": "inputlabel_120",
        "value": "inputlabel_120"
      },
      {
        "label": "inputlabel_150",
        "value": "inputlabel_150"
      },
      {
        "label": "inputlabel_180",
        "value": "inputlabel_180"
      },
      {
        "label": "inputlabel_210",
        "value": "inputlabel_210"
      },
      {
        "label": "inputlabel_240",
        "value": "inputlabel_240"
      },
      {
        "label": "inputlabel_280",
        "value": "inputlabel_280"
      },
      {
        "label": "inputlabel_300",
        "value": "inputlabel_300"
      },
      {
        "label": "inputlabel_350",
        "value": "inputlabel_350"
      },
      {
        "label": "inputlabel_400",
        "value": "inputlabel_400"
      },
      {
        "label": "inputlabel_450",
        "value": "inputlabel_450"
      },
      {
        "label": "inputlabel_500",
        "value": "inputlabel_500"
      },
      {
        "label": "text-primary",
        "value": "text-primary",
      },
      {
        "label": "text-secondary",
        "value": "text-secondary",
      },
      {
        "label": "text-success",
        "value": "text-success",
      },
      {
        "label": "text-danger",
        "value": "text-danger",
      },
      {
        "label": "text-warning",
        "value": "text-warning",
      },
      {
        "label": "text-info",
        "value": "text-info",
      },
      {
        "label": "text-light",
        "value": "text-light",
      },
      {
        "label": "text-dark",
        "value": "text-dark",
      },
      {
        "label": "text-muted",
        "value": "text-muted",
      },
      {
        "label": "text-white",
        "value": "text-white",
      }

    ],
    // element Parent div css
    'elementPrntClass': [{
      "label": "parent1",
      "value": "parent1"
    }],

    "pInputText": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      }
    ],

    "pAutoComplete": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      }
    ],
    "pCalendar": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "primeng-lg",
        "value": " primeng-lg"
      },
      {
        "label": " primeng-sm",
        "value": " primeng-sm"
      },
      {
        "label": "primeng-rounded",
        "value": "primeng-rounded"
      },
      {
        "label": "primeng-rounded-0",
        "value": "primeng-rounded-0"
      },
      {
        "label": "primeng-rounded-1",
        "value": "primeng-rounded-1"
      }

    ],
    "pDropdown": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "primeng-lg",
        "value": " primeng-lg"
      },
      {
        "label": " primeng-sm",
        "value": " primeng-sm"
      },
      {
        "label": "primeng-rounded",
        "value": "primeng-rounded"
      },
      {
        "label": "primeng-rounded-0",
        "value": "primeng-rounded-0"
      },
      {
        "label": "primeng-rounded-1",
        "value": "primeng-rounded-1"
      }

    ],
    "pMultiSelect": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "primeng-lg",
        "value": " primeng-lg"
      },
      {
        "label": " primeng-sm",
        "value": " primeng-sm"
      },
      {
        "label": "primeng-rounded",
        "value": "primeng-rounded"
      },
      {
        "label": "primeng-rounded-0",
        "value": "primeng-rounded-0"
      },
      {
        "label": "primeng-rounded-1",
        "value": "primeng-rounded-1"
      }

    ],
    "pTree": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      }
    ],
    "pTable": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      }
    ],
    "country": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "primeng-lg",
        "value": " primeng-lg"
      },
      {
        "label": " primeng-sm",
        "value": " primeng-sm"
      },
      {
        "label": "primeng-rounded",
        "value": "primeng-rounded"
      },
      {
        "label": "primeng-rounded-0",
        "value": "primeng-rounded-0"
      },
      {
        "label": "primeng-rounded-1",
        "value": "primeng-rounded-1"
      }

    ],
    "currency": [
      {
        "label": "required",
        "value": "required"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },

      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "hidden-on-all",
        "value": "hidden-on-all"
      },
      {
        "label": "hidden-only-on-xs",
        "value": "hidden-only-on-xs"
      },
      {
        "label": "hidden-only-on-sm",
        "value": "hidden-only-on-sm"
      },
      {
        "label": "hidden-only-on-md",
        "value": "hidden-only-on-md"
      },
      {
        "label": "hidden-only-on-lg",
        "value": "hidden-only-on-lg"
      },
      {
        "label": "hidden-only-on-xl",
        "value": "hidden-only-on-xl"
      },
      {
        "label": "visible-on-all",
        "value": "visible-on-all"
      },
      {
        "label": "visible-only-on-xs",
        "value": "visible-only-on-xs"
      },
      {
        "label": "visible-only-on-sm",
        "value": "visible-only-on-sm"
      },
      {
        "label": "visible-only-on-md",
        "value": "visible-only-on-md"
      },
      {
        "label": "visible-only-on-lg",
        "value": "visible-only-on-lg"
      },
      {
        "label": "visible-only-on-xl",
        "value": "visible-only-on-xl"
      },
      {
        "label": "full-on-xs",
        "value": "full-on-xs"
      },
      {
        "label": "full-on-sm",
        "value": "full-on-sm"
      },
      {
        "label": "full-on-md",
        "value": "full-on-md"
      },
      {
        "label": "full-on-lg",
        "value": "full-on-lg"
      },
      {
        "label": "primeng-lg",
        "value": " primeng-lg"
      },
      {
        "label": " primeng-sm",
        "value": " primeng-sm"
      },
      {
        "label": "primeng-rounded",
        "value": "primeng-rounded"
      },
      {
        "label": "primeng-rounded-0",
        "value": "primeng-rounded-0"
      },
      {
        "label": "primeng-rounded-1",
        "value": "primeng-rounded-1"
      }

    ],
  },
  // bootstrapTable Table
  "bootstrapTable": {
    'globelClasses': [

      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },


      {
        "label": "table-dark ",
        "value": "table-dark "
      },

      {
        "label": "table-striped",
        "value": "table-striped"
      },
      {
        "label": "table-hover",
        "value": "table-hover"
      },
      {
        "label": "table-active",
        "value": "table-active"
      },
      {
        "label": "table-bordered",
        "value": "table-bordered"
      },
      {
        "label": "border-primary",
        "value": "border-primary"
      },
      {
        "label": "table-borderless",
        "value": "table-borderless"
      },
      {
        "label": "table-light",
        "value": "table-light"
      },
      {
        "label": "table-sm",
        "value": "table-sm"
      },
    ],

  },
  "tableCells": {
    'globelClasses': [

      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },


      {
        "label": "table-dark ",
        "value": "table-dark "
      },

      {
        "label": "table-striped",
        "value": "table-striped"
      },
      {
        "label": "table-hover",
        "value": "table-hover"
      },
      {
        "label": "table-active",
        "value": "table-active"
      },
      {
        "label": "table-bordered",
        "value": "table-bordered"
      },
      {
        "label": "border-primary",
        "value": "border-primary"
      },
      {
        "label": "table-borderless",
        "value": "table-borderless"
      },
      {
        "label": "table-light",
        "value": "table-light"
      },
      {
        "label": "table-sm",
        "value": "table-sm"
      },
    ],

  },
  "customControls": {
    'globelClasses': [

      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },


      {
        "label": "table-dark ",
        "value": "table-dark "
      },

      {
        "label": "table-striped",
        "value": "table-striped"
      },
      {
        "label": "table-hover",
        "value": "table-hover"
      },
      {
        "label": "table-active",
        "value": "table-active"
      },
      {
        "label": "table-bordered",
        "value": "table-bordered"
      },
      {
        "label": "border-primary",
        "value": "border-primary"
      },
      {
        "label": "table-borderless",
        "value": "table-borderless"
      },
      {
        "label": "table-light",
        "value": "table-light"
      },
      {
        "label": "table-sm",
        "value": "table-sm"
      },
    ],
  },
  // deshboard template header section
  "dashboardTypeOne": {
    'globelClasses': [
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },

    ]
  },
  "headerSection": {
    'globelClasses': [
      {
        "label": "bg-primary",
        "value": "bg-primary"
      },
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },
      {
        "label": "bg-white",
        "value": "bg-white"
      },
      {
        "label": "bg-transparent",
        "value": "bg-transparent"
      },
      {
        "label": "bg-gradient",
        "value": "bg-gradient"
      },
      {
        "label": "navbarDesign1",
        "value": "navbarDesign1"
      },
      {
        "label": "navbarDesign2",
        "value": "navbarDesign2"
      },
      {
        "label": "navbarDesign3",
        "value": "navbarDesign3"
      },
      {
        "label": "hover1",
        "value": "menuTopHover1"
      },
      {
        "label": "hover2",
        "value": "menuTopHover2"
      },
      {
        "label": "hover3",
        "value": "menuTopHover3"
      },
      {
        "label": "hover4",
        "value": "menuTopHover4"
      }
    ]
  },
  "leftSection": {
    'globelClasses': [
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },

    ]
  },
  "rightSection": {
    'globelClasses': [
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },

    ]
  },
  "footerSection": {
    'globelClasses': [
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },

    ]
  },
  "navbar": {
    'globelClasses': [
      {
        "label": "bg-primary",
        "value": "bg-primary"
      },
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },
      {
        "label": "bg-white",
        "value": "bg-white"
      },
      {
        "label": "bg-transparent",
        "value": "bg-transparent"
      },
      {
        "label": "bg-gradient",
        "value": "bg-gradient"
      },
      {
        "label": "navbar-dark",
        "value": "navbar-dark"
      },
      {
        "label": "navbar-light",
        "value": "navbar-light"
      },
      {
        "label": "container",
        "value": "container"
      },
      {
        "label": "container-fluid",
        "value": "container-fluid"
      },
      {
        "label": "m-auto",
        "value": "m-auto"
      },
      {
        "label": "sticky-top",
        "value": "sticky-top"
      }
    
    ]
  },

  "tableRow": {
    'globelClasses': [
      {
        "label": "bg-transparent",
        "value": "bg-transparent",
      },
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },
      /* {
        "label": "text-primary",
        "value": "text-primary",
      },
      {
        "label": "text-secondary",
        "value": "text-secondary",
      },
      {
        "label": "text-success",
        "value": "text-success",
      },
      {
        "label": "text-danger",
        "value": "text-danger",
      },
      {
        "label": "text-warning",
        "value": "text-warning",
      },
      {
        "label": "text-info",
        "value": "text-info",
      },
      {
        "label": "text-light",
        "value": "text-light",
      },
      {
        "label": "text-dark",
        "value": "text-dark",
      },
      {
        "label": "text-muted",
        "value": "text-muted",
      },
      {
        "label": "text-white",
        "value": "text-white",
      } */

    ]
  },

  /* "tableBody": {
    'globelClasses': [
      {
        "label": "thead-dark",
        "value": "thead-dark"
      },
      {
        "label": "thead-light",
        "value": "thead-light"
      },


    ]
  }, */

  "customTag": {

    'elementClass': [
      {
        "label": "media-body",
        "value": "media-body"
      },
      {
        "label": "media",
        "value": "media"
      },
      {
        "label": "container",
        "value": "container"
      },
      {
        "label": "container-fluid",
        "value": "container-fluid"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },
      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },
      {
        "label": "label-left",
        "value": "label-left"
      },
      {
        "label": "label-right",
        "value": "label-right"
      },
      {
        "label": "label-top-left",
        "value": "label-top-left"
      },
      {
        "label": "label-top-right",
        "value": "label-top-right"
      },
      {
        "label": "label-top-center",
        "value": "label-top-center"
      },
      {
        "label": "label-off",
        "value": "label-off"
      },
      {
        "label": "label-on",
        "value": "label-on"
      },
      // Background color add
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },
      //div center css
      {
        "label": "main-center",
        "value": "main-center"
      },
      {
        "label": "form-center",
        "value": "form-center"
      },

    ],
    "animationCss": [
      {
        "label": "bounce",
        "value": "bounce",
      },
      {
        "label": "flash",
        "value": "flash",
      },
      {
        "label": "pulse",
        "value": "pulse",
      },

      {
        "label": "rubberBand",
        "value": "rubberBand",
      },
      {
        "label": "shake",
        "value": "shake",
      },
      {
        "label": "headShake",
        "value": "headShake",
      },
      {
        "label": "swing",
        "value": "swing",
      },
      {
        "label": "tada",
        "value": "tada",
      },
      {
        "label": "wobble",
        "value": "wobble",
      },
      {
        "label": "jello",
        "value": "jello",
      },
      {
        "label": "jackInTheBox",
        "value": "jackInTheBox",
      },
      {
        "label": "heartBeat",
        "value": "heartBeat",
      },
      {
        "label": "bounceIn",
        "value": "bounceIn",
      },
      {
        "label": "bounceInDown",
        "value": "bounceInDown",
      },
      {
        "label": "bounceInLeft",
        "value": "bounceInLeft",
      },
      {
        "label": "bounceInRight",
        "value": "bounceInRight",
      },
      {
        "label": "bounceInUp",
        "value": "bounceInUp",
      },
      {
        "label": "bounceOut",
        "value": "bounceOut",
      },
      {
        "label": "bounceOutDown",
        "value": "bounceOutDown",
      },
      {
        "label": "bounceOutLeft",
        "value": "bounceOutLeft",
      },
      {
        "label": "bounceOutRight",
        "value": "bounceOutRight",
      },
      {
        "label": "bounceOutUp",
        "value": "bounceOutUp",
      },
      {
        "label": "fadeIn",
        "value": "fadeIn",
      },
      {
        "label": "fadeInDown",
        "value": "fadeInDown",
      },
      {
        "label": "fadeInDownBig",
        "value": "fadeInDownBig",
      },
      {
        "label": "fadeInLeft",
        "value": "fadeInLeft",
      },
      {
        "label": "fadeInLeftBig",
        "value": "fadeInLeftBig",
      },
      {
        "label": "fadeInRight",
        "value": "fadeInRight",
      },
      {
        "label": "fadeInRightBig",
        "value": "fadeInRightBig",
      },
      {
        "label": "fadeInUp",
        "value": "fadeInUp",
      },
      {
        "label": "fadeInUpBig",
        "value": "fadeInUpBig",
      },
      {
        "label": "fadeOut",
        "value": "fadeOut",
      },
      {
        "label": "fadeOutDown",
        "value": "fadeOutDown",
      },
      {
        "label": "fadeOutDownBig",
        "value": "fadeOutDownBig",
      },
      {
        "label": "fadeOutLeft",
        "value": "fadeOutLeft",
      },
      {
        "label": "fadeOutLeftBig",
        "value": "fadeOutLeftBig",
      },
      {
        "label": "fadeOutRight",
        "value": "fadeOutRight",
      },
      {
        "label": "fadeOutRightBig",
        "value": "fadeOutRightBig",
      },
      {
        "label": "fadeOutUp",
        "value": "fadeOutUp",
      },
      {
        "label": "fadeOutUpBig",
        "value": "fadeOutUpBig",
      },
      {
        "label": "rotateIn",
        "value": "rotateIn",
      },
      {
        "label": "rotateInDownLeft",
        "value": "rotateInDownLeft",
      },
      {
        "label": "rotateInDownRight",
        "value": "rotateInDownRight",
      },
      {
        "label": "rotateInUpLeft",
        "value": "rotateInUpLeft",
      },
      {
        "label": "rotateInUpRight",
        "value": "rotateInUpRight",
      },
      {
        "label": "rotateOut",
        "value": "rotateOut",
      },
      {
        "label": "rotateOutDownLeft",
        "value": "rotateOutDownLeft",
      },
      {
        "label": "rotateOutDownRight",
        "value": "rotateOutDownRight",
      },
      {
        "label": "rotateOutUpLeft",
        "value": "rotateOutUpLeft",
      },
      {
        "label": "rotateOutUpRight",
        "value": "rotateOutUpRight",
      },
      {
        "label": "hinge",
        "value": "hinge",
      }, {
        "label": "simple-shape",
        "value": "simple-shape"
      },
      {
        "label": "textAnim",
        "value": "textAnim"
      },
      {
        "label": "animate-charcter",
        "value": "animate-charcter"
      },
      {
        "label": "focusEffect",
        "value": "focusEffect"
      },
      {
        "label": "comingsoon-loading",
        "value": "comingsoon-loading"
      },
      {
        "label": "rotateAnimation",
        "value": "rotateAnimation"
      },
      {
        "label": "zoomInOutAnimation",
        "value": "zoomInOutAnimation"
      },
      {
        "label": "upDownAnimation",
        "value": "upDownAnimation"
      },
      {
        "label": "elemLeftRightAnimation",
        "value": "elemLeftRightAnimation"
      }
    ],
  },
  //angular_selector
  "angular_selector": {
    "globelClasses": [{
      "label": "ml-auto",
      "value": "ml-auto"
    }],
  },
  "carouselSlider": {
    'globelClasses': [
      {
        "label": "carousel_CSS_ADD_HERE",
        "value": "carousel_CSS_ADD_HERE"
      },
    ],
    'elementClass': [
      {
        "label": "carousel_CSS_ADD_HERE",
        "value": "carousel_CSS_ADD_HERE"
      },
    ]
  },

  "tableHead": {
    'globelClasses': [
      {
        "label": "table-dark",
        "value": "table-dark"
      },
      {
        "label": "table-light",
        "value": "table-light"
      },

      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },

    ]
  },
  "tableBody": {
    'globelClasses': [
      {
        "label": "table-dark",
        "value": "table-dark"
      },
      {
        "label": "table-light",
        "value": "table-light"
      },

      {
        "label": "text-start",
        "value": "text-start"
      },
      {
        "label": "text-sm-start",
        "value": "text-sm-start"
      },
      {
        "label": "text-md-start",
        "value": "text-md-start"
      },
      {
        "label": "text-lg-start",
        "value": "text-lg-start"
      },
      {
        "label": "text-xl-start",
        "value": "text-xl-start"
      },
      {
        "label": "text-center",
        "value": "text-center"
      },
      {
        "label": "text-end",
        "value": "text-end"
      },

    ]
  },
  "image": {
    "image": [
      {
        "label": "dropdown-toggle",
        "value": "dropdown-toggle"
      },
      {
        "label": "align-self-start",
        "value": "align-self-start"
      },
      {
        "label": "align-self-center",
        "value": "align-self-center"
      },

      {
        "label": "align-self-end",
        "value": "align-self-end"
      },

    ],
    "animationCss": [
      {
        "label": "bounce",
        "value": "bounce",
      },
      {
        "label": "flash",
        "value": "flash",
      },
      {
        "label": "pulse",
        "value": "pulse",
      },

      {
        "label": "rubberBand",
        "value": "rubberBand",
      },
      {
        "label": "shake",
        "value": "shake",
      },
      {
        "label": "headShake",
        "value": "headShake",
      },
      {
        "label": "swing",
        "value": "swing",
      },
      {
        "label": "tada",
        "value": "tada",
      },
      {
        "label": "wobble",
        "value": "wobble",
      },
      {
        "label": "jello",
        "value": "jello",
      },
      {
        "label": "jackInTheBox",
        "value": "jackInTheBox",
      },
      {
        "label": "heartBeat",
        "value": "heartBeat",
      },
      {
        "label": "bounceIn",
        "value": "bounceIn",
      },
      {
        "label": "bounceInDown",
        "value": "bounceInDown",
      },
      {
        "label": "bounceInLeft",
        "value": "bounceInLeft",
      },
      {
        "label": "bounceInRight",
        "value": "bounceInRight",
      },
      {
        "label": "bounceInUp",
        "value": "bounceInUp",
      },
      {
        "label": "bounceOut",
        "value": "bounceOut",
      },
      {
        "label": "bounceOutDown",
        "value": "bounceOutDown",
      },
      {
        "label": "bounceOutLeft",
        "value": "bounceOutLeft",
      },
      {
        "label": "bounceOutRight",
        "value": "bounceOutRight",
      },
      {
        "label": "bounceOutUp",
        "value": "bounceOutUp",
      },
      {
        "label": "fadeIn",
        "value": "fadeIn",
      },
      {
        "label": "fadeInDown",
        "value": "fadeInDown",
      },
      {
        "label": "fadeInDownBig",
        "value": "fadeInDownBig",
      },
      {
        "label": "fadeInLeft",
        "value": "fadeInLeft",
      },
      {
        "label": "fadeInLeftBig",
        "value": "fadeInLeftBig",
      },
      {
        "label": "fadeInRight",
        "value": "fadeInRight",
      },
      {
        "label": "fadeInRightBig",
        "value": "fadeInRightBig",
      },
      {
        "label": "fadeInUp",
        "value": "fadeInUp",
      },
      {
        "label": "fadeInUpBig",
        "value": "fadeInUpBig",
      },
      {
        "label": "fadeOut",
        "value": "fadeOut",
      },
      {
        "label": "fadeOutDown",
        "value": "fadeOutDown",
      },
      {
        "label": "fadeOutDownBig",
        "value": "fadeOutDownBig",
      },
      {
        "label": "fadeOutLeft",
        "value": "fadeOutLeft",
      },
      {
        "label": "fadeOutLeftBig",
        "value": "fadeOutLeftBig",
      },
      {
        "label": "fadeOutRight",
        "value": "fadeOutRight",
      },
      {
        "label": "fadeOutRightBig",
        "value": "fadeOutRightBig",
      },
      {
        "label": "fadeOutUp",
        "value": "fadeOutUp",
      },
      {
        "label": "fadeOutUpBig",
        "value": "fadeOutUpBig",
      },
      {
        "label": "rotateIn",
        "value": "rotateIn",
      },
      {
        "label": "rotateInDownLeft",
        "value": "rotateInDownLeft",
      },
      {
        "label": "rotateInDownRight",
        "value": "rotateInDownRight",
      },
      {
        "label": "rotateInUpLeft",
        "value": "rotateInUpLeft",
      },
      {
        "label": "rotateInUpRight",
        "value": "rotateInUpRight",
      },
      {
        "label": "rotateOut",
        "value": "rotateOut",
      },
      {
        "label": "rotateOutDownLeft",
        "value": "rotateOutDownLeft",
      },
      {
        "label": "rotateOutDownRight",
        "value": "rotateOutDownRight",
      },
      {
        "label": "rotateOutUpLeft",
        "value": "rotateOutUpLeft",
      },
      {
        "label": "rotateOutUpRight",
        "value": "rotateOutUpRight",
      },
      {
        "label": "hinge",
        "value": "hinge",
      }, {
        "label": "simple-shape",
        "value": "simple-shape"
      },
      {
        "label": "textAnim",
        "value": "textAnim"
      },
      {
        "label": "animate-charcter",
        "value": "animate-charcter"
      },
      {
        "label": "focusEffect",
        "value": "focusEffect"
      },
      {
        "label": "comingsoon-loading",
        "value": "comingsoon-loading"
      },
      {
        "label": "rotateAnimation",
        "value": "rotateAnimation"
      },
      {
        "label": "zoomInOutAnimation",
        "value": "zoomInOutAnimation"
      },
      {
        "label": "upDownAnimation",
        "value": "upDownAnimation"
      },
      {
        "label": "elemLeftRightAnimation",
        "value": "elemLeftRightAnimation"
      }
    ],
  },
  "video": {
    "video": [
      {
        "label": "dropdown-toggle",
        "value": "dropdown-toggle"
      },
      {
        "label": "align-self-start",
        "value": "align-self-start"
      },
      {
        "label": "align-self-center",
        "value": "align-self-center"
      },

      {
        "label": "align-self-end",
        "value": "align-self-end"
      },

    ],
  },
  //chart
  "chart": {
    'globelClasses': [
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },

    ]
  },
  // Header Component
  "headerComponent": {
    'globelClasses': [
      {
        "label": "bg-primary",
        "value": "bg-primary"
      },
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },
      {
        "label": "bg-body",
        "value": "bg-body"
      },
      {
        "label": "bg-white",
        "value": "bg-white"
      },
      {
        "label": "bg-transparent",
        "value": "bg-transparent"
      },
      {
        "label": "bg-gradient",
        "value": "bg-gradient"
      },
      {
        "label": "p-1",
        "value": "p-1"
      },
      {
        "label": "p-2",
        "value": "p-2"
      },
      {
        "label": "p-3",
        "value": "p-3"
      },
      {
        "label": "p-4",
        "value": "p-4"
      },
      {
        "label": "p-5",
        "value": "p-5"
      },
      {
        "label": "ps-1",
        "value": "ps-1"
      },
      {
        "label": "ps-2",
        "value": "ps-2"
      },
      {
        "label": "ps-3",
        "value": "ps-3"
      },
      {
        "label": "ps-4",
        "value": "ps-4"
      },
      {
        "label": "ps-5",
        "value": "ps-5"
      },
      {
        "label": "pe-1",
        "value": "pe-1"
      },
      {
        "label": "pe-2",
        "value": "pe-2"
      },
      {
        "label": "pe-3",
        "value": "pe-3"
      },
      {
        "label": "pe-4",
        "value": "pe-4"
      },
      {
        "label": "pe-5",
        "value": "pe-5"
      },
      {
        "label": "pt-1",
        "value": "pt-1"
      },
      {
        "label": "pt-2",
        "value": "pt-2"
      },
      {
        "label": "pt-3",
        "value": "pt-3"
      },
      {
        "label": "pt-4",
        "value": "pt-4"
      },
      {
        "label": "pt-5",
        "value": "pt-5"
      },
      {
        "label": "pb-1",
        "value": "pb-1"
      },
      {
        "label": "pb-2",
        "value": "pb-2"
      },
      {
        "label": "pb-3",
        "value": "pb-3"
      },
      {
        "label": "pb-4",
        "value": "pb-4"
      },
      {
        "label": "pb-5",
        "value": "pb-5"
      },
      {
        "label": "px-1",
        "value": "px-1"
      },
      {
        "label": "px-2",
        "value": "px-2"
      },
      {
        "label": "px-3",
        "value": "px-3"
      },
      {
        "label": "px-4",
        "value": "px-4"
      },
      {
        "label": "px-5",
        "value": "px-5"
      },
      {
        "label": "py-1",
        "value": "py-1"
      },
      {
        "label": "py-2",
        "value": "py-2"
      },
      {
        "label": "py-3",
        "value": "py-3"
      },
      {
        "label": "py-4",
        "value": "py-4"
      },
      {
        "label": "py-5",
        "value": "py-5"
      },
      {
        "label": "m-1",
        "value": "m-1"
      },
      {
        "label": "m-2",
        "value": "m-2"
      },
      {
        "label": "m-3",
        "value": "m-3"
      },
      {
        "label": "m-4",
        "value": "m-4"
      },
      {
        "label": "m-5",
        "value": "m-5"
      },
      {
        "label": "ms-1",
        "value": "ms-1"
      },
      {
        "label": "ms-2",
        "value": "ms-2"
      },
      {
        "label": "ms-3",
        "value": "ms-3"
      },
      {
        "label": "ms-4",
        "value": "ms-4"
      },
      {
        "label": "ms-5",
        "value": "ms-5"
      },
      {
        "label": "me-1",
        "value": "me-1"
      },
      {
        "label": "me-2",
        "value": "me-2"
      },
      {
        "label": "me-3",
        "value": "me-3"
      },
      {
        "label": "me-4",
        "value": "me-4"
      },
      {
        "label": "me-5",
        "value": "me-5"
      },
      {
        "label": "mt-1",
        "value": "mt-1"
      },
      {
        "label": "mt-2",
        "value": "mt-2"
      },
      {
        "label": "mt-3",
        "value": "mt-3"
      },
      {
        "label": "mt-4",
        "value": "mt-4"
      },
      {
        "label": "mt-5",
        "value": "mt-5"
      },
      {
        "label": "mb-1",
        "value": "mb-1"
      },
      {
        "label": "mb-2",
        "value": "mb-2"
      },
      {
        "label": "mb-3",
        "value": "mb-3"
      },
      {
        "label": "mb-4",
        "value": "mb-4"
      },
      {
        "label": "mb-5",
        "value": "mb-5"
      },
      {
        "label": "mx-1",
        "value": "mx-1"
      },
      {
        "label": "mx-2",
        "value": "mx-2"
      },
      {
        "label": "mx-3",
        "value": "mx-3"
      },
      {
        "label": "mx-4",
        "value": "mx-4"
      },
      {
        "label": "mx-5",
        "value": "mx-5"
      },
      {
        "label": "my-1",
        "value": "my-1"
      },
      {
        "label": "my-2",
        "value": "my-2"
      },
      {
        "label": "my-3",
        "value": "my-3"
      },
      {
        "label": "my-4",
        "value": "my-4"
      },
      {
        "label": "my-5",
        "value": "my-5"
      },
    ]
  },
  //Social Media
  "dbrdSocialMedia": {
    'globelClasses': [
      {
        "label": "social_design1",
        "value": "social_design1"
      },
      {
        "label": "social_design2",
        "value": "social_design2"
      },
      {
        "label": "social_design3",
        "value": "social_design3"
      },
      {
        "label": "social_design4",
        "value": "social_design4"
      },
    ]
  },
  "anchor": {
    'elementClass': [
      {
        "label": "dropdown-item",
        "value": "dropdown-item"
      },
      {
        "label": "dropdown-toggle",
        "value": "dropdown-toggle"
      },
      {
        "label": "social_design1",
        "value": "social_design1"
      },
      {
        "label": "social_design2",
        "value": "social_design2"
      },
      {
        "label": "social_design3",
        "value": "social_design3"
      },
      {
        "label": "social_design4",
        "value": "social_design4"
      },
    ]
  },
  "pageContainer": {
    'globelClasses': [
      {
        "label": "bg-secondary",
        "value": "bg-secondary"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-light",
        "value": "bg-light"
      },
      {
        "label": "bg-dark",
        "value": "bg-dark"
      },

    ]
  },
  "magnifyZoomImg": {
    'globelClasses': [],
    'elementClass': [

    ]
  },
  "accordion": {
    'globelClasses': [

    ],
    'elementClass': [

    ],
    'labelClass': [

    ]
  },
  "horizontalLine": {
    'elementClass':
      [
        {
          "label": "hrline1",
          "value": "hrline1"
        },
        {
          "label": "hrline2",
          "value": "hrline2"
        },
        {
          "label": "hrline3",
          "value": "hrline3"
        },
        {
          "label": "hrline4",
          "value": "hrline4"
        },
        {
          "label": "hrline5",
          "value": "hrline5"
        },
      ],
  },
  "ul": {
    'globelClasses': [

    ],
  },
  "li": {
    'elementClass': [

    ],
  },
  "languages": {
    'elementClass': [

    ],
  },
  "bootnavTab": {
    'elementClass': [

    ],
    'labelClass': [

    ]
  },
  "listGroup": {
    'globelClasses': [
      {
        "label": "dropdown-menu",
        "value": "dropdown-menu"
      },
      {
        "label": "dropdown-menu-dark",
        "value": "dropdown-menu-dark"
      },
      {
        "label": "dropdown-menu-end",
        "value": "dropdown-menu-end"
      },
      {
        "label": "dropdown-menu-lg-end",
        "value": "dropdown-menu-lg-end"
      },
      {
        "label": "dropdown-menu-lg-start",
        "value": "dropdown-menu-lg-start"
      },
      {
        "label": "list-group",
        "value": "list-group"
      },
      {
        "label": "list-group-flush",
        "value": "list-group-flush"
      },
      {
        "label": "list-group-numbered",
        "value": "list-group-numbered"
      },
      {
        "label": "list-group-horizontal",
        "value": "list-group-horizontal"
      },
      {
        "label": "list-group-horizontal-sm",
        "value": "list-group-horizontal-sm"
      },
      {
        "label": "list-group-horizontal-md",
        "value": "list-group-horizontal-md"
      },
      {
        "label": "list-group-horizontal-lg",
        "value": "list-group-horizontal-lg"
      },
      {
        "label": "list-group-horizontal-xl",
        "value": "list-group-horizontal-xl"
      },
      {
        "label": "list-group-horizontal-xxl",
        "value": "list-group-horizontal-xxl"
      },
      {
        "label": "tab-content",
        "value": "tab-content"
      },
    ],
    'elementClass': [
      {
        "label": "list-group-item",
        "value": "list-group-item"
      },
      {
        "label": "active",
        "value": "active"
      },
      {
        "label": "disabled",
        "value": "disabled"
      },
      {
        "label": "list-group-item-action",
        "value": "list-group-item-action"
      },
      {
        "label": "list-group-item-primary",
        "value": "list-group-item-primary"
      },
      {
        "label": "list-group-item-secondary",
        "value": "list-group-item-secondary"
      },
      {
        "label": "list-group-item-success",
        "value": "list-group-item-success"
      },
      {
        "label": "list-group-item-danger",
        "value": "list-group-item-danger"
      },
      {
        "label": "list-group-item-warning",
        "value": "list-group-item-warning"
      },
      {
        "label": "list-group-item-info",
        "value": "list-group-item-info"
      },
      {
        "label": "list-group-item-light",
        "value": "list-group-item-light"
      },
      {
        "label": "list-group-item-dark",
        "value": "list-group-item-dark"
      },
    ],
  },
  "appendControls": {
    'globelClasses': [
    ],
    'elementClass': [

    ]
  },
  "iframe": {
    'globelClasses': [
    ],
    'elementClass': [

    ]
  },
  "typingCtrl": {
    'globelClasses': [
      {
        "label": "required",
        "value": "required",
      }
    ],

    'elementClass': [

    ]
  },
  "progressBar": {
    'globelClasses': [
      {
        "label": "progress",
        "value": "progress"
      },
    ],
    // element Parent div css
    'elementClass': [
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },
      {
        "label": "progress-bar-striped",
        "value": "progress-bar-striped"
      },
      {
        "label": "progress-bar-animated",
        "value": "progress-bar-animated"
      },

    ],
  },
  "owlCarouselItem": {
    // element Parent div css
    'elementClass': [
      {
        "label": "bg-success",
        "value": "bg-success"
      },
      {
        "label": "bg-info",
        "value": "bg-info"
      },
      {
        "label": "bg-warning",
        "value": "bg-warning"
      },
      {
        "label": "bg-danger",
        "value": "bg-danger"
      },

    ],
  },
  "autoScroll": {
    "animationCss": [
      {
        "label": "bounce",
        "value": "bounce",
      },
      {
        "label": "flash",
        "value": "flash",
      },
      {
        "label": "pulse",
        "value": "pulse",
      },

      {
        "label": "rubberBand",
        "value": "rubberBand",
      },
      {
        "label": "shake",
        "value": "shake",
      },
      {
        "label": "headShake",
        "value": "headShake",
      },
      {
        "label": "swing",
        "value": "swing",
      },
      {
        "label": "tada",
        "value": "tada",
      },
      {
        "label": "wobble",
        "value": "wobble",
      },
      {
        "label": "jello",
        "value": "jello",
      },
      {
        "label": "jackInTheBox",
        "value": "jackInTheBox",
      },
      {
        "label": "heartBeat",
        "value": "heartBeat",
      },
      {
        "label": "bounceIn",
        "value": "bounceIn",
      },
      {
        "label": "bounceInDown",
        "value": "bounceInDown",
      },
      {
        "label": "bounceInLeft",
        "value": "bounceInLeft",
      },
      {
        "label": "bounceInRight",
        "value": "bounceInRight",
      },
      {
        "label": "bounceInUp",
        "value": "bounceInUp",
      },
      {
        "label": "bounceOut",
        "value": "bounceOut",
      },
      {
        "label": "bounceOutDown",
        "value": "bounceOutDown",
      },
      {
        "label": "bounceOutLeft",
        "value": "bounceOutLeft",
      },
      {
        "label": "bounceOutRight",
        "value": "bounceOutRight",
      },
      {
        "label": "bounceOutUp",
        "value": "bounceOutUp",
      },
      {
        "label": "fadeIn",
        "value": "fadeIn",
      },
      {
        "label": "fadeInDown",
        "value": "fadeInDown",
      },
      {
        "label": "fadeInDownBig",
        "value": "fadeInDownBig",
      },
      {
        "label": "fadeInLeft",
        "value": "fadeInLeft",
      },
      {
        "label": "fadeInLeftBig",
        "value": "fadeInLeftBig",
      },
      {
        "label": "fadeInRight",
        "value": "fadeInRight",
      },
      {
        "label": "fadeInRightBig",
        "value": "fadeInRightBig",
      },
      {
        "label": "fadeInUp",
        "value": "fadeInUp",
      },
      {
        "label": "fadeInUpBig",
        "value": "fadeInUpBig",
      },
      {
        "label": "fadeOut",
        "value": "fadeOut",
      },
      {
        "label": "fadeOutDown",
        "value": "fadeOutDown",
      },
      {
        "label": "fadeOutDownBig",
        "value": "fadeOutDownBig",
      },
      {
        "label": "fadeOutLeft",
        "value": "fadeOutLeft",
      },
      {
        "label": "fadeOutLeftBig",
        "value": "fadeOutLeftBig",
      },
      {
        "label": "fadeOutRight",
        "value": "fadeOutRight",
      },
      {
        "label": "fadeOutRightBig",
        "value": "fadeOutRightBig",
      },
      {
        "label": "fadeOutUp",
        "value": "fadeOutUp",
      },
      {
        "label": "fadeOutUpBig",
        "value": "fadeOutUpBig",
      },
      {
        "label": "rotateIn",
        "value": "rotateIn",
      },
      {
        "label": "rotateInDownLeft",
        "value": "rotateInDownLeft",
      },
      {
        "label": "rotateInDownRight",
        "value": "rotateInDownRight",
      },
      {
        "label": "rotateInUpLeft",
        "value": "rotateInUpLeft",
      },
      {
        "label": "rotateInUpRight",
        "value": "rotateInUpRight",
      },
      {
        "label": "rotateOut",
        "value": "rotateOut",
      },
      {
        "label": "rotateOutDownLeft",
        "value": "rotateOutDownLeft",
      },
      {
        "label": "rotateOutDownRight",
        "value": "rotateOutDownRight",
      },
      {
        "label": "rotateOutUpLeft",
        "value": "rotateOutUpLeft",
      },
      {
        "label": "rotateOutUpRight",
        "value": "rotateOutUpRight",
      },
      {
        "label": "hinge",
        "value": "hinge",
      }, {
        "label": "simple-shape",
        "value": "simple-shape"
      },
      {
        "label": "textAnim",
        "value": "textAnim"
      },
      {
        "label": "animate-charcter",
        "value": "animate-charcter"
      },
      {
        "label": "focusEffect",
        "value": "focusEffect"
      },
      {
        "label": "comingsoon-loading",
        "value": "comingsoon-loading"
      },
      {
        "label": "rotateAnimation",
        "value": "rotateAnimation"
      },
      {
        "label": "zoomInOutAnimation",
        "value": "zoomInOutAnimation"
      },
      {
        "label": "upDownAnimation",
        "value": "upDownAnimation"
      },
      {
        "label": "elemLeftRightAnimation",
        "value": "elemLeftRightAnimation"
      }
    ],
    "elementClass": [
      {
        "label": "backtotop-design1",
        "value": "backtotop-design1"
      },
      {
        "label": "backtotop-design2",
        "value": "backtotop-design2"
      },
      {
        "label": "backtotop-design3",
        "value": "backtotop-design3"
      },
      {
        "label": "backtotop-design4",
        "value": "backtotop-design4"
      },
      {
        "label": "backtotop-design5",
        "value": "backtotop-design5"
      },
      {
        "label": "backtotop-design6",
        "value": "backtotop-design6"
      },
      {
        "label": "backtotop-design7",
        "value": "backtotop-design7"
      },
      {
        "label": "backtotop-design8",
        "value": "backtotop-design8"
      },
    ]
  }
}
