export const profileTool = {
  "type": "defaultCompPage",
  "subtype": "defaultCompPage",
  "icon": "fa-columns",
  "label": "col",
  "ctrlId": 'serverprofile',
  "path": "/src/app/custommodules/",
  "defaultCompData": [
    {
      "ngGenerate": {
        "ngType": "page",
        "ngName": "serverprofile",
        "ngAuthor": "sagDev",
        "ngDesc": "send Mail Folder with file",
        "ngServiceType": "",
      },
      "creationPath": "/src/app/custommodules",
      "data": {
        "htmlData": [
          {
            "attributeLogiclayer": [
              {
                "name": "Globel AttrLogic",
                "selAttrs": [],
                "label": "globelAttrLogic",
                "id": null,
                "type": "globelAttrLogics",
                "value": "globelLogic",
                "attrList": []
              },
              {
                "name": "Element AttrLogic",
                "selAttrs": [
                  "label",
                  "tooltip"
                ],
                "label": "elemAttrLogic",
                "id": null,
                "type": "elemAttrLogics",
                "value": "elemAttrLogic",
                "attrList": []
              }
            ],
            "icon": "fa-columns",
            "isCurrentlySelected": false,
            "description": "Page Container",
            "parseCtrl": {
              "subData": true,
              "layerCount": "1",
              "layerTopId": "pageContainer#Globel",
              "layerCtrls": [
                "pageContainer#Globel"
              ]
            },
            "type": "pageContainer",
            "studioDevClasses": "d-block",
            "projectConfigProperties": [
              "name",
              "label",
              "visibility",
              "expandCollapseForCtrl",
              "globelAttrLogic",
              "controlBindingType",
              "selectedEventList",
              "combineAllModel"
            ],
            "parentId": null,
            "angular": {},
            "errorText": "Please select a valid Div",
            "applicableAttributeLogic": [
              "globelLogic",
              "elemAttrLogic"
            ],
            "database": {},
            "subtype": "div",
            "id": null,
            "subDataArray": [
              {
                "attributeLogiclayer": [
                  {
                    "name": "Globel AttrLogic",
                    "selAttrs": [],
                    "label": "globelAttrLogic",
                    "id": null,
                    "type": "globelAttrLogics",
                    "value": "globelLogic",
                    "attrList": []
                  },
                  {
                    "name": "Element AttrLogic",
                    "selAttrs": [
                      "label",
                      "tooltip"
                    ],
                    "label": "elemAttrLogic",
                    "id": null,
                    "type": "elemAttrLogics",
                    "value": "elemAttrLogic",
                    "attrList": []
                  }
                ],
                "icon": "fa-columns",
                "isCurrentlySelected": false,
                "description": "Page Container",
                "parseCtrl": {
                  "subData": true,
                  "layerCount": "1",
                  "layerTopId": "pageContainer#Globel",
                  "layerCtrls": [
                    "pageContainer#Globel"
                  ]
                },
                "type": "pageContainer",
                "studioDevClasses": "d-block",
                "projectConfigProperties": [
                  "name",
                  "label",
                  "visibility",
                  "expandCollapseForCtrl",
                  "globelAttrLogic",
                  "controlBindingType",
                  "selectedEventList",
                  "combineAllModel"
                ],
                "parentId": null,
                "angular": {},
                "errorText": "Please select a valid Div",
                "applicableAttributeLogic": [
                  "globelLogic",
                  "elemAttrLogic"
                ],
                "database": {},
                "subtype": "div",
                "id": null,
                "subDataArray": [
                  {
                    "attributeLogiclayer": [
                      {
                        "name": "Globel AttrLogic",
                        "selAttrs": [],
                        "label": "globelAttrLogic",
                        "id": null,
                        "type": "globelAttrLogics",
                        "value": "globelLogic",
                        "attrList": []
                      },
                      {
                        "name": "Element AttrLogic",
                        "selAttrs": [
                          "label",
                          "tooltip"
                        ],
                        "label": "elemAttrLogic",
                        "id": null,
                        "type": "elemAttrLogics",
                        "value": "elemAttrLogic",
                        "attrList": []
                      }
                    ],
                    "icon": "fa-columns",
                    "isCurrentlySelected": false,
                    "description": "Page Container",
                    "parseCtrl": {
                      "subData": true,
                      "layerCount": "1",
                      "layerTopId": "pageContainer#Globel",
                      "layerCtrls": [
                        "pageContainer#Globel"
                      ]
                    },
                    "type": "pageContainer",
                    "studioDevClasses": "d-block",
                    "projectConfigProperties": [
                      "name",
                      "label",
                      "visibility",
                      "expandCollapseForCtrl",
                      "globelAttrLogic",
                      "controlBindingType",
                      "selectedEventList",
                      "combineAllModel"
                    ],
                    "parentId": null,
                    "angular": {},
                    "errorText": "Please select a valid Div",
                    "applicableAttributeLogic": [
                      "globelLogic",
                      "elemAttrLogic"
                    ],
                    "database": {},
                    "subtype": "div",
                    "id": null,
                    "subDataArray": [
                      {
                        "sagFooterArea": [
                          {
                            "attributeLogiclayer": [
                              {
                                "name": "Globel AttrLogic",
                                "selAttrs": [],
                                "label": "globelAttrLogic",
                                "id": null,
                                "type": "globelAttrLogics",
                                "value": "globelLogic",
                                "attrList": []
                              },
                              {
                                "name": "Element AttrLogic",
                                "selAttrs": [
                                  "label",
                                  "tooltip"
                                ],
                                "label": "elemAttrLogic",
                                "id": null,
                                "type": "elemAttrLogics",
                                "value": "elemAttrLogic",
                                "attrList": []
                              }
                            ],
                            "icon": "fa-columns",
                            "isCurrentlySelected": false,
                            "description": "sagFooterArea Here",
                            "handle": true,
                            "footerLeft": [
                              {
                                "attributeLogiclayer": [
                                  {
                                    "name": "Globel AttrLogic",
                                    "selAttrs": [],
                                    "label": "globelAttrLogic",
                                    "id": null,
                                    "type": "globelAttrLogics",
                                    "value": "globelLogic",
                                    "attrList": []
                                  },
                                  {
                                    "name": "Element AttrLogic",
                                    "selAttrs": [],
                                    "label": "elemAttrLogic",
                                    "id": null,
                                    "type": "elemAttrLogics",
                                    "value": "elemAttrLogic",
                                    "attrList": []
                                  }
                                ],
                                "icon": "fa-columns",
                                "isCurrentlySelected": true,
                                "description": "footerLeft Here",
                                "handle": true,
                                "parseCtrl": {
                                  "subData": false,
                                  "layerCount": "2",
                                  "layerTopId": "",
                                  "layerCtrls": []
                                },
                                "type": "sagFooterArea",
                                "studioDevClasses": "d-block",
                                "projectConfigProperties": [
                                  "name",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ],
                                "parentId": null,
                                "angular": {},
                                "errorText": "Please select a valid Footer",
                                "applicableAttributeLogic": [
                                  "globelLogic",
                                  "elemAttrLogic"
                                ],
                                "database": {},
                                "subtype": "footerLeft",
                                "id": null,
                                "subDataArray": [],
                                "events": {},
                                "properties": {
                                  "additionElementClass": "",
                                  "selectedElementClassArray": [],
                                  "name": "",
                                  "defaultElementCls": " footer-left-menu",
                                  "elementInnerStyles": {},
                                  "controlBindingType": "static",
                                  "globelAttrLogic": "",
                                  "label": "footerLeft",
                                  "elementClass": ""
                                },
                                "windowProperties": [
                                  "name",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ]
                              }
                            ],
                            "type": "sagFooterArea",
                            "studioDevClasses": "d-block",
                            "projectConfigProperties": [
                              "name",
                              "expandCollapseForCtrl",
                              "globelAttrLogic",
                              "controlBindingType"
                            ],
                            "parentId": null,
                            "angular": {},
                            "errorText": "Please enter a valid Footer",
                            "applicableAttributeLogic": [
                              "globelLogic",
                              "elemAttrLogic"
                            ],
                            "database": {},
                            "subtype": "sagFooterArea",
                            "id": null,
                            "subDataArray": [],
                            "events": {},
                            "properties": {
                              "additionElementClass": "",
                              "selectedElementClassArray": [],
                              "name": "",
                              "defaultElementCls": " page-footer  p-1",
                              "elementInnerStyles": {},
                              "controlBindingType": "static",
                              "globelAttrLogic": "",
                              "label": "sagFooterArea",
                              "elementClass": ""
                            },
                            "windowProperties": [
                              "name",
                              "expandCollapseForCtrl",
                              "globelAttrLogic",
                              "controlBindingType"
                            ],
                            "footerRight": [
                              {
                                "attributeLogiclayer": [
                                  {
                                    "name": "Globel AttrLogic",
                                    "selAttrs": [],
                                    "label": "globelAttrLogic",
                                    "id": null,
                                    "type": "globelAttrLogics",
                                    "value": "globelLogic",
                                    "attrList": []
                                  },
                                  {
                                    "name": "Element AttrLogic",
                                    "selAttrs": [],
                                    "label": "elemAttrLogic",
                                    "id": null,
                                    "type": "elemAttrLogics",
                                    "value": "elemAttrLogic",
                                    "attrList": []
                                  }
                                ],
                                "icon": "fa-columns",
                                "isCurrentlySelected": false,
                                "description": "footerRight Here",
                                "handle": true,
                                "parseCtrl": {
                                  "subData": false,
                                  "layerCount": "2",
                                  "layerTopId": "",
                                  "layerCtrls": []
                                },
                                "type": "sagFooterArea",
                                "studioDevClasses": "d-block",
                                "projectConfigProperties": [
                                  "name",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ],
                                "parentId": null,
                                "angular": {},
                                "errorText": "Please select a valid Footer",
                                "applicableAttributeLogic": [
                                  "globelLogic",
                                  "elemAttrLogic"
                                ],
                                "database": {},
                                "subtype": "footerRight",
                                "id": null,
                                "subDataArray": [
                                  {
                                    "routerLink": null,
                                    "attributeLogiclayer": [
                                      {
                                        "name": "Globel AttrLogic",
                                        "selAttrs": [],
                                        "label": "globelAttrLogic",
                                        "id": null,
                                        "type": "globelAttrLogics",
                                        "value": "globelLogic",
                                        "attrList": []
                                      },
                                      {
                                        "name": "Element AttrLogic",
                                        "selAttrs": [
                                          "label",
                                          "tooltip"
                                        ],
                                        "label": "elemAttrLogic",
                                        "id": null,
                                        "type": "elemAttrLogics",
                                        "value": "elemAttrLogic",
                                        "attrList": []
                                      }
                                    ],
                                    "icon": "fas fa-toggle-off",
                                    "isCurrentlySelected": false,
                                    "description": "Button",
                                    "handle": true,
                                    "parseCtrl": {
                                      "subData": false,
                                      "layerCount": "2",
                                      "layerTopId": "input~button#ElementPrnt",
                                      "layerCtrls": [
                                        "input~button#ElementPrnt",
                                        "input~button#Element"
                                      ]
                                    },
                                    "type": "input",
                                    "studioDevClasses": "d-inline",
                                    "projectConfigProperties": [
                                      "name",
                                      "label",
                                      "disable",
                                      "visibility",
                                      "animationCss",
                                      "iconClass",
                                      "iconPosition",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType",
                                      "formType",
                                      "formGroupName",
                                      "validatorChecker",
                                      "selectedEventList",
                                      "combineAllModel"
                                    ],
                                    "parentId": null,
                                    "angular": {
                                      "tooltipTitle": "",
                                      "formType": "reactiveForm",
                                      "validationMsg": "",
                                      "toolTipPosition": "top",
                                      "formGroupName": "serverprofile",
                                      "toolTipEvent": "mouseenter",
                                      "validators": [],
                                      "validatorChecker": true,
                                      "selectedValidatorsForControls": [],
                                      "toolTipShow": false
                                    },
                                    "errorText": "Please enter a valid Value",
                                    "applicableAttributeLogic": [
                                      "globelLogic",
                                      "elemAttrLogic"
                                    ],
                                    "database": {
                                      "onExcessLoad": false,
                                      "databaseName": "",
                                      "dbMappingState": "none",
                                      "columnInfo": {},
                                      "tableName": "",
                                      "columnName": "",
                                      "dbMappingMsg": "",
                                      "master": false
                                    },
                                    "selectedEventList": " click ",
                                    "subtype": "button",
                                    "id": "input_1663837484690",
                                    "subDataArray": [],
                                    "loadChildrenMod": "",
                                    "events": {
                                      "selectedEventList": [
                                        "click"
                                      ],
                                      "eventData": [
                                        {
                                          "args": "",
                                          "nodeName": "savemail",
                                          "nodeSubType": "method",
                                          "authorName": "",
                                          "bodyInfo": [],
                                          "methodName": "savemail",
                                          "eventType": "click",
                                          "id": "click_1663927769354",
                                          "nodeType": "",
                                          "params": "",
                                          "desc": ""
                                        }
                                      ]
                                    },
                                    "properties": {
                                      "visibility": true,
                                      "selectedElementClassArray": [],
                                      "animationCss": "",
                                      "globelAttrLogic": "",
                                      "label": "Save",
                                      "required": false,
                                      "iconClass": "",
                                      "regex": "",
                                      "additionElementClass": "",
                                      "disable": false,
                                      "name": "save",
                                      "iconPosition": "before",
                                      "defaultElementCls": "btn btn-primary input~button#Element",
                                      "elementInnerStyles": {},
                                      "controlBindingType": "static",
                                      "placeholder": "Button",
                                      "elementClass": "",
                                      "starSymbol": false,
                                      "selectedAnimationArray": []
                                    },
                                    "windowProperties": [
                                      "name",
                                      "label",
                                      "disable",
                                      "visibility",
                                      "animationCss",
                                      "iconClass",
                                      "iconPosition",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType",
                                      "formType",
                                      "formGroupName",
                                      "validatorChecker",
                                      "selectedEventList",
                                      "combineAllModel"
                                    ]
                                  },
                                  {
                                    "routerLink": null,
                                    "attributeLogiclayer": [
                                      {
                                        "name": "Globel AttrLogic",
                                        "selAttrs": [],
                                        "label": "globelAttrLogic",
                                        "id": null,
                                        "type": "globelAttrLogics",
                                        "value": "globelLogic",
                                        "attrList": []
                                      },
                                      {
                                        "name": "Element AttrLogic",
                                        "selAttrs": [
                                          "label",
                                          "tooltip"
                                        ],
                                        "label": "elemAttrLogic",
                                        "id": null,
                                        "type": "elemAttrLogics",
                                        "value": "elemAttrLogic",
                                        "attrList": []
                                      }
                                    ],
                                    "icon": "fas fa-toggle-off",
                                    "isCurrentlySelected": true,
                                    "description": "Button",
                                    "handle": true,
                                    "parseCtrl": {
                                      "subData": false,
                                      "layerCount": "2",
                                      "layerTopId": "input~button#ElementPrnt",
                                      "layerCtrls": [
                                        "input~button#ElementPrnt",
                                        "input~button#Element"
                                      ]
                                    },
                                    "type": "input",
                                    "studioDevClasses": "d-inline",
                                    "projectConfigProperties": [
                                      "name",
                                      "label",
                                      "disable",
                                      "visibility",
                                      "animationCss",
                                      "iconClass",
                                      "iconPosition",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType",
                                      "formType",
                                      "formGroupName",
                                      "validatorChecker",
                                      "selectedEventList",
                                      "combineAllModel"
                                    ],
                                    "parentId": null,
                                    "angular": {
                                      "tooltipTitle": "",
                                      "formType": "none",
                                      "validationMsg": "",
                                      "toolTipPosition": "top",
                                      "formGroupName": "",
                                      "toolTipEvent": "mouseenter",
                                      "validators": [],
                                      "validatorChecker": false,
                                      "selectedValidatorsForControls": [],
                                      "toolTipShow": false
                                    },
                                    "errorText": "Please enter a valid Value",
                                    "applicableAttributeLogic": [
                                      "globelLogic",
                                      "elemAttrLogic"
                                    ],
                                    "database": {
                                      "onExcessLoad": false,
                                      "databaseName": "",
                                      "dbMappingState": "none",
                                      "columnInfo": {},
                                      "tableName": "",
                                      "columnName": "",
                                      "dbMappingMsg": "",
                                      "master": false
                                    },
                                    "subtype": "button",
                                    "id": "input_1664177740271",
                                    "subDataArray": [],
                                    "loadChildrenMod": "",
                                    "events": {
                                      "selectedEventList": [],
                                      "eventData": []
                                    },
                                    "properties": {
                                      "visibility": true,
                                      "selectedElementClassArray": [],
                                      "animationCss": "",
                                      "globelAttrLogic": "",
                                      "label": "Cancel",
                                      "required": false,
                                      "iconClass": "",
                                      "regex": "",
                                      "additionElementClass": "ms-1",
                                      "disable": false,
                                      "name": "cancel",
                                      "iconPosition": "before",
                                      "defaultElementCls": "btn btn-danger input~button#Element",
                                      "elementInnerStyles": {},
                                      "controlBindingType": "static",
                                      "placeholder": "Button",
                                      "elementClass": "",
                                      "starSymbol": false,
                                      "selectedAnimationArray": []
                                    },
                                    "windowProperties": [
                                      "name",
                                      "label",
                                      "disable",
                                      "visibility",
                                      "animationCss",
                                      "iconClass",
                                      "iconPosition",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType",
                                      "formType",
                                      "formGroupName",
                                      "validatorChecker",
                                      "selectedEventList",
                                      "combineAllModel"
                                    ]
                                  }
                                ],
                                "events": {},
                                "properties": {
                                  "additionElementClass": "",
                                  "selectedElementClassArray": [],
                                  "name": "",
                                  "defaultElementCls": " footer-right-menu",
                                  "elementInnerStyles": {},
                                  "controlBindingType": "static",
                                  "globelAttrLogic": "",
                                  "label": "footerRight",
                                  "elementClass": ""
                                },
                                "windowProperties": [
                                  "name",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ]
                              }
                            ]
                          }
                        ],
                        "attributeLogiclayer": [
                          {
                            "name": "Globel AttrLogic",
                            "selAttrs": [],
                            "label": "globelAttrLogic",
                            "id": null,
                            "type": "globelAttrLogics",
                            "value": "globelLogic",
                            "attrList": []
                          },
                          {
                            "name": "Element Div AttrLogic",
                            "selAttrs": [],
                            "label": "elemDivAttrLogic",
                            "id": null,
                            "type": "elemDivAttrLogics",
                            "value": "elemLogic",
                            "attrList": []
                          }
                        ],
                        "icon": "fa-align-left",
                        "isCurrentlySelected": false,
                        "description": "Sag page",
                        "handle": true,
                        "parseCtrl": {
                          "subData": false,
                          "layerCount": "5",
                          "layerTopId": "sagPage#Globel",
                          "layerCtrls": [
                            "sagPage#Globel",
                            "sagPage#ElementPrnt"
                          ]
                        },
                        "type": "sagPage",
                        "studioDevClasses": "d-block",
                        "sagFormArea": [
                          {
                            "attributeLogiclayer": [
                              {
                                "name": "Globel AttrLogic",
                                "selAttrs": [],
                                "label": "globelAttrLogic",
                                "id": null,
                                "type": "globelAttrLogics",
                                "value": "globelLogic",
                                "attrList": []
                              },
                              {
                                "name": "Element Div AttrLogic",
                                "selAttrs": [],
                                "label": "elemDivAttrLogic",
                                "id": null,
                                "type": "elemDivAttrLogics",
                                "value": "elemLogic",
                                "attrList": []
                              }
                            ],
                            "icon": "fa-columns",
                            "isCurrentlySelected": false,
                            "description": "sagFormArea Here",
                            "handle": true,
                            "parseCtrl": {
                              "subData": true,
                              "layerCount": "1",
                              "layerTopId": "sagFormArea#Globel",
                              "layerCtrls": [
                                "sagFormArea#Globel"
                              ]
                            },
                            "type": "sagFormArea",
                            "studioDevClasses": "d-block",
                            "projectConfigProperties": [
                              "name",
                              "expandCollapseForCtrl",
                              "globelAttrLogic",
                              "controlBindingType"
                            ],
                            "angular": {},
                            "errorText": "Please select a valid Div",
                            "applicableAttributeLogic": [
                              "globelLogic",
                              "elemAttrLogic"
                            ],
                            "database": {},
                            "subtype": "sagFormArea",
                            "id": "sagFormArea0_1663831863232",
                            "subDataArray": [
                              {
                                "attributeLogiclayer": [
                                  {
                                    "name": "Globel AttrLogic",
                                    "selAttrs": [],
                                    "label": "globelAttrLogic",
                                    "id": null,
                                    "type": "globelAttrLogics",
                                    "value": "globelLogic",
                                    "attrList": []
                                  },
                                  {
                                    "name": "Element AttrLogic",
                                    "selAttrs": [],
                                    "label": "elemAttrLogic",
                                    "id": null,
                                    "type": "elemAttrLogics",
                                    "value": "elemAttrLogic",
                                    "attrList": []
                                  }
                                ],
                                "icon": "fa-columns",
                                "isCurrentlySelected": false,
                                "description": "Row Here",
                                "handle": true,
                                "parseCtrl": {
                                  "subData": true,
                                  "layerCount": "1",
                                  "layerTopId": "row~Element",
                                  "layerCtrls": [
                                    "row~Element"
                                  ]
                                },
                                "type": "row",
                                "studioDevClasses": "",
                                "projectConfigProperties": [
                                  "name",
                                  "label",
                                  "visibility",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ],
                                "parentId": "sagFormArea0_1663831863232",
                                "angular": {},
                                "errorText": "Please enter a valid Value",
                                "applicableAttributeLogic": [
                                  "globelLogic",
                                  "elemAttrLogic"
                                ],
                                "database": {},
                                "subtype": "row",
                                "id": "row_1663836374962",
                                "validationClass": true,
                                "subDataArray": [
                                  {
                                    "attributeLogiclayer": [
                                      {
                                        "name": "Globel AttrLogic",
                                        "selAttrs": [],
                                        "label": "globelAttrLogic",
                                        "id": null,
                                        "type": "globelAttrLogics",
                                        "value": "globelLogic",
                                        "attrList": []
                                      },
                                      {
                                        "name": "Element AttrLogic",
                                        "selAttrs": [],
                                        "label": "elemAttrLogic",
                                        "id": null,
                                        "type": "elemAttrLogics",
                                        "value": "elemAttrLogic",
                                        "attrList": []
                                      }
                                    ],
                                    "icon": null,
                                    "isCurrentlySelected": false,
                                    "description": "Create Column Here",
                                    "handle": true,
                                    "parseCtrl": {
                                      "subData": true,
                                      "layerCount": "1",
                                      "layerTopId": "column#Globel",
                                      "layerCtrls": [
                                        "column#Globel"
                                      ]
                                    },
                                    "type": "column",
                                    "studioDevClasses": "",
                                    "projectConfigProperties": [
                                      "name",
                                      "label",
                                      "visibility",
                                      "colClass",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType"
                                    ],
                                    "parentId": "",
                                    "angular": {},
                                    "applicableAttributeLogic": [
                                      "globelLogic",
                                      "elemAttrLogic"
                                    ],
                                    "database": {},
                                    "subtype": "column",
                                    "id": "",
                                    "subDataArray": [
                                      {
                                        "takeOptionsFrom": "optFromStatic",
                                        "values": [
                                          {
                                            "label": "Mail",
                                            "value": "1"
                                          },
                                          {
                                            "label": "Message",
                                            "value": "2"
                                          },
                                          {
                                            "label": "Whatsapp",
                                            "value": "3"
                                          }
                                        ],
                                        "attributeLogiclayer": [
                                          {
                                            "name": "Globel AttrLogic",
                                            "selAttrs": [],
                                            "label": "globelAttrLogic",
                                            "id": null,
                                            "type": "globelAttrLogics",
                                            "value": "globelLogic",
                                            "attrList": []
                                          },
                                          {
                                            "name": "Element AttrLogic",
                                            "selAttrs": [
                                              "label",
                                              "tooltip"
                                            ],
                                            "label": "elemAttrLogic",
                                            "id": null,
                                            "type": "elemAttrLogics",
                                            "value": "elemAttrLogic",
                                            "attrList": []
                                          }
                                        ],
                                        "icon": "far fa-dot-circle",
                                        "description": "Radio boxes",
                                        "type": "input",
                                        "projectConfigProperties": [
                                          "name",
                                          "label",
                                          "disable",
                                          "visibility",
                                          "starSymbol",
                                          "required",
                                          "regex",
                                          "expandCollapseForGlobal",
                                          "expandCollapseForLabel",
                                          "expandCollapseForCtrl",
                                          "addOption",
                                          "globelAttrLogic",
                                          "controlBindingType",
                                          "formType",
                                          "formGroupName",
                                          "custom_msgAdd",
                                          "allValidationList",
                                          "tooltip",
                                          "selectedEventList",
                                          "combineAllModel",
                                          "databaseName",
                                          "tableName",
                                          "columnName",
                                          "onExcessLoad",
                                          "master"
                                        ],
                                        "database": {
                                          "onExcessLoad": false,
                                          "databaseName": "",
                                          "dbMappingState": "none",
                                          "columnInfo": {},
                                          "tableName": "",
                                          "columnName": "",
                                          "dbMappingMsg": "",
                                          "master": false
                                        },
                                        "subtype": "radio",
                                        "id": "input_1663836380865",
                                        "events": {
                                          "selectedEventList": [
                                            "click"
                                          ],
                                          "eventData": [
                                            {
                                              "args": "$event",
                                              "nodeName": "checkProvideType",
                                              "nodeSubType": "method",
                                              "authorName": "",
                                              "bodyInfo": [],
                                              "methodName": "checkProvideType",
                                              "eventType": "click",
                                              "id": "click_1663927688029",
                                              "nodeType": "",
                                              "params": "",
                                              "desc": ""
                                            }
                                          ]
                                        },
                                        "optFromServiceList": null,
                                        "optFromVarList": null,
                                        "isCurrentlySelected": false,
                                        "optionAttributes": null,
                                        "handle": true,
                                        "studioDevClasses": "d-block",
                                        "parentId": "",
                                        "angular": {
                                          "tooltipTitle": "",
                                          "formType": "reactiveForm",
                                          "validationMsg": "",
                                          "toolTipPosition": "top",
                                          "formGroupName": "serverprofile",
                                          "toolTipEvent": "mouseenter",
                                          "validators": [],
                                          "selectedValidatorsForControls": [],
                                          "toolTipShow": false
                                        },
                                        "errorText": "Please enter a valid Value",
                                        "applicableAttributeLogic": [
                                          "globelLogic",
                                          "elemAttrLogic"
                                        ],
                                        "selectedEventList": " click ",
                                        "subDataArray": [],
                                        "properties": {
                                          "selectedGlobalClassArray": [],
                                          "labelClass": "inputlabel_90",
                                          "selectedElementClassArray": [],
                                          "defaultGlobelCls": "form-group form_group_label d-flex",
                                          "globelAttrLogic": "",
                                          "selectedTagClassArray": [
                                            "inputlabel_90"
                                          ],
                                          "required": false,
                                          "globelClasses": "",
                                          "additionElementClass": "me-2",
                                          "additionLabelClass": "",
                                          "defaultElementCls": "form-check",
                                          "controlBindingType": "static",
                                          "placeholder": "Type your Radio to display here ",
                                          "elementClass": "",
                                          "starSymbol": false,
                                          "additionGlobelClasses": "",
                                          "visibility": true,
                                          "defaultLabelCls": "",
                                          "label": "Profile Type",
                                          "regex": "",
                                          "disable": false,
                                          "name": "emlProfiletype",
                                          "elementInnerStyles": {},
                                          "labelInnerStyles": {},
                                          "globalInnerStyles": {}
                                        },
                                        "windowProperties": [
                                          "name",
                                          "label",
                                          "disable",
                                          "visibility",
                                          "starSymbol",
                                          "required",
                                          "regex",
                                          "expandCollapseForGlobal",
                                          "expandCollapseForLabel",
                                          "expandCollapseForCtrl",
                                          "addOption",
                                          "globelAttrLogic",
                                          "controlBindingType",
                                          "formType",
                                          "formGroupName",
                                          "custom_msgAdd",
                                          "allValidationList",
                                          "tooltip",
                                          "selectedEventList",
                                          "combineAllModel",
                                          "databaseName",
                                          "tableName",
                                          "columnName",
                                          "onExcessLoad",
                                          "master"
                                        ]
                                      }
                                    ],
                                    "events": {},
                                    "properties": {
                                      "additionElementClass": "",
                                      "visibility": true,
                                      "selectedElementClassArray": [],
                                      "name": "",
                                      "defaultElementCls": "",
                                      "elementInnerStyles": {},
                                      "controlBindingType": "static",
                                      "globelAttrLogic": "",
                                      "label": "Column",
                                      "elementClass": "",
                                      "colClass": "col-sm-12"
                                    },
                                    "windowProperties": [
                                      "name",
                                      "label",
                                      "visibility",
                                      "colClass",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType"
                                    ]
                                  }
                                ],
                                "events": {},
                                "properties": {
                                  "additionElementClass": "",
                                  "visibility": true,
                                  "selectedElementClassArray": [],
                                  "name": "row_1663836374962",
                                  "defaultElementCls": "row",
                                  "elementInnerStyles": {},
                                  "controlBindingType": "static",
                                  "globelAttrLogic": "",
                                  "label": "Row",
                                  "elementClass": ""
                                },
                                "windowProperties": [
                                  "name",
                                  "label",
                                  "visibility",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ]
                              },
                              {
                                "attributeLogiclayer": [
                                  {
                                    "name": "Globel AttrLogic",
                                    "selAttrs": [],
                                    "label": "globelAttrLogic",
                                    "id": null,
                                    "type": "globelAttrLogics",
                                    "value": "globelLogic",
                                    "attrList": []
                                  },
                                  {
                                    "name": "Element AttrLogic",
                                    "selAttrs": [],
                                    "label": "elemAttrLogic",
                                    "id": null,
                                    "type": "elemAttrLogics",
                                    "value": "elemAttrLogic",
                                    "attrList": []
                                  }
                                ],
                                "icon": "fa-columns",
                                "isCurrentlySelected": false,
                                "description": "Row Here",
                                "handle": true,
                                "parseCtrl": {
                                  "subData": true,
                                  "layerCount": "1",
                                  "layerTopId": "row~Element",
                                  "layerCtrls": [
                                    "row~Element"
                                  ]
                                },
                                "type": "row",
                                "studioDevClasses": "",
                                "projectConfigProperties": [
                                  "name",
                                  "label",
                                  "visibility",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ],
                                "parentId": "sagFormArea0_1663831863232",
                                "angular": {},
                                "errorText": "Please enter a valid Value",
                                "applicableAttributeLogic": [
                                  "globelLogic",
                                  "elemAttrLogic"
                                ],
                                "database": {},
                                "subtype": "row",
                                "id": "row_1663836480195",
                                "subDataArray": [
                                  {
                                    "attributeLogiclayer": [
                                      {
                                        "name": "Globel AttrLogic",
                                        "selAttrs": [],
                                        "label": "globelAttrLogic",
                                        "id": null,
                                        "type": "globelAttrLogics",
                                        "value": "globelLogic",
                                        "attrList": []
                                      },
                                      {
                                        "name": "Element AttrLogic",
                                        "selAttrs": [],
                                        "label": "elemAttrLogic",
                                        "id": null,
                                        "type": "elemAttrLogics",
                                        "value": "elemAttrLogic",
                                        "attrList": []
                                      }
                                    ],
                                    "icon": null,
                                    "isCurrentlySelected": false,
                                    "description": "Create Column Here",
                                    "handle": true,
                                    "parseCtrl": {
                                      "subData": true,
                                      "layerCount": "1",
                                      "layerTopId": "column#Globel",
                                      "layerCtrls": [
                                        "column#Globel"
                                      ]
                                    },
                                    "type": "column",
                                    "studioDevClasses": "",
                                    "projectConfigProperties": [
                                      "name",
                                      "label",
                                      "visibility",
                                      "colClass",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType"
                                    ],
                                    "parentId": null,
                                    "angular": {},
                                    "applicableAttributeLogic": [
                                      "globelLogic",
                                      "elemAttrLogic"
                                    ],
                                    "database": {},
                                    "subtype": "column",
                                    "id": null,
                                    "subDataArray": [
                                      {
                                        "takeOptionsFrom": "optFromService",
                                        "optFromServiceList": null,
                                        "optFromVarList": null,
                                        "values": [
                                          {
                                            "label": "Option 1",
                                            "value": "option-1"
                                          },
                                          {
                                            "label": "Option 2",
                                            "value": "option-2"
                                          },
                                          {
                                            "label": "Option 3",
                                            "value": "option-3"
                                          }
                                        ],
                                        "attributeLogiclayer": [
                                          {
                                            "name": "Globel AttrLogic",
                                            "selAttrs": [

                                            ],
                                            "label": "globelAttrLogic",
                                            "id": null,
                                            "type": "globelAttrLogics",
                                            "value": "globelLogic",
                                            "attrList": [

                                            ]
                                          },
                                          {
                                            "name": "Element AttrLogic",
                                            "selAttrs": [
                                              "label",
                                              "tooltip"
                                            ],
                                            "label": "elemAttrLogic",
                                            "id": null,
                                            "type": "elemAttrLogics",
                                            "value": "elemAttrLogic",
                                            "attrList": [

                                            ]
                                          }
                                        ],
                                        "icon": "fas fa-check-double",
                                        "isCurrentlySelected": true,
                                        "description": "Select",
                                        "optionAttributes": {
                                          "selOptions": [
                                            "*ngFor"
                                          ],
                                          "selOptionsList": [
                                            {
                                              "label": "Loop",
                                              "name": "*ngFor",
                                              "value": "*ngFor",
                                              "type": "",
                                              "id": null,
                                              "optValue": "",
                                              "attrInterface": "",
                                              "attrItemName": "_item",
                                              "attrArrType": "",
                                              "attrArrName": "methodResponse1664356552375?.userlist",
                                              "attrArrIndex": "_index",
                                              "moreAttributes": {
                                                "selOptions": [
                                                  "option_Label",
                                                  "ngValue"
                                                ],
                                                "selOptionsList": [
                                                  {
                                                    "label": "Option Label",
                                                    "value": "option_Label",
                                                    "name": "option_Label",
                                                    "type": "option_Label",
                                                    "id": null,
                                                    "optValue": "_item.username",
                                                    "subDataArray": [

                                                    ],
                                                    "selKeyForBindValue": "username"
                                                  },
                                                  {
                                                    "label": "[ngValue]",
                                                    "value": "ngValue",
                                                    "name": "ngValue",
                                                    "type": "ngValue",
                                                    "id": null,
                                                    "optValue": "_item.userid",
                                                    "subDataArray": [

                                                    ],
                                                    "selKeyForBindValue": "userid"
                                                  }
                                                ]
                                              }
                                            }
                                          ]
                                        },
                                        "className": "form-control",
                                        "handle": true,
                                        "type": "input",
                                        "projectConfigProperties": [
                                          "name",
                                          "label",
                                          "disable",
                                          "visibility",
                                          "starSymbol",
                                          "expandCollapseForGlobal",
                                          "expandCollapseForLabel",
                                          "expandCollapseForCtrl",
                                          "addOption",
                                          "globelAttrLogic",
                                          "controlBindingType",
                                          "formType",
                                          "formGroupName",
                                          "custom_msgAdd",
                                          "allValidationList",
                                          "tooltip",
                                          "selectedEventList",
                                          "combineAllModel",
                                          "databaseName",
                                          "tableName",
                                          "columnName",
                                          "onExcessLoad",
                                          "master"
                                        ],
                                        "parentId": null,
                                        "angular": {
                                          "tooltipTitle": "",
                                          "formType": "reactiveForm",
                                          "validationMsg": "",
                                          "toolTipPosition": "top",
                                          "formGroupName": "serverprofile",
                                          "toolTipEvent": "mouseenter",
                                          "validators": [

                                          ],
                                          "selectedValidatorsForControls": [

                                          ],
                                          "toolTipShow": false
                                        },
                                        "errorText": "Please enter a valid Value",
                                        "applicableAttributeLogic": [
                                          "globelLogic",
                                          "elemAttrLogic"
                                        ],
                                        "database": {
                                          "onExcessLoad": false,
                                          "databaseName": "",
                                          "dbMappingState": "none",
                                          "columnInfo": {

                                          },
                                          "tableName": "",
                                          "columnName": "",
                                          "dbMappingMsg": "",
                                          "master": false
                                        },
                                        "subtype": "select",
                                        "id": "input_1663836491771",
                                        "subDataArray": [

                                        ],
                                        "events": {
                                          "selectedEventList": [

                                          ],
                                          "eventData": [
                                            {
                                              "authorName": "",
                                              "args": "",
                                              "bodyInfo": [
                                                {
                                                  "type": "ExpressionStatement",
                                                  "expression": {
                                                    "type": "CallExpression",
                                                    "callee": {
                                                      "type": "MemberExpression",
                                                      "object": {
                                                        "type": "CallExpression",
                                                        "callee": {
                                                          "type": "MemberExpression",
                                                          "object": {
                                                            "type": "MemberExpression",
                                                            "object": {
                                                              "type": "ThisExpression"
                                                            },
                                                            "property": {
                                                              "type": "Identifier",
                                                              "name": "sendmail"
                                                            },
                                                            "computed": false
                                                          },
                                                          "property": {
                                                            "type": "Identifier",
                                                            "name": "getusername"
                                                          },
                                                          "computed": false
                                                        },
                                                        "arguments": [

                                                        ]
                                                      },
                                                      "property": {
                                                        "type": "Identifier",
                                                        "name": "subscribe"
                                                      },
                                                      "computed": false
                                                    },
                                                    "arguments": [
                                                      {
                                                        "type": "ArrowFunctionExpression",
                                                        "generator": false,
                                                        "id": null,
                                                        "params": [
                                                          {
                                                            "type": "Identifier",
                                                            "name": "res"
                                                          }
                                                        ],
                                                        "body": {
                                                          "type": "BlockStatement",
                                                          "body": [
                                                            {
                                                              "type": "ExpressionStatement",
                                                              "expression": {
                                                                "type": "AssignmentExpression",
                                                                "operator": "=",
                                                                "left": {
                                                                  "type": "MemberExpression",
                                                                  "object": {
                                                                    "type": "ThisExpression"
                                                                  },
                                                                  "property": {
                                                                    "type": "Identifier",
                                                                    "name": "methodResponse1664356552375"
                                                                  },
                                                                  "computed": false,
                                                                  "optional": false
                                                                },
                                                                "right": {
                                                                  "type": "Identifier",
                                                                  "name": "res"
                                                                }
                                                              }
                                                            }
                                                          ]
                                                        },
                                                        "async": false,
                                                        "expression": false
                                                      }
                                                    ]
                                                  }
                                                }
                                              ],
                                              "desc": "",
                                              "eventType": null,
                                              "id": "null_1664356664174",
                                              "methodName": "getServiceProvider",
                                              "nodeType": "",
                                              "nodeName": "getServiceProvider",
                                              "nodeSubType": "method",
                                              "params": ""
                                            }
                                          ]
                                        },
                                        "properties": {
                                          "visibility": true,
                                          "selectedGlobalClassArray": [

                                          ],
                                          "labelClass": "inputlabel_90",
                                          "selectedElementClassArray": [

                                          ],
                                          "defaultGlobelCls": "form_group_label form-group",
                                          "defaultLabelCls": "",
                                          "globelAttrLogic": "",
                                          "selectedTagClassArray": [
                                            "inputlabel_90"
                                          ],
                                          "label": "User",
                                          "globelClasses": "",
                                          "additionElementClass": "",
                                          "additionLabelClass": "",
                                          "disable": false,
                                          "name": "user",
                                          "defaultElementCls": "form-select",
                                          "elementInnerStyles": {

                                          },
                                          "controlBindingType": "static",
                                          "placeholder": "Select",
                                          "labelInnerStyles": {

                                          },
                                          "elementClass": "",
                                          "starSymbol": false,
                                          "globalInnerStyles": {

                                          },
                                          "additionGlobelClasses": ""
                                        },
                                        "windowProperties": [
                                          "name",
                                          "label",
                                          "disable",
                                          "visibility",
                                          "starSymbol",
                                          "expandCollapseForGlobal",
                                          "expandCollapseForLabel",
                                          "expandCollapseForCtrl",
                                          "addOption",
                                          "globelAttrLogic",
                                          "controlBindingType",
                                          "formType",
                                          "formGroupName",
                                          "custom_msgAdd",
                                          "allValidationList",
                                          "tooltip",
                                          "selectedEventList",
                                          "combineAllModel",
                                          "databaseName",
                                          "tableName",
                                          "columnName",
                                          "onExcessLoad",
                                          "master"
                                        ],
                                        "name": "user",
                                        "label": "User",
                                        "sno": 7,
                                        "sag_G_Index": 6,
                                        "bindFromResponseVariable": null
                                      }
                                    ],
                                    "events": {},
                                    "properties": {
                                      "additionElementClass": "",
                                      "visibility": true,
                                      "selectedElementClassArray": [],
                                      "name": "",
                                      "defaultElementCls": "",
                                      "elementInnerStyles": {},
                                      "controlBindingType": "static",
                                      "globelAttrLogic": "",
                                      "label": "Column",
                                      "elementClass": "",
                                      "colClass": "col-sm-6"
                                    },
                                    "windowProperties": [
                                      "name",
                                      "label",
                                      "visibility",
                                      "colClass",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType"
                                    ]
                                  }
                                ],
                                "events": {},
                                "properties": {
                                  "additionElementClass": "",
                                  "visibility": true,
                                  "selectedElementClassArray": [],
                                  "name": "row_1663836480195",
                                  "defaultElementCls": "row",
                                  "elementInnerStyles": {},
                                  "controlBindingType": "static",
                                  "globelAttrLogic": "",
                                  "label": "Row",
                                  "elementClass": ""
                                },
                                "windowProperties": [
                                  "name",
                                  "label",
                                  "visibility",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ]
                              },
                              {
                                "attributeLogiclayer": [
                                  {
                                    "name": "Globel AttrLogic",
                                    "selAttrs": [],
                                    "label": "globelAttrLogic",
                                    "id": null,
                                    "type": "globelAttrLogics",
                                    "value": "globelLogic",
                                    "attrList": []
                                  },
                                  {
                                    "name": "Element AttrLogic",
                                    "selAttrs": [
                                      "label",
                                      "tooltip"
                                    ],
                                    "label": "elemAttrLogic",
                                    "id": null,
                                    "type": "elemAttrLogics",
                                    "value": "elemAttrLogic",
                                    "attrList": []
                                  }
                                ],
                                "icon": "far fa-plus-square",
                                "isCurrentlySelected": false,
                                "description": "Form Group",
                                "handle": true,
                                "parseCtrl": {
                                  "subData": false,
                                  "layerCount": "2",
                                  "layerTopId": "",
                                  "layerCtrls": []
                                },
                                "type": "formGroup",
                                "studioDevClasses": "d-block",
                                "projectConfigProperties": [
                                  "name",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ],
                                "parentId": "sagFormArea0_1663831863232",
                                "angular": {},
                                "database": {},
                                "subtype": "formGroup",
                                "id": "serverprofile",
                                "subDataArray": [],
                                "properties": {
                                  "name": "serverprofile",
                                  "controlBindingType": "static",
                                  "globelAttrLogic": "",
                                  "label": "Form Group"
                                },
                                "events": {},
                                "windowProperties": [
                                  "name",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ]
                              },
                              {
                                "attributeLogiclayer": [
                                  {
                                    "name": "Globel AttrLogic",
                                    "selAttrs": [],
                                    "label": "globelAttrLogic",
                                    "id": null,
                                    "type": "globelAttrLogics",
                                    "value": "globelLogic",
                                    "attrList": []
                                  },
                                  {
                                    "name": "Element AttrLogic",
                                    "selAttrs": [],
                                    "label": "elemAttrLogic",
                                    "id": null,
                                    "type": "elemAttrLogics",
                                    "value": "elemAttrLogic",
                                    "attrList": []
                                  }
                                ],
                                "icon": "fa-columns",
                                "isCurrentlySelected": false,
                                "description": "Row Here",
                                "handle": true,
                                "parseCtrl": {
                                  "subData": true,
                                  "layerCount": "1",
                                  "layerTopId": "row~Element",
                                  "layerCtrls": [
                                    "row~Element"
                                  ]
                                },
                                "type": "row",
                                "studioDevClasses": "",
                                "projectConfigProperties": [
                                  "name",
                                  "label",
                                  "visibility",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ],
                                "parentId": "sagFormArea0_1663831863232",
                                "angular": {},
                                "errorText": "Please enter a valid Value",
                                "applicableAttributeLogic": [
                                  "globelLogic",
                                  "elemAttrLogic"
                                ],
                                "database": {},
                                "subtype": "row",
                                "id": "row_1663836530952",
                                "subDataArray": [
                                  {
                                    "attributeLogiclayer": [
                                      {
                                        "name": "Globel AttrLogic",
                                        "selAttrs": [],
                                        "label": "globelAttrLogic",
                                        "id": null,
                                        "type": "globelAttrLogics",
                                        "value": "globelLogic",
                                        "attrList": []
                                      },
                                      {
                                        "name": "Element AttrLogic",
                                        "selAttrs": [],
                                        "label": "elemAttrLogic",
                                        "id": null,
                                        "type": "elemAttrLogics",
                                        "value": "elemAttrLogic",
                                        "attrList": []
                                      }
                                    ],
                                    "icon": null,
                                    "isCurrentlySelected": false,
                                    "description": "Create Column Here",
                                    "handle": true,
                                    "parseCtrl": {
                                      "subData": true,
                                      "layerCount": "1",
                                      "layerTopId": "column#Globel",
                                      "layerCtrls": [
                                        "column#Globel"
                                      ]
                                    },
                                    "type": "column",
                                    "studioDevClasses": "",
                                    "projectConfigProperties": [
                                      "name",
                                      "label",
                                      "visibility",
                                      "colClass",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType"
                                    ],
                                    "parentId": null,
                                    "angular": {},
                                    "applicableAttributeLogic": [
                                      "globelLogic",
                                      "elemAttrLogic"
                                    ],
                                    "database": {},
                                    "subtype": "column",
                                    "id": null,
                                    "subDataArray": [
                                      {
                                        "attributeLogiclayer": [
                                          {
                                            "name": "Globel AttrLogic",
                                            "selAttrs": [],
                                            "label": "globelAttrLogic",
                                            "id": null,
                                            "type": "globelAttrLogics",
                                            "value": "globelLogic",
                                            "attrList": []
                                          },
                                          {
                                            "name": "Element AttrLogic",
                                            "selAttrs": [
                                              "label",
                                              "tooltip",
                                              "*ngIf"
                                            ],
                                            "label": "elemAttrLogic",
                                            "id": null,
                                            "type": "elemAttrLogics",
                                            "value": "elemAttrLogic",
                                            "attrList": [
                                              {
                                                "optValue": "showDiv == '1'",
                                                "name": "If Block",
                                                "label": "Show/Hide",
                                                "id": null,
                                                "type": "ifBlock",
                                                "finalValue": "",
                                                "value": "*ngIf",
                                                "subDataArray": []
                                              }
                                            ]
                                          }
                                        ],
                                        "icon": "fas fa-share-square",
                                        "isCurrentlySelected": false,
                                        "description": "Row Here",
                                        "handle": true,
                                        "parseCtrl": {
                                          "subData": false,
                                          "layerCount": "5",
                                          "layerTopId": "fieldset#Globel",
                                          "layerCtrls": [
                                            "fieldset#Globel",
                                            "fieldset#LabelPrnt",
                                            "fieldset#Label"
                                          ]
                                        },
                                        "type": "fieldset",
                                        "studioDevClasses": "d-block",
                                        "projectConfigProperties": [
                                          "name",
                                          "label",
                                          "visibility",
                                          "placeholder",
                                          "expandCollapseForGlobal",
                                          "expandCollapseForLabel",
                                          "expandCollapseForCtrl",
                                          "globelAttrLogic",
                                          "controlBindingType",
                                          "formType",
                                          "formGroupName",
                                          "allValidationList",
                                          "tooltip",
                                          "databaseName",
                                          "tableName",
                                          "columnName",
                                          "onExcessLoad",
                                          "master"
                                        ],
                                        "parentId": null,
                                        "angular": {
                                          "tooltipTitle": "",
                                          "formType": "none",
                                          "validationMsg": "",
                                          "toolTipPosition": "top",
                                          "formGroupName": "",
                                          "toolTipEvent": "mouseenter",
                                          "validators": [],
                                          "selectedValidatorsForControls": [],
                                          "toolTipShow": false
                                        },
                                        "errorText": "Please select a valid Div",
                                        "applicableAttributeLogic": [
                                          "globelLogic",
                                          "elemAttrLogic"
                                        ],
                                        "database": {
                                          "onExcessLoad": false,
                                          "databaseName": "",
                                          "dbMappingState": "none",
                                          "columnInfo": {},
                                          "tableName": "",
                                          "columnName": "",
                                          "dbMappingMsg": "",
                                          "master": false
                                        },
                                        "subtype": "fieldset",
                                        "id": "fieldset_1663836542287",
                                        "subDataArray": [
                                          {
                                            "takeOptionsFrom": "optFromStatic",
                                            "values": [
                                              {
                                                "label": "Select",
                                                "value": ""
                                              },
                                              {
                                                "label": "Gmail",
                                                "value": "1"
                                              },
                                              {
                                                "label": "Yahoo",
                                                "value": "2"
                                              },
                                              {
                                                "label": "Hotmail",
                                                "value": "3"
                                              }
                                            ],
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [
                                                  "label",
                                                  "tooltip"
                                                ],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": "fas fa-check-double",
                                            "description": "Select",
                                            "className": "form-control",
                                            "type": "input",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "addOption",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ],
                                            "database": {
                                              "onExcessLoad": false,
                                              "databaseName": "",
                                              "dbMappingState": "none",
                                              "columnInfo": {},
                                              "tableName": "",
                                              "columnName": "",
                                              "dbMappingMsg": "",
                                              "master": false
                                            },
                                            "subtype": "select",
                                            "id": "input_1663836608638",
                                            "events": {
                                              "selectedEventList": [],
                                              "eventData": []
                                            },
                                            "optFromServiceList": null,
                                            "optFromVarList": null,
                                            "isCurrentlySelected": false,
                                            "optionAttributes": null,
                                            "handle": true,
                                            "label": "Service Provider",
                                            "parentId": "fieldset_1663836542287",
                                            "angular": {
                                              "tooltipTitle": "",
                                              "formType": "reactiveForm",
                                              "validationMsg": "",
                                              "toolTipPosition": "top",
                                              "formGroupName": "serverprofile",
                                              "toolTipEvent": "mouseenter",
                                              "validators": [],
                                              "selectedValidatorsForControls": [],
                                              "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "subDataArray": [],
                                            "properties": {
                                              "visibility": true,
                                              "selectedGlobalClassArray": [],
                                              "labelClass": "inputlabel_90",
                                              "selectedElementClassArray": [],
                                              "defaultGlobelCls": "form_group_label form-group",
                                              "defaultLabelCls": "",
                                              "globelAttrLogic": "",
                                              "selectedTagClassArray": [
                                                "inputlabel_90"
                                              ],
                                              "label": "Service Provider",
                                              "globelClasses": "",
                                              "additionElementClass": "",
                                              "additionLabelClass": "",
                                              "disable": false,
                                              "name": "emlsrvrPrvdr",
                                              "defaultElementCls": "form-select",
                                              "elementInnerStyles": {},
                                              "controlBindingType": "static",
                                              "placeholder": "Select",
                                              "labelInnerStyles": {},
                                              "elementClass": "",
                                              "starSymbol": false,
                                              "globalInnerStyles": {},
                                              "additionGlobelClasses": ""
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "addOption",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ]
                                          },
                                          {
                                            "values": [
                                              {
                                                "label": "Option 1",
                                                "value": "option-1"
                                              },
                                              {
                                                "label": "Option 2",
                                                "value": "option-2"
                                              }
                                            ],
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelAttrLogic",
                                                "id": null,
                                                "type": "labelAttrLogics",
                                                "value": "labelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelDivAttrLogic",
                                                "id": null,
                                                "type": "labelDivAttrLogics",
                                                "value": "labelDivLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [
                                                  "label",
                                                  "placeholder"
                                                ],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "elemDivAttrLogic",
                                                "id": null,
                                                "type": "elemDivAttrLogics",
                                                "value": "elemLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": "fa-font",
                                            "isCurrentlySelected": false,
                                            "description": "Enter your name",
                                            "handle": true,
                                            "parseCtrl": {
                                              "subData": false,
                                              "layerCount": "5",
                                              "layerTopId": "input~text#Globel",
                                              "layerCtrls": [
                                                "input~text#Globel",
                                                "input~text#LabelPrnt",
                                                "input~text#Label",
                                                "input~text#ElementPrnt",
                                                "input~text#Element"
                                              ]
                                            },
                                            "label": "Display Name",
                                            "type": "input",
                                            "studioDevClasses": "d-block",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ],
                                            "parentId": "fieldset_1663836542287",
                                            "angular": {
                                              "tooltipTitle": "",
                                              "formType": "reactiveForm",
                                              "validationMsg": "",
                                              "toolTipPosition": "top",
                                              "formGroupName": "serverprofile",
                                              "toolTipEvent": "mouseenter",
                                              "validators": [],
                                              "selectedValidatorsForControls": [],
                                              "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "database": {
                                              "onExcessLoad": false,
                                              "databaseName": "",
                                              "dbMappingState": "none",
                                              "columnInfo": {},
                                              "tableName": "",
                                              "columnName": "",
                                              "dbMappingMsg": "",
                                              "master": false
                                            },
                                            "subtype": "text",
                                            "id": "input_1663836656397",
                                            "subDataArray": [],
                                            "events": {
                                              "selectedEventList": [],
                                              "eventData": []
                                            },
                                            "properties": {
                                              "selectedGlobalClassArray": [],
                                              "labelClass": " inputlabel_90",
                                              "selectedElementClassArray": [],
                                              "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                              "globelAttrLogic": "",
                                              "selectedTagClassArray": [
                                                "inputlabel_90"
                                              ],
                                              "required": false,
                                              "globelClasses": "",
                                              "additionElementClass": "",
                                              "additionLabelClass": "",
                                              "defaultElementCls": "form-control input~text#Element",
                                              "controlBindingType": "static",
                                              "placeholder": "",
                                              "elementClass": "",
                                              "starSymbol": false,
                                              "additionGlobelClasses": "",
                                              "visibility": true,
                                              "defaultLabelCls": "input~text#Label",
                                              "label": "Display Name",
                                              "regex": "",
                                              "disable": false,
                                              "name": "emlsrvrDisname",
                                              "elementInnerStyles": {},
                                              "labelInnerStyles": {},
                                              "globalInnerStyles": {}
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ]
                                          },
                                          {
                                            "values": [
                                              {
                                                "label": "Option 1",
                                                "value": "option-1"
                                              },
                                              {
                                                "label": "Option 2",
                                                "value": "option-2"
                                              }
                                            ],
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelAttrLogic",
                                                "id": null,
                                                "type": "labelAttrLogics",
                                                "value": "labelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelDivAttrLogic",
                                                "id": null,
                                                "type": "labelDivAttrLogics",
                                                "value": "labelDivLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [
                                                  "label",
                                                  "placeholder"
                                                ],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "elemDivAttrLogic",
                                                "id": null,
                                                "type": "elemDivAttrLogics",
                                                "value": "elemLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": "fa-font",
                                            "isCurrentlySelected": false,
                                            "description": "Enter your email",
                                            "handle": true,
                                            "parseCtrl": {
                                              "subData": false,
                                              "layerCount": "5",
                                              "layerTopId": "input~email#Globel",
                                              "layerCtrls": [
                                                "input~text#Globel",
                                                "input~text#LabelPrnt",
                                                "input~text#Label",
                                                "input~text#ElementPrnt",
                                                "input~text#Element"
                                              ]
                                            },
                                            "label": "Email ID",
                                            "type": "input",
                                            "studioDevClasses": "d-block",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ],
                                            "parentId": "fieldset_1663836542287",
                                            "angular": {
                                              "tooltipTitle": "",
                                              "formType": "reactiveForm",
                                              "validationMsg": "",
                                              "toolTipPosition": "top",
                                              "formGroupName": "serverprofile",
                                              "toolTipEvent": "mouseenter",
                                              "validators": [],
                                              "selectedValidatorsForControls": [],
                                              "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "database": {
                                              "onExcessLoad": false,
                                              "databaseName": "",
                                              "dbMappingState": "none",
                                              "columnInfo": {},
                                              "tableName": "",
                                              "columnName": "",
                                              "dbMappingMsg": "",
                                              "master": false
                                            },
                                            "subtype": "email",
                                            "id": "input_1663836694701",
                                            "subDataArray": [],
                                            "events": {
                                              "selectedEventList": [],
                                              "eventData": []
                                            },
                                            "properties": {
                                              "selectedGlobalClassArray": [],
                                              "labelClass": " inputlabel_90",
                                              "selectedElementClassArray": [],
                                              "defaultGlobelCls": "form_group_label form-group input~email#Globel ",
                                              "globelAttrLogic": "",
                                              "selectedTagClassArray": [
                                                "inputlabel_90"
                                              ],
                                              "required": false,
                                              "globelClasses": "",
                                              "additionElementClass": "",
                                              "additionLabelClass": "",
                                              "defaultElementCls": "form-control input~email#Element",
                                              "controlBindingType": "static",
                                              "placeholder": "",
                                              "elementClass": "",
                                              "starSymbol": false,
                                              "additionGlobelClasses": "",
                                              "visibility": true,
                                              "defaultLabelCls": "input~email#Label",
                                              "label": "Email ID",
                                              "regex": "",
                                              "disable": false,
                                              "name": "emlsrvrUsrname",
                                              "elementInnerStyles": {},
                                              "labelInnerStyles": {},
                                              "globalInnerStyles": {}
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ]
                                          },
                                          {
                                            "values": [
                                              {
                                                "label": "Option 1",
                                                "value": "option-1"
                                              },
                                              {
                                                "label": "Option 2",
                                                "value": "option-2"
                                              }
                                            ],
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelAttrLogic",
                                                "id": null,
                                                "type": "labelAttrLogics",
                                                "value": "labelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelDivAttrLogic",
                                                "id": null,
                                                "type": "labelDivAttrLogics",
                                                "value": "labelDivLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [
                                                  "label",
                                                  "placeholder"
                                                ],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "elemDivAttrLogic",
                                                "id": null,
                                                "type": "elemDivAttrLogics",
                                                "value": "elemLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": "fa-font",
                                            "isCurrentlySelected": false,
                                            "description": "Enter your password",
                                            "handle": true,
                                            "parseCtrl": {
                                              "subData": false,
                                              "layerCount": "5",
                                              "layerTopId": "input~password#Globel",
                                              "layerCtrls": [
                                                "input~text#Globel",
                                                "input~text#LabelPrnt",
                                                "input~text#Label",
                                                "input~text#ElementPrnt",
                                                "input~text#Element"
                                              ]
                                            },
                                            "label": "Password",
                                            "type": "input",
                                            "studioDevClasses": "d-block",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ],
                                            "parentId": "fieldset_1663836542287",
                                            "angular": {
                                              "tooltipTitle": "",
                                              "formType": "reactiveForm",
                                              "validationMsg": "",
                                              "toolTipPosition": "top",
                                              "formGroupName": "serverprofile",
                                              "toolTipEvent": "mouseenter",
                                              "validators": [],
                                              "selectedValidatorsForControls": [],
                                              "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "database": {
                                              "onExcessLoad": false,
                                              "databaseName": "",
                                              "dbMappingState": "none",
                                              "columnInfo": {},
                                              "tableName": "",
                                              "columnName": "",
                                              "dbMappingMsg": "",
                                              "master": false
                                            },
                                            "subtype": "password",
                                            "id": "input_1663836718756",
                                            "subDataArray": [],
                                            "events": {
                                              "selectedEventList": [],
                                              "eventData": []
                                            },
                                            "properties": {
                                              "selectedGlobalClassArray": [],
                                              "labelClass": " inputlabel_90",
                                              "selectedElementClassArray": [],
                                              "defaultGlobelCls": "form_group_label form-group input~password#Globel ",
                                              "globelAttrLogic": "",
                                              "selectedTagClassArray": [
                                                "inputlabel_90"
                                              ],
                                              "required": false,
                                              "globelClasses": "",
                                              "additionElementClass": "",
                                              "additionLabelClass": "",
                                              "defaultElementCls": "form-control input~password#Element",
                                              "controlBindingType": "static",
                                              "placeholder": "",
                                              "elementClass": "",
                                              "starSymbol": false,
                                              "additionGlobelClasses": "",
                                              "visibility": true,
                                              "defaultLabelCls": "input~password#Label",
                                              "label": "Password",
                                              "regex": "",
                                              "disable": false,
                                              "name": "emlsrvrPwrd",
                                              "elementInnerStyles": {},
                                              "labelInnerStyles": {},
                                              "globalInnerStyles": {}
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ]
                                          },
                                          {
                                            "values": [
                                              {
                                                "label": "Option 1",
                                                "value": "option-1"
                                              },
                                              {
                                                "label": "Option 2",
                                                "value": "option-2"
                                              }
                                            ],
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelAttrLogic",
                                                "id": null,
                                                "type": "labelAttrLogics",
                                                "value": "labelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelDivAttrLogic",
                                                "id": null,
                                                "type": "labelDivAttrLogics",
                                                "value": "labelDivLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [
                                                  "label",
                                                  "placeholder"
                                                ],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "elemDivAttrLogic",
                                                "id": null,
                                                "type": "elemDivAttrLogics",
                                                "value": "elemLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": "fa-font",
                                            "isCurrentlySelected": false,
                                            "description": "Enter your name",
                                            "handle": true,
                                            "parseCtrl": {
                                              "subData": false,
                                              "layerCount": "5",
                                              "layerTopId": "input~text#Globel",
                                              "layerCtrls": [
                                                "input~text#Globel",
                                                "input~text#LabelPrnt",
                                                "input~text#Label",
                                                "input~text#ElementPrnt",
                                                "input~text#Element"
                                              ]
                                            },
                                            "label": "SMTP Server",
                                            "type": "input",
                                            "studioDevClasses": "d-block",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ],
                                            "parentId": "fieldset_1663836542287",
                                            "angular": {
                                              "tooltipTitle": "",
                                              "formType": "reactiveForm",
                                              "validationMsg": "",
                                              "toolTipPosition": "top",
                                              "formGroupName": "serverprofile",
                                              "toolTipEvent": "mouseenter",
                                              "validators": [],
                                              "selectedValidatorsForControls": [],
                                              "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "database": {
                                              "onExcessLoad": false,
                                              "databaseName": "",
                                              "dbMappingState": "none",
                                              "columnInfo": {},
                                              "tableName": "",
                                              "columnName": "",
                                              "dbMappingMsg": "",
                                              "master": false
                                            },
                                            "subtype": "text",
                                            "id": "input_1663836742835",
                                            "subDataArray": [],
                                            "events": {
                                              "selectedEventList": [],
                                              "eventData": []
                                            },
                                            "properties": {
                                              "selectedGlobalClassArray": [],
                                              "labelClass": " inputlabel_90",
                                              "selectedElementClassArray": [],
                                              "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                              "globelAttrLogic": "",
                                              "selectedTagClassArray": [
                                                "inputlabel_90"
                                              ],
                                              "required": false,
                                              "globelClasses": "",
                                              "additionElementClass": "",
                                              "additionLabelClass": "",
                                              "defaultElementCls": "form-control input~text#Element",
                                              "controlBindingType": "static",
                                              "placeholder": "",
                                              "elementClass": "",
                                              "starSymbol": false,
                                              "additionGlobelClasses": "",
                                              "visibility": true,
                                              "defaultLabelCls": "input~text#Label",
                                              "label": "SMTP Server",
                                              "regex": "",
                                              "disable": false,
                                              "name": "emlsrvrSrvname",
                                              "elementInnerStyles": {},
                                              "labelInnerStyles": {},
                                              "globalInnerStyles": {}
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ]
                                          },
                                          {
                                            "values": [
                                              {
                                                "label": "Option 1",
                                                "value": "option-1"
                                              },
                                              {
                                                "label": "Option 2",
                                                "value": "option-2"
                                              }
                                            ],
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelAttrLogic",
                                                "id": null,
                                                "type": "labelAttrLogics",
                                                "value": "labelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Label Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "labelDivAttrLogic",
                                                "id": null,
                                                "type": "labelDivAttrLogics",
                                                "value": "labelDivLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [
                                                  "label",
                                                  "placeholder"
                                                ],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element Div AttrLogic",
                                                "selAttrs": [],
                                                "label": "elemDivAttrLogic",
                                                "id": null,
                                                "type": "elemDivAttrLogics",
                                                "value": "elemLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": "fa-font",
                                            "isCurrentlySelected": false,
                                            "description": "Enter your name",
                                            "handle": true,
                                            "parseCtrl": {
                                              "subData": false,
                                              "layerCount": "5",
                                              "layerTopId": "input~text#Globel",
                                              "layerCtrls": [
                                                "input~text#Globel",
                                                "input~text#LabelPrnt",
                                                "input~text#Label",
                                                "input~text#ElementPrnt",
                                                "input~text#Element"
                                              ]
                                            },
                                            "label": "Port No.",
                                            "type": "input",
                                            "studioDevClasses": "d-block",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ],
                                            "parentId": "fieldset_1663836542287",
                                            "angular": {
                                              "tooltipTitle": "",
                                              "formType": "reactiveForm",
                                              "validationMsg": "",
                                              "toolTipPosition": "top",
                                              "formGroupName": "serverprofile",
                                              "toolTipEvent": "mouseenter",
                                              "validators": [],
                                              "selectedValidatorsForControls": [],
                                              "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "database": {
                                              "onExcessLoad": false,
                                              "databaseName": "",
                                              "dbMappingState": "none",
                                              "columnInfo": {},
                                              "tableName": "",
                                              "columnName": "",
                                              "dbMappingMsg": "",
                                              "master": false
                                            },
                                            "subtype": "text",
                                            "id": "input_1663836775216",
                                            "subDataArray": [],
                                            "events": {
                                              "selectedEventList": [],
                                              "eventData": []
                                            },
                                            "properties": {
                                              "selectedGlobalClassArray": [],
                                              "labelClass": " inputlabel_90",
                                              "selectedElementClassArray": [],
                                              "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                              "globelAttrLogic": "",
                                              "selectedTagClassArray": [
                                                "inputlabel_90"
                                              ],
                                              "required": false,
                                              "globelClasses": "",
                                              "additionElementClass": "",
                                              "additionLabelClass": "",
                                              "defaultElementCls": "form-control input~text#Element",
                                              "controlBindingType": "static",
                                              "placeholder": "",
                                              "elementClass": "",
                                              "starSymbol": false,
                                              "additionGlobelClasses": "",
                                              "visibility": true,
                                              "defaultLabelCls": "input~text#Label",
                                              "label": "Port No.",
                                              "regex": "",
                                              "disable": false,
                                              "name": "emlsrvrPrtno",
                                              "elementInnerStyles": {},
                                              "labelInnerStyles": {},
                                              "globalInnerStyles": {}
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "placeholder",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ]
                                          },
                                          {
                                            "takeOptionsFrom": "optFromStatic",
                                            "values": [
                                              {
                                                "label": "Use Encryption (SSL)",
                                                "value": "Use Encryption (SSL)"
                                              }
                                            ],
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [
                                                  "label",
                                                  "tooltip"
                                                ],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": "far fa-check-square",
                                            "description": "Checkbox",
                                            "type": "input",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "addOption",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ],
                                            "database": {
                                              "onExcessLoad": false,
                                              "databaseName": "",
                                              "dbMappingState": "none",
                                              "columnInfo": {},
                                              "tableName": "",
                                              "columnName": "",
                                              "dbMappingMsg": "",
                                              "master": false
                                            },
                                            "subtype": "checkbox",
                                            "id": "input_1663836786623",
                                            "events": {
                                              "selectedEventList": [],
                                              "eventData": []
                                            },
                                            "optFromServiceList": null,
                                            "optFromVarList": null,
                                            "isCurrentlySelected": false,
                                            "optionAttributes": null,
                                            "handle": true,
                                            "label": "Checkbox",
                                            "studioDevClasses": "d-block",
                                            "parentId": "fieldset_1663836542287",
                                            "angular": {
                                              "tooltipTitle": "",
                                              "formType": "reactiveForm",
                                              "validationMsg": "",
                                              "toolTipPosition": "top",
                                              "formGroupName": "serverprofile",
                                              "toolTipEvent": "mouseenter",
                                              "validators": [],
                                              "selectedValidatorsForControls": [],
                                              "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "subDataArray": [],
                                            "properties": {
                                              "selectedGlobalClassArray": [],
                                              "labelClass": " inputlabel_0 ",
                                              "selectedElementClassArray": [],
                                              "defaultGlobelCls": "form-group form_group_label d-flex",
                                              "globelAttrLogic": "",
                                              "selectedTagClassArray": [
                                                "inputlabel_0"
                                              ],
                                              "required": false,
                                              "globelClasses": "",
                                              "additionElementClass": "",
                                              "additionLabelClass": "",
                                              "defaultElementCls": "form-check",
                                              "controlBindingType": "static",
                                              "placeholder": "Type your Checkbox to display here ",
                                              "elementClass": "",
                                              "starSymbol": false,
                                              "additionGlobelClasses": "",
                                              "visibility": true,
                                              "defaultLabelCls": "",
                                              "label": "",
                                              "regex": "",
                                              "disable": false,
                                              "name": "emlsrvrSsl",
                                              "elementInnerStyles": {},
                                              "labelInnerStyles": {},
                                              "globalInnerStyles": {}
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "disable",
                                              "visibility",
                                              "starSymbol",
                                              "required",
                                              "regex",
                                              "expandCollapseForGlobal",
                                              "expandCollapseForLabel",
                                              "expandCollapseForCtrl",
                                              "addOption",
                                              "globelAttrLogic",
                                              "controlBindingType",
                                              "formType",
                                              "formGroupName",
                                              "custom_msgAdd",
                                              "allValidationList",
                                              "tooltip",
                                              "selectedEventList",
                                              "combineAllModel",
                                              "databaseName",
                                              "tableName",
                                              "columnName",
                                              "onExcessLoad",
                                              "master"
                                            ]
                                          }
                                        ],
                                        "events": {
                                          "selectedEventList": [],
                                          "eventData": []
                                        },
                                        "properties": {
                                          "visibility": true,
                                          "selectedGlobalClassArray": [],
                                          "selectedElementClassArray": [],
                                          "defaultGlobelCls": "sagFieldSet fieldset#Globel",
                                          "label": "Server Profile Details",
                                          "globelClasses": "",
                                          "additionElementClass": "",
                                          "name": "fieldset_1663836542287",
                                          "defaultElementCls": "fieldset#Element",
                                          "elementInnerStyles": {},
                                          "controlBindingType": "static",
                                          "placeholder": "Paste only Row and Columns",
                                          "labelInnerStyles": {},
                                          "elementClass": "",
                                          "additionGlobelClasses": ""
                                        },
                                        "windowProperties": [
                                          "name",
                                          "label",
                                          "visibility",
                                          "placeholder",
                                          "expandCollapseForGlobal",
                                          "expandCollapseForLabel",
                                          "expandCollapseForCtrl",
                                          "globelAttrLogic",
                                          "controlBindingType",
                                          "formType",
                                          "formGroupName",
                                          "allValidationList",
                                          "tooltip",
                                          "databaseName",
                                          "tableName",
                                          "columnName",
                                          "onExcessLoad",
                                          "master"
                                        ]
                                      },
                                      {
                                        "attributeLogiclayer": [
                                          {
                                            "name": "Globel AttrLogic",
                                            "selAttrs": [],
                                            "label": "globelAttrLogic",
                                            "id": null,
                                            "type": "globelAttrLogics",
                                            "value": "globelLogic",
                                            "attrList": []
                                          },
                                          {
                                            "name": "Element AttrLogic",
                                            "selAttrs": [],
                                            "label": "elemAttrLogic",
                                            "id": null,
                                            "type": "elemAttrLogics",
                                            "value": "elemAttrLogic",
                                            "attrList": []
                                          }
                                        ],
                                        "icon": "fa-columns",
                                        "isCurrentlySelected": false,
                                        "description": "Row Here",
                                        "handle": true,
                                        "parseCtrl": {
                                          "subData": true,
                                          "layerCount": "1",
                                          "layerTopId": "row~Element",
                                          "layerCtrls": [
                                            "row~Element"
                                          ]
                                        },
                                        "type": "row",
                                        "studioDevClasses": "",
                                        "projectConfigProperties": [
                                          "name",
                                          "label",
                                          "visibility",
                                          "expandCollapseForCtrl",
                                          "globelAttrLogic",
                                          "controlBindingType"
                                        ],
                                        "parentId": null,
                                        "angular": {},
                                        "errorText": "Please enter a valid Value",
                                        "applicableAttributeLogic": [
                                          "globelLogic",
                                          "elemAttrLogic"
                                        ],
                                        "database": {},
                                        "subtype": "row",
                                        "id": "row_1663837198267",
                                        "validationClass": true,
                                        "subDataArray": [
                                          {
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": null,
                                            "isCurrentlySelected": false,
                                            "description": "Create Column Here",
                                            "handle": true,
                                            "parseCtrl": {
                                              "subData": true,
                                              "layerCount": "1",
                                              "layerTopId": "column#Globel",
                                              "layerCtrls": [
                                                "column#Globel"
                                              ]
                                            },
                                            "type": "column",
                                            "studioDevClasses": "",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "visibility",
                                              "colClass",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType"
                                            ],
                                            "parentId": "",
                                            "angular": {},
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "database": {},
                                            "subtype": "column",
                                            "id": "column10_1663837198267",
                                            "subDataArray": [
                                              {
                                                "attributeLogiclayer": [
                                                  {
                                                    "name": "Globel AttrLogic",
                                                    "selAttrs": [],
                                                    "label": "globelAttrLogic",
                                                    "id": null,
                                                    "type": "globelAttrLogics",
                                                    "value": "globelLogic",
                                                    "attrList": []
                                                  },
                                                  {
                                                    "name": "Element AttrLogic",
                                                    "selAttrs": [
                                                      "label",
                                                      "tooltip",
                                                      "*ngIf"
                                                    ],
                                                    "label": "elemAttrLogic",
                                                    "id": null,
                                                    "type": "elemAttrLogics",
                                                    "value": "elemAttrLogic",
                                                    "attrList": [
                                                      {
                                                        "optValue": "showDiv == '2'",
                                                        "name": "If Block",
                                                        "label": "Show/Hide",
                                                        "id": null,
                                                        "type": "ifBlock",
                                                        "finalValue": "",
                                                        "value": "*ngIf",
                                                        "subDataArray": []
                                                      }
                                                    ]
                                                  }
                                                ],
                                                "icon": "fas fa-share-square",
                                                "isCurrentlySelected": false,
                                                "description": "Row Here",
                                                "handle": true,
                                                "parseCtrl": {
                                                  "subData": false,
                                                  "layerCount": "5",
                                                  "layerTopId": "fieldset#Globel",
                                                  "layerCtrls": [
                                                    "fieldset#Globel",
                                                    "fieldset#LabelPrnt",
                                                    "fieldset#Label"
                                                  ]
                                                },
                                                "type": "fieldset",
                                                "studioDevClasses": "d-block",
                                                "projectConfigProperties": [
                                                  "name",
                                                  "label",
                                                  "visibility",
                                                  "placeholder",
                                                  "expandCollapseForGlobal",
                                                  "expandCollapseForLabel",
                                                  "expandCollapseForCtrl",
                                                  "globelAttrLogic",
                                                  "controlBindingType",
                                                  "formType",
                                                  "formGroupName",
                                                  "allValidationList",
                                                  "tooltip",
                                                  "databaseName",
                                                  "tableName",
                                                  "columnName",
                                                  "onExcessLoad",
                                                  "master"
                                                ],
                                                "parentId": "",
                                                "angular": {
                                                  "tooltipTitle": "",
                                                  "formType": "none",
                                                  "validationMsg": "",
                                                  "toolTipPosition": "top",
                                                  "formGroupName": "",
                                                  "toolTipEvent": "mouseenter",
                                                  "validators": [],
                                                  "selectedValidatorsForControls": [],
                                                  "toolTipShow": false
                                                },
                                                "errorText": "Please select a valid Div",
                                                "applicableAttributeLogic": [
                                                  "globelLogic",
                                                  "elemAttrLogic"
                                                ],
                                                "database": {
                                                  "onExcessLoad": false,
                                                  "databaseName": "",
                                                  "dbMappingState": "none",
                                                  "columnInfo": {},
                                                  "tableName": "",
                                                  "columnName": "",
                                                  "dbMappingMsg": "",
                                                  "master": false
                                                },
                                                "subtype": "fieldset",
                                                "id": "fieldset20_1663837198267",
                                                "subDataArray": [
                                                  {
                                                    "takeOptionsFrom": "optFromStatic",
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      },
                                                      {
                                                        "label": "Option 3",
                                                        "value": "option-3"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "tooltip"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fas fa-check-double",
                                                    "description": "Select",
                                                    "className": "form-control",
                                                    "type": "input",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "addOption",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "select",
                                                    "id": "input30_1663837198267",
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "optFromServiceList": null,
                                                    "optFromVarList": null,
                                                    "isCurrentlySelected": false,
                                                    "optionAttributes": null,
                                                    "handle": true,
                                                    "label": "Select",
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "subDataArray": [],
                                                    "properties": {
                                                      "visibility": true,
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": "inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group",
                                                      "defaultLabelCls": "",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "label": "Service Provider",
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "disable": false,
                                                      "name": "input30_1663837198267",
                                                      "defaultElementCls": "form-select",
                                                      "elementInnerStyles": {},
                                                      "controlBindingType": "static",
                                                      "placeholder": "Select",
                                                      "labelInnerStyles": {},
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "globalInnerStyles": {},
                                                      "additionGlobelClasses": ""
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "addOption",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your name",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~text#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "text",
                                                    "id": "input31_1663837198267",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~text#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~text#Label",
                                                      "label": "Display Name",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input31_1663837198267",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your email",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~email#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "email",
                                                    "id": "input32_1663837198267",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~email#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~email#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~email#Label",
                                                      "label": "Email",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input32_1663837198267",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your password",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~password#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "password",
                                                    "id": "input33_1663837198268",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~password#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~password#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~password#Label",
                                                      "label": "Password",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input33_1663837198268",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your name",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~text#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "text",
                                                    "id": "input34_1663837198268",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~text#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~text#Label",
                                                      "label": "SMTP Server",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input34_1663837198268",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your name",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~text#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "label": "Text",
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "text",
                                                    "id": "input35_1663837198268",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~text#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~text#Label",
                                                      "label": "Port No.",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input35_1663837198268",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "takeOptionsFrom": "optFromStatic",
                                                    "optFromServiceList": null,
                                                    "optFromVarList": null,
                                                    "values": [
                                                      {
                                                        "label": "Use Encryption (SSL)",
                                                        "value": "Use Encryption (SSL)"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "tooltip"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "far fa-check-square",
                                                    "isCurrentlySelected": false,
                                                    "description": "Checkbox",
                                                    "optionAttributes": null,
                                                    "handle": true,
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "addOption",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "checkbox",
                                                    "id": "input36_1663837198268",
                                                    "subDataArray": [],
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_0 ",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form-group form_group_label d-flex",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_0"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-check",
                                                      "controlBindingType": "static",
                                                      "placeholder": "Type your Checkbox to display here ",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "",
                                                      "label": "",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input36_1663837198268",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "addOption",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "tooltip"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fas fa-heading",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your heading",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "2",
                                                      "layerTopId": "headings~headings#Globel",
                                                      "layerCtrls": [
                                                        "headings~headings#Element"
                                                      ]
                                                    },
                                                    "label": "Message",
                                                    "type": "headings",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "headingType",
                                                      "name",
                                                      "label",
                                                      "visibility",
                                                      "iconPosition",
                                                      "iconClass",
                                                      "animationCss",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset20_1663837198267",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "headings",
                                                    "id": "headings_1663927909817",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "visibility": true,
                                                      "selectedElementClassArray": [],
                                                      "headingValue": "5",
                                                      "animationCss": "",
                                                      "globelAttrLogic": "",
                                                      "label": "Message",
                                                      "required": false,
                                                      "iconClass": "",
                                                      "additionElementClass": "",
                                                      "name": "headings_1663927909817",
                                                      "iconPosition": "before",
                                                      "defaultElementCls": "text-warning",
                                                      "elementInnerStyles": {},
                                                      "controlBindingType": "static",
                                                      "placeholder": null,
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "selectedAnimationArray": []
                                                    },
                                                    "windowProperties": [
                                                      "headingType",
                                                      "name",
                                                      "label",
                                                      "visibility",
                                                      "iconPosition",
                                                      "iconClass",
                                                      "animationCss",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  }
                                                ],
                                                "events": {
                                                  "selectedEventList": [],
                                                  "eventData": []
                                                },
                                                "properties": {
                                                  "visibility": true,
                                                  "selectedGlobalClassArray": [],
                                                  "selectedElementClassArray": [],
                                                  "defaultGlobelCls": "sagFieldSet fieldset#Globel",
                                                  "label": "Server Profile Details",
                                                  "globelClasses": "",
                                                  "additionElementClass": "",
                                                  "name": "fieldset20_1663837198267",
                                                  "defaultElementCls": "fieldset#Element",
                                                  "elementInnerStyles": {},
                                                  "controlBindingType": "static",
                                                  "placeholder": "Paste only Row and Columns",
                                                  "labelInnerStyles": {},
                                                  "elementClass": "",
                                                  "additionGlobelClasses": ""
                                                },
                                                "windowProperties": [
                                                  "name",
                                                  "label",
                                                  "visibility",
                                                  "placeholder",
                                                  "expandCollapseForGlobal",
                                                  "expandCollapseForLabel",
                                                  "expandCollapseForCtrl",
                                                  "globelAttrLogic",
                                                  "controlBindingType",
                                                  "formType",
                                                  "formGroupName",
                                                  "allValidationList",
                                                  "tooltip",
                                                  "databaseName",
                                                  "tableName",
                                                  "columnName",
                                                  "onExcessLoad",
                                                  "master"
                                                ]
                                              }
                                            ],
                                            "events": {},
                                            "properties": {
                                              "additionElementClass": "",
                                              "visibility": true,
                                              "selectedElementClassArray": [],
                                              "name": "column10_1663837198267",
                                              "defaultElementCls": "",
                                              "elementInnerStyles": {},
                                              "controlBindingType": "static",
                                              "globelAttrLogic": "",
                                              "label": "Column",
                                              "elementClass": "",
                                              "colClass": "col-sm-12"
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "visibility",
                                              "colClass",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType"
                                            ]
                                          }
                                        ],
                                        "events": {},
                                        "properties": {
                                          "additionElementClass": "",
                                          "visibility": true,
                                          "selectedElementClassArray": [],
                                          "name": "row_1663837198267",
                                          "defaultElementCls": "row",
                                          "elementInnerStyles": {},
                                          "controlBindingType": "static",
                                          "globelAttrLogic": "",
                                          "label": "Row",
                                          "elementClass": ""
                                        },
                                        "windowProperties": [
                                          "name",
                                          "label",
                                          "visibility",
                                          "expandCollapseForCtrl",
                                          "globelAttrLogic",
                                          "controlBindingType"
                                        ]
                                      },
                                      {
                                        "attributeLogiclayer": [
                                          {
                                            "name": "Globel AttrLogic",
                                            "selAttrs": [],
                                            "label": "globelAttrLogic",
                                            "id": null,
                                            "type": "globelAttrLogics",
                                            "value": "globelLogic",
                                            "attrList": []
                                          },
                                          {
                                            "name": "Element AttrLogic",
                                            "selAttrs": [],
                                            "label": "elemAttrLogic",
                                            "id": null,
                                            "type": "elemAttrLogics",
                                            "value": "elemAttrLogic",
                                            "attrList": []
                                          }
                                        ],
                                        "icon": "fa-columns",
                                        "isCurrentlySelected": false,
                                        "description": "Row Here",
                                        "handle": true,
                                        "parseCtrl": {
                                          "subData": true,
                                          "layerCount": "1",
                                          "layerTopId": "row~Element",
                                          "layerCtrls": [
                                            "row~Element"
                                          ]
                                        },
                                        "type": "row",
                                        "studioDevClasses": "",
                                        "projectConfigProperties": [
                                          "name",
                                          "label",
                                          "visibility",
                                          "expandCollapseForCtrl",
                                          "globelAttrLogic",
                                          "controlBindingType"
                                        ],
                                        "parentId": null,
                                        "angular": {},
                                        "errorText": "Please enter a valid Value",
                                        "applicableAttributeLogic": [
                                          "globelLogic",
                                          "elemAttrLogic"
                                        ],
                                        "database": {},
                                        "subtype": "row",
                                        "id": "row_1663836942469",
                                        "validationClass": true,
                                        "subDataArray": [
                                          {
                                            "attributeLogiclayer": [
                                              {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                              },
                                              {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                              }
                                            ],
                                            "icon": null,
                                            "isCurrentlySelected": false,
                                            "description": "Create Column Here",
                                            "handle": true,
                                            "parseCtrl": {
                                              "subData": true,
                                              "layerCount": "1",
                                              "layerTopId": "column#Globel",
                                              "layerCtrls": [
                                                "column#Globel"
                                              ]
                                            },
                                            "type": "column",
                                            "studioDevClasses": "",
                                            "projectConfigProperties": [
                                              "name",
                                              "label",
                                              "visibility",
                                              "colClass",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType"
                                            ],
                                            "parentId": "",
                                            "angular": {},
                                            "applicableAttributeLogic": [
                                              "globelLogic",
                                              "elemAttrLogic"
                                            ],
                                            "database": {},
                                            "subtype": "column",
                                            "id": "",
                                            "subDataArray": [
                                              {
                                                "attributeLogiclayer": [
                                                  {
                                                    "name": "Globel AttrLogic",
                                                    "selAttrs": [],
                                                    "label": "globelAttrLogic",
                                                    "id": null,
                                                    "type": "globelAttrLogics",
                                                    "value": "globelLogic",
                                                    "attrList": []
                                                  },
                                                  {
                                                    "name": "Element AttrLogic",
                                                    "selAttrs": [
                                                      "label",
                                                      "tooltip",
                                                      "*ngIf"
                                                    ],
                                                    "label": "elemAttrLogic",
                                                    "id": null,
                                                    "type": "elemAttrLogics",
                                                    "value": "elemAttrLogic",
                                                    "attrList": [
                                                      {
                                                        "optValue": "showDiv == '3'",
                                                        "name": "If Block",
                                                        "label": "Show/Hide",
                                                        "id": null,
                                                        "type": "ifBlock",
                                                        "finalValue": "",
                                                        "value": "*ngIf",
                                                        "subDataArray": []
                                                      }
                                                    ]
                                                  }
                                                ],
                                                "icon": "fas fa-share-square",
                                                "isCurrentlySelected": false,
                                                "description": "Row Here",
                                                "handle": true,
                                                "parseCtrl": {
                                                  "subData": false,
                                                  "layerCount": "5",
                                                  "layerTopId": "fieldset#Globel",
                                                  "layerCtrls": [
                                                    "fieldset#Globel",
                                                    "fieldset#LabelPrnt",
                                                    "fieldset#Label"
                                                  ]
                                                },
                                                "type": "fieldset",
                                                "studioDevClasses": "d-block",
                                                "projectConfigProperties": [
                                                  "name",
                                                  "label",
                                                  "visibility",
                                                  "placeholder",
                                                  "expandCollapseForGlobal",
                                                  "expandCollapseForLabel",
                                                  "expandCollapseForCtrl",
                                                  "globelAttrLogic",
                                                  "controlBindingType",
                                                  "formType",
                                                  "formGroupName",
                                                  "allValidationList",
                                                  "tooltip",
                                                  "databaseName",
                                                  "tableName",
                                                  "columnName",
                                                  "onExcessLoad",
                                                  "master"
                                                ],
                                                "parentId": "",
                                                "angular": {
                                                  "tooltipTitle": "",
                                                  "formType": "none",
                                                  "validationMsg": "",
                                                  "toolTipPosition": "top",
                                                  "formGroupName": "",
                                                  "toolTipEvent": "mouseenter",
                                                  "validators": [],
                                                  "selectedValidatorsForControls": [],
                                                  "toolTipShow": false
                                                },
                                                "errorText": "Please select a valid Div",
                                                "applicableAttributeLogic": [
                                                  "globelLogic",
                                                  "elemAttrLogic"
                                                ],
                                                "database": {
                                                  "onExcessLoad": false,
                                                  "databaseName": "",
                                                  "dbMappingState": "none",
                                                  "columnInfo": {},
                                                  "tableName": "",
                                                  "columnName": "",
                                                  "dbMappingMsg": "",
                                                  "master": false
                                                },
                                                "subtype": "fieldset",
                                                "id": "fieldset_1663836957284",
                                                "subDataArray": [
                                                  {
                                                    "takeOptionsFrom": "optFromStatic",
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      },
                                                      {
                                                        "label": "Option 3",
                                                        "value": "option-3"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "tooltip"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fas fa-check-double",
                                                    "description": "Select",
                                                    "className": "form-control",
                                                    "type": "input",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "addOption",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "select",
                                                    "id": "input_1663836984186",
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "optFromServiceList": null,
                                                    "optFromVarList": null,
                                                    "isCurrentlySelected": false,
                                                    "optionAttributes": null,
                                                    "handle": true,
                                                    "label": "Select",
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "subDataArray": [],
                                                    "properties": {
                                                      "visibility": true,
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": "inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group",
                                                      "defaultLabelCls": "",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "label": "Service Provider",
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "disable": false,
                                                      "name": "input_1663836984186",
                                                      "defaultElementCls": "form-select",
                                                      "elementInnerStyles": {},
                                                      "controlBindingType": "static",
                                                      "placeholder": "Select",
                                                      "labelInnerStyles": {},
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "globalInnerStyles": {},
                                                      "additionGlobelClasses": ""
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "addOption",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your name",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~text#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "text",
                                                    "id": "input_1663836990090",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~text#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~text#Label",
                                                      "label": "Display Name",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input_1663836990090",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your email",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~email#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "email",
                                                    "id": "input_1663837000009",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~email#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~email#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~email#Label",
                                                      "label": "Email",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input_1663837000009",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your password",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~password#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "password",
                                                    "id": "input_1663837011928",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~password#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~password#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~password#Label",
                                                      "label": "Password",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input_1663837011928",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your name",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~text#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "text",
                                                    "id": "input_1663837029415",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~text#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~text#Label",
                                                      "label": "SMTP Server",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input_1663837029415",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "values": [
                                                      {
                                                        "label": "Option 1",
                                                        "value": "option-1"
                                                      },
                                                      {
                                                        "label": "Option 2",
                                                        "value": "option-2"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelAttrLogic",
                                                        "id": null,
                                                        "type": "labelAttrLogics",
                                                        "value": "labelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Label Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "labelDivAttrLogic",
                                                        "id": null,
                                                        "type": "labelDivAttrLogics",
                                                        "value": "labelDivLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "placeholder"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element Div AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "elemDivAttrLogic",
                                                        "id": null,
                                                        "type": "elemDivAttrLogics",
                                                        "value": "elemLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fa-font",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your name",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "5",
                                                      "layerTopId": "input~text#Globel",
                                                      "layerCtrls": [
                                                        "input~text#Globel",
                                                        "input~text#LabelPrnt",
                                                        "input~text#Label",
                                                        "input~text#ElementPrnt",
                                                        "input~text#Element"
                                                      ]
                                                    },
                                                    "label": "Text",
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "text",
                                                    "id": "input_1663837035752",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_90",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form_group_label form-group input~text#Globel ",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_90"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-control input~text#Element",
                                                      "controlBindingType": "static",
                                                      "placeholder": "",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "input~text#Label",
                                                      "label": "Port No.",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input_1663837035752",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "placeholder",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "takeOptionsFrom": "optFromStatic",
                                                    "optFromServiceList": null,
                                                    "optFromVarList": null,
                                                    "values": [
                                                      {
                                                        "label": "Use Encryption (SSL)",
                                                        "value": "Use Encryption (SSL)"
                                                      }
                                                    ],
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "tooltip"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "far fa-check-square",
                                                    "isCurrentlySelected": false,
                                                    "description": "Checkbox",
                                                    "optionAttributes": null,
                                                    "handle": true,
                                                    "type": "input",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "addOption",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "checkbox",
                                                    "id": "input_1663837043623",
                                                    "subDataArray": [],
                                                    "properties": {
                                                      "selectedGlobalClassArray": [],
                                                      "labelClass": " inputlabel_0 ",
                                                      "selectedElementClassArray": [],
                                                      "defaultGlobelCls": "form-group form_group_label d-flex",
                                                      "globelAttrLogic": "",
                                                      "selectedTagClassArray": [
                                                        "inputlabel_0"
                                                      ],
                                                      "required": false,
                                                      "globelClasses": "",
                                                      "additionElementClass": "",
                                                      "additionLabelClass": "",
                                                      "defaultElementCls": "form-check",
                                                      "controlBindingType": "static",
                                                      "placeholder": "Type your Checkbox to display here ",
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "additionGlobelClasses": "",
                                                      "visibility": true,
                                                      "defaultLabelCls": "",
                                                      "label": "",
                                                      "regex": "",
                                                      "disable": false,
                                                      "name": "input_1663837043623",
                                                      "elementInnerStyles": {},
                                                      "labelInnerStyles": {},
                                                      "globalInnerStyles": {}
                                                    },
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": []
                                                    },
                                                    "windowProperties": [
                                                      "name",
                                                      "label",
                                                      "disable",
                                                      "visibility",
                                                      "starSymbol",
                                                      "required",
                                                      "regex",
                                                      "expandCollapseForGlobal",
                                                      "expandCollapseForLabel",
                                                      "expandCollapseForCtrl",
                                                      "addOption",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  },
                                                  {
                                                    "attributeLogiclayer": [
                                                      {
                                                        "name": "Globel AttrLogic",
                                                        "selAttrs": [],
                                                        "label": "globelAttrLogic",
                                                        "id": null,
                                                        "type": "globelAttrLogics",
                                                        "value": "globelLogic",
                                                        "attrList": []
                                                      },
                                                      {
                                                        "name": "Element AttrLogic",
                                                        "selAttrs": [
                                                          "label",
                                                          "tooltip"
                                                        ],
                                                        "label": "elemAttrLogic",
                                                        "id": null,
                                                        "type": "elemAttrLogics",
                                                        "value": "elemAttrLogic",
                                                        "attrList": []
                                                      }
                                                    ],
                                                    "icon": "fas fa-heading",
                                                    "isCurrentlySelected": true,
                                                    "description": "Enter your heading",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                      "subData": false,
                                                      "layerCount": "2",
                                                      "layerTopId": "headings~headings#Globel",
                                                      "layerCtrls": [
                                                        "headings~headings#Element"
                                                      ]
                                                    },
                                                    "label": "Whatsapp",
                                                    "type": "headings",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                      "headingType",
                                                      "name",
                                                      "label",
                                                      "visibility",
                                                      "iconPosition",
                                                      "iconClass",
                                                      "animationCss",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ],
                                                    "parentId": "fieldset_1663836957284",
                                                    "angular": {
                                                      "tooltipTitle": "",
                                                      "formType": "none",
                                                      "validationMsg": "",
                                                      "toolTipPosition": "top",
                                                      "formGroupName": "",
                                                      "toolTipEvent": "mouseenter",
                                                      "validators": [],
                                                      "selectedValidatorsForControls": [],
                                                      "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                      "globelLogic",
                                                      "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                      "onExcessLoad": false,
                                                      "databaseName": "",
                                                      "dbMappingState": "none",
                                                      "columnInfo": {},
                                                      "tableName": "",
                                                      "columnName": "",
                                                      "dbMappingMsg": "",
                                                      "master": false
                                                    },
                                                    "subtype": "headings",
                                                    "id": "headings_1663927936177",
                                                    "subDataArray": [],
                                                    "events": {
                                                      "selectedEventList": [],
                                                      "eventData": [
                                                        {
                                                          "authorName": "",
                                                          "args": "",
                                                          "bodyInfo": [],
                                                          "desc": "",
                                                          "eventType": null,
                                                          "id": "",
                                                          "methodName": "onnullheadings1663927936176",
                                                          "nodeType": "",
                                                          "nodeName": "onnullheadings1663927936176",
                                                          "nodeSubType": "method",
                                                          "params": ""
                                                        }
                                                      ]
                                                    },
                                                    "properties": {
                                                      "visibility": true,
                                                      "selectedElementClassArray": [],
                                                      "headingValue": "5",
                                                      "animationCss": "",
                                                      "globelAttrLogic": "",
                                                      "label": "Whatsapp",
                                                      "required": false,
                                                      "iconClass": "",
                                                      "additionElementClass": "",
                                                      "name": "headings_1663927936176",
                                                      "iconPosition": "before",
                                                      "defaultElementCls": "text-warning",
                                                      "elementInnerStyles": {},
                                                      "controlBindingType": "static",
                                                      "placeholder": null,
                                                      "elementClass": "",
                                                      "starSymbol": false,
                                                      "selectedAnimationArray": []
                                                    },
                                                    "windowProperties": [
                                                      "headingType",
                                                      "name",
                                                      "label",
                                                      "visibility",
                                                      "iconPosition",
                                                      "iconClass",
                                                      "animationCss",
                                                      "expandCollapseForCtrl",
                                                      "globelAttrLogic",
                                                      "controlBindingType",
                                                      "formType",
                                                      "formGroupName",
                                                      "custom_msgAdd",
                                                      "allValidationList",
                                                      "tooltip",
                                                      "selectedEventList",
                                                      "combineAllModel",
                                                      "databaseName",
                                                      "tableName",
                                                      "columnName",
                                                      "onExcessLoad",
                                                      "master"
                                                    ]
                                                  }
                                                ],
                                                "events": {
                                                  "selectedEventList": [],
                                                  "eventData": []
                                                },
                                                "properties": {
                                                  "visibility": true,
                                                  "selectedGlobalClassArray": [],
                                                  "selectedElementClassArray": [],
                                                  "defaultGlobelCls": "sagFieldSet fieldset#Globel",
                                                  "label": "Server Profile Details",
                                                  "globelClasses": "",
                                                  "additionElementClass": "",
                                                  "name": "fieldset_1663836957284",
                                                  "defaultElementCls": "fieldset#Element",
                                                  "elementInnerStyles": {},
                                                  "controlBindingType": "static",
                                                  "placeholder": "Paste only Row and Columns",
                                                  "labelInnerStyles": {},
                                                  "elementClass": "",
                                                  "additionGlobelClasses": ""
                                                },
                                                "windowProperties": [
                                                  "name",
                                                  "label",
                                                  "visibility",
                                                  "placeholder",
                                                  "expandCollapseForGlobal",
                                                  "expandCollapseForLabel",
                                                  "expandCollapseForCtrl",
                                                  "globelAttrLogic",
                                                  "controlBindingType",
                                                  "formType",
                                                  "formGroupName",
                                                  "allValidationList",
                                                  "tooltip",
                                                  "databaseName",
                                                  "tableName",
                                                  "columnName",
                                                  "onExcessLoad",
                                                  "master"
                                                ]
                                              }
                                            ],
                                            "events": {},
                                            "properties": {
                                              "additionElementClass": "",
                                              "visibility": true,
                                              "selectedElementClassArray": [],
                                              "name": "",
                                              "defaultElementCls": "",
                                              "elementInnerStyles": {},
                                              "controlBindingType": "static",
                                              "globelAttrLogic": "",
                                              "label": "Column",
                                              "elementClass": "",
                                              "colClass": "col-sm-12"
                                            },
                                            "windowProperties": [
                                              "name",
                                              "label",
                                              "visibility",
                                              "colClass",
                                              "expandCollapseForCtrl",
                                              "globelAttrLogic",
                                              "controlBindingType"
                                            ]
                                          }
                                        ],
                                        "events": {},
                                        "properties": {
                                          "additionElementClass": "",
                                          "visibility": true,
                                          "selectedElementClassArray": [],
                                          "name": "row_1663836942469",
                                          "defaultElementCls": "row",
                                          "elementInnerStyles": {},
                                          "controlBindingType": "static",
                                          "globelAttrLogic": "",
                                          "label": "Row",
                                          "elementClass": ""
                                        },
                                        "windowProperties": [
                                          "name",
                                          "label",
                                          "visibility",
                                          "expandCollapseForCtrl",
                                          "globelAttrLogic",
                                          "controlBindingType"
                                        ]
                                      }
                                    ],
                                    "events": {},
                                    "properties": {
                                      "additionElementClass": "",
                                      "visibility": true,
                                      "selectedElementClassArray": [],
                                      "name": "",
                                      "defaultElementCls": "",
                                      "elementInnerStyles": {},
                                      "controlBindingType": "static",
                                      "globelAttrLogic": "",
                                      "label": "Column",
                                      "elementClass": "",
                                      "colClass": "col-sm-6"
                                    },
                                    "windowProperties": [
                                      "name",
                                      "label",
                                      "visibility",
                                      "colClass",
                                      "expandCollapseForCtrl",
                                      "globelAttrLogic",
                                      "controlBindingType"
                                    ]
                                  }
                                ],
                                "events": {},
                                "properties": {
                                  "additionElementClass": "",
                                  "visibility": true,
                                  "selectedElementClassArray": [],
                                  "name": "row_1663836530952",
                                  "defaultElementCls": "row",
                                  "elementInnerStyles": {},
                                  "controlBindingType": "static",
                                  "globelAttrLogic": "",
                                  "label": "Row",
                                  "elementClass": ""
                                },
                                "windowProperties": [
                                  "name",
                                  "label",
                                  "visibility",
                                  "expandCollapseForCtrl",
                                  "globelAttrLogic",
                                  "controlBindingType"
                                ]
                              }
                            ],
                            "events": {},
                            "properties": {
                              "additionElementClass": "",
                              "selectedElementClassArray": [],
                              "name": "sagFormArea0_1663831863232",
                              "defaultElementCls": "form-area sagFormArea#Globel",
                              "elementInnerStyles": {},
                              "controlBindingType": "static",
                              "globelAttrLogic": "",
                              "label": "sagFormArea",
                              "elementClass": ""
                            },
                            "windowProperties": [
                              "name",
                              "expandCollapseForCtrl",
                              "globelAttrLogic",
                              "controlBindingType"
                            ]
                          }
                        ],
                        "projectConfigProperties": [
                          "name",
                          "expandCollapseForGlobal",
                          "expandCollapseForCtrl",
                          "globelAttrLogic",
                          "controlBindingType"
                        ],
                        "parentId": "pageContainer_1663831800058",
                        "angular": {},
                        "errorText": "Please select a valid Footer Area",
                        "applicableAttributeLogic": [
                          "globelLogic",
                          "elemAttrLogic"
                        ],
                        "database": {},
                        "sagGridArea": [],
                        "subtype": "sagPage",
                        "id": "sagPage_1663831863232",
                        "subDataArray": [],
                        "events": {},
                        "properties": {
                          "selectedGlobalClassArray": [],
                          "selectedElementClassArray": [],
                          "defaultGlobelCls": "main-body d-flex flex-column h-100  flexOne sagPage#Globel",
                          "globelAttrLogic": "",
                          "label": "Sag Page",
                          "globelClasses": "",
                          "additionElementClass": "",
                          "name": "sagPage_1663831863232",
                          "defaultElementCls": "card main-card p-2 d-flex flex-column h-100 coverPage sagPage#Element",
                          "elementInnerStyles": {},
                          "controlBindingType": "static",
                          "elementClass": "",
                          "globalInnerStyles": {},
                          "additionGlobelClasses": ""
                        },
                        "windowProperties": [
                          "name",
                          "expandCollapseForGlobal",
                          "expandCollapseForCtrl",
                          "globelAttrLogic",
                          "controlBindingType"
                        ]
                      }
                    ],
                    "properties": {
                      "additionElementClass": "",
                      "visibility": true,
                      "selectedElementClassArray": [],
                      "name": "",
                      "controlBindingType": "static",
                      "defaultElementCls": "d-flex flex-column full-modal h-100 pageContainer#Globel",
                      "elementInnerStyles": {},
                      "globelAttrLogic": "",
                      "label": "Page Container",
                      "elementClass": ""
                    },
                    "events": {
                      "selectedEventList": [],
                      "eventData": []
                    },
                    "windowProperties": [
                      "name",
                      "label",
                      "visibility",
                      "expandCollapseForCtrl",
                      "globelAttrLogic",
                      "controlBindingType",
                      "selectedEventList",
                      "combineAllModel"
                    ]
                  }
                ],
                "properties": {
                  "additionElementClass": "",
                  "visibility": true,
                  "selectedElementClassArray": [],
                  "name": "",
                  "controlBindingType": "static",
                  "defaultElementCls": "d-flex flex-column full-modal h-100 pageContainer#Globel",
                  "elementInnerStyles": {},
                  "globelAttrLogic": "",
                  "label": "Page Container",
                  "elementClass": ""
                },
                "events": {
                  "selectedEventList": [],
                  "eventData": []
                },
                "windowProperties": [
                  "name",
                  "label",
                  "visibility",
                  "expandCollapseForCtrl",
                  "globelAttrLogic",
                  "controlBindingType",
                  "selectedEventList",
                  "combineAllModel"
                ]
              }
            ],
            "properties": {
              "additionElementClass": "",
              "visibility": true,
              "selectedElementClassArray": [],
              "name": "",
              "controlBindingType": "static",
              "defaultElementCls": "d-flex flex-column full-modal h-100 pageContainer#Globel",
              "elementInnerStyles": {},
              "globelAttrLogic": "",
              "label": "Page Container",
              "elementClass": ""
            },
            "events": {
              "selectedEventList": [],
              "eventData": []
            },
            "windowProperties": [
              "name",
              "label",
              "visibility",
              "expandCollapseForCtrl",
              "globelAttrLogic",
              "controlBindingType",
              "selectedEventList",
              "combineAllModel"
            ]
          }
        ],
        "cssData": {},
        "tsData": {
          "diInConstructor": [
            {
              "diName": "SendmailService",
              "diType": "public",
              "diShortName": "sendmail",
              "diImportPath": "src/app/custommodules/sendmail/sendmail.share.service"
            }
          ],
          "varAndMethodList": [
            {
              name: `initializeForm`,
              type: 'MethodDefinition'
            },
            {
              name: `ngAfterViewInit`,
              type: 'MethodDefinition'
            },
            {
              name: `ngOnInit`,
              type: 'MethodDefinition'
            },
          ],
          "writeTsCode": `
                    
                    ngOnInit() {
                      this.initializeForm();
                      this.getServiceProvider();
                    };
                    
                    ngAfterViewInit() { 
                        this.serverprofile.controls['emlProfiletype'].patchValue(this.showDiv)
                      };
                      \n


                    serverprofile: FormGroup;
                    \ninitializeForm() {
                      this.serverprofile = this._formBuilder.group({
                        emlProfiletype: [''], 
                        user: [''], 
                        emlsrvrPrvdr: [''], 
                        emlsrvrDisname: [''], 
                        emlsrvrUsrname: [''], 
                        emlsrvrPwrd: [''], 
                        emlsrvrSrvname: [''], 
                        emlsrvrPrtno: [''], 
                        emlsrvrSsl: [''],
                      });
                    }\n

                    savemail() {
                      let postData = {
                        "id": 0,
                        "mmwprofType": parseInt(this.serverprofile.controls['emlProfiletype'].value),
                        "mmwprofPrvdr": parseInt(this.serverprofile.controls['emlsrvrPrvdr'].value),
                        "mmwprofDisname": this.serverprofile.controls['emlsrvrDisname'].value,
                        "mmwprofUsrname": this.serverprofile.controls['emlsrvrUsrname'].value,
                        "mmwprofPwrd": this.serverprofile.controls['emlsrvrPwrd'].value,
                        "mmwprofSrvname": this.serverprofile.controls['emlsrvrSrvname'].value,
                        "mmwprofPrtno": this.serverprofile.controls['emlsrvrPrtno'].value,
                        "mmwprofSsl": this.serverprofile.controls['emlsrvrSsl'].setValue(this.serverprofile.controls['emlsrvrSsl'].value ? 1 : 0),
                        "txnUmmwprof": [{
                            "userId" : this.serverprofile.controls['user'].value        
                          }
                        ]
                      }
                        this.sendmail.saveProfile(postData).subscribe(res => {
                            this._toast.launch_toast({
                                type: 'success',
                                position: 'bottom-right',
                                message: res['message'],
                            });
                        });
                    }

                    \n
                    showDiv: string = '1';
                    checkProvideType(evt , val){
                        this.showDiv = evt.target.value;
                    }


                    methodResponse1664356552375: any; 
                    getServiceProvider() {
                      this.sendmail.getusername().subscribe(res => {
                        this.methodResponse1664356552375 = res;
                      });
                    }
                    `,
        },
        "routingData": {},
        "moduleData": {}
      },

    },
    {
      "ngGenerate": {
        "ngType": "service",
        "ngName": "sendmail",
        "ngAuthor": "sagDev",
        "ngDesc": "send Mail Service File",
        "ngServiceType": "provideAsShareService",
      },
      "creationPath": "/src/app/custommodules/sendmail",
      "data": {
        "serviceData": {
          "varAndMethodList": [],
          "writeTsCode": ``,
          "sharedData": [
            { "varName": "receiverEmailId" },
            { "varName": "messageSubject" },
            { "varName": "messageBody" }
          ],
          "subDataArray": [
            {
              "type": "customCode",
              "icon": "fas fa-laptop-code",
              "label": "custom Code",
              "description": "Code Here",
              "placeholder": "Custom Code Here..",
              "className": "",
              "classValue": "",
              "SMclassValue": "",
              "MDclassValue": "",
              "LGclassValue": "",
              "XLclassValue": "",
              "labelClasses": "",
              "angular": {
                "appliedEvents": [

                ],
                "events": [

                ]
              },
              "properties": {
                "innerStyles": {},
                "globalInnerStyles": {},
                "elementInnerStyles": {},
                "labelInnerStyles": {},
                "innerText": "",
                "classes": "",
                "innerStylesString": "",
                "propertyOption2": null,
                "propertyOption3": null,
                "propertyOption4": null,
                "propertyOption5": null
              },
              "subtype": "customCode",
              "subDataArray": [

              ],
              //"customCodeBody": "showPage: boolean = false;",
              "customCodeBody": "hello()",
              "domNodeTag": [

              ],
              "regex": null,
              "handle": true,
              "elementId": null,
              "id": "customCode_1655446732102",
              "parentId": null,
              "isCurrentlySelected": false,
              "option5": null,
              "star_Symbol": false,
              "required": false,
              "toolTip": "i am Toop Tip",
              "toolTipShow": false,
              "errorText": "Please select a valid Div",
              "globelClasses": "",
              "selectedGlobalClassArray": [

              ],
              "additionGlobelClasses": "",
              "defaultGlobelCls": "sagFieldSet",
              "elementClass": "",
              "selectedElementClassArray": [

              ],
              "additionElementClass": "",
              "defaultElementCls": "",
              "visibility": false,
              "windowProperties": [
                "label",
                "name",
                "defaultGlobelCls",
                "additionGlobelClasses",
                "globelClasses",
                "expandCollapseIcon",
                "extraElementClass",
                "innerStyles"
              ],
              "name": "customCode_1655446732102"
            }
          ]

        }
      }

    }
  ]
}