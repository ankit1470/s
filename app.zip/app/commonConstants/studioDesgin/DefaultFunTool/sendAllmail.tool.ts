export const sendAllMailTool = {
    "type": "defaultCompPage",
    "subtype": "defaultCompPage",
    "icon": "fa-columns",
    "label": "col",
    "ctrlId": 'sendallmail',
    "path": "/src/app/custommodules/",
    "defaultCompData": [
        {
            "ngGenerate": {
                "ngType": "page",
                "ngName": "sendallmail",
                "ngAuthor": "sagDev",
                "ngDesc": "send Mail Folder with file",
                "ngServiceType": "",
            },
            "creationPath": "/src/app/custommodules",
            "data": {
                "htmlData": [
                    /* {
                        "attributeLogiclayer": [
                            {
                                "name": "Globel AttrLogic",
                                "selAttrs": [],
                                "label": "globelAttrLogic",
                                "id": null,
                                "type": "globelAttrLogics",
                                "value": "globelLogic",
                                "attrList": []
                            },
                            {
                                "name": "Element AttrLogic",
                                "selAttrs": [
                                    "label",
                                    "tooltip"
                                ],
                                "label": "elemAttrLogic",
                                "id": null,
                                "type": "elemAttrLogics",
                                "value": "elemAttrLogic",
                                "attrList": []
                            }
                        ],
                        "icon": "fa-columns",
                        "isCurrentlySelected": false,
                        "description": "Page Container",
                        "parseCtrl": {
                            "subData": true,
                            "layerCount": "1",
                            "layerTopId": "pageContainer#Globel",
                            "layerCtrls": [
                                "pageContainer#Globel"
                            ]
                        },
                        "type": "pageContainer",
                        "studioDevClasses": "d-block",
                        "projectConfigProperties": [
                            "name",
                            "label",
                            "visibility",
                            "expandCollapseForCtrl",
                            "globelAttrLogic",
                            "controlBindingType",
                            "selectedEventList",
                            "combineAllModel"
                        ],
                        "parentId": null,
                        "angular": {},
                        "errorText": "Please select a valid Div",
                        "applicableAttributeLogic": [
                            "globelLogic",
                            "elemAttrLogic"
                        ],
                        "database": {},
                        "subtype": "div",
                        "id": null,
                        "subDataArray": [
                            {
                                "type": "bootstrapModals",
                                "icon": "fas fa-window-maximize",
                                "description": "BootStrap Models",
                                "subtype": "bootstrapModals",
                                "handle": true,
                                "studioDevClasses": "d-block",
                                "children": [],
                                "angular": {
                                    "formType": "none",
                                    "formGroupName": "",
                                    "validationMsg": "",
                                    "validators": [],
                                    "selectedValidatorsForControls": [],
                                    "toolTip": "i am Toop Tip",
                                    "tooltipTitle": "",
                                    "toolTipShow": false,
                                    "toolTipPosition": "top",
                                    "toolTipEvent": "mouseenter"
                                },
                                "events": {
                                    "selectedEventList": [],
                                    "eventData": []
                                },
                                "database": {
                                    "databaseName": "",
                                    "tableName": "",
                                    "columnName": "",
                                    "columnInfo": {},
                                    "dbMappingState": "none",
                                    "dbMappingMsg": "",
                                    "onExcessLoad": false,
                                    "master": false
                                },
                                "properties": {
                                    "label": "Bootstrap Modals",
                                    "name": "usersendallmail",
                                    "placeholder": "bootstrap Modals",
                                    "modalPosition": "sagModal_top",
                                    "backDrop": true,
                                    "visibility": true,
                                    "globelClasses": "",
                                    "selectedGlobalClassArray": [],
                                    "additionGlobelClasses": "",
                                    "defaultGlobelCls": "modal-dialog modal-dialog-centered",
                                    "globalInnerStyles": {},
                                    "globelAttrLogic": "",
                                    "controlBindingType": "static"
                                },
                                "parseCtrl": {
                                    "subData": false,
                                    "layerTopId": "bootstrapModals~bootstrapModals#Globel",
                                    "layerCount": "2",
                                    "layerCtrls": [
                                        "bootstrapModals~bootstrapModals#Globel",
                                        "bootstrapModals~bootstrapModals#Element"
                                    ]
                                },
                                "modelHeader": {
                                    "type": "modelHeader",
                                    "icon": "fa-columns",
                                    "description": "modelHeader Here",
                                    "subtype": "modelHeader",
                                    "handle": true,
                                    "studioDevClasses": "d-block",
                                    "angular": {
                                        "formType": "none",
                                        "formGroupName": "",
                                        "validationMsg": "",
                                        "validators": [],
                                        "selectedValidatorsForControls": [],
                                        "toolTip": "i am Toop Tip",
                                        "tooltipTitle": "",
                                        "toolTipShow": false,
                                        "toolTipPosition": "top",
                                        "toolTipEvent": "mouseenter"
                                    },
                                    "events": {
                                        "selectedEventList": [],
                                        "eventData": []
                                    },
                                    "database": {
                                        "databaseName": "",
                                        "tableName": "",
                                        "columnName": "",
                                        "columnInfo": {},
                                        "dbMappingState": "none",
                                        "dbMappingMsg": "",
                                        "onExcessLoad": false,
                                        "master": false
                                    },
                                    "properties": {
                                        "label": "modelHeader",
                                        "placeholder": " ",
                                        "name": "",
                                        "starSymbol": false,
                                        "required": false,
                                        "visibility": true,
                                        "validationClass": true,
                                        "elementClass": "",
                                        "selectedElementClassArray": [],
                                        "additionElementClass": "",
                                        "defaultElementCls": "modal-header p-2",
                                        "elementInnerStyles": {},
                                        "globelAttrLogic": "",
                                        "controlBindingType": "static"
                                    },
                                    "parseCtrl": {
                                        "subData": false,
                                        "layerTopId": "modelHeader~modelHeader#Globel",
                                        "layerCount": "2",
                                        "layerCtrls": [
                                            "modelHeader~modelHeader#Globel",
                                            "modelHeader~modelHeader#Element"
                                        ]
                                    },
                                    "subDataArray": [
                                        {
                                            "type": "headings",
                                            "icon": "fas fa-heading",
                                            "description": "Enter your heading",
                                            "subtype": "headings",
                                            "handle": true,
                                            "studioDevClasses": "d-block",
                                            "angular": {
                                                "formType": "none",
                                                "formGroupName": "",
                                                "validationMsg": "",
                                                "validators": [],
                                                "selectedValidatorsForControls": [],
                                                "tooltipTitle": "",
                                                "toolTipShow": false,
                                                "toolTipPosition": "top",
                                                "toolTipEvent": "mouseenter"
                                            },
                                            "events": {
                                                "selectedEventList": [],
                                                "eventData": []
                                            },
                                            "database": {
                                                "databaseName": "",
                                                "tableName": "",
                                                "columnName": "",
                                                "columnInfo": {},
                                                "dbMappingState": "none",
                                                "dbMappingMsg": "",
                                                "onExcessLoad": false,
                                                "master": false
                                            },
                                            "properties": {
                                                "label": "Send All Mail",
                                                "placeholder": null,
                                                "name": "headings_1666091158802",
                                                "starSymbol": false,
                                                "visibility": true,
                                                "required": false,
                                                "iconPosition": "before",
                                                "iconClass": "",
                                                "animationCss": "",
                                                "headingValue": "5",
                                                "selectedAnimationArray": [],
                                                "elementClass": "",
                                                "selectedElementClassArray": [],
                                                "additionElementClass": "",
                                                "defaultElementCls": "text-dark",
                                                "elementInnerStyles": {},
                                                "globelAttrLogic": "",
                                                "controlBindingType": "static"
                                            },
                                            "parseCtrl": {
                                                "subData": false,
                                                "layerTopId": "headings~headings#Globel",
                                                "layerCount": "2",
                                                "layerCtrls": [
                                                    "headings~headings#Element"
                                                ]
                                            },
                                            "subDataArray": [],
                                            "id": "headings_1666091158802",
                                            "parentId": null,
                                            "isCurrentlySelected": false,
                                            "errorText": "Please enter a valid Value",
                                            "projectConfigProperties": [
                                                "headingType",
                                                "name",
                                                "label",
                                                "visibility",
                                                "iconPosition",
                                                "iconClass",
                                                "animationCss",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType",
                                                "formType",
                                                "formGroupName",
                                                "custom_msgAdd",
                                                "allValidationList",
                                                "tooltip",
                                                "selectedEventList",
                                                "combineAllModel",
                                                "databaseName",
                                                "tableName",
                                                "columnName",
                                                "onExcessLoad",
                                                "master"
                                            ],
                                            "windowProperties": [
                                                "headingType",
                                                "name",
                                                "label",
                                                "visibility",
                                                "iconPosition",
                                                "iconClass",
                                                "animationCss",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType",
                                                "formType",
                                                "formGroupName",
                                                "custom_msgAdd",
                                                "allValidationList",
                                                "tooltip",
                                                "selectedEventList",
                                                "combineAllModel",
                                                "databaseName",
                                                "tableName",
                                                "columnName",
                                                "onExcessLoad",
                                                "master"
                                            ],
                                            "attributeLogiclayer": [
                                                {
                                                    "label": "globelAttrLogic",
                                                    "name": "Globel AttrLogic",
                                                    "value": "globelLogic",
                                                    "type": "globelAttrLogics",
                                                    "id": null,
                                                    "selAttrs": [],
                                                    "attrList": []
                                                },
                                                {
                                                    "label": "elemAttrLogic",
                                                    "name": "Element AttrLogic",
                                                    "value": "elemAttrLogic",
                                                    "type": "elemAttrLogics",
                                                    "id": null,
                                                    "selAttrs": [
                                                        "label",
                                                        "tooltip"
                                                    ],
                                                    "attrList": []
                                                }
                                            ],
                                            "applicableAttributeLogic": [
                                                "globelLogic",
                                                "elemAttrLogic"
                                            ],
                                            "label": "Send All Mail"
                                        }
                                    ],
                                    "id": null,
                                    "parentId": null,
                                    "isCurrentlySelected": false,
                                    "errorText": "Please enter a valid Value",
                                    "projectConfigProperties": [
                                        "visibility",
                                        "tooltip"
                                    ],
                                    "windowProperties": [
                                        "name",
                                        "label",
                                        "visibility",
                                        "expandCollapseForCtrl",
                                        "globelAttrLogic",
                                        "controlBindingType"
                                    ],
                                    "attributeLogiclayer": [
                                        {
                                            "label": "globelAttrLogic",
                                            "name": "Globel AttrLogic",
                                            "value": "globelLogic",
                                            "type": "globelAttrLogics",
                                            "id": null,
                                            "selAttrs": [],
                                            "attrList": []
                                        },
                                        {
                                            "label": "elemAttrLogic",
                                            "name": "Element AttrLogic",
                                            "value": "elemAttrLogic",
                                            "type": "elemAttrLogics",
                                            "id": null,
                                            "selAttrs": [
                                                "label",
                                                "tooltip"
                                            ],
                                            "attrList": []
                                        }
                                    ],
                                    "applicableAttributeLogic": [
                                        "globelLogic",
                                        "elemAttrLogic"
                                    ]
                                },
                                "modelBody": {
                                    "type": "modelBody",
                                    "icon": "fa-columns",
                                    "description": "modelBody Here",
                                    "subtype": "modelBody",
                                    "handle": true,
                                    "studioDevClasses": "d-block",
                                    "angular": {
                                        "formType": "none",
                                        "formGroupName": "",
                                        "validationMsg": "",
                                        "validators": [],
                                        "selectedValidatorsForControls": [],
                                        "toolTip": "i am Toop Tip",
                                        "tooltipTitle": "",
                                        "toolTipShow": false,
                                        "toolTipPosition": "top",
                                        "toolTipEvent": "mouseenter"
                                    },
                                    "events": {
                                        "selectedEventList": [],
                                        "eventData": []
                                    },
                                    "database": {
                                        "databaseName": "",
                                        "tableName": "",
                                        "columnName": "",
                                        "columnInfo": {},
                                        "dbMappingState": "none",
                                        "dbMappingMsg": "",
                                        "onExcessLoad": false,
                                        "master": false
                                    },
                                    "properties": {
                                        "label": "modelBody",
                                        "name": "",
                                        "required": false,
                                        "visibility": true,
                                        "validationClass": true,
                                        "elementClass": "",
                                        "selectedElementClassArray": [],
                                        "additionElementClass": "",
                                        "defaultElementCls": "modal-body h-100 d-flex flex-column",
                                        "elementInnerStyles": {},
                                        "globelAttrLogic": "",
                                        "controlBindingType": "static"
                                    },
                                    "parseCtrl": {
                                        "subData": false,
                                        "layerTopId": "modelBody~modelBody#Globel",
                                        "layerCount": "2",
                                        "layerCtrls": [
                                            "modelBody~modelBody#Globel",
                                            "modelBody~modelBody#Element"
                                        ]
                                    },
                                    "subDataArray": [
                                        {
                                            "type": "row",
                                            "icon": "fa-columns",
                                            "description": "Row Here",
                                            "subtype": "row",
                                            "handle": true,
                                            "studioDevClasses": "",
                                            "validationClass": true,
                                            "angular": {},
                                            "events": {},
                                            "database": {},
                                            "properties": {
                                                "label": "Row",
                                                "name": "row_1666090611889",
                                                "visibility": true,
                                                "elementClass": "",
                                                "selectedElementClassArray": [],
                                                "additionElementClass": "",
                                                "defaultElementCls": "row",
                                                "elementInnerStyles": {},
                                                "globelAttrLogic": "",
                                                "controlBindingType": "static"
                                            },
                                            "parseCtrl": {
                                                "subData": true,
                                                "layerTopId": "row~Element",
                                                "layerCount": "1",
                                                "layerCtrls": [
                                                    "row~Element"
                                                ]
                                            },
                                            "subDataArray": [
                                                {
                                                    "type": "column",
                                                    "icon": null,
                                                    "description": "Create Column Here",
                                                    "subtype": "column",
                                                    "handle": true,
                                                    "studioDevClasses": "",
                                                    "angular": {},
                                                    "events": {},
                                                    "database": {},
                                                    "properties": {
                                                        "label": "Column",
                                                        "name": "",
                                                        "visibility": true,
                                                        "colClass": "col-sm-12",
                                                        "elementClass": "",
                                                        "selectedElementClassArray": [],
                                                        "additionElementClass": "text-end",
                                                        "defaultElementCls": "",
                                                        "elementInnerStyles": {},
                                                        "globelAttrLogic": "",
                                                        "controlBindingType": "static"
                                                    },
                                                    "parseCtrl": {
                                                        "subData": true,
                                                        "layerTopId": "column#Globel",
                                                        "layerCount": "1",
                                                        "layerCtrls": [
                                                            "column#Globel"
                                                        ]
                                                    },
                                                    "subDataArray": [
                                                        {
                                                            "type": "input",
                                                            "icon": "fas fa-toggle-off",
                                                            "description": "Button",
                                                            "subtype": "button",
                                                            "handle": true,
                                                            "studioDevClasses": "d-inline-block",
                                                            "angular": {
                                                                "formType": "none",
                                                                "formGroupName": "",
                                                                "validationMsg": "",
                                                                "validators": [],
                                                                "selectedValidatorsForControls": [],
                                                                "toolTipShow": false,
                                                                "tooltipTitle": "",
                                                                "toolTipPosition": "top",
                                                                "toolTipEvent": "mouseenter",
                                                                "validatorChecker": false
                                                            },
                                                            "events": {
                                                                "selectedEventList": [
                                                                    "click"
                                                                ],
                                                                "eventData": [
                                                                    {
                                                                        "authorName": "",
                                                                        "args": "",
                                                                        "bodyInfo": [],
                                                                        "desc": "",
                                                                        "eventType": "click",
                                                                        "id": "click_1666091892145",
                                                                        "methodName": "sendAllMailData",
                                                                        "nodeType": "",
                                                                        "nodeName": "sendAllMailData",
                                                                        "nodeSubType": "method",
                                                                        "params": ""
                                                                    }
                                                                ]
                                                            },
                                                            "database": {
                                                                "databaseName": "",
                                                                "tableName": "",
                                                                "columnName": "",
                                                                "columnInfo": {},
                                                                "dbMappingState": "none",
                                                                "dbMappingMsg": "",
                                                                "onExcessLoad": false,
                                                                "master": false
                                                            },
                                                            "properties": {
                                                                "label": "Send All",
                                                                "placeholder": "Button",
                                                                "name": "sendall",
                                                                "regex": "",
                                                                "disable": false,
                                                                "visibility": true,
                                                                "starSymbol": false,
                                                                "required": false,
                                                                "iconClass": "fas fa-paper-plane",
                                                                "iconPosition": "before",
                                                                "animationCss": "",
                                                                "selectedAnimationArray": [],
                                                                "elementClass": "",
                                                                "selectedElementClassArray": [],
                                                                "additionElementClass": "",
                                                                "defaultElementCls": "btn btn-primary input~button#Element mb-3 rounded-0",
                                                                "elementInnerStyles": {},
                                                                "globelAttrLogic": "",
                                                                "controlBindingType": "static"
                                                            },
                                                            "parseCtrl": {
                                                                "subData": false,
                                                                "layerTopId": "input~button#ElementPrnt",
                                                                "layerCount": "2",
                                                                "layerCtrls": [
                                                                    "input~button#ElementPrnt",
                                                                    "input~button#Element"
                                                                ]
                                                            },
                                                            "subDataArray": [],
                                                            "id": "input_1666090633312",
                                                            "parentId": "column0_1666090611889",
                                                            "isCurrentlySelected": false,
                                                            "routerLink": null,
                                                            "loadChildrenMod": "",
                                                            "errorText": "Please enter a valid Value",
                                                            "projectConfigProperties": [
                                                                "name",
                                                                "label",
                                                                "disable",
                                                                "visibility",
                                                                "animationCss",
                                                                "iconClass",
                                                                "iconPosition",
                                                                "expandCollapseForCtrl",
                                                                "globelAttrLogic",
                                                                "controlBindingType",
                                                                "formType",
                                                                "formGroupName",
                                                                "validatorChecker",
                                                                "selectedEventList",
                                                                "combineAllModel"
                                                            ],
                                                            "windowProperties": [
                                                                "name",
                                                                "label",
                                                                "disable",
                                                                "visibility",
                                                                "animationCss",
                                                                "iconClass",
                                                                "iconPosition",
                                                                "expandCollapseForCtrl",
                                                                "globelAttrLogic",
                                                                "controlBindingType",
                                                                "formType",
                                                                "formGroupName",
                                                                "validatorChecker",
                                                                "selectedEventList",
                                                                "combineAllModel"
                                                            ],
                                                            "attributeLogiclayer": [
                                                                {
                                                                    "label": "globelAttrLogic",
                                                                    "name": "Globel AttrLogic",
                                                                    "value": "globelLogic",
                                                                    "type": "globelAttrLogics",
                                                                    "id": null,
                                                                    "selAttrs": [],
                                                                    "attrList": []
                                                                },
                                                                {
                                                                    "label": "elemAttrLogic",
                                                                    "name": "Element AttrLogic",
                                                                    "value": "elemAttrLogic",
                                                                    "type": "elemAttrLogics",
                                                                    "id": null,
                                                                    "selAttrs": [
                                                                        "label",
                                                                        "tooltip"
                                                                    ],
                                                                    "attrList": []
                                                                }
                                                            ],
                                                            "applicableAttributeLogic": [
                                                                "globelLogic",
                                                                "elemAttrLogic"
                                                            ],
                                                            "selectedEventList": " click "
                                                        }
                                                    ],
                                                    "id": "column0_1666090611889",
                                                    "parentId": null,
                                                    "isCurrentlySelected": false,
                                                    "projectConfigProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "colClass",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ],
                                                    "windowProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "colClass",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ],
                                                    "attributeLogiclayer": [
                                                        {
                                                            "label": "globelAttrLogic",
                                                            "name": "Globel AttrLogic",
                                                            "value": "globelLogic",
                                                            "type": "globelAttrLogics",
                                                            "id": null,
                                                            "selAttrs": [],
                                                            "attrList": []
                                                        },
                                                        {
                                                            "label": "elemAttrLogic",
                                                            "name": "Element AttrLogic",
                                                            "value": "elemAttrLogic",
                                                            "type": "elemAttrLogics",
                                                            "id": null,
                                                            "selAttrs": [],
                                                            "attrList": []
                                                        }
                                                    ],
                                                    "applicableAttributeLogic": [
                                                        "globelLogic",
                                                        "elemAttrLogic"
                                                    ]
                                                }
                                            ],
                                            "id": "row_1666090611889",
                                            "parentId": null,
                                            "isCurrentlySelected": false,
                                            "errorText": "Please enter a valid Value",
                                            "projectConfigProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ],
                                            "windowProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ],
                                            "attributeLogiclayer": [
                                                {
                                                    "label": "globelAttrLogic",
                                                    "name": "Globel AttrLogic",
                                                    "value": "globelLogic",
                                                    "type": "globelAttrLogics",
                                                    "id": null,
                                                    "selAttrs": [],
                                                    "attrList": []
                                                },
                                                {
                                                    "label": "elemAttrLogic",
                                                    "name": "Element AttrLogic",
                                                    "value": "elemAttrLogic",
                                                    "type": "elemAttrLogics",
                                                    "id": null,
                                                    "selAttrs": [],
                                                    "attrList": []
                                                }
                                            ],
                                            "applicableAttributeLogic": [
                                                "globelLogic",
                                                "elemAttrLogic"
                                            ]
                                        },
                                        {
                                            "type": "row",
                                            "icon": "fa-columns",
                                            "description": "Row Here",
                                            "subtype": "row",
                                            "handle": true,
                                            "studioDevClasses": "",
                                            "validationClass": true,
                                            "angular": {},
                                            "events": {},
                                            "database": {},
                                            "properties": {
                                                "label": "Row",
                                                "name": "row_1666089955807",
                                                "visibility": true,
                                                "elementClass": "",
                                                "selectedElementClassArray": [],
                                                "additionElementClass": "",
                                                "defaultElementCls": "row",
                                                "elementInnerStyles": {},
                                                "globelAttrLogic": "",
                                                "controlBindingType": "static"
                                            },
                                            "parseCtrl": {
                                                "subData": true,
                                                "layerTopId": "row~Element",
                                                "layerCount": "1",
                                                "layerCtrls": [
                                                    "row~Element"
                                                ]
                                            },
                                            "subDataArray": [
                                                {
                                                    "type": "column",
                                                    "icon": null,
                                                    "description": "Create Column Here",
                                                    "subtype": "column",
                                                    "handle": true,
                                                    "studioDevClasses": "",
                                                    "angular": {},
                                                    "events": {},
                                                    "database": {},
                                                    "properties": {
                                                        "label": "Column",
                                                        "name": "",
                                                        "visibility": true,
                                                        "colClass": "col-sm-12",
                                                        "elementClass": "",
                                                        "selectedElementClassArray": [],
                                                        "additionElementClass": "",
                                                        "defaultElementCls": "",
                                                        "elementInnerStyles": {},
                                                        "globelAttrLogic": "",
                                                        "controlBindingType": "static"
                                                    },
                                                    "parseCtrl": {
                                                        "subData": true,
                                                        "layerTopId": "column#Globel",
                                                        "layerCount": "1",
                                                        "layerCtrls": [
                                                            "column#Globel"
                                                        ]
                                                    },
                                                    "subDataArray": [
                                                        {
                                                            "type": "sagGrid",
                                                            "icon": "fas fa-border-none",
                                                            "description": "Sag Grid",
                                                            "subtype": "sagGrid",
                                                            "handle": true,
                                                            "studioDevClasses": "d-block",
                                                            "tableHead": {
                                                                "type": "tableHead",
                                                                "icon": "fa-columns",
                                                                "description": "tableHead Here",
                                                                "subtype": "tableHead",
                                                                "handle": true,
                                                                "studioDevClasses": "d-block",
                                                                "angular": {},
                                                                "events": {},
                                                                "database": {},
                                                                "properties": {
                                                                    "label": "tableHead",
                                                                    "name": ""
                                                                },
                                                                "subDataArray": [],
                                                                "values": [
                                                                    {
                                                                        "header": "S.No",
                                                                        "field": "sno",
                                                                        "filter": true,
                                                                        "width": "50px",
                                                                        "editable": false,
                                                                        "text-align": "left",
                                                                        "search": true,
                                                                        "component": "label",
                                                                        "freezeCol": "null",
                                                                        "hidden": false,
                                                                        "columnGroup": "",
                                                                        "type": "sagGridInput",
                                                                        "icon": "fas fa-check-double",
                                                                        "label": "label",
                                                                        "values": [
                                                                            {
                                                                                "label": "--select--",
                                                                                "value": ""
                                                                            }
                                                                        ],
                                                                        "subtype": "sagGridLabel",
                                                                        "subDataArray": [],
                                                                        "id": "1666089735146",
                                                                        "parentId": null,
                                                                        "windowProperties": [
                                                                            "label"
                                                                        ],
                                                                        "projectConfigProperties": [
                                                                            "label"
                                                                        ]
                                                                    },
                                                                    {
                                                                        "header": "Grid Data",
                                                                        "field": "gridData",
                                                                        "filter": true,
                                                                        "width": "100px",
                                                                        "editable": false,
                                                                        "text-align": "left",
                                                                        "search": true,
                                                                        "component": "textInput",
                                                                        "freezeCol": "null",
                                                                        "columnGroup": "",
                                                                        "hidden": false,
                                                                        "checkboxLabel": false,
                                                                        "type": "sagGridInput",
                                                                        "icon": "fas fa-check-double",
                                                                        "label": "label",
                                                                        "values": [
                                                                            {
                                                                                "label": "--select--",
                                                                                "value": ""
                                                                            }
                                                                        ],
                                                                        "subtype": "sagGridText",
                                                                        "regex": "",
                                                                        "subDataArray": [],
                                                                        "id": "1666089989792",
                                                                        "parentId": null,
                                                                        "isCurrentlySelected": false,
                                                                        "windowProperties": [
                                                                            "label",
                                                                            "regex",
                                                                            "databaseName",
                                                                            "tableName",
                                                                            "columnName",
                                                                            "onExcessLoad",
                                                                            "master"
                                                                        ],
                                                                        "projectConfigProperties": [
                                                                            "label",
                                                                            "regex"
                                                                        ],
                                                                        "database": {
                                                                            "databaseName": "",
                                                                            "tableName": "",
                                                                            "columnName": "",
                                                                            "columnInfo": {},
                                                                            "dbMappingState": "none",
                                                                            "dbMappingMsg": "",
                                                                            "onExcessLoad": false,
                                                                            "master": false
                                                                        }
                                                                    },
                                                                    {
                                                                        "header": "View",
                                                                        "field": "view",
                                                                        "filter": true,
                                                                        "width": "100px",
                                                                        "editable": false,
                                                                        "text-align": "left",
                                                                        "search": true,
                                                                        "component": "button",
                                                                        "freezeCol": "null",
                                                                        "columnGroup": "",
                                                                        "hidden": false,
                                                                        "checkboxLabel": false,
                                                                        "type": "sagGridInput",
                                                                        "icon": "fas fa-check-double",
                                                                        "label": "label",
                                                                        "values": [
                                                                            {
                                                                                "label": "--select--",
                                                                                "value": ""
                                                                            }
                                                                        ],
                                                                        "subtype": "sagGridButton",
                                                                        "regex": "",
                                                                        "subDataArray": [],
                                                                        "id": "1666090050163",
                                                                        "parentId": null,
                                                                        "isCurrentlySelected": false,
                                                                        "windowProperties": [
                                                                            "label",
                                                                            "regex",
                                                                            "databaseName",
                                                                            "tableName",
                                                                            "columnName",
                                                                            "onExcessLoad",
                                                                            "master"
                                                                        ],
                                                                        "projectConfigProperties": [
                                                                            "label",
                                                                            "regex"
                                                                        ],
                                                                        "database": {
                                                                            "databaseName": "",
                                                                            "tableName": "",
                                                                            "columnName": "",
                                                                            "columnInfo": {},
                                                                            "dbMappingState": "none",
                                                                            "dbMappingMsg": "",
                                                                            "onExcessLoad": false,
                                                                            "master": false
                                                                        }
                                                                    },
                                                                    {
                                                                        "header": "Send",
                                                                        "field": "send",
                                                                        "filter": true,
                                                                        "width": "100px",
                                                                        "editable": false,
                                                                        "text-align": "left",
                                                                        "search": true,
                                                                        "component": "button",
                                                                        "freezeCol": "null",
                                                                        "columnGroup": "",
                                                                        "hidden": false,
                                                                        "checkboxLabel": false,
                                                                        "type": "sagGridInput",
                                                                        "icon": "fas fa-check-double",
                                                                        "label": "label",
                                                                        "values": [
                                                                            {
                                                                                "label": "--select--",
                                                                                "value": ""
                                                                            }
                                                                        ],
                                                                        "subtype": "sagGridButton",
                                                                        "regex": "",
                                                                        "subDataArray": [],
                                                                        "id": "1666090068781",
                                                                        "parentId": null,
                                                                        "isCurrentlySelected": false,
                                                                        "windowProperties": [
                                                                            "label",
                                                                            "regex",
                                                                            "databaseName",
                                                                            "tableName",
                                                                            "columnName",
                                                                            "onExcessLoad",
                                                                            "master"
                                                                        ],
                                                                        "projectConfigProperties": [
                                                                            "label",
                                                                            "regex"
                                                                        ],
                                                                        "database": {
                                                                            "databaseName": "",
                                                                            "tableName": "",
                                                                            "columnName": "",
                                                                            "columnInfo": {},
                                                                            "dbMappingState": "none",
                                                                            "dbMappingMsg": "",
                                                                            "onExcessLoad": false,
                                                                            "master": false
                                                                        }
                                                                    }
                                                                ],
                                                                "apiResponseList": [],
                                                                "columnType": [
                                                                    {
                                                                        "id": "label",
                                                                        "text": "Label"
                                                                    },
                                                                    {
                                                                        "id": "textInput",
                                                                        "text": "Text"
                                                                    },
                                                                    {
                                                                        "id": "numberInput",
                                                                        "text": "Number"
                                                                    },
                                                                    {
                                                                        "id": "dateInput",
                                                                        "text": "Date"
                                                                    },
                                                                    {
                                                                        "id": "selectInput",
                                                                        "text": "Select"
                                                                    },
                                                                    {
                                                                        "id": "checkBox",
                                                                        "text": "CheckBox"
                                                                    },
                                                                    {
                                                                        "id": "button",
                                                                        "text": "Button"
                                                                    },
                                                                    {
                                                                        "id": "btnInHeader",
                                                                        "text": "ButtonInHeader"
                                                                    },
                                                                    {
                                                                        "id": "rowDelete",
                                                                        "text": "rowDelete"
                                                                    }
                                                                ],
                                                                "id": null,
                                                                "parentId": null,
                                                                "isCurrentlySelected": false,
                                                                "errorText": "Please select a valid Table Head",
                                                                "projectConfigProperties": [
                                                                    "label"
                                                                ],
                                                                "windowProperties": [
                                                                    "label"
                                                                ]
                                                            },
                                                            "tableBody": {
                                                                "type": "tableBody",
                                                                "icon": "fa-columns",
                                                                "description": "tableBody Here",
                                                                "subtype": "tableBody",
                                                                "handle": true,
                                                                "studioDevClasses": "d-block",
                                                                "angular": {},
                                                                "events": {},
                                                                "database": {},
                                                                "properties": {
                                                                    "label": "tableBody",
                                                                    "name": ""
                                                                },
                                                                "parseCtrl": {
                                                                    "subData": false,
                                                                    "layerTopId": "",
                                                                    "layerCount": "2",
                                                                    "layerCtrls": []
                                                                },
                                                                "subDataArray": [],
                                                                "values": [
                                                                    {},
                                                                    {},
                                                                    {},
                                                                    {}
                                                                ],
                                                                "id": null,
                                                                "parentId": null,
                                                                "errorText": "Please select a valid Div",
                                                                "projectConfigProperties": [
                                                                    "label"
                                                                ],
                                                                "windowProperties": [
                                                                    "label"
                                                                ]
                                                            },
                                                            "angular": {},
                                                            "events": {},
                                                            "database": {},
                                                            "properties": {
                                                                "label": "Sag Grid",
                                                                "name": "sendallmail",
                                                                "visibility": true,
                                                                "elementClass": "",
                                                                "selectedElementClassArray": [],
                                                                "additionElementClass": "",
                                                                "defaultElementCls": "table-area masterdiv",
                                                                "elementInnerStyles": {},
                                                                "totalColumns": 1,
                                                                "rowHeight": 20,
                                                                "addRowBtn": false,
                                                                "deleteRowBtn": false,
                                                                "gridFilter": true,
                                                                "footerHide": true,
                                                                "totalNoOfRecordHide": true,
                                                                "smlexpandGridHide": true,
                                                                "exportXlsxPageHide": true,
                                                                "exportXlsxAllPageHide": true,
                                                                "exportPDFLandscapeHide": true,
                                                                "exportPDFPortraitHide": true,
                                                                "ariaHiddenHide": true,
                                                                "headerStyle": {},
                                                                "rowEvenStyle": {},
                                                                "rowOddStyle": {},
                                                                "globelAttrLogic": "",
                                                                "controlBindingType": "static"
                                                            },
                                                            "parseCtrl": {
                                                                "subData": false,
                                                                "layerTopId": "",
                                                                "layerCount": "2",
                                                                "layerCtrls": []
                                                            },
                                                            "subDataArray": [],
                                                            "id": "sagGrid_1666089959616",
                                                            "parentId": "",
                                                            "isCurrentlySelected": false,
                                                            "errorText": "Please select a valid Div",
                                                            "sagGridFullscreen": false,
                                                            "openHeaderSection": true,
                                                            "freezeColumn": {},
                                                            "projectConfigProperties": [
                                                                "name",
                                                                "visibility",
                                                                "expandCollapseForCtrl",
                                                                "totalColumns",
                                                                "rowHeight",
                                                                "addRowBtn",
                                                                "deleteRowBtn",
                                                                "gridFilter",
                                                                "gridStatusBar",
                                                                "footerHide",
                                                                "totalNoOfRecordHide",
                                                                "smlexpandGridHide",
                                                                "exportXlsxPageHide",
                                                                "exportXlsxAllPageHide",
                                                                "exportPDFLandscapeHide",
                                                                "exportPDFPortraitHide",
                                                                "ariaHiddenHide",
                                                                "headerStyle",
                                                                "rowEvenStyle",
                                                                "rowOddStyle",
                                                                "gridExpandViewShow",
                                                                "globelAttrLogic",
                                                                "controlBindingType"
                                                            ],
                                                            "windowProperties": [
                                                                "name",
                                                                "visibility",
                                                                "expandCollapseForCtrl",
                                                                "totalColumns",
                                                                "rowHeight",
                                                                "addRowBtn",
                                                                "deleteRowBtn",
                                                                "gridFilter",
                                                                "gridStatusBar",
                                                                "footerHide",
                                                                "totalNoOfRecordHide",
                                                                "smlexpandGridHide",
                                                                "exportXlsxPageHide",
                                                                "exportXlsxAllPageHide",
                                                                "exportPDFLandscapeHide",
                                                                "exportPDFPortraitHide",
                                                                "ariaHiddenHide",
                                                                "headerStyle",
                                                                "rowEvenStyle",
                                                                "rowOddStyle",
                                                                "gridExpandViewShow",
                                                                "globelAttrLogic",
                                                                "controlBindingType"
                                                            ],
                                                            "attributeLogiclayer": [
                                                                {
                                                                    "label": "globelAttrLogic",
                                                                    "name": "Globel AttrLogic",
                                                                    "value": "globelLogic",
                                                                    "type": "globelAttrLogics",
                                                                    "id": null,
                                                                    "selAttrs": [],
                                                                    "attrList": []
                                                                },
                                                                {
                                                                    "label": "elemAttrLogic",
                                                                    "name": "Element AttrLogic",
                                                                    "value": "elemAttrLogic",
                                                                    "type": "elemAttrLogics",
                                                                    "id": null,
                                                                    "selAttrs": [
                                                                        "label",
                                                                        "tooltip"
                                                                    ],
                                                                    "attrList": []
                                                                }
                                                            ],
                                                            "applicableAttributeLogic": [
                                                                "globelLogic",
                                                                "elemAttrLogic"
                                                            ],
                                                            "name": "sendallmail",
                                                            "totalColumns": 4
                                                        }
                                                    ],
                                                    "id": "",
                                                    "parentId": "",
                                                    "isCurrentlySelected": false,
                                                    "projectConfigProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "colClass",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ],
                                                    "windowProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "colClass",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ],
                                                    "attributeLogiclayer": [
                                                        {
                                                            "label": "globelAttrLogic",
                                                            "name": "Globel AttrLogic",
                                                            "value": "globelLogic",
                                                            "type": "globelAttrLogics",
                                                            "id": null,
                                                            "selAttrs": [],
                                                            "attrList": []
                                                        },
                                                        {
                                                            "label": "elemAttrLogic",
                                                            "name": "Element AttrLogic",
                                                            "value": "elemAttrLogic",
                                                            "type": "elemAttrLogics",
                                                            "id": null,
                                                            "selAttrs": [],
                                                            "attrList": []
                                                        }
                                                    ],
                                                    "applicableAttributeLogic": [
                                                        "globelLogic",
                                                        "elemAttrLogic"
                                                    ]
                                                }
                                            ],
                                            "id": "row_1666089955807",
                                            "parentId": "",
                                            "isCurrentlySelected": false,
                                            "errorText": "Please enter a valid Value",
                                            "projectConfigProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ],
                                            "windowProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ],
                                            "attributeLogiclayer": [
                                                {
                                                    "label": "globelAttrLogic",
                                                    "name": "Globel AttrLogic",
                                                    "value": "globelLogic",
                                                    "type": "globelAttrLogics",
                                                    "id": null,
                                                    "selAttrs": [],
                                                    "attrList": []
                                                },
                                                {
                                                    "label": "elemAttrLogic",
                                                    "name": "Element AttrLogic",
                                                    "value": "elemAttrLogic",
                                                    "type": "elemAttrLogics",
                                                    "id": null,
                                                    "selAttrs": [],
                                                    "attrList": []
                                                }
                                            ],
                                            "applicableAttributeLogic": [
                                                "globelLogic",
                                                "elemAttrLogic"
                                            ]
                                        }
                                    ],
                                    "id": null,
                                    "parentId": null,
                                    "isCurrentlySelected": false,
                                    "errorText": "Please enter a valid Value",
                                    "projectConfigProperties": [
                                        "visibility",
                                        "tooltip"
                                    ],
                                    "windowProperties": [
                                        "name",
                                        "label",
                                        "visibility",
                                        "expandCollapseForCtrl",
                                        "globelClasses",
                                        "additionGlobelClasses",
                                        "defaultGlobelCls",
                                        "globelAttrLogic",
                                        "controlBindingType"
                                    ],
                                    "attributeLogiclayer": [
                                        {
                                            "label": "globelAttrLogic",
                                            "name": "Globel AttrLogic",
                                            "value": "globelLogic",
                                            "type": "globelAttrLogics",
                                            "id": null,
                                            "selAttrs": [],
                                            "attrList": []
                                        },
                                        {
                                            "label": "elemAttrLogic",
                                            "name": "Element AttrLogic",
                                            "value": "elemAttrLogic",
                                            "type": "elemAttrLogics",
                                            "id": null,
                                            "selAttrs": [
                                                "label",
                                                "tooltip"
                                            ],
                                            "attrList": []
                                        }
                                    ],
                                    "applicableAttributeLogic": [
                                        "globelLogic",
                                        "elemAttrLogic"
                                    ]
                                },
                                "modelFooter": {
                                    "type": "modelFooter",
                                    "description": "modelFooter Here",
                                    "icon": "fa-columns",
                                    "subtype": "modelFooter",
                                    "handle": true,
                                    "studioDevClasses": "d-block",
                                    "angular": {
                                        "formType": "none",
                                        "formGroupName": "",
                                        "validationMsg": "",
                                        "validators": [],
                                        "selectedValidatorsForControls": [],
                                        "toolTip": "i am Toop Tip",
                                        "tooltipTitle": "",
                                        "toolTipShow": false,
                                        "toolTipPosition": "top",
                                        "toolTipEvent": "mouseenter"
                                    },
                                    "events": {
                                        "selectedEventList": [],
                                        "eventData": []
                                    },
                                    "database": {
                                        "databaseName": "",
                                        "tableName": "",
                                        "columnName": "",
                                        "columnInfo": {},
                                        "dbMappingState": "none",
                                        "dbMappingMsg": "",
                                        "onExcessLoad": false,
                                        "master": false
                                    },
                                    "properties": {
                                        "label": "modelFooter",
                                        "name": "",
                                        "visibility": true,
                                        "validationClass": true,
                                        "elementClass": "",
                                        "selectedElementClassArray": [],
                                        "additionElementClass": "",
                                        "defaultElementCls": "modal-footer",
                                        "elementInnerStyles": {},
                                        "globelAttrLogic": "",
                                        "controlBindingType": "static"
                                    },
                                    "parseCtrl": {
                                        "subData": false,
                                        "layerTopId": "modelFooter~modelFooter#Globel",
                                        "layerCount": "2",
                                        "layerCtrls": [
                                            "modelFooter~modelFooter#Globel",
                                            "modelFooter~modelFooter#Element"
                                        ]
                                    },
                                    "subDataArray": [
                                        {
                                            "type": "row",
                                            "icon": "fa-columns",
                                            "description": "Row Here",
                                            "subtype": "row",
                                            "handle": true,
                                            "studioDevClasses": "",
                                            "validationClass": true,
                                            "angular": {},
                                            "events": {},
                                            "database": {},
                                            "properties": {
                                                "label": "Row",
                                                "name": "row_1666090727782",
                                                "visibility": true,
                                                "elementClass": "",
                                                "selectedElementClassArray": [],
                                                "additionElementClass": "",
                                                "defaultElementCls": "row",
                                                "elementInnerStyles": {},
                                                "globelAttrLogic": "",
                                                "controlBindingType": "static"
                                            },
                                            "parseCtrl": {
                                                "subData": true,
                                                "layerTopId": "row~Element",
                                                "layerCount": "1",
                                                "layerCtrls": [
                                                    "row~Element"
                                                ]
                                            },
                                            "subDataArray": [
                                                {
                                                    "type": "column",
                                                    "icon": null,
                                                    "description": "Create Column Here",
                                                    "subtype": "column",
                                                    "handle": true,
                                                    "studioDevClasses": "",
                                                    "angular": {},
                                                    "events": {},
                                                    "database": {},
                                                    "properties": {
                                                        "label": "Column",
                                                        "name": "",
                                                        "visibility": true,
                                                        "colClass": "col-sm-12",
                                                        "elementClass": "",
                                                        "selectedElementClassArray": [],
                                                        "additionElementClass": "text-end",
                                                        "defaultElementCls": "",
                                                        "elementInnerStyles": {},
                                                        "globelAttrLogic": "",
                                                        "controlBindingType": "static"
                                                    },
                                                    "parseCtrl": {
                                                        "subData": true,
                                                        "layerTopId": "column#Globel",
                                                        "layerCount": "1",
                                                        "layerCtrls": [
                                                            "column#Globel"
                                                        ]
                                                    },
                                                    "subDataArray": [
                                                        {
                                                            "type": "input",
                                                            "icon": "fas fa-toggle-off",
                                                            "description": "Button",
                                                            "subtype": "button",
                                                            "handle": true,
                                                            "studioDevClasses": "d-inline-block",
                                                            "angular": {
                                                                "formType": "none",
                                                                "formGroupName": "",
                                                                "validationMsg": "",
                                                                "validators": [],
                                                                "selectedValidatorsForControls": [],
                                                                "toolTipShow": false,
                                                                "tooltipTitle": "",
                                                                "toolTipPosition": "top",
                                                                "toolTipEvent": "mouseenter",
                                                                "validatorChecker": false
                                                            },
                                                            "events": {
                                                                "selectedEventList": [
                                                                    "click"
                                                                ],
                                                                "eventData": [
                                                                    {
                                                                        "authorName": "",
                                                                        "args": "",
                                                                        "bodyInfo": [],
                                                                        "desc": "",
                                                                        "eventType": "click",
                                                                        "id": "click_1666091934364",
                                                                        "methodName": "closeModal",
                                                                        "nodeType": "",
                                                                        "nodeName": "closeModal",
                                                                        "nodeSubType": "method",
                                                                        "params": ""
                                                                    }
                                                                ]
                                                            },
                                                            "database": {
                                                                "databaseName": "",
                                                                "tableName": "",
                                                                "columnName": "",
                                                                "columnInfo": {},
                                                                "dbMappingState": "none",
                                                                "dbMappingMsg": "",
                                                                "onExcessLoad": false,
                                                                "master": false
                                                            },
                                                            "properties": {
                                                                "label": "Cancel",
                                                                "placeholder": "Button",
                                                                "name": "input_1666090734183",
                                                                "regex": "",
                                                                "disable": false,
                                                                "visibility": true,
                                                                "starSymbol": false,
                                                                "required": false,
                                                                "iconClass": "fas fa-times",
                                                                "iconPosition": "before",
                                                                "animationCss": "",
                                                                "selectedAnimationArray": [],
                                                                "elementClass": "",
                                                                "selectedElementClassArray": [],
                                                                "additionElementClass": "",
                                                                "defaultElementCls": "btn btn-danger input~button#Element rounded-0",
                                                                "elementInnerStyles": {},
                                                                "globelAttrLogic": "",
                                                                "controlBindingType": "static"
                                                            },
                                                            "parseCtrl": {
                                                                "subData": false,
                                                                "layerTopId": "input~button#ElementPrnt",
                                                                "layerCount": "2",
                                                                "layerCtrls": [
                                                                    "input~button#ElementPrnt",
                                                                    "input~button#Element"
                                                                ]
                                                            },
                                                            "subDataArray": [],
                                                            "id": "input_1666090734183",
                                                            "parentId": "",
                                                            "isCurrentlySelected": true,
                                                            "routerLink": null,
                                                            "loadChildrenMod": "",
                                                            "errorText": "Please enter a valid Value",
                                                            "projectConfigProperties": [
                                                                "name",
                                                                "label",
                                                                "disable",
                                                                "visibility",
                                                                "animationCss",
                                                                "iconClass",
                                                                "iconPosition",
                                                                "expandCollapseForCtrl",
                                                                "globelAttrLogic",
                                                                "controlBindingType",
                                                                "formType",
                                                                "formGroupName",
                                                                "validatorChecker",
                                                                "selectedEventList",
                                                                "combineAllModel"
                                                            ],
                                                            "windowProperties": [
                                                                "name",
                                                                "label",
                                                                "disable",
                                                                "visibility",
                                                                "animationCss",
                                                                "iconClass",
                                                                "iconPosition",
                                                                "expandCollapseForCtrl",
                                                                "globelAttrLogic",
                                                                "controlBindingType",
                                                                "formType",
                                                                "formGroupName",
                                                                "validatorChecker",
                                                                "selectedEventList",
                                                                "combineAllModel"
                                                            ],
                                                            "attributeLogiclayer": [
                                                                {
                                                                    "label": "globelAttrLogic",
                                                                    "name": "Globel AttrLogic",
                                                                    "value": "globelLogic",
                                                                    "type": "globelAttrLogics",
                                                                    "id": null,
                                                                    "selAttrs": [],
                                                                    "attrList": []
                                                                },
                                                                {
                                                                    "label": "elemAttrLogic",
                                                                    "name": "Element AttrLogic",
                                                                    "value": "elemAttrLogic",
                                                                    "type": "elemAttrLogics",
                                                                    "id": null,
                                                                    "selAttrs": [
                                                                        "label",
                                                                        "tooltip"
                                                                    ],
                                                                    "attrList": []
                                                                }
                                                            ],
                                                            "applicableAttributeLogic": [
                                                                "globelLogic",
                                                                "elemAttrLogic"
                                                            ],
                                                            "selectedEventList": " click "
                                                        }
                                                    ],
                                                    "id": "",
                                                    "parentId": "",
                                                    "isCurrentlySelected": false,
                                                    "projectConfigProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "colClass",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ],
                                                    "windowProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "colClass",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ],
                                                    "attributeLogiclayer": [
                                                        {
                                                            "label": "globelAttrLogic",
                                                            "name": "Globel AttrLogic",
                                                            "value": "globelLogic",
                                                            "type": "globelAttrLogics",
                                                            "id": null,
                                                            "selAttrs": [],
                                                            "attrList": []
                                                        },
                                                        {
                                                            "label": "elemAttrLogic",
                                                            "name": "Element AttrLogic",
                                                            "value": "elemAttrLogic",
                                                            "type": "elemAttrLogics",
                                                            "id": null,
                                                            "selAttrs": [],
                                                            "attrList": []
                                                        }
                                                    ],
                                                    "applicableAttributeLogic": [
                                                        "globelLogic",
                                                        "elemAttrLogic"
                                                    ]
                                                }
                                            ],
                                            "id": "row_1666090727782",
                                            "parentId": "",
                                            "isCurrentlySelected": false,
                                            "errorText": "Please enter a valid Value",
                                            "projectConfigProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ],
                                            "windowProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ],
                                            "attributeLogiclayer": [
                                                {
                                                    "label": "globelAttrLogic",
                                                    "name": "Globel AttrLogic",
                                                    "value": "globelLogic",
                                                    "type": "globelAttrLogics",
                                                    "id": null,
                                                    "selAttrs": [],
                                                    "attrList": []
                                                },
                                                {
                                                    "label": "elemAttrLogic",
                                                    "name": "Element AttrLogic",
                                                    "value": "elemAttrLogic",
                                                    "type": "elemAttrLogics",
                                                    "id": null,
                                                    "selAttrs": [],
                                                    "attrList": []
                                                }
                                            ],
                                            "applicableAttributeLogic": [
                                                "globelLogic",
                                                "elemAttrLogic"
                                            ]
                                        }
                                    ],
                                    "id": null,
                                    "parentId": null,
                                    "isCurrentlySelected": false,
                                    "errorText": "Please select a valid Div",
                                    "projectConfigProperties": [
                                        "visibility",
                                        "tooltip"
                                    ],
                                    "windowProperties": [
                                        "name",
                                        "label",
                                        "visibility",
                                        "expandCollapseForCtrl",
                                        "globelClasses",
                                        "additionGlobelClasses",
                                        "defaultGlobelCls",
                                        "globelAttrLogic",
                                        "controlBindingType"
                                    ],
                                    "attributeLogiclayer": [
                                        {
                                            "label": "globelAttrLogic",
                                            "name": "Globel AttrLogic",
                                            "value": "globelLogic",
                                            "type": "globelAttrLogics",
                                            "id": null,
                                            "selAttrs": [],
                                            "attrList": []
                                        },
                                        {
                                            "label": "elemAttrLogic",
                                            "name": "Element AttrLogic",
                                            "value": "elemAttrLogic",
                                            "type": "elemAttrLogics",
                                            "id": null,
                                            "selAttrs": [
                                                "label",
                                                "tooltip"
                                            ],
                                            "attrList": []
                                        }
                                    ],
                                    "applicableAttributeLogic": [
                                        "globelLogic",
                                        "elemAttrLogic"
                                    ]
                                },
                                "subDataArray": [],
                                "id": "bootstrapModals_1666089870680",
                                "parentId": null,
                                "isCurrentlySelected": false,
                                "errorText": "Please enter a valid Value",
                                "projectConfigProperties": [
                                    "visibility",
                                    "tooltip"
                                ],
                                "windowProperties": [
                                    "name",
                                    "backDrop",
                                    "modalPosition",
                                    "expandCollapseForGlobal",
                                    "bootModalExpandViewShow",
                                    "globelAttrLogic",
                                    "controlBindingType"
                                ],
                                "attributeLogiclayer": [
                                    {
                                        "label": "globelAttrLogic",
                                        "name": "Globel AttrLogic",
                                        "value": "globelLogic",
                                        "type": "globelAttrLogics",
                                        "id": null,
                                        "selAttrs": [],
                                        "attrList": []
                                    },
                                    {
                                        "label": "elemAttrLogic",
                                        "name": "Element AttrLogic",
                                        "value": "elemAttrLogic",
                                        "type": "elemAttrLogics",
                                        "id": null,
                                        "selAttrs": [
                                            "label",
                                            "tooltip"
                                        ],
                                        "attrList": []
                                    }
                                ],
                                "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                ],
                                "name": "usersendallmail"
                            }
                        ],
                        "properties": {
                            "additionElementClass": "",
                            "visibility": true,
                            "selectedElementClassArray": [],
                            "name": "",
                            "controlBindingType": "static",
                            "defaultElementCls": "d-flex flex-column full-modal h-100 pageContainer#Globel",
                            "elementInnerStyles": {},
                            "globelAttrLogic": "",
                            "label": "Page Container",
                            "elementClass": ""
                        },
                        "events": {
                            "selectedEventList": [],
                            "eventData": []
                        },
                        "windowProperties": [
                            "name",
                            "label",
                            "visibility",
                            "expandCollapseForCtrl",
                            "globelAttrLogic",
                            "controlBindingType",
                            "selectedEventList",
                            "combineAllModel"
                        ]
                    } */
                    {
                        "attributeLogiclayer": [
                            {
                                "name": "Globel AttrLogic",
                                "selAttrs": [],
                                "label": "globelAttrLogic",
                                "id": null,
                                "type": "globelAttrLogics",
                                "value": "globelLogic",
                                "attrList": []
                            },
                            {
                                "name": "Element AttrLogic",
                                "selAttrs": [
                                    "label",
                                    "tooltip"
                                ],
                                "label": "elemAttrLogic",
                                "id": null,
                                "type": "elemAttrLogics",
                                "value": "elemAttrLogic",
                                "attrList": []
                            }
                        ],
                        "icon": "fa-columns",
                        "isCurrentlySelected": false,
                        "description": "Page Container",
                        "parseCtrl": {
                            "subData": true,
                            "layerCount": "1",
                            "layerTopId": "pageContainer#Globel",
                            "layerCtrls": [
                                "pageContainer#Globel"
                            ]
                        },
                        "type": "pageContainer",
                        "studioDevClasses": "d-block",
                        "projectConfigProperties": [
                            "name",
                            "label",
                            "visibility",
                            "expandCollapseForCtrl",
                            "globelAttrLogic",
                            "controlBindingType",
                            "selectedEventList",
                            "combineAllModel"
                        ],
                        "parentId": null,
                        "angular": {},
                        "errorText": "Please select a valid Div",
                        "applicableAttributeLogic": [
                            "globelLogic",
                            "elemAttrLogic"
                        ],
                        "database": {},
                        "subtype": "div",
                        "id": null,
                        "subDataArray": [
                            {
                                "attributeLogiclayer": [
                                    {
                                        "name": "Globel AttrLogic",
                                        "selAttrs": [],
                                        "label": "globelAttrLogic",
                                        "id": null,
                                        "type": "globelAttrLogics",
                                        "value": "globelLogic",
                                        "attrList": []
                                    },
                                    {
                                        "name": "Element AttrLogic",
                                        "selAttrs": [
                                            "label",
                                            "tooltip"
                                        ],
                                        "label": "elemAttrLogic",
                                        "id": null,
                                        "type": "elemAttrLogics",
                                        "value": "elemAttrLogic",
                                        "attrList": []
                                    }
                                ],
                                "icon": "fa-columns",
                                "isCurrentlySelected": false,
                                "description": "Page Container",
                                "parseCtrl": {
                                    "subData": true,
                                    "layerCount": "1",
                                    "layerTopId": "pageContainer#Globel",
                                    "layerCtrls": [
                                        "pageContainer#Globel"
                                    ]
                                },
                                "type": "pageContainer",
                                "studioDevClasses": "d-block",
                                "projectConfigProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "expandCollapseForCtrl",
                                    "globelAttrLogic",
                                    "controlBindingType",
                                    "selectedEventList",
                                    "combineAllModel"
                                ],
                                "parentId": null,
                                "angular": {},
                                "errorText": "Please select a valid Div",
                                "applicableAttributeLogic": [
                                    "globelLogic",
                                    "elemAttrLogic"
                                ],
                                "database": {},
                                "subtype": "div",
                                "id": null,
                                "subDataArray": [
                                    {
                                        "attributeLogiclayer": [
                                            {
                                                "name": "Globel AttrLogic",
                                                "selAttrs": [],
                                                "label": "globelAttrLogic",
                                                "id": null,
                                                "type": "globelAttrLogics",
                                                "value": "globelLogic",
                                                "attrList": []
                                            },
                                            {
                                                "name": "Element AttrLogic",
                                                "selAttrs": [
                                                    "label",
                                                    "tooltip"
                                                ],
                                                "label": "elemAttrLogic",
                                                "id": null,
                                                "type": "elemAttrLogics",
                                                "value": "elemAttrLogic",
                                                "attrList": []
                                            }
                                        ],
                                        "icon": "fas fa-window-maximize",
                                        "description": "BootStrap Models",
                                        "modelFooter": {
                                            "attributeLogiclayer": [
                                                {
                                                    "name": "Globel AttrLogic",
                                                    "selAttrs": [],
                                                    "label": "globelAttrLogic",
                                                    "id": null,
                                                    "type": "globelAttrLogics",
                                                    "value": "globelLogic",
                                                    "attrList": []
                                                },
                                                {
                                                    "name": "Element AttrLogic",
                                                    "selAttrs": [
                                                        "label",
                                                        "tooltip"
                                                    ],
                                                    "label": "elemAttrLogic",
                                                    "id": null,
                                                    "type": "elemAttrLogics",
                                                    "value": "elemAttrLogic",
                                                    "attrList": []
                                                }
                                            ],
                                            "icon": "fa-columns",
                                            "isCurrentlySelected": false,
                                            "description": "modelFooter Here",
                                            "handle": true,
                                            "parseCtrl": {
                                                "subData": false,
                                                "layerCount": "2",
                                                "layerTopId": "modelFooter~modelFooter#Globel",
                                                "layerCtrls": [
                                                    "modelFooter~modelFooter#Globel",
                                                    "modelFooter~modelFooter#Element"
                                                ]
                                            },
                                            "type": "modelFooter",
                                            "studioDevClasses": "d-block",
                                            "projectConfigProperties": [
                                                "visibility",
                                                "tooltip"
                                            ],
                                            "parentId": null,
                                            "angular": {
                                                "tooltipTitle": "",
                                                "formType": "none",
                                                "validationMsg": "",
                                                "toolTipPosition": "top",
                                                "formGroupName": "",
                                                "toolTipEvent": "mouseenter",
                                                "validators": [],
                                                "toolTip": "i am Toop Tip",
                                                "selectedValidatorsForControls": [],
                                                "toolTipShow": false
                                            },
                                            "errorText": "Please select a valid Div",
                                            "applicableAttributeLogic": [
                                                "globelLogic",
                                                "elemAttrLogic"
                                            ],
                                            "database": {
                                                "onExcessLoad": false,
                                                "databaseName": "",
                                                "dbMappingState": "none",
                                                "columnInfo": {},
                                                "tableName": "",
                                                "columnName": "",
                                                "dbMappingMsg": "",
                                                "master": false
                                            },
                                            "subtype": "modelFooter",
                                            "id": null,
                                            "subDataArray": [
                                                {
                                                    "attributeLogiclayer": [
                                                        {
                                                            "name": "Globel AttrLogic",
                                                            "selAttrs": [],
                                                            "label": "globelAttrLogic",
                                                            "id": null,
                                                            "type": "globelAttrLogics",
                                                            "value": "globelLogic",
                                                            "attrList": []
                                                        },
                                                        {
                                                            "name": "Element AttrLogic",
                                                            "selAttrs": [],
                                                            "label": "elemAttrLogic",
                                                            "id": null,
                                                            "type": "elemAttrLogics",
                                                            "value": "elemAttrLogic",
                                                            "attrList": []
                                                        }
                                                    ],
                                                    "icon": "fa-columns",
                                                    "isCurrentlySelected": false,
                                                    "description": "Row Here",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                        "subData": true,
                                                        "layerCount": "1",
                                                        "layerTopId": "row~Element",
                                                        "layerCtrls": [
                                                            "row~Element"
                                                        ]
                                                    },
                                                    "type": "row",
                                                    "studioDevClasses": "",
                                                    "projectConfigProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ],
                                                    "parentId": "",
                                                    "angular": {},
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                        "globelLogic",
                                                        "elemAttrLogic"
                                                    ],
                                                    "database": {},
                                                    "subtype": "row",
                                                    "id": "row_1666090727782",
                                                    "validationClass": true,
                                                    "subDataArray": [
                                                        {
                                                            "attributeLogiclayer": [
                                                                {
                                                                    "name": "Globel AttrLogic",
                                                                    "selAttrs": [],
                                                                    "label": "globelAttrLogic",
                                                                    "id": null,
                                                                    "type": "globelAttrLogics",
                                                                    "value": "globelLogic",
                                                                    "attrList": []
                                                                },
                                                                {
                                                                    "name": "Element AttrLogic",
                                                                    "selAttrs": [],
                                                                    "label": "elemAttrLogic",
                                                                    "id": null,
                                                                    "type": "elemAttrLogics",
                                                                    "value": "elemAttrLogic",
                                                                    "attrList": []
                                                                }
                                                            ],
                                                            "icon": null,
                                                            "isCurrentlySelected": false,
                                                            "description": "Create Column Here",
                                                            "handle": true,
                                                            "parseCtrl": {
                                                                "subData": true,
                                                                "layerCount": "1",
                                                                "layerTopId": "column#Globel",
                                                                "layerCtrls": [
                                                                    "column#Globel"
                                                                ]
                                                            },
                                                            "type": "column",
                                                            "studioDevClasses": "",
                                                            "projectConfigProperties": [
                                                                "name",
                                                                "label",
                                                                "visibility",
                                                                "colClass",
                                                                "expandCollapseForCtrl",
                                                                "globelAttrLogic",
                                                                "controlBindingType"
                                                            ],
                                                            "parentId": "",
                                                            "angular": {},
                                                            "applicableAttributeLogic": [
                                                                "globelLogic",
                                                                "elemAttrLogic"
                                                            ],
                                                            "database": {},
                                                            "subtype": "column",
                                                            "id": "",
                                                            "subDataArray": [
                                                                {
                                                                    "type": "input",
                                                                    "icon": "fas fa-toggle-off",
                                                                    "description": "Button",
                                                                    "subtype": "button",
                                                                    "handle": true,
                                                                    "studioDevClasses": "d-inline-block",
                                                                    "angular": {
                                                                        "formType": "none",
                                                                        "formGroupName": "",
                                                                        "validationMsg": "",
                                                                        "validators": [],
                                                                        "selectedValidatorsForControls": [],
                                                                        "toolTipShow": false,
                                                                        "tooltipTitle": "",
                                                                        "toolTipPosition": "top",
                                                                        "toolTipEvent": "mouseenter",
                                                                        "validatorChecker": false
                                                                    },
                                                                    "events": {
                                                                        "selectedEventList": [
                                                                            "click"
                                                                        ],
                                                                        "eventData": [
                                                                            {
                                                                                "authorName": "",
                                                                                "args": "",
                                                                                "bodyInfo": [],
                                                                                "desc": "",
                                                                                "eventType": "click",
                                                                                "id": "click_1666159850623",
                                                                                "methodName": "onclicksendall",
                                                                                "nodeType": "",
                                                                                "nodeName": "onclicksendall",
                                                                                "nodeSubType": "method",
                                                                                "params": ""
                                                                            }
                                                                        ]
                                                                    },
                                                                    "database": {
                                                                        "databaseName": "",
                                                                        "tableName": "",
                                                                        "columnName": "",
                                                                        "columnInfo": {},
                                                                        "dbMappingState": "none",
                                                                        "dbMappingMsg": "",
                                                                        "onExcessLoad": false,
                                                                        "master": false
                                                                    },
                                                                    "properties": {
                                                                        "label": "Send ALL",
                                                                        "placeholder": "Button",
                                                                        "name": "input_1666159666276",
                                                                        "regex": "",
                                                                        "disable": false,
                                                                        "visibility": true,
                                                                        "starSymbol": false,
                                                                        "required": false,
                                                                        "iconClass": "fas fa-paper-plane ",
                                                                        "iconPosition": "before",
                                                                        "animationCss": "",
                                                                        "selectedAnimationArray": [],
                                                                        "elementClass": "",
                                                                        "selectedElementClassArray": [],
                                                                        "additionElementClass": "",
                                                                        "defaultElementCls": "btn btn-primary input~button#Element rounded-0",
                                                                        "elementInnerStyles": {},
                                                                        "globelAttrLogic": "",
                                                                        "controlBindingType": "static"
                                                                    },
                                                                    "parseCtrl": {
                                                                        "subData": false,
                                                                        "layerTopId": "input~button#ElementPrnt",
                                                                        "layerCount": "2",
                                                                        "layerCtrls": [
                                                                            "input~button#ElementPrnt",
                                                                            "input~button#Element"
                                                                        ]
                                                                    },
                                                                    "subDataArray": [],
                                                                    "id": "input_1666159666276",
                                                                    "parentId": "",
                                                                    "isCurrentlySelected": false,
                                                                    "routerLink": null,
                                                                    "loadChildrenMod": "",
                                                                    "errorText": "Please enter a valid Value",
                                                                    "projectConfigProperties": [
                                                                        "name",
                                                                        "label",
                                                                        "disable",
                                                                        "visibility",
                                                                        "animationCss",
                                                                        "iconClass",
                                                                        "iconPosition",
                                                                        "expandCollapseForCtrl",
                                                                        "globelAttrLogic",
                                                                        "controlBindingType",
                                                                        "formType",
                                                                        "formGroupName",
                                                                        "validatorChecker",
                                                                        "selectedEventList",
                                                                        "combineAllModel"
                                                                    ],
                                                                    "windowProperties": [
                                                                        "name",
                                                                        "label",
                                                                        "disable",
                                                                        "visibility",
                                                                        "animationCss",
                                                                        "iconClass",
                                                                        "iconPosition",
                                                                        "expandCollapseForCtrl",
                                                                        "globelAttrLogic",
                                                                        "controlBindingType",
                                                                        "formType",
                                                                        "formGroupName",
                                                                        "validatorChecker",
                                                                        "selectedEventList",
                                                                        "combineAllModel"
                                                                    ],
                                                                    "attributeLogiclayer": [
                                                                        {
                                                                            "label": "globelAttrLogic",
                                                                            "name": "Globel AttrLogic",
                                                                            "value": "globelLogic",
                                                                            "type": "globelAttrLogics",
                                                                            "id": null,
                                                                            "selAttrs": [],
                                                                            "attrList": []
                                                                        },
                                                                        {
                                                                            "label": "elemAttrLogic",
                                                                            "name": "Element AttrLogic",
                                                                            "value": "elemAttrLogic",
                                                                            "type": "elemAttrLogics",
                                                                            "id": null,
                                                                            "selAttrs": [
                                                                                "label",
                                                                                "tooltip"
                                                                            ],
                                                                            "attrList": []
                                                                        }
                                                                    ],
                                                                    "applicableAttributeLogic": [
                                                                        "globelLogic",
                                                                        "elemAttrLogic"
                                                                    ],
                                                                    "selectedEventList": " click "
                                                                },
                                                                {
                                                                    "type": "input",
                                                                    "icon": "fas fa-toggle-off",
                                                                    "description": "Button",
                                                                    "subtype": "button",
                                                                    "handle": true,
                                                                    "studioDevClasses": "d-inline-block",
                                                                    "angular": {
                                                                        "formType": "none",
                                                                        "formGroupName": "",
                                                                        "validationMsg": "",
                                                                        "validators": [],
                                                                        "selectedValidatorsForControls": [],
                                                                        "toolTipShow": false,
                                                                        "tooltipTitle": "",
                                                                        "toolTipPosition": "top",
                                                                        "toolTipEvent": "mouseenter",
                                                                        "validatorChecker": false
                                                                    },
                                                                    "events": {
                                                                        "selectedEventList": [
                                                                            "click"
                                                                        ],
                                                                        "eventData": [
                                                                            {
                                                                                "authorName": "",
                                                                                "args": "",
                                                                                "bodyInfo": [],
                                                                                "desc": "",
                                                                                "eventType": "click",
                                                                                "id": "click_1666161147455",
                                                                                "methodName": "closeModal",
                                                                                "nodeType": "",
                                                                                "nodeName": "closeModal",
                                                                                "nodeSubType": "method",
                                                                                "params": ""
                                                                            }
                                                                        ]
                                                                    },
                                                                    "database": {
                                                                        "databaseName": "",
                                                                        "tableName": "",
                                                                        "columnName": "",
                                                                        "columnInfo": {},
                                                                        "dbMappingState": "none",
                                                                        "dbMappingMsg": "",
                                                                        "onExcessLoad": false,
                                                                        "master": false
                                                                    },
                                                                    "properties": {
                                                                        "label": "Cancel",
                                                                        "placeholder": "Button",
                                                                        "name": "input_1666159681606",
                                                                        "regex": "",
                                                                        "disable": false,
                                                                        "visibility": true,
                                                                        "starSymbol": false,
                                                                        "required": false,
                                                                        "iconClass": "fas fa-times",
                                                                        "iconPosition": "before",
                                                                        "animationCss": "",
                                                                        "selectedAnimationArray": [],
                                                                        "elementClass": "",
                                                                        "selectedElementClassArray": [],
                                                                        "additionElementClass": "ms-2",
                                                                        "defaultElementCls": "btn btn-danger input~button#Element rounded-0",
                                                                        "elementInnerStyles": {},
                                                                        "globelAttrLogic": "",
                                                                        "controlBindingType": "static"
                                                                    },
                                                                    "parseCtrl": {
                                                                        "subData": false,
                                                                        "layerTopId": "input~button#ElementPrnt",
                                                                        "layerCount": "2",
                                                                        "layerCtrls": [
                                                                            "input~button#ElementPrnt",
                                                                            "input~button#Element"
                                                                        ]
                                                                    },
                                                                    "subDataArray": [],
                                                                    "id": "input_1666159681606",
                                                                    "parentId": "",
                                                                    "isCurrentlySelected": true,
                                                                    "routerLink": null,
                                                                    "loadChildrenMod": "",
                                                                    "errorText": "Please enter a valid Value",
                                                                    "projectConfigProperties": [
                                                                        "name",
                                                                        "label",
                                                                        "disable",
                                                                        "visibility",
                                                                        "animationCss",
                                                                        "iconClass",
                                                                        "iconPosition",
                                                                        "expandCollapseForCtrl",
                                                                        "globelAttrLogic",
                                                                        "controlBindingType",
                                                                        "formType",
                                                                        "formGroupName",
                                                                        "validatorChecker",
                                                                        "selectedEventList",
                                                                        "combineAllModel"
                                                                    ],
                                                                    "windowProperties": [
                                                                        "name",
                                                                        "label",
                                                                        "disable",
                                                                        "visibility",
                                                                        "animationCss",
                                                                        "iconClass",
                                                                        "iconPosition",
                                                                        "expandCollapseForCtrl",
                                                                        "globelAttrLogic",
                                                                        "controlBindingType",
                                                                        "formType",
                                                                        "formGroupName",
                                                                        "validatorChecker",
                                                                        "selectedEventList",
                                                                        "combineAllModel"
                                                                    ],
                                                                    "attributeLogiclayer": [
                                                                        {
                                                                            "label": "globelAttrLogic",
                                                                            "name": "Globel AttrLogic",
                                                                            "value": "globelLogic",
                                                                            "type": "globelAttrLogics",
                                                                            "id": null,
                                                                            "selAttrs": [],
                                                                            "attrList": []
                                                                        },
                                                                        {
                                                                            "label": "elemAttrLogic",
                                                                            "name": "Element AttrLogic",
                                                                            "value": "elemAttrLogic",
                                                                            "type": "elemAttrLogics",
                                                                            "id": null,
                                                                            "selAttrs": [
                                                                                "label",
                                                                                "tooltip"
                                                                            ],
                                                                            "attrList": []
                                                                        }
                                                                    ],
                                                                    "applicableAttributeLogic": [
                                                                        "globelLogic",
                                                                        "elemAttrLogic"
                                                                    ],
                                                                    "selectedEventList": " click "
                                                                }
                                                            ],
                                                            "events": {},
                                                            "properties": {
                                                                "additionElementClass": "text-end",
                                                                "visibility": true,
                                                                "selectedElementClassArray": [],
                                                                "name": "",
                                                                "defaultElementCls": "",
                                                                "elementInnerStyles": {},
                                                                "controlBindingType": "static",
                                                                "globelAttrLogic": "",
                                                                "label": "Column",
                                                                "elementClass": "",
                                                                "colClass": "col-sm-12"
                                                            },
                                                            "windowProperties": [
                                                                "name",
                                                                "label",
                                                                "visibility",
                                                                "colClass",
                                                                "expandCollapseForCtrl",
                                                                "globelAttrLogic",
                                                                "controlBindingType"
                                                            ]
                                                        }
                                                    ],
                                                    "events": {},
                                                    "properties": {
                                                        "additionElementClass": "",
                                                        "visibility": true,
                                                        "selectedElementClassArray": [],
                                                        "name": "row_1666090727782",
                                                        "defaultElementCls": "row",
                                                        "elementInnerStyles": {},
                                                        "controlBindingType": "static",
                                                        "globelAttrLogic": "",
                                                        "label": "Row",
                                                        "elementClass": ""
                                                    },
                                                    "windowProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ]
                                                }
                                            ],
                                            "events": {
                                                "selectedEventList": [],
                                                "eventData": []
                                            },
                                            "properties": {
                                                "additionElementClass": "",
                                                "visibility": true,
                                                "selectedElementClassArray": [],
                                                "name": "",
                                                "defaultElementCls": "modal-footer",
                                                "elementInnerStyles": {},
                                                "controlBindingType": "static",
                                                "globelAttrLogic": "",
                                                "label": "modelFooter",
                                                "elementClass": "",
                                                "validationClass": true
                                            },
                                            "windowProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelClasses",
                                                "additionGlobelClasses",
                                                "defaultGlobelCls",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ]
                                        },
                                        "parseCtrl": {
                                            "subData": false,
                                            "layerCount": "2",
                                            "layerTopId": "bootstrapModals~bootstrapModals#Globel",
                                            "layerCtrls": [
                                                "bootstrapModals~bootstrapModals#Globel",
                                                "bootstrapModals~bootstrapModals#Element"
                                            ]
                                        },
                                        "type": "bootstrapModals",
                                        "projectConfigProperties": [
                                            "visibility",
                                            "tooltip"
                                        ],
                                        "database": {
                                            "onExcessLoad": false,
                                            "databaseName": "",
                                            "dbMappingState": "none",
                                            "columnInfo": {},
                                            "tableName": "",
                                            "columnName": "",
                                            "dbMappingMsg": "",
                                            "master": false
                                        },
                                        "modelHeader": {
                                            "attributeLogiclayer": [
                                                {
                                                    "name": "Globel AttrLogic",
                                                    "selAttrs": [],
                                                    "label": "globelAttrLogic",
                                                    "id": null,
                                                    "type": "globelAttrLogics",
                                                    "value": "globelLogic",
                                                    "attrList": []
                                                },
                                                {
                                                    "name": "Element AttrLogic",
                                                    "selAttrs": [
                                                        "label",
                                                        "tooltip"
                                                    ],
                                                    "label": "elemAttrLogic",
                                                    "id": null,
                                                    "type": "elemAttrLogics",
                                                    "value": "elemAttrLogic",
                                                    "attrList": []
                                                }
                                            ],
                                            "icon": "fa-columns",
                                            "isCurrentlySelected": false,
                                            "description": "modelHeader Here",
                                            "handle": true,
                                            "parseCtrl": {
                                                "subData": false,
                                                "layerCount": "2",
                                                "layerTopId": "modelHeader~modelHeader#Globel",
                                                "layerCtrls": [
                                                    "modelHeader~modelHeader#Globel",
                                                    "modelHeader~modelHeader#Element"
                                                ]
                                            },
                                            "type": "modelHeader",
                                            "studioDevClasses": "d-block",
                                            "projectConfigProperties": [
                                                "visibility",
                                                "tooltip"
                                            ],
                                            "parentId": null,
                                            "angular": {
                                                "tooltipTitle": "",
                                                "formType": "none",
                                                "validationMsg": "",
                                                "toolTipPosition": "top",
                                                "formGroupName": "",
                                                "toolTipEvent": "mouseenter",
                                                "validators": [],
                                                "toolTip": "i am Toop Tip",
                                                "selectedValidatorsForControls": [],
                                                "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                                "globelLogic",
                                                "elemAttrLogic"
                                            ],
                                            "database": {
                                                "onExcessLoad": false,
                                                "databaseName": "",
                                                "dbMappingState": "none",
                                                "columnInfo": {},
                                                "tableName": "",
                                                "columnName": "",
                                                "dbMappingMsg": "",
                                                "master": false
                                            },
                                            "subtype": "modelHeader",
                                            "id": null,
                                            "subDataArray": [
                                                {
                                                    "attributeLogiclayer": [
                                                        {
                                                            "name": "Globel AttrLogic",
                                                            "selAttrs": [],
                                                            "label": "globelAttrLogic",
                                                            "id": null,
                                                            "type": "globelAttrLogics",
                                                            "value": "globelLogic",
                                                            "attrList": []
                                                        },
                                                        {
                                                            "name": "Element AttrLogic",
                                                            "selAttrs": [
                                                                "label",
                                                                "tooltip"
                                                            ],
                                                            "label": "elemAttrLogic",
                                                            "id": null,
                                                            "type": "elemAttrLogics",
                                                            "value": "elemAttrLogic",
                                                            "attrList": []
                                                        }
                                                    ],
                                                    "icon": "fas fa-heading",
                                                    "isCurrentlySelected": false,
                                                    "description": "Enter your heading",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                        "subData": false,
                                                        "layerCount": "2",
                                                        "layerTopId": "headings~headings#Globel",
                                                        "layerCtrls": [
                                                            "headings~headings#Element"
                                                        ]
                                                    },
                                                    "label": "Send All Mail",
                                                    "type": "headings",
                                                    "studioDevClasses": "d-block",
                                                    "projectConfigProperties": [
                                                        "headingType",
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "iconPosition",
                                                        "iconClass",
                                                        "animationCss",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType",
                                                        "formType",
                                                        "formGroupName",
                                                        "custom_msgAdd",
                                                        "allValidationList",
                                                        "tooltip",
                                                        "selectedEventList",
                                                        "combineAllModel",
                                                        "databaseName",
                                                        "tableName",
                                                        "columnName",
                                                        "onExcessLoad",
                                                        "master"
                                                    ],
                                                    "parentId": null,
                                                    "angular": {
                                                        "tooltipTitle": "",
                                                        "formType": "none",
                                                        "validationMsg": "",
                                                        "toolTipPosition": "top",
                                                        "formGroupName": "",
                                                        "toolTipEvent": "mouseenter",
                                                        "validators": [],
                                                        "selectedValidatorsForControls": [],
                                                        "toolTipShow": false
                                                    },
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                        "globelLogic",
                                                        "elemAttrLogic"
                                                    ],
                                                    "database": {
                                                        "onExcessLoad": false,
                                                        "databaseName": "",
                                                        "dbMappingState": "none",
                                                        "columnInfo": {},
                                                        "tableName": "",
                                                        "columnName": "",
                                                        "dbMappingMsg": "",
                                                        "master": false
                                                    },
                                                    "subtype": "headings",
                                                    "id": "headings_1666091158802",
                                                    "subDataArray": [],
                                                    "events": {
                                                        "selectedEventList": [],
                                                        "eventData": []
                                                    },
                                                    "properties": {
                                                        "visibility": true,
                                                        "selectedElementClassArray": [],
                                                        "headingValue": "5",
                                                        "animationCss": "",
                                                        "globelAttrLogic": "",
                                                        "label": "Send All Mail",
                                                        "required": false,
                                                        "iconClass": "",
                                                        "additionElementClass": "",
                                                        "name": "headings_1666091158802",
                                                        "iconPosition": "before",
                                                        "defaultElementCls": "text-dark",
                                                        "elementInnerStyles": {},
                                                        "controlBindingType": "static",
                                                        "placeholder": null,
                                                        "elementClass": "",
                                                        "starSymbol": false,
                                                        "selectedAnimationArray": []
                                                    },
                                                    "windowProperties": [
                                                        "headingType",
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "iconPosition",
                                                        "iconClass",
                                                        "animationCss",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType",
                                                        "formType",
                                                        "formGroupName",
                                                        "custom_msgAdd",
                                                        "allValidationList",
                                                        "tooltip",
                                                        "selectedEventList",
                                                        "combineAllModel",
                                                        "databaseName",
                                                        "tableName",
                                                        "columnName",
                                                        "onExcessLoad",
                                                        "master"
                                                    ]
                                                }
                                            ],
                                            "events": {
                                                "selectedEventList": [],
                                                "eventData": []
                                            },
                                            "properties": {
                                                "visibility": true,
                                                "selectedElementClassArray": [],
                                                "globelAttrLogic": "",
                                                "label": "modelHeader",
                                                "required": false,
                                                "additionElementClass": "",
                                                "name": "",
                                                "defaultElementCls": "modal-header p-2",
                                                "elementInnerStyles": {},
                                                "controlBindingType": "static",
                                                "placeholder": " ",
                                                "elementClass": "",
                                                "starSymbol": false,
                                                "validationClass": true
                                            },
                                            "windowProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ]
                                        },
                                        "subtype": "bootstrapModals",
                                        "children": [],
                                        "id": "bootstrapModals_1666089870680",
                                        "events": {
                                            "selectedEventList": [],
                                            "eventData": []
                                        },
                                        "isCurrentlySelected": false,
                                        "handle": true,
                                        "studioDevClasses": "d-block",
                                        "parentId": null,
                                        "angular": {
                                            "tooltipTitle": "",
                                            "formType": "none",
                                            "validationMsg": "",
                                            "toolTipPosition": "top",
                                            "formGroupName": "",
                                            "toolTipEvent": "mouseenter",
                                            "validators": [],
                                            "toolTip": "i am Toop Tip",
                                            "selectedValidatorsForControls": [],
                                            "toolTipShow": false
                                        },
                                        "errorText": "Please enter a valid Value",
                                        "applicableAttributeLogic": [
                                            "globelLogic",
                                            "elemAttrLogic"
                                        ],
                                        "modelBody": {
                                            "attributeLogiclayer": [
                                                {
                                                    "name": "Globel AttrLogic",
                                                    "selAttrs": [],
                                                    "label": "globelAttrLogic",
                                                    "id": null,
                                                    "type": "globelAttrLogics",
                                                    "value": "globelLogic",
                                                    "attrList": []
                                                },
                                                {
                                                    "name": "Element AttrLogic",
                                                    "selAttrs": [
                                                        "label",
                                                        "tooltip"
                                                    ],
                                                    "label": "elemAttrLogic",
                                                    "id": null,
                                                    "type": "elemAttrLogics",
                                                    "value": "elemAttrLogic",
                                                    "attrList": []
                                                }
                                            ],
                                            "icon": "fa-columns",
                                            "isCurrentlySelected": false,
                                            "description": "modelBody Here",
                                            "handle": true,
                                            "parseCtrl": {
                                                "subData": false,
                                                "layerCount": "2",
                                                "layerTopId": "modelBody~modelBody#Globel",
                                                "layerCtrls": [
                                                    "modelBody~modelBody#Globel",
                                                    "modelBody~modelBody#Element"
                                                ]
                                            },
                                            "type": "modelBody",
                                            "studioDevClasses": "d-block",
                                            "projectConfigProperties": [
                                                "visibility",
                                                "tooltip"
                                            ],
                                            "parentId": null,
                                            "angular": {
                                                "tooltipTitle": "",
                                                "formType": "none",
                                                "validationMsg": "",
                                                "toolTipPosition": "top",
                                                "formGroupName": "",
                                                "toolTipEvent": "mouseenter",
                                                "validators": [],
                                                "toolTip": "i am Toop Tip",
                                                "selectedValidatorsForControls": [],
                                                "toolTipShow": false
                                            },
                                            "errorText": "Please enter a valid Value",
                                            "applicableAttributeLogic": [
                                                "globelLogic",
                                                "elemAttrLogic"
                                            ],
                                            "database": {
                                                "onExcessLoad": false,
                                                "databaseName": "",
                                                "dbMappingState": "none",
                                                "columnInfo": {},
                                                "tableName": "",
                                                "columnName": "",
                                                "dbMappingMsg": "",
                                                "master": false
                                            },
                                            "subtype": "modelBody",
                                            "id": null,
                                            "subDataArray": [
                                                {
                                                    "attributeLogiclayer": [
                                                        {
                                                            "name": "Globel AttrLogic",
                                                            "selAttrs": [],
                                                            "label": "globelAttrLogic",
                                                            "id": null,
                                                            "type": "globelAttrLogics",
                                                            "value": "globelLogic",
                                                            "attrList": []
                                                        },
                                                        {
                                                            "name": "Element AttrLogic",
                                                            "selAttrs": [],
                                                            "label": "elemAttrLogic",
                                                            "id": null,
                                                            "type": "elemAttrLogics",
                                                            "value": "elemAttrLogic",
                                                            "attrList": []
                                                        }
                                                    ],
                                                    "icon": "fa-columns",
                                                    "isCurrentlySelected": false,
                                                    "description": "Row Here",
                                                    "handle": true,
                                                    "parseCtrl": {
                                                        "subData": true,
                                                        "layerCount": "1",
                                                        "layerTopId": "row~Element",
                                                        "layerCtrls": [
                                                            "row~Element"
                                                        ]
                                                    },
                                                    "type": "row",
                                                    "studioDevClasses": "",
                                                    "projectConfigProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ],
                                                    "parentId": "",
                                                    "angular": {},
                                                    "errorText": "Please enter a valid Value",
                                                    "applicableAttributeLogic": [
                                                        "globelLogic",
                                                        "elemAttrLogic"
                                                    ],
                                                    "database": {},
                                                    "subtype": "row",
                                                    "id": "row_1666089955807",
                                                    "validationClass": true,
                                                    "subDataArray": [
                                                        {
                                                            "attributeLogiclayer": [
                                                                {
                                                                    "name": "Globel AttrLogic",
                                                                    "selAttrs": [],
                                                                    "label": "globelAttrLogic",
                                                                    "id": null,
                                                                    "type": "globelAttrLogics",
                                                                    "value": "globelLogic",
                                                                    "attrList": []
                                                                },
                                                                {
                                                                    "name": "Element AttrLogic",
                                                                    "selAttrs": [],
                                                                    "label": "elemAttrLogic",
                                                                    "id": null,
                                                                    "type": "elemAttrLogics",
                                                                    "value": "elemAttrLogic",
                                                                    "attrList": []
                                                                }
                                                            ],
                                                            "icon": null,
                                                            "isCurrentlySelected": false,
                                                            "description": "Create Column Here",
                                                            "handle": true,
                                                            "parseCtrl": {
                                                                "subData": true,
                                                                "layerCount": "1",
                                                                "layerTopId": "column#Globel",
                                                                "layerCtrls": [
                                                                    "column#Globel"
                                                                ]
                                                            },
                                                            "type": "column",
                                                            "studioDevClasses": "",
                                                            "projectConfigProperties": [
                                                                "name",
                                                                "label",
                                                                "visibility",
                                                                "colClass",
                                                                "expandCollapseForCtrl",
                                                                "globelAttrLogic",
                                                                "controlBindingType"
                                                            ],
                                                            "parentId": "",
                                                            "angular": {},
                                                            "applicableAttributeLogic": [
                                                                "globelLogic",
                                                                "elemAttrLogic"
                                                            ],
                                                            "database": {},
                                                            "subtype": "column",
                                                            "id": "",
                                                            "subDataArray": [
                                                                {
                                                                    "attributeLogiclayer": [
                                                                        {
                                                                            "name": "Globel AttrLogic",
                                                                            "selAttrs": [],
                                                                            "label": "globelAttrLogic",
                                                                            "id": null,
                                                                            "type": "globelAttrLogics",
                                                                            "value": "globelLogic",
                                                                            "attrList": []
                                                                        },
                                                                        {
                                                                            "name": "Element AttrLogic",
                                                                            "selAttrs": [
                                                                                "label",
                                                                                "tooltip"
                                                                            ],
                                                                            "label": "elemAttrLogic",
                                                                            "id": null,
                                                                            "type": "elemAttrLogics",
                                                                            "value": "elemAttrLogic",
                                                                            "attrList": []
                                                                        }
                                                                    ],
                                                                    "icon": "fas fa-border-none",
                                                                    "description": "Sag Grid",
                                                                    "totalColumns": 4,
                                                                    "parseCtrl": {
                                                                        "subData": false,
                                                                        "layerCount": "2",
                                                                        "layerTopId": "",
                                                                        "layerCtrls": []
                                                                    },
                                                                    "type": "sagGrid",
                                                                    "projectConfigProperties": [
                                                                        "name",
                                                                        "visibility",
                                                                        "expandCollapseForCtrl",
                                                                        "totalColumns",
                                                                        "rowHeight",
                                                                        "addRowBtn",
                                                                        "deleteRowBtn",
                                                                        "gridFilter",
                                                                        "gridStatusBar",
                                                                        "footerHide",
                                                                        "totalNoOfRecordHide",
                                                                        "smlexpandGridHide",
                                                                        "exportXlsxPageHide",
                                                                        "exportXlsxAllPageHide",
                                                                        "exportPDFLandscapeHide",
                                                                        "exportPDFPortraitHide",
                                                                        "ariaHiddenHide",
                                                                        "headerStyle",
                                                                        "rowEvenStyle",
                                                                        "rowOddStyle",
                                                                        "gridExpandViewShow",
                                                                        "globelAttrLogic",
                                                                        "controlBindingType"
                                                                    ],
                                                                    "sagGridFullscreen": false,
                                                                    "database": {},
                                                                    "subtype": "sagGrid",
                                                                    "id": "sagGrid_1666089959616",
                                                                    "events": {},
                                                                    "tableBody": {
                                                                        "values": [
                                                                            {},
                                                                            {},
                                                                            {},
                                                                            {}
                                                                        ],
                                                                        "icon": "fa-columns",
                                                                        "description": "tableBody Here",
                                                                        "handle": true,
                                                                        "parseCtrl": {
                                                                            "subData": false,
                                                                            "layerCount": "2",
                                                                            "layerTopId": "",
                                                                            "layerCtrls": []
                                                                        },
                                                                        "type": "tableBody",
                                                                        "studioDevClasses": "d-block",
                                                                        "projectConfigProperties": [
                                                                            "label"
                                                                        ],
                                                                        "parentId": null,
                                                                        "angular": {},
                                                                        "errorText": "Please select a valid Div",
                                                                        "database": {},
                                                                        "subtype": "tableBody",
                                                                        "id": null,
                                                                        "subDataArray": [],
                                                                        "events": {},
                                                                        "properties": {
                                                                            "name": "",
                                                                            "label": "tableBody"
                                                                        },
                                                                        "windowProperties": [
                                                                            "label"
                                                                        ]
                                                                    },
                                                                    "openHeaderSection": true,
                                                                    "isCurrentlySelected": false,
                                                                    "handle": true,
                                                                    "studioDevClasses": "d-block",
                                                                    "freezeColumn": {},
                                                                    "parentId": "",
                                                                    "angular": {},
                                                                    "errorText": "Please select a valid Div",
                                                                    "applicableAttributeLogic": [
                                                                        "globelLogic",
                                                                        "elemAttrLogic"
                                                                    ],
                                                                    "name": "sendallmail",
                                                                    "tableHead": {
                                                                        "apiResponseList": [],
                                                                        "values": [
                                                                            {
                                                                                "columnGroup": "",
                                                                                "hidden": false,
                                                                                "editable": false,
                                                                                "values": [
                                                                                    {
                                                                                        "label": "--select--",
                                                                                        "value": ""
                                                                                    }
                                                                                ],
                                                                                "icon": "fas fa-check-double",
                                                                                "label": "label",
                                                                                "type": "sagGridInput",
                                                                                "projectConfigProperties": [
                                                                                    "label"
                                                                                ],
                                                                                "parentId": null,
                                                                                "filter": true,
                                                                                "search": true,
                                                                                "component": "label",
                                                                                "field": "sno",
                                                                                "subtype": "sagGridLabel",
                                                                                "freezeCol": "null",
                                                                                "width": "90px",
                                                                                "header": "S.No",
                                                                                "id": "1666089735146",
                                                                                "subDataArray": [],
                                                                                "windowProperties": [
                                                                                    "label"
                                                                                ],
                                                                                "text-align": "left"
                                                                            },
                                                                            {
                                                                                "hidden": false,
                                                                                "values": [
                                                                                    {
                                                                                        "label": "--select--",
                                                                                        "value": ""
                                                                                    }
                                                                                ],
                                                                                "icon": "fas fa-check-double",
                                                                                "checkboxLabel": false,
                                                                                "type": "sagGridInput",
                                                                                "projectConfigProperties": [
                                                                                    "label",
                                                                                    "regex"
                                                                                ],
                                                                                "search": true,
                                                                                "database": {
                                                                                    "onExcessLoad": false,
                                                                                    "databaseName": "",
                                                                                    "dbMappingState": "none",
                                                                                    "columnInfo": {},
                                                                                    "tableName": "",
                                                                                    "columnName": "",
                                                                                    "dbMappingMsg": "",
                                                                                    "master": false
                                                                                },
                                                                                "subtype": "sagGridText",
                                                                                "id": "1666089989792",
                                                                                "text-align": "left",
                                                                                "columnGroup": "",
                                                                                "editable": false,
                                                                                "isCurrentlySelected": false,
                                                                                "label": "label",
                                                                                "parentId": null,
                                                                                "filter": true,
                                                                                "component": "textInput",
                                                                                "regex": "",
                                                                                "field": "gridData",
                                                                                "freezeCol": "null",
                                                                                "width": "350px",
                                                                                "header": "Grid Data",
                                                                                "subDataArray": [],
                                                                                "windowProperties": [
                                                                                    "label",
                                                                                    "regex",
                                                                                    "databaseName",
                                                                                    "tableName",
                                                                                    "columnName",
                                                                                    "onExcessLoad",
                                                                                    "master"
                                                                                ]
                                                                            },
                                                                            {
                                                                                "hidden": false,
                                                                                "values": [
                                                                                    {
                                                                                        "label": "--select--",
                                                                                        "value": ""
                                                                                    }
                                                                                ],
                                                                                "icon": "fas fa-check-double",
                                                                                "checkboxLabel": false,
                                                                                "type": "sagGridInput",
                                                                                "projectConfigProperties": [
                                                                                    "label",
                                                                                    "regex"
                                                                                ],
                                                                                "search": true,
                                                                                "database": {
                                                                                    "onExcessLoad": false,
                                                                                    "databaseName": "",
                                                                                    "dbMappingState": "none",
                                                                                    "columnInfo": {},
                                                                                    "tableName": "",
                                                                                    "columnName": "",
                                                                                    "dbMappingMsg": "",
                                                                                    "master": false
                                                                                },
                                                                                "subtype": "sagGridButton",
                                                                                "id": "1666090050163",
                                                                                "text-align": "left",
                                                                                "columnGroup": "",
                                                                                "editable": false,
                                                                                "isCurrentlySelected": false,
                                                                                "label": "label",
                                                                                "parentId": null,
                                                                                "filter": true,
                                                                                "component": "button",
                                                                                "regex": "",
                                                                                "field": "view",
                                                                                "freezeCol": "null",
                                                                                "width": "150px",
                                                                                "header": "View",
                                                                                "subDataArray": [],
                                                                                "windowProperties": [
                                                                                    "label",
                                                                                    "regex",
                                                                                    "databaseName",
                                                                                    "tableName",
                                                                                    "columnName",
                                                                                    "onExcessLoad",
                                                                                    "master"
                                                                                ]
                                                                            },
                                                                            {
                                                                                "hidden": false,
                                                                                "values": [
                                                                                    {
                                                                                        "label": "--select--",
                                                                                        "value": ""
                                                                                    }
                                                                                ],
                                                                                "icon": "fas fa-check-double",
                                                                                "checkboxLabel": false,
                                                                                "type": "sagGridInput",
                                                                                "projectConfigProperties": [
                                                                                    "label",
                                                                                    "regex"
                                                                                ],
                                                                                "search": true,
                                                                                "database": {
                                                                                    "onExcessLoad": false,
                                                                                    "databaseName": "",
                                                                                    "dbMappingState": "none",
                                                                                    "columnInfo": {},
                                                                                    "tableName": "",
                                                                                    "columnName": "",
                                                                                    "dbMappingMsg": "",
                                                                                    "master": false
                                                                                },
                                                                                "subtype": "sagGridButton",
                                                                                "id": "1666090068781",
                                                                                "text-align": "left",
                                                                                "columnGroup": "",
                                                                                "editable": false,
                                                                                "isCurrentlySelected": false,
                                                                                "label": "label",
                                                                                "parentId": null,
                                                                                "filter": true,
                                                                                "component": "button",
                                                                                "regex": "",
                                                                                "field": "send",
                                                                                "freezeCol": "null",
                                                                                "width": "150px",
                                                                                "header": "Send",
                                                                                "subDataArray": [],
                                                                                "windowProperties": [
                                                                                    "label",
                                                                                    "regex",
                                                                                    "databaseName",
                                                                                    "tableName",
                                                                                    "columnName",
                                                                                    "onExcessLoad",
                                                                                    "master"
                                                                                ]
                                                                            }
                                                                        ],
                                                                        "icon": "fa-columns",
                                                                        "isCurrentlySelected": false,
                                                                        "description": "tableHead Here",
                                                                        "handle": true,
                                                                        "type": "tableHead",
                                                                        "studioDevClasses": "d-block",
                                                                        "projectConfigProperties": [
                                                                            "label"
                                                                        ],
                                                                        "parentId": null,
                                                                        "angular": {},
                                                                        "columnType": [
                                                                            {
                                                                                "id": "label",
                                                                                "text": "Label"
                                                                            },
                                                                            {
                                                                                "id": "textInput",
                                                                                "text": "Text"
                                                                            },
                                                                            {
                                                                                "id": "numberInput",
                                                                                "text": "Number"
                                                                            },
                                                                            {
                                                                                "id": "dateInput",
                                                                                "text": "Date"
                                                                            },
                                                                            {
                                                                                "id": "selectInput",
                                                                                "text": "Select"
                                                                            },
                                                                            {
                                                                                "id": "checkBox",
                                                                                "text": "CheckBox"
                                                                            },
                                                                            {
                                                                                "id": "button",
                                                                                "text": "Button"
                                                                            },
                                                                            {
                                                                                "id": "btnInHeader",
                                                                                "text": "ButtonInHeader"
                                                                            },
                                                                            {
                                                                                "id": "rowDelete",
                                                                                "text": "rowDelete"
                                                                            }
                                                                        ],
                                                                        "errorText": "Please select a valid Table Head",
                                                                        "database": {},
                                                                        "subtype": "tableHead",
                                                                        "id": null,
                                                                        "subDataArray": [],
                                                                        "events": {},
                                                                        "properties": {
                                                                            "name": "",
                                                                            "label": "tableHead"
                                                                        },
                                                                        "windowProperties": [
                                                                            "label"
                                                                        ]
                                                                    },
                                                                    "subDataArray": [],
                                                                    "properties": {
                                                                        "exportPDFLandscapeHide": false,
                                                                        "selectedElementClassArray": [],
                                                                        "totalColumns": 1,
                                                                        "globelAttrLogic": "",
                                                                        "rowEvenStyle": {
                                                                           /*  "height": "300px",
                                                                            "min-height": "300px" */
                                                                        },
                                                                        "exportXlsxPageHide": false,
                                                                        "headerStyle": {
                                                                            "height": "px",
                                                                            "min-height": "px"
                                                                        },
                                                                        "additionElementClass": "",
                                                                        "deleteRowBtn": false,
                                                                        "defaultElementCls": "table-area masterdiv",
                                                                        "controlBindingType": "static",
                                                                        "elementClass": "",
                                                                        "footerHide": false,
                                                                        "totalNoOfRecordHide": false,
                                                                        "exportXlsxAllPageHide": false,
                                                                        "exportPDFPortraitHide": false,
                                                                        "rowHeight": 20,
                                                                        "gridFilter": true,
                                                                        "visibility": true,
                                                                        "rowOddStyle": {},
                                                                        "label": "Sag Grid",
                                                                        "smlexpandGridHide": false,
                                                                        "addRowBtn": false,
                                                                        "name": "sendallmail",
                                                                        "elementInnerStyles": {
                                                                            "height": "300px"
                                                                        },
                                                                        "ariaHiddenHide": false
                                                                    },
                                                                    "windowProperties": [
                                                                        "name",
                                                                        "visibility",
                                                                        "expandCollapseForCtrl",
                                                                        "totalColumns",
                                                                        "rowHeight",
                                                                        "addRowBtn",
                                                                        "deleteRowBtn",
                                                                        "gridFilter",
                                                                        "gridStatusBar",
                                                                        "footerHide",
                                                                        "totalNoOfRecordHide",
                                                                        "smlexpandGridHide",
                                                                        "exportXlsxPageHide",
                                                                        "exportXlsxAllPageHide",
                                                                        "exportPDFLandscapeHide",
                                                                        "exportPDFPortraitHide",
                                                                        "ariaHiddenHide",
                                                                        "headerStyle",
                                                                        "rowEvenStyle",
                                                                        "rowOddStyle",
                                                                        "gridExpandViewShow",
                                                                        "globelAttrLogic",
                                                                        "controlBindingType"
                                                                    ]
                                                                }
                                                            ],
                                                            "events": {},
                                                            "properties": {
                                                                "additionElementClass": "",
                                                                "visibility": true,
                                                                "selectedElementClassArray": [],
                                                                "name": "",
                                                                "defaultElementCls": "",
                                                                "elementInnerStyles": {},
                                                                "controlBindingType": "static",
                                                                "globelAttrLogic": "",
                                                                "label": "Column",
                                                                "elementClass": "",
                                                                "colClass": "col-sm-12"
                                                            },
                                                            "windowProperties": [
                                                                "name",
                                                                "label",
                                                                "visibility",
                                                                "colClass",
                                                                "expandCollapseForCtrl",
                                                                "globelAttrLogic",
                                                                "controlBindingType"
                                                            ]
                                                        }
                                                    ],
                                                    "events": {},
                                                    "properties": {
                                                        "additionElementClass": "",
                                                        "visibility": true,
                                                        "selectedElementClassArray": [],
                                                        "name": "row_1666089955807",
                                                        "defaultElementCls": "row",
                                                        "elementInnerStyles": {},
                                                        "controlBindingType": "static",
                                                        "globelAttrLogic": "",
                                                        "label": "Row",
                                                        "elementClass": ""
                                                    },
                                                    "windowProperties": [
                                                        "name",
                                                        "label",
                                                        "visibility",
                                                        "expandCollapseForCtrl",
                                                        "globelAttrLogic",
                                                        "controlBindingType"
                                                    ]
                                                }
                                            ],
                                            "events": {
                                                "selectedEventList": [],
                                                "eventData": []
                                            },
                                            "properties": {
                                                "additionElementClass": "",
                                                "visibility": true,
                                                "selectedElementClassArray": [],
                                                "name": "",
                                                "defaultElementCls": "modal-body h-100 d-flex flex-column",
                                                "elementInnerStyles": {},
                                                "controlBindingType": "static",
                                                "globelAttrLogic": "",
                                                "label": "modelBody",
                                                "elementClass": "",
                                                "validationClass": true,
                                                "required": false
                                            },
                                            "windowProperties": [
                                                "name",
                                                "label",
                                                "visibility",
                                                "expandCollapseForCtrl",
                                                "globelClasses",
                                                "additionGlobelClasses",
                                                "defaultGlobelCls",
                                                "globelAttrLogic",
                                                "controlBindingType"
                                            ]
                                        },
                                        "name": "usersendallmail",
                                        "subDataArray": [],
                                        "properties": {
                                            "visibility": true,
                                            "selectedGlobalClassArray": [],
                                            "defaultGlobelCls": "modal-lg modal-dialog modal-dialog-centered",
                                            "globelAttrLogic": "",
                                            "label": "Bootstrap Modals",
                                            "globelClasses": "",
                                            "modalPosition": "sagModal_top",
                                            "backDrop": true,
                                            "name": "usersendallmail",
                                            "controlBindingType": "static",
                                            "placeholder": "bootstrap Modals",
                                            "globalInnerStyles": {},
                                            "additionGlobelClasses": ""
                                        },
                                        "windowProperties": [
                                            "name",
                                            "backDrop",
                                            "modalPosition",
                                            "expandCollapseForGlobal",
                                            "bootModalExpandViewShow",
                                            "globelAttrLogic",
                                            "controlBindingType"
                                        ]
                                    }
                                ],
                                "properties": {
                                    "additionElementClass": "",
                                    "visibility": true,
                                    "selectedElementClassArray": [],
                                    "name": "",
                                    "controlBindingType": "static",
                                    "defaultElementCls": "d-flex flex-column full-modal h-100 pageContainer#Globel",
                                    "elementInnerStyles": {},
                                    "globelAttrLogic": "",
                                    "label": "Page Container",
                                    "elementClass": ""
                                },
                                "events": {
                                    "selectedEventList": [],
                                    "eventData": []
                                },
                                "windowProperties": [
                                    "name",
                                    "label",
                                    "visibility",
                                    "expandCollapseForCtrl",
                                    "globelAttrLogic",
                                    "controlBindingType",
                                    "selectedEventList",
                                    "combineAllModel"
                                ]
                            }
                        ],
                        "properties": {
                            "additionElementClass": "",
                            "visibility": true,
                            "selectedElementClassArray": [],
                            "name": "",
                            "controlBindingType": "static",
                            "defaultElementCls": "d-flex flex-column full-modal h-100 pageContainer#Globel",
                            "elementInnerStyles": {},
                            "globelAttrLogic": "",
                            "label": "Page Container",
                            "elementClass": ""
                        },
                        "events": {
                            "selectedEventList": [],
                            "eventData": []
                        },
                        "windowProperties": [
                            "name",
                            "label",
                            "visibility",
                            "expandCollapseForCtrl",
                            "globelAttrLogic",
                            "controlBindingType",
                            "selectedEventList",
                            "combineAllModel"
                        ]
                    }
                ],
                "cssData": {},
                "tsData": {
                    "diInConstructor": [
                        {
                            "diName": "SendmailService",
                            "diType": "public",
                            "diShortName": "sendmail",
                            "diImportPath": "src/app/custommodules/sendmail/sendmail.share.service"
                        }
                    ],
                    "varAndMethodList": [
                        {
                            name: `ngAfterViewInit`,
                            type: 'MethodDefinition'
                        },
                        {
                            name: `ngOnInit`,
                            type: 'MethodDefinition'
                        },
                    ],
                    "writeTsCode": `

                    
                    
                    ngOnInit() {
                        this.initializeForm();
                    };

                    ngAfterViewInit() {
                        this.openModal();
                        this.rowData_sagGrid_1666089959616 = this.sendmail.formData['sendAllMailObj']
                        this.sendallmail();
                    }

                    openModal() {
                        $("#bootstrapModals_1666089870680").modal('show');
                    }

                    closeModal() {
                        $("#bootstrapModals_1666089870680").modal('hide');
                        this.sendmail.sendAllMailShow = false;
                        //this.clearPreData();
                    }

                    setPreDataLoad() {

                    }

                    clearPreData() {
                        this.sendmail.data = {};
                    }
                    open_sendallmail_sagGrid_1666089959616() {
                        $("#sagGrid_1666089959616").modal('show');
                    }
                    close_sendallmail_sagGrid_1666089959616() {
                        $("#sagGrid_1666089959616").modal('hide');
                    }

                    gridData_sagGrid_1666089959616: any;
                    gridDynamicObj_sagGrid_1666089959616: any;
                    columnData_sagGrid_1666089959616: any = [
                        {
                            "columngroup": "",
                            "hidden": false,
                            "editable": "false",
                            "filter": true,
                            "search": true,
                            "field": "sno",
                            "freezecol": "null",
                            "width": "90px",
                            "header": "S.No",
                            "text-align": "left",

                        },
                        {
                            "hidden": false,
                            "checkboxLabel": false,
                            "search": true,
                            "text-align": "left",
                            "columngroup": "",
                            "editable": "false",
                            "filter": true,
                            "component": "textInput",
                            "field": "gridData",
                            "freezecol": "null",
                            "width": "350px",
                            "header": "Grid Data",

                        },
                        {
                            "hidden": false,
                            "checkboxLabel": false,
                            "search": true,
                            "text-align": "center",
                            "columngroup": "",
                            "editable": "false",
                            "filter": true,
                            "component": "buttonView",
                            "field": "view",
                            "freezecol": "null",
                            "width": "150px",
                            "header": "View",

                        },
                        {
                            "hidden": false,
                            "checkboxLabel": false,
                            "search": true,
                            "text-align": "center",
                            "columngroup": "",
                            "editable": "false",
                            "filter": true,
                            "component": "button",
                            "field": "send",
                            "freezecol": "null",
                            "width": "150px",
                            "header": "Send",

                        },
                    ];

                    rowData_sagGrid_1666089959616: any = [];

                    sendallmail(rowData?, colData?) {
                        let self = this;

                        let textInputObj = new SagInputText({}, function () { });
                        let buttonObj = new ButtonComponent({ "visibility": true, buttonValue: 'Send', styles: { backgroundColor: '#2aa5b9', color: 'white', 'line-height': '15px', border: '1px #2aa5b9 solid', } }, function (ele, params) {
                            ele.onclick = function (evnt) {
                                /* debugger;
                                let setRowSelected = self.gridDynamicObj_sagGrid_1666089959616.getSeletedRowData();
                                self.openSendMailModal(setRowSelected) */
                            }
                        });
                        let buttonObjView = new ButtonComponent({ "visibility": true, buttonValue: 'View', styles: { backgroundColor: '#2aa5b9', color: 'white', 'line-height': '15px', border: '1px #2aa5b9 solid', } }, function (ele, params) {
                            ele.onclick = function (evnt) {
                                debugger;
                                console.log("Btn call");
                            }
                        });
                        this.gridData_sagGrid_1666089959616 = {
                            columnDef: colData ? colData : this.columnData_sagGrid_1666089959616,
                            rowDef: rowData ? rowData : this.rowData_sagGrid_1666089959616,
                            footer_hide: true,
                            totalNoOfRecord_hide: true,
                            sml_expandGrid_hide: true,
                            exportXlsxPage_hide: true,
                            exportXlsxAllPage_hide: true,
                            exportPDFLandscape_hide: true,
                            exportPDFPortrait_hide: true,
                            ariaHidden_hide: true,

                            components: {
                                "textInput": textInputObj,
                                "button": buttonObj,
                                "buttonView": buttonObjView,
                            },
                            callBack: {
                                "onCellClick": function (ele) {

                                    self.onsendallmailCellClick();
                                },
                                "onRowClick": function () {
                                    self.onsendallmailClick();
                                },
                                "onRowDbleClick": function () {
                                    self.onsendallmaildblClick();
                                },
                                "onButtonComponentClick": function (ele) {
                                    let setRowSelected = self.gridDynamicObj_sagGrid_1666089959616.getSeletedRowData();
                                    if (setRowSelected) {
                                        self.openSendMailModal(setRowSelected)
                                    } else {
                                        self._toast.launch_toast({
                                            type: 'alert',
                                            position: 'bottom-right',
                                            message: 'Please Select Row',
                                        });
                                    }                
                                }
                            }
                            ,


                            RowCustomHeight: NaN,
                            header: {
                               
                            },
                            row: {
                               

                            },


                        };

                        let sourceDiv = document.getElementById("sagGrid_1666089959616");
                        this.gridDynamicObj_sagGrid_1666089959616 = SagGridMPT(sourceDiv, this.gridData_sagGrid_1666089959616, true, true);
                    }

                    onsendallmailCellClick() {

                    }

                    onsendallmailClick() {

                    }

                    onsendallmaildblClick() {

                    }

                    sendAllMailData() {

                    }

                    openSendMailModal(setRowSelected) {
                        let postData = {
                            formname: 'home7',
                            /* formid: 36, */
                            formid: this.sendmail.formData.postData['formid'],
                            template: '',
                            formctrl: [{}]
                        }
                        postData.formctrl.push(setRowSelected)
                        this.sendmail.userSave(postData).subscribe((res) => {
                            this.sendmail.formData.type = 'mail';
                            this.sendmail.formData.activeData = res['activetemplatedata'];
                            this.sendmail.formData.tmplateData = res['templatedata'];
                            this.sendmail.showPage = true;
                            //this.sendmail.sendAllMailShow = true;
                        });
                    }

                    `,
                },
                "routingData": {},
                "moduleData": {}
            },

        },
        {
            "ngGenerate": {
                "ngType": "service",
                "ngName": "sendmail",
                "ngAuthor": "sagDev",
                "ngDesc": "send Mail Service File",
                "ngServiceType": "provideAsShareService",
            },
            "creationPath": "/src/app/custommodules/sendmail",
            "data": {
                "serviceData": {
                    "varAndMethodList": [],
                    "writeTsCode": ``,
                    "sharedData": [
                        { "varName": "receiverEmailId" },
                        { "varName": "messageSubject" },
                        { "varName": "messageBody" }
                    ],
                    "subDataArray": [
                        {
                            "type": "customCode",
                            "icon": "fas fa-laptop-code",
                            "label": "custom Code",
                            "description": "Code Here",
                            "placeholder": "Custom Code Here..",
                            "className": "",
                            "classValue": "",
                            "SMclassValue": "",
                            "MDclassValue": "",
                            "LGclassValue": "",
                            "XLclassValue": "",
                            "labelClasses": "",
                            "angular": {
                                "appliedEvents": [

                                ],
                                "events": [

                                ]
                            },
                            "properties": {
                                "innerStyles": {},
                                "globalInnerStyles": {},
                                "elementInnerStyles": {},
                                "labelInnerStyles": {},
                                "innerText": "",
                                "classes": "",
                                "innerStylesString": "",
                                "propertyOption2": null,
                                "propertyOption3": null,
                                "propertyOption4": null,
                                "propertyOption5": null
                            },
                            "subtype": "customCode",
                            "subDataArray": [

                            ],
                            //"customCodeBody": "showPage: boolean = false;",
                            "customCodeBody": "hello()",
                            "domNodeTag": [

                            ],
                            "regex": null,
                            "handle": true,
                            "elementId": null,
                            "id": "customCode_1655446732102",
                            "parentId": null,
                            "isCurrentlySelected": false,
                            "option5": null,
                            "star_Symbol": false,
                            "required": false,
                            "toolTip": "i am Toop Tip",
                            "toolTipShow": false,
                            "errorText": "Please select a valid Div",
                            "globelClasses": "",
                            "selectedGlobalClassArray": [

                            ],
                            "additionGlobelClasses": "",
                            "defaultGlobelCls": "sagFieldSet",
                            "elementClass": "",
                            "selectedElementClassArray": [

                            ],
                            "additionElementClass": "",
                            "defaultElementCls": "",
                            "visibility": false,
                            "windowProperties": [
                                "label",
                                "name",
                                "defaultGlobelCls",
                                "additionGlobelClasses",
                                "globelClasses",
                                "expandCollapseIcon",
                                "extraElementClass",
                                "innerStyles"
                            ],
                            "name": "customCode_1655446732102"
                        }
                    ]

                }
            }

        }
    ]
}