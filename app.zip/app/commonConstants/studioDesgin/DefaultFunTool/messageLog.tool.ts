export const messageLogTool = {
    "type": "defaultCompPage",
    "subtype": "defaultCompPage",
    "icon": "fa-columns",
    "label": "col",
    "ctrlId": 'messagelog',
    "path": "/src/app/custommodules/",
    "defaultCompData": [
        {
            "ngGenerate": {
                "ngType": "page",
                "ngName": "messagelog",
                "ngAuthor": "sagDev",
                "ngDesc": "send Mail Folder with file",
                "ngServiceType": "",
            },
            "creationPath": "/src/app/custommodules",
            "data": {
                "htmlData": [

                ],
                "cssData": {},
                "tsData": {
                    "diInConstructor": [
                        {
                            "diName": "SendmailService",
                            "diType": "public",
                            "diShortName": "sendmail",
                            "diImportPath": "src/app/custommodules/sendmail/sendmail.service"
                        }
                    ],
                    "varAndMethodList": [],
                    "writeTsCode": ``,
                },
                "routingData": {},
                "moduleData": {}
            },

        },
        {
            "ngGenerate": {
                "ngType": "service",
                "ngName": "sendmail",
                "ngAuthor": "sagDev",
                "ngDesc": "send Mail Service File",
                "ngServiceType": "provideAsShareService",
            },
            "creationPath": "/src/app/custommodules/sendmail",
            "data": {
                "serviceData": {
                    "varAndMethodList": [],
                    "writeTsCode": ``,
                    "sharedData": [
                        { "varName": "receiverEmailId" },
                        { "varName": "messageSubject" },
                        { "varName": "messageBody" }
                    ],
                    "subDataArray": [
                        {
                            "type": "customCode",
                            "icon": "fas fa-laptop-code",
                            "label": "custom Code",
                            "description": "Code Here",
                            "placeholder": "Custom Code Here..",
                            "className": "",
                            "classValue": "",
                            "SMclassValue": "",
                            "MDclassValue": "",
                            "LGclassValue": "",
                            "XLclassValue": "",
                            "labelClasses": "",
                            "angular": {
                                "appliedEvents": [

                                ],
                                "events": [

                                ]
                            },
                            "properties": {
                                "innerStyles": {},
                                "globalInnerStyles": {},
                                "elementInnerStyles": {},
                                "labelInnerStyles": {},
                                "innerText": "",
                                "classes": "",
                                "innerStylesString": "",
                                "propertyOption2": null,
                                "propertyOption3": null,
                                "propertyOption4": null,
                                "propertyOption5": null
                            },
                            "subtype": "customCode",
                            "subDataArray": [

                            ],
                            //"customCodeBody": "showPage: boolean = false;",
                            "customCodeBody": "hello()",
                            "domNodeTag": [

                            ],
                            "regex": null,
                            "handle": true,
                            "elementId": null,
                            "id": "customCode_1655446732102",
                            "parentId": null,
                            "isCurrentlySelected": false,
                            "option5": null,
                            "star_Symbol": false,
                            "required": false,
                            "toolTip": "i am Toop Tip",
                            "toolTipShow": false,
                            "errorText": "Please select a valid Div",
                            "globelClasses": "",
                            "selectedGlobalClassArray": [

                            ],
                            "additionGlobelClasses": "",
                            "defaultGlobelCls": "sagFieldSet",
                            "elementClass": "",
                            "selectedElementClassArray": [

                            ],
                            "additionElementClass": "",
                            "defaultElementCls": "",
                            "visibility": false,
                            "windowProperties": [
                                "label",
                                "name",
                                "defaultGlobelCls",
                                "additionGlobelClasses",
                                "globelClasses",
                                "expandCollapseIcon",
                                "extraElementClass",
                                "innerStyles"
                            ],
                            "name": "customCode_1655446732102"
                        }
                    ]

                }
            }

        }
    ]
}