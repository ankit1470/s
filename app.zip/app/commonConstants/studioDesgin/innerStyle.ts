export let innerStyleBlock = [
  {
    "groupName": "General",
    "properties": [
      {
        "name": "Alignment",
        "input": {
          "type": "radio",
          "name": "float-c211",
          "cssProperty": "float",
          "elements": [
            {
              "id": "float-none-c211",
              "value": "none",
              "icon": "fa fa-times sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-float"
            },
            {
              "id": "float-left-c211",
              "value": "left",
              "icon": "fa fa-align-left sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-float"
            },
            {
              "id": "float-right-c211",
              "value": "right",
              "icon": "fa fa-align-right sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-float"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Display",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "display",
          "selected": "flex",
          "elements": [
            {
              "value": "block",
              "label": "Block"
            },
            {
              "value": "inline",
              "label": "Inline"
            },
            {
              "value": "inline-block",
              "label": "Inline Block"
            },
            {
              "value": "flex",
              "label": "Flex"
            },
            {
              "value": "none",
              "label": "None"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Justify content",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "justify-content",
          "selected": "flex",
          "elements": [
            {
              "value": "start",
              "label": "Start"
            },
            {
              "value": "end",
              "label": "end"
            },
            {
              "value": "center",
              "label": "center"
            },
            {
              "value": "between",
              "label": "between"
            },
            {
              "value": "around",
              "label": "around"
            },
            {
              "value": "evenly",
              "label": "evenly"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Align items",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "align-items",
          "selected": "start",
          "elements": [
            {
              "value": "start",
              "label": "start"
            },
            {
              "value": "end",
              "label": "end"
            },
            {
              "value": "center",
              "label": "center"
            },
            {
              "value": "baseline",
              "label": "baseline"
            },
            {
              "value": "stretch",
              "label": "stretch"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Align self",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "align-items",
          "selected": "none",
          "elements": [
            {
              "value": "none",
              "label": "none"
            },
            {
              "value": "start",
              "label": "Start"
            },
            {
              "value": "end",
              "label": "end"
            },
            {
              "value": "center",
              "label": "center"
            },
            {
              "value": "baseline",
              "label": "baseline"
            },
            {
              "value": "stretch",
              "label": "stretch"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Align content",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "align-content",
          "selected": "none",
          "elements": [
            {
              "value": "none",
              "label": "none"
            },
            {
              "value": "start",
              "label": "Start"
            },
            {
              "value": "end",
              "label": "end"
            },
            {
              "value": "center",
              "label": "center"
            },
            {
              "value": "baseline",
              "label": "baseline"
            },
            {
              "value": "stretch",
              "label": "stretch"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Flex Direction",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "flex-direction",
          "selected": "none",
          "elements": [
            {
              "value": "none",
              "label": "none"
            },
            {
              "value": "row",
              "label": "row"
            },
            {
              "value": "row-reverse",
              "label": "row-reverse"
            },
            {
              "value": "column",
              "label": "column"
            },
            {
              "value": "column-reverse",
              "label": "column-reverse"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Fill",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "fill",
          "selected": "none",
          "elements": [
            {
              "value": "none",
              "label": "none"
            },
            {
              "value": "fill",
              "label": "fill"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Grow",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "grow",
          "selected": "none",
          "elements": [
            {
              "value": "none",
              "label": "none"
            },
            {
              "value": "grow-0",
              "label": "grow-0"
            },
            {
              "value": "grow-1",
              "label": "grow-1"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Shrink",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "shrink",
          "selected": "none",
          "elements": [
            {
              "value": "none",
              "label": "none"
            },
            {
              "value": "shrink-0",
              "label": "shrink-0"
            },
            {
              "value": "shrink-1",
              "label": "shrink-1"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Wrap",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "shrink",
          "selected": "none",
          "elements": [
            {
              "value": "none",
              "label": "none"
            },
            {
              "value": "nowrap",
              "label": "nowrap"
            },
            {
              "value": "wrap",
              "label": "wrap"
            },
            {
              "value": "wrap-reverse",
              "label": "wrap-reverse"
            }
          ],
          "important": false
        }
      },
      
      {
        "name": "Position",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "position",
          "selected": "static",
          "elements": [
            {
              "value": "static",
              "label": "Static"
            },
            {
              "value": "relative",
              "label": "Relative"
            },
            {
              "value": "absolute",
              "label": "Absolute"
            },
            {
              "value": "fixed",
              "label": "Fixed"
            },
            {
              "value": "sticky",
              "label": "Sticky"
            },
            {
              "value": "inherit",
              "label": "Inherit"
            },
            {
              "value": "initial",
              "label": "Initial"
            },
            {
              "value": "revert",
              "label": "Revert"
            },
            {
              "value": "revert-layer",
              "label": "Revert-Layer"
            },
            {
              "value": "unset",
              "label": "Unset"
            },
            {
              "value": "",
              "label": "None"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Top",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "top",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Right",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "right",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Left",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "left",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Bottom",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "bottom",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Order",
        "input": {
          "type": "input-img",
          "placeholder": "order-1",
          "name": "",
          "cssProperty": "order",
          "value": "",
          "important": false
        }
      },
    ]
  },
  {
    "groupName": "Dimension",
    "properties": [
      {
        "name": "Width",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "width",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Height",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "height",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Max Width",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "max-width",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Min Width",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "min-width",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Max Height",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "max-height",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Min Height",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "min-height",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Margin Top",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "margin-top",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Margin Right",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "margin-right",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Margin Bottom",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "margin-bottom",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Margin Left",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "margin-left",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Margin",
        "input": {
          "type": "input-img",
          "placeholder": "0px,0px,0px,0px",
          "name": "",
          "cssProperty": "margin",
          "value": "",
          "important": false
        }
      },
      {
        "name": "Padding Top",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "padding-top",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Padding Right",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "padding-right",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Padding Bottom",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "padding-bottom",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Padding Left",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "padding-left",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Padding",
        "input": {
          "type": "input-img",
          "placeholder": "0px,0px,0px,0px",
          "name": "",
          "cssProperty": "padding",
          "value": "",
          "important": false
        }
      },
      {
        "name": "z-index",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "z-index",
          "value": "",
          "select": {
            "selected": "",

          },
          "important": false
        }
      },
      {
        "name": "overflow",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "overflow",
          "selected": "auto",
          "elements": [
            {
              "value": "auto",
              "label": "auto"
            },
            {
              "value": "scroll",
              "label": "scroll"
            },
            {
              "value": "hidden",
              "label": "hidden"
            },
            {
              "value": "clip",
              "label": "clip"
            },
            {
              "value": "visible",
              "label": "visible"
            },
            {
              "value": "hidden visible",
              "label": "Hidden Visible"
            },
            {
              "value": "",
              "label": "None"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Overflow X",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "overflow-x",
          "selected": "unset",
          "elements": [
            {
              "value": "auto",
              "label": "auto"
            },
            {
              "value": "clip",
              "label": "clip"
            },
            {
              "value": "hidden",
              "label": "hidden"
            },
            {
              "value": "overlay",
              "label": "overlay"
            },
            {
              "value": "scroll",
              "label": "scroll"
            },
            {
              "value": "clip",
              "label": "clip"
            },
            {
              "value": "visible",
              "label": "visible"
            },
            {
              "value": "inherit",
              "label": "inherit"
            },
            {
              "value": "revert",
              "label": "revert"
            },
            {
              "value": "revert-layer",
              "label": "revert-layer"
            },
            {
              "value": "initial",
              "label": "initial"
            },
            {
              "value": "unset",
              "label": "unset"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Overflow Y",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "overflow-y",
          "selected": "unset",
          "elements": [
            {
              "value": "auto",
              "label": "auto"
            },
            {
              "value": "clip",
              "label": "clip"
            },
            {
              "value": "hidden",
              "label": "hidden"
            },
            {
              "value": "overlay",
              "label": "overlay"
            },
            {
              "value": "scroll",
              "label": "scroll"
            },
            {
              "value": "clip",
              "label": "clip"
            },
            {
              "value": "visible",
              "label": "visible"
            },
            {
              "value": "inherit",
              "label": "inherit"
            },
            {
              "value": "revert",
              "label": "revert"
            },
            {
              "value": "revert-layer",
              "label": "revert-layer"
            },
            {
              "value": "initial",
              "label": "initial"
            },
            {
              "value": "unset",
              "label": "unset"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Visibility",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "visibility",
          "selected": "unset",
          "elements": [
            {
              "value": "collapse",
              "label": "collapse"
            },
            {
              "value": "visible",
              "label": "visible"
            },
            {
              "value": "hidden",
              "label": "hidden"
            },
            {
              "value": "inherit",
              "label": "inherit"
            },
            {
              "value": "revert",
              "label": "revert"
            },
            {
              "value": "initial",
              "label": "initial"
            },
            {
              "value": "revert-layer",
              "label": "revert-layer"
            },
            {
              "value": "unset",
              "label": "unset"
            }
          ],
          "important": false
        }
      },
    ]
  },
  {
    "groupName": "Typography",
    "properties": [
      {
        "name": "Font",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "font-family",
          "selected": "Arial, Helvetica, sans-serif",
          "elements": [

          ],
          "important": false
        }
      },
      {
        "name": "Font Size",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "font-size",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              },
              {
                "value": "vh",
                "label": "vh"
              }
            ],
            "important": false
          }
        }
      },
      {
        "name": "Font Weight",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "font-weight",
          "selected": "100",
          "elements": [
            {
              "value": "100",
              "label": "Thin"
            },
            {
              "value": "200",
              "label": "Extra-Light"
            },
            {
              "value": "300",
              "label": "Light"
            },
            {
              "value": "400",
              "label": "Normal"
            },
            {
              "value": "500",
              "label": "Medium"
            },
            {
              "value": "600",
              "label": "Semi-Bold"
            },
            {
              "value": "700",
              "label": "Bold"
            },
            {
              "value": "800",
              "label": "Extra-Bold"
            },
            {
              "value": "900",
              "label": "Ultra-Bold"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Font style",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "font-style",
          "selected": "",
          "elements": [
            {
              "value": "italic",
              "label": "Italic"
            },
            {
              "value": "normal",
              "label": "Normal"
            },
            {
              "value": "oblique",
              "label": "Oblique"
            },
            {
              "value": "inherit",
              "label": "Inherit"
            },
            {
              "value": "initial",
              "label": "Initial"
            },
            {
              "value": "revert",
              "label": "Revert"
            },
            {
              "value": "revert-layer",
              "label": "Revert-layer"
            },
            {
              "value": "unset",
              "label": "Unset"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Letter Spacing",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "letter-spacing",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "em",
                "label": "em"
              },
              {
                "value": "rem",
                "label": "rem"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Color",
        "input": {
          "type": "input-color",
          "placeholder": "#000000",
          "name": "",
          "cssProperty": "color",
          "value": "#000000",
          "important": false
        }
      },
      {
        "name": "Background Color",
        "input": {
          "type": "input-color",
          "placeholder": "#000000",
          "name": "",
          "cssProperty": "background-color",
          "value": "#000000",
          "important": false
        }
      },
      {
        "name": "Background Image Url",
        "input": {
          "type": "input-img",
          "placeholder": "https://www.gstatic.com/webp/gallery/1.sm.webp",
          "name": "",
          "showBtn":true,
          "cssProperty": "background-image",
          "value": "",
          "important": false
        }
      },
      {
        "name": "Background Position",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "background-position",
          "selected": "center",
          "elements": [
            {
              "value": "bottom",
              "label": "Bottom"
            },
            {
              "value": "center",
              "label": "Center"
            },
            {
              "value": "inherit",
              "label": "Inherit"
            },
            {
              "value": "initial",
              "label": "Initial"
            },
            {
              "value": "left",
              "label": "Left"
            },
            {
              "value": "revert",
              "label": "Revert"
            },
            {
              "value": "right",
              "label": "Right"
            },
            {
              "value": "top",
              "label": "Top"
            },
            {
              "value": "unset",
              "label": "Unset"
            },
            {
              "value": "",
              "label": "None"
            }

          ],
          "important": false
        }
      },
      {
        "name": "Background Position X",
        "input": {
          "type": "input-select",
          "placeholder": "0",
          "name": "",
          "cssProperty": "background-position-x",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "em",
                "label": "em"
              },
              {
                "value": "rem",
                "label": "rem"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Background Position Y",
        "input": {
          "type": "input-select",
          "placeholder": "0",
          "name": "",
          "cssProperty": "background-position-y",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "em",
                "label": "em"
              },
              {
                "value": "rem",
                "label": "rem"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Background Repeat",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "background-repeat",
          "selected": "no-repeat",
          "elements": [

            {
              "value": "inherit",
              "label": "Inherit"
            },
            {
              "value": "initial",
              "label": "Initial"
            },
            {
              "value": "no-repeat",
              "label": "No-Repeat"
            },
            {
              "value": "repeat",
              "label": "Repeat"
            },
            {
              "value": "repeat-x",
              "label": "Repeat-X"
            },
            {
              "value": "repeat-y",
              "label": "Repeat-Y"
            },

            {
              "value": "revert",
              "label": "Revert"
            },
            {
              "value": "round",
              "label": "Round"
            },
            {
              "value": "space",
              "label": "Space"
            },
            {
              "value": "unset",
              "label": "Unset"
            },
            {
              "value": "",
              "label": "None"
            }

          ],
          "important": false
        }
      },
      {
        "name": "Background Attachment",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "background-attachment",
          "selected": "unset",
          "elements": [

            {
              "value": "fixed",
              "label": "fixed"
            },
            {
              "value": "inherit",
              "label": "inherit"
            },
            {
              "value": "initial",
              "label": "initial"
            },
            {
              "value": "local",
              "label": "local"
            },
            {
              "value": "revert",
              "label": "revert"
            },
            {
              "value": "scroll",
              "label": "scroll"
            },

            {
              "value": "unset",
              "label": "unset"
            }

          ],
          "important": false
        }
      },
      {
        "name": "Background Size",
        "input": {
          "type": "input-multi",
          "cssProperty": "background-size",
          "elements": [
            {
              "type": "input-select",
              "label": "Background Size X",
              "cssName": "background-size-x",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "em",
                    "label": "em"
                  },
                  {
                    "value": "rem",
                    "label": "rem"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Background Size Y",
              "cssName": "background-size-y",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "em",
                    "label": "em"
                  },
                  {
                    "value": "rem",
                    "label": "rem"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "select",
              "label": "Background Size Type",
              "cssName": "background-size-element",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "background-size",
                "elements": [
                  {
                    "value": "auto",
                    "label": "Auto"
                  },
                  {
                    "value": "contain",
                    "label": "Contain"
                  },
                  {
                    "value": "cover",
                    "label": "Cover"
                  },
                  {
                    "value": "inherit",
                    "label": "Inherit"
                  },
                  {
                    "value": "initial",
                    "label": "Initial"
                  },
      
                  {
                    "value": "revert",
                    "label": "Revert"
                  },
                  {
                    "value": "revert-layer",
                    "label": "Revert-Layer"
                  },
      
                  {
                    "value": "unset",
                    "label": "Unset"
                  },
                  {
                    "value": "",
                    "label": "None"
                  }
      
                ],
              }
            },
          ],
          "important": false
        }
      },
      {
        "name": "Flex",
        "input": {
          "type": "input-multi",
          "cssProperty": "flex",
          "elements": [
            {
              "type": "input-select",
              "label": "Grow",
              "cssName": "grow",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                ]
              }
            },
            {
              "type": "input-select",
              "label": "shrink",
              "cssName": "shrink",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                 
                ]
              }
            },
            {
              "type": "select",
              "label": "Fill",
              "cssName": "background-size-element",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "background-size",
                "elements": [
                  {
                    "value": "auto",
                    "label": "Auto"
                  },
                  {
                    "value": "inherit",
                    "label": "Inherit"
                  },
                  {
                    "value": "initial",
                    "label": "Initial"
                  },
      
                  {
                    "value": "revert",
                    "label": "Revert"
                  },
                  {
                    "value": "revert-layer",
                    "label": "Revert-Layer"
                  },
                  {
                    "value": "unset",
                    "label": "Unset"
                  },
                  {
                    "value": "",
                    "label": "None"
                  }
      
                ],
              }
            },
          ],
          "important": false
        }
      },
      {
        "name": "Background",
        "input": {
          "type": "input-img",
          "placeholder": "url('image.png') no-repeat center right",
          "name": "",
          "cssProperty": "background",
          "value": "",
          "showBtn":true,
          "important": false
        }
      },
      {
        "name": "Line Height",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "line-height",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "em",
                "label": "em"
              },
              {
                "value": "rem",
                "label": "rem"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Text Align",
        "input": {
          "type": "radio",
          "name": "text-align-c308",
          "cssProperty": "text-align",
          "checked": "",
          "elements": [
            {
              "id": "text-align-left-c308",
              "value": "left",
              "icon": "fa fa-align-left sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-text-align"
            },
            {
              "id": "text-align-center-c308",
              "value": "center",
              "icon": "fa fa-align-center sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-text-align"
            },
            {
              "id": "text-align-right-c308",
              "value": "right",
              "icon": "fa fa-align-right sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-text-align"
            },
            {
              "id": "text-align-justify-c308",
              "value": "justify",
              "icon": "fa fa-align-justify sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-text-align"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Text Decoration",
        "input": {
          "type": "radio",
          "name": "text-decoration-c310",
          "cssProperty": "text-decoration",
          "checked": "",
          "elements": [
            {
              "id": "text-decoration-none-c310",
              "value": "none",
              "icon": "fa fa-times sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-text-decoration"
            },
            {
              "id": "text-decoration-underline-c310",
              "value": "underline",
              "icon": "fa fa-underline sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-text-decoration"
            },
            {
              "id": "text-decoration-line-through-c310",
              "value": "line-through",
              "icon": "fa fa-strikethrough sag-sm-icon sag-radio-item-label",
              "class": "sag-sm-radio sag-sm-radio-text-decoration"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Text Shadow",
        "input": {
          "type": "input-multi",
          "cssProperty": "text-shadow",
          "elements": [
            {
              "type": "input-select",
              "label": "X Position",
              "cssName": "offset-x",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              },
              "important": false
            },
            {
              "type": "input-select",
              "label": "Y Position",
              "cssName": "offset-y",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              },
              "important": false
            },
            {
              "type": "input-select",
              "label": "Blur",
              "cssName": "blur-radius",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              },
              "important": false
            },
            {
              "type": "input-color",
              "cssName": "color",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "text-shadow",
              "select": {
                "elements": []
              },
              "important": false
            }
          ]
        }
      },
      {
        "name": "word-break",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "word-break",
          "selected": "unset",
          "elements": [

            {
              "value": "auto-phrase",
              "label": "auto-phrase"
            },
            {
              "value": "break-all",
              "label": "break-all"
            },
            {
              "value": "break-word",
              "label": "break-word"
            },
            {
              "value": "keep-all",
              "label": "keep-all"
            },
            {
              "value": "normal",
              "label": "normal"
            },
            {
              "value": "inherit",
              "label": "inherit"
            },
            {
              "value": "initial",
              "label": "initial"
            },
            {
              "value": "revert",
              "label": "revert"
            },
            {
              "value": "revert-layer",
              "label": "revert-layer"
            },

            {
              "value": "unset",
              "label": "unset"
            }

          ],
          "important": false
        }
      },
      {
        "name": "White Space",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "white-space",
          "selected": "unset",
          "elements": [
            {
              "value": "break-spaces",
              "label": "break-spaces"
            },
            {
              "value": "normal",
              "label": "normal"
            },
            {
              "value": "nowrap",
              "label": "nowrap"
            },
            {
              "value": "pre",
              "label": "pre"
            },
            {
              "value": "pre-line",
              "label": "pre-line"
            },
            {
              "value": "pre-wrap",
              "label": "pre-wrap"
            },
            {
              "value": "inherit",
              "label": "inherit"
            },
            {
              "value": "initial",
              "label": "initial"
            },
            {
              "value": "revert",
              "label": "revert"
            },
            {
              "value": "revert-layer",
              "label": "revert-layer"
            },
            {
              "value": "unset",
              "label": "unset"
            },
          ],
          "important": false
        }
      },
      {
        "name": "Text Overflow",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "text-overflow",
          "selected": "unset",
          "elements": [
            {
              "value": "clip",
              "label": "clip"
            },
            {
              "value": "ellipsis",
              "label": "ellipsis"
            },
            {
              "value": "unset",
              "label": "unset"
            }
          ],
          "important": false
        }
      },
      {
        "name": "Overflow wrap",
        "input": {
          "type": "select",
          "name": "",
          "cssProperty": "overflow-wrap",
          "selected": "unset",
          "elements": [
            {
              "value": "anywhere",
              "label": "anywhere"
            },
            {
              "value": "break-word",
              "label": "break-word"
            },
            {
              "value": "normal",
              "label": "normal"
            },
            {
              "value": "inherit",
              "label": "inherit"
            },
            {
              "value": "initial",
              "label": "initial"
            },
            {
              "value": "revert",
              "label": "revert"
            },
            {
              "value": "revert-layer",
              "label": "revert-layer"
            },
            {
              "value": "unset",
              "label": "unset"
            },
          ],
          "important": false
        }
      },
    ]
  },
  {
    "groupName": "Decoration",
    "properties": [
      {
        "name": "Opacity",
        "input": {
          "type": "input-range",
          "value": 1,
          "name": "",
          "cssProperty": "opacity",
          "step": 0.01,
          "max": 1,
          "min": 0,
          "important": false
        }
      },
      // {
      //   "name": "Border Top",
      //   "input": {
      //     "type": "input-select",
      //     "placeholder": "auto",
      //     "name": "",
      //     "cssProperty": "border-top",
      //     "value": "",
      //     "select": {
      //       "selected": "px",
      //       "elements": [
      //         {
      //           "value": "px",
      //           "label": "px"
      //         },
      //         {
      //           "value": "%",
      //           "label": "%"
      //         }
      //       ]
      //     },
      //     "important": false
      //   }
      // },
      // {
      //   "name": "Border Right",
      //   "input": {
      //     "type": "input-select",
      //     "placeholder": "auto",
      //     "name": "",
      //     "cssProperty": "border-right",
      //     "value": "",
      //     "select": {
      //       "selected": "px",
      //       "elements": [
      //         {
      //           "value": "px",
      //           "label": "px"
      //         },
      //         {
      //           "value": "%",
      //           "label": "%"
      //         }
      //       ]
      //     },
      //     "important": false
      //   }
      // },
      // {
      //   "name": "Border Left",
      //   "input": {
      //     "type": "input-select",
      //     "placeholder": "auto",
      //     "name": "",
      //     "cssProperty": "border-left",
      //     "value": "",
      //     "select": {
      //       "selected": "px",
      //       "elements": [
      //         {
      //           "value": "px",
      //           "label": "px"
      //         },
      //         {
      //           "value": "%",
      //           "label": "%"
      //         }
      //       ]
      //     },
      //     "important": false
      //   }
      // },
      // {
      //   "name": "Border Bottom",
      //   "input": {
      //     "type": "input-select",
      //     "placeholder": "auto",
      //     "name": "",
      //     "cssProperty": "border-bottom",
      //     "value": "",
      //     "select": {
      //       "selected": "px",
      //       "elements": [
      //         {
      //           "value": "px",
      //           "label": "px"
      //         },
      //         {
      //           "value": "%",
      //           "label": "%"
      //         }
      //       ]
      //     },
      //     "important": false
      //   }
      // },
      // {
      //   "name": "Border Width",
      //   "input": {
      //     "type": "input-select",
      //     "placeholder": "auto",
      //     "name": "",
      //     "cssProperty": "border-width",
      //     "value": "",
      //     "select": {
      //       "selected": "px",
      //       "elements": [
      //         {
      //           "value": "px",
      //           "label": "px"
      //         },
      //         {
      //           "value": "%",
      //           "label": "%"
      //         }
      //       ]
      //     },
      //     "important": false
      //   }
      // },
      // {
      //   "name": "Border Style",
      //   "input": {
      //     "type": "select",
      //     "name": "",
      //     "cssProperty": "border-style",
      //     "selected": "none",
      //     "elements": [
      //       {
      //         "value": "solid",
      //         "label": "Solid"
      //       },
      //       {
      //         "value": "dotted",
      //         "label": "Dotted"
      //       },
      //       {
      //         "value": "dashed",
      //         "label": "Dashed"
      //       },
      //       {
      //         "value": "double",
      //         "label": "Double"
      //       },
      //       {
      //         "value": "groove",
      //         "label": "Groove"
      //       },
      //       {
      //         "value": "ridge",
      //         "label": "Ridge"
      //       },
      //       {
      //         "value": "inset",
      //         "label": "Inset"
      //       },
      //       {
      //         "value": "outset",
      //         "label": "Outset"
      //       },
      //       {
      //         "value": "hidden",
      //         "label": "Hidden"
      //       },
      //       {
      //         "value": "dotted solid",
      //         "label": "Dotted Solid"
      //       },
      //       {
      //         "value": "none",
      //         "label": "None"
      //       }
      //     ],
      //     "important": false
      //   }
      // },
      // {
      //   "name": "Border Color",
      //   "input": {
      //     "type": "input-color",
      //     "placeholder": "#000000",
      //     "name": "",
      //     "cssProperty": "border-color",
      //     "value": "#000000",
      //     "important": false
      //   }
      // },
      {
        "name": "Border",
        "input": {
          "type": "input-multi",
          "cssProperty": "border",
          "elements": [
            {
              "type": "input-select",
              "label": "Width",
              "cssName": "border-width",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "em",
                    "label": "em"
                  },
                  {
                    "value": "rem",
                    "label": "rem"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "select",
              "label": "Type",
              "cssName": "border-type",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "border-type",
                "elements": [
                  {
                    "value": "solid",
                    "label": "Solid"
                  },
                  {
                    "value": "dotted",
                    "label": "Dotted"
                  },
                  {
                    "value": "dashed",
                    "label": "Dashed"
                  },
                  {
                    "value": "double",
                    "label": "Double"
                  },
                  {
                    "value": "groove",
                    "label": "Groove"
                  },
                  {
                    "value": "ridge",
                    "label": "Ridge"
                  },
                  {
                    "value": "inset",
                    "label": "Inset"
                  },
                  {
                    "value": "outset",
                    "label": "Outset"
                  },
                  {
                    "value": "hidden",
                    "label": "Hidden"
                  },
                  {
                    "value": "dotted solid",
                    "label": "Dotted Solid"
                  },
                  {
                    "value": "none",
                    "label": "None"
                  }
                ]
              }
            },
            {
              "type": "input-color",
              "cssName": "color",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "border",
              "select": {
                "elements": [

                ]
              }
            }
          ],
          "important": false
        }
      },
      {
        "name": "Border Top",
        "input": {
          "type": "input-multi",
          "cssProperty": "border-top",
          "elements": [
            {
              "type": "input-select",
              "label": "Width",
              "cssName": "border-width",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "em",
                    "label": "em"
                  },
                  {
                    "value": "rem",
                    "label": "rem"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "select",
              "label": "Type",
              "cssName": "border-type",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "border-type",
                "elements": [
                  {
                    "value": "solid",
                    "label": "Solid"
                  },
                  {
                    "value": "dotted",
                    "label": "Dotted"
                  },
                  {
                    "value": "dashed",
                    "label": "Dashed"
                  },
                  {
                    "value": "double",
                    "label": "Double"
                  },
                  {
                    "value": "groove",
                    "label": "Groove"
                  },
                  {
                    "value": "ridge",
                    "label": "Ridge"
                  },
                  {
                    "value": "inset",
                    "label": "Inset"
                  },
                  {
                    "value": "outset",
                    "label": "Outset"
                  },
                  {
                    "value": "hidden",
                    "label": "Hidden"
                  },
                  {
                    "value": "dotted solid",
                    "label": "Dotted Solid"
                  },
                  {
                    "value": "none",
                    "label": "None"
                  }
                ]
              }
            },
            {
              "type": "input-color",
              "cssName": "color",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "border-top",
              "select": {
                "elements": [

                ]
              }
            }
          ],
          "important": false
        }
      },
      {
        "name": "Border Bottom",
        "input": {
          "type": "input-multi",
          "cssProperty": "border-bottom",
          "elements": [
            {
              "type": "input-select",
              "label": "Width",
              "cssName": "border-width",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "em",
                    "label": "em"
                  },
                  {
                    "value": "rem",
                    "label": "rem"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "select",
              "label": "Type",
              "cssName": "border-type",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "border-type",
                "elements": [
                  {
                    "value": "solid",
                    "label": "Solid"
                  },
                  {
                    "value": "dotted",
                    "label": "Dotted"
                  },
                  {
                    "value": "dashed",
                    "label": "Dashed"
                  },
                  {
                    "value": "double",
                    "label": "Double"
                  },
                  {
                    "value": "groove",
                    "label": "Groove"
                  },
                  {
                    "value": "ridge",
                    "label": "Ridge"
                  },
                  {
                    "value": "inset",
                    "label": "Inset"
                  },
                  {
                    "value": "outset",
                    "label": "Outset"
                  },
                  {
                    "value": "hidden",
                    "label": "Hidden"
                  },
                  {
                    "value": "dotted solid",
                    "label": "Dotted Solid"
                  },
                  {
                    "value": "none",
                    "label": "None"
                  }
                ]
              }
            },
            {
              "type": "input-color",
              "cssName": "color",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "border-bottom",
              "select": {
                "elements": [

                ]
              }
            }
          ],
          "important": false
        }
      },
      {
        "name": "Border Left",
        "input": {
          "type": "input-multi",
          "cssProperty": "border-left",
          "elements": [
            {
              "type": "input-select",
              "label": "Width",
              "cssName": "border-width",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "em",
                    "label": "em"
                  },
                  {
                    "value": "rem",
                    "label": "rem"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "select",
              "label": "Type",
              "cssName": "border-type",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "border-type",
                "elements": [
                  {
                    "value": "solid",
                    "label": "Solid"
                  },
                  {
                    "value": "dotted",
                    "label": "Dotted"
                  },
                  {
                    "value": "dashed",
                    "label": "Dashed"
                  },
                  {
                    "value": "double",
                    "label": "Double"
                  },
                  {
                    "value": "groove",
                    "label": "Groove"
                  },
                  {
                    "value": "ridge",
                    "label": "Ridge"
                  },
                  {
                    "value": "inset",
                    "label": "Inset"
                  },
                  {
                    "value": "outset",
                    "label": "Outset"
                  },
                  {
                    "value": "hidden",
                    "label": "Hidden"
                  },
                  {
                    "value": "dotted solid",
                    "label": "Dotted Solid"
                  },
                  {
                    "value": "none",
                    "label": "None"
                  }
                ]
              }
            },
            {
              "type": "input-color",
              "cssName": "color",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "border-left",
              "select": {
                "elements": [

                ]
              }
            }
          ],
          "important": false
        }
      },
      {
        "name": "Border Right",
        "input": {
          "type": "input-multi",
          "cssProperty": "border-right",
          "elements": [
            {
              "type": "input-select",
              "label": "Width",
              "cssName": "border-width",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "em",
                    "label": "em"
                  },
                  {
                    "value": "rem",
                    "label": "rem"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "select",
              "label": "Type",
              "cssName": "border-type",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "border-type",
                "elements": [
                  {
                    "value": "solid",
                    "label": "Solid"
                  },
                  {
                    "value": "dotted",
                    "label": "Dotted"
                  },
                  {
                    "value": "dashed",
                    "label": "Dashed"
                  },
                  {
                    "value": "double",
                    "label": "Double"
                  },
                  {
                    "value": "groove",
                    "label": "Groove"
                  },
                  {
                    "value": "ridge",
                    "label": "Ridge"
                  },
                  {
                    "value": "inset",
                    "label": "Inset"
                  },
                  {
                    "value": "outset",
                    "label": "Outset"
                  },
                  {
                    "value": "hidden",
                    "label": "Hidden"
                  },
                  {
                    "value": "dotted solid",
                    "label": "Dotted Solid"
                  },
                  {
                    "value": "none",
                    "label": "None"
                  }
                ]
              }
            },
            {
              "type": "input-color",
              "cssName": "color",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "border-right",
              "select": {
                "elements": [

                ]
              }
            }
          ],
          "important": false
        }
      },
      {
        "name": "Border Radius",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "border-radius",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Top-Right-Radius",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "border-top-right-radius",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Top-Left-Radius",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "border-top-left-radius",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Bottom-Left-Radius",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "border-bottom-left-radius",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Bottom-Right-Radius",
        "input": {
          "type": "input-select",
          "placeholder": "auto",
          "name": "",
          "cssProperty": "border-bottom-right-radius",
          "value": "",
          "select": {
            "selected": "px",
            "elements": [
              {
                "value": "",
                "label": "none"
              },
              {
                "value": "px",
                "label": "px"
              },
              {
                "value": "%",
                "label": "%"
              }
            ]
          },
          "important": false
        }
      },
      {
        "name": "Box Shadow",
        "input": {
          "type": "input-multi",
          "cssProperty": "box-shadow",
          "elements": [
            {
              "type": "input-select",
              "label": "X Position",
              "cssName": "offset-x",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Y Position",
              "cssName": "offset-y",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Blur",
              "cssName": "blur-radius",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Spread",
              "cssName": "spread",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-color",
              "cssName": "color",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "box-shadow",
              "select": {
                "elements": []
              }
            },
            {
              "type": "select",
              "label": "Shadow Type",
              "cssName": "shadow-type",
              "selected": "",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "shadow-type",
                "elements": [
                  {
                    "value": "",
                    "label": "OutSet"
                  },
                  {
                    "value": "inset",
                    "label": "Inset"
                  }
                ]
              }
            }
          ],
          "important": false
        }
      },
      {
        "name": "Text Shadow",
        "input": {
          "type": "input-multi",
          "cssProperty": "text-shadow",
          "elements": [
            {
              "type": "input-select",
              "label": "X Position",
              "cssName": "offset-x",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Y Position",
              "cssName": "offset-y",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Blur",
              "cssName": "blur-radius",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Spread",
              "cssName": "spread",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "px",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  }
                ]
              }
            },
            {
              "type": "input-color",
              "cssName": "color",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "box-shadow",
              "select": {
                "elements": []
              }
            },
            {
              "type": "select",
              "label": "Shadow Type",
              "cssName": "shadow-type",
              "selected": "",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "shadow-type",
                "elements": [
                  {
                    "value": "",
                    "label": "OutSet"
                  },
                  {
                    "value": "inset",
                    "label": "Inset"
                  }
                ]
              }
            }
          ],
          "important": false
        }
      }
    ]
  },
  {
    "groupName": "Extra",
    "properties": [
      {
        "name": "Transition",
        "input": {
          "type": "input-multi",
          "cssProperty": "transition",
          "elements": [
            {
              "type": "select",
              "label": "Property",
              "cssName": "property-type",
              "selected": "all",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "property-type",
                "elements": [
                  {
                    "value": "all",
                    "label": "All"
                  },
                  {
                    "value": "width",
                    "label": "Width"
                  },
                  {
                    "value": "height",
                    "label": "Height"
                  },
                  {
                    "value": "background-color",
                    "label": "Background Color"
                  },
                  {
                    "value": "background-position",
                    "label": "Background Position"
                  },
                  {
                    "value": "transform",
                    "label": "Transform"
                  },
                  {
                    "value": "box-shadow",
                    "label": "Box-Shadow"
                  },
                  {
                    "value": "opacity",
                    "label": "Opacity"
                  },
                  {
                    "value": "margin-right",
                    "label": "Margin-Right"
                  },
                  {
                    "value": "",
                    "label": "None"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Duration",
              "cssName": "duration",
              "value": "0",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "s",
                "elements": [
                  {
                    "value": "s",
                    "label": "s"
                  },
                  {
                    "value": "ms",
                    "label": "ms"
                  }
                ]
              }
            },
            {
              "type": "select",
              "label": "Easing",
              "cssName": "easing",
              "selected": "linear",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "easing",
                "elements": [
                  {
                    "value": "linear",
                    "label": "Linear"
                  },
                  {
                    "value": "ease",
                    "label": "Ease"
                  },
                  {
                    "value": "ease-in",
                    "label": "Ease In"
                  },
                  {
                    "value": "ease-out",
                    "label": "Ease-Out"
                  },
                  {
                    "value": "ease-in-out",
                    "label": "Ease-In-Out"
                  },
                  {
                    "value": "transform",
                    "label": "Transform"
                  },
                  {
                    "value": "",
                    "label": "None"
                  }
                ]
              }
            }
          ],
          "important": false
        }
      },
      {
        "name": "content",
        "input": {
          "type": "input-img",
          "placeholder": "",
          "name": "",
          "cssProperty": "content",
          "value": "",
          "important": false
        }
      },
    ]
  },
  {
    "groupName": "Filter",
    "properties": [
      {
        "name": "Filter",
        "input": {
          "type": "input-multi",
          "cssProperty": "filter",
          "elements": [
            //contrast
            {
              "type": "select",
              "label": "contrast",
              "cssName": "filter-contrast",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-contrast",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                   {
                    "value": "contrast",
                    "label": "contrast"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "contrast-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },
            //brightness
            {
              "type": "select",
              "label": "brightness",
              "cssName": "filter-brightness",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-brightness",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "brightness",
                    "label": "brightness"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "brightness-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },
            //blur
            {
              "type": "select",
              "label": "blur",
              "cssName": "filter-blur",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-blur",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "blur",
                    "label": "blur"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "blur-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },

            //hue-rotate
            {
              "type": "select",
              "label": "hue-rotate",
              "cssName": "filter-hue-rotate",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-hue-rotate",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "hue-rotate",
                    "label": "hue-rotate"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "hue-rotate-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },

            //opacity
            {
              "type": "select",
              "label": "opacity",
              "cssName": "filter-opacity",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-opacity",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "opacity",
                    "label": "opacity"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "opacity-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },

            //grayscale
            {
              "type": "select",
              "label": "grayscale",
              "cssName": "filter-grayscale",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-grayscale",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "grayscale",
                    "label": "grayscale"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "grayscale-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },

            //sepia
            {
              "type": "select",
              "label": "sepia",
              "cssName": "filter-sepia",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-sepia",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "sepia",
                    "label": "sepia"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "sepia-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": ""
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },
            //saturate
            {
              "type": "select",
              "label": "saturate",
              "cssName": "filter-saturate",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-saturate",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "saturate",
                    "label": "saturate"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "saturate-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },
            //invert
            {
              "type": "select",
              "label": "Invert",
              "cssName": "filter-invert",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-invert",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "invert",
                    "label": "invert"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "invert-value",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },

            //drop-shadow
            {
              "type": "select",
              "label": "Drop-shadow",
              "cssName": "filter-drop-shadow",
              "selected": "none",
              "value": "",
              "input": {
                "type": "select",
                "name": "",
                "cssProperty": "filter-drop-shadow",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },

                  {
                    "value": "drop-shadow",
                    "label": "drop-shadow"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "drop-shadow-value1",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "drop-shadow-value2",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": ""
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "drop-shadow-value3",
              "value": "",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "px",
                    "label": "px"
                  },
                  {
                    "value": "%",
                    "label": "%"
                  },
                  {
                    "value": "deg",
                    "label": "deg"
                  }
                ]
              }
            },
            {
              "type": "input-color",
              "cssName": "drop-shadow-value4",
              "placeholder": "#000000",
              "name": "",
              "value": "#000000",
              "cssProperty": "box-shadow",
              "select": {
                "elements": []
              }
            },
          ],
          "important": false
        }
      }
    ]
  },
  {
    "groupName": "Transform",
    "properties": [
      {
        "name": "transform",
        "input": {
          "type": "input-multi",
          "cssProperty": "transform",
          "elements": [
           
            {
              "type": "select",
              "label": "transform",
              "cssName": "transform",
              "selected": "",
              "value": "",
              "input": {
                "type": "select",
                "name": "transform-key",
                "cssProperty": "transform-key",
                "elements": [
                  {
                    "value": "",
                    "label": "none"
                  },
                  {
                    "value": "inherit",
                    "label": "inherit"
                  },
                  {
                    "value": "initial",
                    "label": "initial"
                  },
                  {
                    "value": "revert",
                    "label": "revert"
                  },
                  {
                    "value": "rotate",
                    "label": "rotate"
                  },
                  {
                    "value": "matrix",
                    "label": "matrix"
                  },
                  {
                    "value": "matrix3d",
                    "label": "matrix3d"
                  },
                  {
                    "value": "perspective",
                    "label": "perspective"
                  },
                  {
                    "value": "rotate3d",
                    "label": "rotate3d"
                  },
                  {
                    "value": "rotateX",
                    "label": "rotateX"
                  },
                  {
                    "value": "rotateY",
                    "label": "rotateY"
                  },
                  {
                    "value": "rotateZ",
                    "label": "rotateZ"
                  },
                  {
                    "value": "scale",
                    "label": "scale"
                  },
                  {
                    "value": "scale3d",
                    "label": "scale3d"
                  },
                  {
                    "value": "scaleX",
                    "label": "scaleX"
                  },
                  {
                    "value": "scaleY",
                    "label": "scaleY"
                  },
                  {
                    "value": "skew",
                    "label": "skew"
                  },
                  {
                    "value": "skewX",
                    "label": "skewX"
                  },
                  {
                    "value": "skewY",
                    "label": "skewY"
                  },
                  {
                    "value": "translate",
                    "label": "translate"
                  },
                  {
                    "value": "translate3d",
                    "label": "translate3d"
                  },
                  {
                    "value": "translateX",
                    "label": "translateX"
                  },
                  {
                    "value": "translateY",
                    "label": "translateY"
                  },
                  {
                    "value": "translateZ",
                    "label": "translateZ"
                  },
                  {
                    "value": "unset",
                    "label": "unset"
                  },

                ]
              }
            },
            {
              "type": "input-select",
              "label": "Value",
              "cssName": "transform-value",
              "value": "()",
              "class": "sag-sm-property sag-sm-integer sag-sm-property__text-shadow-h",
              "select": {
                "selected": "()",
                "elements": [
                  
                ]
              }
            }
            
          ],
          "important": false
        }
      }
    ]
  },

];
