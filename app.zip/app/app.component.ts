import { Component, OnInit, HostListener, ChangeDetectorRef, AfterContentChecked } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { SagStudioService } from './services/sagStudio/sag-studio.service';
import { SagShareService } from './services/sagshare.service';
declare var ui: any;


@Component({

  host: {
    class: 'app-container app-theme-white body-tabs-shadow fixed-header fixed-sidebar fixed-footer d-flex flex-column h-100 sdmtDarkMode_'
  },
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterContentChecked {
  title = 'sagstudio';


  // call this event handler before browser refresh
  // @HostListener("window:beforeunload", ["$event"]) async unloadHandler(event: Event) {
  //   console.log("Processing beforeunload...");

  // }

  constructor(private router: Router,
    public _sagStudioService: SagStudioService,
    public _shareService: SagShareService,
    private cdr: ChangeDetectorRef,
  ) {

  }

  ngOnInit() {
    // this.getSagStudioJson();
  }

  // async getSagStudioJson() {
  //   let sagStudioJson = parse(localStorage.getItem('sagStudioJson'));
  //   if (sagStudioJson) {
  //     // const conf = await ui.confirm(' Do You want to Restore Last Page');
  //     const conf = confirm(' Do You want to Restore Last Page');
  //     if (conf) {
  //       this._sagStudioService.sagWorkSpace = sagStudioJson;
  //       this._sagStudioService.allValidationList = this._sagStudioService.sagWorkSpace.allValidationList;
  //       // this._sagStudioService.projectConfig = this._sagStudioService.sagWorkSpace.projectConfig;
  //       this._sagStudioService.sagBootstrapComponents = this._sagStudioService.sagWorkSpace.sagBootstrapComponents;
  //       console.log(this._sagStudioService)
  //     }
  //   }

  //   // if (localStorage.getItem('selectedProjectChooseData')) {
  //   //   this._shareService.setDataprotool("selectedProjectChooseData", JSON.parse(localStorage.getItem('selectedProjectChooseData')));
  //   // }


  // }
  // for Content check Loader
  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }








}




