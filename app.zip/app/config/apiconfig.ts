export const apiConstant = {
    sagTranslateUrl: "http://localhost:1008/",
    baseurl : "http://localhost:8080/genmaster/master",
    masterbaseurl : "http://localhost:8080/genmaster/master",
    masterbaseurlconn :"http://localhost:8080/genmaster/master",
    loginUrl : "http://localhost:8080/genmaster",
    genmasterTokenUrl : `http://localhost:8080`,
    aiUrl :  `http://192.168.0.161:5001`,
    projectinfourl :  `http://localhost:7777`,
    studiobaseurl : `http://localhost:5100/api/sagstudio/`,
    pmtBaseUrl : `http://localhost:8080/genmaster`,
    systemIP:`192.168.0.88`,
    storeTokenInSession :"genmaster",
    isLocalhostOrIP:"localhost",
    EditorAiChat :  `http://192.168.0.183:5003`,
}

