import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import { SharedModule } from 'src/app/core/shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { CalendarModule } from 'primeng/primeng';



@NgModule({
  declarations: [LoginComponent],
  imports: [
    CommonModule, 
    SharedModule, 
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    CalendarModule
  ],
  providers :[DatePipe],
  exports: [
    LoginComponent, 
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    CalendarModule
  ],
})
export class AuthModule { }
