import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DialogService } from 'primeng/primeng';
import { TaskProgressComponent } from 'src/app/modules/database/project-utility-tool/procompare-tool/pmt/task-progress/task-progress.component';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ProcomparetoolFirststepService } from 'src/app/services/project-utility-tool/procomparetool-firststep.service';
import { BCreateProjectStepperComponent } from '../b-create-project-stepper/b-create-project-stepper.component';
import { GitSvnComponent } from '../projectConfig/git-svn/git-svn.component';

declare function alerts(m: any): any;
declare function success(m: any): any;
declare var SdmtGridT: any;
declare var ui;
declare var $: any;

@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: 'app-studio-project-list',
  templateUrl: './studio-project-list.component.html',
  styleUrls: ['./studio-project-list.component.scss']
})
export class StudioProjectListComponent implements OnInit, AfterViewInit {

  // for lightModeToggle
  isDarkModeMoon: any = "darkmodeMoon";
  isLightModeSun: any;
  // for table view and grid view change
  isGridView: any = "gridView";
  isTableView: any;
  taskTableDataList: any;
  jwProjectPath: any;
  angProjectPath: any;
  steps: any = 1;
  projectTaskDetailsData:any
  isProjectOnlineFlag: boolean=false;
  constructor(public _sagStudioService: SagStudioService,
      private shareService: SagShareService,
      public _router: Router,
      public firststepProjectService: ProcomparetoolFirststepService,
      public toast: ToastService,
      private procomparetool: ProcomparetoolService,
      public dialogService: DialogService,
      ) { 
        window['angularComponentRef'] = window['angularComponentRef'] || {};
        window['angularComponentRef'].getAccessRights = this.shareService.getAccessRights.bind(this.shareService);
        window['angularComponentRef'].getAccessTreeRightsJson = this.shareService.getAccessTreeRightsJson.bind(this.shareService);
        window['angularComponentRef'].newFunc = this.newFunc.bind(this);
      }
      ngAfterViewInit(): void {
        if (document.getElementById('scriptLoadID')) {
          this.shareService.showEditor('hide');
        }
        sessionStorage.setItem('newDashboard','true')
        document.getElementById('dashSideBar') ? document.getElementById('dashSideBar').classList.add('d-none'): false;
      }


  ngOnInit() {
    (async () => {
      let projectData = JSON.parse(localStorage.getItem("checkProjectData"));
      let routLoad = sessionStorage.getItem("routLoad");
      this.isProjectOnline();
      if (projectData && routLoad) {
        // let abc='/'+projectData.projectname;
        // if(projectData.awspace.includes(abc)){
        //   projectData.awspace = projectData.awspace.replace(abc,'');
        //   projectData.jwspace = projectData.jwspace.replace(abc,'');
        // }
        let getData: any = await this._sagStudioService.getLocalProject(projectData, routLoad);

        if (getData == "stopped") {
          this.getProjectTaskDetails();
          let conf = await ui.confirm("Please Clone Project First ,\n Do You Want To Clone Project ?");
          if (conf == true) {
            this.projectCloneButtonClick();
          }
        }
        localStorage.removeItem("checkProjectData");
        this.shareService.projectUtility = false;
        return;
      }
      this.getProjectTaskDetails();
      //this.projectList();
      // this.myTaskListGridNew1()
      this.getTaskTableData()
    })();
  }


  getProjectTaskDetails() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    const userId = sessionStoragedatauserId["data"]["clientInfo"]["usrId"];
    this.procomparetool.getSagStudioProjectDetailList(userId).subscribe(res => {
      if (res["status"] == 200) {
       // this.projectDetailGrid(res["data"]);
      this.projectList(res["data"]);
      this.projectTaskDetailsData = res['data']
      }
      else {
       // this.projectDetailGrid([]);
        this.projectList([]);
      }
    })
  }

getTaskTableData() {
  this.shareService.loading++;
  const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
  const userid = sessionStoragedatauserId.data.clientInfo.usrId
  this.procomparetool.getTaskTable(userid).subscribe(
    (response: any) => {
      this.shareService.loading--;
      if (response) {
        this.taskTableDataList = response["data"];
        this.myTaskListGridNew1(this.taskTableDataList)
      }
    },
    err => {
      this.shareService.loading--;
      console.error('err response');
    }
  );
}


  gridData_projectList: any;
  gridDynamicObj_projectList: any;
  columnData_projectList: any = [
    {
      header: "Name",
      field: "projectname",
      filter: false,
      width: "300px",
      editable: "false",
      "text-align": "left",
      search: false,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Status",
      field: "status",
      filter: false,
      width: "200px",
      editable: "false",
      "text-align": "center",
      search: false,
      component: "button",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
      button: {
        cellValue: "",
        visibility: true,
        name: "Completed",
        classes: "",
        attribute: "",
        styles: "",
      },
    },
    {
      header: "Members",
      field: "members",
      filter: false,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "button",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
      button: {
        cellValue: "",
        visibility: true,
        name: "View Members",
        classes: ['btnRed'],
        attribute: "",
        styles: "",
      },
    },
    {
      header: "Open",
      field: "totalopen",
      filter: false,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: false,
      component: "label",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "In-Progress",
      field: "totalinprogress",
      filter: false,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: false,
      component: "label",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Close",
      field: "totalclose",
      filter: false,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: false,
      component: "label",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Total",
      field: "totalopen",
      filter: false,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: false,
      component: "label",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
   

    // {
    //   header: "Progress",
    //   field: "progressBtn",
    //   filter: false,
    //   width: "300px",
    //   editable: "false",
    //   "text-align": "left",
    //   search: false,
    //   component: "button",
    //   cellRenderView: true,
    //   freezecol: "null",
    //   hidden: false,
    //   sort: false,
    //   cellHover: false,
    //   button: {
    //     cellValue: "",
    //     visibility: true,
    //     name: "100%",
    //     classes: ["btnComponentTwo"],
    //     attribute: "",
    //     styles: "",
    //   },
    // },
    {
      header: "Actions",
      field: "action",
      filter: false,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: false,
      component: "ellipsisVBtn",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "",
      field: "progress",
      filter: false,
      width: "390px",
      editable: "false",
      "text-align": "left",
      search: false,
      component: "buttonMultiIcon",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
      button: {
        id: ["home", "home1"],
        iconclass: ["fa fa-edit", "fa fa-paint-brush"],
        visibility: true,
        classes: [],
        name: "",
        styles: "",
        attribute: "",
      },
    },
    
  ];
  rowData_projectList: any = [
    
  ];
  validationprojectList: any = {};
  projectList(rowData?, colData?) {
    let self = this;

    this.gridData_projectList = {
      columnDef: colData ? colData : this.columnData_projectList,
      rowDef: rowData ? rowData : this.rowData_projectList,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: true,
      common_search_column: "all",
      common_filter: false,
      common_filter_column: "",
      exportBtn: false,
      validation: this.validationprojectList,
      newPagination: false,
      recordPerPage: 10,
      commonSearchSelect_hide:true, 
      components: {},

      callBack: {
        "onEllipsisBtn_action": function (ele, params, check) {
          if(check =="fa fa-child createTask"){
            self._router.navigate(['dashboard/database/projectToolFirst/newprojectinfo/pmt/createTask'])
          }
          if(check =="fa fa-copy createModule"){
            self._router.navigate(['dashboard/database/projectToolFirst/newprojectinfo/pmt/createModules'])
          }
          if(check == 'fa fa-copy assignTask'){
            self._router.navigate(['dashboard/sagstudiodashboard/database/projectToolFirst/newprojectinfo/pmt/assignProject'])
          }
          if (check == 'fa fa-clone projectClone') {
            self.projectCloneButtonClick();

          } 
          if (check == 'fas fa-eraser cleanLayout001') {
            self.cleanLayoutStoredData();
          }
         }, 
        onCellClick: function (ele) {
          self.onprojectListCellClick();
        },
        onRowClick: function () {
          self.onprojectListClick();
          let selectedObj
           selectedObj =  self.gridDynamicObj_projectList.getSeletedRowData();
          //  selectedObj.pmtValue=true;
          //  selectedObj.projectId = selectedObj.pj_id;
           selectedObj = JSON.parse(JSON.stringify(selectedObj));
           selectedObj.awspace ? selectedObj.awspace = `${selectedObj.awspace}/${selectedObj.projectname}` : false;
           selectedObj.jwspace ? selectedObj.jwspace = `${selectedObj.jwspace}/${selectedObj.projectname}` : false;
           
           //Projects avalable on Repository auther@CP
           if (selectedObj && selectedObj.projectGitPath && (selectedObj.projectGitPath != null) && (selectedObj.projectGitPath != '')
             && (selectedObj.projectGitPath != null) && (selectedObj.projectSvnPath != '')) {
             selectedObj['projectOnRepository'] = true;
           } else {
             selectedObj['projectOnRepository'] = false;
           }
           self.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj)));
           localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj));
           self.shareService.setDatadbtool("projectNameValue", selectedObj.projectId);
           self.shareService.setDataprotool("selectedAngularProject", selectedObj.awspace);
        },
        onRowDbleClick: function () {
          self.onprojectListdblClick();
          self.getTaskTableData();
          
          self._sagStudioService.workTaskList = true;
        },

        onMultiButtonIcon_progress: async function (data, params) {
          event.stopImmediatePropagation();
          let selectedObj =  self.gridDynamicObj_projectList.getSeletedRowData();
         if(selectedObj){
        //  self.shareService.removeDataprotool("selectedProjectChooseData");
          if(data.id=='home'){
            sessionStorage.setItem("routLoad", "project_type");
            self.shareService.setDataprotool("acctiveTab", "UIbuilder_workspace");

            //  self.shareService.showBar.next(true)
            let getData: any = await self._sagStudioService.getLocalProject(selectedObj, 'project_type');
            if (getData == "stopped") {
              let conf = await ui.confirm("Please Clone Project First ,\n Do You Want To Clone Project ?");
              if (conf == true) {
              self.projectCloneButtonClick();
              }
            }

          } else if(data.id=='home1'){
            sessionStorage.setItem("routLoad", "UIbuilder");
            self.shareService.setDataprotool("acctiveTab", "UIbuilder");
            self.shareService.setDataprotool("UIbuilder", false);
            self.shareService.setDataprotool("UIbuilderFileShow", true);
           await self._sagStudioService.getLocalProject(selectedObj, 'UIbuilder');
           document.getElementById("dashSideBar").classList.remove("d-none");
           // self.shareService.$uIbuilderLoadProject.next(true);
          //  self.shareService.showBar.next(true)
          }
        }else{
          alerts('please select project');
        }

        

          // document.getElementById('sdmtDarkModeId').classList.contains('sdmtDarkMode') ?  document.getElementById('sdmtDarkModeId').classList.remove('sdmtDarkMode') : false;
          // self.shareService.showBar.next(true);
        },
        // onButton_loadProject:function(ele,param){
        //   console.log(param)
        //   const data = {
        //     apiId: param.rowValue.apiId
        //   }
        // //  self.shareService.showBar.next(true)
        //  self.getLocalProject();
        //  },
        onButton_members:function(ele,param){
          let projectId=self.gridDynamicObj_projectList.getSeletedRowData().pmtProjectId
          self.getSpecificModuleList(projectId)
          // self.memberList = param.value;
          $("#viewMembers").modal("show");
        },
    
      },
      ellipsisV:{action:[
        {class:'fa fa-child createTask',textContent:'Create Task'},
        {class:'fa fa-copy createModule',textContent:'Create Module'},
        {class:'fa fa-copy assignTask',textContent:'Assign Team'},
        {class:'fa fa-clone projectClone',textContent:'Project Clone'},
        {class:'fas fa-eraser cleanLayout001',textContent:'Clean Layout'},
    ]},
      rowCustomHeight: 25,
    };

    let sourceDiv = document.getElementById("projectList");
    this.gridDynamicObj_projectList = SdmtGridT(
      sourceDiv,
      this.gridData_projectList,
      true,
      true
    );
  }


  cleanLayoutStoredData() {
    let selectedObj = this.gridDynamicObj_projectList.getSeletedRowData();
    if (selectedObj) {
      let userCode = sessionStorage.getItem('userCode');
      let projectId: any = selectedObj['projectId'] + '_' + selectedObj['projectname'] + '(' + selectedObj['awspace'] + '/' + selectedObj['projectname'] + selectedObj['jwspace'] + '/' + selectedObj['projectname'] + ')';
      projectId = projectId.replace(/[: ?<>|\/*]/g, '_');
      let obj = {
        fileList: [`${userCode}/layoutRestore/${projectId}`],
      };
      this.shareService.cleanWorkSpaceStorage(obj).subscribe(
        (res: any) => {
          if (res["status"] == 200) {
            success("successfully clean layout storage");
          } else {
            alerts(res.msg);
          }
        },
        (error: any) => {
          alerts(error.msg);
        }
      );
    }
  }

  isProjectOnline(){
    this.procomparetool.isProjectOnline().subscribe(
      (response: any) => {
        this.isProjectOnlineFlag = response['isOnline'];
      },
    );
  }

  projectCloneButtonClick(){
    let selectedObj: any = this.gridDynamicObj_projectList.getSeletedRowData();
    if (this.isProjectOnlineFlag) {
      this.getUserWorkSpacePath();
    } else {
      this.angProjectPath = selectedObj.awspace || '';
      this.jwProjectPath = selectedObj.jwspace || '';
      $("#projectPathSetModel").modal("show");
    }
  }

  getUserWorkSpacePath() {
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'));
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId

    let selectedObj1 = this.gridDynamicObj_projectList.getSeletedRowData();
    if (!this.isProjectOnlineFlag) {
      selectedObj1.awspace = this.angProjectPath.trim();
      selectedObj1.jwspace = this.jwProjectPath.trim();
    }
    if (selectedObj1.awspace || selectedObj1.jwspace) {
      this.gitSvnChackOutClone();
    } else {

      this.procomparetool.getUserWorkSpacePath(userid, selectedObj1.projectId, sessionStoragedata.username).subscribe(
        (response: any) => {
          if (response.status == 200) {
            this.gridDynamicObj_projectList.updateCell(selectedObj1['sag_G_Index'], "jwspace", response.javaWorkspace);
            this.gridDynamicObj_projectList.updateCell(selectedObj1['sag_G_Index'], "awspace", response.angWorkspace);
          }
          this.gitSvnChackOutClone();
        },
        err => {
          this.gitSvnChackOutClone();
        }
      );
    }
  };


  gitSvnChackOutClone() {
    let selectedObj = this.gridDynamicObj_projectList.getSeletedRowData();
    if (!this.isProjectOnlineFlag) {
      selectedObj.awspace = this.angProjectPath.trim();
      selectedObj.jwspace = this.jwProjectPath.trim();
    }
    // if (((selectedObj.awspace != null || selectedObj.jwspace != null) && (selectedObj.awspace != '' || selectedObj.jwspace != '') &&
    //   (selectedObj.awspace != null || selectedObj.jwspace != '') && (selectedObj.awspace != '' || selectedObj.jwspace != '') && (selectedObj.awspace != selectedObj.jwspace))) {
    if ((selectedObj.awspace || selectedObj.jwspace) && (selectedObj.awspace != selectedObj.jwspace)) {
      $("#projectPathSetModel").modal("hide");
      this.setPathButtonClick();
      const ref = this.dialogService.open(GitSvnComponent, {
        header: 'Import Project',
        width: '40%',
        contentStyle: { "height": "335px" },
        styleClass: "dsDarkModal",
        data: { rowdata: this.shareService.getDataprotool("selectedProjectChooseData") }
      });
      ref.onClose.subscribe((res) => {
        console.info(res);
      });
    }
    //  else if ((selectedObj.awspace == selectedObj.jwspace)
    //   && (selectedObj.awspace != '' || selectedObj.jwspace != '')
    //   && (selectedObj.awspace != null || selectedObj.jwspace != null)) {
    else if ((selectedObj.awspace == selectedObj.jwspace) && (selectedObj.awspace || selectedObj.jwspace)) {
      alerts("Frontend & Backend path can't be same..!!");
    }
    else {
      alerts("Please Specify At Least One  Path..!");
    }
  }

  updateUserWiseLocalProjectPath() {
    let selectedObj = this.gridDynamicObj_projectList.getSeletedRowData();
    selectedObj.awspace = this.angProjectPath.trim();
    selectedObj.jwspace = this.jwProjectPath.trim();
    if (!selectedObj.awspace) {
      alerts("Please Enter Repository Path");
      return;
    }
    const postdata = [selectedObj];
    let posttdata = { data: postdata };
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.procomparetool.saveUserWiseLocalProjectPath(userId, posttdata).subscribe(
      (response: any) => {
        if (response['status'] == 200) {
          success("Repository Path Successfully Updated !!!");
          // this.getUserWiseLocalProjectPath();
          // this.saveUserWiseLocalProjectPathresponce = response['data']
        }
        else if (response['status'] == 406) {
          alerts(response['message']);
        }else{
          alerts('Internal Server Error');
        }
      }
    );
  }

  memberList: any
  getSpecificModuleList(projectId) {
    this.memberList = []
    const data = {
      projectId: projectId,
    }
    
    this.procomparetool.getSpecificModuleList(data).subscribe(res => {
      console.log(res);
      // this.listOfMultipleProject = res['data'];
      this.memberList = res['data'][0].members
      
    }
    )
  }
cardSelectedProjectId:any
  cardViewProject(projectId,project){
    console.log(project)
    this.cardSelectedProjectId = projectId
    this.shareService.selectedProjectId.next(this.cardSelectedProjectId)
  }

  onprojectListCellClick() {}

  onprojectListClick() {}

  onprojectListdblClick() {}

  


  // for new designs
  getSteps(event) {
    if (event == "next") {
      if (this.steps < 6) {
        this.steps++;
      }
    } else {
      if (this.steps > 1) {
        this.steps--;
      }
    }
  }

  // for new designs


  searchData=[]
  timer:any
  searchProject(searchValue:any){
    console.log(this.gridDynamicObj_projectList.getGridData() )
    clearTimeout(this.timer)
  this.timer = setTimeout(() => {
    this.searchData=[]
    if(searchValue.length>0){
   this.projectTaskDetailsData.filter((x)=>{
      if(x.projectname.includes(searchValue)){
          this.searchData.push(x)
          if(this.searchData.length>0)
          this.projectList(this.searchData);
      }
  })
}
else{
  this.projectList(this.projectTaskDetailsData);
}
  }, 700)
  }
// grid myTaskListGridNew start
gridData_myTaskListGridNew1: any;
gridDynamicObj_myTaskListGridNew1: any;
columnData_myTaskListGridNew1: any = [

 {
   header: "S.No.",
   field: "sno",
   filter: false,
   width: "50px",
   editable: "false",
   "text-align": "left",
   search: true,
   component: "label",
   cellRenderView: true,
   freezecol: "null",
   hidden: false,
   sort: false,
   cellHover: false,
 },
 {
   header: "Task Name",
   field: "task_name",
   filter: false,
   width: "200px",
   editable: "false",
   "text-align": "left",
   search: true,
   component: "label",
   cellRenderView: true,
   freezecol: "null",
   hidden: false,
   sort: false,
   cellHover: false,
 },
 {
   header: "Start Date",
   field: "start_date",
   filter: false,
   width: "200px",
   editable: "false",
   "text-align": "left",
   search: true,
   component: "label",
   cellRenderView: true,
   freezecol: "null",
   hidden: false,
   sort: false,
   cellHover: false,
 },
 {
   header: "Task Severity",
   field: "severity",
   filter: false,
   width: "200px",
   editable: "false",
   "text-align": "left",
   search: true,
   component: "label",
   cellRenderView: true,
   freezecol: "null",
   hidden: false,
   sort: false,
   cellHover: false,
 },
 
 {
  header: "Task Priority",
  field: "priority",
  filter: false,
  width: "200px",
  editable: "false",
  "text-align": "left",
  search: true,
  component: "label",
  cellRenderView: false,
  freezecol: "null",
  hidden: false,
  sort: false,
  cellHover: false,
},

{ header: "Action",
  field: "action",
  filter: false,
  width: "200px",
  editable: "false",
  "text-align": "left",
  search: true,
  component: "button",
  cellRenderView: true,
  freezecol: "null",
  hidden: false,
  sort: false,
  cellHover: false,
  button: {
       cellValue: "",
       visibility: true,
       name: "Action",
       classes: ["btnBlue"],
       attribute: "",
       styles: "",
     },
    },
 {
   header: "Load Project",
   field: "loadProject",
   filter: false,
   width: "150px",
   editable: "false",
   "text-align": "left",
   search: true,
   component: "button",
   cellRenderView: true,
   freezecol: "null",
   hidden: false,
   sort: false,
   cellHover: false,
   button: {
     cellValue: "",
     visibility: true,
     name: "Load Project",
     classes: ["btnRed"],
     attribute: "",
     styles: "",
   },
 },


];
rowData_myTaskListGridNew1: any = [];
validationmyTaskListGridNew1: any = {};
myTaskListGridNew1(rowData?, colData?) {
  let self = this;

  this.gridData_myTaskListGridNew1 = {
    columnDef: colData ? colData : this.columnData_myTaskListGridNew1,
    rowDef: rowData ? rowData : this.rowData_myTaskListGridNew1,
    footer_hide: false,
    totalNoOfRecord_hide: false,
    sml_expandGrid_hide: false,
    exportXlsxPage_hide: false,
    exportXlsxAllPage_hide: false,
    exportPDFLandscape_hide: false,
    exportPDFPortrait_hide: false,
    ariaHidden_hide: false,
    disableAllSearch: false,
    wordBreak: false,
    wordBreakHeader: false,
    cellHover: false,
    rowHover: false,
    rowBorder_hide: false,
    columnBorder_hide: false,
    header_hide: false,
    gridbody_hide: false,
    rowLineSpace: 0,
    multiHeader: false,
    common_search: true,
    common_search_column: "",
    common_filter: true,
    common_filter_column: "",
    validation: this.validationmyTaskListGridNew1,
    newPagination: false,
    recordPerPage: 10,
    components: {},
    commonSearchSelect_hide:true,
    commonFilterSelect_hide:true,
    // gridCustomButtonsArr:[{textContent:'Sort',iconClass:'',buttonName:'Sort'},{textContent:'Filter',iconClass:'',buttonName:'Filter'},{textContent:'Group',iconClass:'',buttonName:'Group'}],
    callBack: {
      onCellClick: function (ele) {
        self.onmyTaskListGridNewCellClick();
      },
      onRowClick: function () {
        self.onmyTaskListGridNewClick();
      },
      onRowDbleClick: function () {
        self.onmyTaskListGridNewdblClick();
      },
      onButton_action:function(){
        self.openTaskProgressComponentModal();
      },
      onButton_loadProject:function(ele,param){
        self.getLocalProject();
       // self.shareService.showBar.next(true)
       },
      // "gridCustomButtons": function (ele,param,name) {},
    },
    rowCustomHeight: 25,
  };

  let sourceDiv = document.getElementById("myTaskListGridNew1");
  this.gridDynamicObj_myTaskListGridNew1 = SdmtGridT(
    sourceDiv,
    this.gridData_myTaskListGridNew1,
    true,
    true
  );
}

onmyTaskListGridNewCellClick() {}

onmyTaskListGridNewClick() {}

onmyTaskListGridNewdblClick() {}

// grid  myTaskListGridNew end

OpenCrtPrjtStepper() {
  const ref = this.dialogService.open(BCreateProjectStepperComponent, {
    header: "create Project",
    width: "60%",
    contentStyle: { height: "90vh", maxHeight:'100%', minHeight:'100%', overflow:"hidden", flexDirection:"column", display:"flex", backgroundColor: "unset"},
    showHeader: false,
   
  });
}

selectedTab: any;
async openTaskProgressComponentModal() {
  const ref = this.dialogService.open(TaskProgressComponent, {
    header: "Version Control",
    width: "80%",
    contentStyle: { height: "75vh" },
    styleClass: "sdmtDarkMode",
  });

  ref.onClose.subscribe((res) => {

  });
}

async getLocalProject(proData?) {
  let projectData = this.shareService.getDataprotool("selectedProjectChooseData");
  this.shareService.projectUtility = false;
  await this.setPathButtonClick(proData);
  let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
  if (document.getElementById('scriptLoadID')) {
    if (projectData && selectedObj) {
      if (projectData.awspace == selectedObj.awspace) {
        if (document.getElementById('dashSideBar')) {
          document.getElementById('dashSideBar').classList.add('d-none');
        }
        this._router.navigate(['dashboard/database/projectToolFirst/newprojectinfo/project_type']);
        this.shareService.showBar.next(true)
        return;
      } else {
        await this.shareService.closeAllTerminalServers();
        if (window['angularComponentRef'].callStoreLayout) {
          await window['angularComponentRef'].callStoreLayout();
        }
        localStorage.setItem("checkProjectData", JSON.stringify(selectedObj));
        if (window['angularComponentRef'].getCheckClickOnLogout) {
          const checkClickOnLogout = await window['angularComponentRef'].getCheckClickOnLogout;
          checkClickOnLogout(true);
        }
        window.location.reload();
      }

    }
  }

  this.shareService.modeBoolean = true;
  if (window['angularComponentRef'].setProjectAlldetails) {
    const callFun = window['angularComponentRef'].setProjectAlldetails;
    callFun(selectedObj);
  }
  await this.shareService.getAccessRights();
  if (selectedObj) {
    const postData = {
      destpath: selectedObj.awspace,
      projectname: selectedObj.projectname,
    }
    this.shareService.loading++;
    const resSagStudioJson = await this.procomparetool.loadProjectJson(postData).toPromise().catch(console.warn);
    this.shareService.loading--;
    this._sagStudioService.sagWorkSpace = resSagStudioJson[0];
    if (this._sagStudioService.sagWorkSpace || this._sagStudioService.sagWorkSpace == undefined) {
      this.getDbConnObj(selectedObj.awspace + `/prjconn.json`);
      await this.getPrjConfObj(selectedObj.projectId);
      //  this.getpStylesScss();
      this.getFontFamily(selectedObj.awspace);
      // this.close('projectLoaded');
      this.selectedTab = 'project_type';
      this.projectPathReplaceProjectWise();
      // localStorage.setItem('UIBuilder', 'true');

    } else {
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: 'Something went Wrong !!!',
      });
    }
    this.shareService.propertyWindowJsonData().subscribe(jsonData => {
      this._sagStudioService.propertyWindowJson = jsonData["data"];
    })
    setTimeout(() => {
    //  document.querySelector('.sidebarArea').classList.add('d-none');
    document.getElementById('dashSideBar') ? document.getElementById('dashSideBar').classList.add('d-none') : false;
    }, 100)
  }
}

async getpStylesScss() {
  const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
  const fullPath = this._sagStudioService.getLocalFilePath("/src/styles.scss");
  const postData = {
    "destpath": fullPath,
    "projectName": `${selectedProjectChooseData.projectname}`,
    "projectSubtype": "scss"
  };
  this.shareService
    .getPageJson(postData)
    .subscribe((respJson) => {
      this._sagStudioService.currentActiveProject.subDataArray.push(...respJson['data']);
      const styleScssObj = this._sagStudioService.currentActiveProject
        .subDataArray
        .find(e => e["matchableId"] == `customfile~${selectedProjectChooseData.projectname}$src$styles.scss`)
      this._sagStudioService.pStylesScss = styleScssObj;
    });
}

getFontFamily(path) {
  let dataJson = {
    projectPath: path
  }
  this.shareService.getFontFamilyList(dataJson).subscribe(async (res) => {
    this._sagStudioService.fontFamilyList = res || [];

  });
}

  async newFunc(): Promise<void> {

    await this.shareService.getAccessRights();
    document.querySelector('body').classList.remove('uiEditorNew');
    this.shareService.showBar.next(true);
    this.shareService.loading--;
    this.firststepProjectService.projectHeaderActiveTab.next('project_type');
    this._router.navigate(['dashboard/database/projectToolFirst/newprojectinfo/project_type']);
    this.shareService.sidebarAreaShow.next(false);

    success("Project Loaded Successfully !!!...");
    localStorage.setItem('editorLoading', 'false');
    
  }


newContact(route) {
  this.selectedTab = route;
  this.firststepProjectService.projectHeaderActiveTab.next(route);
  this._router.navigate(["dashboard/database/projectToolFirst/newprojectinfo/project_type"]);
}

setPathButtonClick(setDefault?) {
  const loginUserInfo = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
  const userId = Number(loginUserInfo.data.clientInfo.usrId);
  let selectedObj: any;
  if(setDefault){
    selectedObj=setDefault;
  }else{
    selectedObj = this.gridDynamicObj_projectList.getSeletedRowData();

  }
  selectedObj = JSON.parse(JSON.stringify(selectedObj));
  
  return new Promise((res, rej) => {
    if(selectedObj){
      selectedObj['userId'] = userId;
     selectedObj.awspace ? (setDefault && setDefault.awspace) ? false : selectedObj.awspace = `${selectedObj.awspace}/${selectedObj.projectname}` : false;
      selectedObj.jwspace ? (setDefault && setDefault.jwspace) ? false :selectedObj.jwspace = `${selectedObj.jwspace}/${selectedObj.projectname}` : false;
      //Projects avalable on Repository auther@CP
      if (selectedObj.projectGitPath &&selectedObj.projectSvnPath) {
        selectedObj['projectOnRepository'] = true;
      } else {
        selectedObj['projectOnRepository'] = false;
      }
      this.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj)));
      localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj));
      this.shareService.setDatadbtool("projectNameValue", selectedObj.projectId);
      this.shareService.setDataprotool("selectedAngularProject", selectedObj.awspace);
      res(true);
    }else{
      rej(false);
    }
  });
}


addScript(path) {
  var head = document.getElementsByTagName("head")[0];
  var s = document.createElement("script");
  s.type = "text/javascript";
  s.src = path;
  s.id = "scriptLoadID";
  head.appendChild(s);
}


projectPathReplaceProjectWise() {
  const ProjectPath = this.shareService.getDataprotool("selectedProjectChooseData");
  const reqObj = {
    javaworkspace: ProjectPath.jwspace,
    angworkspace: ProjectPath.awspace,
  }
  this.shareService.loading++;
  this.procomparetool.projectPathReplace(reqObj).subscribe(
    async (response: any) => {
      this.shareService.loading--;
      if (response['status'] == 200) {
        this.shareService.loading++;
        this.shareService.setDataprotool("loadDataTreeType", "projectType");
        if (!document.getElementById('scriptLoadID')) {
          localStorage.setItem('editorLoading', 'true');
          this.addScript(this.shareService.editorLoadPath);
        }else {
          this.shareService.showEditor('show');
        }

        localStorage.setItem('openProject', 'false');
        localStorage.setItem('projectUtility', 'true');

      }
      else if (response['status'] == 500) {
        alerts(response.msg);
      }
    }, error => {
    }
  );
}

getDbConnObj(path) {
  let dataJson = {
    projectPath: path
  }
  this.shareService.getPrjConfObject(dataJson).subscribe((res) => {
    if (res['status'] == 'success') {
      let dbInfo = res['confobj'];
      dbInfo['operation'] = 'COMPARESINGLE';
      dbInfo['targetDataSource'] = {};
      dbInfo['details'] = {
        software: [],
        year: [],
        client: [],
        columns: [],
        operation: ['']
      }
      this.shareService.setDatadbtool('finalDataForConnection', dbInfo);
    }
  });
}

  // get project conf Object
  async getPrjConfObj(path) {
    let dataJson = {
      projectId: path
    }
    this.shareService.getProjectVersion(dataJson).subscribe(async (res) => {
      this.shareService.setData('angversnObj',res)
      let versionControl = this._sagStudioService.versionObject(res)
      if (res['status'] == 'success' && !ObjectCompare(versionControl[0], res)) {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: "PROJECT JSON VERSION  MISMATCH",
        });
        let conf = await ui.confirm("Do You Want To Update Project JSON Version? ");
        if (conf == true) {
          //  await this.openVersionCheckMappingModal(res['confobj']);
        }
        // log out code
        else {
          this.firststepProjectService.logout().subscribe(
            (data) => {
              //  this.close('projectLoaded');
              localStorage.clear();
              this.shareService.clearAllData();
              this.firststepProjectService.unAuthorizeCalllback();
            }
          );
        }
      }
      // project loaded successfull
      else {
        //success("Successfully Loaded Your Project !!!");
        // this.toast.launch_toast({
        //   type: 'success',
        //   position: 'bottom-right',
        //   message: 'Successfully Loaded Your Project !!!',
        // });

        this._sagStudioService.currentActiveProject = this._sagStudioService.sagWorkSpace.projectList.find(item => item.id == 'defaultProject1618079400000');
        this._sagStudioService.initSagWorkSpaceJSON("arg1", "arg2");
        this.onGetMobileTheme();
        //   this.close('projectLoaded');
      }
    });

    function ObjectCompare(o1, o2) {

      if (typeof o1 !== 'object' || typeof o2 !== 'object') {
        return false; // we compare objects only!
      }
      // when one object has more attributes than the other - they can't be eq
      if (Object.keys(o1).length !== Object.keys(o2).length) {
        return false;
      }
      for (let k of Object.keys(o1)) {
        if (o1[k] !== o2[k]) {
          return false;
        }
      }
      return true;
    }
  }

  
  onGetMobileTheme() {
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    const postData = {
      "projectName": `${selectedProjectChooseData.projectname}`,
    };
    this.shareService
      .getMobileTheme(postData)
      .subscribe(res => {
        if (res) {
          this._sagStudioService.mobileAppTheme = res["mobileTheme"];
        }
      });
  }
  

}


