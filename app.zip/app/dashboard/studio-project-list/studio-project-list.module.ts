import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudioProjectListRoutingModule } from './studio-project-list-routing.module';
import { StudioProjectListComponent } from './studio-project-list.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [StudioProjectListComponent],
  imports: [
    CommonModule,
    StudioProjectListRoutingModule,
    FormsModule
  ]
})
export class StudioProjectListModule { }
