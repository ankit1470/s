import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PendingApprovalStatusRoutingModule } from './pending-approval-status-routing.module';
import { PendingApprovalStatusComponent } from './pending-approval-status.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { CalendarModule } from 'primeng/calendar';

@NgModule({
  declarations: [PendingApprovalStatusComponent],
  imports: [
    CommonModule,
    PendingApprovalStatusRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    DropdownModule,
    CalendarModule
  ],
  exports:[PendingApprovalStatusComponent]
})
export class PendingApprovalStatusModule { }
