import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PendingApprovalFilesComponent } from './pending-approval-files.component';


const routes: Routes = [
  {
    path:"",
    component:PendingApprovalFilesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PendingApprovalFilesRoutingModule { }
