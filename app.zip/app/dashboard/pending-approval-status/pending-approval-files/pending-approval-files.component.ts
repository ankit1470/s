
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { DialogService, DynamicDialogConfig } from 'primeng/api';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-pending-approval-files',
  templateUrl: './pending-approval-files.component.html',
  styleUrls: ['./pending-approval-files.component.scss']
})
export class PendingApprovalFilesComponent implements OnInit {
  gridDynamicPendingFiles: any;
  PendingStatusFileData: any;
  ModuleOwnerAndReviewUser: any;
  gridDynamicFileHisTory: any;
  commingFlag = "ProjectTypeFlag"
  compareToolDisplay: boolean = false;
  openHtmlFlag: boolean = true;
  constructor(public config: DynamicDialogConfig,
    private ProcomparetoolService: ProcomparetoolService,
    private shareService: SagShareService,
    public dialogService: DialogService,
    private _cdRef: ChangeDetectorRef,
  ) { }

  ngOnInit() {
    this.PendingStatusFileData = this.config.data
    if (this.PendingStatusFileData.projectType == "JAVA") {
      if (this.PendingStatusFileData.purpose == "Review") {
        this.getApproveListForReviewUser(this.PendingStatusFileData);
      } else {
        this.getApproveListForModuleOwner(this.PendingStatusFileData)
      }
      this.PendingStatusFilesGrid([])
    }
    else if (this.PendingStatusFileData.projectType == "ANGULAR") {
      if (this.PendingStatusFileData.purpose == "Review") {
        this.getApproveListForAngularReviewUser(this.PendingStatusFileData);
      } else {
        this.getApproveListForAngularModuleOwner(this.PendingStatusFileData)
      }
      this.PendingStatusFilesGrid([])
    }
  }

  getApproveListForModuleOwner(SelectedRowObj) {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.ProcomparetoolService.getApproveListForModuleOwnerData(SelectedRowObj.userId, parseInt(sessionStoragedatauserId.data.clientInfo.usrId), SelectedRowObj.workId).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.ModuleOwnerAndReviewUser = response["data"]
          let __itsValue = this.ModuleOwnerAndReviewUser.map(item => {
            let newitem = item;
            if (newitem['isManual'] == 'M') {
              newitem['isManual'] = 'Manual'
            }
            else if (newitem['isManual'] == 'A') {
              newitem['isManual'] = 'Auto'
            }
            return newitem;
          })
          this.PendingStatusFilesGrid(__itsValue)
        }
        else if (response["status"] == 500) {
          this.ModuleOwnerAndReviewUser = response["data"]
          this.PendingStatusFilesGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }


    )
  }

  getApproveListForAngularModuleOwner(SelectedRowObj) {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.ProcomparetoolService.getApproveListForAngularModuleOwnerData(SelectedRowObj.userId, parseInt(sessionStoragedatauserId.data.clientInfo.usrId), SelectedRowObj.workId).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.ModuleOwnerAndReviewUser = response["data"]
          let __itsValue = this.ModuleOwnerAndReviewUser.map(item => {
            let newitem = item;
            if (newitem['isManual'] == 'M') {
              newitem['isManual'] = 'Manual'
            }
            else if (newitem['isManual'] == 'A') {
              newitem['isManual'] = 'Auto'
            }
            return newitem;
          })
          this.PendingStatusFilesGrid(__itsValue)
        }
        else if (response["status"] == 500) {
          this.ModuleOwnerAndReviewUser = response["data"]
          this.PendingStatusFilesGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }


    )
  }
  getApproveListForReviewUser(SelectedRowObj) {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.ProcomparetoolService.getApproveListForReviewUserData(SelectedRowObj.userId, parseInt(sessionStoragedatauserId.data.clientInfo.usrId), SelectedRowObj.workId).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.ModuleOwnerAndReviewUser = response["data"]
          let __itsValue = this.ModuleOwnerAndReviewUser.map(item => {
            let newitem = item;
            if (newitem['isManual'] == 'M') {
              newitem['isManual'] = 'Manual'
            }
            else if (newitem['isManual'] == 'A') {
              newitem['isManual'] = 'Auto'
            }
            return newitem;
          })
          this.PendingStatusFilesGrid(__itsValue)
        }
        else if (response["status"] == 500) {
          this.ModuleOwnerAndReviewUser = response["data"]
          this.PendingStatusFilesGrid(this.ModuleOwnerAndReviewUser)
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }



    )
  }

  getApproveListForAngularReviewUser(SelectedRowObj) {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.ProcomparetoolService.getApproveListForAngularReviewUserData(SelectedRowObj.userId, parseInt(sessionStoragedatauserId.data.clientInfo.usrId), SelectedRowObj.workId).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.ModuleOwnerAndReviewUser = response["data"]
          let __itsValue = this.ModuleOwnerAndReviewUser.map(item => {
            let newitem = item;
            if (newitem['isManual'] == 'M') {
              newitem['isManual'] = 'Manual'
            }
            else if (newitem['isManual'] == 'A') {
              newitem['isManual'] = 'Auto'
            }
            return newitem;
          })
          this.PendingStatusFilesGrid(__itsValue)
        }
        else if (response["status"] == 500) {
          this.ModuleOwnerAndReviewUser = response["data"]
          this.PendingStatusFilesGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }



    )
  }
  getChangesMethodById(SelectedRowObj) {
    this.ProcomparetoolService.getChangesMethodByIdData(SelectedRowObj.workId, SelectedRowObj.userId, SelectedRowObj.methodNameId).subscribe(
      (response: any) => {
        if (response.status == 200) {
          this.shareService.setDataprotool("rightSideCode", response.data.changesCode);
          this.shareService.setDataprotool("leftSideCode", response.data.previousCode);
          this.shareService.setDataprotool("rightSideCodeFile", "New Code");
          this.shareService.setDataprotool("leftSideCodeFile", "Previous Code");
          this.shareService.setDataprotool("filePathEditorDiff", {
               path: SelectedRowObj["srcfileUniqePath"],
            projectpath: undefined
        });
          this.openHtmlFlag = false;
          this.compareToolDisplay = true;
          this._cdRef.detectChanges();
          this.compareToolDisplay ? $("#VscodecampareToolforPendingApproval").modal('show') : false;
        }
        else if (response.status == 500) {
          alerts(response['message']);
        }
        else {
          alerts(response['message']);
        }
      },
      err => {
        console.error('err response');
        alerts(err.error.msg);
      }
    );
  }
  getChangesSrcFileById(SelectedRowObj) {
    this.ProcomparetoolService.getChangesSrcFileByIdData(SelectedRowObj.workId, SelectedRowObj.userId, SelectedRowObj.srcfileId).subscribe(
      (response: any) => {
        if (response.status == 200) {
          this.shareService.setDataprotool("rightSideCode", response.data.changesCode);
          this.shareService.setDataprotool("leftSideCode", response.data.previousCode);
          this.shareService.setDataprotool("rightSideCodeFile", "New Code");
          this.shareService.setDataprotool("leftSideCodeFile", "Previous Code");
          this.shareService.setDataprotool("filePathEditorDiff", {
            path: SelectedRowObj["srcfileUniqePath"],
            projectpath: undefined
        });
        this.openHtmlFlag = false;
        this.compareToolDisplay = true;
        this._cdRef.detectChanges();
        this.compareToolDisplay ? $("#VscodecampareToolforPendingApproval").modal('show') : false;
        }
        else if (response.status == 500) {
          alerts(response['msg']);
        }
        else {
          alerts(response['msg']);
        }
      },
      err => {
        console.error('err response');
        alerts(err.error.msg);
      }
    );
  }
  pendingApprovalFilesSave() {
    if (this.PendingStatusFileData.projectType == "JAVA") {
      if (this.PendingStatusFileData.purpose == "Review") {
        this.updateWorkApproveUser()
      } else {
        this.updateWorkDependUser();
      }
    }
    else if (this.PendingStatusFileData.projectType == "ANGULAR") {
      if (this.PendingStatusFileData.purpose == "Review") {
        this.updateAngularWorkApproveUser()
      } else {
        this.updateAngularWorkDependUser();
      }
    }
  }
  Checked_ArraySave = []
  updateWorkApproveUser() {
    this.Checked_ArraySave = []
    const Checked_Array = this.gridDynamicPendingFiles.getCheckedDataParticularColumnWise();
    Checked_Array.forEach(_ele => {
      const reqObj = {
        "id": _ele.approveId,
        "status": _ele.status,
        "remark": _ele.remark,
        "workStatusId": _ele.workStatusId,
        "userCid": _ele.userCid,
        "userId": _ele.userId,
      }
      this.Checked_ArraySave.push(reqObj)
    });
    this.ProcomparetoolService.updateWorkApproveUser(this.Checked_ArraySave).subscribe(
      (response: any) => {

        if (response["status"] == 200) {
          success(response.msg);
        }
        else if (response["status"] == 500) {
          alerts(response.msg)
        }
        else if (response["status"] == 400) {

        } else {
        }
      }, error => {
        alerts("Error While assign right")
      }
    );
  }
 
  updateAngularWorkApproveUser() {
    this.Checked_ArraySave = []
    const Checked_Array = this.gridDynamicPendingFiles.getCheckedDataParticularColumnWise();
    Checked_Array.forEach(_ele => {
      const reqObj = {
        "id": _ele.approveId,
        "status": _ele.status,
        "remark": _ele.remark,
        "workStatusId": _ele.workStatusId,
        "userCid": _ele.userCid,
        "userId": _ele.userId,
      }
      this.Checked_ArraySave.push(reqObj)
    });
    this.ProcomparetoolService.updateAngularWorkApproveUser(this.Checked_ArraySave).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          success(response.msg);
        }
        else if (response["status"] == 500) {
          alerts(response.msg)
        }
        else if (response["status"] == 400) {

        } else {
        }
      }, error => {
        alerts("Error While assign right")
      }
    );
  }
  updateWorkDependUser() {
    const SelectedRow_Obj = this.gridDynamicPendingFiles.getSeletedRowData();;

    this.Checked_ArraySave = []
    const Checked_Array = this.gridDynamicPendingFiles.getCheckedDataParticularColumnWise();
    Checked_Array.forEach(_ele => {
      const reqObj = {
        "id": _ele.depentId,
        "status": _ele.status,
        "remark": _ele.remark,
        "workStatusId": _ele.workStatusId,
        "userCid": _ele.userCid,
        "userId": _ele.userId,
      }
      this.Checked_ArraySave.push(reqObj)
    });

    console.log(SelectedRow_Obj)
    // const reqObj = {
    //   "id": SelectedRow_Obj.depentId,
    //   "status": SelectedRow_Obj.status,
    //   "remark": SelectedRow_Obj.remark,
    //   "workStatusId": SelectedRow_Obj.workStatusId,
    //   "userCid": SelectedRow_Obj.userCid,
    //   "userId": SelectedRow_Obj.userId,
    // }
    this.ProcomparetoolService.updateWorkDependUser(this.Checked_ArraySave).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          success(response.msg);
        }
        else if (response["status"] == 500) {
          alerts(response.msg)
        }
        else if (response["status"] == 400) {

        } else {
        }
      }, error => {
        alerts("Error While assign right")
      }
    );
  }
  updateAngularWorkDependUser() {
    // const SelectedRow_Obj = this.gridDynamicPendingFiles.getSeletedRowData();
    // const reqObj = {
    //   "id": SelectedRow_Obj['depentId'],
    //   "status": SelectedRow_Obj['status'],
    //   "remark": SelectedRow_Obj['remark'],
    //   "workStatusId": SelectedRow_Obj['workStatusId'],
    //   "userCid": SelectedRow_Obj['userCid'],
    //   "userId": SelectedRow_Obj['userId'],
    // }

    this.Checked_ArraySave = []
    const Checked_Array = this.gridDynamicPendingFiles.getCheckedDataParticularColumnWise();
    Checked_Array.forEach(_ele => {
      const reqObj = {
        "id": _ele.depentId,
        "status": _ele.status,
        "remark": _ele.remark,
        "workStatusId": _ele.workStatusId,
        "userCid": _ele.userCid,
        "userId": _ele.userId,
      }
      this.Checked_ArraySave.push(reqObj)
    });

    this.ProcomparetoolService.updateAngularWorkDependUser(this.Checked_ArraySave).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          success(response.msg);
        }
        else if (response["status"] == 500) {
          alerts(response.msg)
        }
        else if (response["status"] == 400) {

        } else {
        }
      }, error => {
        alerts("Error While assign right")
      }
    );
  }
  PendingStatusFilesGrid(rowsData) {
    const sourceDiv = document.getElementById("PendingStatusFilesId");
    const columns = [
      {
        "header": "checkBox",
        "field": "checkbox",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "colType": "checkBox",
        "freezecol": "null",
        "hidden": false,
      },

      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Project Name",
        field: "projectName",
        filter: true,
        width: "255px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Src File Name",
        field: "srcfileName",
        filter: true,
        width: "260px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "MethodName",
        field: "methodName",
        filter: true,
        width: "216px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "Code Type",
        field: "isManual",
        filter: true,
        width: "216px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "User Name",
        field: "userName",
        filter: true,
        width: "197px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "status",
        field: "status",
        filter: true,
        width: "190px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": "selectselectDropDown",
      },
      {
        header: "Remark",
        field: "remark",
        filter: true,
        width: "270px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": "descriptionComp",
      },


    ];
    var self = this;
    let dropDownValue = [
      { "key": null, "val": "--Select--" },
      { "key": "A", "val": "Approve" },
      { "key": "R", "val": "Reject" },

    ];
    // let selectDropDown = new SagSelectBox(dropDownValue, function (ele, params) {
    //   ele.onkeydown = function (event) {

    //   }
    // });
    let selectDropDown = new SagSelectBox(dropDownValue, function (ele, params) {
      ele.onkeydown = function (event) {
        if (event.keyCode == 13) {
          self.pendingApprovalFileEnterClick(ele, params, dropDownValue);

        }
      }
    });
    let components = {
      "selectselectDropDown": selectDropDown,
      "descriptionComp": new SagInputText({}, function () {
      }),
      "textInputObj": new SagInputText({}, function () {
      }),
    };
    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.onSelectedRowClick(event);
          },
          "onRowDbleClick": function () {
            self.onSelectedRowDoubleClick(event);
          },

        }
      };
      this.gridDynamicPendingFiles = SagGridMPT(sourceDiv, gridData, true, true);
      this.setColorOnGrid();
      this.setRowColorOnGrid();
    }
  }
  pendingApprovalFileEnterClick(ele, params, dropDownValue) {
    const checkSelectedArray = this.gridDynamicPendingFiles.sagGridObj.checkedRowIdArray
    checkSelectedArray.forEach(index => {
      this.gridDynamicPendingFiles.updateCell(index, "status", ele.value);
    });

  }
  onSelectedRowClick(event: Event) {
    let SelectedRowObj = this.gridDynamicPendingFiles.getSeletedRowData();
    this.shareService.setDatadbtool("SelectedRowObj", SelectedRowObj)
  }

  onSelectedRowDoubleClick(event: Event) {
    let SelectedRowObj = this.gridDynamicPendingFiles.getSeletedRowData();
    this.shareService.setDataprotool("GitselectedDataForProjectCompareDetails", SelectedRowObj);
    let column = this.gridDynamicPendingFiles.getSeletedCellData().field;
    if (this.PendingStatusFileData.projectType == "JAVA") {
      if (column == "methodName") {
        this.getChangesMethodById(SelectedRowObj);
      } else if (column == "srcfileName") {
        this.getChangesSrcFileById(SelectedRowObj)
      }
    }
    else if (this.PendingStatusFileData.projectType == "ANGULAR") {
      if (column == "methodName") {
        this.gethistoryrivisionPandingMathodcontent(SelectedRowObj);

      } else if (column == "srcfileName") {
        this.gethistoryrivisionPandingfilecontent(SelectedRowObj)
      }
    }
  }
  setRowColorOnGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicPendingFiles.sagGridObj.originalRowData
    gridRowsData.forEach((ele, index) => {
      if (ele.isManual == "Manual") {
        if (ele.isManual) {
          self.gridDynamicPendingFiles.setColRowProperty(index, 'isManual', { "background": "#87dba1" });
        }
      }
    });
  }
  setColorOnGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicPendingFiles.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      // change Row Color
      if (ele.srcfileName || ele.projectName || ele.userName || ele.methodName) {
        self.gridDynamicPendingFiles.setColRowProperty(index, 'projectName', { "background": "#87dba1" });
        self.gridDynamicPendingFiles.setColRowProperty(index, 'srcfileName', { "background": "#fff8e1" });
        self.gridDynamicPendingFiles.setColRowProperty(index, 'userName', { "background": "#f8d7da" });
        self.gridDynamicPendingFiles.setColRowProperty(index, 'methodName', { "background": "#f9e79f" });

      }

      ;
    });

  }
  gethistoryrivisionPandingfilecontent(SelectedRowObj) {
    this.ProcomparetoolService.gethistoryrivisionPandingFilecontent(SelectedRowObj.workId, SelectedRowObj.userId, SelectedRowObj.srcfileId).subscribe(
      (response: any) => {
        if (response.status == 200) {
          this.shareService.setDataprotool("rightSideCode", response.data.changesCode);
          this.shareService.setDataprotool("leftSideCode", response.data.previousCode);
          this.shareService.setDataprotool("rightSideCodeFile", "New Code");
          this.shareService.setDataprotool("leftSideCodeFile", "Previous Code");
              this.shareService.setDataprotool("filePathEditorDiff", {
              path: SelectedRowObj["srcfileUniqePath"],
              projectpath: undefined
          });
          this.openHtmlFlag = false;
          this.compareToolDisplay = true;
          this._cdRef.detectChanges();
          this.compareToolDisplay ? $("#VscodecampareToolforPendingApproval").modal('show') : false;
        }
        else if (response.status == 500) {
          alerts(response['msg']);
        }
        else {
          alerts(response['msg']);
        }
      },
      err => {
        console.error('err response');
        alerts(err.error.msg);
      }
    );
  }
  gethistoryrivisionPandingMathodcontent(SelectedRowObj) {
    this.ProcomparetoolService.gethistoryrivisionPandingMathodcontent(SelectedRowObj.workId, SelectedRowObj.userId, SelectedRowObj.methodNameId).subscribe(
      (response: any) => {
        if (response.status == 200) {
          this.shareService.setDataprotool("rightSideCode", response.data.changesCode);
          this.shareService.setDataprotool("leftSideCode", response.data.previousCode);
          this.shareService.setDataprotool("rightSideCodeFile", "New Code");
          this.shareService.setDataprotool("leftSideCodeFile", "Previous Code");
          this.shareService.setDataprotool("leftSideCodeFile", "Previous Code");
          this.shareService.setDataprotool("filePathEditorDiff", {
             path: SelectedRowObj["srcfileUniqePath"],
          projectpath: undefined
      });
          this.openHtmlFlag = false;
          this.compareToolDisplay = true;
          this._cdRef.detectChanges();
          this.compareToolDisplay ? $("#VscodecampareToolforPendingApproval").modal('show') : false;
        }
        else if (response.status == 500) {
          alerts(response['msg']);
        }
        else {
          alerts(response['msg']);
        }
      },
      err => {
        console.error('err response');
        alerts(err.error.msg);
      }
    );
  }
}
