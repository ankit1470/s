import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { SharedModule } from 'src/app/core/shared/shared.module';
import { EditorDiffChangeModule } from 'src/app/modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-diff-change/editor-diff-change.module';
import { ViewFileModule } from 'src/app/modules/database/project-utility-tool/view-file/view-file.module';
import { WidgetModule } from 'src/app/modules/database/widget/widget.module';
import { PendingApprovalFilesRoutingModule } from './pending-approval-files-routing.module';
import { PendingApprovalFilesComponent } from './pending-approval-files.component';


@NgModule({
  declarations: [PendingApprovalFilesComponent],
  imports: [
    CommonModule,
    PendingApprovalFilesRoutingModule,
    ViewFileModule,
    SharedModule,
    WidgetModule,
    EditorDiffChangeModule
  ],
  exports:[PendingApprovalFilesComponent]
})
export class PendingApprovalFilesModule { }
