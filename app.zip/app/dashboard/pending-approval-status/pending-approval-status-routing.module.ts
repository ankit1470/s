import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PendingApprovalStatusComponent } from './pending-approval-status.component';


const routes: Routes = [
  {
    path:"",
    component:PendingApprovalStatusComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PendingApprovalStatusRoutingModule { }
