
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DialogService } from 'primeng/api';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { PendingApprovalFilesComponent } from './pending-approval-files/pending-approval-files.component';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-pending-approval-status',
  templateUrl: './pending-approval-status.component.html',
  styleUrls: ['./pending-approval-status.component.scss']
})
export class PendingApprovalStatusComponent implements OnInit {
  gridDynamicPendingApproval: any;
  gridDynamicApproved: any;
  gridDynamicPending: any;
  innerType = [
    {
      "label": "----Select----",
      "value": null
    },
    {
      "label": "JAVA",
      "value": "JAVA"
    }, {
      "label": "ANGULAR",
      "value": "ANGULAR"
    }
  ]
  PendingStatusData: any;
  ApprovedStatusData: any;
  commitedListObj: any;
  commitTaskListForm: any;
  constructor(private ProcomparetoolService: ProcomparetoolService,
    private shareService: SagShareService,
    private formBuilder: FormBuilder, public dialogService: DialogService,) { }

  ngOnInit() {
    this.initgitCommitTaskForm();
    this.getJavapendingList();
  }
  initgitCommitTaskForm() {
    this.commitTaskListForm = this.formBuilder.group({
      startDate: [null, Validators.required],
      endDate: [null, Validators.required],
    });
  }
  getOnChangPandingList(event) {
    if (event.value == "JAVA") {
      this.getJavapendingList();
    }
    else if (event.value == "ANGULAR") {
      this.getAngularpendingList();
    }
    else {

    }
  }
  getOnChangeApprovedList(event) {
    if (event.value == "JAVA") {
      this.getJavaApprovedList();
    }
    else if (event.value == "ANGULAR") {
      this.getAngularApprovedList()
    }
    else {

    }
  }

  getJavapendingList() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.shareService.setDataprotool("TaskPendingList", "");
    this.ProcomparetoolService.getPendingList(parseInt(sessionStoragedatauserId.data.clientInfo.usrId)).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.PendingStatusData = response["data"];
          let objItem = this.PendingStatusData.map(item => {
            item["projectType"] = "JAVA";
            return item
          })
          this.PendingStatusGrid(objItem);
        }
        else if (response["status"] == 500) {
          this.PendingStatusGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }
    );
  }
  getAngularpendingList() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.shareService.setDataprotool("TaskPendingList", "");
    this.ProcomparetoolService.getAngularPendingList(parseInt(sessionStoragedatauserId.data.clientInfo.usrId)).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.PendingStatusData = response["data"];
          let objItem = this.PendingStatusData.map(item => {
            item["projectType"] = "ANGULAR";
            return item
          })
          this.PendingStatusGrid(objItem)

        }
        else if (response["status"] == 500) {
          this.PendingStatusGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }
    );
  }

  getJavaApprovedList() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.shareService.setDataprotool("TaskPendingList", "");
    this.ProcomparetoolService.getApprovedList(parseInt(sessionStoragedatauserId.data.clientInfo.usrId)).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.ApprovedStatusData = response["data"]
          let objItem = this.ApprovedStatusData.map(item => {
            item["projectType"] = "JAVA";
            return item
          })
          this.ApprovedStatusGrid(objItem)
        }
        else if (response["status"] == 500) {
          this.ApprovedStatusGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }
    );
  }
  getAngularApprovedList() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.ProcomparetoolService.getAngularApprovedList(parseInt(sessionStoragedatauserId.data.clientInfo.usrId)).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.ApprovedStatusData = response["data"]
          let objItem = this.ApprovedStatusData.map(item => {
            item["projectType"] = "ANGULAR";
            return item
          })
          this.ApprovedStatusGrid(objItem)
        }
        else if (response["status"] == 500) {
          this.ApprovedStatusGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }
    );
  }

  taskPendingApprovalStatus(SelectedRowObj) {
    const ref = this.dialogService.open(PendingApprovalFilesComponent, {
      header: "Task Pending Approval Files",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model ",
      data: SelectedRowObj
    });
    ref.onClose.subscribe((res) => {

    });
  }
  PendingStatusGrid(rowsData) {
    const sourceDiv = document.getElementById("PendingStatusId");
    const columns = [

      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Project Name",
        field: "projectName",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Task Id/ Description",
        field: "taskNumberAndDesc",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "Reguest Datetime",
        field: "requestTime",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "User Name",
        field: "userName",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "TL Name",
        field: "tlName",
        filter: true,
        width: "120px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "Module Name",
        field: "moduleName",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "Status",
        field: "status",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },

      {
        header: "For(Approval/Pending)",
        field: "purpose",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },


    ];
    var self = this;
    let dropDownValue = [
      { "key": null, "val": "--Select--" },
      { "key": "Y", "val": "YES" },
      { "key": "N", "val": "NO" },
    ];

    let selectDropDown = new SagSelectBox(dropDownValue, function (ele, params) {
      ele.onkeydown = function (event) {

      }
    });

    let components = {
      "selectselectDropDown": selectDropDown,
      "descriptionComp": new SagInputText({}, function () {
      }),
      "textInputObj": new SagInputText({}, function () {
      }),
    };


    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.onRowSelectTaskPendingApprovalList(event);
          },
          "onRowDbleClick": function () {
            self.onSelectedRowDoubleClick(event);
          }
        }
      };
      this.gridDynamicPending = SagGridMPT(sourceDiv, gridData, true, true);
      this.setColorOnGrid();
    }
  }
  setColorOnGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicPending.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      // change Row Color
      if (ele.taskNumberAndDesc || ele.userName || ele.status || ele.purpose) {
        self.gridDynamicPending.setColRowProperty(index, 'taskNumberAndDesc', { "background": "#fff8e1" });
        self.gridDynamicPending.setColRowProperty(index, 'userName', { "background": "#f8d7da" });
        self.gridDynamicPending.setColRowProperty(index, 'status', { "background": "#f9e79f" });
        self.gridDynamicPending.setColRowProperty(index, 'purpose', { "background": "#43ac6a" });
      }

      ;
    });

  }
  onSelectedRowDoubleClick(event: Event) {
    let SelectedRowObj = this.gridDynamicPending.getSeletedRowData();
    this.taskPendingApprovalStatus(SelectedRowObj);
  }
  onRowSelectTaskPendingApprovalList(event) {
    let SelectedRowObj = this.gridDynamicPending.getSeletedRowData();
    this.shareService.setDataprotool("TaskPendingList", SelectedRowObj);
  }

  ApprovedStatusGrid(rowsData) {
    const sourceDiv = document.getElementById("ApprovedGridId");
    const columns = [
      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Project Name",
        field: "projectName",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Task Id/ Description",
        field: "taskNumberAndDesc",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "Reguest Datetime",
        field: "requestTime",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "User Name",
        field: "userName",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "TL Name",
        field: "tlName",
        filter: true,
        width: "120px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "Module Name",
        field: "moduleName",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "Status",
        field: "status",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },

      {
        header: "For(Approval/Pending)",
        field: "purpose",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "Approved Date",
        field: "approvedDate",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },

    ];
    var self = this;
    let dropDownValue = [
      { "key": null, "val": "--Select--" },
      { "key": "Y", "val": "YES" },
      { "key": "N", "val": "NO" },
    ];

    let selectDropDown = new SagSelectBox(dropDownValue, function (ele, params) {
      ele.onkeydown = function (event) {

      }
    });

    let components = {
      "selectselectDropDown": selectDropDown,
      "descriptionComp": new SagInputText({}, function () {
      }),
      "textInputObj": new SagInputText({}, function () {
      }),
    };


    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            //self.onRowSelectApprovalCommitedListGrid(event);
          },
          "onRowDbleClick": function () {
            self.onSelectedRowDoubleFileClick(event);
          }
        }
      };
      this.gridDynamicApproved = SagGridMPT(sourceDiv, gridData, true, true);
      this.setColorOnGrid1();
    }
  }
  onSelectedRowDoubleFileClick(event: Event) {
    let SelectedRowObj = this.gridDynamicApproved.getSeletedRowData();
    this.taskPendingApprovalStatus(SelectedRowObj);
  }
  setColorOnGrid1() {
    let self = this;
    let gridRowsData = self.gridDynamicApproved.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      // change Row Color
      if (ele.taskNumberAndDesc || ele.userName || ele.status || ele.purpose) {
        self.gridDynamicApproved.setColRowProperty(index, 'taskNumberAndDesc', { "background": "#fff8e1" });
        self.gridDynamicApproved.setColRowProperty(index, 'userName', { "background": "#f8d7da" });
        self.gridDynamicApproved.setColRowProperty(index, 'status', { "background": "#f9e79f" });
        self.gridDynamicApproved.setColRowProperty(index, 'purpose', { "background": "#43ac6a" });
      }

      ;
    });

  }

  taskPendingFilesClick() {
    const obj = this.shareService.getDataprotool("TaskPendingList");
    if (obj == "" || obj == undefined) {
      alerts("Please select at least one row ! ")
    }
    else {
      this.taskPendingApprovalStatus(obj);
    }
  }
  

  getCommitedList() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    const prj_Details = this.shareService.getDataprotool("selectedProjectChooseData");
      const _reqJson = {
        userId:sessionStoragedatauserId.data.clientInfo.usrId,
        projectId:prj_Details.projectId,
        startDate:null,
        endDate:null
      }
    this.ProcomparetoolService.getCommitedListJson(_reqJson).subscribe(
      (response: any) => {
        if (response["data"].length > 0) {
          this.commitedListGrid(response["data"])
        }
        else if (response["data"].length <= 0) {
          this.commitedListGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }
    );
  }
  getCommitedListByBtn() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    const prj_Details = this.shareService.getDataprotool("selectedProjectChooseData");
      const _reqJson = {
        userId:sessionStoragedatauserId.data.clientInfo.usrId,
        projectId:prj_Details.projectId,
        startDate:this.commitTaskListForm.controls['startDate'].value,
        endDate:this.commitTaskListForm.controls['endDate'].value
      }
    this.ProcomparetoolService.getCommitedListJson(_reqJson).subscribe(
      (response: any) => {
        if (response["data"].length > 0) {
          this.commitedListGrid(response["data"])
        }
        else if (response["data"].length <= 0) {
          this.commitedListGrid([])
        } else {
        }
      }, error => {
        alerts("Error While Fetching")
      }
    );
  }
  commitedListGrid(rowsData) {
    const sourceDiv = document.getElementById("commitedGridId");
    const columns = [
      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Project Name",
        field: "projectName",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Task Id/ Description",
        field: "ticketNo",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "Reguest Datetime",
        field: "createdDate",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "Assign To",
        field: "assignTo",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "Assign By",
        field: "assignBy",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "help Remark",
        field: "helpRemark",
        filter: true,
        width: "120px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },
      {
        header: "work Desc",
        field: "workDesc",
        filter: true,
        width: "385px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },

    
      {
        header: "Approved Date",
        field: "approvedDate",
        filter: true,
        width: "150px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      },

    ];
    var self = this;
    let components = {
      "descriptionComp": new SagInputText({}, function () {
      }),
      "textInputObj": new SagInputText({}, function () {
      }),
    };


    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
          },
          "onRowDbleClick": function () {
          }
        }
      };
      this.commitedListObj = SagGridMPT(sourceDiv, gridData, true, true);
      this.commitedListColor();
    }
  }
  commitedListColor() {
    let self = this;
    let gridRowsData = self.commitedListObj.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      // change Row Color
      if (ele.projectName || ele.assignTo || ele.assignBy ) {
        self.commitedListObj.setColRowProperty(index, 'projectName', { "background": "#f9e79f" });
        self.commitedListObj.setColRowProperty(index, 'assignTo', { "background": "#f8d7da" });
        self.commitedListObj.setColRowProperty(index, 'assignBy', { "background": "#f8d7da" });
       ;
      }

      ;
    });

  }
}
