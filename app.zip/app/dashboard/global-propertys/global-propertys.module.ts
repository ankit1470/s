import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GlobalPropertysRoutingModule } from './global-propertys-routing.module';
import { GlobalPropertysComponent } from './global-propertys.component';


@NgModule({
  declarations: [GlobalPropertysComponent],
  imports: [
    CommonModule,
    GlobalPropertysRoutingModule
  ],exports:[GlobalPropertysComponent]
})
export class GlobalPropertysModule { }
