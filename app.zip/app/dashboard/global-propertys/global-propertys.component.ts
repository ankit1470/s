import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-global-propertys',
  templateUrl: './global-propertys.component.html',
  styleUrls: ['./global-propertys.component.scss']
})
export class GlobalPropertysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
