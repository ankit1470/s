import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SaveStudioFilesRoutingModule } from './save-studio-files-routing.module';
import { SaveStudioFilesComponent } from './save-studio-files.component';


@NgModule({
  declarations: [SaveStudioFilesComponent],
  imports: [
    CommonModule,
    SaveStudioFilesRoutingModule
  ],
  exports:[SaveStudioFilesComponent]
})
export class SaveStudioFilesModule { }
