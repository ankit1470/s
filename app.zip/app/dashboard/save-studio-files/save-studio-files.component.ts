/**
 * @author P A N K A J   S I N G H
 * @var  
 */

import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { ApiServiceService } from 'src/app/services/http/api-service.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  selector: 'app-save-studio-files',
  templateUrl: './save-studio-files.component.html',
  styleUrls: ['./save-studio-files.component.scss']
})
export class SaveStudioFilesComponent implements OnInit {
  gridDynamicForSaveFile: any;
  sagBlankData = []
  sagStudioChangesFiles: any;
  SaveDataJson: any;
  gridDynamicForExplorerFiles: any;
  sagStudioCExplorerFilesData: any;
  SaveJsonData: any;
  sagStudioChangesFilesData: any;
  projectTreefileDatalist: any;
  projectTreefileData: any;
  eventdatalistdata: any;
  newPath: string;
  readFileContent: any;
  responceFileContect: any;
  getDataJson: any;
  constructor(
    public _sagStudioService: SagStudioService,
    private dbcomparetoolService: ProcomparetoolService,
    private shareService: SagShareService,
    private cdRef: ChangeDetectorRef,
    private formbuilder: FormBuilder,
    private _api: ApiServiceService,
  ) { }

  ngOnInit() {
    debugger
    this.sagStudioChangesFiles = this._sagStudioService.currentActiveProject.subDataArray;
    // this.sagStudioChangesFilesData = this.sagStudioChangesFiles.filter(item=>item.fileVisited)
    if (this.sagStudioChangesFiles) {
      this.SagStudioChangesFiles(this.sagStudioChangesFiles)
    }
    else {
      this.SagStudioChangesFiles(this.sagBlankData)
    }

  }

  projectExplorerFiles() {
    debugger
    this.sagStudioCExplorerFilesData = this.shareService.getDataprotool("sagStudioCExplorerFiles",);
    console.log(this.sagStudioCExplorerFilesData)
    if (this.sagStudioCExplorerFilesData) {
      this.sagGridExplorerFiles(this.sagStudioCExplorerFilesData)
    } else {
      this.sagGridExplorerFiles(this.sagBlankData)
    }

  }


  // =====================================api Start ==================================================

  projectSaveJsonData() {
    const checkSelectedArray = this.gridDynamicForSaveFile.sagGridObj.checkedRowIdArray;
    if (checkSelectedArray.length == 0) {
      alerts('Please Select At Least One File..!');
      return;
    }
    else {
      if (checkSelectedArray.length == 0)
        return;

    }
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    const chackSaveJson = this.gridDynamicForSaveFile.getCheckedDataParticularColumnWise();
    const ProjectDataJsonId = this.shareService.getDataprotool("selectedProjectChooseData");
    console.log(ProjectDataJsonId);
    let forkJoinArray = [];
    this.shareService.loading++;
    chackSaveJson.forEach(elem => {
      if (elem.matchableId) {
        const postData = {
          projectId: ProjectDataJsonId.projectname,
          fileId: elem.matchableId,
          userId: userId,
          fileJson: JSON.stringify(elem)
        }
        forkJoinArray.push(this.shareService.saveJsonData(postData));
      }
    });
    forkJoin(forkJoinArray).subscribe((res) => {
      let resStatusArr = res.filter(itm => itm.status == 200);
      if (res.length == resStatusArr.length) {
        this.shareService.loading--;
        success('Files Saved Successfully :):)');
      }
      else {
        this.shareService.loading--;
        alerts('Something Went Wrong :(:(')
      }
    });
  }

  async projectExplorerFilesData() {
    debugger
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    const ExplorerchackSaveJson = this.shareService.getDataprotool("ExplorerFilesSagStudioData");
    const ProjectDataJsonId = this.shareService.getDataprotool("selectedProjectChooseData");
    console.log(ProjectDataJsonId);

    const proExpl = (arr) => {
      arr.forEach(itm => {
        itm.parent = {};
        if (itm.children.length > 0) {
          proExpl(itm.children)
        }
      })
    }

    const explorVal = this._sagStudioService.sagWorkSpace.projectExplorerTree[0].children.map(item => {
      item['parent'] = [];
      if (item.children.length > 0) {
        proExpl(item.children)
      }
      return item
    }
    );
    console.log('explorVal--', explorVal);
    let forkJoinArray = [];
    ExplorerchackSaveJson.forEach(elem => {
      const postData = {
        projectId: ProjectDataJsonId.projectname,
        fileId: ProjectDataJsonId.projectname,
        userId: userId,
        fileJson: JSON.stringify(explorVal)
      }
      forkJoinArray.push(this.shareService.saveJsonData(postData));
    });
    forkJoin(forkJoinArray).subscribe((res) => {
      success('saved successfully !!!');
    });


  }


  showGridData(event) {
    switch (event.target.value) {
      case "totelData":
        this.sagStudioChangesFiles = this._sagStudioService.currentActiveProject.subDataArray;
        this.SagStudioChangesFiles(this.sagStudioChangesFiles)
        break;
      case "changesData":
        this.sagStudioChangesFilesData = this.sagStudioChangesFiles.filter(item => item.fileVisited)
        this.SagStudioChangesFiles(this.sagStudioChangesFilesData)
        break;
      default:
        break;
    }

  }
  recursiveFun(data: any, label: string) {
    debugger
    let self = this;
    data.forEach((element) => {
      if (element.length > 0) {
        element['label'] = label;
        element['nativePath'] = label;
        element['projectPath'] = label;
        self.recursiveFun(element, label);
      } else {
        element['label'] = label;
        element['nativePath'] = label;
        element['projectPath'] = label;
        return element;
      }
    });
    return data;
  }

  saveInLocalClick(newPath, blob) {
    const checkSelectedArray = this.gridDynamicForSaveFile.sagGridObj.checkedRowIdArray;
    if (checkSelectedArray.length == 0) {
      alerts('Please Select At Least One File..!');
      return;
    }
    else {
      if (checkSelectedArray.length == 0)
        return;

    }
    const chackSaveJson = this.gridDynamicForSaveFile.getCheckedDataParticularColumnWise();
    const ProjectDataJsonId = this.shareService.getDataprotool("selectedProjectChooseData");
    chackSaveJson.forEach(elem => {
      if (elem.matchableId) {
        const newPath = `${ProjectDataJsonId.awspace}/studioJson/filejson/${elem.matchableId}.json`;
        const blob = new Blob([JSON.stringify(elem, null, 4)], { type: "	application/json" });
        this.writeFile(newPath, blob);
      }
    });
  };

  writeFile(newPath, blob) {
    const writeFileOnServerData = new FormData();
    writeFileOnServerData.append('flag', 'true');
    writeFileOnServerData.append('path', newPath);
    writeFileOnServerData.append('file', blob);
    this._api.writeFileOnserver(writeFileOnServerData)
      .subscribe(res => {
        success('save LocalFiles successfully !!!');
      });
  }




 

  SagStudioChangesFiles(rowsData) {
    var sourceDiv = document.getElementById("SagStudioChangesFiles");
    var columns = [
      {
        "field": "fileVisited",
        "filter": false,
        "editable": false,
        "sagGridResize": false,
        "width": "50px",
        "header": "All",
        "text-align": "center",
        "colType": "checkBox",
        // "cellRenderView":"checkBox"
      },
      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "type",
        field: "type",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "left",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "subType",
        field: "subtype",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "left",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "matchableId",
        field: "matchableId",
        filter: true,
        width: "320px",
        "editable": false,
        "text-align": "left",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "document",
        field: "document",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": "selectInput",
      },
      {
        header: "Help",
        field: "help",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": "selectInput",
      },




    ];
    let self = this;
    let dropDownValue = [
      { "key": null, "val": "--Select--" },
      { "key": 1, "val": "YES" },
      { "key": 0, "val": "NO" }
    ];
    //  let dropDownValue: any = [{ key: "--", "val": "--" }]; 
    let selectInputObj = new SagSelectBox(dropDownValue, function (ele, params) { });
    let components = {
      "selectInput": selectInputObj,
      "checkBox": new SagCheckBox({}, function () {
      }),
      "headerCheckBox1": new headerCheckBox({}, function () {
      }),
    };



    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.onRowSelSaveFiles(event);
          },
          "onRowDbleClick": function () {
            self.onRowDblClickSaveFiles(event);
          }
        }
      };
      this.gridDynamicForSaveFile = SagGridMPT(sourceDiv, gridData, true, true);
      return this.gridDynamicForSaveFile;

    }


  }

  onRowSelSaveFiles(event: Event) {
    let SelectedRowObj = this.gridDynamicForSaveFile.getCheckedDataParticularColumnWise();
    this.shareService.setDataprotool("SaveSagStudioFilesData", SelectedRowObj);
    console.log(SelectedRowObj)
  }
  onRowDblClickSaveFiles(event: Event) {

    let SelectedRowObj = this.gridDynamicForSaveFile.getCheckedDataParticularColumnWise();
    this.shareService.setDataprotool("SaveSagStudioFilesData", SelectedRowObj);

  }


  sagGridExplorerFiles(rowsData) {
    var sourceDiv = document.getElementById("sagGridExplorerFilesId");
    var columns = [
      {
        "field": "fileVisited",
        "filter": false,
        "editable": false,
        "sagGridResize": false,
        "width": "50px",
        "header": "All",
        "text-align": "center",
        "colType": "checkBox"
      },
      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "label",
        field: "label",
        filter: true,
        width: "180px",
        "editable": false,
        "text-align": "left",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "matchableId",
        field: "matchableId",
        filter: true,
        width: "220px",
        "editable": false,
        "text-align": "left",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "projectSubType",
        field: "projectSubtype",
        filter: true,
        width: "320px",
        "editable": false,
        "text-align": "left",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "document",
        field: "document",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": "selectInput",
      },
      {
        header: "Help",
        field: "help",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": "selectInput",
      },




    ];
    let self = this;
    let dropDownValue = [
      { "key": null, "val": "--Select--" },
      { "key": 1, "val": "YES" },
      { "key": 0, "val": "NO" }
    ];
    //  let dropDownValue: any = [{ key: "--", "val": "--" }]; 
    let selectInputObj = new SagSelectBox(dropDownValue, function (ele, params) { });
    let components = {
      "selectInput": selectInputObj,
      "checkbox1": new SagCheckBox({}, function () {
      }),
      "checkbox2": new SagCheckBox({}, function () {
      }),
      "checkbox3": new SagCheckBox({}, function () {
      }),
      "checkbox4": new SagCheckBox({}, function () {
      }),
      "checkbox5": new SagCheckBox({}, function () {
      }),
      "headerCheckBox1": new headerCheckBox({}, function () {
      }),
      "headerCheckBox2": new headerCheckBox({}, function () {
      }),
      "headerCheckBox3": new headerCheckBox({}, function () {
      }),
      "headerCheckBox4": new headerCheckBox({}, function () {
      }),
      "headerCheckBox5": new headerCheckBox({}, function () {
      }),
    };



    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.onRowSelExplorerFiles(event);
          },
          "onRowDbleClick": function () {
            self.onRowDblClickExplorerFiles(event);
          }
        }
      };
      this.gridDynamicForExplorerFiles = SagGridMPT(sourceDiv, gridData, true, true);
      return this.gridDynamicForSaveFile;

    }


  }
  onRowSelExplorerFiles(event: Event) {
    let SelectedRowObj = this.gridDynamicForExplorerFiles.getCheckedDataParticularColumnWise();
    this.shareService.setDataprotool("ExplorerFilesSagStudioData", SelectedRowObj);
    console.log(SelectedRowObj)
  }
  onRowDblClickExplorerFiles(event: Event) {

    let SelectedRowObj = this.gridDynamicForExplorerFiles.getCheckedDataParticularColumnWise();
    this.shareService.setDataprotool("ExplorerFilesSagStudioData", SelectedRowObj);

  }
}
