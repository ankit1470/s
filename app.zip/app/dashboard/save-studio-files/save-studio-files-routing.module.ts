import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SaveStudioFilesComponent } from './save-studio-files.component';


const routes: Routes = [
  {
    path: "",
    component:SaveStudioFilesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SaveStudioFilesRoutingModule { }
