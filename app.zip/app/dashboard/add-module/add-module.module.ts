import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddModuleRoutingModule } from './add-module-routing.module';
import { AddModuleComponent } from './add-module.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [AddModuleComponent],
  imports: [
    CommonModule,
    AddModuleRoutingModule,
    FormsModule 
  ]
})
export class AddModuleModule { }
