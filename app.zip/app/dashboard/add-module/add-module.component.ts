import { Component, OnInit } from '@angular/core';
import { DialogService, DynamicDialogRef } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { WriteNgFilesService } from 'src/app/services/writeStudio/write-ng-files.service';

@Component({
  selector: 'app-add-module',
  templateUrl: './add-module.component.html',
  styleUrls: ['./add-module.component.scss']
})
export class AddModuleComponent implements OnInit {

  constructor(public _sagStudioService: SagStudioService,
    public StudioDragDropService: CommonStudioDragDropService,
    public dialogService: DialogService,
    public modalRef: DynamicDialogRef,
    public toast : ToastService,
    private _writengfilesService : WriteNgFilesService,) { }
  item: any;
  list: any[];
  databaseModule: any[];


  ngOnInit() {
    this.list = [
      {
        id: 'userCreateId',
        title: 'User Create',
        checked: false,
        type: "userPage", 
        icon: "fa-columns",
        label: "user", 
        customTemplate: "userTemplate", // subDataArray push data uses key
        pageTemplatKey: "userPageKey", // service file create key
        subtype: 'usercreate',
        subDataArray: [],
        customCodeBody: '', 
        elementId: null,
        parentId: null,
        userCreate: {
          ngType: 'addModule', //page
          ngName: 'userCreate',
          ngAuthor: 'Balshankar',
          ngDesc: 'customService',
          parentFolder: 'user'
        }
      },
      {
        id: 'userLoginId',
        title: 'User Login',
        checked: false,
        type: "userPage",
        icon: "fa-columns",
        label: "Login",
        customTemplate: "userTemplate", // subDataArray push data uses key
        pageTemplatKey: "userPageKey", // service file Login key
        subtype: 'userLogin',
        subDataArray: [],
        customCodeBody: '',
        elementId: null,
        parentId: null,
        userCreate: {
          ngType: 'addModule', //page
          ngName: 'userLogin',
          ngAuthor: 'Balshankar',
          ngDesc: 'customService',
          parentFolder: 'user'
        }
      }
    ];

    this.databaseModule = [
      {
        id: 'backupId',
        title: 'Backup',
        checked: false,
        type: "backupdb", 
        icon: "fa-columns",
        label: "Backup", 
        customTemplate: "userTemplate", // subDataArray push data uses key
        pageTemplatKey: "userPageKey", // service file create key
        subtype: 'backupdb',
        subDataArray: [],
        customCodeBody: '', 
        elementId: null,
        parentId: null,
        userCreate: {
          ngType: 'addModule', //page
          ngName: 'backupdb',
          ngAuthor: 'Balshankar',
          ngDesc: 'customService',
          parentFolder: 'database'
        }
      },
      {
        id: 'scheduleBackupId',  
        title: 'Schedule Backup',
        checked: false,
        type: "scheduleBackup",
        icon: "fa-columns",
        label: "Schedule Backup",
        customTemplate: "userTemplate", // subDataArray push data uses key
        pageTemplatKey: "userPageKey", // service file Login key
        subtype: 'scheduleBackup',
        subDataArray: [],
        customCodeBody: '',
        elementId: null,
        parentId: null,
        userCreate: {
          ngType: 'addModule', //page
          ngName: 'scheduleBackup',
          ngAuthor: 'Balshankar',
          ngDesc: 'customService',
          parentFolder: 'database'
        }
      }
    ];
  }

  get result() {
    return this.databaseModule.filter(item => item.checked);
  }
  commonList : any;
  checkObj(item){
    this.commonList = [];
    this.commonList = item;
  }
  selectModule() { 

    this.commonList.forEach(async ele => {
      if (ele.checked == true) {
        //let filenode = this._sagStudioService.sagWorkSpace.projectExplorerTree[0].children[0].children[1].children[0];
        // change custommodules module
        let filenode = this._sagStudioService.sagWorkSpace.projectExplorerTree[0].children[0].children[1].children[0].children.find(ele => ele.label == 'custommodules')
        this.StudioDragDropService.addangularScemeticsProExplr(
          filenode,
          this._sagStudioService.sagWorkSpace.projectExplorerTree,
          ele.customTemplate,
          ele.pageTemplatKey,
          ele.userCreate
        );
        //let wait  = await this._writengfilesService.writeNewGeneratedNodes(this._sagStudioService.writableNewNodes,this._sagStudioService.currentActiveProject,'from');
        this._sagStudioService.resetFileList();
        this._sagStudioService.getFilesList(this._sagStudioService.sagWorkSpace.projectExplorerTree);
      }
      this.toast.launch_toast({
        type : 'success',
        position : 'bottom-right',
        message : 'Project Init Successfully !!!...',
      });
      this.modalRef.close(false);
    });
  }

  close() {
    this.modalRef.close(false);
  }
}
