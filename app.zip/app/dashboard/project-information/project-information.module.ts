import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectInformationRoutingModule } from './project-information-routing.module';
import { ProjectInformationComponent } from './project-information.component';
import { JavaTotalInfoModule } from 'src/app/modules/database/project-utility-tool/procompare-tool/project-type/java-total-info/java-total-info.module';
import { ProjectTotalInfoModule } from 'src/app/modules/database/project-utility-tool/procompare-tool/project-type/project-total-info/project-total-info.module';
import { JavaApiListModule } from 'src/app/modules/sag-studio/property-window/java-api/java-api-list/java-api-list.module';


@NgModule({
  declarations: [ProjectInformationComponent],
  imports: [
    CommonModule,
    ProjectInformationRoutingModule,
    ProjectTotalInfoModule,
    JavaApiListModule,
    JavaTotalInfoModule,
  ], exports: [ProjectInformationComponent]
})
export class ProjectInformationModule { }
