import { Component, OnInit } from '@angular/core';

@Component({
  host: {class:"d-flex flex-column h-100"},
  selector: 'app-project-information',
  templateUrl: './project-information.component.html',
  styleUrls: ['./project-information.component.scss']
})
export class ProjectInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
