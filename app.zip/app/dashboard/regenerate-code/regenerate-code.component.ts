import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef } from 'primeng/primeng';
import { ToastService } from 'src/app/core/services/toast.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { WriteNgFilesService } from 'src/app/services/writeStudio/write-ng-files.service';
declare var SdmtGridT;
@Component({
  selector: 'app-regenerate-code',
  templateUrl: './regenerate-code.component.html',
  styleUrls: ['./regenerate-code.component.scss']
})
export class RegenerateCodeComponent implements OnInit {
  selectedProject: any;
  componentsOptionsData = [];
  listOfFiles: any = [];
  componentFiles:any=[];
  deleteSourceFiles:any=[];
  fetchComponentData:any={}
  constructor(
    public shareService: SagShareService,
    public sagStudioService: SagStudioService,
    public studioDragDropService: CommonStudioDragDropService,
    public procomparetoolService: ProcomparetoolService,
    private _writeNgFile: WriteNgFilesService,
    public modalRef: DynamicDialogRef,
    public toast: ToastService,
  ) {

  }

  ngOnInit() {
    this.selectedProject = this.shareService.getDataprotool("selectedProjectChooseData");
    this.getFileTree();
  }
  getFileTree() {
    if (this.selectedProject) {
      let obj = {
        "projectName": this.selectedProject.projectname,
        "projectId": this.selectedProject.projectId
      }
      this.shareService.getMenuForVoice(obj).subscribe((res) => {
        if (res) {
          this.componentsOptionsData = res['menujson'];
        }
      });
    }
  }


  gridData_filelist: any;
  gridDynamicObj_filelist: any;
  columnData_filelist: any = [
    {
      "header": "",
      "field": "selectedRow",
      "filter": false,
      "width": "30px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "headerCheckBox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "Type",
      "field": "type",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File name",
      "field": "fName",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Source Code",
      "field": "src",
      "filter": true,
      "width": "110px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Compare",
      "field": "compare",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Compare", "classes": ["btn", "btn-info", "w-70"], "attribute": "", "styles": "" },

    },
    {
      "header": "Meta",
      "field": "meta",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Manual/Auto",
      "field": "ismanual",
      "filter": true,
      "width": "140px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    
    {
      "header": "File path",
      "field": "path",
      "filter": true,
      "width": "600px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    }
  ];

  rowData_filelist: any = [
    {},
    {},
    {},
    {}
  ];

  filelist(rowData?, colData?) {
    let self = this;

    this.gridData_filelist = {
      columnDef: colData ? colData : this.columnData_filelist,
      rowDef: rowData ? rowData : this.rowData_filelist,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {
        "onButton_compare": function (ele, params) {
          console.log(params)
          self.onjavaVersionUpdateFileListCompare(params)
        },
        "onCellClick": function (ele) {

          self.onfilelistCellClick();
        },
        "onRowClick": function () {
          self.onfilelistClick();
        },
        "onRowDbleClick": function () {
          self.onfilelistdblClick();
        }
      }
      ,


      rowCustomHeight: 20,




    };

    let sourceDiv = document.getElementById("filelist");
    this.gridDynamicObj_filelist = SdmtGridT(sourceDiv, this.gridData_filelist, true, true);
  }



  async onjavaVersionUpdateFileListCompare(params) {
      let EndpathArray = params.rowValue.path
      let index = EndpathArray.indexOf('src');
      let newEndPath = EndpathArray.slice(index)
      let firstpath = window['editorComponentRef'].editorRef.firstRootStore[1].id
      const fullPath:any = firstpath + '/' + newEndPath
      window['angularComponentRef'].openFileEditor(fullPath);
     const ele: any = document.querySelector('.hide_configureapproval');
     ele.style.display = 'none';

     let fileUriPath = fullPath && fullPath.replaceAll('/', '\\');

     const selectProjectData = this.shareService.getDataprotool("selectedProjectChooseData");
     const projectPath = fileUriPath.substring(fileUriPath.indexOf(selectProjectData.projectname))
     this.shareService.setDataprotool("nodeSelectPath", projectPath);
     window['angularComponentRef'].selectedModulePath = fileUriPath;
     const selNode = await this.studioDragDropService.getExplorerNodeByProjectPath(projectPath.replaceAll('\\', '/'), 'from');
     await this.studioDragDropService.fileShow(selNode, 'customfile');
      // success("Please Merge Your Changes")
       window['angularComponentRef'].editorMethodCompare(true, fullPath)
    }


  onfilelistCellClick() {

  }

  onfilelistClick() {

  }

  onfilelistdblClick() {

  }

  onComponentSelect(event) {
    this.fetchComponentData = {}
    this.fetchComponentData = event;
    let dataRes:any;
    this.componentFiles = [];
    let obj = {
      "projectId" : this.selectedProject.projectId,
      "menudetId" : event.menuid,
      "projectName":this.selectedProject.projectname,
      "projectPath":this.selectedProject.awspace,
  }
    this.shareService.getMenuRelatedFile(obj).subscribe(res=>{
      dataRes = res;
      if(dataRes && dataRes.length > 0){
        for (let index = 0; index < dataRes.length; index++) {
          const element = dataRes[index];
          let obj= element;
          obj["projectName"] = this.selectedProject.projectname;
          obj["path"] = this.selectedProject.awspace + '/' + element.filePath;
          obj["projectPath"] = this.selectedProject.projectname + '/' + element.filePath;
          this.componentFiles.push(obj)
        }
      }
      this.rowData_filelist = this.componentFiles;
      this.filelist();
    })
  }
  
  getComponentFiles(filepath) {
    let getFolderPath = filepath.split('/').splice(0,filepath.split('/').length-1).join('/'); 
    if (this.listOfFiles && this.listOfFiles.length > 0) {
      for (let index = 0; index < this.listOfFiles.length; index++) {
        const file = this.listOfFiles[index];
        if(file.path.includes(getFolderPath)){
          this.componentFiles.push(file)
        }
      }
    }
  }
  closeModal(flag) {
    this.sagStudioService.restrictFileOpen = true;
    this.modalRef.close(flag);
  }
  async saveModified(){
    this.listOfFiles = []
    this.rowData_filelist.forEach(dataRow=>{
      if(dataRow.selectedRow == 1){
        this.listOfFiles.push(dataRow)
      }
    })
    await this._writeNgFile.saveUnSaveMethod(this.listOfFiles); 
    // this.closeModal(true);
    this.onComponentSelect(this.fetchComponentData);
  }
  deleteSource(){
    this.deleteSourceFiles = {
      "files" : []
    }
    this.rowData_filelist.forEach(dataRow=>{
      if(dataRow.selectedRow == 1){

        let obj = {
          "filePath":dataRow.path
        }
        this.deleteSourceFiles["files"].push(obj)
      }
    })
    this.shareService.delFilesToRegenerate(this.deleteSourceFiles).subscribe(res=>{
      this.toast.launch_toast({
        type: 'success',
        position: 'top-right',
        message: 'successfully deleted files  !!!',
      });
      this.onComponentSelect(this.fetchComponentData);
    })
  }
  stringGenerateCode(){
    debugger
  }
  async JSONGenerateCode(){
    debugger
    this.listOfFiles = []
    this.rowData_filelist.forEach(dataRow=>{
      if(dataRow.selectedRow == 1){
        this.listOfFiles.push(dataRow)
      }
    })
    for (let i = 0; i < this.listOfFiles.length; i++){
      const obj = this.listOfFiles[i];
    }
    // await this._writeNgFile.saveUnSaveMethod(this.listOfFiles); 
  }
}
