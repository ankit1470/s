import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegenerateCodeRoutingModule } from './regenerate-code-routing.module';
import { RegenerateCodeComponent } from './regenerate-code.component';
import {TreeModule} from 'primeng/tree';


@NgModule({
  declarations: [RegenerateCodeComponent],
  imports: [
    CommonModule,
    TreeModule,
    RegenerateCodeRoutingModule
  ],
  exports:[RegenerateCodeComponent,]
})
export class RegenerateCodeModule { }
