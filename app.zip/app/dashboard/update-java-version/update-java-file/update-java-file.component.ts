import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-update-java-file',
  templateUrl: './update-java-file.component.html',
  styleUrls: ['./update-java-file.component.scss']
})
export class UpdateJavaFileComponent implements OnInit {
  gridData_UpdateJavaFile: any;
  gridDynamicObj_UpdateJavaFile: any;
  currentPagePathforcompare: any;
  openHtmlFlag: boolean = true;
  modelType: any = "UpdateJavaFileComponent";
  compareToolDisplay: boolean = false;
  constructor(public shareService: SagShareService,
    private ProCompareToolService: ProcomparetoolService,
    private cdRef: ChangeDetectorRef,) {

      
     }

  ngOnInit() {
    
    this.getConvertFileList();
    // this.UpdateJavaFileGrid();
   
  }
  columnData_UpdateJavaFile: any = [
    {
      "header": "S.No",
      "field": "sno",
      "width": "50px",
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "freezecol": "null",
      "text-align": "center"
    },
    // {
    //   "header": "ProjectName",
    //   "field": "projectName",
    //   "filter": false,
    //   "width": "250px",
    //   "editable": "false",
    //   "text-align": "center",
    //   "search": true,
    //   "component": "label",
    //   "cellRenderView": false,
    //   "freezecol": "null",
    //   "hidden": false,
    //   "sort": false,
    //   "cellHover": false
    // },

    {
      "header": "File Name",
      "field": "fileName",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    // {
    //   "header": "File Path",
    //   "field": "filePath",
    //   "filter": true,
    //   "width": "300px",
    //   "editable": "false",
    //   "text-align": "left",
    //   "search": true,
    //   "component": "label",
    //   "cellRenderView": false,
    //   "freezecol": "null",
    //   "hidden": false,
    //   "sort": false,
    //   "cellHover": false,

    // },
    {
      "header": "Qualified Name",
      "field": "classFullyQualifiedName",
      "filter": true,
      "width": "500px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "No. Of Change",
      "field": "noOfChanges",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Update",
      "field": "update",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Update", "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },

    },
  ];
  rowData_UpdateJavaFile: any = [
    {},
    {},
    {},
    {}
  ];

  UpdateJavaFileGrid(rowData?, colData?) {
    let self = this;

    this.gridData_UpdateJavaFile = {
      columnDef: colData ? colData : this.columnData_UpdateJavaFile,
      rowDef: rowData ? rowData : this.rowData_UpdateJavaFile,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {
        "onButton_update": function (ele, params) {
          console.log(params)
          self.currentPagePathforcompare = params.rowValue["filePath"]
          self.upgradeJavaVersionFile(params.rowValue);
        },
        "onCellClick": function (ele) {

          //self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          // self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          // self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("UpdateJavaFileId");
    if (sourceDiv != null) {
      this.gridDynamicObj_UpdateJavaFile = SdmtGridT(sourceDiv, this.gridData_UpdateJavaFile, true, true);
    }
  }

  getConvertFileList() {
    const projectTotalInfoDet = this.shareService.getDataprotool("projectNodeSelect");
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    let parsePath = "";
    if(projectTotalInfoDet){
      parsePath =  projectTotalInfoDet.path;
    }else{
      parsePath = __project_Details.jwspace;
    }
    let postObj = {
      "projectId": __project_Details.projectId,
      "projectPath": __project_Details.jwspace,
      "parsePath":parsePath,
      "userId": __project_Details.userId
    };

    this.ProCompareToolService.getJavaVersionConvertFileList(postObj).subscribe((res) => {
      if (res["status"] == 200) {
        this.UpdateJavaFileGrid(res["data"]);
      } else {
        this.UpdateJavaFileGrid();
      }
    }, error => {
      alerts("Error While Fetching");
    })
  }

  upgradeJavaVersionFile(rowData) {
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    let postObj = {
      "projectId": __project_Details.projectId,
      "projectPath": __project_Details.jwspace,
      "parsePath": __project_Details.jwspace,
      "filePath": rowData.filePath,
      "userId": __project_Details.userId
    };

    this.ProCompareToolService.upgradeJavaVersionFile(postObj).subscribe((res) => {
      if (res["status"] == 200) {
        //success(res["msg"]);
        this.getConvertFileList();
        this.onjavaVersionUpdateFileCompare(res,rowData.filePath);
      }
      else if (res["status"] == 500) {
        alerts(res["msg"]);
      }
    })
  }


  onjavaVersionUpdateFileCompare(resData,filePath) {
     this.shareService.setDataprotool("rightSideCode", resData.changedFileContent);
     this.shareService.setDataprotool("leftSideCode", resData.currentFileContent);

    this.shareService.setDataprotool("filePathEditorDiff", {
      path: filePath,
      projectpath: undefined
    });
    this.openHtmlFlag = false;
    this.compareToolDisplay = true;
    this.cdRef.detectChanges();
    this.compareToolDisplay ? $("#VscodecompareToolforJavaUpdate").modal('show') : false;
  }
}
