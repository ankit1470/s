import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UpdateJavaFileRoutingModule } from './update-java-file-routing.module';
import { UpdateJavaFileComponent } from './update-java-file.component';
import { EditorDiffChangeModule } from 'src/app/modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-diff-change/editor-diff-change.module';


@NgModule({
  declarations: [UpdateJavaFileComponent],
  imports: [
    CommonModule,
    UpdateJavaFileRoutingModule,
    EditorDiffChangeModule
  ],
  exports:[UpdateJavaFileComponent]
})
export class UpdateJavaFileModule { }
