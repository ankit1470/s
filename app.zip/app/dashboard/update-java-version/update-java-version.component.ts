import { Component, OnInit } from '@angular/core';
import { DialogService} from "primeng/api";
import { UpdateJavaFileComponent } from './update-java-file/update-java-file.component';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { JavaApiRegenerateComponent } from './java-api-regenerate/java-api-regenerate.component';
declare function alerts(m): any;
declare function success(m): any;
declare var ui;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-update-java-version',
  templateUrl: './update-java-version.component.html',
  styleUrls: ['./update-java-version.component.scss'],
})
export class UpdateJavaVersionComponent implements OnInit {
proTechList:any;
isUpgradeVersion:boolean = false;
projectName:any = "";
  constructor(public dialogService: DialogService,
              public shareService: SagShareService,
              private ProCompareToolService: ProcomparetoolService,
  ) { }

  ngOnInit() {
    this.getProjectTechnology();
  }
  
  updateJavaVersionFile() {
    const ref = this.dialogService.open(UpdateJavaFileComponent, {
      header: "Update Java Version file",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model User_Wise_working hide_javaVersionUpdate",
    });
    ref.onClose.subscribe((res) => {
      //ref.close();
      console.log("Close Tab")
    });
  }

  getProjectTechnology(){
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    const Project_Id = __project_Details.projectId
    this.projectName = __project_Details.projectname;

    this.ProCompareToolService.getProjectTechnology(Project_Id).subscribe((res)=>{
      console.log(res)
      if(res["status"] == 200){
        this.proTechList = res["data"];
        this.isUpgradeVersion = res["isUpgradeVersion"];
      }
    },error =>{
      alerts("Error While Fetching");
    })
  }

  async changeConfiguration(){

    let conf = await ui.confirm("Are you sure you want to change the configuration?");

    if (conf == true) {
      const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    let postObj ={
      "projectId": __project_Details.projectId,
      "projectPath": __project_Details.jwspace,
      "userId": __project_Details.userId
    };
    
    this.ProCompareToolService.changeJavaVersionConfi(postObj).subscribe((res)=>{
      if(res["status"] == 200){
        this.getProjectTechnology();
        success(res["msg"]);
      }
      else if(res["status"] == 500){
        alerts(res["msg"]);
      }
    },error =>{
      alerts("Error While Fetching");
    })

    }


    
  }

  javaApiRegenerate(){
    const ref = this.dialogService.open(JavaApiRegenerateComponent, {
      header: "Java Api Regenerate",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model User_Wise_working new_javaVersionUpdate",
    });
    ref.onClose.subscribe((res) => {
      //ref.close();
      console.log("Close Tab")
    });
  }
}
