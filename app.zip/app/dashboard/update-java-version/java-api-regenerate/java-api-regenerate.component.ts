import { Component, OnInit } from '@angular/core';
import { error } from 'console';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-java-api-regenerate',
  templateUrl: './java-api-regenerate.component.html',
  styleUrls: ['./java-api-regenerate.component.scss']
})
export class JavaApiRegenerateComponent implements OnInit {
  gridDynamicObj_JavaApiRegenerate: any;
  gridData_JavaApiRegenerate: any;
  gridDynamicObj_ApiRegenerateCompare:any;
  gridData_ApiRegenerateCompare:any;
  currentPagePathforcompare:string ="";
  statusCheck:any;
  reletedMsg:string ="";
  gridData_unSelectedReletedApi:any;
  gridDynamicObj_unSelectedReletedApi:any;
  constructor(public shareService: SagShareService,
    private ProCompareToolService: ProcomparetoolService,
    public dbcomparetoolService : DbcomparetoolService
  ) { 
 
  }

  ngOnInit() {
    //this.javaApiRegenerateGrid();
    this.getJavaApiListForRegenerate();
    //document.querySelector('.ui-dialog-content').classList.add('d-flex flex-column h-100');
    this.dbcomparetoolService.javaApiRegenerateStatus.subscribe((res)=>{
      console.log(res);
      if(res == true){
        let index = this.statusCheck["sag_G_Index"];
        this.gridDynamicObj_ApiRegenerateCompare.updateCell(index, "status",'Complete');
        this.gridDynamicObj_ApiRegenerateCompare.setColRowProperty(index, 'status', { "color": "#2ff702" });
      }    
    })
  }
 
  columnData_JavaApiRegenerate: any = [
    {
      "header": "S.No",
      "field": "sno",
      "width": "50px",
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "freezecol": "null",
      "text-align": "center"
    },
    {
      "hidden": false,
      "search": false,
      "cellHover": false,
      "text-align": "center",
      "editable": "false",
      "sort": false,
      "filter": false,
      "component": "headerCheckBox",
      "field": "checkbox",
      "freezecol": "null",
      "width": "100px",
      "header": "",
      "cellRenderView": true,

    },
   
    {
      "header": "Api Name",
      "field": "apiNameWithRoot",
      "filter": true,
      "width": "500px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Api Type",
      "field": "apiType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },

  ];
  rowData_JavaApiRegenerate: any = [
    {},
    {},
    {},
    {}
  ];

  javaApiRegenerateGrid(rowData?, colData?) {
    let self = this;

    this.gridData_JavaApiRegenerate = {
      columnDef: colData ? colData : this.columnData_JavaApiRegenerate,
      rowDef: rowData ? rowData : this.rowData_JavaApiRegenerate,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          //self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          // self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          // self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("javaApiRegenerateGridId");
    if (sourceDiv != null) {
      this.gridDynamicObj_JavaApiRegenerate = SdmtGridT(sourceDiv, this.gridData_JavaApiRegenerate, true, true);
    }
  }
  getJavaApiListForRegenerate() {
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    let postObj = {
      "projectId": __project_Details.projectId,
      "projectPath": __project_Details.jwspace,
      "userId": __project_Details.userId

    };
    this.ProCompareToolService.getJavaApiListForRegenerate(postObj).subscribe((res)=>{
      if(res["status"] == 200){
        this.javaApiRegenerateGrid(res["data"]);
      }else{
        this.javaApiRegenerateGrid();
      }
    },error =>{alerts("Error While Fetching")});
  }

  regenerateJavaApi(){
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    let List = this.gridDynamicObj_JavaApiRegenerate.getCheckedDataParticularColumnWise();
    let apiList = List.filter((ele) =>{
      return ele["checkbox"] == 1;
    });
    let srcDataSource = null;
    let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
    if(dataForConnection && dataForConnection.srcDataSource){
      srcDataSource = dataForConnection.srcDataSource;
    }
    let postObj = {
      "projectId": __project_Details.projectId,
      "projectPath": __project_Details.jwspace,
      "userId": __project_Details.userId,
      "isModifyApi":true,
      "apiList": apiList,
      "databaseConfig":srcDataSource

    };
    this.ProCompareToolService.regenerateJavaApiCode(postObj).subscribe((res)=>{
      if(res["status"] == 200){
        console.log(res);
        success(res["msg"]);
        if(res["generatedFileList"].length > 0){
          this.javaApiRegenerateCompareGrid(res["generatedFileList"].map(ele=>{
            let obj = ele;
            obj["status"] = "Pending";
            return obj;
          }));
        }else{
          this.javaApiRegenerateCompareGrid(res["generatedFileList"]);
        }
        
      }else if(res["status"] == 400){
        this.reletedMsg = res["msg"];
        $("#unSelectedReletedFileId").modal("show");
        this.unSelectedReletedApiGrid(res["data"]);
      }
      else if(res["status"] == 500){
        alerts(res["msg"]);
      }
    });
  }
  columnData_ApiRegenerateCompare: any = [
    {
      "header": "S.No",
      "field": "sno",
      "width": "50px",
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "freezecol": "null",
      "text-align": "center"
    },
    
    {
      "header": "File Name",
      "field": "srcfileName",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File Path",
      "field": "srcfileUniqeName",
      "filter": true,
      "width": "450px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Type",
      "field": "autoManualType",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Status",
      "field": "status",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Compare",
      "field": "compare",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Compare", "classes": ["btn", "btn-info", "w-70"], "attribute": "", "styles": "" },

    },

  ];
  rowData_ApiRegenerateCompare: any = [
    {},
    {},
    {},
    {}
  ];

  javaApiRegenerateCompareGrid(rowData?, colData?) {
    let self = this;

    this.gridData_ApiRegenerateCompare = {
      columnDef: colData ? colData : this.columnData_ApiRegenerateCompare,
      rowDef: rowData ? rowData : this.rowData_ApiRegenerateCompare,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {
        "onButton_compare": function (ele, params) {
          console.log(params)
           self.currentPagePathforcompare = params.rowValue["filePath"];
           self.statusCheck = params.rowValue;
           self.onjavaVersionUpdateFileListCompare();
        },
        "onCellClick": function (ele) {

          //self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          // self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          // self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("ApiRegenerateCompareGridId");
    if (sourceDiv != null) {
      this.gridDynamicObj_ApiRegenerateCompare = SdmtGridT(sourceDiv, this.gridData_ApiRegenerateCompare, true, true);
      self.setColorOnGrid();
      return this.gridDynamicObj_ApiRegenerateCompare;

    }
  }
  setColorOnGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicObj_ApiRegenerateCompare.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      if (ele.status) {
        self.gridDynamicObj_ApiRegenerateCompare.setColRowProperty(index, 'status', { "color": "#fa0505" });
      }

      ;
    });

  }
  onjavaVersionUpdateFileListCompare() {
    if ( this.currentPagePathforcompare) {
      let EndpathArray = this.currentPagePathforcompare.split('\\')
      let index = EndpathArray.indexOf('src');
      let newEndPath = EndpathArray.slice(index).join('/')
      let firstpath = window['editorComponentRef'].editorRef.firstRootStore[0].id
      const fullPath = firstpath + '/' + newEndPath
      window['angularComponentRef'].openFileEditor(fullPath);
     const ele: any = document.querySelector('.hide_configureapproval');
     ele.style.display = 'none';
     const JavaApiRege: any = document.querySelector('.new_javaVersionUpdate ');
     JavaApiRege.style.display = 'none';
       window['angularComponentRef'].editorMethodCompare(true, fullPath)
    }
    else (
      alerts("Please Select a File")
    )
  }


  columnData_unSelectedReletedApi: any = [
    {
      "header": "S.No",
      "field": "sno",
      "width": "50px",
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "freezecol": "null",
      "text-align": "center"
    },
    
    {
      "header": "Api Name",
      "field": "apiName",
      "filter": true,
      "width": "500px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Api Type",
      "field": "apiType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },

  ];
  rowData_unSelectedReletedApi: any = [
    {},
    {},
    {},
    {}
  ];

  unSelectedReletedApiGrid(rowData?, colData?) {
    let self = this;

    this.gridData_unSelectedReletedApi = {
      columnDef: colData ? colData : this.columnData_unSelectedReletedApi,
      rowDef: rowData ? rowData : this.rowData_unSelectedReletedApi,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          //self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          // self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          // self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("unSelectedReletedApiGridId");
    if (sourceDiv != null) {
      this.gridDynamicObj_unSelectedReletedApi = SdmtGridT(sourceDiv, this.gridData_unSelectedReletedApi, true, true);
    }
  }
  
}
