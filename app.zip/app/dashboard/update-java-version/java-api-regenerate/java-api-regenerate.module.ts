import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JavaApiRegenerateRoutingModule } from './java-api-regenerate-routing.module';
import { JavaApiRegenerateComponent } from './java-api-regenerate.component';


@NgModule({
  declarations: [JavaApiRegenerateComponent],
  imports: [
    CommonModule,
    JavaApiRegenerateRoutingModule
  ],
  exports:[JavaApiRegenerateComponent]
})
export class JavaApiRegenerateModule { }
