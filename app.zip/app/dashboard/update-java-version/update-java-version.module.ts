import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpdateJavaVersionRoutingModule } from './update-java-version-routing.module';
import { UpdateJavaVersionComponent } from './update-java-version.component';
import { UpdateJavaFileModule } from './update-java-file/update-java-file.module';
import { JavaApiRegenerateModule } from './java-api-regenerate/java-api-regenerate.module';




@NgModule({
 
  declarations: [UpdateJavaVersionComponent],
  
  imports: [
    CommonModule,
    UpdateJavaVersionRoutingModule,
    UpdateJavaFileModule,
    JavaApiRegenerateModule
  ],
  
  exports:[UpdateJavaVersionComponent],
  
})
export class UpdateJavaVersionModule { }
