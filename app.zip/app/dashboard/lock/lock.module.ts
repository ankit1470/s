import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LockRoutingModule } from './lock-routing.module';
import { LockComponent } from './lock.component';
import { TreeModule } from 'primeng/tree';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [LockComponent],
  imports: [
    CommonModule,
    LockRoutingModule,
    TreeModule,
    FormsModule
  ],
  exports : [LockComponent]
})
export class LockModule { }
