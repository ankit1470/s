import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GenerateApkRoutingModule } from './generate-apk-routing.module';
import { GenerateApkComponent } from './generate-apk.component';


@NgModule({
  declarations: [GenerateApkComponent],
  imports: [
    CommonModule,
    GenerateApkRoutingModule
  ],
  exports:[GenerateApkComponent]
})
export class GenerateApkModule { }
