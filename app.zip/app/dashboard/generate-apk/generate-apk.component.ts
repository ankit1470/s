import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generate-apk',
  templateUrl: './generate-apk.component.html',
  styleUrls: ['./generate-apk.component.scss']
})
export class GenerateApkComponent implements OnInit {

  progressData ={
    width : 0,
    content : ''
  }
  constructor() { }

  ngOnInit() {
  }

  onBuildApk(){
    this.progressData.width = 0;
    this.progressFn();
  }

  progressFn(){
    if(this.progressData.width == 100){ 
     this.progressData.content = 'Apk Generated Successfully !!!';
    }else {
      setTimeout(() => {
        this.progressData.content = `Building Modules....${this.progressData.width}%`;
        this.progressData.width++;
        this.progressFn();
      }, 100);
    }
  }

}
