import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegexGeneratorRoutingModule } from './regex-generator-routing.module';
import { RegexGeneratorComponent } from './regex-generator.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiSelectModule } from 'primeng/multiselect';
import { DropdownModule } from 'primeng/dropdown';


@NgModule({
  declarations: [RegexGeneratorComponent],
  imports: [
    CommonModule,
    RegexGeneratorRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MultiSelectModule,
    DropdownModule
    
  ],
  exports : [RegexGeneratorComponent]
})
export class RegexGeneratorModule { }
