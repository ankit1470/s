import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import  toRegexRange  from 'to-regex-range';
declare var $: any;
@Component({
  selector: 'app-regex-generator',
  templateUrl: './regex-generator.component.html',
  styleUrls: ['./regex-generator.component.scss']
})
export class RegexGeneratorComponent implements OnInit {

  form: FormGroup;
  regexForm: FormGroup | any;
  passwordForm: FormGroup | any;
  regexString: any
  rangeRegex: any;
  range: any;
  index: any;
  minRange: any
  maxRange: any
  decimal: any
  spsChar: any
  categories: any[] = [
    { label: 'Uppercase', value: 'Uppercase' },
    { label: 'Lowercase', value: 'Lowercase' },
    { label: 'Numbers', value: 'Numbers' },
    { label: 'Special Characters', value: 'Special Characters' },
    { label: 'Nagate (include All Case)', value: 'Nagate' }
  ];
  selectedCategory: string = '';
  availableItems: any[] = [];
  nagatedItems: string[] = [];
  restrictLength: boolean = false;
  minLength: number = 1;
  maxLength: number = 10;
  uppercaseAlphabets: any[] = Array.from('ABCDEFGHIJKLMNOPQRSTUVWXYZ').map(char => ({ label: char, value: char }));
  lowercaseAlphabets: any[] = Array.from('abcdefghijklmnopqrstuvwxyz').map(char => ({ label: char, value: char }));
  numbers: any[] = Array.from('0123456789').map(char => ({ label: char, value: char }));
  specialCharacter: any[] = Array.from('!@#$%^&*()_=+{}|;:,.<>?-').map(char => ({ label: char, value: char }));
  regexNegate: any
  regex: string = '';
  testString: string = '';
  paragraph: string = '';
  result: string | null = null;
  minWords: number = 1; 
  maxWords: number | null = null;
  options:any = {
    upperCase: false,
    lowerCase: false,
    specialChar: false,
    numbers: false,
    continuous: false,
    length: 0
  };
  charSet: string | null = null;
  allCharSet: string = '';
  error: string = '';
  validationResult: string | null = null; 
  rangeMin: number | null = 1; 
  rangeMax: number | null = 9; 
  rangeMinInvalid: boolean = false; 
  rangeMaxInvalid: boolean = false;
  continuous: boolean = false;
  timeFormats = ['12-hour', '24-hour'];
  includeSecondsOptions = ['Yes', 'No']; 
  selectedTimeFormat = '24-hour'; 
  includeSeconds = 'Yes';
  specialCharacters: any[] = [
    { label: '!', value: '!' },
    { label: '@', value: '@' },
    { label: '#', value: '#' },
    { label: '$', value: '$' },
    { label: '%', value: '%' },
    { label: '^', value: '^' },
    { label: '&', value: '&' },
    { label: '*', value: '*' },
    { label: '(', value: '(' },
    { label: ')', value: ')' },
    { label: '-', value: '-' },
    { label: '_', value: '_' },
    { label: '=', value: '=' },
    { label: '+', value: '+' },
    { label: '[', value: '[' },
    { label: ']', value: ']' },
    { label: '{', value: '{' },
    { label: '}', value: '}' },
    { label: '|', value: '|' },
    { label: '\\', value: '\\' },
    { label: ';', value: ';' },
    { label: ':', value: ':' },
    { label: "'", value: "'" },
    { label: '"', value: '"' },
    { label: ',', value: ',' },
    { label: '.', value: '.' },
    { label: '/', value: '/' },
    { label: '<', value: '<' },
    { label: '>', value: '>' },
    { label: '?', value: '?' },
    { label: '`', value: '`' },
    { label: '~', value: '~' }
  ];

  regexData = [
    { "label": "Character Set", "regex": "[ABC]" },
    { "label": "Match Any", "regex": "[\\s\\S]" },
    { "label": "Hexadecimal Escape", "regex": "\\xFF" },
    { "label": "Negated Set", "regex": "[^ABC]" },
    { "label": "Range", "regex": "[A-Z]" },
    { "label": "A char in the range: a-z or A-Z ", "regex": "[a-zA-Z]" },
    { "label": "A char in the range: a-z or A-Z or 0-9 ", "regex": "[A-Za-z0-9]" },
    { "label": "A char in the range: a-z or A-Z or 0-9 or any Special char (Only one charactor) ", "regex": "[A-Za-z0-9\\W_]{1}" },
    { "label": "A char Set in the range: a-z or A-Z or 0-9 or any Special char", "regex": "[A-Za-z0-9\\W_]+" },
    { "label": "A 5 char Set in the range: a-z or A-Z or 0-9 or any Special char", "regex": "[A-Za-z0-9\\W_]{5}" },
    { "label": "Number Range", "regex": "rangeGenerate" },
    { "label": "Password", "regex": "generatePass" },
    { "label": "Negation", "regex": "generateNegation" },
    { "label": "paragraph", "regex": "generateparagraph" },
    { "label": "Generate Char Set", "regex": "generateCharSet" },
    { "label": "Generate Custom All Char Set", "regex": "generateSplCharSet" },
    { "label": "Generate Number Set", "regex": "generateNumberSet" },
    { "label": "Generate Time Format", "regex": "generateTimeFormat" },
    { "label": "Dot", "regex": "[.]" },
    { "label": "Word", "regex": "\\w" },
    { "label": "Not Word", "regex": "\\W" },
    { "label": "Digit", "regex": "\\d" },
    { "label": "Not Digit", "regex": "\\D" },
    { "label": "Whitespace", "regex": "\\s" },
    { "label": "Unicode Category  ******************", "regex": "\\p{L}" },
    { "label": "Not Unicode Category  ******************", "regex": "\\P{L}" },
    { "label": "Unicode Script  ******************", "regex": "\\p{Han}" },
    { "label": "Not Unicode Script  ******************", "regex": "\\P{Han}" },
    { "label": "Reserved Characters  ******************", "regex": "\\+" },
    { "label": "Hexadecimal Escape  ******************", "regex": "\\xFF" },
    { "label": "Unicode Escape  ******************", "regex": "\\uFFFF" },
    { "label": "Extended Unicode Escape  ******************", "regex": "\\u{FFFF}" },
    { "label": "Control Character Escape  ******************", "regex": "\\cI" },
    { "label": "Tab", "regex": "\\t" },
    { "label": "Line Feed  ******************", "regex": "\\n" },
    { "label": "Vertical Tab  ******************", "regex": "\\v" },
    { "label": "Form Feed  ******************", "regex": "\\f" },
    { "label": "Carriage Return  ******************", "regex": "\\r" },
    { "label": "Capturing Group  ******************", "regex": "(ABC)" },
    { "label": "Named Capturing Group  ******************", "regex": "(?<name>ABC)" },
    { "label": "Positive Lookahead   ******************", "regex": "(?=ABC)" },
    { "label": "Negative Lookahead   ******************", "regex": "(?!ABC)" },
    { "label": "Positive Lookbehind   ******************", "regex": "(?<=ABC)" },
    { "label": "Negative Lookbehind  ******************", "regex": "(?<!ABC)" },
    { "label": "All Special Char Except @#$", "regex": "[^\\w\\s@#$]" },
    { "label": "All Special Char", "regex": "[^A-Za-z0-9]" }
  ];

  constructor(
    public _toast: ToastService,
    public activeRoute: ActivatedRoute,
    private fb: FormBuilder
  ) { }

  ngOnInit() {
    this.form = this.fb.group({
      testString: ['', Validators.required],
      Regex: ['', Validators.required]
    });

    this.regexForm = this.fb.group({
      strCount: '',
      quantities: this.fb.array([]),
    });

    this.passwordForm = this.fb.group({
      uppercase: ['false'],
      lowercase: ['false'],
      numbers: ['false'],
      includeSpecialChar: ['false'],
      excludeSpecialChar: [[]],
      atLeastOneUppercase: [Number],
      atLeastOneLowercase: [false],
      atLeastOneSpecialChar: [false],
      minLength: [8, [Validators.min(1)]],
      maxLength: [16, [Validators.min(1)]]
    });
  }

  quantities(): FormArray {
    return this.regexForm.get("quantities") as FormArray
  }

  newQuantity(ind:any): FormGroup {
    return this.fb.group({
      regexString: '',
      regexType: ''
    })
  }

  addQuantity() {
    this.quantities().clear();
    let strCount = this.regexForm.get("strCount").value;
    if (strCount) {
      for (let i = 0; i < strCount; i++) {
        this.quantities().push(this.newQuantity(i));
      }
    }
  }

  removeQuantity(i: number) {
    this.quantities().removeAt(i);
  }

  onSubmit() {
    this.regexString = '';
    this.regexForm.value.quantities.forEach((res) => {
      this.regexString += res.regexString;
    });
    this.regexString = `^(${this.regexString})$`
  }

resultedOptionInd:any
  selectedRegex(event: Event, index: number): void {
    const selectedValue = (event.target as HTMLSelectElement).value;
    const quantities = this.regexForm.get('quantities') as FormArray;
    quantities.at(index).get('regexType').setValue(selectedValue);
    // console.log("event :",selectedValue, "index :",index);
    this.index = index
    let ind = this.regexData.findIndex((m) => m.regex == selectedValue);
    this.resultedOptionInd = index
    if (selectedValue == 'rangeGenerate') {
      $('#rangeGenerate').modal('toggle');
    } else if (selectedValue == 'generatePass') {
      $('#generatePass').modal('toggle');
    } else if (selectedValue == 'generateNegation') {
      $('#generateNegation').modal('toggle');
    } else if (selectedValue == 'generateparagraph') {
      $('#generateparagraph').modal('toggle');
    } else if (selectedValue == 'generateCharSet') {
      $('#generateCharSet').modal('toggle');
    } else if (selectedValue == 'generateSplCharSet') {
      $('#generateSplCharSet').modal('toggle');
    } else if (selectedValue == 'generateNumberSet') {
      $('#generateNumberSet').modal('toggle');
    } else if (selectedValue == 'generateTimeFormat') {
      $('#generateTimeFormat').modal('toggle');
    } else {
      this.quantities().value[index].regexString = selectedValue;
    }
    
  }
  


  rangeRegexFun() {
    this.rangeRegex = ''
    if (this.minRange >= 0 && this.maxRange > 0) {
      if (this.minRange >= 0 && this.maxRange > 0 && this.decimal) {
        this.rangeRegex = toRegexRange(this.minRange, this.maxRange);
        this.rangeRegex = this.rangeRegex.split("|");
        let str = ''
        for (let i = 0; i < this.rangeRegex.length; i++) {
          if (i == this.rangeRegex.length - 1) {
            let strEnd;
            strEnd = this.rangeRegex[i].split(")");
            str += `${strEnd[0]}(\\.0+)?)`;
          } else {
            str += `${this.rangeRegex[i]}(\\.\\d+)?|`;
          }
        }
        this.minRange = '';
        this.maxRange = '';
        this.decimal = '';
        this.rangeRegex = `${str}`;
      } else if (this.minRange >=0 && this.maxRange>0 && !this.decimal) {
        this.rangeRegex = toRegexRange(this.minRange, this.maxRange);
        this.minRange = ''
        this.maxRange = ''
        this.decimal = ''
      }
    } else if (this.minRange < 0 && this.maxRange >= 0 && this.decimal) {
      this.rangeRegex = toRegexRange(this.minRange, this.maxRange);
      this.rangeRegex = this.rangeRegex.split("|");
      let str = ''
      for (let i = 0; i < this.rangeRegex.length; i++) {
        if (this.rangeRegex[i].charAt(0) === '-' && !(this.rangeRegex[i + 1].charAt(0) === '-')) {
          str += this.negativeRangeStringDecimal(this.rangeRegex[i]);
          str += `(\\.0+)?|`;
        } else if (i == this.rangeRegex.length - 1) {
          let strEnd;
          strEnd = this.endRangeStringDecimal(this.rangeRegex[i]);
          str += `${strEnd}(\\.0+)?)`;
        } else {
          str += `${this.rangeRegex[i]}(\\.\\d+)?|`;
        }
      }
      this.minRange = '';
      this.maxRange = '';
      this.decimal = '';
      this.rangeRegex = `${str}`;
    } else if (this.minRange < 0 && this.maxRange >= 0 && !this.decimal) {
      this.rangeRegex = toRegexRange(this.minRange, this.maxRange);
      this.minRange = ''
      this.maxRange = ''
      this.decimal = ''
    } else if (this.minRange < 0 && this.maxRange <= 0 && !this.decimal) {
      this.rangeRegex = toRegexRange(this.minRange, this.maxRange);
      this.minRange = ''
      this.maxRange = ''
      this.decimal = ''
    } else if (this.minRange < 0 && this.maxRange <= 0 && this.decimal) {
      this.rangeRegex = toRegexRange(this.minRange, this.maxRange);
      this.rangeRegex = this.rangeRegex.split("|");
      let str = ''
      for (let i = 0; i < this.rangeRegex.length; i++) {
        if (i == this.rangeRegex.length - 1) {
          let strEnd;
          strEnd = this.endRangeStringDecimal(this.rangeRegex[i]);
          str += `${strEnd}(\\.0+)?)`;
        } else {
          str += `${this.rangeRegex[i]}(\\.\\d+)?|`;
        }
      }
      this.minRange = '';
      this.maxRange = '';
      this.decimal = '';
      this.rangeRegex = `${str}`;
    }
    
    if(this.rangeRegex){
      this.quantities().value[this.index].regexString = this.rangeRegex
      $('#rangeGenerate').modal('toggle');
      this.index = '';
    } else {
      this._toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Empty Form`,
      });
    }
  }

  negativeRangeStringDecimal(inputString: any) {
    let stringCheck = inputString.split("");
    if (stringCheck[stringCheck.length - 1] == 0) {
      return inputString
    } else {
      return inputString.substring(0, inputString.length - 2) + (JSON.parse(inputString[inputString.length - 2]) - 1) + inputString[inputString.length - 1] + '(\\.\\d+)?|' + inputString.split("[")[0] + JSON.parse(inputString[inputString.length - 2])
    }
  }

  endRangeStringDecimal(inputString: any) {
    let stringCheck = inputString.split("");
    if (stringCheck[stringCheck.length - 2] == 0) {
      return inputString.substring(0, inputString.length - 1);
    } else {
      return inputString.substring(0, inputString.length - 3) + (JSON.parse(inputString[inputString.length - 3]) - 1) + inputString[inputString.length - 2] + '(\\.\\d+)?|' + inputString.split("[")[0] + JSON.parse(inputString[inputString.length - 3])
    }
  }

  generatePasswordRegex() {
    const formValue = this.passwordForm.value;
    let regex = "";
    if (formValue.uppercase === 'true') {
      regex += "A-Z";
    }
    if (formValue.lowercase === 'true') {
      regex += "a-z";
    }
    if (formValue.numbers === 'true') {
      regex += "0-9";
    }
    regex = `[${regex}`;
    if (formValue.includeSpecialChar === 'true') {
      this.spsChar = '[!@#$%^&*(),.?\":{}|<>]';
      this.spsChar = this.spsChar.split('');
      this.spsChar.pop();
      formValue.excludeSpecialChar.forEach((res) => {
        this.spsChar.splice(this.spsChar.indexOf(res.value), 1)
      })
      this.spsChar.splice(0, 1)
      this.spsChar = this.spsChar.join('');
      regex += `${this.spsChar}]`;
    }
    if (formValue.includeSpecialChar === 'false') {
      regex = `${regex}]`;
    }

    if (formValue.atLeastOneUppercase) {
      let regexString = "(?=.*[A-Z]";
      for (let i = 1; i < formValue.atLeastOneLowercase; i++) {
        regexString += ".*[A-Z]";
      }
      regex = `${regexString})${regex}`;
    }

    if (formValue.atLeastOneLowercase) {
      let regexString = "(?=.*[a-z]";
      for (let i = 1; i < formValue.atLeastOneLowercase; i++) {
        regexString += ".*[a-z]";
      }
      regex = `${regexString})${regex}`;
    }

    if (formValue.atLeastOneSpecialChar) {
      let regexString = `(?=.*[${this.spsChar}]`;
      for (let i = 1; i < formValue.atLeastOneLowercase; i++) {
        regexString += `.*[${this.spsChar}]`;
      }
      regex = `${regexString})${regex}`;
    }

    if (!formValue.uppercase && !formValue.lowercase && !formValue.numbers && !formValue.includeSpecialChar) {
      regex = `.${regex}`;
    }

    regex += `{${formValue.minLength},${formValue.maxLength}}`;
    // this.quantities().value[this.index].regexString = regexStr;
    this.rangeRegex = `${regex}`;
  }

 

  onCategoryChange() {
    switch (this.selectedCategory) {
      case 'Uppercase':
        this.availableItems = [...this.uppercaseAlphabets];
        break;
      case 'Lowercase':
        this.availableItems = [...this.lowercaseAlphabets];
        break;
      case 'Numbers':
        this.availableItems = [...this.numbers];
        break;
      case 'Special Characters':
        this.availableItems = [...this.specialCharacter];
        break;
      case 'Nagate':
        this.availableItems = [...this.uppercaseAlphabets, ...this.lowercaseAlphabets, ...this.specialCharacter, ...this.numbers];
        break;
      default:
        this.availableItems = [];
    }
    this.nagatedItems = []; 
  }

  onRestrictLengthChange() {
    if (!this.restrictLength) {
      this.minLength = 0;
      this.maxLength = 0;
    }
  }

  
  generateNagation() {
    let regexStr: any = '';
    switch (this.selectedCategory) {
      case 'Uppercase':  
      case 'Lowercase':
      case 'Numbers':
      case 'Special Characters':
        this.availableItems.map((res) => {
          regexStr += res.value
        });

        regexStr = regexStr.split('');
        this.nagatedItems.forEach((item: any) => {
          regexStr.splice(regexStr.indexOf(item.value), 1);
        });

        if (this.restrictLength) {
          regexStr = `[${regexStr}]{${this.minLength},${this.maxLength}}`
        } else {
          regexStr = `([${regexStr}])+`
        }
        break;

      case 'Nagate':
        this.nagatedItems.forEach((item: any) => {
          regexStr += item.value
        });
        if (this.restrictLength) {
          regexStr = `([^${regexStr}]{${this.minLength},${this.maxLength}})`
        } else {
          regexStr = `([^${regexStr}])+`
        }
        break;
      default:
        this.availableItems = [];
    }
    if(regexStr){
      $('#generateNegation').modal('toggle');
      this.quantities().value[this.index].regexString = regexStr;
    } else {
      this._toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Empty Form`,
      });
    }
  }

  
  testRegex() {
    try {
      const regex = new RegExp(this.regex);
      const match = regex.test(this.testString);
      this.result = match ? 'Match found!' : 'No match found.';
    } catch (e) {
      this.result = 'Invalid regular expression.';
    }
  }

 
  validateParagraph() {
    if(this.maxWords && this.minWords){
      let paraRegex = `^((?:^|\\s+)([^\\s]{${this.minWords},${this.maxWords}})(?=\\s+|$))*$`;
      this.quantities().value[this.index].regexString = paraRegex;
      $('#generateparagraph').modal('toggle');
    } else {
      this._toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Empty Form`,
      });
    }
  }

  
  generateCharSet() {
    const upperCaseChars = 'A-Z';
    const lowerCaseChars = 'a-z';
    const specialChars = '\\W_';
    const numberChars = '0-9';
    let availableChars = '';
    if (this.options.upperCase == 'true') {availableChars += upperCaseChars};
    if (this.options.lowerCase == 'true') {availableChars += lowerCaseChars;}
    if (this.options.specialChar == 'true') {availableChars += specialChars;}
    if (this.options.numbers == 'true') {availableChars += numberChars;}
    if (!availableChars) {
      return this._toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Please select at least one character type.`,
      });
    }
    if (this.options.continuous) {
      this.charSet = `[${availableChars}]+`;
      this.rangeRegex = this.charSet;
    } else if (this.options.length) {
      this.charSet = `[${availableChars}]{${this.options.length}}`;
      this.rangeRegex = this.charSet;
    }
    else {
      this.charSet = `[${availableChars}]`;
      this.rangeRegex = this.charSet;
    }

    if(this.rangeRegex){
      this.quantities().value[this.index].regexString = this.rangeRegex
      $('#generateCharSet').modal('toggle');
      this.charSet = '';
    } else {
      this._toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Empty Form`,
      });
    }
    // this.quantities().value[this.index].regexString = this.rangeRegex;
    // this.charSet = ''
  }

  onContinuousChange() {
    if (this.options.continuous) {
      this.options.length = 0;
    }
  }

  generateSplCharSet() {
    if (this.error === '') {
      if(this.allCharSet){
        this.rangeRegex = `[${this.allCharSet}]`;
        this.quantities().value[this.index].regexString = this.rangeRegex;
        $('#generateSplCharSet').modal('toggle');
      } else {
        this._toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: `Empty Form`,
        });
      }
      
    }
  }

  
  validateRanges() {
    this.rangeMinInvalid = this.rangeMin === null || this.rangeMin < 0 || this.rangeMin > 9;
    this.rangeMaxInvalid = this.rangeMinInvalid ? true : this.rangeMax === null || this.rangeMax < this.rangeMin || this.rangeMax >= 10 || (this.rangeMin !== null && this.rangeMax <= this.rangeMin);
  }
  numberSetMinLength:any
  numberSetMaxLength:any
  generateNumberRegex(){
    if(this.rangeMin >= 0 && this.rangeMax >= 0){
      if(this.continuous){
        this.rangeRegex = `[${this.rangeMin}-${this.rangeMax}]+`;
        this.quantities().value[this.index].regexString = this.rangeRegex;
        $('#generateNumberSet').modal('toggle');
      } else {
        this.rangeRegex = `[${this.rangeMin}-${this.rangeMax}]{${this.numberSetMinLength},${this.numberSetMaxLength}}`;
        this.quantities().value[this.index].regexString = this.rangeRegex;
        $('#generateNumberSet').modal('toggle');
      }
    } else {
      this._toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Empty Form`,
      });
    }
    
  }


  submitTimeFormat(){

    this.rangeRegex = this.getTimeInputPattern();
    if( this.rangeRegex){
      this.quantities().value[this.index].regexString = this.rangeRegex;
      $('#generateTimeFormat').modal('toggle');
    } else {
      this._toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Empty Form`,
      });
    }
  }

  getTimeInputPattern(): string { 
    if (this.selectedTimeFormat === '12-hour') { 
      return this.includeSeconds === 'Yes' ? '(0[1-9]|1[0-2]):[0-5]\\d:[0-5]\\d (AM|PM) *' : '(0[1-9]|1[0-2]):[0-5]\\d (AM|PM) *'; 
    } else { 
      return this.includeSeconds === 'Yes' ? '(?:[01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d *' : '(?:[01]\\d|2[0-3]):[0-5]\\d *'; 
    } 
  }

  defVal
  closeModal(id){
    let newid:any = `#dataDropDown${this.resultedOptionInd}`
    $(newid).val('Select a Regex');
    let index = document.getElementById("dataDropDown");
    // this.defVal = "";
    $(id).modal("hide");
    // const add = this.form.get('address') as FormArray;
    // const add = this.regexForm.get("quantities") as FormArray;
    // for (let i = 0; i < add.value.length; i++) {
    //   const ele = add.value[i];
    //   if (i == this.resultedOptionInd) {
    //     console.log('data found', ele);
    //     ele.regexString = ''
    //     ele.regexType = ''
    //   }
    // }
  }

}