import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormJsonImportViewComponent } from './form-json-import-view.component';
 


const routes: Routes = [
  {
    path : "form-json-import-view",
    component : FormJsonImportViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormJsonImportViewRoutingModule { }
