import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/core/shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AddMethodModule } from 'src/app/modules/sag-studio/add-method/add-method.module';
import { NgGenerateModule } from 'src/app/modules/sag-studio/ng-generate/ng-generate.module';
import { FormJsonImportViewComponent } from './form-json-import-view.component';
import { FormJsonImportViewRoutingModule } from './form-json-import-view-routing.module';



@NgModule({
  declarations: [FormJsonImportViewComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AddMethodModule,
    NgGenerateModule,
    SharedModule,
    FormJsonImportViewRoutingModule
    ],
  exports:[FormJsonImportViewComponent]
})
export class FormJsonImportViewModule { }
