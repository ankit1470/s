import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-import-export-varriable',
  templateUrl: './import-export-varriable.component.html',
  styleUrls: ['./import-export-varriable.component.scss']
})
export class ImportExportVarriableComponent implements OnInit,OnDestroy {

  variableImportExportInfoFormGroup: FormGroup;
  submittedVariableImportExport: boolean = false;

  gridDynamicForVariableMappingInfo: any
  gridDynamicForAddFormLabels: any

  angularFormList = []
  angularFormDropdownList = [{ "key": "", "val": "--Select--" }]

  submittedFileImportExport: boolean = false;

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
     ) { }

  ngOnInit() {
    this.getFormList();
    this.initializeFormGroup();
    if(this.config.data){
      this.variableImportExportInfoFormGroup.patchValue(this.config.data); 
    }

    this.getVariableImpExpModuleList();
  }

  ngOnDestroy() { }

  initializeFormGroup() {
    this.variableImportExportInfoFormGroup = this.formbuilder.group({
      softwareName: [{ value: '', disabled: false }],
      softwareId: [{ value: null, disabled: false }],
      formName: [{ value: '', disabled: false }],
      softwareFormId: [{ value: '', disabled: false }, [Validators.required]],
      moduleName: [{ value: '', disabled: false }],
      subModuleName: [{ value: '', disabled: false }],

    });
  }
 
  closeAddVariableMapping() {
    this.modalRef.close();
    this.ngOnDestroy();
  }



  saveVariableImpExpModule(type) {

    this.saveVariableModule(type);
  }

  saveVariableModule(type) {
    let moduleName = null;
    let parentModuleId = null;
    let obj = this.variableImportExportInfoFormGroup.getRawValue();
    if (type == 'module') {
      moduleName = obj['moduleName'];
      if (!moduleName) {
        alerts("please fill module name");
        return;
      }
    } else {
      let selectedRowData = this.gridDynamicForVariableMappingInfo.getSeletedRowData();
      if (selectedRowData) {
        moduleName = obj['subModuleName'];
        if (!moduleName) {
          alerts("please fill sub module name");
          return;
        }
        parentModuleId = selectedRowData.moduleId;
      } else {
        alerts("please select row");
        return;
      }
    }

    let reqObj = {
      "parentModuleId": parentModuleId,
      "moduleName": moduleName,
      "formId": obj['softwareFormId']
    }

    this.autoJavacodeService.saveVariableImpExpModule(reqObj).subscribe(res => {
      if (res.status == 200) {
        this.getVariableImpExpModuleList();
        this.variableImportExportInfoFormGroup.controls['subModuleName'].setValue('');
      } else {
        alerts(res.msg);
      }
    }, Error => {
      alerts("Error While saving data");
    });
  }



  variableMappingInfoGrid(rowsData) {
    var sourceDiv = document.getElementById("variableMappingInfoGridId");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Module Name",
        "field": "moduleName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      {
        "header": "Form Name",
        "field": "formName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      
      {
        "header": "Variables",
        "field": "variables",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'button',
        "cellRenderView": true,
        button:{"name":"Add Varriable",visibility:true,classes: ['btn','btn-primary'],
        styles: { 'padding': '0px !important', 'font-size': '20px !important' }},
      },

      {
        "header": "Action",
        "field": "action",
        "filter": true,
        "width": "100px",
        "editable": "false",
        "text-align": "left",
        "search": true,
        "component": "buttonIcon",
        "cellRenderView": true,
        "freezecol": "null",
        "hidden": false,
        "sort": false,
        "cellHover": false,
        "button": { "imgsrc": "", "iconclass": "fas fa-trash", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-danger"], "attribute": "", "styles": "" },
      }, 

    ];
    let self = this;

    let components = { };

    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",

        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        rowCustomHeight :20,
        cellCustomPadding:5,
        recordNo: true,
        rowGrouping: {
          "enable": true,
          "groupType": "custome",
          "groupBy": "moduleName",
          "expandRow": []
        },
        rowSelection: false,
        rowDataViewTotal: true,
        sml_expandGrid_hide: true,
        exportXlsxPage_hide: true,
        exportXlsxAllPage_hide: true,
        exportPDFLandscape_hide: true,
        exportPDFPortrait_hide: true,
        ariaHidden_hide: true,
        callBack: {
          "onButtonIcon_action": function (ele, params) {
            self.deleteVariableImpExpModule(params.rowIndex);
          },
          "onButton_variables": function (ele, params) {
            let obj = params['rowValue'];
            self.getFormLabelName(obj);
          },
        },

        dropDownJson_formName: this.angularFormDropdownList,
      };
      this.gridDynamicForVariableMappingInfo = SdmtGridT(sourceDiv, gridData, true, true);
      this.gridDynamicForVariableMappingInfo.expandAll();
      return this.gridDynamicForVariableMappingInfo;
    }
  }

  async deleteVariableImpExpModule(index) {

    let selectedRowData = this.gridDynamicForVariableMappingInfo.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row");
      return;
    }
    let conf = await ui.confirm("Do You Want To Delete ? ");
    if (!conf) {
      return;
    }

    let variableModuleId = selectedRowData.moduleId;

    this.autoJavacodeService.deleteVariableImpExpModule(variableModuleId).subscribe(res => {
      if (res.status == 200) {
        success(res.msg)
        this.getVariableImpExpModuleList();
      }
    }, Error => {
      alerts("Error While Deleting Data");
    });
  }


  getVariableImpExpModuleList() {
    let softwareFormId = this.variableImportExportInfoFormGroup.controls['softwareFormId'].value;
    if (softwareFormId) {

      this.autoJavacodeService.getVariableImpExpModuleList(softwareFormId).subscribe(res => {
        if (res.status == 200) {
          this.variableMappingInfoGrid(res.data);
        } else {
          this.variableMappingInfoGrid([]);
        }
      }, Error => {
        this.variableMappingInfoGrid([]);
        alerts("Error While Fetching Data");
      });
    } else {
      this.variableMappingInfoGrid([]);
    }

  }

  getFormLabelName(selectedRowData) {
    let ngsrcfileId = selectedRowData.formName;
    let moduleId = selectedRowData.moduleId

    if (ngsrcfileId) {
      this.autoJavacodeService.getFormLabelName(Number(ngsrcfileId)).subscribe(res => {
        if (res.status == 200) {
         
          this.openFormLabelsModel();
          res.data.forEach(element => {
            element["moduleId"] = moduleId;
          });
          this.getImportExportVarriabels(moduleId,res.data);
        }
      }, Error => {

        alerts("Error While Fetching Data");
      });
    } else {
      alerts('please select form name first')
    }

  }

  getImportExportVarriabels(moduleId,data) {
 
    this.autoJavacodeService.getImportExportVarriabels(moduleId).subscribe(res => {
      if (res.status == 200) {
        let mapDataList = res.data;
        mapDataList.forEach(mapData => {
          data.forEach(element => {
            if(mapData.pagedbmapId == element.pagedbmapId){
              element['checkBox'] = mapData['checkBox']
            }
          });
        });
        this.addFormLabelsGrid(data);
      }else{
        this.addFormLabelsGrid(data);
      }
    }, Error => {
      this.addFormLabelsGrid(data);
       
    });
  } 



  onCloseFormLabels() {
    $('#addFormLabelsModel').modal('hide')
  }

  openFormLabelsModel() {
    $('#addFormLabelsModel').modal('show')
  }


  addFormLabelsGrid(rowsData) {
    var sourceDiv = document.getElementById("addFormLabelsGrid");
    var columns = [
      {
        "field": "checkBox",
        "filter": false,
        "editable": false,
        "sagGridResize": false,
        "width": "50px",
        "header": "All",
        "text-align": "center",
        "colType": "checkBox"
      },
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      {
        "header": "Page Name",
        "field": "formName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      {
        "header": "Label Name",
        "field": "labelName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      {
        "header": "Input Type",
        "field": "inputType",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      {
        "header": "Table Name",
        "field": "tableName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      }, {
        "header": "Table Column",
        "field": "tableColumn",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },


    ];
    let self = this;

    let components = {};

    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        rowCustomHeight :20,
        cellCustomPadding:5,
        recordNo: true,
        callBack: {

        }
      };
      this.gridDynamicForAddFormLabels = SdmtGridT(sourceDiv, gridData, true, true);
      return this.gridDynamicForAddFormLabels;
    }
  }

  onClickOkFormLabels() {
    let checkedData = this.gridDynamicForAddFormLabels.getCheckedDataParticularColumnWise();

    if (checkedData.length == 0) {
      alerts("Please select atleast one row")
      return;
    }
    let selectedRowData = this.gridDynamicForVariableMappingInfo.getSeletedRowData();
    let moduleId = selectedRowData.moduleId
    let ngsrcfileId = selectedRowData.formName;
    
    this.autoJavacodeService.saveImportExportVarriabels(checkedData,moduleId,ngsrcfileId).subscribe(res => {
      if (res.status == 200) {
        success(res.msg);
        this.onCloseFormLabels();
      } else {
        alerts(res.msg);
      }
    }, Error => {
      alerts("Error While saving data");
    });

  }

  getFormList() {
    const setProjectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    this.angularFormList = [];
    if (setProjectInfo && setProjectInfo.jwspace) {
      const projectId = setProjectInfo.projectId

      this.autoJavacodeService.getFormList(projectId).subscribe(res => {
        if (res.status == 200) {
          this.angularFormList = res.data;
          this.getFormDropDownList(res.data);
        }
      }, Error => {

        alerts("Error While Fetching Data");
      });
    } else {
      alerts('please setPath in workspace Configuration')
    }

  }

 
  getFormDropDownList(data) {
    this.angularFormDropdownList = [{ "key": "", "val": "--Select--" }]
    data.forEach(ele => {
      let obj = {
        "key": ele['ngsrcfileId'],
        "val": ele['formName']
      }
      this.angularFormDropdownList.push(obj);
    });
  }


 

}
