import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/core/shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AddMethodModule } from 'src/app/modules/sag-studio/add-method/add-method.module';
import { NgGenerateModule } from 'src/app/modules/sag-studio/ng-generate/ng-generate.module';
import { ImportExportVarriableComponent } from './import-export-varriable.component';

@NgModule({
  declarations: [ImportExportVarriableComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AddMethodModule,
    NgGenerateModule,
    SharedModule,
    ],
  exports:[ImportExportVarriableComponent]
})
export class ImportExportVarriableModule { }
