import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy, ElementRef, ViewChild, HostListener } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { ImportExportManualCodeComponent } from '../import-export-manual-code/import-export-manual-code.component';
import { Subscription } from 'rxjs';
import { OverlayRef } from '@angular/cdk/overlay';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $, Contextual, ContextualItem;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-export-report-mapping',
  templateUrl: './export-report-mapping.component.html',
  styleUrls: ['./export-report-mapping.component.scss']
})
export class ExportReportMappingComponent implements OnInit,OnDestroy {

  refrenceExcelSheetList=[];
  refrenceManualMethodList = [];

  fileImportExportInfoFormGroup: FormGroup;
  gridDynamicForReportMapping :any;
  sheetHeaderAlias = {};

  angularFormList = []
  angularFormDropdownList = [{ "key": "", "val": "--Select--" }]
  angularFormLabelList = [];
  angularFormLabelDropdownList = [];

  variabelModuleDropdropdownList = [];
  variabelModuleList = [];

  
  allTableList = [];
  tableListDropdownList = [{ "key": "", "val": "--Select--" }];
  tableFieldsMap = new Map();
  angularformFieldsMap = new Map();
  tableFieldDropdownList = [];
  tableMasterDropdownForSheetMapping = [];

  masterTableFieldMap = new Map();
  masterTableFieldDropdownList = [];

  manualMethodList = [];

 reportSectionList = [];

 aliaseStartIndex

 reportSectionData = {
  "varriableMappingData": [],
  "type":"fix",
  "varriableMappingType":"table",
  "sectionHeaderList" : [],
  "recordType":"muliple_record",
  "jsonLevel":"",
  "relationBeetweenTables":[], 
};

dataFindFrom = [
  { "key": "", "val": "--Select--" },
  { "key": "_database", "val": "Database" },
  { "key": "client_side", "val": "Client Side" },
  { "key": "Formula", "val": "Formula" },
  { "key": "by_manual_method_with_aliase", "val": "Manual Method With Aliase" },
  { "key": "by_manual_method", "val": "Manual Method With static" },
  { "key": "static_value", "val": "Static Value" },
 
 ];
 dateFormateList = [];
  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService, ) { }
  
  ngOnInit() {
    this.initializeFormGroup(); 
    this.getDateFormateList();
    if(this.config.data){
      this.fileImportExportInfoFormGroup.patchValue(this.config.data); 
    }

    this.setApiGeneratedInfo();
  
    this.getSheetHeaderAlias();
    this.getVariableImpExpModuleListForSheetMapping();
    this.getFormList();
    this.getAllTableList();
    this.getReportFileInfo();
    this.isCreatedFileValid(false);
  }

  ngOnDestroy() { }

  onClose() {
    this.modalRef.close();
    this.ngOnDestroy();
   }

   initializeFormGroup() {

    this.fileImportExportInfoFormGroup = this.formbuilder.group({
      mappingId: [{ value: '', disabled: false }],
      softwareName: [{ value: '', disabled: false }],
      softwareId: [{ value: null, disabled: false }],
      formName: [{ value: '', disabled: false }],
      softwareFormId: [{ value: '', disabled: false }, [Validators.required]],
      file: [{ value: '', disabled: false }],
      fileName: [{ value: '', disabled: false }, [Validators.required]],
      type: [{ value: '', disabled: false }, [Validators.required]],
      fileType: [{ value: '', disabled: false }, [Validators.required]],
      providerId: [{ value: '', disabled: false }, [Validators.required]],
      providerName:[{ value: '', disabled: false }],
      noOfSheet: [{ value: '', disabled: false }, [Validators.required]],
      versionNo: [{ value: '', disabled: false }, [Validators.required]],
      fileExtention: [{ value: '', disabled: false }, [Validators.required]],
      fromDate: [{ value: '', disabled: false }, [Validators.required]],
      toDate: [{ value: '', disabled: false }, [Validators.required]],
      dataInsertType: [{ value: 'hibernate_query', disabled: false }],
      databaseType: [{ value: 'mysql', disabled: false }],
      viceVersaId: [{ value: '', disabled: false }],
    });
  }


  getDateFormateList() {
    this.dateFormateList = [];
    this.autoJavacodeService.getDateFormateList().subscribe(res => {
      if (res.status == 200) {
        this.dateFormateList = res.data;
        
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }


  getReportFileInfo() {

    let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;
    let softwareFormId = this.fileImportExportInfoFormGroup.controls["softwareFormId"].value;
    this.reportSectionList = [];
    this.manualMethodList = [];
  
    this.autoJavacodeService.getReportMappingInfo(mappingId,softwareFormId).subscribe(res => {
      if (res.status == 200) {
        let data = res.data;
        if(data){
          this.reportSectionList = data.excelSheetList;
          this.manualMethodList = data.manualMethodList;
        
            let item = _.find(this.reportSectionList, { active: true });
            if (item) {
              setTimeout(() => {
              this.onClickReportSection(item, 1);
              }, 100);
  
            }
            //this.getRefrenceFileInfo(false);
        }else{
          //this.getRefrenceFileInfo(true);
        }
       
      }
    }, Error => {
      alerts("Error While Fetching info");
    });

  }


  
  getRefrenceFileInfo(isMappingImport) {

    let mappingId = this.fileImportExportInfoFormGroup.controls["viceVersaId"].value;
    this.refrenceExcelSheetList = [];
    this.refrenceManualMethodList = [];
  
    this.autoJavacodeService.getExcelFileInfo(mappingId).subscribe(res => {
      if (res.status == 200) {
        let data = res.data;
        
        let excelData = data.excelSheetList;
        let refData = [];
        excelData.forEach(element => {
          if("multiMixSheet"==element.type){
            let excelChildSheet = element.excelChildSheet;
            if(excelChildSheet){
              excelChildSheet.forEach(childElement => {
                if(element.sheetHeaderList && element.sheetHeaderList.length > 0){
                 childElement['sectionHeaderList'] = childElement['sheetHeaderList']
                 childElement['sheetHeaderList'] = []
                this.refrenceExcelSheetList.push(childElement);
                }
              });
            }

          } else {
            if(element.sheetHeaderList && element.sheetHeaderList.length > 0){
              element['sectionHeaderList'] = element['sheetHeaderList']
              element['sheetHeaderList'] = []
              this.refrenceExcelSheetList.push(element);
            }
            
          }
          
        });


        this.refrenceManualMethodList = data.manualMethodList;
        if(isMappingImport){
          this.reportSectionList = this.refrenceExcelSheetList;
        }
      }
    }, Error => {
      alerts("Error While Fetching info");
    });

  }

  onClickReportSection(item: any, index) {

  this.reportSectionData = item;
  
  if(!this.reportSectionData['dataFindFrom']){
    this.reportSectionData['dataFindFrom'] = JSON.parse(JSON.stringify(this.dataFindFrom))
  }
  
  this.manageExcelSheetState(true);  
  
  this.reportSectionList.forEach(itm => itm.active = false);
  this.reportSectionList.forEach(itm => itm.isRename = false);

  item['active'] = true;
  
 
  this.sagSheetMappingGrid(item.sectionHeaderList)
  
  
  setTimeout(() => {
     this.manageExcelSheetState(false);  
  }, 500);
  
  
  setTimeout(() => {
    let gridData = this.gridDynamicForReportMapping.getGridData();
    this.bindSheetData(gridData);
  }, 500);

  try {
    this.gridDynamicForReportMapping.expandAll();
  } catch (error) {
    
  }

  

  }

  
  bindSheetData(gridData){
    if(this.gridDynamicForReportMapping){
     if(gridData){
       gridData.forEach(rowData => {
        if(rowData.details){
          this.bindSheetData(rowData.details);
         }
         if(rowData.formName && rowData.field){
           this.onChangeFormNameInGrid(rowData.formName,rowData.sag_G_Index,rowData.field);
         }
         if(rowData.tableName && rowData.tableField){
           this.onChangeTable(rowData.tableName, rowData.sag_G_Index,rowData.tableField);
           this.onChangeMasterTable(rowData.tableMaster, rowData.sag_G_Index,rowData.masterColumnName);
         }
       });
     }
    }
  }

  manageExcelSheetState(isLoadBefore) {
    if (this.reportSectionData && this.reportSectionData.varriableMappingType) {
      if (isLoadBefore && this.reportSectionData.varriableMappingType == "form") {
        this.getFormDropDownList(this.angularFormList);
        this.getTableDropdownName(this.allTableList);
        
      } else if ( isLoadBefore && this.reportSectionData.varriableMappingType == "table") {
        this.getFormDropDownList(this.angularFormList);
        this.getTableDropdownName(this.allTableList);
    
      } else if (!isLoadBefore && this.reportSectionData.varriableMappingType == "formDbMapping") {
        if (this.reportSectionData.varriableMappingData) {
          this.getVariableNameByModuleId(this.reportSectionData.varriableMappingData);
        }
      }
    }
  }

  
  getSheetHeaderAlias() {
 
    this.autoJavacodeService.getSheetHeaderAlias().subscribe(res => {
      if (res.status == 200) {
        this.sheetHeaderAlias = res.data;
      }else{
        this.sheetHeaderAlias = {}
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  getVariableImpExpModuleListForSheetMapping() {
    this.variabelModuleDropdropdownList = [];
    this.variabelModuleList = []; 
    let fileMappingId = this.fileImportExportInfoFormGroup.controls['softwareFormId'].value;
    if (fileMappingId) {
      this.autoJavacodeService.getVariableImpExpModuleListForSheetMapping(fileMappingId).subscribe(res => {
        if (res.status == 200) {
          this.variabelModuleList = res.data;
        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
    }
  }

  getFormList() {
    const setProjectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    this.angularFormList = [];
    if (setProjectInfo && setProjectInfo.jwspace) {
      const projectId = setProjectInfo.projectId

      this.autoJavacodeService.getFormList(projectId).subscribe(res => {
        if (res.status == 200) {
          this.angularFormList = res.data;
          this.getFormDropDownList(res.data);
        }
      }, Error => {

        alerts("Error While Fetching Data");
      });
    } else {
      alerts('please setPath in workspace Configuration')
    }

  }

  getFormDropDownList(data) {
    this.angularFormDropdownList = [{ "key": "", "val": "--Select--" }]
    data.forEach(ele => {
      let obj = {
        "key": ele['ngsrcfileId'],
        "val": ele['formName']
      }
      this.angularFormDropdownList.push(obj);
    });
    if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['formName']) {
      this.gridDynamicForReportMapping.sagGridObj.components['formName'].setOption(this.angularFormDropdownList);
    }
  }

  getAllTableList() {
  
    this.tableListDropdownList = [];
    this.allTableList = [];

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
    }
    this._dbcomparetoolService.tblstrcturedrpdown(dbData).subscribe((res) => {
      if (res) {
        let masterdropdown = res['masterdropdown'];
        let mtbllist = masterdropdown.mtbllist.sort();
        this.allTableList = masterdropdown.mtbllist.sort();
        this.getTableDropdownName(mtbllist);
        this.getTableDropdownNameForMaster();
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }

  getTableDropdownName(mtbllist) {
    this.tableListDropdownList = [{ "key": "", "val": "--Select--" }];
    mtbllist.forEach(table => {
      let obj = {
        "key": table,
        "val": table
      }
      this.tableListDropdownList.push(obj);
    });
    if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['tableName']) {
      this.gridDynamicForReportMapping.sagGridObj.components['tableName'].setOption(this.tableListDropdownList);
    }
  }

    
  getTableDropdownNameForMaster() {
    this.tableMasterDropdownForSheetMapping = [{ "key": "", "val": "--Select--" }];
  this.allTableList.forEach(table => {
    let obj = {
     "key":table,
     "val":table
    }
    this.tableMasterDropdownForSheetMapping.push(obj);
  });
  }


  addRowSheetMapping(){
    let obj = this.getEmptyObjForAddRow();
     
    this.reportSectionData['sectionHeaderList'].push(obj);
    
     this.sagSheetMappingGrid(this.reportSectionData['sectionHeaderList']);
     this.gridDynamicForReportMapping.expandAll();
  }


  sagSheetMappingGrid(rowsData) {
    var sourceDiv = document.getElementById("sagSheetMappingGrid");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Name",
        "field": "name",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      {
        "header": "Header Alias",
        "field": "headerAlias",
        "filter": true,
        "width": "100px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
          
      {
        "header": "Data Find From",
        "field": "dataFindFrom",
        "filter": true,
        "width": "170px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Column Type",
        "field": "columnType",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      // {
      //   "header": "Date Format",
      //   "field": "dateFormat",
      //   "filter": true,
      //   "width": "150px",
      //   "editable": "false",
      //   "textalign": "center",
      //   "search": true,
      //   "component": 'select',
      //   "cellRenderView": false
      // },
       
       
      // {
      //   "header": "Form Name",
      //   "field": "formName",
      //   "filter": true,
      //   "width": "150px",
      //   "editable": "false",
      //   "textalign": "center",
      //   "search": true,
      //   "component": 'select',
      //   "cellRenderView": false
      // },
      // {
      //   "header": "Field",
      //   "field": "field",
      //   "filter": true,
      //   "width": "150px",
      //   "editable": "false",
      //   "textalign": "center",
      //   "search": true,
      //   "component": 'select',
      //   "cellRenderView": false
      // },
      // {
      //   "header": "Field Properties",
      //   "field": "fieldProperties",
      //   "filter": true,
      //   "width": "150px",
      //   "editable": "false",
      //   "textalign": "center",
      //   "search": true,
      //   "cellRenderView": true,
      //   "component": 'label',
      // },
      {
        "header": "Table Name",
        "field": "tableName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "left",
        "search": true,
        "component": 'select',
        // "component": 'selectSearch', 
        "cellRenderView": false
      },
      {
        "header": "Table Field",
        "field": "tableField",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Table Properties",
        "field": "tableProperties",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      {
        "header": "Is Master",
        "field": "isMaster",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Table Master",
        "field": "tableMaster",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
       "cellRenderView": false,
       //"component": 'selectSearch',
       //"cellRenderView": true,

       

      },
      {
        "header": "Master Column Name",
        "field": "masterColumnName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      // {
      //   "header": "Unique Constraint",
      //   "field": "uniqueConstraint",
      //   "filter": true,
      //   "width": "150px",
      //   "editable": "false",
      //   "text-align": "center",
      //   "search": true,
      //   "component": 'checkbox',
      //   "cellRenderView": true
      // },
      {
        "header": "Formula/Static Value/Method Calling",
        "field": "formulaStaticValue",
        "filter": true,
        "width": "250px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      {
        "header": "Group By",
        "field": "groupBy",
        "filter": true,
        "width": "100px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'checkbox',
        "cellRenderView": true
      },
      {
        "header": "Export By",
        "field": "importBy",
        "filter": true,
        "width": "100px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'checkbox',
        "cellRenderView": true
      },
      {
        "header": "Function",
        "field": "aggregateFunction",
        "filter": true,
        "width": "100px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
    ];
  
    let self = this;
  
    let fieldTypeList = [
      { "key": "", "val": "--Select--" },
      { "key": "STRING", "val": "STRING" },
      { "key": "INTEGER", "val": "NUMBER" },
      { "key": "DECIMAL", "val": "DECIMAL NUMBER" },
      { "key": "BOOLEAN", "val": "BOOLEAN" },
      { "key": "DATE", "val": "DATE" },
      { "key": "OBJECT", "val": "OBJECT" },
      { "key": "ARRAY", "val": "ARRAY" },
  
    ];
    let isMaster = [
      { "key": "", "val": "--Select--" },
      { "key": "Y", "val": "Yes" },
      { "key": "N", "val": "No" },
     ];
 
   
     let aggregateFunctionList = [
      { "key": "", "val": "--Select--" },
      { "key": "sum", "val": "SUM" },
      { "key": "count", "val": "Count" },
      
     ];
  
  
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
     // SagGridRowStatus[i]["headerAlias"] = this.sheetHeaderAlias[i + 1];
    }
    this.aliaseStartIndex = 0;
    this.setAliaseNameInGrid(rowsData);
  
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        frezzManager: { "sno": "left", "name": "left","cellDesc":"left","cellRefrence":"left","headerAlias":"left" },
        components: {},
        rowCustomHeight :20,
        cellCustomPadding:5,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {

          // "onCellClick": function (ele) {
          //   ele.onkeydown = function (event) {
          //     alerts("down" + event.keyCode);
          //   }
          //   ele.onkeyup = function (event) {
          //     alerts("up" + event.keyCode);
          //   }
          // },

        

          "onChangeSelect_columnType": function (ele, params) {
            self.onChangeSheetColumnType(ele.value, params.rowIndex)
          },
          "onChangeSelect_formName": function (ele, params) {
            self.onChangeFormNameInGrid(ele.value, params.rowIndex,null)
          },
          "onChangeSelect_field": function (ele, params) {
            self.onChangeFormFieldNameInGrid(ele.value, params)
          },
  
          "onChangeSelect_tableName": function (ele, params) {
            let value = ele.value;
            ele.onkeydown = function (event) {
              if (event.keyCode == 13) {
                self.fillTableNameSameValue(params, value);
                
              }
            }
            self.onChangeTable(ele.value, params.rowIndex,null);
            self.setTableNameIntoDataBindFrom(ele.value);
          },
          "onChangeSelect_tableField": function (ele, params) {
            self.onChangeTableField(ele.value, params)
          },
          "onChangeSelect_isMaster": function (ele, params) {
            if(ele.value == "Y"){
              self.gridDynamicForReportMapping.enableCell(params.rowIndex, "tableMaster");
              self.gridDynamicForReportMapping.enableCell(params.rowIndex, "masterColumnName");
            }else{
              self.gridDynamicForReportMapping.updateCell(params.rowIndex, "tableMaster",'');
              self.gridDynamicForReportMapping.updateCell(params.rowIndex, "masterColumnName",'');
              self.gridDynamicForReportMapping.updateCell(params.rowIndex, "addDisplayMasterColumn", []);
  
               self.gridDynamicForReportMapping.disableCell(params.rowIndex, "tableMaster");
               self.gridDynamicForReportMapping.disableCell(params.rowIndex, "masterColumnName");
            }
          },
           "onChangeSelect_tableMaster": function (ele, params) {
          //  "onChangeSearchSelect_tableMaster": function (ele, params) {
            self.gridDynamicForReportMapping.updateCell(params.rowIndex, "addDisplayMasterColumn", []);
            self.onChangeMasterTable(ele.value, params.rowIndex,null)
          },
          // "onChangeSelect_columnType": function (ele, params) {
          //  // self.onChangeSheetColumnType(ele.value, params.rowIndex)
          // },
  
          "onChangeSelect_masterColumnName": function (ele, params) {
            self.onChangeMasterTableField(ele.value, params.rowValue.tableMaster,params.rowIndex)
          },

          "cellCallBack": function (param) {
            let ele = param.ele;
            ele.addEventListener('contextmenu', event => {
              event.preventDefault();
              self.gridDynamicForReportMapping.setRowSelected(param.rowIndex);
            let selectedRowData =  self.gridDynamicForReportMapping.getSeletedRowData(param.rowIndex);

              if("masterColumnName"==param.colKey){
                //self.open1(event);

                new Contextual({
                  isSticky: false,
                  items: [
                    new ContextualItem({ cssIcon:"fa fa-eye",  label: 'Select Master For Display', onClick: () => {self.openContextMenuForAddDisplayMaster(event,selectedRowData) } }),
                    new ContextualItem({ cssIcon:"fa fa-plus",  label: 'Insert Row', onClick: () => {self.addRowEllipsis(param.rowIndex); } }),
                    new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Row', onClick: () => {self.deleteRowSheetMapping(param.rowIndex); } }),
                    new ContextualItem({cssIcon:"fa fa-copy",  label: 'Copy Row', onClick: () => { self.copyRow(ele,param) } }),
                    new ContextualItem({cssIcon:"fa fa-paste",  label: 'Paste Row', onClick: () => {  self.pasteRowSheetMapping(param.rowIndex) } }),
                    new ContextualItem({ cssIcon:"fa fa-child", label: 'Add Child Row', onClick: () => {  self.addChildRowSheetMapping(param.rowIndex); } }),
                    ]
                });

              }else{
                new Contextual({
                  isSticky: false,
                  items: [
                    new ContextualItem({ cssIcon:"fa fa-plus",  label: 'Insert Row', onClick: () => {self.addRowEllipsis(param.rowIndex); } }),
                    new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Row', onClick: () => {self.deleteRowSheetMapping(param.rowIndex); } }),
                    new ContextualItem({cssIcon:"fa fa-copy",  label: 'Copy Row', onClick: () => { self.copyRow(ele,param) } }),
                    new ContextualItem({cssIcon:"fa fa-paste",  label: 'Paste Row', onClick: () => {  self.pasteRowSheetMapping(param.rowIndex) } }),
                    new ContextualItem({ cssIcon:"fa fa-child", label: 'Add Child Row', onClick: () => {  self.addChildRowSheetMapping(param.rowIndex); } }),
                   
                               ]
                });
              }

             
            });
          }

        },
        

        dropDownJson_columnType: fieldTypeList,
        dropDownJson_formName: this.angularFormDropdownList,
        dropDownJson_field: [{ "key": "", "val": "--Select--" }],
        dropDownJson_tableName: this.tableListDropdownList,
        dropDownJson_tableField: [{ "key": "", "val": "--Select--" }],
        dropDownJson_isMaster: isMaster,
        dropDownJson_tableMaster: this.tableMasterDropdownForSheetMapping,
        //selectSearchdropDownJson_tableMaster: this.tableMasterDropdownForSheetMapping,
        dropDownJson_masterColumnName: [{ "key": "", "val": "--Select--" }],
        dropDownJson_dataFindFrom: this.dataFindFrom, 
        dropDownJson_dateFormat:this.dateFormateList,
        dropDownJson_aggregateFunction:aggregateFunctionList,

        rowGrouping: {
          "enable": true,
          "groupType": "custome",
          "groupBy": "name",
          "expandRow": []
        },

        rowSelection: false,
        rowDataViewTotal: true,
        sml_expandGrid_hide: true,
        exportXlsxPage_hide: true,
        exportXlsxAllPage_hide: true,
        exportPDFLandscape_hide: true,
        exportPDFPortrait_hide: true,
        ariaHidden_hide: true,

      };
  
      
  
      this.gridDynamicForReportMapping = SdmtGridT(sourceDiv, gridData, true, true);
      this.disableMasterCell();
      this.setValidationRowProperty(rowsData); 

      this.setRowColor(this.gridDynamicForReportMapping.getGridData());

      return this.gridDynamicForReportMapping;
    }
  }

  setAliaseNameInGrid (rowsData) {
    for (let index = 0; index < rowsData.length; index++) {
      let element = rowsData[index];
      if(element.details){
        this.aliaseStartIndex = this.aliaseStartIndex + 1;
        element["headerAlias"] =  this.sheetHeaderAlias[this.aliaseStartIndex]
        this.setAliaseNameInGrid(element.details)
        
      } else {
        this.aliaseStartIndex = this.aliaseStartIndex + 1;
        element["headerAlias"] =  this.sheetHeaderAlias[this.aliaseStartIndex]
      }
    }
  }

  setRowColor(gridData){
   
    gridData.forEach(rowData => {
     if(rowData.details){
        this.setRowColor(rowData.details);
      }else{
        this.setColorByDataFindFrom(rowData.dataFindFrom,rowData.sag_G_Index)
      }
   });
  }
  
  setColorByDataFindFrom(dataFindFrom,sag_G_Index){ 
    if ("_database" == dataFindFrom) {
      let colorProperty = { "background-color": "rgb(153, 235, 255)" }
      this.gridDynamicForReportMapping.setRowProperty(sag_G_Index, colorProperty);
    }
    if ("client_side" == dataFindFrom) {
      let colorProperty = { "background-color": "rgb(153, 255, 179)" }
      this.gridDynamicForReportMapping.setRowProperty(sag_G_Index, colorProperty);
    }
    if ("Formula" == dataFindFrom) {
      let colorProperty = { "background-color": "rgb(255, 255, 153)" }
      this.gridDynamicForReportMapping.setRowProperty(sag_G_Index, colorProperty);
    } if ("by_manual_method_with_aliase" == dataFindFrom || "by_manual_method" == dataFindFrom) {
      let colorProperty = { "background-color": "rgb(148, 184, 175)" }
      this.gridDynamicForReportMapping.setRowProperty(sag_G_Index, colorProperty);
    } if ("static_value" == dataFindFrom || "static_master_code" == dataFindFrom) {
      let colorProperty = { "background-color": "rgb(214, 194, 194)" }
      this.gridDynamicForReportMapping.setRowProperty(sag_G_Index, colorProperty);
    }
  }


  onChangeSheetColumnType(columnType, rowIndex){
 
    let decimalFormat = ["decimal_format"];
    
    if("DECIMAL"== columnType){
      this.gridDynamicForReportMapping.updateCell(rowIndex, "decimalFormat", decimalFormat);
    }else{
      this.gridDynamicForReportMapping.updateCell(rowIndex, "decimalFormat", []);
    }

    if("DATE"== columnType){
      this.gridDynamicForReportMapping.updateCell(rowIndex, "dateFormat", 'dd/MMM/yyyy');
    }else{
      this.gridDynamicForReportMapping.updateCell(rowIndex, "dateFormat", "");
    }
       
   }
  
  disableMasterCell(){
    let gridData = this.gridDynamicForReportMapping.getGridData();
    gridData.forEach(rowData => {
      if("Y" == rowData.isMaster){
        this.gridDynamicForReportMapping.enableCell( rowData.sag_G_Index, "excelMaster"); 
        this.gridDynamicForReportMapping.enableCell( rowData.sag_G_Index, "tableMaster");
        this.gridDynamicForReportMapping.enableCell( rowData.sag_G_Index, "masterColumnName");
      }else {
       this.gridDynamicForReportMapping.disableCell( rowData.sag_G_Index, "excelMaster");
        this.gridDynamicForReportMapping.disableCell( rowData.sag_G_Index, "tableMaster");
        this.gridDynamicForReportMapping.disableCell( rowData.sag_G_Index, "masterColumnName");
      }
    });
  }

  async fillTableNameSameValue(params, tableName){
    if (await ui.confirm('Do You Want To Fill Same Value In Next Remainig Row ?')) {
     let gridsize = this.gridDynamicForReportMapping.sagGridObj.AllRowIndex.length;
     for (let i = params.rowIndex; i < gridsize; i++) {
       this.gridDynamicForReportMapping.updateCell(i, "tableName", tableName);
       this.onChangeTable(tableName, i,null);
       this.setTableNameIntoDataBindFrom(tableName);
     }
    }
   }

   fillTableList
   setTableNameIntoDataBindFrom(tableName){
    let gridData = this.gridDynamicForReportMapping.getGridData();
  this.fillTableList = [];
  this._getAllFillTableList(gridData);
  this.fillTableList.push(tableName);
  let tableList = _.uniq(this.fillTableList);

  let relationList = [];
  tableList.forEach(element => {
    tableList.forEach(element1 => {
      if(element1 && element){
        let relatation =  _.find(this.tableFieldsMap.get(element) , {"parentTable":element1});
        if(relatation){
         relationList.push(relatation);
        }
      }
    });
   
  });

  this.reportSectionData['relationBeetweenTables'] = relationList;

 this.fillTableList = [];
   
  }

  _getAllFillTableList(gridData){
    let tableList = _.map(gridData, 'tableName');
    tableList = _.uniq(tableList);
    if(tableList){
      tableList.forEach(element => {
        if(element){
          this.fillTableList.push(element);
        }
      });
    }
  
    gridData.forEach(element => {
      if(element.details){
        this._getAllFillTableList(element.details);
      }
    });
    
  }

  onChangeTableField(tableField, params) {
    let rowIndex = params.rowIndex;
    if (tableField) {
      let tableName = params.rowValue.tableName;
    
      let tableFieldsList = this.tableFieldsMap.get(tableName);
      let item = _.find(tableFieldsList, { "columnName": tableField });
      if (item) {
        this.gridDynamicForReportMapping.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
        this.gridDynamicForReportMapping.updateCell(rowIndex, "tableCoulmnType", item.dataType);
        
      }
      let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
      if(pkObj){
       this.gridDynamicForReportMapping.updateCell(rowIndex, "primaryKey", pkObj.columnName);
       this.gridDynamicForReportMapping.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
      }
  
    }else{
      this.gridDynamicForReportMapping.updateCell(rowIndex, "tableProperties",'');
      this.gridDynamicForReportMapping.updateCell(rowIndex, "tableCoulmnType", '');
    }
  }
  
  onChangeFormNameInGrid(formName, rowIndex,formFieldBind) {
    let formFields = [{ "key": "", "val": "--Select--" }];
     
    if (formName) {

      if(this.reportSectionData && (this.reportSectionData.varriableMappingType )+"" == "formDbMapping"){
        
        this.getImportExportVarriabels(formName, rowIndex,formFieldBind);

      } else {
        let ngsrcfileId = formName;
        this.autoJavacodeService.getFormLabelName(Number(ngsrcfileId)).subscribe(res => {
          if (res.status == 200) {
            res.data.forEach(ele => {
              let obj = {
                "key": ele.labelName,
                "val": ele.labelName
              }
              formFields.push(obj);
              this.angularformFieldsMap.set(ngsrcfileId, res.data);
            });
            if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['field']) {
              this.gridDynamicForReportMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
              if(formFieldBind){
                this.gridDynamicForReportMapping.updateCell(rowIndex, "field", formFieldBind);
              }
            }
          }
        }, Error => {
          alerts("Error While Fetching Data");
        });
      }

      

    } else {
      if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['field']) {
        this.gridDynamicForReportMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
      }

    }

  }

  getImportExportVarriabels(formName, rowIndex,formFieldBind) {

    let formFields = [{ "key": "", "val": "--Select--" }];

    let moduleId = this.reportSectionData.varriableMappingData;
    if(!moduleId){
      if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['field']) {
        this.gridDynamicForReportMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
      }
   }
   let ngsrcfileId = formName;
    this.autoJavacodeService.getImportExportVarriabels(moduleId).subscribe(res => {
      if (res.status == 200) {
        if(res.data!=null){
          res.data.forEach(ele => {
            let obj = {
              "key": ele.labelName,
              "val": ele.labelName
            }
            formFields.push(obj);
            this.angularformFieldsMap.set(ngsrcfileId, res.data);
          });
        }
       
        if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['field']) {
          this.gridDynamicForReportMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
          if(formFieldBind){
            this.gridDynamicForReportMapping.updateCell(rowIndex, "field", formFieldBind);

          }
       
        }
      }
    }, Error => {
       
      alerts("Error While Fetching Data");
    });
  } 

  
  onChangeTable(tableName, rowIndex,tableFieldBind) {
    if (tableName) {

      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName
      }
      this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
        if (res) {
          this.setTableFieldDropdown(res, rowIndex,tableFieldBind,tableName);
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }

  }

  setTableFieldDropdown(res, rowIndex,tableFieldBind,tableName) {
    this.tableFieldDropdownList = [{ "key": "", "val": "--Select--" }];

    let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);
 
    tableFieldsInfo.forEach(tableColumn => {
      let obj = {
        "key": tableColumn['columnName'],
        "val": tableColumn['columnName']
      }
      this.tableFieldDropdownList.push(obj);
    });

    this.tableFieldsMap.set(tableName, tableFieldsInfo);

    if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['tableField']) {
      this.gridDynamicForReportMapping.sagGridObj.components['tableField'].setOptionRow(this.tableFieldDropdownList, "tableField", rowIndex);
      if(tableFieldBind){ 
       this.gridDynamicForReportMapping.updateCell(rowIndex, "tableField", tableFieldBind);

       let tableFieldsList = this.tableFieldsMap.get(tableName);
       let item = _.find(tableFieldsList, { "columnName": tableFieldBind });
       if (item) {
         this.gridDynamicForReportMapping.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
         this.gridDynamicForReportMapping.updateCell(rowIndex, "tableCoulmnType", item.dataType);
       }

       let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
       if(pkObj){
        this.gridDynamicForReportMapping.updateCell(rowIndex, "primaryKey", pkObj.columnName);
        this.gridDynamicForReportMapping.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
       }

      }
    }
  }

  onChangeMasterTable(tableName, rowIndex,tableFieldBind) {
    if (tableName) {

      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName
      }
      this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
        if (res) {
         
          this.setMasterTableFieldDropdown(res, rowIndex,tableFieldBind,tableName);
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }else{
      if(this.gridDynamicForReportMapping.sagGridObj.components['masterColumnName']){
      this.gridDynamicForReportMapping.sagGridObj.components['masterColumnName'].setOptionRow([{ "key": "", "val": "--Select--" }], "masterColumnName", rowIndex);
    }
    }
 }

 setMasterTableFieldDropdown(res, rowIndex,tableFieldBind,tableName) {
  this.masterTableFieldDropdownList = [{ "key": "", "val": "--Select--" }];

  let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);

 
  tableFieldsInfo.forEach(tableColumn => {
   
    let obj = {
      "key": tableColumn['columnName'],
      "val": tableColumn['columnName']
    }
    this.masterTableFieldDropdownList.push(obj);
  });

  this.masterTableFieldMap.set(tableName, tableFieldsInfo);

  if (this.gridDynamicForReportMapping) {

    if(tableFieldsInfo.length > 0){
      this.gridDynamicForReportMapping.updateCell(rowIndex, "tableMasterEntityName", tableFieldsInfo[0]['entityName']);
     }
 
    if(this.gridDynamicForReportMapping.sagGridObj.components['masterColumnName']){
      this.gridDynamicForReportMapping.sagGridObj.components['masterColumnName'].setOptionRow(this.masterTableFieldDropdownList, "masterColumnName", rowIndex);
    }
    if(tableFieldBind){ 
     this.gridDynamicForReportMapping.updateCell(rowIndex, "masterColumnName", tableFieldBind);
     this.onChangeMasterTableField(tableFieldBind,tableName,rowIndex);
    }
  }
}

onChangeFormFieldNameInGrid(labelName, params) {
   
  if (labelName) {
     
    let formId = params.rowValue.formName; 
    let rowIndex = params.rowIndex;
    let formFields = this.angularformFieldsMap.get(formId);
    let item = _.find(formFields, { "labelName": labelName });
    if (item) {
      this.gridDynamicForReportMapping.updateCell(rowIndex, "fieldProperties", item.inputType );
    }

  }
}

onChangeMasterTableField(tableField, tableName,rowIndex) {

  if (tableField) {
    let tableFieldsList = this.masterTableFieldMap.get(tableName);
    let item = _.find(tableFieldsList, { "columnName": tableField });
    if (item) {
      this.gridDynamicForReportMapping.updateCell(rowIndex, "masterEntityColumnName", item.entityColumn);
      this.gridDynamicForReportMapping.updateCell(rowIndex, "masterColumnDBDataType", item.dataType);
    }
    let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
    if(pkObj){
      this.gridDynamicForReportMapping.updateCell(rowIndex, "masterTablePrimaryKey", pkObj.columnName);
      this.gridDynamicForReportMapping.updateCell(rowIndex, "masterPrimarykeyDBDataType", pkObj.dataType);
    }

  }
}

onChangeVariableData(moduleId) {
  this.getVariableNameByModuleId(moduleId);
}

getVariableNameByModuleId(moduleId) {
  let formFields = [{ "key": "", "val": "--Select--" }];
  if (moduleId) {
    this.autoJavacodeService.getVariableNameByModuleId(moduleId).subscribe(res => {
      if (res.status == 200) {
        res.data.forEach(ele => {
          let obj = {
            "key": ele.labelName,
            "val": ele.labelName
          }
          formFields.push(obj);
        });

        this.filterFormsAccordingVarMapping(res);
        this.filterTablesAccordingVarMapping(res);
        this.setDefaultFormNameInSheetMapping(res);
        if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['field']) {
          this.gridDynamicForReportMapping.sagGridObj.components['field'].setOption(formFields);
        }

      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  } else {
    let gridsize = this.gridDynamicForReportMapping.sagGridObj.AllRowIndex.length;
    for (let i = 0; i < gridsize; i++) {
      this.gridDynamicForReportMapping.updateCell(i, "formName", '');
    }
    if(this.gridDynamicForReportMapping.sagGridObj.components['field']){
      this.gridDynamicForReportMapping.sagGridObj.components['field'].setOption(formFields);
    }
    
  }

}

filterFormsAccordingVarMapping(res) {
  this.angularFormDropdownList = [{ "key": "", "val": "--Select--" }];
  if (res.data.length > 0) {
    let mtbllist = _.uniqBy(_.filter(res.data, variable => variable.formName != null && variable.formName != undefined && variable.formName != ""), 'formName');
    mtbllist.forEach(ele => {
      let obj = {
        "key": ele.ngsrcfileId,
        "val": ele.formName
      }
      this.angularFormDropdownList.push(obj);
    });
   
  }
  if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['formName']) {
    this.gridDynamicForReportMapping.sagGridObj.components['formName'].setOption(this.angularFormDropdownList);
    this.gridDynamicForReportMapping.sagGridObj.dropDownJson_formName = this.angularFormDropdownList;
  }

}

onChangeRecordType(recordType){
  if("single_record" != recordType){
    this.reportSectionData.jsonLevel = "";
  }

}

setDefaultFormNameInSheetMapping(res) {
  if (res.data.length > 0) {
    let ngsrcfileId = res.data[0]['ngsrcfileId'];
    let gridsize = this.gridDynamicForReportMapping.sagGridObj.AllRowIndex.length;

    for (let i = 0; i < gridsize; i++) {
      this.gridDynamicForReportMapping.updateCell(i, "formName", ngsrcfileId);
    }
  }
}

filterTablesAccordingVarMapping(res) {
  this.tableListDropdownList = [{ "key": "", "val": "--Select--" }];
  if (res.data.length > 0) {
    let mtbllist = _.uniqBy(_.filter(res.data, variable => variable.tableName != null && variable.tableName != undefined && variable.tableName != ""), 'tableName');
   mtbllist.forEach(ele => {
      let obj = {
        "key": ele.tableName,
        "val": ele.tableName
      }
      this.tableListDropdownList.push(obj);
    });
  }
  if (this.gridDynamicForReportMapping && this.gridDynamicForReportMapping.sagGridObj.components['tableName']) {
    this.gridDynamicForReportMapping.sagGridObj.components['tableName'].setOption(this.tableListDropdownList);
  }
}

onChangeVariableMappingType(value) {

  if (value == 'table') {
    this.variabelModuleDropdropdownList = [];
  } else if (value == 'formDbMapping') {
    this.setVariableImpExpModuleListForSheetMappingDropdown();
  } else {
    this.variabelModuleDropdropdownList = [];
  }

  if (this.reportSectionData && this.reportSectionData.varriableMappingType) {
    if (value == "form" || value == "table") {
      this.getFormDropDownList(this.angularFormList);
      this.getTableDropdownName(this.allTableList);
      
    } else if (value == "formDbMapping") {
      if (this.reportSectionData.varriableMappingData) {
        this.getVariableNameByModuleId(this.reportSectionData.varriableMappingData);
      }
    }
  }
 
}

setVariableImpExpModuleListForSheetMappingDropdown(){
  this.variabelModuleDropdropdownList = [];
  this.variabelModuleList.forEach(ele => {
    let obj = {
      "value": ele.moduleId,
      "label": ele.moduleName,
    }
    this.variabelModuleDropdropdownList.push(obj);
  });
}

/**************************SAVE MAPPING*************************************** */



saveFileImportExportMappingJson() {
  let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;

  if (mappingId == '' || mappingId == null || mappingId == undefined || 
  this.reportSectionList == undefined || this.reportSectionList == null ) {
    alerts("Data not valid")
    return;
  }

  let obj = {
    "mappingId": mappingId,
    "excelSheetList": this.reportSectionList,
    "manualMethodList": this.manualMethodList ? this.manualMethodList : [],
    "type":"REPORT"
  }

  this.autoJavacodeService.saveFileImportExportMappingJson(obj).subscribe(res => {
    if (res.status == 200) {
      success(res.msg);
    }else if (res.status == 400) {
      alerts(res.msg);
     this.validateExcelData(res.excelSheetList); 
    } else {
      alerts(res.msg);
    }
  }, Error => {
    alerts("Error While saving data");
  });
}

/******************************************Generate Java Api******************************************************************************** */

setApiGeneratedInfo(){
  let backEndProjectName = this.shareService.getDataprotool("selectedProjectChooseData");
  if (backEndProjectName) {
    this.sagStudioService.setSagStudioData("autoGeneretedProjectPath", backEndProjectName.jwspace);
  }
  else {
    alerts("please setPath in workspace Configuration");
    return
  }
  let projectName = backEndProjectName.jwspace.substring(backEndProjectName.jwspace.lastIndexOf("/") + 1, backEndProjectName.jwspace.length);
  this.initializeForm(projectName);
  this.setDefaultValueInDbMappingForm();
}

dbMappingform: FormGroup;
_rootPackagePath="com.sagipl" 

generateJavaCode(){
  if(!this.isGeneratedFileValid){
    this.isCreatedFileValid(false);
    return;
 }
  this.generateJavaApi();

}

generateJavaApi() {
    
    let masterJsonObj = this.dbMappingform.getRawValue();
    let formObj = this.fileImportExportInfoFormGroup.getRawValue();
    let jsonObj = _.merge(masterJsonObj, formObj);
   
   jsonObj['excelSheetList'] = this.reportSectionList;
   jsonObj['manualMethodList'] = this.manualMethodList;
   
   let srcDataSource = null;
   let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
   if(dataForConnection && dataForConnection.srcDataSource){
     srcDataSource = dataForConnection.srcDataSource;
   }

   let reqObj = {
     apiCategory: 'report_export', 
     newApiInfoObj: jsonObj,
     apiId: null,
     apijsonId: null,
     oldApiInfoObj: null,
     databaseConfig:srcDataSource
   }

   this.autoJavacodeService.generateJavaNewCode(reqObj).subscribe(res => {
     if (res.status == 200) {
       success(res["msg"]);

       let apiInfo = res.generatedJavaApiInfo

       let apiObj = {
         uniqId: `${new Date().getTime()}${1}`,
         baseUrl: 'apiConstant.projectBaseUrl',
         failedMsg: 'error',
         run: false,
         expand: false,
         numberOfReq: 1,
         excutionTime: 0,
         argument: '',
         methodName: '',
         apiType: `${apiInfo.apiType}`,
         request: '',
         response: '',
         successMsg: 'scccessfull fetch',
         url: `${apiInfo.apiName}`,
         fullUrl: '',
         apiList: [],
         expectedReq: ``,
         expectedRes: ``,
         desc: '',
         apiResType: null,
         errorCode: "",
         msg: "",
         apiId:apiInfo.apiId  
       };
     }else if (res.status == 400) {
      alerts(res.msg);
     this.validateExcelData(res.excelSheetList); 
    } else {
      alerts(res.msg);
    }
   }, Error => {
     alerts("Error While Generating");
   })

}




initializeForm(projectName) {
 this.dbMappingform = this.formbuilder.group({
   projectName: [{ value: projectName, disabled: true }, [Validators.required]],
   versionNo: [{ value: "", disabled: true }, [Validators.required]],
   providerName: [{ value: "", disabled: true }, [Validators.required]],

   moduleName: [{ value: '', disabled: false }, [Validators.required]],
   packageName: [{ value: '', disabled: true }, [Validators.required]],
   PageWindowName: [{ value: '', disabled: false }, [Validators.required]],
   controllerName: [{ value: '', disabled: false }, [Validators.required]],
   serviceName: [{ value: '', disabled: false }, [Validators.required]],
   serviceImplName: [{ value: '', disabled: false }, [Validators.required]],
   daoName: [{ value: '', disabled: false }, [Validators.required]],
   daoImplName: [{ value: '', disabled: false }, [Validators.required]],
   classLevelApiName: [{ value: '', disabled: false }, [Validators.required]],
   projectSourcePath: [{ value: this.sagStudioService.getSagStudioData("autoGeneretedProjectPath"), disabled: false }, [Validators.required]],
   userName: [],
   userId: [],
   projectId: [],
   projectname: [],
   userwrokspace: [],
   menuId: [],
   javaApiType: [],
   modelPackage:[],
   entityPackage:[],
   documentation:[],
   apiId:[{ value: null, disabled: false }],
   apijsonId:[{ value: null, disabled: false }],
   controllerMethodList:[{ value: null, disabled: false }],
   repositoryMethodList:[{ value: null, disabled: false }],
   ngsrcfilePath:[{ value: '', disabled: false }],
})
 
}

setDefaultValueInDbMappingForm(){
 let projectName = this.dbMappingform.controls["projectName"].value;
 projectName=this.convertProjectNameToPackageName(projectName);
 
 const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
 if(sessionStoragedatauserId!=undefined){
   this.dbMappingform.controls["userName"].setValue(sessionStoragedatauserId.data.clientInfo.usrName);
   this.dbMappingform.controls["userId"].setValue(sessionStoragedatauserId.data.clientInfo.usrId);
 
 let setProjectInfo= this.shareService.getDataprotool("selectedProjectChooseData");
 if(setProjectInfo!=undefined){
   this.dbMappingform.controls["projectId"].setValue(setProjectInfo.projectId);
   this.dbMappingform.controls["projectname"].setValue(setProjectInfo.projectname);
   this.dbMappingform.controls["userwrokspace"].setValue(setProjectInfo.jwspace);
   let componentNode=  "src/app.gstr1.component.html";
   if(componentNode){
     //let projectPath=componentNode.projectPath;
   //  let uniqePath=projectPath.replace(setProjectInfo.projectname,"");
     //if(uniqePath.startsWith('/')){
     // uniqePath=uniqePath.replace('/',"");
    // }
    this.dbMappingform.controls["ngsrcfilePath"].setValue(componentNode);
   }
 }
 }else{
   alerts("user not found")
 }
 //  let menuId= this.shareService.getDatadbtool("ComponentMenuId");
 //  if(menuId && menuId!=null && menuId!="" ){
 //   this.dbMappingform.controls["menuId"].setValue(menuId);
 //  }else {
 //    alerts("menu not found")
 //  }
  
 let componentName= this.fileImportExportInfoFormGroup.controls['formName'].value;
 let versionNo= this.fileImportExportInfoFormGroup.controls['versionNo'].value;
 this.dbMappingform.controls["versionNo"].setValue(versionNo);
 let providerName= this.fileImportExportInfoFormGroup.controls['providerName'].value;
 this.dbMappingform.controls["providerName"].setValue(providerName);
 
 // let menuName= this.shareService.getDatadbtool("ComponentMenuName");
 // if(menuName!=undefined && menuName!=null && menuName!=""){
 //   let moduleName=this.convertMenuNameToModuleName(menuName);
 //   this.dbMappingform.controls["moduleName"].setValue(moduleName);
 //   this.onModuleNameChange(moduleName);
 // }else{
 //   if(componentName){
 //     this.dbMappingform.controls["moduleName"].setValue(componentName.toLowerCase());
 //     this.onModuleNameChange(componentName.toLowerCase());
 //   }
 // }
 if(componentName){
   this.dbMappingform.controls["moduleName"].setValue(componentName.toLowerCase());
   this.onModuleNameChange(componentName.toLowerCase());
 }

 if(componentName){
   componentName = componentName+"Report"+providerName+versionNo.replace(/[^\w\s]/gi, '_');
   this.dbMappingform.controls["PageWindowName"].setValue(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
   this.onPageChange(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
  
  // this.onPageNameChange(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
 }

}

convertProjectNameToPackageName(projectName){
 projectName=projectName.replace(/\s/g, "").toLowerCase();
 projectName=projectName.replace(/[^\w\s]/gi, '')
 return projectName;
}
convertMenuNameToModuleName(menuName){
  
 menuName=menuName.replace(/\s/g, "").toLowerCase();
 menuName=menuName.replace(/[^\w\s]/gi, '')
 if(menuName == "return"){
   menuName = menuName+"1"
 }

 return menuName;
}

onModuleNameChange(filedName) {
 if(filedName == "return"){
   filedName = filedName+"1"
 }

 if(filedName==""){
   this.dbMappingform.controls["packageName"].setValue("");
     return;
  }
 let projectName = this.dbMappingform.controls["projectName"].value;
 let versionNo= this.fileImportExportInfoFormGroup.controls['versionNo'].value;
 let providerName= this.fileImportExportInfoFormGroup.controls['providerName'].value;
 

 this.dbMappingform.controls["packageName"].setValue(this._rootPackagePath+"." + projectName.toLowerCase() +".import_export"+ "." + filedName.toLowerCase());  
 //+providerName.toLowerCase()+".v"+versionNo.replace(/\./g,"_"));

 let PageWindowName=this.dbMappingform.controls["PageWindowName"].value;
 if(PageWindowName!=""){
  // this.onPageNameChange(PageWindowName);
 }



}

onPageChange(pageName) {

 if (pageName == "") {
   this.dbMappingform.patchValue({
     controllerName: "",
     serviceName: "",
     serviceImplName: "",
     daoName: "",
     daoImplName: "",
     classLevelApiName: "",
   })
 
   return;
 } else if (pageName != null) {
 
   this.dbMappingform.patchValue({
     controllerName: pageName + "Controller",
     serviceName: pageName + "Service",
     serviceImplName: pageName + "ServiceImpl",
     daoName: pageName + "Dao",
     daoImplName: pageName + "DaoImpl",
     classLevelApiName: pageName.toLowerCase(),
    
   })
   
 }
}

/*****************************************Display Configuration******************************************************************/

gridDynamicForDisplayConfiguration:any;

onClickDisplayConfiguration(){
 this.openDisplayConfigurationModal();
 let item = _.find(this.reportSectionList,{"displayActive":true});
 if(item){
   this.onClickDisplayConfigurationTab(item,null);
 }
}

onClickDisplayConfigurationTab(item: any, index) {
 this.reportSectionList.forEach(itm => itm.displayActive = false);
 item['displayActive'] = true;

 this.displayConfigurationGrid(item['sectionHeaderList']); 
}
okDisplayConfigurationModal(){
 this.closeDisplayConfigurationModal();
}

openDisplayConfigurationModal(){
 $('#displayConfigurationModal').modal('show')
}

closeDisplayConfigurationModal(){
  $('#displayConfigurationModal').modal('hide')
}

displayConfigurationGrid(rowsData) {
 var sourceDiv = document.getElementById("displayConfigurationGridId");
 var columns = [
   {
     "header": "S.No",
     "field": "sno",
     "filter": true,
     "width": "50px",
     "editable": "false",
     "textalign": "center",
     "search": true,
   },
   {
    "header": "Name",
    "field": "name",
    "filter": true,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'label',
    "cellRenderView": false
  },
  {
    "header": "Show Column",
    "field": "isDisplayColumn",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "component": 'checkbox',
    "cellRenderView": true
  },
   {
     "header": "Date Format",
     "field": "dateFormat",
     "filter": true,
     "width": "150px",
     "editable": "false",
     "textalign": "center",
     "search": true,
     "component": 'select',
     "cellRenderView": false
   },
   {
     "header": "Decimal Format",
     "field": "decimalFormat",
     "filter": true,
     "width": "150px",
     "editable": "false",
     "text-align": "center",
     "search": true,
     "component": 'multiSelect',
     "cellRenderView": true
   },
   {
     "header": "Decimal Digit",
     "field": "decimalDigit",
     "filter": true,
     "width": "150px",
     "editable": "false",
     "text-align": "center",
     "search": true,
     "component": 'text',
     "cellRenderView": false
   },
   {
    "header": "Default Value",
    "field": "defaultValue",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  },
  

 ];
 let self = this;
 
 let components = {};
 let numberFormate = [
   { "key": "decimal_format", "val": "Decimal Format" },
   { "key": "round_number", "val": "Round Number" },
  
   
  ];
 


 var SagGridRowStatus = rowsData;
 for (var i = 0; i < SagGridRowStatus.length; i++) {
   SagGridRowStatus[i]["sno"] = i + 1;
 }

 
 if (undefined != sourceDiv) {
   var gridData = {
     columnDef: columns,
     rowDef: SagGridRowStatus,
     menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
     selection: "row",
     frezzManager: { "sno": "left", "name": "left"},
        rowCustomHeight :20,
        cellCustomPadding:5,
     components: components,
     clientSidePagging: true,
     recordPerPage: 20,
     recordNo: true,
     callBack: {},

    multidropDownJson_decimalFormat: numberFormate,
    dropDownJson_dateFormat: this.dateFormateList,
       
    rowGrouping: {
      "enable": true,
      "groupType": "custome",
      "groupBy": "name",
      "expandRow": []
    },
    rowSelection: false,
    rowDataViewTotal: true,
    sml_expandGrid_hide: true,
    exportXlsxPage_hide: true,
    exportXlsxAllPage_hide: true,
    exportPDFLandscape_hide: true,
    exportPDFPortrait_hide: true,
    ariaHidden_hide: true,
    
     
   };
   this.gridDynamicForDisplayConfiguration = SdmtGridT(sourceDiv, gridData, true, true);
  
   this.gridDynamicForDisplayConfiguration.expandAll();

   return this.gridDynamicForDisplayConfiguration;
 }
 }


 /***************************************Manual Code************************************** */

 openManualCode() {
  let selectedRowManualMethod = "";
  let selectedRowData = this.gridDynamicForReportMapping.getSeletedRowData();
  if (selectedRowData && selectedRowData.formulaStaticValue) {
    selectedRowManualMethod = selectedRowData.formulaStaticValue;
  }

  let apiGeneratedObj = this.dbMappingform.getRawValue();
  // let formObj = this.fileImportExportInfoFormGroup.getRawValue();
  // let apiGeneratedObj = _.merge(masterJsonObj, formObj);

  let sheetNameList = this._getAllSheetName();

    const ref = this.dialogService.open(ImportExportManualCodeComponent, {
      header: "Manual Code",
      width: "100%",
      contentStyle: { "margin-top": "0px", "height": "100%" },
      styleClass: "service_full_model excel-demo-view",
      data: { "selectedRowManualMethod" : selectedRowManualMethod, "manualMethodList": this.manualMethodList,
      "sheetNameList":sheetNameList,"type":"REPORT","apiGeneratedObj":apiGeneratedObj  },

    });
    ref.onClose.subscribe((res) => {
      if (res) {
        this.manualMethodList = res;
      }
    });
  }  




_getAllSheetName (){
  let sheetNameList = [ ];
  sheetNameList.push({ "key": "", "val": "--Select--" }); 
 this.reportSectionList.forEach(element => {
  if(element['sectionHeaderList']!=undefined && element['sectionHeaderList'].length > 0){
    let obj = {
       "key":element['name'],
       "val":element['name']
    }
   sheetNameList.push(obj)
  }
  
 });

 return sheetNameList;
}


//***********************************************************Add,Copy,Paste******************************************************************* */

copyPastEllipsisValue = null;
isRecursionOff =false;  

addChildRowSheetMapping(index){
 
  let details = this.reportSectionData['sectionHeaderList'];
  this.isRecursionOff = false;
 this.addRecursionRowForChildren(details,index);
 
 this.sagSheetMappingGrid(this.reportSectionData['sectionHeaderList']);
 this.gridDynamicForReportMapping.expandAll();

}

addRecursionRowForChildren(details,sag_G_Index){
  if(this.isRecursionOff){
    return;
  }
  if(details){
   for (let index = 0; index < details.length; index++) {
     if(this.isRecursionOff){
       break;
     }
     const rowData = details[index];
     if(rowData.details && rowData.details.length > 0){
      this.addRecursionRowForChildren(rowData.details,sag_G_Index)
    }else{
      if(rowData.sag_G_Index == sag_G_Index){
        let arr = [];
        arr.push(this.getEmptyObjForAddRow());
        rowData["details"] = arr;
        this.isRecursionOff = true;
        break;
      };
    }
   }
  }
}

pasteRowSheetMapping(index){
let data = this.copyPastEllipsisValue;

  if(data){
    let details = this.reportSectionData['sectionHeaderList'];
    this.isRecursionOff = false;
    this.addRecursionRow(details,index,data);
 
    this.sagSheetMappingGrid(this.reportSectionData['sectionHeaderList']);
    this.gridDynamicForReportMapping.expandAll();
  }
}


copyRow(ele,param){
  let rowValue = param.rowValue;
  this.copyPastEllipsisValue = JSON.parse(JSON.stringify(rowValue)); 
}

addRowEllipsis(index){
    let details = this.reportSectionData['sectionHeaderList'];
    this.isRecursionOff = false;
    this.addRecursionRow(details,index,this.getEmptyObjForAddRow());
 
    this.sagSheetMappingGrid(this.reportSectionData['sectionHeaderList']);
    this.gridDynamicForReportMapping.expandAll();
}

addRecursionRow(details,sag_G_Index,data){
  if(this.isRecursionOff){
    return;
  }
  if(details){
   for (let index = 0; index < details.length; index++) {
    if(this.isRecursionOff){
      break;
    }
     const rowData = details[index];
     if(rowData.sag_G_Index == sag_G_Index){
      details.splice(index+1, 0,data);

      let allSheetHeaderListSimpleFormat =   this._getApiFieldSimpleFormate(this.reportSectionData['sectionHeaderList']);

      this.autoSetFormula(rowData.sag_G_Index,this.reportSectionData['sectionHeaderList'],allSheetHeaderListSimpleFormat,"add");
      this.isRecursionOff = true;

      this.isRecursionOff = true;
      break;
    }else{
      this.addRecursionRow(rowData.details,sag_G_Index,data)
    };

   }
  }
}



getEmptyObjForAddRow(){
  let obj = {
        "dataBindFrom":"",
        "name": "",
        "formName":"",
        "field":"",
        "fieldProperties":"",
        "tableName":"",
        "tableField":"",
        "tableProperties":"",
        "isMaster":"",
        "excelMaster":"",
        "tableMaster":"",
        "masterColumnName":"",
        "isDisplayColumn":"1",
}
return obj;
}


async deleteRowSheetMapping(rowIndex){
  
  let aliaseUsageHeader = this.checkHeaderAliaseUsage();
  
  let isDeleteRow = false;
 
  if(aliaseUsageHeader){
    if (await ui.confirm('You use this row refrence in '+aliaseUsageHeader+" ! Do you want to delete this row ")) {
      isDeleteRow = true
    }
  } else{
    isDeleteRow = true;
  }
 
  if(isDeleteRow){
    this.deleteRowJsonMappingTree(rowIndex, this.reportSectionData['sectionHeaderList'])
   let allSheetHeaderListSimpleFormat =   this._getApiFieldSimpleFormate(this.reportSectionData['sectionHeaderList']);
 
   this.autoSetFormula(rowIndex,this.reportSectionData['sectionHeaderList'],allSheetHeaderListSimpleFormat,"delete");
 

  this.sagSheetMappingGrid( this.reportSectionData['sectionHeaderList']);
  this.gridDynamicForReportMapping.expandAll();
  }


 
}

deleteRowJsonMappingTree(sag_G_Index,array){

  for (let index = 0; index < array.length; index++) { 
    const element = array[index];
    if(element.details){
      this.deleteRowJsonMappingTree(sag_G_Index,element.details);
     }
     if(element.sag_G_Index == sag_G_Index){
      array.splice(index, 1)
     }
  }
}


reportSectionName:String = "";


openReportSectionNameModal(){
  $('#addReportSectionNameModal').modal('show')
 }

 closeReportSectionNameModal(){
   $('#addReportSectionNameModal').modal('hide')
 }


addReportSection(){
  this.reportSectionName = "";
  this.openReportSectionNameModal();
}
  
  onClickAddReportSectionName(){
    if(!this.reportSectionName){
     alerts("Master name not valid");
    }
    
   let find =  _.find(this.reportSectionList , {"name" : this.reportSectionName});
   if(find){
     alerts(this.reportSectionName+ " Already exist")
     return;
   }

  let reportSectionData = {
    "varriableMappingData": [],
    "type":"fix",
    "varriableMappingType":"table",
    "sectionHeaderList" : [],
    "recordType":"muliple_record",
    "jsonLevel":"",
    "name":this.reportSectionName,
    "relationBeetweenTables":[]
  };
  
    
   this.reportSectionList.push(reportSectionData);
   this.closeReportSectionNameModal();

  }


  async deleteReportSection(){
  if (await ui.confirm('Do You Want To Delete Report Section ?')) {
 
    if(this.reportSectionList){
      for (let index = 0; index < this.reportSectionList.length; index++) {
        const element = this.reportSectionList[index];
        if(element['active']){
          this.reportSectionList.splice(index, 1);
        }
      }
     }
    }
}


validateExcelData(excelSheetList) {
  this.reportSectionList = excelSheetList;

  let item = _.find(this.reportSectionList, { active: true });
  if (item) {
    setTimeout(() => {
      this.onClickReportSection(item, 1);
    }, 100);
  }

}

setValidationRowProperty(rowsData) {

  for (let i = 0; i < rowsData.length; i++) {
    const element = rowsData[i];
    if (element.isInvalid) {
      let colorProperty = { "background-color": "rgb(255, 204, 203)" }
      this.gridDynamicForReportMapping.setRowProperty(element.sag_G_Index, colorProperty);
      let errorResponse = element['toolTipMsg'];
      for (let key in errorResponse) {
        if (errorResponse.hasOwnProperty(key)) {
          let value = errorResponse[key];
          let cellColorProperty = { "background-color": "#dc3545" }
          this.gridDynamicForReportMapping.setColRowProperty(element.sag_G_Index, key, cellColorProperty);
        }
      }
    }
    if (element.details) {
      this.setValidationRowProperty(element.details);
    }
  }

}


/********************* Context Menu ***************************************** */
 
@ViewChild("editSheetTabName", { static: false }) editSheetTabName: ElementRef;
displayContextMenu(event,item){
  if(this.reportSectionData['name'] != item.name){
    this.onClickReportSection(item, 1);
  }
  let self = this;
  event.preventDefault();
  new Contextual({
    isSticky: false,
    items: [
      new ContextualItem({ cssIcon:"fa fa-edit", label: 'Rename', onClick: () => { self.renameSheetName() } }),
      new ContextualItem({ cssIcon:"fa fa-plus", label: 'Add Report Section', onClick: () => { self.addReportSection() } }),
      new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Report Section', onClick: () => { self.deleteReportSection() } }),
    ]
    
  });

}

@HostListener('document:click', ['$event', '$event.target'])
public onClick(event: MouseEvent, targetElement: HTMLElement): void {
    if (!targetElement) {
        return;
    }
    
    if(this.editSheetTabName){
      const clickSheetTabName = this.editSheetTabName.nativeElement.contains(targetElement);
      if (!clickSheetTabName) {
         this.reportSectionData['isRename'] = false;
      }
    }

    if(this.addMasterContextMenu){
          const clickSheetTabName = this.addMasterContextMenu.nativeElement.contains(targetElement);
          if (!clickSheetTabName) {
             let selectedRowData = this.gridDynamicForReportMapping.getSeletedRowData();
             this.gridDynamicForReportMapping.updateCell(selectedRowData.sag_G_Index, "addDisplayMasterColumn", this.addDisplayMasterColumn);
             this.contextmenu = false;
          }
    }
   
}

renameSheetName(){
  this.reportSectionData['isRename'] = true;
}

/********************Context Menu Extra master column select***************************************** */

contextmenu = false;
contextmenuX = 0;
contextmenuY = 0;

addDisplayMasterColumn = [];

openContextMenuForAddDisplayMaster(event,selectedRowData) {
  event.preventDefault();
  this.addDisplayMasterColumn = [];
 
  if(selectedRowData.addDisplayMasterColumn){
    this.addDisplayMasterColumn = selectedRowData.addDisplayMasterColumn
  } 
  
  let masterTableName = selectedRowData.tableMaster;
  if(masterTableName){
     let tableFieldsInfo =  this.masterTableFieldMap.get(masterTableName);
     if(tableFieldsInfo){
    
      tableFieldsInfo.forEach(element => {
        if(element.columnName){
         if(!_.find(this.addDisplayMasterColumn ,{columnName:element.columnName})){
           let obj = element;
           obj['isSelect'] = false;
           obj['columnAliase'] = this._getFieldNameFromCaptionName(element.columnName); 
          this.addDisplayMasterColumn.push(obj);
         };
        }
      });
     }
  }
  this.contextmenuX = event.clientX+1
  this.contextmenuY = event.clientY
  this.contextmenu = true;
}


_getFieldNameFromCaptionName(captionName) {
  let words = captionName.split(/[\W_]+/);
  let builder = '';
  for (let i = 0; i < words.length; i++) {
    let word = words[i];
    if (i === 0) {
      word = word.length === 0 ? word : word.toLowerCase();
    } else {
      word = word.length === 0 ? word : word.charAt(0).toUpperCase() + word.substring(1).toLowerCase();
    }
    builder += word;
  }
  return builder;
}

@ViewChild("addMasterContextMenu", { static: false }) addMasterContextMenu: ElementRef;
 
// @HostListener('document:click', ['$event', '$event.target'])
// public onClick1(event: MouseEvent, targetElement: HTMLElement): void {
 
  
//   if(this.addMasterContextMenu){
//     const clickSheetTabName = this.addMasterContextMenu.nativeElement.contains(targetElement);
//     if (!clickSheetTabName) {
//        let selectedRowData = this.gridDynamicForReportMapping.getSeletedRowData();
//        this.gridDynamicForReportMapping.updateCell(selectedRowData.sag_G_Index, "addDisplayMasterColumn", this.addDisplayMasterColumn);
//        this.contextmenu = false;
//     }
//   }
// }


sub: Subscription;
overlayRef: OverlayRef | null;

close() {
  this.sub && this.sub.unsubscribe();
  if (this.overlayRef) {
    this.overlayRef.dispose();
    this.overlayRef = null;
  }
}


/**************************************Auto set Formula*********************************************************** */


autoSetFormula(rowIndex,gridData,allSheetHeaderListSimpleFormat,opName:String){ 
  //let  gridData =  this.jsonSchema['details'];

  for (let index = 0; index < gridData.length; index++) {
    
     const element = gridData[index];

     if(element.details){
      this.autoSetFormula(rowIndex,element.details,allSheetHeaderListSimpleFormat,opName);
     } else {
      if ("Formula" == element.dataFindFrom) {
        let formulaStaticValue = element.formulaStaticValue;
        if (formulaStaticValue) {
          let replaceValue = this._getCalculateValueBodyForDisplay(allSheetHeaderListSimpleFormat, formulaStaticValue, rowIndex,opName);
          gridData[index]["formulaStaticValue"] = replaceValue;
        }
      }
  
      if ("by_manual_method_with_aliase" == element.dataFindFrom) {
      
        let formulaStaticValue = element.formulaStaticValue;
      
        if (formulaStaticValue) {
          const argument = formulaStaticValue.substring(formulaStaticValue.indexOf("(") + 1, formulaStaticValue.indexOf(")"));
          let replaceArgument = this._getCalculateValueBodyForDisplay(allSheetHeaderListSimpleFormat, argument, rowIndex,opName);
          const methodName = formulaStaticValue.substring(0, formulaStaticValue.indexOf("("));
          const changeMethod = `${methodName}(${replaceArgument})`;
          gridData[index]["formulaStaticValue"] = changeMethod;
        }
      }
     }
  }
  }

  


  _getCalculateValueBodyForDisplay(sheetHeaderList, formulaStaticValue,rowIndex,opName:String) {
    let split = formulaStaticValue.split(/[^\w\s]/gi);
  
    let list = split.slice();

    list  = _.map(list,_.trim)

    list.sort((a, b) => b.length - a.length);
  
    let number = 0;
    for (let value of list) {
      if (this.isValidFormulaAliase(formulaStaticValue, value)) {
        let findAny = sheetHeaderList.find(ele => value === ele.headerAlias);
        if (findAny) {
          if(rowIndex < findAny.sag_G_Index){
            number++;
            formulaStaticValue = formulaStaticValue.replace(value, `%${number}$s`);
          }
         
        }
      }
    }
  
    let replaceNumber = 0;
    for (let value of list) {
      if (this.isValidFormulaAliase(formulaStaticValue, value)) {
        let findAny = sheetHeaderList.find(ele => value === ele.headerAlias);
        if (findAny) {
          if(rowIndex < findAny.sag_G_Index){
          replaceNumber++;
          let replaceIndex = findAny.sag_G_Index + 2;
          if("delete" == opName){
            /***sag_g_index not change because grid not load ***** */
            replaceIndex = findAny.sag_G_Index 
          } 

          let replaceValue = this.sheetHeaderAlias[replaceIndex];
          formulaStaticValue = formulaStaticValue.replace(`%${replaceNumber}$s`, replaceValue);
          }
        }
      }
    }
    return formulaStaticValue;
  }
  
   isValidFormulaAliase(formula, value) {
    let isValid = this.isAlphabet(value);
    if (isValid) {
      if (formula.includes(`'${value}'`) || formula.includes(`"${value}"'`) || value.trim() === "null") {
        return false;
      }
    }
    return isValid;
  }
  
   isAlphabet(value) {
    return /^[a-zA-Z]+$/.test(value);
  }
  
   checkHeaderAliaseUsage(){
    let selectedRowData = this.gridDynamicForReportMapping.getSeletedRowData();
    let selectedRowHeaderAlias = selectedRowData.headerAlias;

    let useAliaseList = new Map(); 
    let gridData =  this.reportSectionData['sectionHeaderList'];

    this.fillAliaseUsageHeader(gridData,useAliaseList);

    let aliaseUsageHeader =   useAliaseList.get(selectedRowHeaderAlias);
 
    return aliaseUsageHeader;

  }

  fillAliaseUsageHeader(gridData,useAliaseList){
    gridData.forEach(element => {
   
       if(element.details){
        this.fillAliaseUsageHeader(element.details,useAliaseList);
       } else{
        if("Formula" == element.dataFindFrom){
          let formulaStaticValue = element.formulaStaticValue;
          if(formulaStaticValue){
            let split = formulaStaticValue.split(/[^\w\s]/gi);
            let list = split.slice();
            list  = _.map(list,_.trim)
            if(list){
              list.forEach(al => {
                useAliaseList.set(al, element['name']); 
              });
           }
          }
         }
     
         if("by_manual_method_with_aliase" == element.dataFindFrom){
          let formulaStaticValue = element.formulaStaticValue;
          if(formulaStaticValue){
            const argument = formulaStaticValue.substring(formulaStaticValue.indexOf("(") + 1, formulaStaticValue.indexOf(")"));
           
            let split = argument.split(/[^\w\s]/gi);
            let list = split.slice();
            list  = _.map(list,_.trim)
            if(list){
              list.forEach(al => {
                useAliaseList.set(al, element['name']);
              });
           }
          }
         }
       }
    });

     
  }

  /************Simple format ***************** */

  _getApiFieldSimpleFormate(apiFieldList) {
    const treeDetails = JSON.parse(JSON.stringify(apiFieldList)); 
    const simpleDetails = [];
  
    treeDetails.forEach(obj => {
      if (!Object.prototype.hasOwnProperty.call(obj, "details")) {
        simpleDetails.push(obj);
      } else if (Object.prototype.hasOwnProperty.call(obj, "details")) {
        const details = obj.details;
        this.convertDataTreeToList(simpleDetails, details);
      }
    });
  
    return simpleDetails;
  }
  
  convertDataTreeToList(simpleDetails, treeDetails) {
    treeDetails.forEach(obj => {
      if (!Object.hasOwnProperty.call(obj, "details")) {
        simpleDetails.push(obj);
      } else if (Object.hasOwnProperty.call(obj, "details")) {
        let details = obj.details;
        this.convertDataTreeToList(simpleDetails, details);
      }
    });
  }



/*******************************User Rights ******************************************************** */
  
gridDynamicapiAlreadyAssign:any
isAccessToCreateNewPackageGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Name",
    field: "packageName",
    filter: true,
    width: "300px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Path",
    field: "packagePath",
    filter: true,
    width: "300px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()",
  },
  
];
isCreateFileToAnotherUserGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Name",
    field: "srcFilePath",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "User Name",
    field: "userName",
    filter: true,
    width: "168px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()",
  },
  
];
isAccessToCreateNewFileGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Name",
    field: "packageName",
    filter: true,
    width: "400px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
 
  
];
isAccessToCreateNewApiColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Name",
    field: "fileName",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
  
];

isAccessToModifyApiColumn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Path",
    field: "srcfileUniqePath",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
  
];

accessRightErrorMsg=""

isUserValid = false;

displayPopupForRights(flag,res) {
  if (res.isValid) {
    this.isUserValid = true;
  } else {
    this.isUserValid = false;
    if(flag){
      if(res.status == 401){
        this.accessRightErrorMsg = res.msg;
        $("#apiAlreadyAssignId").modal('show');
        this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewPackageGridColmn);
      } else  if(res.status == 402){
        this.accessRightErrorMsg = res.msg;
        $("#apiAlreadyAssignId").modal('show');
        this.apiAlreadyAssignGrid(res.data,this.isAccessToModifyApiColumn);
      }else  if(res.status == 403){
        this.accessRightErrorMsg = res.msg;
        $("#apiAlreadyAssignId").modal('show');
        this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewFileGridColmn);
      }else if(res.status == 404){
        this.accessRightErrorMsg = res.msg;
        $("#apiAlreadyAssignId").modal('show');
        this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewApiColmn);
      } else{
       alerts(res.msg)
      }
     }
   
  }
}


apiAlreadyAssignGrid(rowsData,columns) {
const sourceDiv = document.getElementById("apiAlreadyAssignIdGrid");

var self = this;

let SagGridRowStatus = rowsData;
for (let i = 0; i < SagGridRowStatus.length; i++) {
  SagGridRowStatus[i]["sno"] = i + 1;
}

if (undefined != sourceDiv) {
  var gridData = {
    columnDef: columns,
    rowDef: SagGridRowStatus,
    menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
    selection: "row",
    components: {},
    clientSidePagging: true,
    recordPerPage: 20,
    recordNo: true,
   
  };
  this.gridDynamicapiAlreadyAssign = SagGridMPT(sourceDiv, gridData, true, true);
  this.setColorOnGrid1();
}
}

setColorOnGrid1() {
let self = this;
let gridRowsData = self.gridDynamicapiAlreadyAssign.sagGridObj.originalRowData;
gridRowsData.forEach((ele, index) => {
  // change Row Color
  if (ele.apiName || ele.apiType || ele.assignTo || ele.assignBy) {
    self.gridDynamicapiAlreadyAssign.setColRowProperty(index, 'srcFilePath', { "background": "#fff8e1" });
    self.gridDynamicapiAlreadyAssign.setColRowProperty(index, 'userName', { "background": "#f8d7da" });
  }
});

}


isGeneratedFileValid:boolean = false;
isCreatedFileValid(flag) {
  let masterJsonObj = this.dbMappingform.getRawValue();
  let formObj = this.fileImportExportInfoFormGroup.getRawValue();
  let jsonObj = _.merge(masterJsonObj, formObj);

    this.autoJavacodeService.isCreatedFileValid(jsonObj,"report_export").subscribe(res => {
      this.isGeneratedFileValid = res.isValid;
    if (!res.isValid) {
      alerts(res.msg)
    } 
  }, Error => {
    alerts("Error While validate generated file");
  });
  
}

/*****************TABLE FIELD WITH CUSTOM KEY ************************** */
getTableInfoWithCustomKeys(res, tableName) {
  let tableFields = [];

  if (res) {
    res.forEach(tableColumn => {
      let tableFieldInfo = {};
      tableFieldInfo['columnName'] = tableColumn['name'];
      tableFieldInfo['pkey'] = tableColumn['pkey'];
      tableFieldInfo['fkey'] = tableColumn['fkey'];
      tableFieldInfo['dataType'] = tableColumn['type'];
      tableFieldInfo['entityColumn'] = tableColumn['entitylabel'];
      tableFieldInfo['tableName'] = tableName;

      tableFieldInfo['parentTable'] = tableColumn['parenttbl'];
      tableFieldInfo['dbColumnSize'] = tableColumn['size'];
      tableFieldInfo['uniquecol'] = tableColumn['uniquecol'];
      tableFieldInfo['entityName'] = tableColumn['entityName'];
      tableFieldInfo['pkeyName'] = tableColumn['pkeyName'];

      tableFields.push(tableFieldInfo);
    });
  }
  return tableFields;
}

getTableProperties(item):String{
  if(item){
    return item.dataType+"("+item.dbColumnSize+")";
  }
 return ""
}


}
