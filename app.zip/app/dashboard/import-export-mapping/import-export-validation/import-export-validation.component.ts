import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { ApiServiceService } from 'src/app/services/http/api-service.service';
import { ToastService } from 'src/app/core/services/toast.service';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
declare var SagButton
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-import-export-validation',
  templateUrl: './import-export-validation.component.html',
  styleUrls: ['./import-export-validation.component.scss'],
  providers: [DialogService]
})
export class ImportExportValidationComponent implements OnInit,OnDestroy {

  columnType ="";


  addNewValidationForm:FormGroup
  submitted = false;
  item: any;
  validationAddList: any = [];
  addMsgList: boolean = false;
  listOfValidation: any;

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService,
    private _apiService: ApiServiceService, 
    public toast: ToastService,) { }

  ngOnInit() {
    this.initializeForm();

    if(this.config.data){
      if(this.config.data.validation){
        this.validationAddList = this.config.data.validation.filter(ele=>(typeof ele) == 'object' );
      }
      if(this.config.data.columnType){
        this.columnType = this.config.data.columnType;
      }
    }

    this.getvalidationList();
   
   
    this.validationselecteddata(this.validationAddList);
  }

  ngOnDestroy() { }


  

 initializeForm(){
   this.addNewValidationForm = this.formbuilder.group({
     validation: ['', Validators.required],
     valMsg: ['', Validators.required],
     valRegex: ['', Validators.required],
     valDesc: [''],
     valCode: ['', Validators.required]
   });
 }


 projectValidation : any=[];

 upDateMsg: any;
 addNewMsgFun() {
   this.upDateMsg = this.gridDynamicObj_messagegrid.getSeletedRowData();

   this.addNewValidationForm.patchValue({
     validation : this.upDateMsg.label,
     valMsg : this.upDateMsg.msg,
     valRegex : this.upDateMsg.pattern,
     valCode : this.upDateMsg.id
   })
  
   $("#exampleModal").modal('show');
 }

 addNewFun() {
  this.addNewValidationForm.value.validation =''
  this.addNewValidationForm.value.valMsg =''
  this.addNewValidationForm.value.valRegex =''
  $("#exampleModal").modal('show');
}


 saveNewMsg() {
  this.projectValidation=[]
  this.submitted = true;
  let selectProject = this.shareService.getDataprotool("selectedProjectChooseData");
  let add_new = {
    projectId: selectProject.projectId,
    projectName: selectProject.projectname,
    rule:  this.addNewValidationForm.value.valRegex,
    message: this.addNewValidationForm.value.valMsg,
    valName:  this.addNewValidationForm.value.validation,
    desc: this.addNewValidationForm.value.valDesc,
    vcode:  this.addNewValidationForm.value.valCode
  }
  this.upDateMsg = {}
  if(this.addNewValidationForm.valid){
    this._apiService.prjValidator(add_new).subscribe((res) => {
      if (res['status'] == 'success') {
        this.projectValidation = add_new
        this.toast.launch_toast({
          type: 'success',
          position: 'top-right',
          message: res['msg'],
        });
      } else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'top-right',
          message: res['msg'],
        });
      }
     
      this.getvalidationList();
    });
  }else{
    this.addNewValidationForm.markAllAsTouched()
    this.toast.launch_toast({
      type: 'alert',
      position: 'top-right',
      message: 'Please fill required fields',
    });
  }
}



getvalidationList() {
    
  let project = this.shareService.getDataprotool("selectedProjectChooseData");
  let pro_data = {
    projectId: project.projectId,
    projectName: project.projectname
  }
  this._apiService.allValidationOfList(pro_data).subscribe((res) => {
    this.listOfValidation = res;
    this._filterValidationByType();
    this.messagegrid();
  });
}

_filterValidationByType(){
  if(!this.columnType){
    this.rowData_messagegrid = [];
    return ;
  }

  if("STRING" == this.columnType.toUpperCase()){
     this.rowData_messagegrid =  this.listOfValidation;
  }
  
  if("NUMERIC" == this.columnType.toUpperCase() || "INTEGER" == this.columnType.toUpperCase() || "NUMBER" == this.columnType.toUpperCase()){
    this.rowData_messagegrid = _.filter(this.listOfValidation,ele=>{
      if(ele.vCode == "REQ" 
      || ele.vCode == "DGT"
      || ele.vCode == "NMC"
      || ele.vCode == "MNV"
      || ele.vCode == "MXV"){
        return true;
      }
      return false;
    })
  }
  
  if("BOOLEAN" == this.columnType.toUpperCase()){
    this.rowData_messagegrid = _.filter(this.listOfValidation,ele=>{
      if(ele.vCode == "REQ"){
        return true;
      }
      return false;
    })
  }

  if("DATE" == this.columnType.toUpperCase()){
    this.rowData_messagegrid = _.filter(this.listOfValidation,ele=>{
      if(ele.vCode == "REQ"){
        return true;
      }
      return false;
    })
  }
 

}


gridData_messagegrid: any;
gridDynamicObj_messagegrid: any;
columnData_messagegrid: any = [
  {
    "header": "S.no",
    "field": "sno",
    "filter": true,
    "width": "20px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "freezecol": "null",
    "columngroup": "",
    "hidden": false,
    "checkboxLabel": false,
    "sort": false,
    "cellHover": false,

  },
 
  {
    "header": "Validation",
    "field": "label",
    "filter": true,
    "width": "10%",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "freezecol": "null",
    "columngroup": "",
    "hidden": false,
    "checkboxLabel": false,
    "sort": false,
    "cellHover": false,

  },
  {
    "header": "message",
    "field": "msg",
    "filter": true,
    "width": "20%",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "freezecol": "null",
    "columngroup": "",
    "hidden": false,
    "checkboxLabel": false,
    "sort": false,
    "cellHover": false,

  },
  {
    "header": "Regular expression",
    "field": "pattern",
    "filter": true,
    "width": "50%",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "freezecol": "null",
    "columngroup": "",
    "hidden": false,
    "checkboxLabel": false,
    "sort": false,
    "cellHover": false,

  },
  {
    "header": "Action",
    "field": "pattern",
    "filter": true,
    "width": "6%",
    "editable": "false",
    "text-align": "left",
    "cellRenderView": "buttonIcon",
    "button": {
      "text": "",
      "imgsrc": "",
      "iconclass": "fas fa-plus",
      "position": "After",
    }
  }


];

rowData_messagegrid: any = [];
messagegrid(rowData?, colData?) {
  let self = this;
  this.gridData_messagegrid = {
    columnDef: colData ? colData : this.columnData_messagegrid,
    rowDef: rowData ? rowData : this.rowData_messagegrid,
    footer_hide: false,
    totalNoOfRecord_hide: false,
    sml_expandGrid_hide: false,
    exportXlsxPage_hide: false,
    exportXlsxAllPage_hide: false,
    exportPDFLandscape_hide: false,
    exportPDFPortrait_hide: false,
    ariaHidden_hide: false,
    disableAllSearch: false,
    workBreak: false,
    workBreakHeader: false,
    cellHover: false,
    rowHover: false,
    rowBorder_hide: false,
    columnBorder_hide: false,
    header_hide: false,
    common_search: false,
    common_search_column: "",
    gridbody_hide: false,
    rowCustomHeight :20,
    cellCustomPadding:5,

    components: {
           
      "buttonIcon": new SagButton({}, function (ele, params) {
        ele.onclick = function () {
          self.addValidation(params)
        };
      })
    },
    callBack: {
      
      "onRowClick": function () {
        self.addNewValidationForm.value.validation =''
        self.addNewValidationForm.value.valMsg =''
        self.addNewValidationForm.value.valRegex =''
        self.onmessagegridClick();
      },
       
    },


    
    header: {
      style: { "background-color": "#ececec" },

    },



  };

  let sourceDiv = document.getElementById("messagegrid");
  this.gridDynamicObj_messagegrid = SagGridMPT(sourceDiv, this.gridData_messagegrid, true, true);
}

addValidation(addData) {
  const userExists = this.validationAddList.some(val => val.id === addData.rowValue.id);
  if (userExists) {
    this.toast.launch_toast({
      type: 'alert',
      position: 'top-right',
      message: `${addData.rowValue.label} validation is already exist!!!`,
    });
    return
  } else {
    this.validationAddList.push(addData.rowValue);
  }
  this.validationselecteddata(this.validationAddList);
}



gridData_validationselecteddata: any;
gridDynamicObj_validationselecteddata: any;
columnData_validationselecteddata: any = [
  {
    "hidden": false,
    "editable": "false",
    "filter": true,
    "search": true,
    "component": "label",
    "field": "sno",
    "freezecol": "null",
    "width": "45px",
    "header": "S.No",
    "text-align": "left",
  },
  // {
  //   "header": "Local",
  //   "field": "localVal",
  //   "filter": true,
  //   "width": "50px",
  //   "editable": "false",
  //   "text-align": "center",
  //   "flag_localVal": false,
  //   "search": true,
  //   "component": "checkboxLabel",
  //   "cellRenderView": true,
  //   "freezecol": "null",
  //   "hidden": false,
  //   "sort": false,
  //   "cellHover": false,
  // },
  {
    "header": "Action",
    "field": "action",
    "filter": true,
    "width": "50px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "buttonIcon",
    "cellRenderView": true,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,
    "button": { "imgsrc": "", "iconclass": "fas fa-trash", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-danger"], "attribute": "", "styles": "" },

  },  
  {
    "header": "Validation",
    "field": "label",
    "filter": true,
    "width": "130px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "label",
    "cellRenderView": true,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,
    "styles":{
      "padding-left": "5px",
    }

  },
  {
    "header": "message",
    "field": "msg",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "label",
    "cellRenderView": false,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,

  },
  {
    "header": "Regular expression",
    "field": "pattern",
    "filter": true,
    "width": "300px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "label",
    "cellRenderView": false,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,

  },
  {
    "header": "Value",
    "field": "vidValue",
    "filter": true,
    "width": "120px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "text",
    "cellRenderView": false,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,

  }
  
];

rowData_validationselecteddata: any = [

];

validationselecteddata(rowData?, colData?) {
  let self = this;
  
  this.gridData_validationselecteddata = {
    columnDef: colData ? colData : this.columnData_validationselecteddata,
    rowDef: rowData ? rowData : this.rowData_validationselecteddata,
    footer_hide: false,
    totalNoOfRecord_hide: false,
    sml_expandGrid_hide: false,
    exportXlsxPage_hide: false,
    exportXlsxAllPage_hide: false,
    exportPDFLandscape_hide: false,
    exportPDFPortrait_hide: false,
    ariaHidden_hide: false,
    disableAllSearch: false,
    workBreak: false,
    workBreakHeader: false,
    cellHover: false,
    rowHover: false,
    rowBorder_hide: false,
    columnBorder_hide: false,
    header_hide: false,
    common_search: false,
    common_search_column: "",
    gridbody_hide: false,
    rowCustomHeight :20,
    cellCustomPadding:5,

    rowGrouping: {
      "enable": true,
      "allowClick": true,
      "groupType": "custome",
      "groupBy": "label",
      "expandRow": [],
      "StopExpandCollapse": [3]
  },
    components: {
      
    },
    callBack: {

      "onButtonIcon_action": function (ele, params) {
        self.removeValidation(params)
     },
      
    },
    
    

  };
  
  let sourceDiv = document.getElementById("validationselecteddata");
  this.gridDynamicObj_validationselecteddata = SdmtGridT(sourceDiv, this.gridData_validationselecteddata, true, true);
}


removeValidation(removeData) {
  const index = this.validationAddList.indexOf(removeData.rowValue);
  this.validationAddList.splice(index, 1);
  this.validationselecteddata(this.validationAddList);
}

 


onmessagegridClick() {
  this.addMsgList = true
}
 

 close(){
  this.submitted = false
  this.addNewValidationForm.reset()
  $("#exampleModal").modal('hide')

}

applyValidation(){
  if(this.isValidData(this.validationAddList)){
    this.modalRef.close(this.validationAddList);
    this.ngOnDestroy();
  } else{
    alerts("Please fill validation value");
  }
 
}


isValidData(validationAddList){
 let isValid = true;
 validationAddList.forEach(element => {
  if('MNL'== element.id || 'MXL'== element.id || 'MNV'== element.id || 'MXV'== element.id || 'FXL'== element.id ){
    if(!element.vidValue){
      isValid = false;
      let colorProperty = { "background-color": "rgb(255, 204, 203)" }
      this.gridDynamicObj_validationselecteddata.setRowProperty(element.sag_G_Index, colorProperty);
      let cellColorProperty = { "background-color": "#dc3545" }
      this.gridDynamicObj_validationselecteddata.setColRowProperty(element.sag_G_Index, "vidValue", cellColorProperty);
    }
  } 
 }); 

 return isValid;
}


onClose() {
  this.modalRef.close();
  this.ngOnDestroy();
 }

}
