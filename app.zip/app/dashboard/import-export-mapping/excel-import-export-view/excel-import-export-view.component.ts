import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogService } from 'primeng/api';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { SagShareService } from 'src/app/services/sagshare.service';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-excel-import-export-view',
  templateUrl: './excel-import-export-view.component.html',
  styleUrls: ['./excel-import-export-view.component.scss']
})
export class ExcelImportExportViewComponent implements OnInit {

  classLevelApiName = "";
  rootUrl = "http://localhost:7778";
  //rootUrl = "http://192.168.2.118:9090/gengst";
  fileType = "";
  isDisplayExportInvalidButton : boolean = true;
  isLoadDataButtonDisplay :boolean  = false;

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService,
    public _router: Router,
    public activatedRoute: ActivatedRoute) { }

  ngOnInit() {
     this.activatedRoute["params"].subscribe(params => {
      this.classLevelApiName = params['api-name'];
      this.fileType = params['file-type'];
    if("excel" == this.fileType){
      this.isDisplayExportInvalidButton = true;
    }else if("json" == this.fileType){
      this.isDisplayExportInvalidButton = false;
    }

    });
   
  }

  
  viewFile;
  gridDynamicForViewExcelDemo;
  
  viewfileChange(event) {
    let fileList: FileList = event.target.files;
    if (fileList && fileList.length > 0) {
      this.viewFile =  fileList[0];
    } else {
      this.viewFile =  null;
    }
  }
  
  viewExcelData ;
  viewSheetNameList = [];
  viewExcelMasterData;
  viewExcelProperties;
  viewGridColumn ;
  isViewGridDisplay :boolean = false;
  selectedViewSheet ="";
  viewDBMasterData:[]
  tempId;
  importExportType = "All";
  totalViewTime = "00:00:00:0000";
  importDataType ="delete_all_exiting_record_then_import_all_record";
  importSheetList = [];
  importSheetDropDownList = [];
  

  uploadFile(){
    if(this.viewFile){
      let formData = new FormData();
      formData.set('file', this.viewFile);
      let url = `${this.rootUrl}/${this.classLevelApiName}/file-upload`;

      this.autoJavacodeService.callImportExportApi(formData,url).subscribe(res => {
        if (res.success) {
          this.tempId = res.data;
          this.isLoadDataButtonDisplay = true;
        } else {
          alerts(res.message);
        }
      }, Error => {
        alerts("Error While upload file"); 
      });
  

    }else{
      alerts("Please select file ");
    }

  }

  loadData(){
    this.resetTime();
    this.viewSheetNameList = [];
    this.importSheetList = [];
    this.importSheetDropDownList = [];
    this.importExportType = "All";
    if(this.viewFile){
      this.startTimer();
      this.closeRequestJsonModal();
      this.isViewGridDisplay = true;
      let reqObj = {};
      if(this.requestJsonObj){
        reqObj = JSON.parse(this.requestJsonObj);
      }else{
        reqObj = {};
      }
     
      let url = `${this.rootUrl}/${this.classLevelApiName}/get-sheet-data/${this.tempId}`;
      this.autoJavacodeService.callImportExportApi(reqObj,url).subscribe(res => {
        this.closeTimer();
        this.totalViewTime =  this.totalTimeDisplay
        if (res.success) {
         
          this.viewExcelData = res.data.data;
          this.viewExcelMasterData = res.data.excelMasterData;
          this.viewDBMasterData = res.data.dbMasterData;
          this.viewExcelProperties = res.data.property;
          this.viewSheetNameList = res.data.sheetNames;
          this.tempId = res.data.tempId;

          res.data.sheetNames.forEach(element => {
            let obj = {
              "value": element,
              "label": element,
            }
            this.importSheetList.push(element);
            this.importSheetDropDownList.push(obj);
          });
          

          if(this.viewSheetNameList){
            this.selectedViewSheet = this.viewSheetNameList[0];
            this.onChaneViewSheetName(this.viewSheetNameList[0]);
          }
         
        } else {
          alerts(res.message);
        }
      }, Error => {
        this.closeTimer();
        this.totalViewTime =  this.totalTimeDisplay
        alerts("Error While fetching data"); 
      });
  
    }else{
      alerts("Please select file ");
    }
   }
  
   onChaneViewSheetName(sheetName){
    if(sheetName){
  
      this.isViewGridDisplay = true;
      this.setSrNoColum();
       let gridProperties =  this.viewExcelProperties[sheetName]['gridProperties'];
       
       let dropDownList = [];
       gridProperties.forEach(ele => {
        let component = ele['isMaster'] ? "select" : "text"
        this.viewGridColumn.push({
          "header": ele['gridHeaderName'],
          "field": ele['headerName'],
          "filter": true,
          "width": "200px",
          "editable": "false",
          "text-align": ele['textAlign'],
          "search": true,
          "component": component,
          "cellRenderView": false
        })
  
        if(ele['isMaster']){
        let masterData =   this.viewExcelMasterData[ele['master']];
        if(!masterData){
          masterData =   this.viewExcelMasterData[ele['master']+("_"+sheetName)]; 
        }
        let masterDropdown = [{ "key": "", "val": "--Select--" }];
        masterData.forEach(element => {
          let obj = {
            "key": element['excelMaster'],
            "val": element['excelMasterDesc']
          }
          masterDropdown.push(obj);
        });
   
        let obj = {};
        obj["name"] = "dropDownJson_"+ele['headerName'],
        obj["value"] = masterDropdown,
        
        dropDownList.push(obj)
        }
  
       });
        
       let rowData = this.viewExcelData[sheetName]['data'];
       if(this.importExportType == "Valid"){
        rowData =   _.filter(rowData, ele => ele.isValid);
       }else if(this.importExportType == "Invalid"){
        rowData =  _.filter(rowData, ele => !ele.isValid);
       }
       this.viewExcelDemoGrid(rowData,dropDownList);
       this.disableColumn(sheetName);
  
    }else{
      this.isViewGridDisplay = false; 
    }
   }
  
   setSrNoColum(){
    this.viewGridColumn = [];
    this.viewProceedGridColumn = [];
    this.viewGridColumn = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      }
    ];
    this.viewProceedGridColumn = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      }
    ];
   }
  
  
   viewExcelDemoGrid(rowsData,dropDownList) {
    var sourceDiv = document.getElementById("viewExcelDemoGridId");
  
    let self = this;
  
    let components = {};
  
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
      SagGridRowStatus[i]["toolTipMsg"] =  SagGridRowStatus[i]["errorResponse"]
    }
  
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: this.viewGridColumn,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        rowCustomHeight :30,
        recordNo: true,
        callBack: {},
      };
  
      dropDownList.forEach(ele => {
        gridData[ele['name']] =ele['value'] 
      });
  
      this.gridDynamicForViewExcelDemo = SdmtGridT(sourceDiv, gridData, true, true);
      this.setRowProperty(rowsData)
      return this.gridDynamicForViewExcelDemo;
    }
  }
  
 disableColumn(sheetName){
  let gridProperties =  this.viewExcelProperties[sheetName]['gridProperties'];
  gridProperties.forEach(ele => {
    let isModify = ele.isModify;
    if(!isModify){
      this.gridDynamicForViewExcelDemo.disableColumn(ele.headerName);
    }
    
  });


 }

  setRowProperty(rowsData){
    
    for (let i = 0; i < rowsData.length; i++) {
      const element = rowsData[i];
      if(element.isValid){
        let colorProperty = {"background-color":"rgb(50 189 211)"}
        this.gridDynamicForViewExcelDemo.setRowProperty(i,colorProperty);
       
      }else{
        let colorProperty = {"background-color":"rgb(255, 204, 203)"}
        this.gridDynamicForViewExcelDemo.setRowProperty(i,colorProperty);
        let errorResponse = element['errorResponse'];
        for (let key in errorResponse) {
          if (errorResponse.hasOwnProperty(key)) {
              let value = errorResponse[key];
              let cellColorProperty = {"background-color":"rgb(255, 0, 0)"}
              this.gridDynamicForViewExcelDemo.setColRowProperty(i, key, cellColorProperty);
          }
      }
      }
    }
  
  }
  
  validateData(){
    this.viewSheetNameList = [];
    let selectedRowData = this.gridDynamicForViewExcelDemo.getSeletedRowData();
    if(!selectedRowData){
     alerts("please select row");
     return;
    }
    let reqObj = {};
    if(this.requestJsonObj){
      reqObj = JSON.parse(this.requestJsonObj);
    }else{
      reqObj = {};
    }
      let obj = {};
      obj[this.selectedViewSheet] = [this.gridDynamicForViewExcelDemo.getSeletedRowData()]; 

      reqObj['sheetData'] = obj;
  
      let url = `${this.rootUrl}/${this.classLevelApiName}/validate-sheet-data/${this.tempId}`; 

      this.autoJavacodeService.callImportExportApi(reqObj,url).subscribe(res => {
        if (res.success) {
          this.viewExcelData = res.data.data;
          this.viewExcelMasterData = res.data.excelMasterData;
          this.viewDBMasterData = res.data.dbMasterData;
          this.viewExcelProperties = res.data.property;
          this.viewSheetNameList = res.data.sheetNames;
          this.tempId = res.data.tempId;
          res.data.sheetNames.forEach(element => {
            let obj = {
              "value": element,
              "label": element,
            }
            this.importSheetList.push(element);
            this.importSheetDropDownList.push(obj);
          });
          if(this.viewSheetNameList){
            this.selectedViewSheet = this.viewSheetNameList[0];
            this.onChaneViewSheetName(this.viewSheetNameList[0]);
          }
         
        } else {
          alerts(res.message);
        }
      }, Error => {
        alerts("Error While fetching data"); 
      });
  
   
  }
  
  onChaneImportExportType(){
    this.onChaneViewSheetName(this.selectedViewSheet);
  }
  
  viewProceedExcelData ;
  viewProceedSheetNameList = [];
  viewProceedExcelMasterData;
  viewProceedExcelProperties;
  selectedViewProceedSheet = "";
  gridDynamicForViewProceedExcelDemo:any;
  viewProceedGridColumn ;
  totalProceedTime = "00:00:00:0000";
  totalInsertTime = "00:00:00:0000";
  totalTimeFormate = "00:00:00:0000";
  isProceedData = false;
  totalTime=0;
  
  processSheetData(){
    this.isProceedData = true;
    this.viewProceedExcelDemoGrid([],[]);
    this.startTimer();

    let reqObj = {};
    if(this.requestJsonObj){
      reqObj = JSON.parse(this.requestJsonObj);
    }
    reqObj["importType"] = this.importDataType;
    reqObj["sheetNames"] = this.importSheetList;
   
      let url = `${this.rootUrl}/${this.classLevelApiName}/proceed-sheet-data/${this.tempId}`; 
      this.autoJavacodeService.callImportExportApi(reqObj,url).subscribe(res => {
        this.closeTimer();
        this.totalProceedTime =  this.totalTimeDisplay
        if (res.success) {
          this.viewProceedExcelData = res.data.data;
          this.viewProceedExcelProperties = res.data.property;
          this.viewProceedSheetNameList = res.data.sheetNames;
          if(this.viewSheetNameList){
            this.selectedViewProceedSheet = this.viewSheetNameList[0];
            this.onProceedViewSheetName(this.viewSheetNameList[0]);
          }
  
        } else {
          alerts(res.message);
        }
      }, Error => {
        this.closeTimer();
        this.totalProceedTime =  this.totalTimeDisplay
        alerts("Error While fetching data"); 
      });
  }
  
  requestJsonObj = "";
  openRequestJsonModal(){
    $('#requestJsonModal').modal('show');
  }

  closeRequestJsonModal(){
    $('#requestJsonModal').modal('hide')
  }

  importSheetData(){
    let reqObj = {};
    if(this.requestJsonObj){
      reqObj = JSON.parse(this.requestJsonObj);
    }
    reqObj["importType"] = this.importDataType;
    reqObj["sheetNames"] = this.importSheetList;
    
   
    this.startTimer();
   
      let url = `${this.rootUrl}/${this.classLevelApiName}/write-sheet-data/${this.tempId}`; 
      this.autoJavacodeService.callImportExportApi(reqObj,url).subscribe(res => {
        this.closeTimer();
        this.totalInsertTime =  this.totalTimeDisplay
        if (res.success) {
          success(res.message);
        } else {
          alerts(res.message);
        }
      }, Error => {
        this.closeTimer();
        this.totalInsertTime =  this.totalTimeDisplay
        alerts("Error While fetching data"); 
      });
  }
  
  onProceedViewSheetName(sheetName){
    this.setSrNoColum();
    let gridProperties =  this.viewProceedExcelProperties[sheetName]['gridProperties'];
    
    let dropDownList = [];
    gridProperties.forEach(ele => {
     let component = "label"
     this.viewProceedGridColumn.push({
       "header": ele['gridHeaderName'],
       "field": ele['headerName'],
       "filter": true,
       "width": "200px",
       "editable": "false",
       "text-align": ele['textAlign'],
       "search": true,
       "component": component,
       "cellRenderView": false
     })
  });
  let rowData = this.viewProceedExcelData[sheetName];
  this.viewProceedExcelDemoGrid(rowData,dropDownList);
  
  }
  
  viewProceedExcelDemoGrid(rowsData,dropDownList) {
    var sourceDiv = document.getElementById("viewExcelProceedDemoGridId");
  
    let self = this;
  
    let components = {};
  
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }
  
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: this.viewProceedGridColumn,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        rowCustomHeight :30,
        recordNo: true,
        callBack: {},
      };
  
      dropDownList.forEach(ele => {
        gridData[ele['name']] =ele['value'] 
      });
  
      this.gridDynamicForViewProceedExcelDemo = SdmtGridT(sourceDiv, gridData, true, true);
     // this.setRowProperty(rowsData)
      return this.gridDynamicForViewProceedExcelDemo;
    }
  }

  exportValidInvalidData(){
   let url = `${this.rootUrl}/${this.classLevelApiName}/export-valid-invalid-data/${this.tempId}/${this.importExportType}`; 
   let reqObj = {};
   if(this.requestJsonObj){
     reqObj = JSON.parse(this.requestJsonObj);
   }else{
     reqObj = {};
   }

      this.autoJavacodeService.callImportExportApi(reqObj,url).subscribe(res => {
     
        if (res.success) {
          let fileName = res.data;
          let url1 = `${this.rootUrl}/${this.classLevelApiName}/file-download?fileName=${fileName}`; 
          window.location.href = url1;
          success(res.message);
        } else {
          alerts(res.message);
        }
      }, Error => {
        alerts("Error While export data"); 
      });

     
   
  }
  
  
  
  resetTime(){
    this.totalTimeDisplay="00:00:00:0000" ;
    this.totalViewTime="00:00:00:0000" ;
    this.totalProceedTime="00:00:00:0000" ;
    this.totalInsertTime="00:00:00:0000" ;
    this.totalTimeFormate="00:00:00:0000" ;
    this.time = 0;
    this.totalTime = 0;
  }
  
  time: number = 0;
  totalTimeDisplay="00:00:00:0000" ;
  interval;
  
  startTimer() {
    this.totalTimeDisplay="00:00:00:0000" ;
    const startTime = Date.now() - (this.time || 0);
    this.interval = setInterval(() => {
      this.time = Date.now() - startTime;
      
      this.totalTimeDisplay=this.transform( this.time) 
      
      
    },0);
  }
  transform(time: number): string {
    var milliseconds = ''+ Math.floor((time % 1000) );
    var seconds = ''+Math.floor((time / 1000) % 60);
    var minutes = ''+Math.floor((time / (1000 * 60)) % 60);
    var hours = ''+Math.floor((time / (1000 * 60 * 60)) % 24);
  
    if (Number(hours) < 10) {
      hours = '0' + hours;
    } else {
      hours = '' + hours;
    }
    if (Number(minutes) < 10) {
      minutes = '0' + minutes;
    } else {
      minutes = '' + minutes;
    }
    if (Number(seconds) < 10) {
      seconds = '0' + seconds;
    } else {
      seconds = '' + seconds;
    }
  
   return hours + ':' + minutes + ':' + seconds+':'+milliseconds;
  }
  closeTimer() {
    clearInterval(this.interval);
    this.totalTime = this.totalTime + this.time 
    this.time = 0;
    this.totalTimeFormate =  this.transform(this.totalTime);
  }

  flagFalse(){
    this.isLoadDataButtonDisplay =false;
    this.isViewGridDisplay = false;
  }

}
