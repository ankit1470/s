import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExcelImportExportViewComponent } from './excel-import-export-view.component';


const routes: Routes = [
  {
    path : "import-export-view",
    component : ExcelImportExportViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExcelImportExportViewRoutingModule { }
