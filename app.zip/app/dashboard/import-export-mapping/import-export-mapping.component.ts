import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { FileImportExportMappingComponent } from './file-import-export-mapping/file-import-export-mapping.component';
import { ImportExportVarriableComponent } from './import-export-varriable/import-export-varriable.component';
import { JavaApiGeneratorComponent } from '../java-api-generator/java-api-generator.component';

declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-import-export-mapping',
  templateUrl: './import-export-mapping.component.html',
  styleUrls: ['./import-export-mapping.component.scss'],
  providers: [DialogService]
})
export class ImportExportMappingComponent implements OnInit,OnDestroy {

  
 
  gridDynamicForSoftwareForm: any;
 

  softwareFormFormGroup: FormGroup;
  submittedSoftwareForm: boolean = false;


  softwareList = [];
 

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
     ) { }


  ngOnInit() {
    this.getSoftwareList();
    this.initializeFormGroup();
    this.sagSoftwareFormGrid([]);
  }

  ngOnDestroy() { }

  initializeFormGroup() {

    this.softwareFormFormGroup = this.formbuilder.group({
      softwareName: [{ value: '', disabled: false }],
      softwareId: [{ value: null, disabled: false }, [Validators.required]],
      formName: [{ value: '', disabled: false }, [Validators.required]],
      softwareFormId: [{ value: '', disabled: false }],
    });

  }


  getSoftwareList() {
 
    this.autoJavacodeService.getSoftwareList().subscribe(res => {
      if (res.status == 200) {
        this.softwareList = res.data;
        const setProjectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
        if (setProjectInfo && setProjectInfo.jwspace) {
          const projectId = setProjectInfo.projectId
          this.softwareFormFormGroup.controls['softwareId'].setValue(projectId);
          this.getSoftwareFormList(projectId);
        }
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }





  getSoftwareFormList(softwareId) {
    if (!softwareId) {
      this.sagSoftwareFormGrid([]);
      return;
    }

    this.softwareFormFormGroup.controls['softwareId'].setValue(Number(softwareId));

    this.autoJavacodeService.getSoftwareFormList(softwareId).subscribe(res => {
      if (res.status == 200) {
        this.sagSoftwareFormGrid(res.data);
      } else {
        this.sagSoftwareFormGrid([]);
      }
    }, Error => {
      this.sagSoftwareFormGrid([]);
      alerts("Error While Fetching Data");
    });

  }

  async deleteSoftwareForm() {
    let selectedRowData = this.gridDynamicForSoftwareForm.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row");
      return;
    }
    let conf = await ui.confirm("Do You Want To Delete Software Form ? ");
    if (!conf) {
      return;
    }

    let softwareFormId = selectedRowData.softwareFormId;

    this.autoJavacodeService.deleteSoftwareForm(softwareFormId).subscribe(res => {
      if (res.status == 200) {
        success(res.msg)
        this.getSoftwareFormList(this.softwareFormFormGroup.controls['softwareId'].value);
      }
    }, Error => {
      alerts("Error While Deleting Data");
    });
  }

  saveFormName() {
    if (!this.softwareFormFormGroup.valid) {
      alerts("Data not valid")
      return;
    }
    this.autoJavacodeService.saveSoftwareForm(this.softwareFormFormGroup.getRawValue()).subscribe(res => {
      if (res.status == 200) {
        success(res.msg);
        this.getSoftwareFormList(this.softwareFormFormGroup.controls['softwareId'].value);
        this.softwareFormFormGroup.controls['formName'].setValue('');
        this.onCloseAddForm();
      } else {
        alerts(res.msg);
      }
    }, Error => {
      alerts("Error While saving data");
    });

  }

  modifySoftwareForm() {

    let selectedRowData = this.gridDynamicForSoftwareForm.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row")
      return;
    }
    this.onClickAddForm();

    this.softwareFormFormGroup.patchValue(selectedRowData);

  }


  sagSoftwareFormGrid(rowsData) {
    var sourceDiv = document.getElementById("sagSoftwareFormGrid");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Software Name",
        "field": "softwareName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "Form Name",
        "field": "formName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },


    ];
    let self = this;

    let components = {};

    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        rowCustomHeight :20,
        cellCustomPadding:5,
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowDbleClick": function () {
            self.onClickFileMappingInfo();
          }
        }
      };
      this.gridDynamicForSoftwareForm = SdmtGridT(sourceDiv, gridData, true, true);
      return this.gridDynamicForSoftwareForm;
    }
  }

  formNameDisplay="";
  onClickFileMappingInfo() {
    this.formNameDisplay="";
    if (!this.shareService.getDatadbtool("finalDataForConnection")) {
      alerts("DataBase Connection are not established")
      return;
    }

    let selectedRowData = this.gridDynamicForSoftwareForm.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row")
      return;
    }

    this.formNameDisplay = "("+selectedRowData.formName+")";
    this.openFileImportExportMapping(selectedRowData);
  }

  openFileImportExportMapping(selectedRowData){
    const ref = this.dialogService.open(FileImportExportMappingComponent, {
      header: "File Mapping Info"+this.formNameDisplay,
      width: "100%",
      contentStyle: {"margin-top": "0px", "height": "100%" },
      styleClass: "service_full_model excel-demo-view",
      data: selectedRowData
    });
    ref.onClose.subscribe((res) => {
  
    });
  }

  onClickAddForm() {

    this.softwareFormFormGroup.patchValue({
      "softwareName":"",
      "formName":"",
      "softwareFormId":"",
    })

    $('#addFormModal').modal('show')
  }

  onCloseAddForm() {
    $('#addFormModal').modal('hide')
  }



//********************************************Varriable  MAPPING****************************************************************************** */

openImportExportVarriableMapping(){

  if (!this.shareService.getDatadbtool("finalDataForConnection")) {
    alerts("DataBase Connection are not established")
    return;
  }

  let selectedRowData = this.gridDynamicForSoftwareForm.getSeletedRowData();
  if (!selectedRowData) {
    alerts("Please select row");
    return;
  }

  this.formNameDisplay = "("+selectedRowData.formName+")";

  const ref = this.dialogService.open(ImportExportVarriableComponent, {
    header: "Varriable Mapping "+this.formNameDisplay,
    width: "100%",
    contentStyle: {"margin-top": "0px", "height": "100%" },
    styleClass: "service_full_model excel-demo-view",
    data : selectedRowData,
  });
  ref.onClose.subscribe((res) => {

  });
}

onClose() {
  this.modalRef.close();
  this.ngOnDestroy();
 }

 /********************** Java Api Tool ******************************** */
 openJavaApiGenerateTool(){

  const ref = this.dialogService.open(JavaApiGeneratorComponent, {
    header: "Java Api Tool",
    width: "100%",
    contentStyle: { "margin-top": "0px", "height": "100%" },
    styleClass: "service_full_model excel-demo-view",
    data: {},

  });
  ref.onClose.subscribe((res) => {
    if (res) {
    }
  });

}


}
