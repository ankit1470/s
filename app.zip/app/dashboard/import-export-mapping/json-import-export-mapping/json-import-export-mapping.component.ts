import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy, ViewChild, ElementRef, HostListener } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { Router } from '@angular/router';
import { ImportExportValidationComponent } from '../import-export-validation/import-export-validation.component';
import { ImportExportManualCodeComponent } from '../import-export-manual-code/import-export-manual-code.component';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $, Contextual, ContextualItem;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-json-import-export-mapping',
  templateUrl: './json-import-export-mapping.component.html',
  styleUrls: ['./json-import-export-mapping.component.scss'],
  providers: [DialogService]
})
export class JsonImportExportMappingComponent implements OnInit,OnDestroy {

  copyPastEllipsisValue = null;
  isRecursionOff =false; 
  gridDynamicAddMasterExtraColumn:any

  fileImportExportInfoFormGroup: FormGroup;

  classLevelApiName="gstr1json"

  tableFieldDropdownListForJson = [];
  tableFieldsMapForJson = new Map();
  masterTableFieldDropdownListForJson = [];
  masterTableFieldMapForJson = new Map();
  jsonSchemaList;
  gridDynamicForJsonMapping;
  sheetHeaderNameDropdown = [{ "key": "", "val": "--Select--" }]
  jsonSheetDataList = {};
  excelSheetListForJsonMapping = [];
  importExcelMasterList = [];
  jsonSchema = {
    "excelSheetName":"",
    "importDataInsertType":[],
    "varriableMappingData": [],
    "jsonType":"",
    "varriableMappingType":"table",
    "tableRelations":[],
  }; 
  
  dataFindFromForJson = [
    { "key": "", "val": "--Select--" },
    { "key": "_sheet", "val": "JSON" },
    { "key": "client_side", "val": "Client Side" },
    { "key": "Formula", "val": "Formula" },
    { "key": "by_manual_method_with_aliase", "val": "Manual Method With Aliase" },
    { "key": "by_manual_method", "val": "Manual Method With static" },
    { "key": "static_value", "val": "Static Value" },
    { "key": "static_master_code", "val": "Static Unique code" },
   ];
  
  angularFormLabelListForJson = [];
  angularFormLabelDropdownListForJson = [];
  angularformFieldsMapForJson = new Map();

  importDataInsertType = [
    { "value": "import_only_non_existing_record", "label": "Import only non existing record" },
    { "value": "overwrite_the_exiting_record", "label": "Overwrite the exiting record" },
    { "value": "delete_all_exiting_record_then_import_all_record", "label": "Delete all exiting record"},
   ];


  excelSheetList=[];
  excelManualMethod = [];

  allTableList = [];
  tableListDropdownList = [{ "key": "", "val": "--Select--" }];

  validationList;
  dropdownValidationList = [];
 
  angularFormDropdownList = [{ "key": "", "val": "--Select--" }]
  angularFormList = []
  manualMethodList=[];
  tableMasterDropdownForSheetMapping = [];

  variabelModuleDropdropdownList = [];
  variabelModuleList = [];
  sheetHeaderAlias = {};

  excelMasterDropdownForSheetMapping = [];
  excelMasterForSheetMapping = [];

  isExcelMappingImport : boolean = true;

  dateFormateList = [];
  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService,
    public _router: Router,) { }

  ngOnInit() {

    this.initializeFormGroup(); 
    this.getDateFormateList();

    if(this.config.data){
      this.fileImportExportInfoFormGroup.patchValue(this.config.data);
      this.isExcelMappingImport = "EXCEL"==this.config.data['viceVersaFileType']
    }

    this.setApiGeneratedInfo();

    this.getExcelMasterForSheetMapping(false);
    this.getMasterMapping(false);

    if(this.isExcelMappingImport){
      this.getExcelFileInfo();
      this.getExcelMasterForImport();
    }
  
    this.getAllTableList();
    this.getValidationList();
    this.getFormList();
    this.getVariableImpExpModuleListForSheetMapping();
    this.getSheetHeaderAlias();
   
    this.jsonSheetDataList = {};
  
    this.getJsonSchemaData();
    this.jsonMappingGrid([],'dynamic');
    this.isCreatedFileValid(false);
   }

   
  getDateFormateList() {
    this.dateFormateList = [];
    this.autoJavacodeService.getDateFormateList().subscribe(res => {
      if (res.status == 200) {
        this.dateFormateList = res.data;
        
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

   ngOnDestroy() { }

   initializeFormGroup() {

    this.fileImportExportInfoFormGroup = this.formbuilder.group({
      mappingId: [{ value: '', disabled: false }],
      softwareName: [{ value: '', disabled: false }],
      softwareId: [{ value: null, disabled: false }],
      formName: [{ value: '', disabled: false }],
      softwareFormId: [{ value: '', disabled: false }, [Validators.required]],
      file: [{ value: '', disabled: false }],
      fileName: [{ value: '', disabled: false }, [Validators.required]],
      type: [{ value: '', disabled: false }, [Validators.required]],
      fileType: [{ value: '', disabled: false }, [Validators.required]],
      providerId: [{ value: '', disabled: false }, [Validators.required]],
      providerName:[{ value: '', disabled: false }],
      noOfSheet: [{ value: '', disabled: false }, [Validators.required]],
      versionNo: [{ value: '', disabled: false }, [Validators.required]],
      fileExtention: [{ value: '', disabled: false }, [Validators.required]],
      fromDate: [{ value: '', disabled: false }, [Validators.required]],
      toDate: [{ value: '', disabled: false }, [Validators.required]],
      dataInsertType: [{ value: 'hibernate_query', disabled: false }],
      databaseType: [{ value: 'mysql', disabled: false }],
      viceVersaId: [{ value: '', disabled: false }],
      viceVersaFileType: [{ value: '', disabled: false }],
    });
  }

  getExcelFileInfo() {
  let mappingId = this.fileImportExportInfoFormGroup.controls["viceVersaId"].value;
    this.excelSheetList = [];
    this.excelManualMethod = [];

    if(mappingId){
      this.autoJavacodeService.getExcelFileInfo(mappingId).subscribe(res => {
        if (res.status == 200) {
          let data = res.data;
          let excelData = data.excelSheetList;
          excelData.forEach(element => {
            if("multiMixSheet"==element.type){
              let excelChildSheet = element.excelChildSheet;
              if(excelChildSheet){
                excelChildSheet.forEach(childElement => {
                  this.excelSheetList.push(childElement);
                });
              }

            }else{
              this.excelSheetList.push(element);
            }
            
          });

          
          this.excelManualMethod = data.manualMethodList;
        
        }
      }, Error => {
        alerts("Error While Fetching info");
      });
    }
  }

  getExcelMasterForImport(){
    let mappingId = this.fileImportExportInfoFormGroup.controls["viceVersaId"].value;
  
    this.autoJavacodeService.getMasterMapping(mappingId, 'master', 1).subscribe(res => {
      if (res.status == 200) {
        this.importExcelMasterList = res.data
        
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  getAllTableList() {
     this.tableListDropdownList = [];
    this.allTableList = [];

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
    }
    this._dbcomparetoolService.tblstrcturedrpdown(dbData).subscribe((res) => {
      if (res) {
        let masterdropdown = res['masterdropdown'];
        let mtbllist = masterdropdown.mtbllist.sort();
        this.allTableList = masterdropdown.mtbllist.sort();
        this.getTableDropdownNameForJson(mtbllist);
        this.getTableDropdownNameForMaster();
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }

  getTableDropdownNameForMaster() {
    this.tableMasterDropdownForSheetMapping = [{ "key": "", "val": "--Select--" }];
  this.allTableList.forEach(table => {
    let obj = {
     "key":table,
     "val":table
    }
    this.tableMasterDropdownForSheetMapping.push(obj);
  });
  }

  getValidationList() {
    this.dropdownValidationList = [];
    this.autoJavacodeService.getValidationList().subscribe(res => {
      if (res.status == 200) {
        this.validationList = res.data;
        this.getValidationDropdown(res.data);
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  getValidationDropdown(validationList) {
    this.dropdownValidationList = []
    validationList.forEach((ele) => {
      let obj = {
        key: ele.validationCode,
        val: ele.validationName
      };
      this.dropdownValidationList.push(obj);
    })
  }

  getFormList() {
    const setProjectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    this.angularFormList = [];
    if (setProjectInfo && setProjectInfo.jwspace) {
      const projectId = setProjectInfo.projectId

      this.autoJavacodeService.getFormList(projectId).subscribe(res => {
        if (res.status == 200) {
          this.angularFormList = res.data;
          this.getFormDropDownListForJson(res.data);
        }
      }, Error => {

        alerts("Error While Fetching Data");
      });
    } else {
      alerts('please setPath in workspace Configuration')
    }

  }

  getVariableImpExpModuleListForSheetMapping() {
    this.variabelModuleDropdropdownList = [];
    this.variabelModuleList = []; 
    let softwareFormId = this.fileImportExportInfoFormGroup.controls['softwareFormId'].value;
    if (softwareFormId) {
      this.autoJavacodeService.getVariableImpExpModuleListForSheetMapping(softwareFormId).subscribe(res => {
        if (res.status == 200) {
          this.variabelModuleList = res.data;
        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
    }
  }

  getSheetHeaderAlias() {
 
    this.autoJavacodeService.getSheetHeaderAlias().subscribe(res => {
      if (res.status == 200) {
        this.sheetHeaderAlias = res.data;
      }else{
        this.sheetHeaderAlias = {}
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

setSheetListForJsonMapping(){
  this.excelSheetListForJsonMapping = [];
  this.excelSheetList.forEach(element => {
    this.excelSheetListForJsonMapping.push(element.name);
  });
}



getJsonSchemaData(){
  let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;
  this.jsonSchemaList = [];

  this.autoJavacodeService.getJsonSchemaData(mappingId).subscribe(res => {
    if (res.status == 200) {
      let data = res.data;
      this.jsonSchemaList = data.excelSheetList;
      this.manualMethodList = data.manualMethodList;
      this.setSheetListForJsonMapping();
      if (res.isModify) {
        let item = _.find(this.jsonSchemaList, { active: true });
        if (item) {
          setTimeout(() => {
          this.onClickJsonObject(item, 1);
          }, 100);

        }
      }
    }
  }, Error => {
    alerts("Error While Fetching Data");
  });
}

onClickJsonObject(item: any, index) {

  this.jsonSchema = item;

  

if(!this.jsonSchema['dataFindFrom']){
  this.jsonSchema['dataFindFrom'] = JSON.parse(JSON.stringify(this.dataFindFromForJson))
}

this.manageExcelSheetStateForJson(true);  

this.jsonSchemaList.forEach(itm => itm.active = false);
this.jsonSchemaList.forEach(itm => itm.isRename = false);

item['active'] = true;

this.onChangeSheetNameForJson(item['excelSheetName'] ,false );

setTimeout(() => {
  this.jsonMappingGrid(item.details,this.jsonSchema.jsonType);
  try {
    this.gridDynamicForJsonMapping.expandAll();
  } catch (error) {
    
  }
 }, 100);

setTimeout(() => {
   this.manageExcelSheetStateForJson(false);  
}, 500);


setTimeout(() => {
  let gridData = this.gridDynamicForJsonMapping.getGridData();
  this.bindSheetDataForJson(gridData);
}, 500);


  
}

saveFileImportExportMappingJson() {
  let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;

  if (mappingId == '' || mappingId == null || mappingId == undefined || this.jsonSchemaList == undefined || this.jsonSchemaList == null || this.jsonSchemaList == '') {
    alerts("Data not valid")
    return;
  }

  let obj = {
    "mappingId": mappingId,
    "excelSheetList": this.jsonSchemaList,
    "manualMethodList": this.manualMethodList ? this.manualMethodList : [],
    "type":"JSON"
  }

  this.autoJavacodeService.saveFileImportExportMappingJson(obj).subscribe(res => {
    if (res.status == 200) {
      success(res.msg);
    }else if (res.status == 400) {
      alerts(res.msg);
     this.validateExcelData(res.excelSheetList); 
    } else {
      alerts(res.msg);
    }
  }, Error => {
    alerts("Error While saving data");
  });
}

onChangeJSONType(type){
  this.jsonMappingGrid(this.jsonSchema['details'],type);
  this.gridDynamicForJsonMapping.expandAll();
}

jsonMappingGrid(rowsData,type) {
var sourceDiv = document.getElementById("jsonMappingGridId");
var columns = [
  {
    "header": "S.No",
    "field": "sno",
    "filter": true,
    "width": "50px",
    "editable": "false",
    "textalign": "center",
    "search": true,
  },
  {
    "header": "Name",
    "field": "name",
    "filter": true,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  },
  {
    "header": "Description",
    "field": "description",
    "filter": true,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'label',
    "cellRenderView": false
  },
  {
    "header": "Header Alias",
    "field": "headerAlias",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'label',
    "cellRenderView": true
  },
  {
    "header": "Sheet Header Name",
    "field": "sheetHeaderName",
    "filter": true,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  
  {
    "header": "Data Find From",
    "field": "dataFindFrom",
    "filter": true,
    "width": "170px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  
  {
    "header": "Column Type",
    "field": "type",
    "filter": true,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Date Format",
    "field": "dateFormat",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  // {
  //   "header": "Validation",
  //   "field": "validation",
  //   "filter": true,
  //   "width": "200px",
  //   "editable": "false",
  //   "textalign": "center",
  //   "search": true,
  //   "component": 'multiSelect',
  //   "cellRenderView": true
  // },
  // {
  //   "header": "Minimum Length",
  //   "field": "minLength",
  //   "filter": true,
  //   "width": "200px",
  //   "editable": "false",
  //   "textalign": "center",
  //   "search": true,
  //   "component": 'text',
  //   "cellRenderView": false
  // },
  // {
  //   "header": "Max Length",
  //   "field": "maxLength",
  //   "filter": true,
  //   "width": "200px",
  //   "editable": "false",
  //   "textalign": "center",
  //   "search": true,
  //   "component": 'text',
  //   "cellRenderView": false
  // },
  {
    "header": "Form Name",
    "field": "formName",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Field",
    "field": "field",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Field Properties",
    "field": "fieldProperties",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "cellRenderView": true,
    "component": 'label',
  },
  {
    "header": "Table Name",
    "field": "tableName",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "left",
    "search": true,
    "component": 'select',
    // "component": 'selectSearch', 
    "cellRenderView": false
  },
  {
    "header": "Table Field",
    "field": "tableField",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Table Properties",
    "field": "tableProperties",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'label',
    "cellRenderView": true
  },
  {
    "header": "Is Master",
    "field": "isMaster",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "JSON Master",
    "field": "excelMaster",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Table Master",
    "field": "tableMaster",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Master Column Name",
    "field": "masterColumnName",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Unique Constraint",
    "field": "uniqueConstraint",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "component": 'checkbox',
    "cellRenderView": true
  },
  {
    "header": "Formula/Static Value/Method Calling",
    "field": "formulaStaticValue",
    "filter": true,
    "width": "250px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  },
  {
    "header": "Export By",
    "field": "importBy",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "component": 'checkbox',
    "cellRenderView": true
  },
  {
    "header": "Export Type",
    "field": "exportTypeInEquals",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Group By",
    "field": "groupBy",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "component": 'checkbox',
    "cellRenderView": true
  },
  {
    "header": "Function",
    "field": "aggregateFunction",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  },
  {
    "header": "Validation",
    "field": "validationtfield",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'button',
    "cellRenderView": true,
    button:{"name":"Validation",visibility:true,classes: ['btn','btn-primary'],
    styles: { 'padding': '0px !important', 'font-size': '20px !important' }},
  }

];

let tableRow = {
  "header": "Table Row",
  "field": "tableRow",
  "filter": true,
  "width": "150px",
  "editable": "false",
  "textalign": "center",
  "search": true,
  "component": 'text',
  "cellRenderView": false
};
if("fix_child_key_wise" == type){
  columns.splice(4, 0, tableRow);
}

if("client_details" == type){
 columns = _.filter(columns,ele=>{
   if(ele.field == "sno" 
   || ele.field == "name" 
   || ele.field == "description"  
   || ele.field == "dataFindFrom"
   || ele.field == "formulaStaticValue"){
     return true;
   }
   return false;
 })
}

if("table" == this.jsonSchema.varriableMappingType){
  columns = _.filter(columns,ele=>{
    if(ele.field == "formName" 
    || ele.field == "field" 
    || ele.field == "fieldProperties"){
      return false;
    }
    return true;
  })
}

if(!this.excelSheetListForJsonMapping || this.excelSheetListForJsonMapping.length == 0){
  columns = _.filter(columns,ele=>{
    if(ele.field == "sheetHeaderName"){
      return false;
    }
    return true;
  })
}

let fieldTypeList = [
  { "key": "", "val": "--Select--" },
  { "key": "number", "val": "Decimal Number" },
  { "key": "string", "val": "String" },
  { "key": "integer", "val": "Number" },
  { "key": "boolean", "val": "Boolean" },
  { "key": "object", "val": "Object" },
  { "key": "array", "val": "Array" },

];

let self = this;

let isMaster = [
  { "key": "", "val": "--Select--" },
  { "key": "Y", "val": "Yes" },
  { "key": "N", "val": "No" },
 ];
 

 let aggregateFunctionList = [
  { "key": "", "val": "--Select--" },
  { "key": "sum", "val": "SUM" },
  
 ];

 let exportTypeInEqualsList = [
  { "key": "", "val": "" },
  { "key": "equalsOperator", "val": "EQUAL" },
  { "key": "inOperator", "val": "IN" },
 ];

let components = {};

var SagGridRowStatus = rowsData;
for (var i = 0; i < SagGridRowStatus.length; i++) {
  SagGridRowStatus[i]["sno"] = i + 1;
}
this.aliaseStartIndex = 0;
this.setAliaseNameInGrid(rowsData);

if (undefined != sourceDiv) {
  var gridData = {
    columnDef: columns,
    rowDef: SagGridRowStatus,
    menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
    selection: "row",
    frezzManager: { "sno": "left", "name": "left","description":"left","headerAlias":"left" , "sheetHeaderName":"left"},
    rowCustomHeight :20,
    cellCustomPadding:5,
    components: components,
    clientSidePagging: true,
    recordPerPage: 20,
    recordNo: true,
    callBack: {
      "onChangeSelect_formName": function (ele, params) {
        self.onChangeFormNameInGridForJson(ele.value, params.rowIndex,null)
      },
      "onChangeSelect_field": function (ele, params) {
        self.onChangeFormFieldNameInGrid(ele.value, params);
      },

      "onChangeSelect_sheetHeaderName": function (ele, params) {
        self.onChangeJsonsheetHeaderName(ele.value, params)
      },
      "onChangeSelect_isMaster": function (ele, params) {
        self.setDisableEnableMasterColumnForJson(ele.value,params.rowIndex);
      },
      "onCheckBox_importBy": function (ele, params) {
        if("1" == params.rowValue.importBy  || "true" == params.rowValue.importBy ){
         self.gridDynamicForJsonMapping.enableCell(params.rowIndex, "exportTypeInEquals");
        }else{
          self.gridDynamicForJsonMapping.updateCell(params.rowIndex, "exportTypeInEquals",'');
          self.gridDynamicForJsonMapping.disableCell(params.rowIndex, "exportTypeInEquals");
        }
      },

      "onChangeSelect_dataFindFrom": function (ele, params) {
        self.setDisableEnableColumnTypeForJson(ele.value,params.rowIndex);
        self.setColorByDataFindFrom(ele.value, params.rowIndex)
      },
        "onChangeSelect_tableName": function (ele, params) {
        //"onChangeSearchSelect_tableName": function (ele, params) {
        let value = ele.value;
        ele.onkeydown = function (event) {
          if (event.keyCode == 13) {
             self.fillTableNameSameValueForJson(params, value);
          }
        }
        self.onChangeTableForJson(ele.value, params.rowIndex,null);
        self.setTableNameIntoDataBindFromForJson(ele.value);
      },
      "onChangeSelect_tableField": function (ele, params) {
        self.onChangeTableFieldForJson(ele.value, params);
      },
      "onChangeSelect_tableMaster": function (ele, params) {
        self.onChangeMasterTableForJson(ele.value, params.rowIndex,null);
      },

      "onChangeSelect_masterColumnName": function (ele, params) {
        self.onChangeMasterTableFieldForJson(ele.value, params.rowValue.tableMaster,params.rowIndex)
      },
      "onChangeSelect_type": function (ele, params) {
        self.onChangeSheetColumnType(ele.value, params.rowIndex)
      },
      "onChangeSelect_excelMaster": function (ele, params) {
        self.onChangeExcelMasterField(ele.value, params)
      },
   
      "onButton_validationtfield": function (ele, params) {
        self.onClickValidation(params);
      },

      "cellCallBack": function (param) {
        let ele = param.ele;
        ele.addEventListener('contextmenu', event => {
          event.preventDefault();
          self.gridDynamicForJsonMapping.setRowSelected(param.rowIndex);
          new Contextual({
            isSticky: false,
            items: [
              new ContextualItem({ cssIcon:"fa fa-plus", label: 'Insert Row', onClick: () => {self.addRowEllipsis(param.rowIndex); } }),
              new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Row', onClick: () => {self.deleteRowJsonMapping(param.rowIndex); } }),
              new ContextualItem({ cssIcon:"fa fa-copy", label: 'Copy Row', onClick: () => { self.copyRow(ele,param) } }),
              new ContextualItem({ cssIcon:"fa fa-paste", label: 'Paste Row', onClick: () => {  self.pasteRowSheetMapping(param.rowIndex) } }),
              new ContextualItem({ cssIcon:"fa fa-child", label: 'Add Master Extra Column', onClick: () => { self.addExtraMasterField(param.rowIndex); } }),
                         ]
          });
        });
      }

    },

   
    dropDownJson_formName: this.angularFormDropdownList,
    dropDownJson_field: [{ "key": "", "val": "--Select--" }],
    dropDownJson_sheetHeaderName: this.sheetHeaderNameDropdown,
    //multidropDownJson_validation: this.dropdownValidationList,
    dropDownJson_isMaster: isMaster,
    dropDownJson_tableMaster: this.tableMasterDropdownForSheetMapping,
    dropDownJson_excelMaster: this.excelMasterDropdownForSheetMapping,
    dropDownJson_masterColumnName: [{ "key": "", "val": "--Select--" }],
    dropDownJson_dateFormat:this.dateFormateList,
    dropDownJson_tableName: this.tableListDropdownList,
    //selectSearchdropDownJson_tableName: this.tableListDropdownList,
    dropDownJson_type: fieldTypeList,
    dropDownJson_aggregateFunction:aggregateFunctionList,
   
    dropDownJson_tableField: [{ "key": "", "val": "--Select--" }],
    dropDownJson_dataFindFrom: this.jsonSchema['dataFindFrom'], 
    dropDownJson_exportTypeInEquals: exportTypeInEqualsList,

    rowGrouping: {
      "enable": true,
      "groupType": "custome",
      "groupBy": "name",
      "expandRow": []
    },
    rowSelection: false,
    rowDataViewTotal: true,
    sml_expandGrid_hide: true,
    exportXlsxPage_hide: true,
    exportXlsxAllPage_hide: true,
    exportPDFLandscape_hide: true,
    exportPDFPortrait_hide: true,
    ariaHidden_hide: true,
    
  };
  this.gridDynamicForJsonMapping = SdmtGridT(sourceDiv, gridData, true, true);
  this.setColorPropertiesForJson(this.gridDynamicForJsonMapping.getGridData());
  this.disableMasterCell(this.gridDynamicForJsonMapping.getGridData());
  this.disableExportTypeInEquals(this.gridDynamicForJsonMapping.getGridData());
  this.disableColumnTypeCell(this.gridDynamicForJsonMapping.getGridData());
  this.setRowColor(this.gridDynamicForJsonMapping.getGridData());

  this.setValidationRowProperty(rowsData); 
  return this.gridDynamicForJsonMapping;
}
}

setRowColor(gridData){
   
  gridData.forEach(rowData => {
   if(rowData.details){
      this.setRowColor(rowData.details);
    }else{
      this.setColorByDataFindFrom(rowData.dataFindFrom,rowData.sag_G_Index)
    }
 });
}

setColorByDataFindFrom(dataFindFrom,sag_G_Index){ 
  if ("_sheet" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(153, 235, 255)" }
    this.gridDynamicForJsonMapping.setRowProperty(sag_G_Index, colorProperty);
  }
  if ("client_side" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(153, 255, 179)" }
    this.gridDynamicForJsonMapping.setRowProperty(sag_G_Index, colorProperty);
  }
  if ("Formula" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(255, 255, 153)" }
    this.gridDynamicForJsonMapping.setRowProperty(sag_G_Index, colorProperty);
  } if ("by_manual_method_with_aliase" == dataFindFrom || "by_manual_method" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(148, 184, 175)" }
    this.gridDynamicForJsonMapping.setRowProperty(sag_G_Index, colorProperty);
  } if ("static_value" == dataFindFrom || "static_master_code" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(214, 194, 194)" }
    this.gridDynamicForJsonMapping.setRowProperty(sag_G_Index, colorProperty);
  }
}

onChangeExcelMasterField(excelMaster, params){
  if(excelMaster){
   let item = _.find(this.excelMasterForSheetMapping, { "name": excelMaster });
   if(item){
     this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableMaster", item.tableName);
     this.onChangeMasterTableForJson(item.tableName, params.rowIndex,item.nameTableColumn);
   }
  }
  }

setDisableEnableColumnTypeForJson(value,rowIndex){
  if(value == "_sheet"){
    this.gridDynamicForJsonMapping.disableCell(rowIndex, "type");
  } else {
    this.gridDynamicForJsonMapping.enableCell(rowIndex, "type"); 
  }
}

disableColumnTypeCell(gridData){
  
  gridData.forEach(rowData => {

    if(rowData.details){
      this.disableColumnTypeCell(rowData.details)
    }else{
      this.setDisableEnableColumnTypeForJson(rowData.dataFindFrom,rowData.sag_G_Index);
    }

  });
}


onChangeVariableMappingType(value) {

  if (value == 'table') {
    this.variabelModuleDropdropdownList = [];
  } else if (value == 'formDbMapping') {
    this.setVariableImpExpModuleListForSheetMappingDropdown();
  } else {
    this.variabelModuleDropdropdownList = [];
  }

  if (this.jsonSchema && this.jsonSchema.varriableMappingType) {
    if (value == "form" || value == "table") {
      this.getFormDropDownListForJson(this.angularFormList);
      this.getTableDropdownNameForJson(this.allTableList);
      
    } else if (value == "formDbMapping") {
      if (this.jsonSchema.varriableMappingData) {
        this.getVariableNameByModuleIdForJson(this.jsonSchema.varriableMappingData);
      }
    }
  }

  this.jsonMappingGrid(this.jsonSchema['details'],this.jsonSchema.jsonType);
  this.gridDynamicForJsonMapping.expandAll();
}



setVariableImpExpModuleListForSheetMappingDropdown(){
  this.variabelModuleDropdropdownList = [];
  this.variabelModuleList.forEach(ele => {
    let obj = {
      "value": ele.moduleId,
      "label": ele.moduleName,
    }
    this.variabelModuleDropdropdownList.push(obj);
  });
}

onChangeVariableData(moduleId) {
  this.getVariableNameByModuleIdForJson(moduleId);
}

onChangeSheetColumnType(columnType, rowIndex){
 
  let textAlign = null;
  let decimalFormat = [];
  
  switch (columnType.toLowerCase()) {
    case "string":
      textAlign = "left";
      decimalFormat =  [];
    break;
  case "boolean":
      textAlign = "center";
      decimalFormat =  [];
    break;
  case "date":
      textAlign = "center";
      decimalFormat =  [];
    break;
  case "number":
      textAlign = "right";
      decimalFormat =  ["decimal_format"];
   case "integer":
      textAlign = "right";
      decimalFormat =  [];
     break;

  
    }
    this.gridDynamicForJsonMapping.updateCell(rowIndex, "textAlign", textAlign);
    this.gridDynamicForJsonMapping.updateCell(rowIndex, "decimalFormat", decimalFormat);
     
 }

disableMasterCell(gridData){
  
  gridData.forEach(rowData => {

    if(rowData.details){
      this.disableMasterCell(rowData.details)
    }else{
     
      if(rowData.isMaster == "Y"){
        this.gridDynamicForJsonMapping.enableCell(rowData.sag_G_Index, "excelMaster"); 
        this.gridDynamicForJsonMapping.enableCell(rowData.sag_G_Index, "tableMaster");
        this.gridDynamicForJsonMapping.enableCell(rowData.sag_G_Index, "masterColumnName");
      } else {
         this.gridDynamicForJsonMapping.disableCell(rowData.sag_G_Index, "excelMaster");
         this.gridDynamicForJsonMapping.disableCell(rowData.sag_G_Index, "tableMaster");
         this.gridDynamicForJsonMapping.disableCell(rowData.sag_G_Index, "masterColumnName");
      }
    }
  
  });
}

disableExportTypeInEquals(gridData){
  
  gridData.forEach(rowData => {

    if(rowData.details){
      this.disableExportTypeInEquals(rowData.details)
    }else{
      if("1" == rowData.importBy  || "true" == rowData.importBy){
        this.gridDynamicForJsonMapping.enableCell(rowData.sag_G_Index, "exportTypeInEquals");
      }else {
        this.gridDynamicForJsonMapping.disableCell(rowData.sag_G_Index, "exportTypeInEquals");
      }
    }
  
  });
}

aliaseStartIndex = 0

setAliaseNameInGrid (rowsData) {
  for (let index = 0; index < rowsData.length; index++) {
    let element = rowsData[index];
    if(element.details){
      this.aliaseStartIndex = this.aliaseStartIndex + 1;
      element["headerAlias"] =  this.sheetHeaderAlias[this.aliaseStartIndex]
      this.setAliaseNameInGrid(element.details)
    } else {
      this.aliaseStartIndex = this.aliaseStartIndex + 1;
      element["headerAlias"] =  this.sheetHeaderAlias[this.aliaseStartIndex]
    }
    
  }
  
}

setColorPropertiesForJson(gridData){
 
  gridData.forEach(rowData => {
    if(rowData.details){
      let colorProperty = {"background-color":"rgb(195 195 195)"}
      this.gridDynamicForJsonMapping.disableRow( rowData.sag_G_Index);
      //this.gridDynamicForJsonMapping.enableCell( rowData.sag_G_Index,"tableRow");
      this.gridDynamicForJsonMapping.setRowProperty(rowData.sag_G_Index,colorProperty);
      this.setColorPropertiesForJson(rowData.details)
    }
  });
}

onChangeSheetNameForJson(sheetName,isGridAlreadyLoaded){
 
this.sheetHeaderNameDropdown = [{ "key": "", "val": "--Select--" }];;
this.jsonSheetDataList = _.find(this.excelSheetList,{"name":sheetName});

if(this.jsonSheetDataList){
  let headerKey = "name";
  if("fix"==this.jsonSheetDataList['type'] && "cellRefrenceWise" == this.jsonSheetDataList['readDataRowCellWise'] ){
    headerKey = "cellDesc";
  }
  this.jsonSheetDataList['sheetHeaderList'].forEach(element => {
    let obj = {
      "key": element[headerKey],
      "val": element[headerKey]
    }
    this.sheetHeaderNameDropdown.push(obj);
  });

  if (isGridAlreadyLoaded && this.gridDynamicForJsonMapping) {
    if(this.gridDynamicForJsonMapping.sagGridObj.components['sheetHeaderName']){
    this.gridDynamicForJsonMapping.sagGridObj.components['sheetHeaderName'].setOption(this.sheetHeaderNameDropdown);
  }
  }

  if(isGridAlreadyLoaded){
    this.jsonSchema["importDataInsertType"] =  this.jsonSheetDataList['importDataInsertType'];
   
    let details = this.removeSheetHeaderRow( this.jsonSchema["details"]);
    this.jsonSheetDataList['sheetHeaderList'].forEach(element => {
      if ("_sheet" != element['dataFindFrom']  ) {
        element['name'] = element[headerKey];
        element['description'] = element[headerKey];
        element['sheetHeaderName'] = element[headerKey];
        element['caption'] = element[headerKey];
        if("Formula" == element['dataFindFrom']){
          element['formulaStaticValue'] = "";
        }

         details.push(element);
         this.setTableNameIntoDataBindFromForJson(element.tableName);
      }
    });
  
    this.onClickJsonObject(this.jsonSchema,null);

    
  } 

}else{
  if(isGridAlreadyLoaded){
    this.jsonSchema["importDataInsertType"]  = [];
  this.removeSheetHeaderRow( this.jsonSchema["details"]);
  this.onClickJsonObject(this.jsonSchema,null);
  }
}

}

removeSheetHeaderRow(arr) {
  var i = 0;
  while (i < arr.length) {
    if (!arr[i]['isJsonExport']) {
      arr.splice(i, 1);
    } else {
      ++i;
    }
  }
  return arr;
}

onChangeJsonsheetHeaderName(value, params){
 if(this.jsonSheetDataList){
  let sheetHeaderData = _.find(this.jsonSheetDataList['sheetHeaderList'],{"name":value});
  if(!sheetHeaderData){
    sheetHeaderData = _.find(this.jsonSheetDataList['sheetHeaderList'],{"cellDesc":value});
  }

  let rowValue = params.rowValue;
  let onlyTableInfoMap:boolean = false;
  if("_sheet" == rowValue.dataFindFrom){
    onlyTableInfoMap = true;
  }
 
  if(sheetHeaderData){
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "caption",value);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "isMaster",sheetHeaderData.isMaster);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "primaryKey",sheetHeaderData.primaryKey);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "primaryKeyType",sheetHeaderData.primaryKeyType);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableCoulmnType",sheetHeaderData.tableCoulmnType);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableField",sheetHeaderData.tableField);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableName",sheetHeaderData.tableName);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableProperties",sheetHeaderData.tableProperties);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "validation",sheetHeaderData.validation);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "uniqueConstraint",sheetHeaderData.uniqueConstraint);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "importBy",sheetHeaderData.importBy);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "exportTypeInEquals",sheetHeaderData.exportTypeInEquals);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "dateFormat",sheetHeaderData.dateFormat);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "childMasterExtraFields",sheetHeaderData.childMasterExtraFields);

   
    if(!onlyTableInfoMap){
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "dataFindFrom",sheetHeaderData.dataFindFrom);
      if("Formula" != sheetHeaderData['dataFindFrom']+""){
        this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "formulaStaticValue",sheetHeaderData.formulaStaticValue);
      }
    }
   
    this.setDisableEnableMasterColumnForJson(sheetHeaderData.isMaster,params.rowIndex);

    if("Y"==sheetHeaderData.isMaster){
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableMaster",sheetHeaderData.tableMaster);
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableMasterEntityName",sheetHeaderData.tableMasterEntityName);
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterColumnName",sheetHeaderData.masterColumnName);
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterEntityColumnName",sheetHeaderData.masterEntityColumnName);
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterColumnDBDataType",sheetHeaderData.masterColumnDBDataType);
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterPrimarykeyDBDataType",sheetHeaderData.masterPrimarykeyDBDataType);
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterTablePrimaryKey",sheetHeaderData.masterTablePrimaryKey);
 
      
     let find =  _.find(this.excelMasterDropdownForSheetMapping,{key:sheetHeaderData.excelMaster } )
     if(find){
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "excelMaster",sheetHeaderData.excelMaster);
     }else{
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "excelMaster","");
     }
      
      this.onChangeMasterTableForJson(sheetHeaderData.tableMaster, params.rowIndex,null);
    }else{
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableMaster","");
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableMasterEntityName","");
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterColumnName","");
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterEntityColumnName","");
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterColumnDBDataType","");
      
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterPrimarykeyDBDataType","");
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterTablePrimaryKey","");
      this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "excelMaster","");
    
      
    }

    this.onChangeTableForJson(sheetHeaderData.tableName, params.rowIndex,sheetHeaderData.tableField);
   
    this.setTableNameIntoDataBindFromForJson(sheetHeaderData.tableName);
  }else{
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "caption","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "isMaster","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "primaryKey","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "primaryKeyType","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableCoulmnType","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableField","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableName","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableProperties","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "validation",[]);
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "uniqueConstraint","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "importBy","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "exportTypeInEquals","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "dateFormat","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableMaster","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "tableMasterEntityName","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterColumnName","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterEntityColumnName","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterColumnDBDataType","");
    
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "masterPrimarykeyDBDataType","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "formulaStaticValue","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "dataFindFrom","");
    this.gridDynamicForJsonMapping.updateCell(params.rowIndex, "childMasterExtraFields",[]); 
  }
 }

 
}

addRowJsonMapping(){
   
  let obj = this.getEmptyObjForAddRow();

   this.jsonSchema['details'].push(obj);
   this.jsonMappingGrid(this.jsonSchema['details'],this.jsonSchema.jsonType);
   this.gridDynamicForJsonMapping.expandAll();
}


getEmptyObjForAddRow(){
  let obj = {
    "name":"",
    "description": "",
    "sheetHeaderName": "",
    "caption": "",
    "dataFindFrom":"",
    "type":"",
    "dateFormat":"",
    "validation":[],
    "tableName":"",
    "tableField":"",
    "tableProperties":"",
    "isMaster":"",
    "excelMaster":"",
    "tableMaster":"",
    "masterColumnName":"",
    "uniqueConstraint":0,
    "formulaStaticValue":"",
    "importBy":0,
    "exportTypeInEquals":"",
    "groupBy":0
}
return obj;
}

async deleteRowJsonMapping(rowIndex){
    
 let aliaseUsageHeader = this.checkHeaderAliaseUsage();
  
 let isDeleteRow = false;

 if(aliaseUsageHeader){
   if (await ui.confirm('You use this row refrence in '+aliaseUsageHeader+" ! Do you want to delete this row ")) {
     isDeleteRow = true
   }
 } else{
   isDeleteRow = true;
 }

 if(isDeleteRow){
  this.deleteRowJsonMappingTree(rowIndex , this.jsonSchema['details'])
  let allSheetHeaderListSimpleFormat =   this._getApiFieldSimpleFormate(this.jsonSchema['details']);

  this.autoSetFormula(rowIndex,this.jsonSchema['details'],allSheetHeaderListSimpleFormat,"delete");

  this.jsonMappingGrid(this.jsonSchema['details'],this.jsonSchema.jsonType);
  this.gridDynamicForJsonMapping.expandAll();
 }
}

deleteRowJsonMappingTree(sag_G_Index,array){

  for (let index = 0; index < array.length; index++) { 
    const element = array[index];
    if(element.details){
      this.deleteRowJsonMappingTree(sag_G_Index,element.details);
     }
     if(element.sag_G_Index == sag_G_Index){
      array.splice(index, 1)
     }
  }
}

setDisableEnableMasterColumnForJson(value,rowIndex){
  if(value == "Y"){
    this.gridDynamicForJsonMapping.enableCell(rowIndex, "excelMaster"); 
    this.gridDynamicForJsonMapping.enableCell(rowIndex, "tableMaster");
    this.gridDynamicForJsonMapping.enableCell(rowIndex, "masterColumnName");
  } else {
    this.gridDynamicForJsonMapping.updateCell(rowIndex, "excelMaster",'');
    this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableMaster",'');
    this.gridDynamicForJsonMapping.updateCell(rowIndex, "masterColumnName",'');

     this.gridDynamicForJsonMapping.disableCell(rowIndex, "excelMaster");
     this.gridDynamicForJsonMapping.disableCell(rowIndex, "tableMaster");
     this.gridDynamicForJsonMapping.disableCell(rowIndex, "masterColumnName");
  }
}



async fillTableNameSameValueForJson(params, tableName){
 
  if (await ui.confirm('Do You Want To Fill Same Value In Next Remainig Row ?')) {
   let gridsize = this.gridDynamicForJsonMapping.sagGridObj.AllRowIndex.length;
   for (let i = params.rowIndex; i < gridsize; i++) {
     this.gridDynamicForJsonMapping.updateCell(i, "tableName", tableName);
     this.onChangeTableForJson(tableName, i,null);
     this.setTableNameIntoDataBindFromForJson(tableName);
   }
  }
 }

 fillTableList
 setTableNameIntoDataBindFromForJson(tableName){
  let gridData = this.gridDynamicForJsonMapping.getGridData();
  this.fillTableList = [];
  this._getAllFillTableList(gridData);
  this.fillTableList.push(tableName);
  let tableList = _.uniq(this.fillTableList);

  let relationList = [];
  tableList.forEach(element => {
    tableList.forEach(element1 => {
      if(element1 && element){
        let relatation =  _.find(this.tableFieldsMapForJson.get(element) , {"parentTable":element1});
        if(relatation){
         relationList.push(relatation);
        }
      }
    });
  });

  this.jsonSchema['tableRelations'] = relationList;

  this.jsonSchema['dataFindFrom'] = JSON.parse(JSON.stringify(this.dataFindFromForJson));

  if(tableList){
    tableList.forEach(element => {
      if(element){
        this.jsonSchema['dataFindFrom'].push({
          "key": "pk_of_"+element, "val": "Pk of "+element
        });
      }
    });
  }
  if(this.gridDynamicForJsonMapping.sagGridObj.components['dataFindFrom']){
 this.gridDynamicForJsonMapping.sagGridObj.components['dataFindFrom'].setOption(this.jsonSchema['dataFindFrom']);
}
 this.fillTableList = [];
}


_getAllFillTableList(gridData){
  let tableList = _.map(gridData, 'tableName');
  tableList = _.uniq(tableList);
  if(tableList){
    tableList.forEach(element => {
      if(element){
        this.fillTableList.push(element);
      }
    });
  }

  gridData.forEach(element => {
    if(element.details){
      this._getAllFillTableList(element.details);
    }
  });
}


 onChangeTableForJson(tableName, rowIndex,tableFieldBind) {
  if (tableName) {

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
      "dbtype": "master",
      "tableName": tableName
    }
    this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
      if (res) {
        this.setTableFieldDropdownForJson(res, rowIndex,tableFieldBind,tableName);
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }

}



setTableFieldDropdownForJson(res, rowIndex,tableFieldBind,tableName) {
  this.tableFieldDropdownListForJson = [{ "key": "", "val": "--Select--" }];

  let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);
  
  tableFieldsInfo.forEach(tableColumn => {
    let obj = {
      "key": tableColumn['columnName'],
      "val": tableColumn['columnName']
    }
    this.tableFieldDropdownListForJson.push(obj);
  });

  this.tableFieldsMapForJson.set(tableName, tableFieldsInfo);

  if (this.gridDynamicForJsonMapping && this.gridDynamicForJsonMapping.sagGridObj.components['tableField']) {
    this.gridDynamicForJsonMapping.sagGridObj.components['tableField'].setOptionRow(this.tableFieldDropdownListForJson, "tableField", rowIndex);
    if(tableFieldBind){ 
     this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableField", tableFieldBind);

     let tableFieldsList = this.tableFieldsMapForJson.get(tableName);
     let item = _.find(tableFieldsList, { "columnName": tableFieldBind });
     if (item) {
       this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
       this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableCoulmnType", item.dataType);
     }

     let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
     if(pkObj){
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "primaryKey", pkObj.columnName);
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
     }

    }
  }
}

onChangeTableFieldForJson(tableField, params) {
  let rowIndex = params.rowIndex;
  if (tableField) {
    let tableName = params.rowValue.tableName;
   
    let tableFieldsList = this.tableFieldsMapForJson.get(tableName);
    let item = _.find(tableFieldsList, { "columnName": tableField });
    if (item) {
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableCoulmnType", item.dataType);
      
    }
    let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
    if(pkObj){
     this.gridDynamicForJsonMapping.updateCell(rowIndex, "primaryKey", pkObj.columnName);
     this.gridDynamicForJsonMapping.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
    }

  }else{
    this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableProperties", '');
    this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableCoulmnType", '');
  }
}

onChangeMasterTableForJson(tableName, rowIndex,tableFieldBind) {
  if (tableName) {

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
      "dbtype": "master",
      "tableName": tableName
    }
    this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
      if (res) {
      
        this.setMasterTableFieldDropdownForJson(res, rowIndex,tableFieldBind,tableName);
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }else{
    if(this.gridDynamicForJsonMapping.sagGridObj.components['masterColumnName']){
    this.gridDynamicForJsonMapping.sagGridObj.components['masterColumnName'].setOptionRow([{ "key": "", "val": "--Select--" }], "masterColumnName", rowIndex);
  }
  }
}

setMasterTableFieldDropdownForJson(res, rowIndex,tableFieldBind,tableName) {
  this.masterTableFieldDropdownListForJson = [{ "key": "", "val": "--Select--" }];

  let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);
  tableFieldsInfo.forEach(tableColumn => {
    let obj = {
      "key": tableColumn['columnName'],
      "val": tableColumn['columnName']
    }
    this.masterTableFieldDropdownListForJson.push(obj);
  });

  this.masterTableFieldMapForJson.set(tableName, tableFieldsInfo);

  if (this.gridDynamicForJsonMapping) {
    if(tableFieldsInfo.length > 0){
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "tableMasterEntityName", tableFieldsInfo[0]['entityName']);
    }

    if(this.gridDynamicForJsonMapping.sagGridObj.components['masterColumnName']){
      this.gridDynamicForJsonMapping.sagGridObj.components['masterColumnName'].setOptionRow(this.masterTableFieldDropdownListForJson, "masterColumnName", rowIndex);
    }
    if(tableFieldBind){ 
     this.gridDynamicForJsonMapping.updateCell(rowIndex, "masterColumnName", tableFieldBind);
     this.onChangeMasterTableFieldForJson(tableFieldBind,tableName,rowIndex);
    }
  }
}

onChangeMasterTableFieldForJson(tableField, tableName,rowIndex) {

  if (tableField) {
   let tableFieldsList = this.masterTableFieldMapForJson.get(tableName);
    let item = _.find(tableFieldsList, { "columnName": tableField });
    if (item) {
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "masterEntityColumnName", item.entityColumn);
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "masterColumnDBDataType", item.dataType);
    }
    let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
    if(pkObj){
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "masterTablePrimaryKey", pkObj.columnName);
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "masterPrimarykeyDBDataType", pkObj.dataType);
    
    }

  }
}

manageExcelSheetStateForJson(isLoadBefore) {
  if (this.jsonSchema && this.jsonSchema.varriableMappingType) {
    if (isLoadBefore && this.jsonSchema.varriableMappingType == "form") {
      this.getFormDropDownListForJson(this.angularFormList);
      this.getTableDropdownNameForJson(this.allTableList);
      
    } else if ( isLoadBefore && this.jsonSchema.varriableMappingType == "table") {
      this.getFormDropDownListForJson(this.angularFormList);
      this.getTableDropdownNameForJson(this.allTableList);
  
    } else if (!isLoadBefore && this.jsonSchema.varriableMappingType == "formDbMapping") {
      if (this.jsonSchema.varriableMappingData) {
        this.getVariableNameByModuleIdForJson(this.jsonSchema.varriableMappingData);
      }
    }
  }
}

getFormDropDownListForJson(data) {
  this.angularFormDropdownList = [{ "key": "", "val": "--Select--" }]
  data.forEach(ele => {
    let obj = {
      "key": ele['ngsrcfileId'],
      "val": ele['formName']
    }
    this.angularFormDropdownList.push(obj);
  });
}

getTableDropdownNameForJson(mtbllist) {
  this.tableListDropdownList = [{ "key": "", "val": "--Select--" }];
  mtbllist.forEach(table => {
    let obj = {
      "key": table,
      "val": table
    }
    this.tableListDropdownList.push(obj);
  });
  if (this.gridDynamicForJsonMapping && this.gridDynamicForJsonMapping.sagGridObj && 
    this.gridDynamicForJsonMapping.sagGridObj.components['tableName']) {
    this.gridDynamicForJsonMapping.sagGridObj.components['tableName'].setOption(this.tableListDropdownList);
  }
}

getVariableNameByModuleIdForJson(moduleId) {
  let formFields = [{ "key": "", "val": "--Select--" }];
  if (moduleId) {
    this.autoJavacodeService.getVariableNameByModuleId(moduleId).subscribe(res => {
      if (res.status == 200) {
        res.data.forEach(ele => {
          let obj = {
            "key": ele.labelName,
            "val": ele.labelName
          }
          formFields.push(obj);
        });

        this.filterFormsAccordingVarMappingForJson(res);
        this.setDefaultFormNameInSheetMappingForJson(res);
        this.filterTablesAccordingVarMappingForJson(res);
        if (this.gridDynamicForJsonMapping.sagGridObj.components['field']) {
          this.gridDynamicForJsonMapping.sagGridObj.components['field'].setOption(formFields);
        }

      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  } else {
    let gridsize = this.gridDynamicForJsonMapping.sagGridObj.AllRowIndex.length;
    for (let i = 0; i < gridsize; i++) {
      this.gridDynamicForJsonMapping.updateCell(i, "formName", '');
    }
    if(this.gridDynamicForJsonMapping.sagGridObj.components['field']){
    this.gridDynamicForJsonMapping.sagGridObj.components['field'].setOption(formFields);
  }
  }

}

filterTablesAccordingVarMappingForJson(res) {
  this.tableListDropdownList = [{ "key": "", "val": "--Select--" }];
  if (res.data.length > 0) {
    let mtbllist = _.uniqBy(_.filter(res.data, variable => variable.tableName != null && variable.tableName != undefined && variable.tableName != ""), 'tableName');

    mtbllist.forEach(ele => {
      let obj = {
        "key": ele.tableName,
        "val": ele.tableName
      }
      this.tableListDropdownList.push(obj);
    });
  }
  if (this.gridDynamicForJsonMapping && this.gridDynamicForJsonMapping.sagGridObj.components['tableName']) {
    this.gridDynamicForJsonMapping.sagGridObj.components['tableName'].setOption(this.tableListDropdownList);
  }
}

filterFormsAccordingVarMappingForJson(res) {
  this.angularFormDropdownList = [{ "key": "", "val": "--Select--" }];
  if (res.data.length > 0) {
    let mtbllist = _.uniqBy(_.filter(res.data, variable => variable.formName != null && variable.formName != undefined && variable.formName != ""), 'formName');

    mtbllist.forEach(ele => {
      let obj = {
        "key": ele.ngsrcfileId,
        "val": ele.formName
      }
      this.angularFormDropdownList.push(obj);
    });
   }
  if (this.gridDynamicForJsonMapping && this.gridDynamicForJsonMapping.sagGridObj.components['formName']) {
    this.gridDynamicForJsonMapping.sagGridObj.components['formName'].setOption(this.angularFormDropdownList);
    this.gridDynamicForJsonMapping.sagGridObj.dropDownJson_formName = this.angularFormDropdownList;
  }
}

setDefaultFormNameInSheetMappingForJson(res) {
  if (res.data.length > 0) {
    let ngsrcfileId = res.data[0]['ngsrcfileId'];
    let gridsize = this.gridDynamicForJsonMapping.sagGridObj.AllRowIndex.length;

    for (let i = 0; i < gridsize; i++) {
      this.gridDynamicForJsonMapping.updateCell(i, "formName", ngsrcfileId);
    }
  }
}

bindSheetDataForJson(gridData){
  if(this.gridDynamicForJsonMapping){
   if(gridData){
     gridData.forEach(rowData => {
       if(rowData.details){
        this.bindSheetDataForJson(rowData.details);
       }
       if(rowData.formName && rowData.field){
         this.onChangeFormNameInGridForJson(rowData.formName,rowData.sag_G_Index,rowData.field);
       }
       if(rowData.tableName && rowData.tableField){
         this.onChangeTableForJson(rowData.tableName, rowData.sag_G_Index,rowData.tableField);
         this.onChangeMasterTableForJson(rowData.tableMaster, rowData.sag_G_Index,rowData.masterColumnName);
       }
     });
   }
  }
}


getImportExportVarriabels(formName, rowIndex,formFieldBind) {

  let formFields = [{ "key": "", "val": "--Select--" }];

  let moduleId = this.jsonSchema.varriableMappingData;
  if(!moduleId){
    if (this.gridDynamicForJsonMapping && this.gridDynamicForJsonMapping.sagGridObj.components['field']) {
      this.gridDynamicForJsonMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
    }
 }
 let ngsrcfileId = formName;
  this.autoJavacodeService.getImportExportVarriabels(moduleId).subscribe(res => {
    if (res.status == 200) {
      if(res.data!=null){
        res.data.forEach(ele => {
          let obj = {
            "key": ele.labelName,
            "val": ele.labelName
          }
          formFields.push(obj);
          this.angularformFieldsMapForJson.set(ngsrcfileId, res.data);
        });
      }
     
      if (this.gridDynamicForJsonMapping && this.gridDynamicForJsonMapping.sagGridObj.components['field']) {
        this.gridDynamicForJsonMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
        if(formFieldBind){
          this.gridDynamicForJsonMapping.updateCell(rowIndex, "field", formFieldBind);

        }
     
      }
    }
  }, Error => {
     
    alerts("Error While Fetching Data");
  });
} 


onChangeFormNameInGridForJson(formName, rowIndex,formFieldBind) {
  let formFields = [{ "key": "", "val": "--Select--" }];
   
  if (formName) {

    if(this.jsonSchema && (this.jsonSchema.varriableMappingType )+"" == "formDbMapping"){
      
      this.getImportExportVarriabels(formName, rowIndex,formFieldBind);

    } else {
      let ngsrcfileId = formName;
      this.autoJavacodeService.getFormLabelName(Number(ngsrcfileId)).subscribe(res => {
        if (res.status == 200) {
          res.data.forEach(ele => {
            let obj = {
              "key": ele.labelName,
              "val": ele.labelName
            }
            formFields.push(obj);
            this.angularformFieldsMapForJson.set(ngsrcfileId, res.data);
          });
          if (this.gridDynamicForJsonMapping && this.gridDynamicForJsonMapping.sagGridObj.components['field']) {
            this.gridDynamicForJsonMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
            if(formFieldBind){
              this.gridDynamicForJsonMapping.updateCell(rowIndex, "field", formFieldBind);

            }
         
          }
        }
      }, Error => {

        alerts("Error While Fetching Data");
      });
    }

    

  } else {
    if (this.gridDynamicForJsonMapping && this.gridDynamicForJsonMapping.sagGridObj.components['field']) {
      this.gridDynamicForJsonMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
    }

  }

}


autoFillSheetFields(){
  let gridData = this.gridDynamicForJsonMapping.getGridData();

  gridData.forEach(rowData => {
    if(rowData.formName && rowData.field){
      let formFields = this.angularformFieldsMapForJson.get(rowData.formName);
      let item = _.find(formFields, { "labelName":  rowData.field});
      this.gridDynamicForJsonMapping.updateCell(rowData.sag_G_Index, "tableName", item.tableName);
      this.onChangeTableForJson(item.tableName, rowData.sag_G_Index,item.tableColumn);
      
    }else  if(rowData.tableName && rowData.tableField){

    }
  });


  }

onChangeFormFieldNameInGrid(labelName, params) {
   
  if (labelName) {
    let formId = params.rowValue.formName; 
    let rowIndex = params.rowIndex;
    let formFields = this.angularformFieldsMapForJson.get(formId);
    let item = _.find(formFields, { "labelName": labelName });
    if (item) {
      this.gridDynamicForJsonMapping.updateCell(rowIndex, "fieldProperties", item.inputType );
    }

  }
}


dbMappingform: FormGroup;
_rootPackagePath="com.sagipl" 

setApiGeneratedInfo(){
  let backEndProjectName = this.shareService.getDataprotool("selectedProjectChooseData");
  if (backEndProjectName) {
    this.sagStudioService.setSagStudioData("autoGeneretedProjectPath", backEndProjectName.jwspace);
  }
  else {
    alerts("please setPath in workspace Configuration");
    return
  }
  let projectName = backEndProjectName.jwspace.substring(backEndProjectName.jwspace.lastIndexOf("/") + 1, backEndProjectName.jwspace.length);
  this.initializeForm(projectName);
  this.setDefaultValueInDbMappingFormForJson();
}

generateJSONJavaCode(){
  if(!this.isGeneratedFileValid){
    this.isCreatedFileValid(false);
    return;
 }
  this.generateJavaApiForJson();
}

initializeForm(projectName) {
  this.dbMappingform = this.formbuilder.group({
    projectName: [{ value: projectName, disabled: true }, [Validators.required]],
    versionNo: [{ value: "", disabled: true }, [Validators.required]],
    providerName: [{ value: "", disabled: true }, [Validators.required]],
 
    moduleName: [{ value: '', disabled: false }, [Validators.required]],
    packageName: [{ value: '', disabled: true }, [Validators.required]],
    PageWindowName: [{ value: '', disabled: false }, [Validators.required]],
    controllerName: [{ value: '', disabled: false }, [Validators.required]],
    serviceName: [{ value: '', disabled: false }, [Validators.required]],
    serviceImplName: [{ value: '', disabled: false }, [Validators.required]],
    daoName: [{ value: '', disabled: false }, [Validators.required]],
    daoImplName: [{ value: '', disabled: false }, [Validators.required]],
    classLevelApiName: [{ value: '', disabled: false }, [Validators.required]],
    projectSourcePath: [{ value: this.sagStudioService.getSagStudioData("autoGeneretedProjectPath"), disabled: false }, [Validators.required]],
    userName: [],
    userId: [],
    projectId: [],
    projectname: [],
    userwrokspace: [],
    menuId: [],
    javaApiType: [],
    modelPackage:[],
    entityPackage:[],
    documentation:[],
    apiId:[{ value: null, disabled: false }],
    apijsonId:[{ value: null, disabled: false }],
    controllerMethodList:[{ value: null, disabled: false }],
    repositoryMethodList:[{ value: null, disabled: false }],
    ngsrcfilePath:[{ value: '', disabled: false }],
 })
  
 }

setDefaultValueInDbMappingFormForJson(){
  let projectName = this.dbMappingform.controls["projectName"].value;
  projectName=this.convertProjectNameToPackageName(projectName);
  
  const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
  if(sessionStoragedatauserId!=undefined){
    this.dbMappingform.controls["userName"].setValue(sessionStoragedatauserId.data.clientInfo.usrName);
    this.dbMappingform.controls["userId"].setValue(sessionStoragedatauserId.data.clientInfo.usrId);
  
  let setProjectInfo= this.shareService.getDataprotool("selectedProjectChooseData");
  if(setProjectInfo!=undefined){
    this.dbMappingform.controls["projectId"].setValue(setProjectInfo.projectId);
    this.dbMappingform.controls["projectname"].setValue(setProjectInfo.projectname);
    this.dbMappingform.controls["userwrokspace"].setValue(setProjectInfo.jwspace);
    let componentNode=  "src/app.gstr1.component.html";
    if(componentNode){
      //let projectPath=componentNode.projectPath;
    //  let uniqePath=projectPath.replace(setProjectInfo.projectname,"");
      //if(uniqePath.startsWith('/')){
      // uniqePath=uniqePath.replace('/',"");
     // }
     this.dbMappingform.controls["ngsrcfilePath"].setValue(componentNode);
    }
  }
  }else{
    alerts("user not found")
  }
  //  let menuId= this.shareService.getDatadbtool("ComponentMenuId");
  //  if(menuId && menuId!=null && menuId!="" ){
  //   this.dbMappingform.controls["menuId"].setValue(menuId);
  //  }else {
  //    alerts("menu not found")
  //  }
   
  let componentName= this.fileImportExportInfoFormGroup.controls['formName'].value;
  let versionNo= this.fileImportExportInfoFormGroup.controls['versionNo'].value;
  this.dbMappingform.controls["versionNo"].setValue(versionNo);
  let providerName= this.fileImportExportInfoFormGroup.controls['providerName'].value;
  this.dbMappingform.controls["providerName"].setValue(providerName);
  
  // let menuName= this.shareService.getDatadbtool("ComponentMenuName");
  // if(menuName!=undefined && menuName!=null && menuName!=""){
  //   let moduleName=this.convertMenuNameToModuleName(menuName);
  //   this.dbMappingform.controls["moduleName"].setValue(moduleName);
  //   this.onModuleNameChange(moduleName);
  // }else{
  //   if(componentName){
  //     this.dbMappingform.controls["moduleName"].setValue(componentName.toLowerCase());
  //     this.onModuleNameChange(componentName.toLowerCase());
  //   }
  // }
  if(componentName){
    this.dbMappingform.controls["moduleName"].setValue(componentName.toLowerCase());
    this.onModuleNameChange(componentName.toLowerCase());
  }

  if(componentName){
    componentName = componentName+"Json"+providerName+versionNo.replace(/[^\w\s]/gi, '_');
    this.dbMappingform.controls["PageWindowName"].setValue(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
    this.onPageChange(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
   
   // this.onPageNameChange(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
  }

}

convertProjectNameToPackageName(projectName){
  projectName=projectName.replace(/\s/g, "").toLowerCase();
  projectName=projectName.replace(/[^\w\s]/gi, '')
  return projectName;
 }

convertMenuNameToModuleName(menuName){
  
  menuName=menuName.replace(/\s/g, "").toLowerCase();
  menuName=menuName.replace(/[^\w\s]/gi, '')
  if(menuName == "return"){
    menuName = menuName+"1"
  }
 
  return menuName;
 }
 
 onModuleNameChange(filedName) {
  if(filedName == "return"){
    filedName = filedName+"1"
  }
 
  if(filedName==""){
    this.dbMappingform.controls["packageName"].setValue("");
      return;
   }
  let projectName = this.dbMappingform.controls["projectName"].value;
  let versionNo= this.fileImportExportInfoFormGroup.controls['versionNo'].value;
  let providerName= this.fileImportExportInfoFormGroup.controls['providerName'].value;
  
 
  this.dbMappingform.controls["packageName"].setValue(this._rootPackagePath+"." + projectName.toLowerCase() +".import_export"+ "." + filedName.toLowerCase());  
  //+providerName.toLowerCase()+".v"+versionNo.replace(/\./g,"_"));

  let PageWindowName=this.dbMappingform.controls["PageWindowName"].value;
  if(PageWindowName!=""){
   // this.onPageNameChange(PageWindowName);
  }
 
 
 
 }
 
 onPageChange(pageName) {
 
  if (pageName == "") {
    this.dbMappingform.patchValue({
      controllerName: "",
      serviceName: "",
      serviceImplName: "",
      daoName: "",
      daoImplName: "",
      classLevelApiName: "",
    })
  
    return;
  } else if (pageName != null) {
  
    this.dbMappingform.patchValue({
      controllerName: pageName + "Controller",
      serviceName: pageName + "Service",
      serviceImplName: pageName + "ServiceImpl",
      daoName: pageName + "Dao",
      daoImplName: pageName + "DaoImpl",
      classLevelApiName: pageName.toLowerCase(),
     
    })
    
  }
 }

generateJavaApiForJson() {
  this.classLevelApiName = this.dbMappingform.controls["classLevelApiName"].value;
  let masterJsonObj = this.dbMappingform.getRawValue();
  let formObj = this.fileImportExportInfoFormGroup.getRawValue();
  let jsonObj = _.merge(masterJsonObj, formObj);


 jsonObj['jsonSheetList'] = this.jsonSchemaList;
 jsonObj['excelMasterList'] = this.jsonMasterList;
 jsonObj['manualMethodList'] = this.manualMethodList; 
 
 let srcDataSource = null;
 let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
 if(dataForConnection && dataForConnection.srcDataSource){
   srcDataSource = dataForConnection.srcDataSource;
 }

 let reqObj = {
   apiCategory: 'json_import_export', 
   newApiInfoObj: jsonObj,
   apiId: null,
   apijsonId: null,
   oldApiInfoObj: null,
   databaseConfig:srcDataSource
 }

 this.autoJavacodeService.generateJavaNewCode(reqObj).subscribe(res => {
   if (res.status == 200) {
     success(res["msg"]);

     let apiInfo = res.generatedJavaApiInfo

     let apiObj = {
       uniqId: `${new Date().getTime()}${1}`,
       baseUrl: 'apiConstant.projectBaseUrl',
       failedMsg: 'error',
       run: false,
       expand: false,
       numberOfReq: 1,
       excutionTime: 0,
       argument: '',
       methodName: '',
       apiType: `${apiInfo.apiType}`,
       request: '',
       response: '',
       successMsg: 'scccessfull fetch',
       url: `${apiInfo.apiName}`,
       fullUrl: '',
       apiList: [],
       expectedReq: ``,
       expectedRes: ``,
       desc: '',
       apiResType: null,
       errorCode: "",
       msg: "",
       apiId:apiInfo.apiId  
     };
   }else if (res.status == 400) {
    alerts(res.msg);
   this.validateExcelData(res.excelSheetList); 
  } else {
    alerts(res.msg);
  }
 }, Error => {
   alerts("Error While Generating");
 })

}
  
closeJSONSchemaModal(){
  
  this.modalRef.close();
  this.ngOnDestroy();

}

autoFillMaster() {
  let gridData = this.gridDynamicForMasterMapping.getGridData();
  gridData.forEach(element => {
    if ("map_with_constant_value" != this.excelMasterInfo['masterMappingType'] + "") {
      let excelMaster = element.excelMaster;
      let defaultPer = 50;
      this.tableDataDropdownMasterMapping.forEach(tableMaster => {
        let per = this.similarity(excelMaster, tableMaster.val);
        if (per >= defaultPer) {
          defaultPer = per;
          this.gridDynamicForMasterMapping.updateCell(element.sag_G_Index, "tableMasterName", tableMaster.val);
          this.onChangetableMasterNameInGrid(tableMaster.val, element.sag_G_Index)
        }
      });
    }
  });
}
similarity(s1, s2) {
  s1 = s1.toLowerCase();
  s2 = s2.toLowerCase();

  let words = s1.split(/[^\w]/gi);
  
  words = words.filter(function (el) {
    return el != null &&  el != "";
  });

  let count = 0;
  let list = s2.split(/[^\w]/gi);

  list = list.filter(function (el) {
    return el != null &&  el != "";
  });

  for (var i = 0; i < words.length; i++) {
    let word = words[i].trim();
    if (list.includes(word)) {
      count++;
    }
  }

  return (count / parseFloat(words.length)) * 100;

}

/****************************************Manual Method*********************************************** */


openManualCode() {
  let selectedRowManualMethod = "";
  let selectedRowData = this.gridDynamicForJsonMapping.getSeletedRowData();
  if (selectedRowData && selectedRowData.formulaStaticValue) {
    selectedRowManualMethod = selectedRowData.formulaStaticValue;
  }

  if (!this.manualMethodList || this.manualMethodList.length == 0) {
    this.manualMethodList = this.excelManualMethod;
  } 

  let apiGeneratedObj = this.dbMappingform.getRawValue();
  // let formObj = this.fileImportExportInfoFormGroup.getRawValue();
  // let apiGeneratedObj = _.merge(masterJsonObj, formObj);

  let sheetNameList = this._getAllSheetName();

    const ref = this.dialogService.open(ImportExportManualCodeComponent, {
      header: "Manual Code",
      width: "100%",
      contentStyle: { "margin-top": "0px", "height": "100%" },
      styleClass: "service_full_model excel-demo-view",
      data: { "selectedRowManualMethod" : selectedRowManualMethod, 
      "manualMethodList": this.manualMethodList,"sheetNameList":sheetNameList,"type":"JSON",
      "jsonSchemaList":this.jsonSchemaList ,"apiGeneratedObj":apiGeneratedObj },

    });
    ref.onClose.subscribe((res) => {
      if (res) {
        this.manualMethodList = res;
      }
    });
  }  


_getAllSheetName (){
  let sheetNameList = [ ];
  sheetNameList.push({ "key": "", "val": "--Select--" }); 
 this.jsonSchemaList.forEach(element => {

    if(element['details']!=undefined && element['details'].length > 0){
      let obj = {
         "key":element['name'],
         "val":element['name']
      }
     sheetNameList.push(obj)
    }
 
  
 });

 return sheetNameList;
}



getExcelMasterForSheetMapping(isSetOption){
  let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;

  this.autoJavacodeService.getJsonMasterMapping(mappingId).subscribe(res => {
    if (res.status == 200) {
      this.excelMasterForSheetMapping = res.data
      this.mapExcelMasterDropdownForSheetMapping(isSetOption);
    }
  }, Error => {
    alerts("Error While Fetching Data");
  });
}

mapExcelMasterDropdownForSheetMapping(isSetOption){
  this.excelMasterDropdownForSheetMapping = [{ "key": "", "val": "--Select--" }];
  this.excelMasterForSheetMapping.forEach(ele => {
    let obj = {
     "key":ele.name,
     "val":ele.name
    }
    this.excelMasterDropdownForSheetMapping.push(obj);
  });

  if(isSetOption){
    if(this.gridDynamicForJsonMapping.sagGridObj.components['excelMaster']){
      this.gridDynamicForJsonMapping.sagGridObj.components['excelMaster'].setOption(this.excelMasterDropdownForSheetMapping);
    }
  }
}

/***********************View****************** */


excelImportExportView(){

  const url = this._router.createUrlTree(['../import-export-view',{"file-type": "json","api-name":this.classLevelApiName}])
  window.open(url.toString(), '_blank')

}
  


    /***********************Master Mapping*************************************************************************** */


    excelMasterInfo: { "tableName": "", "nameTableColumn": "", "codeTableColumn": "", "masterList":any,"masterMappingType":"map_with_table_data","isMasterManualCreate":false}
    gridDynamicForMasterMapping

    jsonMasterList
    tableNameDropdownForMasterMapping = [];
    tableColumnDropdownForMasterMapping = [];
    tableFieldsMapForMasterMapping = new Map();
    tableDataListForMasterMapping = [];
    tableDataMapMasterMapping = new Map();
    tableDataDropdownMasterMapping = [{ "key": "", "val": "--Select--" }] ;
  
    getMasterMapping(isOpenModal){
  
      if(isOpenModal){
        this.getTableDropdownForMasterMapping();
      }
    
      let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;
    
      this.autoJavacodeService.getJsonMasterMapping(mappingId).subscribe(res => {
        if (res.status == 200) {
          this.jsonMasterList = res.data
          if(isOpenModal){
            this.openMasterMappingModal();
          
            let item = _.find(res.data, { active: true });
            if (item) {
              setTimeout(() => {
                this.onClickMasterHeader(item, 1);
              }, 100);
            }
          }
          
    
        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
     }

     openMasterMappingModal(){
      $('#masterMappingModal').modal('show')
     }
    
     closeMasterMappingModal(){
       $('#masterMappingModal').modal('hide')
     }
    
     onClickMasterHeader(item: any, index) {
      this.excelMasterInfo = item;
      this.jsonMasterList.forEach(itm => itm.active = false);
      this.jsonMasterList.forEach(itm => itm.isRename = false);

      item['active'] = true;
      this.tableColumnDropdownForMasterMapping = [];
      this.tableDataDropdownMasterMapping      = [{ "key": "", "val": "--Select--" }];
    
      this.bindMasterMappingData();
    
    }
    
    bindMasterMappingData(){
      let tableName = this.excelMasterInfo["tableName"];
      let nameTableColumn = this.excelMasterInfo["nameTableColumn"];
    
      if(tableName == undefined || tableName == ""){
        if(this.excelMasterInfo['masterList']){
          this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
        }else{
          this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
        }
        return;
      }
      
      let tableFields =  this.tableFieldsMapForMasterMapping.get(tableName);
      if(tableFields!=undefined && tableFields!=null && tableFields.length > 0 ){
        this.getTableColumnDropdownForMasterMapping(tableFields,tableName,true);
        if(nameTableColumn){
          let tableData =  this.tableDataMapMasterMapping.get(tableName);
          if(tableData){
            this.getTableDataDropdownForMasterMapping(tableData,nameTableColumn,true);
          }else{
            this.getTableDataForMasterMapping(tableName,true); 
          }
         
        }else{
          if(this.excelMasterInfo['masterList']){
           this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
          }else{
            this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
          }
        }
        
    
      }else{
        if(nameTableColumn){
          this.onChangeTableNameDropdownForMasterMapping(tableName,true);
        }else{
          if(this.excelMasterInfo['masterList']){
          
            this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
          }else{
            this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
          }
          this.onChangeTableNameDropdownForMasterMapping(tableName,false);
        }
        
      }
      if(this.excelMasterInfo["isFilterData"]){
        if(this.excelMasterInfo['query']){
          if(this.excelMasterInfo['query']){
            if(this.excelMasterInfo['query']['sql']){
              this.executeQuery(this.excelMasterInfo['query']['sql'],true);     
            }
           }
         }
      }
    
    }
  
    onChangeTableNameDropdownForMasterMapping(tableName,isGridLoad){
      if (tableName) {
        this.getTableDataForMasterMapping(tableName,isGridLoad);
        let dbData = {
          "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
          "targetDataSource": {},
          "operation": "COMPARESINGLE",
          "connectionRoleType": "admin",
          "dbtype": "master",
          "tableName": tableName
        }
        this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
          if (res) {
         
            this.getTableColumnDropdownForMasterMapping(res,tableName,false);
            
          }
        }, Error => {
          alerts("Error While Fetching data");
        });
      }
     }
    
     getTableColumnDropdownForMasterMapping(res,tableName,isFetchFromCache){
      this.tableColumnDropdownForMasterMapping = [];

       let tableFieldsInfo = [];

       if (isFetchFromCache) {
         tableFieldsInfo = res;
       } else {
         tableFieldsInfo = this.getTableInfoWithCustomKeys(res, tableName);
       }

     
      let pkObj = _.find(tableFieldsInfo, { "pkey": "Y" });
        if(pkObj){
            this.excelMasterInfo["primaryKeyEntityColumn"] = pkObj.entityColumn;
            this.excelMasterInfo["primaryKeyTableColumn"] = pkObj.columnName,
            this.excelMasterInfo["primaryKeyTableColumnDbDataType"] = pkObj.dataType
            this.excelMasterInfo["entityName"] = pkObj["entityName"]
        }
    
        tableFieldsInfo.forEach(tableColumn => {
        let obj = {
          "label": tableColumn['columnName'],
          "value": tableColumn['columnName']
        }
        
        this.tableColumnDropdownForMasterMapping.push(obj);
      });

      this.tableFieldsMapForMasterMapping.set(tableName, tableFieldsInfo);

     } 

   getTableDataForMasterMapping(tableName,isGridLoad){
    if (tableName) {
  
      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName,
        "details": {
          "columns": [],
          "software": [],
          "year": [],
          "client": [],
          "operation": "",
          "limitRows": "null"
      },
      }
      this._dbcomparetoolService.getAllTabTableData(dbData).subscribe((res) => {
        if (res) {
       
          this.tableDataMapMasterMapping.set(tableName,res);
          if(isGridLoad){
            this.getTableDataDropdownForMasterMapping(res,this.excelMasterInfo['nameTableColumn'],isGridLoad);
          }
         
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }
   }
  
   
   getTableDataDropdownForMasterMapping(res,nameTableColumn,isGridLoad){
    this.tableDataDropdownMasterMapping = [{ "key": "", "val": "--Select--" }];
    if(res.gridarray){
      if(nameTableColumn){
        res.gridarray.forEach(ele => {
          let obj = {
            "key": ele[nameTableColumn],
            "val": ele[nameTableColumn]
          }
          this.tableDataDropdownMasterMapping.push(obj);
        });
      }
    }
  
    if(!isGridLoad){
      if(this.gridDynamicForMasterMapping.sagGridObj.components['tableMasterName']){
      this.gridDynamicForMasterMapping.sagGridObj.components['tableMasterName'].setOption(this.tableDataDropdownMasterMapping);
    }
    }else{
      if(this.excelMasterInfo['masterList']){
       
        this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
      }else{
        this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
      }
    }
    
   }
  
  
    
    
     getTableDropdownForMasterMapping(){
      this.tableNameDropdownForMasterMapping = [];
      this.allTableList.forEach(table => {
        let obj = {
          "label": table,
          "value": table
        }
        this.tableNameDropdownForMasterMapping.push(obj);
      });
     }
  
     onChangeNameColumnDropdownForMasterMapping(nameColumn){
  
      let tableName =  this.excelMasterInfo['tableName'];
      if(tableName && nameColumn){
       let data =  this.tableDataMapMasterMapping.get(tableName);
       let tableFieldsInfo = this.tableFieldsMapForMasterMapping.get(tableName)
       if(tableFieldsInfo){
        let columnObj = _.find(tableFieldsInfo, { "columnName": nameColumn });
        if(columnObj){
         this.excelMasterInfo["nameEntityColumn"] = columnObj.entityColumn;
        }
       }
        this.getTableDataDropdownForMasterMapping(data,nameColumn,false);

        this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
      }
    }
  
    saveFileImportExportMasterMappingJson() {
      let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;
    
      if(!mappingId){
        alerts("Please save first data mapping")
        return;
      }

      if (mappingId == '' || mappingId == null || mappingId == undefined || this.jsonMasterList == undefined || this.jsonMasterList == null || this.jsonMasterList == '') {
        alerts("Data not valid")
        return;
      }
    
      let obj = {
        "mappingId": mappingId,
        "excelMasterList": this.jsonMasterList
      }
    
      if(this.checkDuplicateMasterMapping()){
        return;
      }
    
      this.autoJavacodeService.saveFileImportExportMasterMappingJson(obj).subscribe(res => {
        if (res.status == 200) {
          this.getExcelMasterForSheetMapping(true);
          success(res.msg);
        } else {
          alerts(res.msg);
        }
      }, Error => {
        alerts("Error While saving data");
      });
    }
  
    checkDuplicateMasterMapping(){
      let isDuplicate:boolean = false;
      this.jsonMasterList.forEach(element => {
        let sheetName = element["name"];
        let masterList = element['masterList'];
      
        if(isDuplicate){
            return;
          }
          if(masterList){
            let groupBy = _.chain(masterList).groupBy('tableMasterName').map((value, key) => ({ key,  value }))
            .value();
            groupBy.forEach(group => {
              if(group['key'] && group['value']){
                if(group['value'] && group['value'].length > 1){
                  
                  alerts(sheetName+ " have duplicate table master entry" );
                  isDuplicate = true;
                  return;
               };
              }
            });
          }
      
      });
      return isDuplicate;
    }
   
  
  filterMasterMappingData(){
    this.getMasterTableDataWithParentTable(this.excelMasterInfo['tableName'],false)
   }

   resetFilter(){
    this.excelMasterInfo['isFilterData'] = true;
    this.excelMasterInfo['query'] = null;
    this.bindMasterMappingData();
   }
  
   getMasterTableDataWithParentTable(tableName,isGridLoad){
    if (tableName) {
      this.openFilterMasterMappingModal();
      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName,
        "details": {
          "columns": [],
          "software": [],
          "year": [],
          "client": [],
          "operation": "",
          "limitRows": "null"
      },
      }
      this._dbcomparetoolService.getEnityHqlData(dbData).subscribe((res) => {
        if (res) {
          let arr = [];
          this.createMastersFilterData(arr,res);
          this.sagFilterMasterMappinGrid(arr);
         
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }
   }
  
  
   gridDynamicFilterMasterMappingGrid:any;
   sagFilterMasterMappinGrid(rowsData) {
    var sourceDiv = document.getElementById("filterMasterMappingGridId");
    let columns : any =  [
      {
        "field": "checkBox",
        "filter": false,
        "editable": false,
        "sagGridResize": false,
        "width": "50px",
        "header": "All",
        "text-align": "center",
        "colType": "checkBox"
      },
     
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
  
      {
        "header": "Table Column",
        "field": "tablecolumn",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Value",
        "field": "tableValue",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": "tableValueComponent",
      },
     
  
  
    ];
    
     let self = this;
     let components = { 
       "tableValueComponent": new SagInputText({}, function () {
    })
  };
   var SagGridRowStatus = rowsData;
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        rowCustomHeight :20,
        cellCustomPadding:5,
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          
        },
        rowGrouping: {
          "enable": true,
          "groupType": "custome",
          "groupBy": "tablecolumn",
          "expandRow": []
        },
        rowSelection: false,
        rowDataViewTotal: true,
        sml_expandGrid_hide: true,
        exportXlsxPage_hide: true,
        exportXlsxAllPage_hide: true,
        exportPDFLandscape_hide: true,
        exportPDFPortrait_hide: true,
        ariaHidden_hide: true,
      };
      this.gridDynamicFilterMasterMappingGrid = SagGridMPT(sourceDiv, gridData, true, true);
      
      return this.gridDynamicFilterMasterMappingGrid;
  
    }
  
  }
  
   createMastersFilterData(arr,res){
    let columns =res['columns'];
    let jointable = res['jointable'];
    let foreignkeycolumns =res['foreignkeycolumns'];
    columns.forEach(column => {
      column['tablename'] = res['tablename'];
      column['entitytable'] = res['entitytable'];
      column['primarykey'] = res['primarykey'];
      let foreignObj =  _.find(foreignkeycolumns ,{"fkeycol":column.tablecolumn});
    
      if(foreignObj){
       let referencedtable = foreignObj['referencedtable'];
        let parentJoinTable =  _.find(jointable ,{"tablename":referencedtable});
        let obj = column;
        obj['details'] = []; 
        this.createMastersFilterDataRec(obj['details'],parentJoinTable)
        arr.push(obj); 
      }else {
        arr.push(column);
      }
     });
      
   }
  
   createMastersFilterDataRec(arr,res){
    let columns =res['columns'];
    let jointable = res['jointable'];
    let foreignkeycolumns =res['foreignkeycolumns'];
    columns.forEach(column => {
      column['tablename'] = res['tablename'];
      column['entitytable'] = res['entitytable'];
      column['primarykey'] = res['primarykey'];
    
      let foreignObj =  _.find(foreignkeycolumns ,{"fkeycol":column.tablecolumn});
    
      if(foreignObj){
       let referencedtable = foreignObj['referencedtable'];
        let parentJoinTable =  _.find(jointable ,{"tablename":referencedtable});
        let obj = column;
        obj['details'] = []; 
        this.createMastersFilterDataRec(obj['details'],parentJoinTable)
        arr.push(obj); 
      }else {
        arr.push(column);
      }
     });
      
   }
  
   
  
   onClickFilterMasterDataOk(){
    let gridData  = this.gridDynamicFilterMasterMappingGrid.getGridData();
    let sqlWhere = [];
    let hqlWhere = [];
  
    let join = new Set();
    let hqljoin = new Set();
  
   let sqlSelect = this.createSqlSelect();
   let hqlSelect = this.createHqlSelect();
  
    gridData.forEach(row => {
      if(row.details){
        this.createSql(join,sqlWhere,row);
        this.createHql(hqljoin,hqlWhere,row);
      }
    });
   
   let sqlWhereStr =  _.join(sqlWhere, [' and ']);
   let hqlWhereStr =  _.join(hqlWhere, [' and ']);
  
   join.forEach(value => {
    sqlSelect = sqlSelect.concat(value+"");
   });
  
   hqljoin.forEach(value => {
    hqlSelect = hqlSelect.concat(value+"");
   });
  
   sqlSelect = sqlSelect.concat(" where "+sqlWhereStr);
   hqlSelect = hqlSelect.concat(" where "+hqlWhereStr);
  
  if(!this.excelMasterInfo['query']){
    this.excelMasterInfo['query'] = {}
  }
  this.excelMasterInfo['isFilterData'] = true;
  this.excelMasterInfo['query'] = {
    "hql":hqlSelect,
    "sql":sqlSelect,
  }
  
   this.executeQuery(sqlSelect,true);
  
  
  
   }
  
   executeQuery(query,isGridLoad){
    if (query) {
     
      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "details": {
          "sql": query,
          "queryType":"select"
      },
      }
      this._dbcomparetoolService.getexecuteSql(dbData).subscribe((res) => {
        if (res) {
          this.closeFilterMasterMappingModal();
          //this.tableDataMapMasterMapping.set(this.excelMasterInfo.tableName,res);
          this.getTableDataDropdownForMasterMapping(res,this.excelMasterInfo['nameTableColumn'],isGridLoad);
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }
   }
  
   createSqlSelect () {
    let tableName = this.excelMasterInfo.tableName;
    let nameTableColumn = this.excelMasterInfo.nameTableColumn;
    let codeTableColumn = this.excelMasterInfo.codeTableColumn;
    let primaryKeyTableColumn = this.excelMasterInfo["primaryKeyTableColumn"] ;
  
    let sqlSelect = "select " ;
    sqlSelect = sqlSelect + (tableName+"."+ primaryKeyTableColumn);
    sqlSelect = sqlSelect + (","+tableName+"."+ nameTableColumn);
    if(codeTableColumn!=""){
      sqlSelect = sqlSelect + (","+tableName+"."+ codeTableColumn);
    }
    sqlSelect = sqlSelect +(" from "+tableName);
   
    return sqlSelect;
   }
  
   createHqlSelect () {
    let entityName = this.excelMasterInfo['entityName'];
    let nameEntityColumn = this.excelMasterInfo['nameEntityColumn'];
    let primaryKeyEntityColumn = this.excelMasterInfo["primaryKeyEntityColumn"];
   let aliase =  this._getAliase(entityName);
    let sqlSelect = "select new map (" ;
    sqlSelect = sqlSelect + (aliase+"."+primaryKeyEntityColumn +" as id ");
    sqlSelect = sqlSelect + (","+ aliase+"."+nameEntityColumn + " as label");
    
    sqlSelect = sqlSelect +(" ) from "+entityName +" as " +aliase);
   
    return sqlSelect;
   }
  
   _getAliase(entityName:string){
     if(entityName){
      return entityName.substring(0, 1).toLowerCase()+entityName.substring(1); 
     }
    return entityName;
   }
  
   isAnyFieldSelected;
   createSql(join,sql,row){
     this.isAnyFieldSelected = false;
     this.getAnyFiledSelected(row.details);
    if(this.isAnyFieldSelected){
      let firstRow = row.details[0];
      join.add(" inner join "+firstRow.tablename + " on " +row.tablename+"."+row.tablecolumn +" = " +firstRow.tablename +"."+firstRow.primarykey+" "); 
    }
    row.details.forEach(element => {
      if(element.checkBox){
        sql.push(" "+element.tablename+"."+element.tablecolumn+" ='"+element.tableValue+"' ");
      }
      if(element.details){
        this.createSql(join,sql,element);
      }
    });
  
   }
  
   createHql(join,hql,row){
    this.isAnyFieldSelected = false;
    this.getAnyFiledSelected(row.details);
   if(this.isAnyFieldSelected){
    let firstRow = row.details[0];
    let aliase =  this._getAliase(firstRow.entitytable); 
    let aliase1 =  this._getAliase(row.entitytable);
    
    let joinStr = " inner join "+firstRow.entitytable + " "+aliase+ " on " +aliase1+"."+row.entitylabel +" = " +aliase +"."+firstRow.entitylabel+" ";
    // let joinStr =  " inner join "+aliase1+"."+row.entitylabel + " as " +aliase;
    join.add(joinStr);
  

   }
   row.details.forEach(element => {
     if(element.checkBox){
      let aliase =  this._getAliase(element.entitytable);
      hql.push(" "+aliase+"."+element.entitylabel+" ='"+element.tableValue+"' ");
     }
     if(element.details){
       this.createHql(join,hql,element);
     }
   });
  
  }
  
  
   getAnyFiledSelected (parentTableList){
     if(this.isAnyFieldSelected){
       return;
     }
    let data = _.find(parentTableList,{checkBox:true})
    if(data){
      this.isAnyFieldSelected = true;
    }
   
    if(!this.isAnyFieldSelected){
      parentTableList.forEach(element => {
        if(element.details){
          this.getAnyFiledSelected(element.details);
        }
      });
    }
    
   }
  
  notMatchExcelMasterList = [];
  notMatchTableMasterList = [];
  
  onClickCheckMismatchMaster(){
    this.notMatchTableMasterList = [];
    let masterList = this.excelMasterInfo.masterList;
    let gridData =  this.gridDynamicForMasterMapping.getGridData();
    let tableDataDropdownMasterMapping = this.tableDataDropdownMasterMapping;
  
   this.notMatchExcelMasterList =  masterList.filter(x => (!x['tableMasterName']));
  
    let tableDataList = tableDataDropdownMasterMapping.filter(x => (x['key'])).map(ele => ele['key']);
  
    tableDataList.forEach(field => {
      if(!_.find(gridData, { tableMasterName: field })){
        this.notMatchTableMasterList.push(field);
      }
    });
  
    this.openCheckMismatchMasterModalId();
  }
  
  
  addExcelMaster(){
      let obj = {
            "excelMaster":"",
            "tableMasterName": "",
            "tableMasterCode": "",
       }
       let sheetName = this.excelMasterInfo['name']
       if(sheetName){
       this.excelMasterInfo['masterList'].push(obj);
       this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']); 
       }   
  }
  
  deleteExcelMaster(){
    let sheetName = this.excelMasterInfo['name']
    if(sheetName){
      let selectedRowData = this.gridDynamicForMasterMapping.getSeletedRowData();
      this.excelMasterInfo['masterList'].splice(selectedRowData.sag_G_Index, 1);
      this.gridDynamicForMasterMapping.deleteRow(selectedRowData.sag_G_Index);
              if (this.gridDynamicForMasterMapping.sagGridObj
                && this.gridDynamicForMasterMapping.sagGridObj.AllRowIndex.length == 0) {
                  this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']); 
              }
    }
    
  }
  
  openCheckMismatchMasterModalId() {
    $('#checkMismatchMasterModalId').modal('show')
  }
  
  closeCheckMismatchMasterModalId() {
    $('#checkMismatchMasterModalId').modal('hide')
  }
  
   openFilterMasterMappingModal(){
    $('#filterMasterMappingId').modal('show')
   }
  
   closeFilterMasterMappingModal(){
     $('#filterMasterMappingId').modal('hide')
   }
  
   onChangeMasterMappingType(masterMappingType){
    if("map_with_table_data"!= masterMappingType){
      this.excelMasterInfo['tableName'] ="";
      this.excelMasterInfo['nameTableColumn'] ="";
      this.excelMasterInfo['codeTableColumn'] ="";
      this.excelMasterInfo['mappingType'] ="EXCEL_WISE";
      this.excelMasterInfo['sheetName'] ="";
     }
    this.masterMappingGrid(this.excelMasterInfo['masterList'],masterMappingType);
   }
  
    
     masterMappingGrid(rowsData,masterMappingType) {
      var sourceDiv = document.getElementById("masterMappingGridId");
      var columns = [
        {
          "header": "S.No",
          "field": "sno",
          "filter": true,
          "width": "50px",
          "editable": "false",
          "textalign": "center",
          "search": true,
        },
        {
          "header": "JSON Master Data",
          "field": "excelMaster",
          "filter": true,
          "width": "200px",
          "editable": "false",
          "textalign": "center",
          "search": true,
          "component": 'text',
          "cellRenderView": false
        },
        
    
      ];
      let constantValue = {
        "header": "Table Value",
        "field": "tableMasterName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      };
      let constantDisplayValue = {
        "header": "Display Value",
        "field": "tableMasterCode",
        "filter": true,
        "width": "450px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      };
      let tableMasterName = {
        "header": "Table Data Name",
        "field": "tableMasterName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      };
      
      let tableMasterCode = {
        "header": "Display Value",
        "field": "tableMasterCode",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      };

      if("map_with_constant_value" == masterMappingType){
        columns.push(constantValue);
        columns.push(constantDisplayValue);
      }else{
        columns.push(tableMasterName);
        columns.push(tableMasterCode);
      }

      let self = this;
    
      let components = {};
    
      var SagGridRowStatus = rowsData;
      for (var i = 0; i < SagGridRowStatus.length; i++) {
        SagGridRowStatus[i]["sno"] = i + 1;
      }
    
      if (undefined != sourceDiv) {
        var gridData = {
          columnDef: columns,
          rowDef: SagGridRowStatus,
          menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
          selection: "row",
          rowCustomHeight :20,
          cellCustomPadding:5,
          components: components,
          clientSidePagging: true,
          recordPerPage: 20,
          recordNo: true,
          callBack: {
            "onChangeSelect_tableMasterName": function (ele, params) {
              self.onChangetableMasterNameInGrid(ele.value, params.rowIndex)
            },
          },
          dropDownJson_tableMasterName: this.tableDataDropdownMasterMapping,
          
        };
        this.gridDynamicForMasterMapping = SdmtGridT(sourceDiv, gridData, true, true);
        return this.gridDynamicForMasterMapping;
      }
    }
    onChangetableMasterNameInGrid(value,rowIndex){
      let tableName =  this.excelMasterInfo['tableName'];
      let nameTableColumn =  this.excelMasterInfo['nameTableColumn'];
      let data =  this.tableDataMapMasterMapping.get(tableName);
      let codeTableColumn =  this.excelMasterInfo['codeTableColumn'];
     if(codeTableColumn){
      let item =_.find(data.gridarray, function(obj) {
        return obj[nameTableColumn] === value;
    });
    
      if(item){
        this.gridDynamicForMasterMapping.updateCell(rowIndex, "tableMasterCode", item[codeTableColumn]);
      }
     }
     
    }


    
  async importTableDataFromDb(){
   
    let tableName = this.excelMasterInfo['tableName'];
    let data = this.tableDataMapMasterMapping.get(tableName);
    let isFilterData = this.excelMasterInfo["isFilterData"]

    if (isFilterData) {
      if (this.excelMasterInfo['query']) {
        if (this.excelMasterInfo['query']) {
          if (this.excelMasterInfo['query']['sql']) {
            let query = this.excelMasterInfo['query']['sql']
            let dbData = {
              "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
              "targetDataSource": {},
              "operation": "COMPARESINGLE",
              "connectionRoleType": "admin",
              "dbtype": "master",
              "details": {
                "sql": query,
                "queryType": "select"
              },
            }
            this._dbcomparetoolService.getexecuteSql(dbData).subscribe((res) => {
              if (res) {
                this.createMasterRow(res);
              
                this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']); 
    
                
              }
            }, Error => {
              alerts("Error While Fetching data");
            });
          }
        }
      }
    } else {
      if (data) {
        this.createMasterRow(data);
        
        this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']); 
    
        
      }
    }
    
  }

  createMasterRow(data) {
    
    let nameTableColumn = this.excelMasterInfo['nameTableColumn'];
    let codeTableColumn = this.excelMasterInfo['codeTableColumn'];


    this.excelMasterInfo['masterList'] = [];
    data.gridarray.forEach(element => {
      let obj = {
        excelMaster: element[nameTableColumn],
        tableMasterName: element[nameTableColumn],
        tableMasterCode: element[codeTableColumn],
      }

      this.excelMasterInfo['masterList'].push(obj);
    });

    return  this.excelMasterInfo['masterList'];
  }
  
    masterName:String = "";
    addMasterName(){
      this.masterName = "";
      this.openMasterNameModal();
    }
    async deleteMasterName(){
      if (await ui.confirm('Do You Want To Delete Master ?')) {
 
        if(this.jsonMasterList){
          for (let index = 0; index < this.jsonMasterList.length; index++) {
            const element = this.jsonMasterList[index];
            if(element['active']){
              this.jsonMasterList.splice(index, 1);
            }
          }
         }
         if(this.jsonMasterList && this.jsonMasterList.length > 0 ){
          this.onClickMasterHeader(this.jsonMasterList[0], 1);
        }else{
          this.masterMappingGrid([],"map_with_constant_value");
        }

        }
    }

    onClickAddMasterName(){
      if(!this.masterName){
       alerts("Master name not valid");
      }
      
     let find =  _.find(this.jsonMasterList , {"name" : this.masterName});
     if(find){
       alerts(this.masterName+ " Already exist")
       return;
     }
      let obj = {
        "name": this.masterName,
        "tableName": "",
        "active": false,
        "nameTableColumn": "",
        "codeTableColumn": "",
        "masterList": [],
        'masterMappingType':"map_with_table_data",
        'excelMasterList': [],
        'isMasterManualCreate':true,
       
      };
     this.jsonMasterList.push(obj);
     this.closeMasterNameModal();

    }

    openMasterNameModal(){
      $('#addMasterNameModal').modal('show')
     }
    
     closeMasterNameModal(){
       $('#addMasterNameModal').modal('hide')
     }

     /**************************************Import Excel Master************************************************************************* */
     importExcelMasterObj
     importExcelMaster(){
      this.openImportMasterNameModal();
      this.importExcelMasterList;
     }


     onClickImportExcelMaster(){
     if(!this.importExcelMasterObj){
       alerts("Please Select Master name");
       return ; 
     }
     
     let sheetList = [];
    

    if("SHEET_WISE" == this.importExcelMasterObj['mappingType']){
     if(this.importExcelMasterObj['query']){
     let query =  this.importExcelMasterObj['query'];
      for (const property in query) {
        sheetList.push(property);
      }
     }
    }else{
     sheetList = [""];
    
    }

    
    sheetList.forEach(sheetName => {
      let suffix = sheetName ? " "+sheetName : sheetName;
      let masterName = this.importExcelMasterObj.name+suffix
      let find =  _.find(this.jsonMasterList , {"name" : masterName});
      if(find){
       alerts(masterName+ " Already exist")
       return;
      }
      let masterList =  [];
    
    this.importExcelMasterObj.masterList[sheetName].forEach(element => {
      let obj = {
        excelMaster : element['tableMasterCode'],
        tableMasterCode:element['tableMasterName'],
        tableMasterName:element['tableMasterCode']
      }
      masterList.push(obj);
    });

     let obj = {
       "name": masterName,
       "tableName": this.importExcelMasterObj.tableName,
       "entityName": this.importExcelMasterObj.entityName,
       "active": false,
       "primaryKeyEntityColumn": this.importExcelMasterObj.primaryKeyEntityColumn,
       "primaryKeyTableColumn": this.importExcelMasterObj.primaryKeyTableColumn,
       "codeTableColumn": this.importExcelMasterObj.nameTableColumn,
       "codeEntityColumn": this.importExcelMasterObj.nameEntityColumn,
       "nameTableColumn": this.importExcelMasterObj.codeTableColumn,
       "nameEntityColumn": this.importExcelMasterObj.codeEntityColumn,
       "masterList": masterList,
       "masterMappingType": this.importExcelMasterObj.masterMappingType,
       
     };
     if(this.importExcelMasterObj['query']){
     if(this.importExcelMasterObj['query'][sheetName]){
      obj['isFilterData'] = true;
      obj['query'] =  this.importExcelMasterObj['query'][sheetName];
     }
     
     }
     
  
    this.jsonMasterList.push(obj);
    });
    
     
    this.closeImportMasterNameModal();
    
  }

     openImportMasterNameModal(){
      $('#importExcelMasterModal').modal('show')
     }
    
     closeImportMasterNameModal(){
      this.importExcelMasterObj = null;
       $('#importExcelMasterModal').modal('hide')
     }

     /*****************************************Display Configuration******************************************************************/

     gridDynamicForDisplayConfiguration:any;

     onClickDisplayConfiguration(){
      this.openDisplayConfigurationModal();
      let item = _.find(this.jsonSchemaList,{"displayActive":true});
      if(item){
        this.onClickDisplayConfigurationTab(item,null);
      }
     }

     onClickDisplayConfigurationTab(item: any, index) {
      this.jsonSchemaList.forEach(itm => itm.displayActive = false);
      item['displayActive'] = true;

      this.displayConfigurationGrid(item.details); 
     }
     okDisplayConfigurationModal(){
      this.closeDisplayConfigurationModal();
     }

     openDisplayConfigurationModal(){
      $('#displayConfigurationModal').modal('show')
     }
    
     closeDisplayConfigurationModal(){
       $('#displayConfigurationModal').modal('hide')
     }

     displayConfigurationGrid(rowsData) {
      var sourceDiv = document.getElementById("displayConfigurationGridId");
      var columns = [
        {
          "header": "S.No",
          "field": "sno",
          "filter": true,
          "width": "50px",
          "editable": "false",
          "textalign": "center",
          "search": true,
        },
        {
          "header": "Name",
          "field": "name",
          "filter": true,
          "width": "200px",
          "editable": "false",
          "textalign": "center",
          "search": true,
          "component": 'label',
          "cellRenderView": false
        },
        {
          "header": "Description",
          "field": "description",
          "filter": true,
          "width": "200px",
          "editable": "false",
          "textalign": "center",
          "search": true,
          "component": 'label',
          "cellRenderView": false
        },
        {
          "header": "Caption",
          "field": "caption",
          "filter": true,
          "width": "200px",
          "editable": "false",
          "textalign": "center",
          "search": true,
          "component": 'text',
          "cellRenderView": false
        },
        {
          "header": "Show Column",
          "field": "isDisplayColumn",
          "filter": true,
          "width": "150px",
          "editable": "false",
          "text-align": "center",
          "search": true,
          "component": 'checkbox',
          "cellRenderView": true
        },
        {
          "header": "Modify Column",
          "field": "isModifyColumn",
          "filter": true,
          "width": "150px",
          "editable": "false",
          "text-align": "center",
          "search": true,
          "component": 'checkbox',
          "cellRenderView": true,
        },
        {
          "header": "Text Align",
          "field": "textAlign",
          "filter": true,
          "width": "150px",
          "editable": "false",
          "text-align": "center",
          "search": true,
          "component": 'select',
          "cellRenderView": false
        },
        {
          "header": "Sequence",
          "field": "columnSequence",
          "filter": true,
          "width": "150px",
          "editable": "false",
          "text-align": "center",
          "search": true,
          "component": 'select',
          "cellRenderView": false
        },
        {
          "header": "Decimal Format",
          "field": "decimalFormat",
          "filter": true,
          "width": "150px",
          "editable": "false",
          "text-align": "center",
          "search": true,
          "component": 'multiSelect',
          "cellRenderView": true
        },
        {
          "header": "Decimal Digit",
          "field": "decimalDigit",
          "filter": true,
          "width": "150px",
          "editable": "false",
          "text-align": "center",
          "search": true,
          "component": 'text',
          "cellRenderView": false
        },
        // {
        //   "header": "Round Number",
        //   "field": "roundNumber",
        //   "filter": true,
        //   "width": "150px",
        //   "editable": "false",
        //   "text-align": "center",
        //   "search": true,
        //   "component": 'checkbox',
        //   "cellRenderView": true
        // },
        // {
        //   "header": "Round Digit",
        //   "field": "roundDigit",
        //   "filter": true,
        //   "width": "150px",
        //   "editable": "false",
        //   "text-align": "center",
        //   "search": true,
        //   "component": 'checkbox',
        //   "cellRenderView": true
        // },

      ];
      let self = this;
      
      let components = {};
      let numberFormate = [
        { "key": "decimal_format", "val": "Decimal Format" },
        { "key": "round_number", "val": "Round Number" },
       
        
       ];
     
      let textAlignList = [
        { "key": "", "val": "--Select--" },
        { "key": "left", "val": "LEFT" },
        { "key": "right", "val": "RIGHT" },
        { "key": "center", "val": "CENTER" },
       ];
       let sequenceList = [
        { "key": "", "val": "--Select--" }
       ]
       for (i = 1; i <= 100; i++) {
        let obj = { "key": i+"", "val":i+"" }
        sequenceList.push(obj);
      }

      var SagGridRowStatus = rowsData;
      for (var i = 0; i < SagGridRowStatus.length; i++) {
        SagGridRowStatus[i]["sno"] = i + 1;
      }
     
      
      if (undefined != sourceDiv) {
        var gridData = {
          columnDef: columns,
          rowDef: SagGridRowStatus,
          menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
          selection: "row",
          frezzManager: { "sno": "left", "name": "left","description":"left"},
          rowCustomHeight :20,
          cellCustomPadding:5,
          components: components,
          clientSidePagging: true,
          recordPerPage: 20,
          recordNo: true,
          callBack: {},

          dropDownJson_textAlign: textAlignList,
          dropDownJson_columnSequence: sequenceList,
          multidropDownJson_decimalFormat: numberFormate,

          rowGrouping: {
            "enable": true,
            "groupType": "custome",
            "groupBy": "name",
            "expandRow": []
          },
          rowSelection: false,
          rowDataViewTotal: true,
          sml_expandGrid_hide: true,
          exportXlsxPage_hide: true,
          exportXlsxAllPage_hide: true,
          exportPDFLandscape_hide: true,
          exportPDFPortrait_hide: true,
          ariaHidden_hide: true,
          
        };
        this.gridDynamicForDisplayConfiguration = SdmtGridT(sourceDiv, gridData, true, true);
       
        this.setColorPropertiesForDisplayConfig(this.gridDynamicForDisplayConfiguration.getGridData());
        this.gridDynamicForDisplayConfiguration.expandAll();
        return this.gridDynamicForDisplayConfiguration;
      }
      }
     
      setColorPropertiesForDisplayConfig(gridData){
 
        gridData.forEach(rowData => {
          if(rowData.details){
            let colorProperty = {"background-color":"rgb(195 195 195)"}
            this.gridDynamicForDisplayConfiguration.disableRow( rowData.sag_G_Index);
            this.gridDynamicForDisplayConfiguration.setRowProperty(rowData.sag_G_Index,colorProperty);
            this.setColorPropertiesForDisplayConfig(rowData.details)
          }
        });
      }


      /***************************************Ellipsis********************************************************* */

 
      copyRow(ele,param){
        let rowValue = param.rowValue;
        this.copyPastEllipsisValue = JSON.parse(JSON.stringify(rowValue)); 
      }
      

      pasteRowSheetMapping(index){
        let data = this.copyPastEllipsisValue;
        if(data){
          let details = this.jsonSchema['details'];
          this.isRecursionOff = false;
          this.addRecursionRowForElipsis(details,index,data);
          this.jsonMappingGrid(this.jsonSchema['details'],this.jsonSchema.jsonType);
          this.gridDynamicForJsonMapping.expandAll();
        }
      }

      addRowEllipsis(index){
        let details = this.jsonSchema['details'];
        this.isRecursionOff = false;
        this.addRecursionRowForElipsis(details,index,this.getEmptyObjForAddRow());
      
        this.jsonMappingGrid(this.jsonSchema['details'],this.jsonSchema.jsonType);

        this.gridDynamicForJsonMapping.expandAll();
      }
      
      addRecursionRowForElipsis(details,sag_G_Index,data){
        if(this.isRecursionOff){
          return;
        }
        if(details){
         for (let index = 0; index < details.length; index++) {
          if(this.isRecursionOff){
            break;
          }
           const rowData = details[index];
           if(rowData.sag_G_Index == sag_G_Index){
            details.splice(index+1, 0,data);

            let allSheetHeaderListSimpleFormat =   this._getApiFieldSimpleFormate(this.jsonSchema['details']);

            this.autoSetFormula(rowData.sag_G_Index,this.jsonSchema['details'],allSheetHeaderListSimpleFormat,"add");
            this.isRecursionOff = true;
            break;
          }else{
            this.addRecursionRowForElipsis(rowData.details,sag_G_Index,data)
          };
      
         }
        }
      }
      
      addExtraMasterField(rowIndex){
        this.openAddMasterExtraColumnModal();
        let selectedRowData = this.gridDynamicForJsonMapping.getSeletedRowData();
      
        let childMasterExtraFields = selectedRowData.childMasterExtraFields;
        if(childMasterExtraFields){
          this.addMasterExtraColumnGrid(childMasterExtraFields);
          setTimeout(() => {
            this.bindSheetDataForMasterExtraFields();
           
          }, 500);
          
        }else{
          this.addMasterExtraColumnGrid([]);
        }
       
      }
      
      bindSheetDataForMasterExtraFields(){
        if(this.gridDynamicAddMasterExtraColumn){
         let gridData = this.gridDynamicAddMasterExtraColumn.getGridData();
         if(gridData){
           gridData.forEach(rowData => {
             if(rowData.tableName && rowData.tableField){
               this.onChangeTableForMasterExtraColumn(rowData.tableName, rowData.sag_G_Index,rowData.tableField);
               this.setTableNameIntoDataBindFromForMaster(rowData.tableName);
             }
           });
         }
        }
      }
      
      okMasterExtraColumn(){
        let selectedRowData = this.gridDynamicForJsonMapping.getSeletedRowData();
        let gridData = this.gridDynamicAddMasterExtraColumn.getGridData();
        if(gridData){
          this.gridDynamicForJsonMapping.updateCell(selectedRowData.sag_G_Index, "childMasterExtraFields",gridData);
        }else{
          this.gridDynamicForJsonMapping.updateCell(selectedRowData.sag_G_Index, "childMasterExtraFields",[]);
        }
        
      
        this.closeAddMasterExtraColumnModal();
       }
      
      openAddMasterExtraColumnModal(){
        $('#addMasterExtraColumnModal').modal('show')
       }
       
       closeAddMasterExtraColumnModal(){
         $('#addMasterExtraColumnModal').modal('hide')
       }
      
       addMasterExtraColumnGrid(rowsData) {
        var sourceDiv = document.getElementById("addMasterExtraColumnGridId");
        var columns:any = [
          {
            "header": "S.No",
            "field": "sno",
            "filter": true,
            "width": "50px",
            "editable": "false",
            "textalign": "center",
            "search": true,
          },
          {
            "header": "Header Name",
            "field": "name",
            "filter": true,
            "width": "200px",
            "editable": "false",
            "textalign": "center",
            "search": true,
            "component": 'text',
            "cellRenderView": false
          },
          {
            "header": "Data Find From",
            "field": "dataFindFrom",
            "filter": true,
            "width": "150px",
            "editable": "false",
            "textalign": "center",
            "search": true,
            "component": 'select',
            "cellRenderView": false
          },
          {
            "header": "Sheet Column",
            "field": "sheetColumnReference",
            "filter": true,
            "width": "150px",
            "editable": "false",
            "textalign": "center",
            "search": true,
            "component": 'select',
            "cellRenderView": false
          },
          {
            "header": "Column Type",
            "field": "columnType",
            "filter": true,
            "width": "150px",
            "editable": "false",
            "textalign": "center",
            "search": true,
            "component": 'select',
            "cellRenderView": false
          },
          {
            "header": "Date Format",
            "field": "dateFormat",
            "filter": true,
            "width": "150px",
            "editable": "false",
            "textalign": "center",
            "search": true,
            "component": 'select',
            "cellRenderView": false
          },
          {
            "header": "Table Name",
            "field": "tableName",
            "filter": true,
            "width": "150px",
            "editable": "false",
            "textalign": "left",
            "search": true,
            "component": 'select',
            "cellRenderView": false
          },
          {
            "header": "Table Field",
            "field": "tableField",
            "filter": true,
            "width": "150px",
            "editable": "false",
            "textalign": "center",
            "search": true,
            "component": 'select',
            "cellRenderView": false
          },
          {
            "header": "Table Properties",
            "field": "tableProperties",
            "filter": true,
            "width": "150px",
            "editable": "false",
            "textalign": "center",
            "search": true,
            "component": 'label',
            "cellRenderView": true
          },
          
          {
            "header": "Unique Constraint",
            "field": "uniqueConstraint",
            "filter": true,
            "width": "150px",
            "editable": "false",
            "text-align": "center",
            "search": true,
            "component": 'checkbox',
            "cellRenderView": true
          },
          {
            "header": "Formula/Static Value/Method Calling",
            "field": "formulaStaticValue",
            "filter": true,
            "width": "250px",
            "editable": "false",
            "textalign": "center",
            "search": true,
            "component": 'text',
            "cellRenderView": false
          },
          
        ];
      
        let self = this;
      
        let fieldTypeList = [
          { "key": "", "val": "--Select--" },
          { "key": "STRING", "val": "STRING" },
          { "key": "NUMERIC", "val": "NUMERIC" },
          { "key": "BOOLEAN", "val": "BOOLEAN" },
          { "key": "DATE", "val": "DATE" },
      
        ];
       
       
      
      
         let dataFindFrom = [
          { "key": "", "val": "--Select--" },
          { "key": "_sheet", "val": "Sheet" },
          { "key": "client_side", "val": "Client Side" },
          { "key": "by_manual_method", "val": "Manual Method With static" },
          { "key": "static_value", "val": "Static Value" },
         ];
      
      
        var SagGridRowStatus = rowsData;
        for (var i = 0; i < SagGridRowStatus.length; i++) {
          SagGridRowStatus[i]["sno"] = i + 1;
          
        }
      
        if (undefined != sourceDiv) {
          var gridData = {
            columnDef: columns,
            rowDef: SagGridRowStatus,
            menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
            selection: "row",
            frezzManager: { "sno": "left", "name": "left","cellDesc":"left","cellRefrence":"left" },
            components: {},
            rowCustomHeight :20,
            cellCustomPadding:5,
            clientSidePagging: true,
            recordPerPage: 20,
            recordNo: true,
            callBack: {
              "onChangeSelect_tableName": function (ele, params) {
                let value = ele.value;
                ele.onkeydown = function (event) {
                  if (event.keyCode == 13) {
                    self.fillTableNameSameValueForMasterExtraColumn(params, value);
                    
                  }
                }
                self.onChangeTableForMasterExtraColumn(ele.value, params.rowIndex,null);
                self.setTableNameIntoDataBindFromForMaster(ele.value);
              },
              "onChangeSelect_dataFindFrom": function (ele, params) {
               if("_sheet"==ele.value){
                self.gridDynamicAddMasterExtraColumn.enableCell(params.rowIndex, "sheetColumnReference");
               
               }else{
                self.gridDynamicAddMasterExtraColumn.disableCell(params.rowIndex, "sheetColumnReference");
                self.gridDynamicAddMasterExtraColumn.updateCell(params.rowIndex, "sheetColumnReference","");
               }
              },
              "onChangeSelect_tableField": function (ele, params) {
                self.onChangeTableFieldForMasterExtraFields(ele.value, params)
              },
             
            },
         
            dropDownJson_columnType: fieldTypeList,
            dropDownJson_tableName: this.tableListDropdownList,
            dropDownJson_tableField: [{ "key": "", "val": "--Select--" }],
            dropDownJson_dataFindFrom: dataFindFrom, 
            dropDownJson_sheetColumnReference: this._getSheetColumnRefernce(), 
            dropDownJson_dateFormat:this.dateFormateList,
          };
        
      
          this.gridDynamicAddMasterExtraColumn = SdmtGridT(sourceDiv, gridData, true, true);
        
          this.disableSheetColumnRef();
          return this.gridDynamicAddMasterExtraColumn;
        }
      }
      
      async fillTableNameSameValueForMasterExtraColumn(params, tableName){
        if (await ui.confirm('Do You Want To Fill Same Value In Next Remainig Row ?')) {
         let gridsize = this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length;
         for (let i = params.rowIndex; i < gridsize; i++) {
           this.gridDynamicAddMasterExtraColumn.updateCell(i, "tableName", tableName);
           this.onChangeTableForMasterExtraColumn(tableName, i,null);
           this.setTableNameIntoDataBindFromForMaster(tableName);
          
         }
        }
       }
      
      disableSheetColumnRef(){
        let gridData =  this.gridDynamicAddMasterExtraColumn.getGridData();
        if(gridData){
          gridData.forEach(element => {
            if("_sheet"==element.dataFindFrom){
              this.gridDynamicAddMasterExtraColumn.enableCell(element.sag_G_Index, "sheetColumnReference");
             }else{
              this.gridDynamicAddMasterExtraColumn.disableCell(element.sag_G_Index, "sheetColumnReference");
              this.gridDynamicAddMasterExtraColumn.updateCell(element.sag_G_Index, "sheetColumnReference","");
             }
          });
        }
      }
      
      sheetColumnDrodown = [{ "key": "", "val": "--Select--" }]
      _getSheetColumnRefernce(){
      
        this.sheetColumnDrodown = [{ "key": "", "val": "--Select--" }];
      
      let selectedRowData =  this.gridDynamicForJsonMapping.getSeletedRowData();
      let rowIndex = selectedRowData.sag_G_Index;
      
      let gridData =  this.gridDynamicForJsonMapping.getGridData();
      this._getSheetColumnRefernceRecursion(gridData,rowIndex)
        
      return this.sheetColumnDrodown;
      
      }

      _getSheetColumnRefernceRecursion(gridData,rowIndex){
        if (gridData) {
          gridData.forEach(element => {
            if(element.details){
              this._getSheetColumnRefernceRecursion(element.details,rowIndex);
            } else{
              if (element.sag_G_Index <= rowIndex || "client_side" == element.dataFindFrom) {
                let obj = {
                  "key": element.name,
                  "val": element.name
                }
                this.sheetColumnDrodown.push(obj);
              }
            }
          });
        }
      }

      
      
      onChangeTableForMasterExtraColumn(tableName, rowIndex,tableFieldBind) {
        if (tableName) {
      
          let dbData = {
            "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
            "targetDataSource": {},
            "operation": "COMPARESINGLE",
            "connectionRoleType": "admin",
            "dbtype": "master",
            "tableName": tableName
          }
          this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
            if (res) {
              this.setTableFieldDropdownForMasterExtraColumn(res, rowIndex,tableFieldBind,tableName);
            }
          }, Error => {
            alerts("Error While Fetching data");
          });
        }
      
      }
      
      setTableFieldDropdownForMasterExtraColumn(res, rowIndex,tableFieldBind,tableName) {
        this.tableFieldDropdownListForJson = [{ "key": "", "val": "--Select--" }];

        let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);

       
        tableFieldsInfo.forEach(tableColumn => {
          let obj = {
            "key": tableColumn['columnName'],
            "val": tableColumn['columnName']
          }
         this.tableFieldDropdownListForJson.push(obj);
        });

        this.tableFieldsMapForJson.set(tableName, tableFieldsInfo);

        if (this.gridDynamicAddMasterExtraColumn && this.gridDynamicAddMasterExtraColumn.sagGridObj.components['tableField']) {
          this.gridDynamicAddMasterExtraColumn.sagGridObj.components['tableField'].setOptionRow(this.tableFieldDropdownListForJson, "tableField", rowIndex);
          if(tableFieldBind){ 
           this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableField", tableFieldBind);
      
           let tableFieldsList = this.tableFieldsMapForJson.get(tableName);
           let item = _.find(tableFieldsList, { "columnName": tableFieldBind });
           if (item) {
             this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
             this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", item.dataType);
           }
      
           let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
           if(pkObj){
            this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKey", pkObj.columnName);
            this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
           }
      
          }
        }
      }
      
      onChangeTableFieldForMasterExtraFields(tableField, params) {
        let rowIndex = params.rowIndex;
        if (tableField) {
          let tableName = params.rowValue.tableName;
         
          let tableFieldsList = this.tableFieldsMapForJson.get(tableName);
          let item = _.find(tableFieldsList, { "columnName": tableField });
          if (item) {
            this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
            this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", item.dataType);
            
          }
          let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
          if(pkObj){
           this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKey", pkObj.columnName);
           this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
          }
      
        }else{
          this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties", '');
          this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", '');
        }
      }
      
      addRowMasterExtraColumn(){
      
        let selectedRowData = this.gridDynamicForJsonMapping.getSeletedRowData();
        let tableMaster = selectedRowData.tableMaster
      
        let index = this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length;
        let obj = {
              "dataBindFrom":"",
              "name": "",
              "modelFieldName": "",
              "index": "",
              "tableName":tableMaster,
              "tableField":"",
              "tableProperties":"",
            
         }
      
         this.gridDynamicAddMasterExtraColumn.addRowByIndex(index, obj);
         setTimeout(() => {
          this.onChangeTableForMasterExtraColumn(tableMaster, index,null);
          this.setTableNameIntoDataBindFromForMaster(tableMaster);
         }, 500);
         
      }
      
      deleteRowMasterExtraColumn(){
        let selectedRowData = this.gridDynamicAddMasterExtraColumn.getSeletedRowData();
        if(selectedRowData){
          this.gridDynamicAddMasterExtraColumn.deleteRow(selectedRowData.sag_G_Index);
          if (this.gridDynamicAddMasterExtraColumn.sagGridObj
            && this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length == 0) {
            this.addMasterExtraColumnGrid([]); 
      }
        }
      
      }
      
      setTableNameIntoDataBindFromForMaster(tableName){
      
        // let dataFindFrom = [
        //   { "key": "", "val": "--Select--" },
        //   { "key": "_sheet", "val": "Sheet" },
        //   { "key": "client_side", "val": "Client Side" },
        //   { "key": "by_manual_method", "val": "Manual Method With static" },
        //   { "key": "static_value", "val": "Static Value" },
        //  ];
      
        // let gridData = this.gridDynamicAddMasterExtraColumn.getGridData();
        // let tableList = _.map(gridData, 'tableName');
        // tableList.push(tableName);
        // tableList = _.uniq(tableList);
      
      
        // if(tableList){
        //   tableList.forEach(element => {
        //     if(element){
        //       dataFindFrom.push({
        //         "key": "pk_of_"+element, "val": "Pk of "+element
        //       });
        //     }
            
        //   });
        // }
        // if(this.gridDynamicAddMasterExtraColumn && this.gridDynamicAddMasterExtraColumn.sagGridObj.components['dataFindFrom']){
        //   this.gridDynamicAddMasterExtraColumn.sagGridObj.components['dataFindFrom'].setOption(dataFindFrom);
        // }
       
      }

      validateExcelData(excelSheetList) {
        this.jsonSchemaList = excelSheetList;
    
        let item = _.find(this.jsonSchemaList, { active: true });
        if (item) {
          setTimeout(() => {
            this.onClickJsonObject(item, 1);
          }, 100);
        }
    
      }
    
      setValidationRowProperty(rowsData) {
    
        for (let i = 0; i < rowsData.length; i++) {
          const element = rowsData[i];
          if (element.isInvalid) {
            let colorProperty = { "background-color": "rgb(255, 204, 203)" }
            this.gridDynamicForJsonMapping.setRowProperty(element.sag_G_Index, colorProperty);
            let errorResponse = element['toolTipMsg'];
            for (let key in errorResponse) {
              if (errorResponse.hasOwnProperty(key)) {
                let value = errorResponse[key];
                let cellColorProperty = { "background-color": "#dc3545" }
                this.gridDynamicForJsonMapping.setColRowProperty(element.sag_G_Index, key, cellColorProperty);
              }
            }
          }
          if (element.details) {
            this.setValidationRowProperty(element.details);
          }
        }
    
      }

      /**************************************Validation*********************************************************** */

  onClickValidation(params) {

    let index = params.rowIndex

    if (params.rowValue.type) {

      let columnType = params.rowValue.type;
      let validation = params.rowValue.validation

      const ref = this.dialogService.open(ImportExportValidationComponent, {
        header: "Validation",
        width: "100%",
        contentStyle: { "margin-top": "0px", "height": "100%" },
        styleClass: "service_full_model excel-demo-view",
        data: { "columnType": columnType, "validation": validation },

      });
      ref.onClose.subscribe((res) => {
        if (res) {
          this.gridDynamicForJsonMapping.updateCell(index, "validation", res);
        }
      });
    }
    else{
      alerts("Please select first column type");
     }
  }

/********************* Context Menu ***************************************** */
 
@ViewChild("editSheetTabName", { static: false }) editSheetTabName: ElementRef;
displayContextMenu(event,item){
  if(this.jsonSchema['name'] != item.name){
    this.onClickJsonObject(item, 1);
  }
  let self = this;
  event.preventDefault();
  new Contextual({
    isSticky: false,
    items: [
      new ContextualItem({ cssIcon:"fa fa-edit",label: 'Rename', onClick: () => { self.renameSheetName() } }),
      new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete', onClick: () => { self.deleteJsonSection() } }),
    //   new ContextualItem({ label: 'Add Synonym', 
    //   submenu:  [
    //     new ContextualItem({ label: 'Test',
    //     submenu:  [
    //       new ContextualItem({ label: 'Modify'}),
    //       new ContextualItem({ label: 'Delete' }),
    //     ]
    //   } ),
    //   ]
    // }),
    ]
  });

}


async deleteJsonSection(){
  if (await ui.confirm('Do You Want To Delete Report Section ?')) {
 
    if(this.jsonSchemaList){
      for (let index = 0; index < this.jsonSchemaList.length; index++) {
        const element = this.jsonSchemaList[index];
        if(element['active']){
          this.jsonSchemaList.splice(index, 1);
        }
      }
     }
    }
}

@HostListener('document:click', ['$event', '$event.target'])
public onClick(event: MouseEvent, targetElement: HTMLElement): void {
    if (!targetElement) {
        return;
    }
    
    if(this.editSheetTabName){
      const clickSheetTabName = this.editSheetTabName.nativeElement.contains(targetElement);
      if (!clickSheetTabName) {
         this.jsonSchema['isRename'] = false;
      }
    }

    if(this.editMasterTabName){
      const clickMasterTabName = this.editMasterTabName.nativeElement.contains(targetElement);
      if (!clickMasterTabName) {
         this.excelMasterInfo['isRename'] = false;
      }
    }
   
}

renameSheetName(){
  this.jsonSchema['isRename'] = true;
}

@ViewChild("editMasterTabName", { static: false }) editMasterTabName: ElementRef;
displayContextMenuForMaster(event,item){
  if(this.excelMasterInfo['name'] != item.name){
    this.onClickMasterHeader(item, 1);
  }
  let self = this;
  event.preventDefault();
  new Contextual({
    isSticky: false,
    items: [
      new ContextualItem({ cssIcon:"fa fa-edit", label: 'Rename', onClick: () => { self.renameMasterName() } }),
      new ContextualItem({ cssIcon:"fa fa-plus", label: 'Add Master', onClick: () => { self.addMasterName() } }),
      new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Master', onClick: () => { self.deleteMasterName() } }),
    ]
  });

}


renameMasterName(){
  this.excelMasterInfo['isRename'] = true;
}


jsonSectionName:"";

openJsonSectionNameModal(){
  $('#addReportSectionNameModal').modal('show')
 }

 closeJsonSectionNameModal(){
   $('#addReportSectionNameModal').modal('hide')
 }

 addJsonSection(){
  this.jsonSectionName = "";
  this.openJsonSectionNameModal();
}
  
  onClickAddJsonSectionName(){
    if(!this.jsonSectionName){
     alerts("name not valid");
    }
    
   let find =  _.find(this.jsonSchemaList , {"name" : this.jsonSectionName});
   if(find){
     alerts(this.jsonSectionName+ " Already exist")
     return;
   }

  let jsonSectionData = {
    "excelSheetName":"",
    "importDataInsertType":[],
    "jsonType":"dynamic",
    "varriableMappingType":"table",
    "varriableMappingData":[],
    "name":this.jsonSectionName,
    "tableRelations":[]
  };
  
    
   this.jsonSchemaList.push(jsonSectionData);
   this.closeJsonSectionNameModal();

  }

/**************************************Auto set Formula*********************************************************** */


autoSetFormula(rowIndex,gridData,allSheetHeaderListSimpleFormat,opName:String){ 
  //let  gridData =  this.jsonSchema['details'];

  for (let index = 0; index < gridData.length; index++) {
    
     const element = gridData[index];

     if(element.details){
      this.autoSetFormula(rowIndex,element.details,allSheetHeaderListSimpleFormat,opName);
     } else {
      if ("Formula" == element.dataFindFrom) {
        let formulaStaticValue = element.formulaStaticValue;
        if (formulaStaticValue) {
          let replaceValue = this._getCalculateValueBodyForDisplay(allSheetHeaderListSimpleFormat, formulaStaticValue, rowIndex,opName);
          gridData[index]["formulaStaticValue"] = replaceValue;
        }
      }
  
      if ("by_manual_method_with_aliase" == element.dataFindFrom) {
      
        let formulaStaticValue = element.formulaStaticValue;
      
        if (formulaStaticValue) {
          const argument = formulaStaticValue.substring(formulaStaticValue.indexOf("(") + 1, formulaStaticValue.indexOf(")"));
          let replaceArgument = this._getCalculateValueBodyForDisplay(allSheetHeaderListSimpleFormat, argument, rowIndex,opName);
          const methodName = formulaStaticValue.substring(0, formulaStaticValue.indexOf("("));
          const changeMethod = `${methodName}(${replaceArgument})`;
          gridData[index]["formulaStaticValue"] = changeMethod;
        }
      }
     }
  }
  }

  


  _getCalculateValueBodyForDisplay(sheetHeaderList, formulaStaticValue,rowIndex,opName:String) {
    let split = formulaStaticValue.split(/[^\w\s]/gi);
  
    let list = split.slice();

    list  = _.map(list,_.trim)

    list.sort((a, b) => b.length - a.length);
  
    let number = 0;
    for (let value of list) {
      if (this.isValidFormulaAliase(formulaStaticValue, value)) {
        let findAny = sheetHeaderList.find(ele => value === ele.headerAlias);
        if (findAny) {
          if(rowIndex < findAny.sag_G_Index){
            number++;
            formulaStaticValue = formulaStaticValue.replace(value, `%${number}$s`);
          }
         
        }
      }
    }
  
    let replaceNumber = 0;
    for (let value of list) {
      if (this.isValidFormulaAliase(formulaStaticValue, value)) {
        let findAny = sheetHeaderList.find(ele => value === ele.headerAlias);
        if (findAny) {
          if(rowIndex < findAny.sag_G_Index){
          replaceNumber++;
          let replaceIndex = findAny.sag_G_Index + 2;
          if("delete" == opName){
            /***sag_g_index not change because grid not load ***** */
            replaceIndex = findAny.sag_G_Index 
          } 

          let replaceValue = this.sheetHeaderAlias[replaceIndex];
          formulaStaticValue = formulaStaticValue.replace(`%${replaceNumber}$s`, replaceValue);
          }
        }
      }
    }
    return formulaStaticValue;
  }
  
   isValidFormulaAliase(formula, value) {
    let isValid = this.isAlphabet(value);
    if (isValid) {
      if (formula.includes(`'${value}'`) || formula.includes(`"${value}"'`) || value.trim() === "null") {
        return false;
      }
    }
    return isValid;
  }
  
   isAlphabet(value) {
    return /^[a-zA-Z]+$/.test(value);
  }
  
   checkHeaderAliaseUsage(){
    let selectedRowData = this.gridDynamicForJsonMapping.getSeletedRowData();
    let selectedRowHeaderAlias = selectedRowData.headerAlias;

    let useAliaseList = new Map(); 
    let  gridData =  this.jsonSchema['details'];

    this.fillAliaseUsageHeader(gridData,useAliaseList);

    let aliaseUsageHeader =   useAliaseList.get(selectedRowHeaderAlias);
 
    return aliaseUsageHeader;

  }

  fillAliaseUsageHeader(gridData,useAliaseList){
    gridData.forEach(element => {
   
       if(element.details){
        this.fillAliaseUsageHeader(element.details,useAliaseList);
       } else{
        if("Formula" == element.dataFindFrom){
          let formulaStaticValue = element.formulaStaticValue;
          if(formulaStaticValue){
            let split = formulaStaticValue.split(/[^\w\s]/gi);
            let list = split.slice();
            list  = _.map(list,_.trim)
            if(list){
              list.forEach(al => {
                useAliaseList.set(al, element['name']); 
              });
           }
          }
         }
     
         if("by_manual_method_with_aliase" == element.dataFindFrom){
          let formulaStaticValue = element.formulaStaticValue;
          if(formulaStaticValue){
            const argument = formulaStaticValue.substring(formulaStaticValue.indexOf("(") + 1, formulaStaticValue.indexOf(")"));
           
            let split = argument.split(/[^\w\s]/gi);
            let list = split.slice();
            list  = _.map(list,_.trim)
            if(list){
              list.forEach(al => {
                useAliaseList.set(al, element['name']);
              });
           }
          }
         }
       }
    });

     
  }

  /************Simple format ***************** */

  _getApiFieldSimpleFormate(apiFieldList) {
    const treeDetails = JSON.parse(JSON.stringify(apiFieldList)); 
    const simpleDetails = [];
  
    treeDetails.forEach(obj => {
      if (!Object.prototype.hasOwnProperty.call(obj, "details")) {
        simpleDetails.push(obj);
      } else if (Object.prototype.hasOwnProperty.call(obj, "details")) {
        const details = obj.details;
        this.convertDataTreeToList(simpleDetails, details);
      }
    });
  
    return simpleDetails;
  }
  
  convertDataTreeToList(simpleDetails, treeDetails) {
    treeDetails.forEach(obj => {
      if (!Object.hasOwnProperty.call(obj, "details")) {
        simpleDetails.push(obj);
      } else if (Object.hasOwnProperty.call(obj, "details")) {
        let details = obj.details;
        this.convertDataTreeToList(simpleDetails, details);
      }
    });
  }


  
/*******************************User Rights ******************************************************** */
  
gridDynamicapiAlreadyAssign:any
isAccessToCreateNewPackageGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Name",
    field: "packageName",
    filter: true,
    width: "300px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Path",
    field: "packagePath",
    filter: true,
    width: "300px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()",
  },
  
];
isCreateFileToAnotherUserGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Name",
    field: "srcFilePath",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "User Name",
    field: "userName",
    filter: true,
    width: "168px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()",
  },
  
];
isAccessToCreateNewFileGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Name",
    field: "packageName",
    filter: true,
    width: "400px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
 
  
];
isAccessToCreateNewApiColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Name",
    field: "fileName",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
  
];

isAccessToModifyApiColumn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Path",
    field: "srcfileUniqePath",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
  
];

accessRightErrorMsg=""

isUserValid = false;

displayPopupForRights(flag,res) {
  if (res.isValid) {
    this.isUserValid = true;
  } else {
    this.isUserValid = false;
    if(flag){
      if(res.status == 401){
        this.accessRightErrorMsg = res.msg;
        $("#apiAlreadyAssignId").modal('show');
        this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewPackageGridColmn);
      } else  if(res.status == 402){
        this.accessRightErrorMsg = res.msg;
        $("#apiAlreadyAssignId").modal('show');
        this.apiAlreadyAssignGrid(res.data,this.isAccessToModifyApiColumn);
      }else  if(res.status == 403){
        this.accessRightErrorMsg = res.msg;
        $("#apiAlreadyAssignId").modal('show');
        this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewFileGridColmn);
      }else if(res.status == 404){
        this.accessRightErrorMsg = res.msg;
        $("#apiAlreadyAssignId").modal('show');
        this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewApiColmn);
      } else{
       alerts(res.msg)
      }
     }
   
  }
}


apiAlreadyAssignGrid(rowsData,columns) {
const sourceDiv = document.getElementById("apiAlreadyAssignIdGrid");

var self = this;

let SagGridRowStatus = rowsData;
for (let i = 0; i < SagGridRowStatus.length; i++) {
  SagGridRowStatus[i]["sno"] = i + 1;
}

if (undefined != sourceDiv) {
  var gridData = {
    columnDef: columns,
    rowDef: SagGridRowStatus,
    menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
    selection: "row",
    components: {},
    clientSidePagging: true,
    recordPerPage: 20,
    recordNo: true,
   
  };
  this.gridDynamicapiAlreadyAssign = SagGridMPT(sourceDiv, gridData, true, true);
  this.setColorOnGrid1();
}
}

setColorOnGrid1() {
let self = this;
let gridRowsData = self.gridDynamicapiAlreadyAssign.sagGridObj.originalRowData;
gridRowsData.forEach((ele, index) => {
  // change Row Color
  if (ele.apiName || ele.apiType || ele.assignTo || ele.assignBy) {
    self.gridDynamicapiAlreadyAssign.setColRowProperty(index, 'srcFilePath', { "background": "#fff8e1" });
    self.gridDynamicapiAlreadyAssign.setColRowProperty(index, 'userName', { "background": "#f8d7da" });
  }
});

}

isGeneratedFileValid:boolean = false;
isCreatedFileValid(flag) {
  let masterJsonObj = this.dbMappingform.getRawValue();
  let formObj = this.fileImportExportInfoFormGroup.getRawValue();
  let jsonObj = _.merge(masterJsonObj, formObj);

    this.autoJavacodeService.isCreatedFileValid(jsonObj,"json_import_export").subscribe(res => {
      this.isGeneratedFileValid = res.isValid;
    if (!res.isValid) {
      alerts(res.msg)
    } 
  }, Error => {
    alerts("Error While validate generated file");
  });
  
}

/*****************TABLE FIELD WITH CUSTOM KEY ************************** */
getTableInfoWithCustomKeys(res, tableName) {
  let tableFields = [];

  if (res) {
    res.forEach(tableColumn => {
      let tableFieldInfo = {};
      tableFieldInfo['columnName'] = tableColumn['name'];
      tableFieldInfo['pkey'] = tableColumn['pkey'];
      tableFieldInfo['fkey'] = tableColumn['fkey'];
      tableFieldInfo['dataType'] = tableColumn['type'];
      tableFieldInfo['entityColumn'] = tableColumn['entitylabel'];
      tableFieldInfo['tableName'] = tableName;

      tableFieldInfo['parentTable'] = tableColumn['parenttbl'];
      tableFieldInfo['dbColumnSize'] = tableColumn['size'];
      tableFieldInfo['uniquecol'] = tableColumn['uniquecol'];
      tableFieldInfo['entityName'] = tableColumn['entityName'];
      tableFieldInfo['pkeyName'] = tableColumn['pkeyName'];

      tableFields.push(tableFieldInfo);
    });
  }
  return tableFields;
}

getTableProperties(item):String{
  if(item){
    return item.dataType+"("+item.dbColumnSize+")";
  }
 return ""
}


}
