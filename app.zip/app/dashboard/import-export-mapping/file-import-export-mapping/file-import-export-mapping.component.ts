import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { ExcelSheetImportExportMappingComponent } from '../excel-sheet-import-export-mapping/excel-sheet-import-export-mapping.component';
import { JsonImportExportMappingComponent } from '../json-import-export-mapping/json-import-export-mapping.component';
import { ExportReportMappingComponent } from '../export-report-mapping/export-report-mapping.component';
 

declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-file-import-export-mapping',
  templateUrl: './file-import-export-mapping.component.html',
  styleUrls: ['./file-import-export-mapping.component.scss'],
  providers: [DialogService]
})
export class FileImportExportMappingComponent implements OnInit,OnDestroy {

  fileImportExportInfoFormGroup: FormGroup;
  submittedFileImportExport: boolean = false;
  fileProviderList = [];
  providerName = '';
  gridDynamicForFileImportExportMapping: any;
  formNameVersionDisplay = "";
  mappingRefrenceList = [];

  isModify:boolean = false;

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService, ) { }

  ngOnInit() {
    this.getFileProviderList();
    this.initializeFormGroup();
    if(this.config.data){
      this.fileImportExportInfoFormGroup.patchValue(this.config.data); 
    
    }
    this.getFileImportExportMapping();
  }

  ngOnDestroy() { }

  initializeFormGroup() {

    this.fileImportExportInfoFormGroup = this.formbuilder.group({
      mappingId: [{ value: '', disabled: false }],
      softwareName: [{ value: '', disabled: false }],
      softwareId: [{ value: null, disabled: false }],
      formName: [{ value: '', disabled: false }],
      softwareFormId: [{ value: '', disabled: false }, [Validators.required]],
      file: [{ value: '', disabled: false }],
      fileName: [{ value: '', disabled: false }, [Validators.required]],
      type: [{ value: '', disabled: false }, [Validators.required]],
      fileType: [{ value: '', disabled: false }, [Validators.required]],
      providerId: [{ value: '', disabled: false }, [Validators.required]],
      providerName:[{ value: '', disabled: false }],
      noOfSheet: [{ value: '', disabled: true }, [Validators.required]],
      versionNo: [{ value: '', disabled: false }, [Validators.required]],
      fileExtention: [{ value: '', disabled: true }, [Validators.required]],
      fromDate: [{ value: '', disabled: false }, [Validators.required]],
      toDate: [{ value: '', disabled: false }, [Validators.required]],
      dataInsertType: [{ value: 'hibernate_query', disabled: false }],
      databaseType: [{ value: 'mysql', disabled: false }],
      viceVersaId: [{ value: '', disabled: false }],
      viceVersaFileType: [{ value: '', disabled: false }],
      viceVersaCopyConfiguration: [{ value: [], disabled: false }],
      
      
    });
  }

  getFileProviderList() {
    this.autoJavacodeService.getFileProviderList().subscribe(res => {
      if (res.status == 200) {
        this.fileProviderList = res.data;
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }


  onClickSheetMapping() {
    this.formNameVersionDisplay = "";
    let selectedRowData = this.gridDynamicForFileImportExportMapping.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row");
      return;
    }
    this.fileImportExportInfoFormGroup.patchValue(selectedRowData);

    this.formNameVersionDisplay = " ("+selectedRowData['formName']+" "+selectedRowData['versionNo']+")"

    if("EXCEL"==selectedRowData.fileType ){
      this.openFileImportExportMapping(selectedRowData);
    }else if("JSON"==selectedRowData.fileType ){

      if(selectedRowData.viceVersaId){
        let gridData = this.gridDynamicForFileImportExportMapping.getGridData();
        let find =  _.find(gridData,{"mappingId": Number(selectedRowData.viceVersaId)});
        if(find){
          selectedRowData["viceVersaFileType"] = find.fileType
          
        }
       }

      this.openJSONImportExportMapping(selectedRowData);
    }else if("Report" == selectedRowData.type){
     this.openExportReportingMapping(selectedRowData); 
    }else {
      alerts("Please update file type")
    }
    
  }

  openFileImportExportMapping(selectedRowData){
    const ref = this.dialogService.open(ExcelSheetImportExportMappingComponent, {
      header: "Excel Sheet Mapping"+this.formNameVersionDisplay,
      width: "100%",
      contentStyle: {"margin-top": "0px", "height": "100%" },
      styleClass: "service_full_model excel-demo-view",
      data: selectedRowData
    });
    ref.onClose.subscribe((res) => {
  
    });
  }

  
openJSONImportExportMapping(selectedRowData){
  const ref = this.dialogService.open(JsonImportExportMappingComponent, {
    header: "JSON Mapping",
    width: "100%",
    contentStyle: {"margin-top": "0px", "height": "100%" },
    styleClass: "service_full_model excel-demo-view",
    data: selectedRowData,         
  
  });
  ref.onClose.subscribe((res) => {

  });
}

openExportReportingMapping(selectedRowData){
  const ref = this.dialogService.open(ExportReportMappingComponent, {
    header: "Report Mapping"+this.formNameVersionDisplay,
    width: "100%",
    contentStyle: {"margin-top": "0px", "height": "100%" },
    styleClass: "service_full_model excel-demo-view",
    data: selectedRowData
  });
  ref.onClose.subscribe((res) => {

  });
}

  onClickAddExcelMappingInfo() {
    this.resetFileImportExportInfoForm();
    this.isModify = false;
    this.mappingRefrenceList = [];
    $('#addExcelInfoModel').modal('show')
  }
  onCloseAddExcelMappingInfo() {
    $('#addExcelInfoModel').modal('hide')
  }

  onCloseFileInfo() {
    this.modalRef.close();
    this.ngOnDestroy();
  }

  resetFileImportExportInfoForm() {
    this.fileImportExportInfoFormGroup.patchValue({
      "mappingId": "",
      "file": "",
      "fileName": "",
      "type": "",
      "fileType": "",
      "providerId": "",
      "noOfSheet": "",
      "versionNo": "",
      "fileExtention": "",
      "fromDate": "",
      "toDate": "",
      "dataInsertType": "hibernate_query",
      "databaseType": "mysql",
      "viceVersaId":"",
      "viceVersaFileType":""
    })
  }

  modifyFileImportExportMapping() {
    let selectedRowData = this.gridDynamicForFileImportExportMapping.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row");
      return;
    }

    this.fileImportExportInfoFormGroup.patchValue(selectedRowData);
    this.isModify = true;
    this.setMappingRefrenceDropdown(selectedRowData.fileType);

    if(selectedRowData.viceVersaId){
      this.onChangeMappingRefrence(selectedRowData.viceVersaId);
    }
    

    $('#addExcelInfoModel').modal('show')
  }

  async deleteFileImportExportMapping() {
    let selectedRowData = this.gridDynamicForFileImportExportMapping.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row");
      return;
    }
    let conf = await ui.confirm("Do You Want To Delete File Mapping ? ");
    if (!conf) {
      return;
    }

    let mappingId = selectedRowData.mappingId;

    this.autoJavacodeService.deleteFileImportExportMapping(mappingId).subscribe(res => {
      if (res.status == 200) {
        success(res.msg)
        this.getFileImportExportMapping();
      }
    }, Error => {
      alerts("Error While Deleting Data");
    });
  }


  
  fileChange(event) {
    let fileList: FileList = event.target.files;
    if (fileList && fileList.length > 0) {
      this.getFileInfo(fileList[0]);
      this.fileImportExportInfoFormGroup.controls["file"].patchValue(fileList[0]);
     
    } else {
      this.fileImportExportInfoFormGroup.controls["file"].patchValue(null);
    }
 }

 getFileInfo(file){
  
   let formData = new FormData();
   formData.set('file', file);

   this.autoJavacodeService.getFileInfo(formData).subscribe(res => {
       this.fileImportExportInfoFormGroup.controls["fileName"].patchValue(res.fileNameWithoutExtension);
       this.fileImportExportInfoFormGroup.controls["fileType"].patchValue(res.fileType);
       this.fileImportExportInfoFormGroup.controls["noOfSheet"].patchValue(res.totalSheet);
       this.fileImportExportInfoFormGroup.controls["fileExtention"].patchValue(res.fileExtension);
      if(res.fileType){
        this.setMappingRefrenceDropdown(res.fileType);
      }
     

   }, Error => {

   });
 }


  getFileImportExportMapping() {
    let softwareFormId = this.fileImportExportInfoFormGroup.controls["softwareFormId"].value;
    if (!softwareFormId) {
      this.sagFileMappingInfoGrid([]);
      return;
    }

    this.autoJavacodeService.getFileImportExportMapping(softwareFormId).subscribe(res => {
      if (res.status == 200) {
        this.sagFileMappingInfoGrid(res.data);
      } else {
        this.sagFileMappingInfoGrid([]);
      }
    }, Error => {
      this.sagFileMappingInfoGrid([]);
      alerts("Error While Fetching Data");
    });

  }

  
  saveFileImportExportMapping() {
    this.submittedFileImportExport = true;

    let formObj = this.fileImportExportInfoFormGroup.getRawValue();
    let formData = new FormData();

    if("Report" != this.fileImportExportInfoFormGroup.controls['type'].value){
      if (!this.fileImportExportInfoFormGroup.valid) {
        alerts("Please Fill All Requird Fields")
        return;
      }
      this.submittedFileImportExport = false;
  
      let file = this.fileImportExportInfoFormGroup.controls["file"].value;
     
      if (!formObj.mappingId && (file == null || file == "" || file == undefined)) {
        alerts("Please Choose file first")
        return;
      }

    
    }
    let obj = JSON.parse(JSON.stringify(formObj));
    obj['file'] = null;
    formData.set('file', this.fileImportExportInfoFormGroup.controls["file"].value);
    formData.set('modelStr', JSON.stringify(obj));

    this.autoJavacodeService.saveFileImportExportMapping(formData).subscribe(res => {
      if (res.status == 200) {
        this.getFileImportExportMapping();
        success(res.msg);
        this.onCloseAddExcelMappingInfo();
      } else {
        alerts(res.msg);
      }
    }, Error => {
      alerts("Error While saving data");
    });


  }

  onchangeType(type){
   if("Report" == type ){
    this.setMappingRefrenceDropdown('Report');
   }
  }

  setMappingRefrenceDropdown(fileType){
    this.mappingRefrenceList = [];

    if("Report" == this.fileImportExportInfoFormGroup.controls['type'].value){
       return;
    }
    
    let gridData = this.gridDynamicForFileImportExportMapping.getGridData();

    if(this.isModify){
      let mappingId = this.fileImportExportInfoFormGroup.controls['mappingId'].value;
      gridData =   _.filter(gridData,function (data) {  
        return data['mappingId']!=mappingId;  
    })

    }

    if("EXCEL" == fileType || "JSON" == fileType ){
      gridData.forEach(element => {
        if(element['fileType']==fileType){
        let obj = {
         "id":element.mappingId,
         "label":element.providerName +" "+ element.fileType+" "+ element.versionNo,
         }
         this.mappingRefrenceList.push(obj);
        }
    });
    }
    if(this.mappingRefrenceList.length == 0){
      gridData.forEach(element => {
        if(element['fileType']!=fileType){
        let obj = {
         "id":element.mappingId,
         "label":element.providerName +" "+ element.fileType+" "+ element.versionNo,
         }
         this.mappingRefrenceList.push(obj);
        }
    });
    }
 
  }


  sagFileMappingInfoGrid(rowsData) {
    var sourceDiv = document.getElementById("sagExcelInfoGrid");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Form Name",
        "field": "formName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
     
      {
        "header": "Version",
        "field": "versionNo",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "Type",
        "field": "type",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "Provider",
        "field": "providerName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "File Type",
        "field": "fileType",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      
      {
        "header": "File Name",
        "field": "fileName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "File Extention",
        "field": "fileExtention",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "No Of Sheet",
        "field": "noOfSheet",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "From Date",
        "field": "fromDate",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "To Date",
        "field": "toDate",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "Software version",
        "field": "softwareVersion",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },

    ];
    let self = this;

    let components = {};

    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        rowCustomHeight :20,
        cellCustomPadding:5,
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
           "onRowDbleClick": function () {
            self.onClickSheetMapping();
          }
        }
      };
      this.gridDynamicForFileImportExportMapping = SdmtGridT(sourceDiv, gridData, true, true);
      return this.gridDynamicForFileImportExportMapping;
    }
  }



  onClickAddProvider() {
    $('#addProviderModel').modal('show')
  }
  onCloseAddProvider() {
    $('#addProviderModel').modal('hide')
  }

  saveProvider() {
    if (!this.providerName) {
      alerts("Please fill Provider name")
      return;
    }
    let obj = {
      "providerName": this.providerName
    }

    this.autoJavacodeService.saveProviderName(obj).subscribe(res => {
      if (res.status == 200) {
        success(res.msg);
        this.getFileProviderList();
        this.providerName = "";
        this.onCloseAddProvider();
      } else {
        alerts(res.msg);
      }
    }, Error => {
      alerts("Error While saving data");
    });
  }

  onChangeMappingRefrence(mappingId){
   
   if(mappingId){
    let gridData = this.gridDynamicForFileImportExportMapping.getGridData();
    let find =  _.find(gridData,{"mappingId": Number(mappingId)});
    if(find){
     this.fileImportExportInfoFormGroup.controls['viceVersaFileType'].patchValue(find.fileType);
    }
   }
 

  }



/**************** Copy Mapping Configuration ***************************** */

 
copyMappingConfiguration = []

childExcelSheetList = []; 
gridDynamicForCopyFileImportExportMapping:any

refHeaderNameDropdown = []

sheet: { "type": null, "headerRow": null, "name": null, "sheetHeaderList": any, "startDataRow": "","endDataRow": "", 
"varriableMappingType": any, "varriableMappingData": [], "excelChildSheet": any,'isChildernSheet':false,
"readDataRowCellWise":any,"startHeaderRow":any ,"endHeaderRow":any,"refrenceSheetName":""}

childSheetName:String;
oldVersionExcelSheetList = [];
oldVersionExcelSheetNameList = [];


onClickCopyMappingRefernce(){

  let viceVersaFileType =  this.fileImportExportInfoFormGroup.controls['viceVersaFileType'].value;
  let viceVersaId =   this.fileImportExportInfoFormGroup.controls['viceVersaId'].value;
  let fileType =  this.fileImportExportInfoFormGroup.controls['fileType'].value;
  let file  = this.fileImportExportInfoFormGroup.controls["file"].value;
  let mappingId  = this.fileImportExportInfoFormGroup.controls["mappingId"].value;

  if(!viceVersaId){
    alerts("please select first mapping refrence");
    return;
  }

  if(fileType != viceVersaFileType){
   alerts("Mapping refrence configuration only applicable for same file type");
   return;
  }

  if(!mappingId && !file){
   alerts("please select file ");
   return;
  }

  $('#copyFileImportExportMappingModal').modal('show')
  this.loadData();
    



 }


 
 loadData(){

  let viceVersaId =   this.fileImportExportInfoFormGroup.controls['viceVersaId'].value;
  let fileType =  this.fileImportExportInfoFormGroup.controls['fileType'].value;
  let file  = this.fileImportExportInfoFormGroup.controls["file"].value;
  let mappingId  = this.fileImportExportInfoFormGroup.controls["mappingId"].value;

  let formData = new FormData();

  formData.set('file', file);
  formData.set('viceVersaId', viceVersaId);
  formData.set('fileType', fileType);
  formData.set('mappingId', mappingId);
  

  this.autoJavacodeService.getCopyMappingRefernceConfiguration(formData).subscribe(res => {
    if (res.status == 200) {
     this.oldVersionExcelSheetList =  res.oldVersionData;
     this.copyMappingConfiguration = res.newVersionData;
    
     this.setSheetListForJsonMapping();

     let item = _.find(this.copyMappingConfiguration, { active: true });
     if (item) {
       setTimeout(() => {
       this.onClickSheet(item, 1);
       }, 100);

     } else{
      if(this.copyMappingConfiguration && this.copyMappingConfiguration.length > 0 ){
        setTimeout(() => {
          this.onClickSheet(this.copyMappingConfiguration[0], 1);
          }, 100)
      }

     }

    } else {
      alerts(res.msg);
    }
  }, Error => {
    alerts("Error While fetching data");
  });

}


onClickSheet(item: any, index) {
  this.sheet = item;

  if(!item['isChildernSheet']){
    if(item['excelChildSheet']){
      this.childExcelSheetList = item['excelChildSheet'];
    }else{
      this.childExcelSheetList = [];
    }
  }

  if(!item['isChildernSheet']){
    this.copyMappingConfiguration.forEach(itm => itm.active = false);
    
    if(this.childExcelSheetList){
      this.childExcelSheetList.forEach(itm => itm.active = false);
    }
  }else{
    this.childExcelSheetList.forEach(itm => itm.active = false);
  }

  if(!this.sheet['refrenceSheetName']){
    let item = _.find(this.oldVersionExcelSheetList, { "name": this.sheet['name'] });
   if(item){
    this.sheet['refrenceSheetName'] = this.sheet['name'];
    this.onChangeReferenceSheetName(this.sheet['refrenceSheetName'],true)
   } else{
    this.onChangeReferenceSheetName(this.sheet['refrenceSheetName'],false)
   }
  
  } else{
    this.onChangeReferenceSheetName(this.sheet['refrenceSheetName'],false)
  }
  this.sheet['active'] = true;

  let excelJsonType =  this.fileImportExportInfoFormGroup.controls['fileType'].value;

 if("EXCEL" == excelJsonType){
  setTimeout(() => {
    this.copySheetMappingConfigureGrid(this.sheet['sheetHeaderList'],this.sheet['type']);
   }, 100);
 }else{
  setTimeout(() => {
    this.copySheetMappingConfigureGrid(this.sheet['details'],this.sheet['type']);
   }, 100);
 }
 
  
  

}

copySheetMappingConfigureGrid(rowsData,type) {
  var sourceDiv = document.getElementById("copyfileImportExportSheetMappingId");
  var columns = [
    {
      "header": "S.No",
      "field": "sno",
      "filter": true,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
    {
      "header": "Sheet Header Name",
      "field": ("client_details" == type || ("fix" == type && "cellRefrenceWise" == this.sheet['readDataRowCellWise'])) ? "cellRefrence" : "name",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": true
    },
    {
      "header": "Refernce Header Name",
      "field": "refHeaderName",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    }
    
  ];


 let self = this;
 let components ={};
 var SagGridRowStatus = rowsData;

 for (var i = 0; i < SagGridRowStatus.length; i++) {
  //SagGridRowStatus[i]["refHeaderName"] = '';
  SagGridRowStatus[i]["sno"] = i + 1;
}
 
  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      rowCustomHeight :20,
      cellCustomPadding:5,
      components: components,
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
      callBack: {
        
      },
      dropDownJson_refHeaderName: this.refHeaderNameDropdown,

      rowGrouping: {
        "enable": true,
        "groupType": "custome",
        "groupBy": "name",
        "expandRow": []
      },
      rowSelection: false,
      rowDataViewTotal: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
    };

    this.gridDynamicForCopyFileImportExportMapping = SdmtGridT(sourceDiv, gridData, true, true);
   
   // this.gridDynamicForCopyFileImportExportMapping.expandAll();
    return this.gridDynamicForCopyFileImportExportMapping;

  
  }
}


setSheetListForJsonMapping(){
  this.oldVersionExcelSheetNameList = [];
  this.oldVersionExcelSheetList.forEach(element => {
    this.oldVersionExcelSheetNameList.push(element.name);
  });
}

onChangeReferenceSheetName(oldSheetName,isGridAlreadyLoaded){

  this.refHeaderNameDropdown = [{ "key": "", "val": "--Select--" }];

  let fileType =  this.fileImportExportInfoFormGroup.controls['fileType'].value;

  if (oldSheetName) {
    let item = _.find(this.oldVersionExcelSheetList, { "name": oldSheetName });
    if (item) {
      let headerKey = "name";
      if ("fix" == item['type'] && "cellRefrenceWise" == item['readDataRowCellWise'] ) {
        headerKey = "cellRefrence";
      }
      if ("client_details" == item['type']) {
        headerKey = "cellRefrence";
      }

      let sheetHeaderListKey = "JSON" == fileType ? "details": "sheetHeaderList"

      this.setRefHeaderDropdownData(item[sheetHeaderListKey],headerKey)

      this.sheet['type'] = item['type'];
      this.sheet['headerRow'] = item['headerRow'];
      this.sheet['readDataRowCellWise'] = item['readDataRowCellWise'];
      this.sheet['startDataRow'] = item['startDataRow'];
      this.sheet['endHeaderRow'] = item['endHeaderRow'];
      this.sheet['parentHeaderName'] = item['parentHeaderName'];
      this.sheet['endDataRow'] = item['endDataRow'];
      this.sheet['readDataRowCellWise'] = item['readDataRowCellWise'];
     
      

      if (isGridAlreadyLoaded && this.gridDynamicForCopyFileImportExportMapping) {
        if (this.gridDynamicForCopyFileImportExportMapping.sagGridObj.components['refHeaderName']) {
          this.gridDynamicForCopyFileImportExportMapping.sagGridObj.components['refHeaderName'].setOption(this.refHeaderNameDropdown);
        }

        if("EXCEL" == fileType){
          this.getSheetHeaders();
        }else{
          this.autoFillAndLoadGrid();
        }
        
      }
    }
  }

}

setRefHeaderDropdownData(data,headerKey){
  data.forEach(element => {
    let obj = {
      "key": element[headerKey],
      "val": element[headerKey]
    }
    this.refHeaderNameDropdown.push(obj);
   if(element.details){
    this.setRefHeaderDropdownData(element.details,headerKey);
   }

  });
}

onOkCopyFileImportExportMapping(){
  this.fileImportExportInfoFormGroup.controls['viceVersaCopyConfiguration'].setValue(this.copyMappingConfiguration);
  this.onCloseCopyFileImportExportMapping();
 }

onChangeSheetType(sheetType) {
  if (!this.sheet['isChildernSheet'] && "multiMixSheet" != sheetType) {
    this.childExcelSheetList = [];
    this.sheet['excelChildSheet'] = [];
  }
}

onCloseCopyFileImportExportMapping() {
  $('#copyFileImportExportMappingModal').modal('hide')
 }

 getSheetHeaders() {
  let sheetName = this.sheet['isChildernSheet'] ?  this.sheet['parentSheetName']  : this.sheet['name'];
  let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;

  if("dynamic_header_merge"==this.sheet['type']){
     let startHeaderRow = this.sheet["startHeaderRow"];
     let endHeaderRow = this.sheet["endHeaderRow"];
     let parentHeaderName = this.sheet["parentHeaderName"];

     let formData = new FormData();
     let file  = this.fileImportExportInfoFormGroup.controls["file"].value;
    
    formData.set('file', file);
    formData.set('mappingId', mappingId);
    formData.set('sheetName', sheetName);
    formData.set('startHeaderRow', startHeaderRow);
    formData.set('endHeaderRow', endHeaderRow);
    formData.set('parentHeaderName', parentHeaderName);
  
     if(startHeaderRow && endHeaderRow){
      this.autoJavacodeService.getSheetMergeHeadersForCopy(formData).subscribe(res => {
        if (res.status == 200) {
          this.sheet['sheetHeaderList'] = res.data
          this.autoFillAndLoadGrid();
        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
     }


  }else{

  let sheetType = this.sheet.type;
  let startDataRow = this.sheet["startDataRow"];
  let endDataRow = this.sheet["endDataRow"] ? this.sheet["endDataRow"] : 0 ;
  let readDataRowCellWise = this.sheet["readDataRowCellWise"] ? this.sheet["readDataRowCellWise"] : "" ;
  let file  = this.fileImportExportInfoFormGroup.controls["file"].value;
  let formData = new FormData();

  formData.set('file', file);
  formData.set('mappingId', mappingId);
  formData.set('sheetName', sheetName);
  formData.set('headerRow', this.sheet['headerRow']);
  formData.set('sheetType', sheetType);
  formData.set('startDataRow', startDataRow);
  formData.set('endDataRow', endDataRow+"");
  formData.set('readDataRowCellWise', readDataRowCellWise);
 
  
  this.autoJavacodeService.getSheetHeadersForCopy(formData).subscribe(res => {
    if (res.status == 200) {
      this.sheet['sheetHeaderList'] = res.data
      
      this.autoFillAndLoadGrid();
    }
  }, Error => {
    alerts("Error While Fetching Data");
  });
  }
}

autoFillAndLoadGrid(){
  let headerKey = "name";
  if ("fix" == this.sheet['type'] && "cellRefrenceWise" == this.sheet['readDataRowCellWise']) {
    headerKey = "cellRefrence";
  }
  if ("client_details" == this.sheet['type']) {
    headerKey = "cellRefrence";
  }
  let fileType =  this.fileImportExportInfoFormGroup.controls['fileType'].value;
  let sheetHeaderListKey = "JSON" == fileType ? "details": "sheetHeaderList"

  this.autoFillRecursive(this.sheet[sheetHeaderListKey],headerKey);

  this.copySheetMappingConfigureGrid(this.sheet[sheetHeaderListKey],this.sheet['type']);

}

autoFillRecursive(data,headerKey){
  data.forEach(element => {
    this.refHeaderNameDropdown.forEach(ref => {
    let newHeader =   element[headerKey];
    let oldHeader =   ref['key'];
     
    if(oldHeader && newHeader){
      newHeader = newHeader.toUpperCase().replace(/\s/g, "");
      oldHeader = oldHeader.toUpperCase().replace(/\s/g, "");
     
      if(newHeader == oldHeader){
        element["refHeaderName"] = ref['key']
      }
    }
   });

   if(element.details){
    this.autoFillRecursive(element.details,headerKey); 
   }
    
  }); 
}

}
