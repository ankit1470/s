import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { Router } from '@angular/router';



declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-import-export-manual-code',
  templateUrl: './import-export-manual-code.component.html',
  styleUrls: ['./import-export-manual-code.component.scss'],
  providers: [DialogService]
})
export class ImportExportManualCodeComponent implements OnInit,OnDestroy {

  tabName = "manual_code"

  isManualCodeDispaly : boolean = true;

  manualCodeBody = "";
  gridDynamicForManualCode: any;
  manualMethodList=[];
  selectedRowManualMethod ="";
  sheetNameList = [];
  type = "";
  jsonSchemaList = [];
  apiGeneratedObj = {};
  automethodList = [];

  gridDynamicForAutoCodeGrid:any
  totalNoOfLine = 0;

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService,
    public _router: Router, ) { }

  ngOnInit() {
    this.tabName = "manual_code"
    if(this.config.data){
      if(this.config.data.manualMethodList){
        this.manualMethodList = this.config.data.manualMethodList;
      }
      if(this.config.data.selectedRowManualMethod){
        this.selectedRowManualMethod = this.config.data.selectedRowManualMethod;
      }

      if(this.config.data.selectedRowManualMethod){
        this.selectedRowManualMethod = this.config.data.selectedRowManualMethod;
      }

      if(this.config.data.sheetNameList){
        this.sheetNameList = this.config.data.sheetNameList;
      }
      if(this.config.data.type){
       this.type = this.config.data.type;
      }
      if(this.config.data.jsonSchemaList){
        this.jsonSchemaList = this.config.data.jsonSchemaList;
       }
       if(this.config.data.apiGeneratedObj){
        this.apiGeneratedObj = this.config.data.apiGeneratedObj;
       }

    }
    this.calculateNoOfLine();

    this.manualCodeList(this.manualMethodList);
    this.setSelectedRowForManualCode(this.manualMethodList.length > 0); 

    if("JSON"==this.type){
      let gridData = this.gridDynamicForManualCode.getGridData();
      setTimeout(() => {
        gridData.forEach(element => {
          if(("methodCall" == element.statementType || "statement" == element.statementType)  && "change_value_particular_column"== element.purpose){
            this.setJsonColumnNameDropdownValue(element.sag_G_Index,element.sheetName,element.jsonColumnName);
          }
        });
      }, 1000);
     
    }
   
  }

  calculateNoOfLine(){
    this.totalNoOfLine = 0;
    if(this.manualMethodList){
      this.manualMethodList.forEach(element => {
        if(element.manualCodeBody){
         let no =  element.manualCodeBody.split("\n").length+1;
         this.totalNoOfLine = this.totalNoOfLine + no
        };
      });
    }
  }


  ngOnDestroy() { }

  onClickTab(tabName){
    this.tabName = tabName;
    this.totalNoOfLine = 0;

    if('auto_code'==tabName){
      this.isManualCodeDispaly = false
     
        this.autoJavacodeService.getAllImportExportMethod(this.apiGeneratedObj).subscribe(res => {
          if (res.status == 200) {
            this.automethodList = res.data;
            this.totalNoOfLine = res.totalNoOfLine;
            this.autoCodeGrid(this.automethodList);
          } else {
            alerts(res.msg);
          }
        }, Error => {
          alerts("Error While saving data");
        });
      

    } else{
      this.isManualCodeDispaly = true
      this.manualCodeList(this.manualMethodList);
      this.setSelectedRowForManualCode(this.manualMethodList.length > 0); 
      this.calculateNoOfLine();
    }
 }

  


  setManualBodyInGrid() {
    let seletedRowData = this.gridDynamicForManualCode.getSeletedRowData();
   this.gridDynamicForManualCode.updateCell(seletedRowData.sag_G_Index, 'manualCodeBody', this.manualCodeBody);
  }
  
  disableManualCodeAllRowCell(){
    let gridData = this.gridDynamicForManualCode.getGridData();
    gridData.forEach(rowData => {
      this.disableManualCodeRow(rowData.sag_G_Index,rowData.statementType);
      if("JSON"==this.type){
        this.disableSheetColumn(rowData.sag_G_Index,rowData.purpose);
      }
    });
  }
  
  disableManualCodeRow(index,value){
  if("methodCall" == value ||  "predicate" == value ||  "statement" == value){
    this.gridDynamicForManualCode.enableCell(index, "importExportType");  
    this.gridDynamicForManualCode.enableCell(index, "sheetName");
    this.gridDynamicForManualCode.enableCell(index, "purpose");
  }else{
     this.gridDynamicForManualCode.updateCell(index, "importExportType",'');
     this.gridDynamicForManualCode.updateCell(index, "sheetName",'');
     this.gridDynamicForManualCode.updateCell(index, "purpose",'');
   
     this.gridDynamicForManualCode.disableCell(index, "importExportType");
     this.gridDynamicForManualCode.disableCell(index, "sheetName");
     this.gridDynamicForManualCode.disableCell(index, "purpose");
   }
  }
  
  setSelectedRowForManualCode(isNotEmpty){
  
    if (isNotEmpty) {
      if (this.selectedRowManualMethod) {
        let manualMethodList = this.gridDynamicForManualCode.getGridData();
        let index = 0;
        manualMethodList.forEach(element => {
          if(element.methodName){
            if (this.selectedRowManualMethod.includes(element.methodName)) {
              index = element.sag_G_Index;
           }
          }
        });
        this.gridDynamicForManualCode.setRowSelected(index);
        this.setManualMethodBody()
      }
    }
  
  }
  
  addRowManualCode(){
    let index = this.gridDynamicForManualCode.sagGridObj.AllRowIndex.length;
    let obj = {
          "methodName":"",
          "classTypeName": "",
          "manualCodeBody": "",
     }
    this.gridDynamicForManualCode.addRowByIndex(index, obj);
    this.disableManualCodeRow(index,"")
    this.calculateNoOfLine();
  }
  
  deleteRowManualCode(){
    this.manualCodeBody = "";
    let selectedRowData = this.gridDynamicForManualCode.getSeletedRowData();
    this.gridDynamicForManualCode.deleteRow(selectedRowData.sag_G_Index);
            if (this.gridDynamicForManualCode.sagGridObj
              && this.gridDynamicForManualCode.sagGridObj.AllRowIndex.length == 0) {
                this.manualCodeList([]); 
            }else{
              this.gridDynamicForManualCode.setRowSelected(0);
              this.setManualMethodBody()
            }
            this.calculateNoOfLine();      
  }
  
  
  onClickOkManualMethod(){
    this.manualMethodList = this.gridDynamicForManualCode.getGridData();
    this.onCloseManualCode();
  }

  setManualMethodBody() {
    let data = this.gridDynamicForManualCode.getSeletedRowData();
    this.manualCodeBody = data.manualCodeBody;
    this.calculateNoOfLine();   
   }

  manualCodeList(rowsData) {
    var sourceDiv = document.getElementById("manualCodeGridId1");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Statement Type",
        "field": "statementType",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Class Type Name",
        "field": "classTypeName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Method Name",
        "field": "methodName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      {
        "header": "Import Export Type",
        "field": "importExportType",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Sheet Name",
        "field": "sheetName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Purpose",
        "field": "purpose",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
    ];

    if("REPORT" == this.type){
      columns = _.filter(columns,ele=>{
        if(ele.field == "importExportType"){
          return false;
        }
        return true;
      })
     }

    if("JSON"==this.type){
      columns.push(
         {
        "header": "Column Name",
        "field": "jsonColumnName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      });
    }

    let self = this;
    let statementType = [
      { "key": "", "val": "--Select--" },
      { "key": "method", "val": "Method" },
      { "key": "methodCall", "val": "Method Call" },
      { "key": "predicate", "val": "Predicate" },
      { "key": "statement", "val": "Statement" },
      ];
    let classTypeList = [
      { "key": "", "val": "--Select--" },
      { "key": "service", "val": "Service" },
      { "key": "repository", "val": "Repository" },
     ];
   
     let importExportType = [
      { "key": "", "val": "--Select--" },
      { "key": "import", "val": "Import" },
      { "key": "export", "val": "Export" },
     ];
     
  
     let purpose = [
      { "key": "", "val": "--Select--" },
      { "key": "get_data_from_database", "val": "Get Data From Database" },
      { "key": "change_value_particular_column", "val": "Change Value Particular Column"},
      { "key": "change_value_all_record", "val": "Change Value All Record"},
      { "key": "filter_sheet_data", "val": "Filter Sheet Data"},
      { "key": "custum_validate_excel_data", "val": "Custum Validate Excel Data"},
      { "key": "validate_excel", "val": "Validate Excel"},
      { "key": "read_data", "val": "Read Data"},
      { "key": "process_data", "val": "Process Data"},
      { "key": "save_data", "val": "Save Data"},
      { "key": "statement_after_save", "val": "Statement After Save"},
      { "key": "statement_before_save", "val": "Statement Before Save"},
     ]
  
     if("REPORT" == this.type){
      purpose = _.filter(purpose,ele=>{
        if(ele.key == "get_data_from_database"
         || ele.key == "change_value_particular_column"
         || ele.key == "change_value_all_record"
         || ele.key == "filter_sheet_data"){
          return true;
        }
        return false;
      })
     }

   
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }
  
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        frezzManager: { "sno": "left", "statementType": "left" },
        components: {},
        clientSidePagging: true,
        recordPerPage: 20,
        rowCustomHeight :20,
        cellCustomPadding:5,
     
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.setManualMethodBody();
          },
          "onChangeSelect_statementType": function (ele, params) {
            self.disableManualCodeRow(params.rowIndex,ele.value)
          },
          "onChangeSelect_purpose": function (ele, params) {
            if( "change_value_particular_column"== ele.value){
              self.setJsonColumnNameDropdownValue(params.rowIndex,params.rowValue.sheetName,"");
            }
            self.disableSheetColumn(params.rowIndex,ele.value);
          },
        },
        dropDownJson_statementType: statementType,
        dropDownJson_classTypeName: classTypeList,
        dropDownJson_importExportType: importExportType,
        dropDownJson_sheetName: this.sheetNameList,
        dropDownJson_purpose: purpose,
        dropDownJson_jsonColumnName: [{ "key": "", "val": "--Select--" }],
       
      };
      this.gridDynamicForManualCode = SdmtGridT(sourceDiv, gridData, true, true);
  
      this.disableManualCodeAllRowCell();
  
      return this.gridDynamicForManualCode;
    }
  }

  disableSheetColumn(index,purpose){
    if( "change_value_particular_column"== purpose){
      this.gridDynamicForManualCode.enableCell(index, "jsonColumnName");  
    }else{
      this.gridDynamicForManualCode.updateCell(index, "jsonColumnName",'');
      this.gridDynamicForManualCode.disableCell(index, "jsonColumnName");  
    }
  }

jsonColumnVar = [];
setJsonColumnNameDropdownValue(rowIndex,sheetName,fillValue){
  this.jsonColumnVar = [];
  if(sheetName){
    let sheetData =  _.find(this.jsonSchemaList,{name:sheetName});
    if(sheetData){
      this.getAllSheetColumnName(sheetData.details);
      
     let jsonColumnName = [{ "key": "", "val": "--Select--" }];
      this.jsonColumnVar.forEach(ele => {
        let obj = {
          "key": ele,
          "val": ele
        }
        jsonColumnName.push(obj);
      });

      
      if (this.gridDynamicForManualCode && this.gridDynamicForManualCode.sagGridObj.components['jsonColumnName']) {
        this.gridDynamicForManualCode.sagGridObj.components['jsonColumnName'].setOptionRow(jsonColumnName, "jsonColumnName", rowIndex);
      }
      if(fillValue){
        this.gridDynamicForManualCode.updateCell(rowIndex, "jsonColumnName", fillValue);

      }
    }
  
  }
}

getAllSheetColumnName(details){
  if(details){
    details.forEach(element => {
      if(element.details){
        this.getAllSheetColumnName(element.details);
      }else{
        this.jsonColumnVar.push(element.name);
      }
      
    });
  }

}


autoCodeGrid(rowsData) {
  var sourceDiv = document.getElementById("autoCodeGridId");
  var columns = [
    {
      "header": "S.No",
      "field": "sno",
      "filter": true,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
    {
      "header": "File Type",
      "field": "classType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": false
    },
   
    {
      "header": "Method Name",
      "field": "methodName",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": false
    },
    {
      "header": "Method Signature",
      "field": "methodSignature",
      "filter": true,
      "width": "500px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": false
    },
    

  ];
  let self = this;

  let components = {};

  var SagGridRowStatus = rowsData;
  for (var i = 0; i < SagGridRowStatus.length; i++) {
    SagGridRowStatus[i]["sno"] = i + 1;
  }

  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      rowCustomHeight :20,
      cellCustomPadding:5,
      components: components,
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
      callBack: {
       
      }
    };
    this.gridDynamicForAutoCodeGrid = SdmtGridT(sourceDiv, gridData, true, true);
    return this.gridDynamicForAutoCodeGrid;
  }
}


  onCloseManualCode(){
    this.manualMethodList = this.gridDynamicForManualCode.getGridData();
    this.modalRef.close(this.manualMethodList);
    this.ngOnDestroy();
  }

  

}
