import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy,  ViewChild,  ElementRef, HostListener } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { Router } from '@angular/router';
import { ImportExportValidationComponent } from '../import-export-validation/import-export-validation.component';
import { ImportExportManualCodeComponent } from '../import-export-manual-code/import-export-manual-code.component';
 
 

declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $, Contextual, ContextualItem;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
declare var SagButton;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-excel-sheet-import-export-mapping',
  templateUrl: './excel-sheet-import-export-mapping.component.html',
  styleUrls: ['./excel-sheet-import-export-mapping.component.scss'],
  providers: [DialogService]
})
export class ExcelSheetImportExportMappingComponent implements OnInit, OnDestroy{

  copyPastEllipsisValue = null;
  isRecursionOff =false; 
  gridDynamicAddMasterExtraColumn:any

  fileImportExportInfoFormGroup: FormGroup;

  sheetHeaderAlias = {};
  gridDynamicForSheetMapping: any;

  manualMethodList=[];
  excelSheetList;
  childExcelSheetList; 


  angularFormList = []
  angularFormDropdownList = [{ "key": "", "val": "--Select--" }]
  angularFormLabelList = [];
  angularFormLabelDropdownList = [];

  variabelModuleDropdropdownList = [];
  variabelModuleList = [];

  
  allTableList = [];
  tableListDropdownList = [{ "key": "", "val": "--Select--" }];
  tableFieldsMap = new Map();
  angularformFieldsMap = new Map();
  tableFieldDropdownList = [];
  skipFixRowDropdownList = [];


  sheet: { "type": null, "headerRow": null, "name": null, "sheetHeaderList": any, "startDataRow": "","endDataRow": "", 
  "varriableMappingType": any, "varriableMappingData": [], "excelChildSheet": any,'isChildernSheet':false,
  "readDataRowCellWise":any,"skipRow":[],"startHeaderRow":any ,"endHeaderRow":any,"parentHeaderName":"","importDataInsertType":[]
  ,"exitInvalidRow":"",
  "tableRelations":any}
  validationList;

  dataFindFrom = [
    { "key": "", "val": "--Select--" },
    { "key": "_sheet", "val": "Sheet" },
    { "key": "client_side", "val": "Client Side" },
    { "key": "Formula", "val": "Formula" },
    { "key": "by_manual_method_with_aliase", "val": "Manual Method With Aliase" },
    { "key": "by_manual_method", "val": "Manual Method With static" },
    { "key": "static_value", "val": "Static Value" },
    { "key": "static_master_code", "val": "Static Unique code" },
   ];

   excelHeaderType = [
    { "key": "", "val": "--Select--" },
    { "key": "common", "val": "Common" },
    { "key": "parent", "val": "Parent" },
   ];

   importDataInsertType = [
    { "value": "import_only_non_existing_record", "label": "Import only non existing record" },
    { "value": "overwrite_the_exiting_record", "label": "Overwrite the exiting record" },
    { "value": "delete_all_exiting_record_then_import_all_record", "label": "Delete all exiting record "},
   ];


   excelMasterForSheetMapping = [];
   excelMasterDropdownForSheetMapping = [];
   tableMasterDropdownForSheetMapping = [];
   masterTableFieldDropdownList = [];
   masterTableFieldMap = new Map();
   dropdownValidationList = [];

  //master mapping
  gridDynamicForMasterMapping
  excelMasterList;
  excelMasterInfo: { "mappingType": "EXCEL_WISE","sheetName": "","tableName": "", "nameTableColumn": "", "codeTableColumn": "",
   "masterList":any,"masterMappingType": "map_with_table_data","isMasterManualCreate":false}
  tableNameDropdownForMasterMapping = [];
  tableColumnDropdownForMasterMapping = [];
  tableFieldsMapForMasterMapping = new Map();
  tableDataListForMasterMapping = [];
  tableDataMapMasterMapping = new Map();
  tableDataDropdownMasterMapping = [{ "key": "", "val": "--Select--" }] ;

  isMasterMappingExcelWise:boolean = true;
  childSheetName:String;

  clientDetailsSheetColumn = [
   
    {
      "header": "S.No",
      "field": "sno",
      "filter": true,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
    {
      "header": "Header Name",
      "field": "name",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    },
    {
      "header": "Cell Refrence",
      "field": "cellRefrence",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    },
    {
      "header": "Data Find From",
      "field": "dataFindFrom",
      "filter": true,
      "width": "170px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Sheet Column Type",
      "field": "columnType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Formula/Static Value/Method Calling",
      "field": "formulaStaticValue",
      "filter": true,
      "width": "250px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    },
   
  ];

  dateFormateList = [];

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService,
    public _router: Router,
  ) { }

  ngOnInit() {
    this.initializeFormGroup(); 
    this.getDateFormateList();

   if(this.config.data){
      this.fileImportExportInfoFormGroup.patchValue(this.config.data); 
    }
    this.setApiGeneratedInfo();

    this.getSheetHeaderAlias();
    this.getValidationList();
  
    this.getVariableImpExpModuleListForSheetMapping();
    this.getFormList();
    this.getAllTableList();
    this.getExcelMasterForSheetMapping(false);
    this.getMasterMapping(false);
    this.getExcelFileInfo();

    this.isCreatedFileValid(false);
  }

  ngOnDestroy() { }

  initializeFormGroup() {

    this.fileImportExportInfoFormGroup = this.formbuilder.group({
      mappingId: [{ value: '', disabled: false }],
      softwareName: [{ value: '', disabled: false }],
      softwareId: [{ value: null, disabled: false }],
      formName: [{ value: '', disabled: false }],
      softwareFormId: [{ value: '', disabled: false }, [Validators.required]],
      file: [{ value: '', disabled: false }],
      fileName: [{ value: '', disabled: false }, [Validators.required]],
      type: [{ value: '', disabled: false }, [Validators.required]],
      fileType: [{ value: '', disabled: false }, [Validators.required]],
      providerId: [{ value: '', disabled: false }, [Validators.required]],
      providerName:[{ value: '', disabled: false }],
      noOfSheet: [{ value: '', disabled: false }, [Validators.required]],
      versionNo: [{ value: '', disabled: false }, [Validators.required]],
      fileExtention: [{ value: '', disabled: false }, [Validators.required]],
      fromDate: [{ value: '', disabled: false }, [Validators.required]],
      toDate: [{ value: '', disabled: false }, [Validators.required]],
      dataInsertType: [{ value: 'hibernate_query', disabled: false }],
      databaseType: [{ value: 'mysql', disabled: false }],
      viceVersaId: [{ value: '', disabled: false }],
    });
  }


  getDateFormateList() {
    this.dateFormateList = [];
    this.autoJavacodeService.getDateFormateList().subscribe(res => {
      if (res.status == 200) {
        this.dateFormateList = res.data;
        
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  getVariableImpExpModuleListForSheetMapping() {
    this.variabelModuleDropdropdownList = [];
    this.variabelModuleList = []; 
    let fileMappingId = this.fileImportExportInfoFormGroup.controls['softwareFormId'].value;
    if (fileMappingId) {
      this.autoJavacodeService.getVariableImpExpModuleListForSheetMapping(fileMappingId).subscribe(res => {
        if (res.status == 200) {
          this.variabelModuleList = res.data;
        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
    }
  }

  getFormList() {
    const setProjectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    this.angularFormList = [];
    if (setProjectInfo && setProjectInfo.jwspace) {
      const projectId = setProjectInfo.projectId

      this.autoJavacodeService.getFormList(projectId).subscribe(res => {
        if (res.status == 200) {
          this.angularFormList = res.data;
          this.getFormDropDownList(res.data);
        }
      }, Error => {

        alerts("Error While Fetching Data");
      });
    } else {
      alerts('please setPath in workspace Configuration')
    }

  }

  getExcelMasterForSheetMapping(isSetOption){
    let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;
  
    this.autoJavacodeService.getMasterMapping(mappingId, 'master', 1).subscribe(res => {
      if (res.status == 200) {
        this.excelMasterForSheetMapping = res.data
        this.mapExcelMasterDropdownForSheetMapping(isSetOption);
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  mapExcelMasterDropdownForSheetMapping(isSetOption){
    this.excelMasterDropdownForSheetMapping = [{ "key": "", "val": "--Select--" }];
    this.excelMasterForSheetMapping.forEach(ele => {
      let obj = {
       "key":ele.name,
       "val":ele.name
      }
      this.excelMasterDropdownForSheetMapping.push(obj);
    });

    if(isSetOption){
      if(this.gridDynamicForSheetMapping.sagGridObj.components['excelMaster']){
        this.gridDynamicForSheetMapping.sagGridObj.components['excelMaster'].setOption(this.excelMasterDropdownForSheetMapping);
      }
    }

  }
  

  getAllTableList() {
  
    this.tableListDropdownList = [];
    this.allTableList = [];

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
    }
    this._dbcomparetoolService.tblstrcturedrpdown(dbData).subscribe((res) => {
      if (res) {
        let masterdropdown = res['masterdropdown'];
        let mtbllist = masterdropdown.mtbllist.sort();
        this.allTableList = masterdropdown.mtbllist.sort();
        this.getTableDropdownName(mtbllist);
        this.getTableDropdownNameForMaster();
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }

  
  getTableDropdownNameForMaster() {
    this.tableMasterDropdownForSheetMapping = [{ "key": "", "val": "--Select--" }];
  this.allTableList.forEach(table => {
    let obj = {
     "key":table,
     "val":table
    }
    this.tableMasterDropdownForSheetMapping.push(obj);
  });
  }

  getSheetHeaderAlias() {
 
    this.autoJavacodeService.getSheetHeaderAlias().subscribe(res => {
      if (res.status == 200) {
        this.sheetHeaderAlias = res.data;
      }else{
        this.sheetHeaderAlias = {}
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  

  getValidationList() {
    this.dropdownValidationList = [];
    this.autoJavacodeService.getValidationList().subscribe(res => {
      if (res.status == 200) {
        this.validationList = res.data;
        this.getValidationDropdown(res.data);
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  getValidationDropdown(validationList) {
    this.dropdownValidationList = []
    validationList.forEach((ele) => {
      let obj = {
        key: ele.validationCode,
        val: ele.validationName
      };
      this.dropdownValidationList.push(obj);
    })
  }


  getExcelFileInfo() {

    let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;
    this.excelSheetList = [];
    this.manualMethodList = [];
    this.childExcelSheetList = [];
    this.sheet = null;

    this.autoJavacodeService.getExcelFileInfo(mappingId).subscribe(res => {
      if (res.status == 200) {
        let data = res.data;
        this.excelSheetList = data.excelSheetList;
        this.manualMethodList = data.manualMethodList;
        if (res.isModify) {
          let item = _.find(this.excelSheetList, { active: true });
          if (item) {
            setTimeout(() => {
            this.onClickSheet(item, 1);
            }, 100);

          }
        }
      }
    }, Error => {
      alerts("Error While Fetching info");
    });

  }

  onClickSheet(item: any, index) {
    this.sheet = item;

    if(!item['isChildernSheet']){
      if(item['excelChildSheet']){
        this.childExcelSheetList = item['excelChildSheet'];
      }else{
        this.childExcelSheetList = [];
      }
    }
 

    if(!this.sheet['dataFindFrom']){
      this.sheet['dataFindFrom'] = JSON.parse(JSON.stringify(this.dataFindFrom))
    }
    if(!this.sheet['excelHeaderType']){
      this.sheet['excelHeaderType'] = JSON.parse(JSON.stringify(this.excelHeaderType))
    }

    if(item['varriableMappingType'] == "formDbMapping"){
      this.setVariableImpExpModuleListForSheetMappingDropdown();
    }else{
      this.variabelModuleDropdropdownList = [];
      this.manageExcelSheetState(true);  
    }
  
    if(!item['isChildernSheet']){
      this.excelSheetList.forEach(itm => itm.active = false);
      this.excelSheetList.forEach(itm => itm.isRename = false);

      if(this.childExcelSheetList){
        this.childExcelSheetList.forEach(itm => itm.active = false);
      }
    }else{
      this.childExcelSheetList.forEach(itm => itm.active = false);
    }
  
   setTimeout(() => {
    this.sagSheetMappingGrid(this.sheet['sheetHeaderList']);
   }, 100);
    
    item['active'] = true;
    setTimeout(() => {
       this.manageExcelSheetState(false);  
    }, 500);
   
    
    setTimeout(() => {
      this.bindSheetData();
    }, 500);
   
    this.createDropDownForSkipRow();

  }

  setVariableImpExpModuleListForSheetMappingDropdown(){
    this.variabelModuleDropdropdownList = [];
    this.variabelModuleList.forEach(ele => {
      let obj = {
        "value": ele.moduleId,
        "label": ele.moduleName,
      }
      this.variabelModuleDropdropdownList.push(obj);
    });
  }

  manageExcelSheetState(isLoadBefore) {
    if (this.sheet && this.sheet.varriableMappingType) {
      if (isLoadBefore && this.sheet.varriableMappingType == "form") {
        this.getFormDropDownList(this.angularFormList);
        this.getTableDropdownName(this.allTableList);
        
      } else if ( isLoadBefore && this.sheet.varriableMappingType == "table") {
        this.getFormDropDownList(this.angularFormList);
        this.getTableDropdownName(this.allTableList);
    
      } else if (!isLoadBefore && this.sheet.varriableMappingType == "formDbMapping") {
        if (this.sheet.varriableMappingData) {
          this.getVariableNameByModuleId(this.sheet.varriableMappingData);
        }
      }
    }
  }

  getFormDropDownList(data) {
    this.angularFormDropdownList = [{ "key": "", "val": "--Select--" }]
    data.forEach(ele => {
      let obj = {
        "key": ele['ngsrcfileId'],
        "val": ele['formName']
      }
      this.angularFormDropdownList.push(obj);
    });
    if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['formName']) {
      this.gridDynamicForSheetMapping.sagGridObj.components['formName'].setOption(this.angularFormDropdownList);
    }
  }

  getTableDropdownName(mtbllist) {
    this.tableListDropdownList = [{ "key": "", "val": "--Select--" }];
    mtbllist.forEach(table => {
      let obj = {
        "key": table,
        "val": table
      }
      this.tableListDropdownList.push(obj);
    });
    if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['tableName']) {
      this.gridDynamicForSheetMapping.sagGridObj.components['tableName'].setOption(this.tableListDropdownList);
    }
  }
  onChangeVariableData(moduleId) {
    this.getVariableNameByModuleId(moduleId);
  }

  getVariableNameByModuleId(moduleId) {
    let formFields = [{ "key": "", "val": "--Select--" }];
    if (moduleId) {
      this.autoJavacodeService.getVariableNameByModuleId(moduleId).subscribe(res => {
        if (res.status == 200) {
          res.data.forEach(ele => {
            let obj = {
              "key": ele.labelName,
              "val": ele.labelName
            }
            formFields.push(obj);
          });

          this.filterFormsAccordingVarMapping(res);
          this.filterTablesAccordingVarMapping(res);
          this.setDefaultFormNameInSheetMapping(res);
          if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['field']) {
            this.gridDynamicForSheetMapping.sagGridObj.components['field'].setOption(formFields);
          }

        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
    } else {
      let gridsize = this.gridDynamicForSheetMapping.sagGridObj.AllRowIndex.length;
      for (let i = 0; i < gridsize; i++) {
        this.gridDynamicForSheetMapping.updateCell(i, "formName", '');
      }
      if(this.gridDynamicForSheetMapping.sagGridObj.components['field']){
        this.gridDynamicForSheetMapping.sagGridObj.components['field'].setOption(formFields);
      }
      
    }

  }

  filterTablesAccordingVarMapping(res) {
    this.tableListDropdownList = [{ "key": "", "val": "--Select--" }];
    if (res.data.length > 0) {
      let mtbllist = _.uniqBy(_.filter(res.data, variable => variable.tableName != null && variable.tableName != undefined && variable.tableName != ""), 'tableName');
     mtbllist.forEach(ele => {
        let obj = {
          "key": ele.tableName,
          "val": ele.tableName
        }
        this.tableListDropdownList.push(obj);
      });
    }
    if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['tableName']) {
      this.gridDynamicForSheetMapping.sagGridObj.components['tableName'].setOption(this.tableListDropdownList);
    }
  }

  filterFormsAccordingVarMapping(res) {
    this.angularFormDropdownList = [{ "key": "", "val": "--Select--" }];
    if (res.data.length > 0) {
      let mtbllist = _.uniqBy(_.filter(res.data, variable => variable.formName != null && variable.formName != undefined && variable.formName != ""), 'formName');
      mtbllist.forEach(ele => {
        let obj = {
          "key": ele.ngsrcfileId,
          "val": ele.formName
        }
        this.angularFormDropdownList.push(obj);
      });
     
    }
    if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['formName']) {
      this.gridDynamicForSheetMapping.sagGridObj.components['formName'].setOption(this.angularFormDropdownList);
      this.gridDynamicForSheetMapping.sagGridObj.dropDownJson_formName = this.angularFormDropdownList;
    }

  }

  

  setDefaultFormNameInSheetMapping(res) {
    if (res.data.length > 0) {
      let ngsrcfileId = res.data[0]['ngsrcfileId'];
      let gridsize = this.gridDynamicForSheetMapping.sagGridObj.AllRowIndex.length;

      for (let i = 0; i < gridsize; i++) {
        this.gridDynamicForSheetMapping.updateCell(i, "formName", ngsrcfileId);
      }
    }
  }

  createDropDownForSkipRow(){
    this.skipFixRowDropdownList = [];
    let startDataRow = Number( this.sheet['startDataRow']);
    let endDataRow =  Number(this.sheet['endDataRow']); 

    if(startDataRow && endDataRow){
      for (let index = startDataRow; index <= endDataRow; index++) {
        let obj = {
          "value": index,
          "label": index,
        }
        this.skipFixRowDropdownList.push(obj);
      }
    }
  }

  bindSheetData(){
    if(this.gridDynamicForSheetMapping){
     let gridData = this.gridDynamicForSheetMapping.getGridData();
     if(gridData){
       gridData.forEach(rowData => {
         if(rowData.formName && rowData.field){
           this.onChangeFormNameInGrid(rowData.formName,rowData.sag_G_Index,rowData.field);
         }
         if(rowData.tableName && rowData.tableField){
           this.onChangeTable(rowData.tableName, rowData.sag_G_Index,rowData.tableField);
           this.onChangeMasterTable(rowData.tableMaster, rowData.sag_G_Index,rowData.masterColumnName);
         }
       });
     }
    }
  }

  onChangeSheetType(sheetType) {
    if (!this.sheet['isChildernSheet'] && "multiMixSheet" != sheetType) {
      this.childExcelSheetList = [];
      this.sheet['excelChildSheet'] = [];
    }
  }

  getImportExportVarriabels(formName, rowIndex,formFieldBind) {

    let formFields = [{ "key": "", "val": "--Select--" }];

    let moduleId = this.sheet.varriableMappingData;
    if(!moduleId){
      if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['field']) {
        this.gridDynamicForSheetMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
      }
   }
   let ngsrcfileId = formName;
    this.autoJavacodeService.getImportExportVarriabels(moduleId).subscribe(res => {
      if (res.status == 200) {
        if(res.data!=null){
          res.data.forEach(ele => {
            let obj = {
              "key": ele.labelName,
              "val": ele.labelName
            }
            formFields.push(obj);
            this.angularformFieldsMap.set(ngsrcfileId, res.data);
          });
        }
       
        if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['field']) {
          this.gridDynamicForSheetMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
          if(formFieldBind){
            this.gridDynamicForSheetMapping.updateCell(rowIndex, "field", formFieldBind);

          }
       
        }
      }
    }, Error => {
       
      alerts("Error While Fetching Data");
    });
  } 


  onChangeFormNameInGrid(formName, rowIndex,formFieldBind) {
    let formFields = [{ "key": "", "val": "--Select--" }];
     
    if (formName) {

      if(this.sheet && (this.sheet.varriableMappingType )+"" == "formDbMapping"){
        
        this.getImportExportVarriabels(formName, rowIndex,formFieldBind);

      } else {
        let ngsrcfileId = formName;
        this.autoJavacodeService.getFormLabelName(Number(ngsrcfileId)).subscribe(res => {
          if (res.status == 200) {
            res.data.forEach(ele => {
              let obj = {
                "key": ele.labelName,
                "val": ele.labelName
              }
              formFields.push(obj);
              this.angularformFieldsMap.set(ngsrcfileId, res.data);
            });
            if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['field']) {
              this.gridDynamicForSheetMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
              if(formFieldBind){
                this.gridDynamicForSheetMapping.updateCell(rowIndex, "field", formFieldBind);
  
              }
           
            }
          }
        }, Error => {
  
          alerts("Error While Fetching Data");
        });
      }

      

    } else {
      if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['field']) {
        this.gridDynamicForSheetMapping.sagGridObj.components['field'].setOptionRow(formFields, "field", rowIndex);
      }

    }

  }

  
  onChangeTable(tableName, rowIndex,tableFieldBind) {
    if (tableName) {

      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName
      }
      this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
        if (res) {
          this.setTableFieldDropdown(res, rowIndex,tableFieldBind,tableName);
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }

  }

  setTableFieldDropdown(res, rowIndex,tableFieldBind,tableName) {
    this.tableFieldDropdownList = [{ "key": "", "val": "--Select--" }];;

    let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);
 
    tableFieldsInfo.forEach(tableColumn => {
     let obj = {
        "key": tableColumn['columnName'],
        "val": tableColumn['columnName']
      }
      this.tableFieldDropdownList.push(obj);
    });

    this.tableFieldsMap.set(tableName, tableFieldsInfo);

    if (this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['tableField']) {
      this.gridDynamicForSheetMapping.sagGridObj.components['tableField'].setOptionRow(this.tableFieldDropdownList, "tableField", rowIndex);
      if(tableFieldBind){ 
       this.gridDynamicForSheetMapping.updateCell(rowIndex, "tableField", tableFieldBind);

       let tableFieldsList = this.tableFieldsMap.get(tableName);
       let item = _.find(tableFieldsList, { "columnName": tableFieldBind });
       if (item) {
       
         this.gridDynamicForSheetMapping.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
         this.gridDynamicForSheetMapping.updateCell(rowIndex, "tableCoulmnType", item.dataType);
       }

       let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
       if(pkObj){
        this.gridDynamicForSheetMapping.updateCell(rowIndex, "primaryKey", pkObj.columnName);
        this.gridDynamicForSheetMapping.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
       }

      }
    }
  }

  onChangeMasterTable(tableName, rowIndex,tableFieldBind) {
    if (tableName) {

      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName
      }
      this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
        if (res) {
         
          this.setMasterTableFieldDropdown(res, rowIndex,tableFieldBind,tableName);
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }else{
      if(this.gridDynamicForSheetMapping.sagGridObj.components['masterColumnName']){
      this.gridDynamicForSheetMapping.sagGridObj.components['masterColumnName'].setOptionRow([{ "key": "", "val": "--Select--" }], "masterColumnName", rowIndex);
    }
    }
 }

 setMasterTableFieldDropdown(res, rowIndex,tableFieldBind,tableName) {
  this.masterTableFieldDropdownList = [{ "key": "", "val": "--Select--" }];
  let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);

  tableFieldsInfo.forEach(tableColumn => {
    let obj = {
      "key": tableColumn['columnName'],
      "val": tableColumn['columnName']
    }
    this.masterTableFieldDropdownList.push(obj);
  });

  this.masterTableFieldMap.set(tableName, tableFieldsInfo);

  if (this.gridDynamicForSheetMapping) {
    if(tableFieldsInfo.length > 0){
      this.gridDynamicForSheetMapping.updateCell(rowIndex, "tableMasterEntityName", tableFieldsInfo[0]['entityName']);
    }

    if(this.gridDynamicForSheetMapping.sagGridObj.components['masterColumnName']){
      this.gridDynamicForSheetMapping.sagGridObj.components['masterColumnName'].setOptionRow(this.masterTableFieldDropdownList, "masterColumnName", rowIndex);
    }
    if(tableFieldBind){ 
     this.gridDynamicForSheetMapping.updateCell(rowIndex, "masterColumnName", tableFieldBind);
     this.onChangeMasterTableField(tableFieldBind,tableName,rowIndex);
    }
  }
}

getSheetHeaders() {
  let sheetName = this.sheet['isChildernSheet'] ?  this.sheet['parentSheetName']  : this.sheet['name'];
  let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;

  if("dynamic_header_merge"==this.sheet['type']){
     let startHeaderRow = this.sheet["startHeaderRow"];
     let endHeaderRow = this.sheet["endHeaderRow"];
     let parentHeaderName = this.sheet["parentHeaderName"];
     if(startHeaderRow && endHeaderRow){
      this.autoJavacodeService.getSheetMergeHeaders(mappingId, sheetName, startHeaderRow,endHeaderRow,parentHeaderName).subscribe(res => {
        if (res.status == 200) {
          this.sheet['sheetHeaderList'] = res.data
          this.sagSheetMappingGrid(this.sheet['sheetHeaderList']);
        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
     }


  }else{

  let sheetType = this.sheet.type;
  let startDataRow = this.sheet["startDataRow"];
  let endDataRow = this.sheet["endDataRow"] ? this.sheet["endDataRow"] : 0 ;
  let readDataRowCellWise = this.sheet["readDataRowCellWise"] ? this.sheet["readDataRowCellWise"] : "" ;

  this.autoJavacodeService.getSheetHeaders(mappingId, sheetName, this.sheet['headerRow'],
  sheetType,startDataRow,endDataRow,readDataRowCellWise).subscribe(res => {
    if (res.status == 200) {
      this.sheet['sheetHeaderList'] = res.data
      this.sagSheetMappingGrid(this.sheet['sheetHeaderList']);
    }
  }, Error => {
    alerts("Error While Fetching Data");
  });
  }

  
}

async deleteChildSheet(){
  if (await ui.confirm('Do You Want To Delete Child Sheet ?')) {
 
  if(this.childExcelSheetList){
    for (let index = 0; index < this.childExcelSheetList.length; index++) {
      const element = this.childExcelSheetList[index];
      if(element['active']){
        this.childExcelSheetList.splice(index, 1);
      }
    }
   }
  }
}


onChangeVariableMappingType(value) {

  if (value == 'table') {
    this.variabelModuleDropdropdownList = [];
  } else if (value == 'formDbMapping') {
    this.setVariableImpExpModuleListForSheetMappingDropdown();
  } else {
    this.variabelModuleDropdropdownList = [];
  }

  if (this.sheet && this.sheet.varriableMappingType) {
    if (value == "form" || value == "table") {
      this.getFormDropDownList(this.angularFormList);
      this.getTableDropdownName(this.allTableList);
      
    } else if (value == "formDbMapping") {
      if (this.sheet.varriableMappingData) {
        this.getVariableNameByModuleId(this.sheet.varriableMappingData);
      }
    }
  }

  this.sagSheetMappingGrid(this.sheet['sheetHeaderList']);
 
}


addChildSheet(){

  if(!this.childSheetName){
    alerts("Child sheet name not valid");
    return;
  }

  let  isChildSheetNameAlreadyExist = _.find(this.childExcelSheetList,{name:this.childSheetName});
  if(isChildSheetNameAlreadyExist){
    alerts("Child Sheet name already exists");
    return ; 
  }

  this.childSheetName = this.childSheetName.trim();

  if(!this.childExcelSheetList){
    this.childExcelSheetList = [];
   }

  let sheet= { "type": "dynamic", "headerRow": null, "name":  this.childSheetName, "sheetHeaderList": [], 
  "startDataRow": "","endDataRow": "", 
  "varriableMappingType": "", "varriableMappingData": [], "excelChildSheet": [],"isChildernSheet":true,
  "parentSheetName":this.sheet['name'],
  "readDataRowCellWise":"rowWise","skipRow":[],"startHeaderRow":"" ,
  "endHeaderRow":"","parentHeaderName":"","importDataInsertType":"","exitInvalidRow":"",
  "tableRelations":[]}
  
  if(!this.sheet['excelChildSheet']){
    this.sheet['excelChildSheet'] = [];
  }

  this.childExcelSheetList.push(sheet);
  this.sheet['excelChildSheet'] = this.childExcelSheetList;
}



_getSheetMappingCommonColumn(){

  let formColumns = [];
 
    formColumns.push({
      "header": "Data Find From",
      "field": "dataFindFrom",
      "filter": true,
      "width": "170px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Sheet Column Type",
      "field": "columnType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Date Format",
      "field": "dateFormat",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })

    if("form" == this.sheet.varriableMappingType || "formDbMapping" == this.sheet.varriableMappingType){
      formColumns.push({
        "header": "Form Name",
        "field": "formName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      })
      formColumns.push({
        "header": "Field",
        "field": "field",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      })
      formColumns.push({
        "header": "Field Properties",
        "field": "fieldProperties",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "cellRenderView": true,
        "component": 'label',
      })
    }

    formColumns.push({
      "header": "Table Name",
      "field": "tableName",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "left",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Table Field",
      "field": "tableField",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Table Properties",
      "field": "tableProperties",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": true
    })
    formColumns.push({
      "header": "Is Master",
      "field": "isMaster",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Excel Master",
      "field": "excelMaster",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Table Master",
      "field": "tableMaster",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Master Column Name",
      "field": "masterColumnName",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Unique Constraint",
      "field": "uniqueConstraint",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": 'checkbox',
      "cellRenderView": true
    })
    formColumns.push({
      "header": "Formula/Static Value/Method Calling",
      "field": "formulaStaticValue",
      "filter": true,
      "width": "250px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Export By",
      "field": "importBy",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'checkbox',
      "cellRenderView": true
    })
    formColumns.push({
      "header": "Export Type",
      "field": "exportTypeInEquals",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Function",
      "field": "aggregateFunction",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    })
    formColumns.push({
      "header": "Validation",
      "field": "validationtfield",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'button',
      "cellRenderView": true,
      button:{"name":"Validation",visibility:true,classes: ['btn','btn-primary'],
      styles: { 'padding': '0px !important', 'font-size': '20px !important' }},
    })
  
 return formColumns;
}



sagSheetMappingGrid(rowsData) {
  var sourceDiv = document.getElementById("sagSheetMappingGrid");
  var columns:any = [
    {
      "header": "S.No",
      "field": "sno",
      "filter": true,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
     
  ];
 if("fix" == this.sheet['type'] && 'cellRefrenceWise' == this.sheet['readDataRowCellWise']){
  // columns.push({
  //   "header": "Row Desc",
  //   "field": "rowNo",
  //   "filter": true,
  //   "width": "100px",
  //   "editable": "false",
  //   "textalign": "center",
  //   "search": true,
  //   "component": 'text',
  //   "cellRenderView": false
  // });
  columns.push({
    "header": "Cell Desc",
    "field": "cellDesc",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  });
  columns.push({
    "header": "Cell Refrence",
    "field": "cellRefrence",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  });
  columns.push({
    "header": "Header Alias",
    "field": "headerAlias",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'label',
    "cellRenderView": true
  })
  columns.push({
    "header": "Table Row Number",
    "field": "tableRowNumber",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  });
  
 }else{

   columns.push( {
    "header": "Header Name",
    "field": "name",
    "filter": true,
    "width": "300px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  });
  
  columns.push({
    "header": "Header Alias",
    "field": "headerAlias",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'label',
    "cellRenderView": true
  })
  
  if("dynamic_header_merge" == this.sheet['type'] ){
    columns.push({
      "header": "Header Type",
      "field": "headerType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },);
 
  }
 

 }

let commonColumn =  this._getSheetMappingCommonColumn();

commonColumn.forEach(element => {
  columns.push(element);
});

if("client_details" == this.sheet['type']){
  columns = this.clientDetailsSheetColumn
}

  let self = this;

  let fieldTypeList = [
    { "key": "", "val": "--Select--" },
    { "key": "STRING", "val": "STRING" },
    { "key": "NUMERIC", "val": "NUMERIC" },
    { "key": "BOOLEAN", "val": "BOOLEAN" },
    { "key": "DATE", "val": "DATE" },

  ];
  let isMaster = [
    { "key": "", "val": "--Select--" },
    { "key": "Y", "val": "Yes" },
    { "key": "N", "val": "No" },
   ];

   let exportTypeInEqualsList = [
    { "key": "", "val": "" },
    { "key": "equalsOperator", "val": "EQUAL" },
    { "key": "inOperator", "val": "IN" },
   ];

   let aggregateFunctionList = [
    { "key": "", "val": "--Select--" },
    { "key": "sum", "val": "SUM" },
    
   ];

  
 


  var SagGridRowStatus = rowsData;
  for (var i = 0; i < SagGridRowStatus.length; i++) {
    SagGridRowStatus[i]["sno"] = i + 1;
    SagGridRowStatus[i]["headerAlias"] = this.sheetHeaderAlias[i + 1];
  }

  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      frezzManager: { "sno": "left", "name": "left","cellDesc":"left","cellRefrence":"left","headerAlias":"left" },
      components: {},
      rowCustomHeight :20,
      cellCustomPadding:5,
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
      callBack: {

        "onChangeSelect_formName": function (ele, params) {
          self.onChangeFormNameInGrid(ele.value, params.rowIndex,null)
        },
        "onChangeSelect_field": function (ele, params) {
          self.onChangeFormFieldNameInGrid(ele.value, params)
        },

        "onChangeSelect_tableName": function (ele, params) {
          let value = ele.value;
          ele.onkeydown = function (event) {
            if (event.keyCode == 13) {
              self.fillTableNameSameValue(params, value);
              
            }
          }
          self.onChangeTable(ele.value, params.rowIndex,null);
          self.setTableNameIntoDataBindFrom(ele.value);
        },
        "onChangeSelect_tableField": function (ele, params) {
          self.onChangeTableField(ele.value, params)
        },
        "onChangeSelect_isMaster": function (ele, params) {
          if(ele.value == "Y"){
            self.gridDynamicForSheetMapping.enableCell(params.rowIndex, "excelMaster"); 
            self.gridDynamicForSheetMapping.enableCell(params.rowIndex, "tableMaster");
            self.gridDynamicForSheetMapping.enableCell(params.rowIndex, "masterColumnName");
          }else{
            self.gridDynamicForSheetMapping.updateCell(params.rowIndex, "excelMaster",'');
            self.gridDynamicForSheetMapping.updateCell(params.rowIndex, "tableMaster",'');
            self.gridDynamicForSheetMapping.updateCell(params.rowIndex, "masterColumnName",'');

             self.gridDynamicForSheetMapping.disableCell(params.rowIndex, "excelMaster");
             self.gridDynamicForSheetMapping.disableCell(params.rowIndex, "tableMaster");
             self.gridDynamicForSheetMapping.disableCell(params.rowIndex, "masterColumnName");
          }
        },

        "onCheckBox_importBy": function (ele, params) {
          if("1" == params.rowValue.importBy  || "true" == params.rowValue.importBy ){
           self.gridDynamicForSheetMapping.enableCell(params.rowIndex, "exportTypeInEquals");
          }else{
            self.gridDynamicForSheetMapping.updateCell(params.rowIndex, "exportTypeInEquals",'');
            self.gridDynamicForSheetMapping.disableCell(params.rowIndex, "exportTypeInEquals");
          }
        },

        "onChangeSelect_tableMaster": function (ele, params) {
          self.onChangeMasterTable(ele.value, params.rowIndex,null)
        },
        "onChangeSelect_columnType": function (ele, params) {
          self.onChangeSheetColumnType(ele.value, params.rowIndex)
        },

        "onChangeSelect_masterColumnName": function (ele, params) {
          self.onChangeMasterTableField(ele.value, params.rowValue.tableMaster,params.rowIndex)
        },
        "onChangeSelect_excelMaster": function (ele, params) {
          self.onChangeExcelMasterField(ele.value, params)
        },
        "onChangeSelect_dataFindFrom": function (ele, params) {
          self.setColorByDataFindFrom(ele.value, params.rowIndex)
        },
      
        
         "onButton_validationtfield": function (ele, params) {
          self.onClickValidation(params);
        },

        "cellCallBack": function (param) {
          let ele = param.ele;
          ele.addEventListener('contextmenu', event => {
            event.preventDefault();
            self.gridDynamicForSheetMapping.setRowSelected(param.rowIndex);
            new Contextual({
              isSticky: false,
              items: [
                new ContextualItem({ cssIcon:"fa fa-plus", label: 'Insert Row', onClick: () => {self.addRowEllipsis(param.rowIndex); } }),
                new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Row', onClick: () => {self.deleteRowSheetMapping(param.rowIndex); } }),
                new ContextualItem({ cssIcon:"fa fa-copy", label: 'Copy Row', onClick: () => { self.copyRow(ele,param) } }),
                new ContextualItem({ cssIcon:"fa fa-paste", label: 'Paste Row', onClick: () => {  self.pasteRowSheetMapping(param.rowIndex) } }),
                new ContextualItem({ cssIcon:"fa fa-child", label: 'Add Master Extra Column', onClick: () => { self.addExtraMasterField(param.rowIndex); } }),
                ]
            });
          });
        }
      },
    
      dropDownJson_columnType: fieldTypeList,
      dropDownJson_formName: this.angularFormDropdownList,
      dropDownJson_field: [{ "key": "", "val": "--Select--" }],
      dropDownJson_tableName: this.tableListDropdownList,
      dropDownJson_tableField: [{ "key": "", "val": "--Select--" }],
      //multidropDownJson_validation: this.dropdownValidationList,
      dropDownJson_isMaster: isMaster,
      dropDownJson_excelMaster: this.excelMasterDropdownForSheetMapping,
      dropDownJson_tableMaster: this.tableMasterDropdownForSheetMapping,
      dropDownJson_masterColumnName: [{ "key": "", "val": "--Select--" }],
      dropDownJson_dataFindFrom: this.sheet['dataFindFrom'], 
      dropDownJson_dateFormat:this.dateFormateList,
      dropDownJson_aggregateFunction:aggregateFunctionList,
      dropDownJson_exportTypeInEquals: exportTypeInEqualsList,
    };
    if("dynamic_header_merge" == this.sheet['type'] ){
      gridData['dropDownJson_headerType']= this.sheet['excelHeaderType'];
      gridData['callBack']['onChangeSelect_headerType'] = function (ele, params) {
        self.onChangeExcelHeaderType(ele.value, params)
      }
   
    }

    this.gridDynamicForSheetMapping = SdmtGridT(sourceDiv, gridData, true, true);
    this.disableMasterCell();
    this.disableExportTypeInEquals();
    if (this.sheet.type=="fix"){
     // this.setColorPropertiesForFixHeader();
      //this.gridDynamicForSheetMapping.expandAll();
     
    }
    
    this.setRowColor();
    this.setValidationRowProperty(rowsData); 

    return this.gridDynamicForSheetMapping;
  }
}



setRowColor(){
  let gridData = this.gridDynamicForSheetMapping.getGridData();
  gridData.forEach(rowData => {
    this.setColorByDataFindFrom(rowData.dataFindFrom,rowData.sag_G_Index)
  });
}

setColorByDataFindFrom(dataFindFrom,sag_G_Index){ 
  if ("_sheet" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(153, 235, 255)" }
    this.gridDynamicForSheetMapping.setRowProperty(sag_G_Index, colorProperty);
  }
  if ("client_side" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(153, 255, 179)" }
    this.gridDynamicForSheetMapping.setRowProperty(sag_G_Index, colorProperty);
  }
  if ("Formula" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(255, 255, 153)" }
    this.gridDynamicForSheetMapping.setRowProperty(sag_G_Index, colorProperty);
  } if ("by_manual_method_with_aliase" == dataFindFrom || "by_manual_method" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(148, 184, 175)" }
    this.gridDynamicForSheetMapping.setRowProperty(sag_G_Index, colorProperty);
  } if ("static_value" == dataFindFrom || "static_master_code" == dataFindFrom) {
    let colorProperty = { "background-color": "rgb(214, 194, 194)" }
    this.gridDynamicForSheetMapping.setRowProperty(sag_G_Index, colorProperty);
  }
}

onChangeExcelMasterField(excelMaster, params){
 if(excelMaster){
  let item = _.find(this.excelMasterForSheetMapping, { "name": excelMaster });
  if(item){
    
    this.gridDynamicForSheetMapping.updateCell(params.rowIndex, "tableMaster", item.tableName);
    this.onChangeMasterTable(item.tableName, params.rowIndex,item.nameTableColumn);
    
  }
 }
 }

onChangeTableField(tableField, params) {
  let rowIndex = params.rowIndex;
  if (tableField) {
    let tableName = params.rowValue.tableName;
    
    let tableFieldsList = this.tableFieldsMap.get(tableName);
    let item = _.find(tableFieldsList, { "columnName": tableField });
    if (item) {
      
      this.gridDynamicForSheetMapping.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
      this.gridDynamicForSheetMapping.updateCell(rowIndex, "tableCoulmnType", item.dataType);
      
    }
    let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
    if(pkObj){
     this.gridDynamicForSheetMapping.updateCell(rowIndex, "primaryKey", pkObj.columnName);
     this.gridDynamicForSheetMapping.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
    }

  }else{
    this.gridDynamicForSheetMapping.updateCell(rowIndex, "tableProperties", ''); 
    this.gridDynamicForSheetMapping.updateCell(rowIndex, "tableCoulmnType", '');
  }
}

async fillTableNameSameValue(params, tableName){
  if (await ui.confirm('Do You Want To Fill Same Value In Next Remainig Row ?')) {
   let gridsize = this.gridDynamicForSheetMapping.sagGridObj.AllRowIndex.length;
   for (let i = params.rowIndex; i < gridsize; i++) {
     this.gridDynamicForSheetMapping.updateCell(i, "tableName", tableName);
     this.onChangeTable(tableName, i,null);
     this.setTableNameIntoDataBindFrom(tableName);
   }
  }
 }

onChangeFormFieldNameInGrid(labelName, params) {
   
  if (labelName) {
     
    let formId = params.rowValue.formName; 
    let rowIndex = params.rowIndex;
    let formFields = this.angularformFieldsMap.get(formId);
    let item = _.find(formFields, { "labelName": labelName });
    if (item) {
      this.gridDynamicForSheetMapping.updateCell(rowIndex, "fieldProperties", item.inputType );
    }

  }
}

setTableNameIntoDataBindFrom(tableName){
  let gridData = this.gridDynamicForSheetMapping.getGridData();
  let tableList = _.map(gridData, 'tableName');
  tableList.push(tableName);
  tableList = _.uniq(tableList);

  let relationList = [];
  tableList.forEach(element => {
    tableList.forEach(element1 => {
      if(element1 && element){
        let relatation =  _.find(this.tableFieldsMap.get(element) , {"parentTable":element1});
        if(relatation){
         relationList.push(relatation);
        }
      }
    
    });
  });

  this.sheet['tableRelations'] = relationList;

  this.sheet['dataFindFrom'] = JSON.parse(JSON.stringify(this.dataFindFrom));

  if(tableList){
    tableList.forEach(element => {
      if(element){
        this.sheet['dataFindFrom'].push({
          "key": "pk_of_"+element, "val": "Pk of "+element
        });
      }
      
    });
  }
  if(this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['dataFindFrom']){
    this.gridDynamicForSheetMapping.sagGridObj.components['dataFindFrom'].setOption(this.sheet['dataFindFrom']);
  }
 
}


onChangeMasterTableField(tableField, tableName,rowIndex) {

  if (tableField) {
    let tableFieldsList = this.masterTableFieldMap.get(tableName);
    let item = _.find(tableFieldsList, { "columnName": tableField });
    if (item) {
      this.gridDynamicForSheetMapping.updateCell(rowIndex, "masterEntityColumnName", item.entityColumn);
      this.gridDynamicForSheetMapping.updateCell(rowIndex, "masterColumnDBDataType", item.dataType);
    }
    let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
    if(pkObj){
      this.gridDynamicForSheetMapping.updateCell(rowIndex, "masterTablePrimaryKey", pkObj.columnName);
     this.gridDynamicForSheetMapping.updateCell(rowIndex, "masterPrimarykeyDBDataType", pkObj.dataType);
    }

  }
}

setColorPropertiesForFixHeader(){
  let gridData = this.gridDynamicForSheetMapping.getGridData();
  gridData.forEach(rowData => {
    if(rowData.details){
      let colorProperty = {"background-color":"rgb(50 189 211)"}
      this.gridDynamicForSheetMapping.disableRow( rowData.sag_G_Index);
      this.gridDynamicForSheetMapping.enableCell( rowData.sag_G_Index,"name");
      this.gridDynamicForSheetMapping.setRowProperty(rowData.sag_G_Index,colorProperty);
    }
  });
}

disableMasterCell(){
  let gridData = this.gridDynamicForSheetMapping.getGridData();
  gridData.forEach(rowData => {
    if("Y" == rowData.isMaster){
      this.gridDynamicForSheetMapping.enableCell( rowData.sag_G_Index, "excelMaster"); 
      this.gridDynamicForSheetMapping.enableCell( rowData.sag_G_Index, "tableMaster");
      this.gridDynamicForSheetMapping.enableCell( rowData.sag_G_Index, "masterColumnName");
    }else {
     this.gridDynamicForSheetMapping.disableCell( rowData.sag_G_Index, "excelMaster");
      this.gridDynamicForSheetMapping.disableCell( rowData.sag_G_Index, "tableMaster");
      this.gridDynamicForSheetMapping.disableCell( rowData.sag_G_Index, "masterColumnName");
    }
  });
}

disableExportTypeInEquals(){
  let gridData = this.gridDynamicForSheetMapping.getGridData();
  gridData.forEach(rowData => {
    if("1" == rowData.importBy  || "true" == rowData.importBy){
      this.gridDynamicForSheetMapping.enableCell(rowData.sag_G_Index, "exportTypeInEquals");
    }else {
      this.gridDynamicForSheetMapping.disableCell(rowData.sag_G_Index, "exportTypeInEquals");
    }
  });
}

onChangeExcelHeaderType(value, params){

  let gridData = this.gridDynamicForSheetMapping.getGridData();
  let filterData =  _.filter(gridData,{'headerType':'parent'})
  let headerAliasList = _.map(filterData, 'headerAlias');
  if(value=="parent"){
    headerAliasList.push(params.rowValue['headerAlias']);
  }

  this.sheet['excelHeaderType'] = JSON.parse(JSON.stringify(this.excelHeaderType));

  if(headerAliasList){
    headerAliasList.forEach(element => {
      if(element){
        this.sheet['excelHeaderType'].push({
          "key": "child_"+element, "val": "Child of "+element
        });
      }
      
    });
  }
 if(this.gridDynamicForSheetMapping && this.gridDynamicForSheetMapping.sagGridObj.components['headerType']){
  this.gridDynamicForSheetMapping.sagGridObj.components['headerType'].setOption(this.sheet['excelHeaderType']);
}
}

addRowSheetMapping(){
   this.sheet['sheetHeaderList'].push(this.getEmptyObjForAddRow());
   this.sagSheetMappingGrid(this.sheet['sheetHeaderList']);
 }


async deleteRowSheetMapping(rowIndex){
 let aliaseUsageHeader = this.checkHeaderAliaseUsage(rowIndex);
  
 let isDeleteRow = false;

 if(aliaseUsageHeader){
   if (await ui.confirm('You use this row refrence in '+aliaseUsageHeader+" ! Do you want to delete this row ")) {
     isDeleteRow = true
   }
 } else{
   isDeleteRow = true;
 }


  if(isDeleteRow){
    this.sheet['sheetHeaderList'].splice(rowIndex, 1);
     let rowNo = 0;  
    this.sheet['sheetHeaderList'].forEach(element => {
      rowNo = rowNo+1;
      element['headerAlias'] = this.sheetHeaderAlias[rowNo];
    });
    this.autoSetFormula(rowIndex,"delete"); 
    this.sagSheetMappingGrid(this.sheet['sheetHeaderList']);
  }
 
  
}


 
 autoFillSheetFields(){
  let gridData = this.gridDynamicForSheetMapping.getGridData();

  gridData.forEach(rowData => {
    if(rowData.formName && rowData.field){
      let formFields = this.angularformFieldsMap.get(rowData.formName);
      let item = _.find(formFields, { "labelName":  rowData.field});
      this.gridDynamicForSheetMapping.updateCell(rowData.sag_G_Index, "tableName", item.tableName);
      this.onChangeTable(item.tableName, rowData.sag_G_Index,item.tableColumn);
      
    }else  if(rowData.tableName && rowData.tableField){

    }
  });


  }

  saveFileImportExportMappingJson() {
    let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;

    if (mappingId == '' || mappingId == null || mappingId == undefined || this.excelSheetList == undefined || this.excelSheetList == null || this.excelSheetList == '') {
      alerts("Data not valid")
      return;
    }

    let obj = {
      "mappingId": mappingId,
      "excelSheetList": this.excelSheetList,
      "manualMethodList": this.manualMethodList ? this.manualMethodList : [],
      "type":"EXCEL"
    }

    this.autoJavacodeService.saveFileImportExportMappingJson(obj).subscribe(res => {
      if (res.status == 200) {
        success(res.msg);
      }else if (res.status == 400) {
        alerts(res.msg);
       this.validateExcelData(res.excelSheetList); 
      } else {
        alerts(res.msg);
      }
   


    }, Error => {
      alerts("Error While saving data");
    });
  }

   
  onCloseSheetMapping() {
   this.modalRef.close();
   this.ngOnDestroy();
  }

  /***********************Master Mapping********************* */
  getMasterMapping(isOpenModal){
  
    if(isOpenModal){
      this.getTableDropdownForMasterMapping();
    }
  
  
    let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;
  
    this.autoJavacodeService.getMasterMapping(mappingId, 'master', 1).subscribe(res => {
      if (res.status == 200) {
        this.excelMasterList = res.data
        if(isOpenModal){
          this.openMasterMappingModal();
        
          let item = _.find(res.data, { active: true });
          if (item) {
            setTimeout(() => {
              this.onClickMasterHeader(item, 1);
            }, 100);
          }
        }
        
  
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
   }
  
   openMasterMappingModal(){
    $('#masterMappingModal').modal('show')
   }
  
   closeMasterMappingModal(){
     $('#masterMappingModal').modal('hide')
   }
  
   onClickMasterHeader(item: any, index) {
    this.isMasterMappingExcelWise = "SHEET_WISE" == item.mappingType  ? false :true
    this.excelMasterInfo = item;
    this.excelMasterList.forEach(itm => itm.active = false);
    this.excelMasterList.forEach(itm => itm.isRename = false);

    item['active'] = true;
    this.tableColumnDropdownForMasterMapping = [];
    this.tableDataDropdownMasterMapping      = [{ "key": "", "val": "--Select--" }];
  
    this.bindMasterMappingData();
  
  }
  
  bindMasterMappingData(){
    let tableName = this.excelMasterInfo["tableName"];
    let nameTableColumn = this.excelMasterInfo["nameTableColumn"];
  
    if(tableName == undefined || tableName == ""){
      if(this.excelMasterInfo['masterList']){
        let sheetName = this.excelMasterInfo['sheetName']
        this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']);
      }else{
        this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
      }
     
      return;
    }

   
    
    let tableFields =  this.tableFieldsMapForMasterMapping.get(tableName);
    if(tableFields!=undefined && tableFields!=null && tableFields.length > 0 ){
      this.getTableColumnDropdownForMasterMapping(tableFields,tableName,true);
      if(nameTableColumn){
        let tableData =  this.tableDataMapMasterMapping.get(tableName);
        if(tableData){
          this.getTableDataDropdownForMasterMapping(tableData,nameTableColumn,true);
        }else{
          this.getTableDataForMasterMapping(tableName,true); 
        }
       
      }else{
        if(this.excelMasterInfo['masterList']){
          let sheetName = this.excelMasterInfo['sheetName']
          this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']);
        }else{
          this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
        }
        
      }
      
  
    }else{
      if(nameTableColumn){
        this.onChangeTableNameDropdownForMasterMapping(tableName,true);
      }else{
        if(this.excelMasterInfo['masterList']){
          let sheetName = this.excelMasterInfo['sheetName']
          this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']);
        }else{
          this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
        }
        this.onChangeTableNameDropdownForMasterMapping(tableName,false);
      }
      
    }

    if(this.excelMasterInfo["isFilterData"] || "SHEET_WISE" == this.excelMasterInfo.mappingType+""){
      if(this.excelMasterInfo['query']){
        if(this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]){
          if(this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]['sql']){
            this.executeQuery(this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]['sql'],true);     
          }
         }
       }
    }
    this.gridDynamicForMasterMapping.expandAll();
  
  }

  onChangeTableNameDropdownForMasterMapping(tableName,isGridLoad){
    if (tableName) {
      this.getTableDataForMasterMapping(tableName,isGridLoad);
      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName
      }
      this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
        if (res) {
       
          this.getTableColumnDropdownForMasterMapping(res,tableName,false);
          
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }
   }
  
   getTableColumnDropdownForMasterMapping(res,tableName,isFetchFromCache){
    this.tableColumnDropdownForMasterMapping = [];

    let tableFieldsInfo = [];

    if (isFetchFromCache) {
      tableFieldsInfo = res;
    } else {
      tableFieldsInfo = this.getTableInfoWithCustomKeys(res, tableName);
    }
  
    let pkObj = _.find(tableFieldsInfo, { "pkey": "Y" });
      if(pkObj){
          this.excelMasterInfo["primaryKeyEntityColumn"] = pkObj.entityColumn;
          this.excelMasterInfo["primaryKeyTableColumn"] = pkObj.columnName
          this.excelMasterInfo["primaryKeyTableColumnDbDataType"] = pkObj.dataType
          this.excelMasterInfo["entityName"] = pkObj["entityName"];
      }
  
      tableFieldsInfo.forEach(tableColumn => {
      let obj = {
        "label": tableColumn['columnName'],
        "value": tableColumn['columnName']
      }
      
      this.tableColumnDropdownForMasterMapping.push(obj);
    });

    this.tableFieldsMapForMasterMapping.set(tableName, tableFieldsInfo);

   }

    
 getTableDataForMasterMapping(tableName,isGridLoad){
  if (tableName) {

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
      "dbtype": "master",
      "tableName": tableName,
      "details": {
        "columns": [],
        "software": [],
        "year": [],
        "client": [],
        "operation": "",
        "limitRows": "null"
    },
    }
    this._dbcomparetoolService.getAllTabTableData(dbData).subscribe((res) => {
      if (res) {
     
        this.tableDataMapMasterMapping.set(tableName,res);
        if(isGridLoad){
          this.getTableDataDropdownForMasterMapping(res,this.excelMasterInfo['nameTableColumn'],isGridLoad);
        }
       
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }
 }

 
 getTableDataDropdownForMasterMapping(res,nameTableColumn,isGridLoad){
  this.tableDataDropdownMasterMapping = [{ "key": "", "val": "--Select--" }];
  if(res.gridarray){
    if(nameTableColumn){
      res.gridarray.forEach(ele => {
        let obj = {
          "key": ele[nameTableColumn],
          "val": ele[nameTableColumn]
        }
        this.tableDataDropdownMasterMapping.push(obj);
      });
    }
  }

  if(!isGridLoad){
    if(this.gridDynamicForMasterMapping.sagGridObj.components['tableMasterName']){
      this.gridDynamicForMasterMapping.sagGridObj.components['tableMasterName'].setOption(this.tableDataDropdownMasterMapping);
    }
   
  }else{
    if(this.excelMasterInfo['masterList']){
      let sheetName = this.excelMasterInfo['sheetName']
      this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']);
    }else{
      this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
    }
  }
  try {
    this.gridDynamicForMasterMapping.expandAll();
  } catch (error) {
    
  }
 }

  
  
  
   getTableDropdownForMasterMapping(){
    this.tableNameDropdownForMasterMapping = [];
    this.allTableList.forEach(table => {
      let obj = {
        "label": table,
        "value": table
      }
      this.tableNameDropdownForMasterMapping.push(obj);
    });
   }

   onChangeNameColumnDropdownForMasterMapping(nameColumn){

    let tableName =  this.excelMasterInfo['tableName'];
    if(tableName && nameColumn){
     let data =  this.tableDataMapMasterMapping.get(tableName);
     let tableFieldsInfo = this.tableFieldsMapForMasterMapping.get(tableName)
     if(tableFieldsInfo){
      
      let columnObj = _.find(tableFieldsInfo, { "columnName": nameColumn });
      if(columnObj){
       this.excelMasterInfo["nameEntityColumn"] = columnObj.entityColumn;
      }
     }
      this.getTableDataDropdownForMasterMapping(data,nameColumn,false);
      
      let sheetName = this.excelMasterInfo['sheetName']
      this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']);
    }

    this.gridDynamicForMasterMapping.expandAll();
  }

  onChangeCodeColumnDropdownForMasterMapping(codeColumn){

    let tableName =  this.excelMasterInfo['tableName'];
    if(tableName && codeColumn){
     let tableFieldsInfo = this.tableFieldsMapForMasterMapping.get(tableName)
     if(tableFieldsInfo){
      
      let columnObj = _.find(tableFieldsInfo, { "columnName": codeColumn });
      if(columnObj){
       this.excelMasterInfo["codeEntityColumn"] = columnObj.entityColumn;
      }
     }
     
    }
  }


  saveFileImportExportMasterMappingJson() {
    let mappingId = this.fileImportExportInfoFormGroup.controls["mappingId"].value;
  
    if(!mappingId){
      alerts("Please save first data mapping")
      return;
    }
    if (mappingId == '' || mappingId == null || mappingId == undefined ) {
      alerts("Data not valid")
      return;
    }
    if(this.excelMasterList == undefined || this.excelMasterList == null || this.excelMasterList == ''){
      this.excelMasterList = [];
    }

    let obj = {
      "mappingId": mappingId,
      "excelMasterList": this.excelMasterList
    }
  
    if(this.checkDuplicateMasterMapping()){
      return;
    }
  
    this.autoJavacodeService.saveFileImportExportMasterMappingJson(obj).subscribe(res => {
      if (res.status == 200) {
        this.getExcelMasterForSheetMapping(true);
        success(res.msg);
      } else {
        alerts(res.msg);
      }
    }, Error => {
      alerts("Error While saving data");
    });
  }

  checkDuplicateMasterMapping(){
    let isDuplicate:boolean = false;
    this.excelMasterList.forEach(element => {
      let sheetName = element["name"];
      let masterList = element['masterList'];
      for (const property in masterList) {
        let masterList1 = masterList[property];
        if(isDuplicate){
          return;
        }
        if(masterList1){
          let groupBy = _.chain(masterList1).groupBy('tableMasterName').map((value, key) => ({ key,  value }))
          .value();
          groupBy.forEach(group => {
            if(group['key'] && group['value']){
              if(group['value'] && group['value'].length > 1){
                let msgSheetName = sheetName+" "+property;
                console.log(msgSheetName);
                
                alerts(msgSheetName+ " have duplicate table master entry" );
                isDuplicate = true;
                return;
             };
            }
          });
        }
      }
    });
    return isDuplicate;
  }
 
  
onChangeExcelSheetWiseMapping(mappingType){
   

  if(mappingType == "EXCEL_WISE"){
    this.isMasterMappingExcelWise = true;
    this.excelMasterInfo['sheetName'] = "";
    let obj = {
      "":this.excelMasterInfo['excelMasterList']
    }
    this.excelMasterInfo['masterList'] = obj

  } else if(mappingType == "SHEET_WISE"){
    this.isMasterMappingExcelWise = false;
    if(this.excelSheetList){
      let obj = {
        "":[]
      }
      this.excelSheetList.forEach(element => {
        obj[element.name] = JSON.parse(JSON.stringify(this.excelMasterInfo['excelMasterList']));
      });
      this.excelMasterInfo['masterList'] = obj
    }
  }
 
    let sheetName = this.excelMasterInfo['sheetName']
    this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']);

    this.gridDynamicForMasterMapping.expandAll();
 }

 onChangeSheetNameInMasterMapping(sheetName){
  let isSqlExist = false;
  if(sheetName){
   if(this.excelMasterInfo['query']){
     if(this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]){
       if(this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]['sql']){
         isSqlExist = true;
         this.executeQuery(this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]['sql'],true);     
       }
      }
    }
  }
 if(!isSqlExist){
  let tableName = this.excelMasterInfo["tableName"];
  let nameTableColumn = this.excelMasterInfo["nameTableColumn"];
  let tableData =  this.tableDataMapMasterMapping.get(tableName);
  if(tableData){
    this.getTableDataDropdownForMasterMapping(tableData,nameTableColumn,true);
  }else{
    this.getTableDataForMasterMapping(tableName,true); 
  }

   this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']);
   this.gridDynamicForMasterMapping.expandAll();
 }
 
}

filterMasterMappingData(){
  this.getMasterTableDataWithParentTable(this.excelMasterInfo['tableName'],false)
 }

 resetFilter(){
  this.excelMasterInfo['isFilterData'] = true;
  this.excelMasterInfo['query'] = null;
  this.bindMasterMappingData();
 }

 getMasterTableDataWithParentTable(tableName,isGridLoad){
  if (tableName) {
    this.openFilterMasterMappingModal();
    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
      "dbtype": "master",
      "tableName": tableName,
      "details": {
        "columns": [],
        "software": [],
        "year": [],
        "client": [],
        "operation": "",
        "limitRows": "null"
    },
    }
    this._dbcomparetoolService.getEnityHqlData(dbData).subscribe((res) => {
      if (res) {
        let arr = [];
        this.createMastersFilterData(arr,res);
        this.sagFilterMasterMappinGrid(arr);
       
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }
 }


 gridDynamicFilterMasterMappingGrid:any;
 sagFilterMasterMappinGrid(rowsData) {
  var sourceDiv = document.getElementById("filterMasterMappingGridId");
  let columns : any =  [
    {
      "field": "checkBox",
      "filter": false,
      "editable": false,
      "sagGridResize": false,
      "width": "50px",
      "header": "All",
      "text-align": "center",
      "colType": "checkBox"
    },
   
    {
      "header": "S.No",
      "field": "sno",
      "filter": true,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },

    {
      "header": "Table Column",
      "field": "tablecolumn",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
    {
      "header": "Value",
      "field": "tableValue",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": "tableValueComponent",
    },
   


  ];
  
   let self = this;
   let components = { 
     "tableValueComponent": new SagInputText({}, function () {
  })
};
 var SagGridRowStatus = rowsData;
  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      rowCustomHeight :20,
      cellCustomPadding:5,
      components: components,
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
      callBack: {
        
      },
      rowGrouping: {
        "enable": true,
        "groupType": "custome",
        "groupBy": "tablecolumn",
        "expandRow": []
      },
      rowSelection: false,
      rowDataViewTotal: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
    };
    this.gridDynamicFilterMasterMappingGrid = SagGridMPT(sourceDiv, gridData, true, true);
    
    return this.gridDynamicFilterMasterMappingGrid;

  }

}

 createMastersFilterData(arr,res){
  let columns =res['columns'];
  let jointable = res['jointable'];
  let foreignkeycolumns =res['foreignkeycolumns'];
  columns.forEach(column => {
    column['tablename'] = res['tablename'];
    column['entitytable'] = res['entitytable'];
    column['primarykey'] = res['primarykey'];
    let foreignObj =  _.find(foreignkeycolumns ,{"fkeycol":column.tablecolumn});
  
    if(foreignObj){
     let referencedtable = foreignObj['referencedtable'];
      let parentJoinTable =  _.find(jointable ,{"tablename":referencedtable});
      let obj = column;
      obj['details'] = []; 
      this.createMastersFilterDataRec(obj['details'],parentJoinTable)
      arr.push(obj); 
    }else {
      arr.push(column);
    }
   });
    
 }

 createMastersFilterDataRec(arr,res){
  let columns =res['columns'];
  let jointable = res['jointable'];
  let foreignkeycolumns =res['foreignkeycolumns'];
  columns.forEach(column => {
    column['tablename'] = res['tablename'];
    column['entitytable'] = res['entitytable'];
    column['primarykey'] = res['primarykey'];
  
    let foreignObj =  _.find(foreignkeycolumns ,{"fkeycol":column.tablecolumn});
  
    if(foreignObj){
     let referencedtable = foreignObj['referencedtable'];
      let parentJoinTable =  _.find(jointable ,{"tablename":referencedtable});
      let obj = column;
      obj['details'] = []; 
      this.createMastersFilterDataRec(obj['details'],parentJoinTable)
      arr.push(obj); 
    }else {
      arr.push(column);
    }
   });
    
 }

 

 onClickFilterMasterDataOk(){
  let gridData  = this.gridDynamicFilterMasterMappingGrid.getGridData();
  let sqlWhere = [];
  let hqlWhere = [];

  let join = new Set();
  let hqljoin = new Set();

 let sqlSelect = this.createSqlSelect();
 let hqlSelect = this.createHqlSelect();

  gridData.forEach(row => {
    if(row.details){
      this.createSql(join,sqlWhere,row);
      this.createHql(hqljoin,hqlWhere,row);
    }
  });
 
 let sqlWhereStr =  _.join(sqlWhere, [' and ']);
 let hqlWhereStr =  _.join(hqlWhere, [' and ']);

 join.forEach(value => {
  sqlSelect = sqlSelect.concat(value+"");
 });

 hqljoin.forEach(value => {
  hqlSelect = hqlSelect.concat(value+"");
 });

 sqlSelect = sqlSelect.concat(" where "+sqlWhereStr);
 hqlSelect = hqlSelect.concat(" where "+hqlWhereStr);

if(!this.excelMasterInfo['query']){
  this.excelMasterInfo['query'] = {}
}
this.excelMasterInfo['query'][this.excelMasterInfo.sheetName] = {
  "hql":hqlSelect,
  "sql":sqlSelect,
}

this.excelMasterInfo['isFilterData'] = true;

 this.executeQuery(sqlSelect,true);



 }

 executeQuery(query,isGridLoad){
  if (query) {
   
    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
      "dbtype": "master",
      "details": {
        "sql": query,
        "queryType":"select"
    },
    }
    this._dbcomparetoolService.getexecuteSql(dbData).subscribe((res) => {
      if (res) {
        this.closeFilterMasterMappingModal();
        //this.tableDataMapMasterMapping.set(this.excelMasterInfo.tableName,res);
        this.getTableDataDropdownForMasterMapping(res,this.excelMasterInfo['nameTableColumn'],isGridLoad);
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }
 }

 createSqlSelect () {
  let tableName = this.excelMasterInfo.tableName;
  let nameTableColumn = this.excelMasterInfo.nameTableColumn;
  let codeTableColumn = this.excelMasterInfo.codeTableColumn;
  let primaryKeyTableColumn = this.excelMasterInfo["primaryKeyTableColumn"] ;

  let sqlSelect = "select " ;
  sqlSelect = sqlSelect + (tableName+"."+ primaryKeyTableColumn);
  sqlSelect = sqlSelect + (","+tableName+"."+ nameTableColumn);
  if(codeTableColumn!=""){
    sqlSelect = sqlSelect + (","+tableName+"."+ codeTableColumn);
  }
  sqlSelect = sqlSelect +(" from "+tableName);
 
  return sqlSelect;
 }

 createHqlSelect () {
  let entityName = this.excelMasterInfo['entityName'];
  let nameEntityColumn = this.excelMasterInfo['nameEntityColumn'];
  let primaryKeyEntityColumn = this.excelMasterInfo["primaryKeyEntityColumn"];
 let aliase =  this._getAliase(entityName);
  let sqlSelect = "select new map (" ;
  sqlSelect = sqlSelect + (aliase+"."+primaryKeyEntityColumn +" as id ");
  sqlSelect = sqlSelect + (","+ aliase+"."+nameEntityColumn + " as label");
  
  sqlSelect = sqlSelect +(" ) from "+entityName +" as " +aliase);
 
  return sqlSelect;
 }

 _getAliase(entityName:string){
   if(entityName){
    return entityName.substring(0, 1).toLowerCase()+entityName.substring(1); 
   }
  return entityName;
 }

 isAnyFieldSelected;
 createSql(join,sql,row){
   this.isAnyFieldSelected = false;
   this.getAnyFiledSelected(row.details);
  if(this.isAnyFieldSelected){
    let firstRow = row.details[0];
    join.add(" inner join "+firstRow.tablename + " on " +row.tablename+"."+row.tablecolumn +" = " +firstRow.tablename +"."+firstRow.primarykey+" "); 
  }
  row.details.forEach(element => {
    if(element.checkBox){
      sql.push(" "+element.tablename+"."+element.tablecolumn+" ='"+element.tableValue+"' ");
    }
    if(element.details){
      this.createSql(join,sql,element);
    }
  });

 }

 createHql(join,hql,row){
  this.isAnyFieldSelected = false;
  this.getAnyFiledSelected(row.details);
 if(this.isAnyFieldSelected){
  let firstRow = row.details[0];
  let aliase =  this._getAliase(firstRow.entitytable); 
  let aliase1 =  this._getAliase(row.entitytable);
  let joinStr = " inner join "+firstRow.entitytable + " "+aliase+ " on " +aliase1+"."+row.entitylabel +" = " +aliase +"."+firstRow.entitylabel+" ";
 // let joinStr =  " inner join "+aliase1+"."+row.entitylabel + " as " +aliase;

  join.add(joinStr);
  
   
 
  }
 row.details.forEach(element => {
   if(element.checkBox){
    let aliase =  this._getAliase(element.entitytable);
    hql.push(" "+aliase+"."+element.entitylabel+" ='"+element.tableValue+"' ");
   }
   if(element.details){
     this.createHql(join,hql,element);
   }
 });

}


 getAnyFiledSelected (parentTableList){
   if(this.isAnyFieldSelected){
     return;
   }
  let data = _.find(parentTableList,{checkBox:true})
  if(data){
    this.isAnyFieldSelected = true;
  }
 
  if(!this.isAnyFieldSelected){
    parentTableList.forEach(element => {
      if(element.details){
        this.getAnyFiledSelected(element.details);
      }
    });
  }
  
 }

 notMatchExcelMasterList = [];
notMatchTableMasterList = [];

onClickCheckMismatchMaster(){
  this.notMatchTableMasterList = [];
  let masterList = this.excelMasterInfo.masterList[this.excelMasterInfo.sheetName];
  let gridData =  this.gridDynamicForMasterMapping.getGridData();
  let tableDataDropdownMasterMapping = this.tableDataDropdownMasterMapping;

 this.notMatchExcelMasterList =  masterList.filter(x => (!x['tableMasterName']));

  let tableDataList = tableDataDropdownMasterMapping.filter(x => (x['key'])).map(ele => ele['key']);

  tableDataList.forEach(field => {
    if(!_.find(gridData, { tableMasterName: field })){
      this.notMatchTableMasterList.push(field);
    }
  });

  this.openCheckMismatchMasterModalId();
}


addExcelMaster(){
  let index = this.gridDynamicForMasterMapping.sagGridObj.AllRowIndex.length;
    let obj = {
          "excelMaster":"",
          "tableMasterName": "",
          "tableMasterCode": "",
     }
     let sheetName = this.excelMasterInfo['sheetName']
    
     this.excelMasterInfo['masterList'][sheetName].push(obj);
     this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']); 
        
     this.gridDynamicForMasterMapping.expandAll();
}

deleteExcelMaster(){
  let sheetName = this.excelMasterInfo['sheetName']
  let selectedRowData = this.gridDynamicForMasterMapping.getSeletedRowData();
  this.deleteRowMasterMappingTree(selectedRowData.sag_G_Index , this.excelMasterInfo['masterList'][sheetName])
  this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']);
  this.gridDynamicForMasterMapping.expandAll();
}

deleteRowMasterMappingTree(sag_G_Index,array){

  for (let index = 0; index < array.length; index++) { 
    const element = array[index];
    if(element.details){
      this.deleteRowMasterMappingTree(sag_G_Index,element.details);
     }
     if(element.sag_G_Index == sag_G_Index){
      array.splice(index, 1)
     }
  }
}

openCheckMismatchMasterModalId() {
  $('#checkMismatchMasterModalId').modal('show')
}

closeCheckMismatchMasterModalId() {
  $('#checkMismatchMasterModalId').modal('hide')
}

 openFilterMasterMappingModal(){
  $('#filterMasterMappingId').modal('show')
 }

 closeFilterMasterMappingModal(){
   $('#filterMasterMappingId').modal('hide')
 }

 onChangeMasterMappingType(masterMappingType){
  let sheetName = this.excelMasterInfo['sheetName'];
  if("map_with_table_data"!= masterMappingType){
    this.excelMasterInfo['tableName'] ="";
    this.excelMasterInfo['nameTableColumn'] ="";
    this.excelMasterInfo['codeTableColumn'] ="";
    this.excelMasterInfo['mappingType'] ="EXCEL_WISE";
    this.excelMasterInfo['sheetName'] ="";
   }
  this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],masterMappingType);

  this.gridDynamicForMasterMapping.expandAll();
 }

  
   masterMappingGrid(rowsData,masterMappingType) {
    var sourceDiv = document.getElementById("masterMappingGridId");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Add Case",
        "field": "addCase",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "text-align": "left",
        "search": true,
        "component": "dynamicComponent",
        "cellRenderView": true,
        "freezecol": "null",
        "hidden": false,
        "sort": false,
        "cellHover": false,
        "button": { "imgsrc": "", "iconclass": "fas fa-plus", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-info"], "attribute": "", "styles": "" },
  
      },  
      {
        "header": "Excel Master Value",
        "field": "excelMaster",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      
      
    ];

    let tableMasterName ={
      "header": "Table Data Value",
      "field": "tableMasterName",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    };
    let tableMasterCode = {
      "header": "Table Data Code",
      "field": "tableMasterCode",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": true
    };

    let constantValue = {
      "header": "Table Data Value",
      "field": "tableMasterName",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    };

    if("map_with_constant_value" == masterMappingType){
      columns.push(constantValue);
      //columns.push(constantDisplayValue);
    }else{
      columns.push(tableMasterName);
      columns.push(tableMasterCode);
    }


    let self = this;
  
    let components ={};
  
    var SagGridRowStatus = rowsData;
     
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
       
      if(SagGridRowStatus[i].details){
       
        for (var j = 0; j < SagGridRowStatus[i].details.length; j++) {
          SagGridRowStatus[i].details[j]['dynamicCompName_addCase'] = 'label';
        }

        SagGridRowStatus[i]['dynamicCompName_addCase'] = 'buttonIcon';
       }else{
        SagGridRowStatus[i]['dynamicCompName_addCase'] = 'buttonIcon';
         
       }

     
    }
  
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        rowCustomHeight :20,
        cellCustomPadding:5,
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onChangeSelect_tableMasterName": function (ele, params) {
            self.onChangetableMasterNameInGrid(ele.value, params.rowIndex)
          },
          "onButtonIcon_addCase": function (ele, params) {
            self.addCaseInMaster(params);
  
          },
        },
        dropDownJson_tableMasterName: this.tableDataDropdownMasterMapping,

        rowGrouping: {
          "enable": true,
          "groupType": "custome",
          "groupBy": "excelMaster",
          "expandRow": []
        },
        rowSelection: false,
        rowDataViewTotal: true,
        sml_expandGrid_hide: true,
        exportXlsxPage_hide: true,
        exportXlsxAllPage_hide: true,
        exportPDFLandscape_hide: true,
        exportPDFPortrait_hide: true,
        ariaHidden_hide: true,
      };
  
      this.gridDynamicForMasterMapping = SdmtGridT(sourceDiv, gridData, true, true);
     
      this.disableExtraMasterValue();

      return this.gridDynamicForMasterMapping;
    }
  }

  addCaseInMaster(params){
     
    let sagGridData = this.gridDynamicForMasterMapping.getGridData();

    let rowIndex = 0;

    for (let index = 0; index < sagGridData.length; index++) {
      if (params.rowIndex == sagGridData[index].sag_G_Index) {
        rowIndex = index;
      }
    }

    let obj = {
          "excelMaster":"",
          "tableMasterName": params.rowValue.tableMasterName,
          "tableMasterCode": params.rowValue.tableMasterCode,
     }
     let sheetName = this.excelMasterInfo['sheetName']
     
     if(!this.excelMasterInfo['masterList'][sheetName][rowIndex]['details']){
       this.excelMasterInfo['masterList'][sheetName][rowIndex]['details'] = [];
     }
     this.excelMasterInfo['masterList'][sheetName][rowIndex]['details'].push(obj);
     this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']); 

    // let length =  this.excelMasterInfo['masterList'][sheetName][rowIndex]['details'].length;
    // let disableRowIndex = params.rowIndex + length;

    //  this.gridDynamicForMasterMapping.disableCell(disableRowIndex, "addCase");
    //  this.gridDynamicForMasterMapping.disableCell(disableRowIndex, "tableMasterName");
    //  this.gridDynamicForMasterMapping.disableCell(disableRowIndex, "tableMasterCode");
        
     this.gridDynamicForMasterMapping.expandAll();
  }

  disableExtraMasterValue() {
    let sagGridData = this.gridDynamicForMasterMapping.getGridData();

    if (sagGridData) {

      sagGridData.forEach(element => {
        if (element.details) {
          element.details.forEach(childEle => {
            this.gridDynamicForMasterMapping.disableCell(childEle.sag_G_Index, "addCase");
            this.gridDynamicForMasterMapping.disableCell(childEle.sag_G_Index, "tableMasterName");
            this.gridDynamicForMasterMapping.disableCell(childEle.sag_G_Index, "tableMasterCode");
          });
        }
      });
    }

  }

  onChangetableMasterNameInGrid(value,rowIndex){
    let tableName =  this.excelMasterInfo['tableName'];
    let nameTableColumn =  this.excelMasterInfo['nameTableColumn'];
    let data =  this.tableDataMapMasterMapping.get(tableName);
    let codeTableColumn =  this.excelMasterInfo['codeTableColumn'];
   if(codeTableColumn){
    let item =_.find(data.gridarray, function(obj) {
      return obj[nameTableColumn] === value;
  });
  
    if(item){
      this.gridDynamicForMasterMapping.updateCell(rowIndex, "tableMasterCode", item[codeTableColumn]);
    }
   }
   
  }

  async importTableDataFromDb(){
   
    let isSubMasterAdd = false
    if (await ui.confirm('Do You Want To Create Table Column Code is also master')) {
      isSubMasterAdd = true
    }

    let tableName = this.excelMasterInfo['tableName'];
    let data = this.tableDataMapMasterMapping.get(tableName);
    let isFilterData = this.excelMasterInfo["isFilterData"]

    if (isFilterData) {
      if (this.excelMasterInfo['query']) {
        if (this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]) {
          if (this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]['sql']) {
            let query = this.excelMasterInfo['query'][this.excelMasterInfo.sheetName]['sql']
            let dbData = {
              "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
              "targetDataSource": {},
              "operation": "COMPARESINGLE",
              "connectionRoleType": "admin",
              "dbtype": "master",
              "details": {
                "sql": query,
                "queryType": "select"
              },
            }
            this._dbcomparetoolService.getexecuteSql(dbData).subscribe((res) => {
              if (res) {
                this.createMasterRow(res, isSubMasterAdd);
                let sheetName = this.excelMasterInfo['sheetName']
                this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']); 
    
                this.gridDynamicForMasterMapping.expandAll();
              }
            }, Error => {
              alerts("Error While Fetching data");
            });
          }
        }
      }
    } else {
      if (data) {
        this.createMasterRow(data, isSubMasterAdd);
        let sheetName = this.excelMasterInfo['sheetName']
        this.masterMappingGrid(this.excelMasterInfo['masterList'][sheetName],this.excelMasterInfo['masterMappingType']); 
    
        this.gridDynamicForMasterMapping.expandAll();
      }
    }
    
  }

  createMasterRow(data, isSubMasterAdd) {
    let sheetName = this.excelMasterInfo['sheetName']
    let nameTableColumn = this.excelMasterInfo['nameTableColumn'];
    let codeTableColumn = this.excelMasterInfo['codeTableColumn'];


    this.excelMasterInfo['masterList'][sheetName] = [];
    data.gridarray.forEach(element => {
      let obj = {
        excelMaster: element[nameTableColumn],
        tableMasterName: element[nameTableColumn],
        tableMasterCode: element[codeTableColumn],
      }

      if (isSubMasterAdd) {
        let arr = [];
        arr.push({
          excelMaster: element[codeTableColumn],
          tableMasterName: element[nameTableColumn],
          tableMasterCode: element[codeTableColumn],
        })
        obj['details'] = arr;
      }
      this.excelMasterInfo['masterList'][sheetName].push(obj);
    });

    return  this.excelMasterInfo['masterList'][sheetName];
  }

  masterName:String = "";
  importExcelMasterObj
  addMasterName(){
    this.masterName = "";
    this.openMasterNameModal();
  }

  async deleteMasterName(){
    if (await ui.confirm('Do You Want To Delete Master ?')) {

      if(this.excelMasterList){
        for (let index = 0; index < this.excelMasterList.length; index++) {
          const element = this.excelMasterList[index];
          if(element['active']){
            this.excelMasterList.splice(index, 1);
          }
        }
       }
      if(this.excelMasterList && this.excelMasterList.length > 0 ){
        this.onClickMasterHeader(this.excelMasterList[0], 1);
      }else{
        this.masterMappingGrid([],"map_with_constant_value");
      }

      }
  }

  onClickAddMasterName(){
    if(!this.masterName){
     alerts("Master name not valid");
    }
    
   let find =  _.find(this.excelMasterList , {"name" : this.masterName});
   if(find){
     alerts(this.masterName+ " Already exist")
     return;
   }

   let sheetObj = {
     "":[],
   }

    let obj = {
      "name": this.masterName,
      "tableName": "",
      "active": false,
      "nameTableColumn": "",
      "codeTableColumn": "",
      "masterList": sheetObj,
      "mappingType": "EXCEL_WISE",
      "sheetName":"",
      'masterMappingType':"map_with_constant_value",
      'excelMasterList': [],
      'isMasterManualCreate':true,
      
    };
    
   this.excelMasterList.push(obj);
   this.closeMasterNameModal();

  }
  openMasterNameModal(){
    $('#addMasterNameModal').modal('show')
   }
  
   closeMasterNameModal(){
     $('#addMasterNameModal').modal('hide')
   }

  autoFillMaster() {
    let gridData = this.gridDynamicForMasterMapping.getGridData();
    gridData.forEach(element => {
      if ("map_with_constant_value" != this.excelMasterInfo['masterMappingType'] + "") {
        let excelMaster = element.excelMaster;
        let defaultPer = 50;
        this.tableDataDropdownMasterMapping.forEach(tableMaster => {
          let per = this.similarity(excelMaster, tableMaster.val);
          if (per >= defaultPer) {
            defaultPer = per;
            this.gridDynamicForMasterMapping.updateCell(element.sag_G_Index, "tableMasterName", tableMaster.val);
            this.onChangetableMasterNameInGrid(tableMaster.val, element.sag_G_Index)
          }
        });
      }
    });
  }

   similarity(s1, s2) {
		s1 = s1.toString().toLowerCase();
		s2 = s2.toString().toLowerCase();

    let words = s1.split(/[^\w]/gi);
    
    words = words.filter(function (el) {
      return el != null &&  el != "";
    });

		let count = 0;
    let list = s2.split(/[^\w]/gi);

    list = list.filter(function (el) {
      return el != null &&  el != "";
    });

		for (var i = 0; i < words.length; i++) {
			let word = words[i].trim();
			if (list.includes(word)) {
				count++;
			}
		}

		return (count / parseFloat(words.length)) * 100;

	}


/***************************************Manual Code************************************** */

openManualCode() {
  let selectedRowManualMethod = "";
  let selectedRowData = this.gridDynamicForSheetMapping.getSeletedRowData();
  if (selectedRowData && selectedRowData.formulaStaticValue) {
    selectedRowManualMethod = selectedRowData.formulaStaticValue;
  }

  let apiGeneratedObj = this.dbMappingform.getRawValue();
  // let formObj = this.fileImportExportInfoFormGroup.getRawValue();
  // let apiGeneratedObj = _.merge(masterJsonObj, formObj);

  let sheetNameList = this._getAllSheetName();

    const ref = this.dialogService.open(ImportExportManualCodeComponent, {
      header: "Manual Code",
      width: "100%",
      contentStyle: { "margin-top": "0px", "height": "100%" },
      styleClass: "service_full_model excel-demo-view",
      data: { "selectedRowManualMethod" : selectedRowManualMethod, "manualMethodList": this.manualMethodList,
      "sheetNameList":sheetNameList,"type":"EXCEL" ,"apiGeneratedObj":apiGeneratedObj },

    });
    ref.onClose.subscribe((res) => {
      if (res) {
        this.manualMethodList = res;
      }
    });
  }  

_getAllSheetName (){
  let sheetNameList = [ ];
  sheetNameList.push({ "key": "", "val": "--Select--" }); 
 this.excelSheetList.forEach(element => {
   if("multiMixSheet" == element['type']){

  let excelChildSheet=  element['excelChildSheet'];
  if(excelChildSheet){
    excelChildSheet.forEach(child => {
      if(child['sheetHeaderList']!=undefined && child['sheetHeaderList'].length > 0){
        let obj = {
           "key":child['name'],
           "val":child['name']
        }
       sheetNameList.push(obj)
      }
    });
  }

  
   }else{
    if(element['sheetHeaderList']!=undefined && element['sheetHeaderList'].length > 0){
      let obj = {
         "key":element['name'],
         "val":element['name']
      }
     sheetNameList.push(obj)
    }
   }
  
 });

 return sheetNameList;
}







/***********************View****************** */
classLevelApiName = "gstr1";

excelImportExportView(){

  const url = this._router.createUrlTree(['../import-export-view',{"file-type": "excel","api-name":this.classLevelApiName}])
  window.open(url.toString(), '_blank')


}



/******************************************Generate Java Api******************************************************************************** */
dbMappingform: FormGroup;
_rootPackagePath="com.sagipl" 

setApiGeneratedInfo(){
  let backEndProjectName = this.shareService.getDataprotool("selectedProjectChooseData");
  if (backEndProjectName) {
    this.sagStudioService.setSagStudioData("autoGeneretedProjectPath", backEndProjectName.jwspace);
  }
  else {
    alerts("please setPath in workspace Configuration");
    return
  }
  let projectName = backEndProjectName.jwspace.substring(backEndProjectName.jwspace.lastIndexOf("/") + 1, backEndProjectName.jwspace.length);
  this.initializeForm(projectName);
  this.setDefaultValueInDbMappingForm();
}

generateJavaCode(){
if(!this.isGeneratedFileValid){
   this.isCreatedFileValid(false);
   return;
}

 this.generateJavaApi();
}

generateJavaApi() {
    this.classLevelApiName = this.dbMappingform.controls["classLevelApiName"].value;
    let masterJsonObj = this.dbMappingform.getRawValue();
    let formObj = this.fileImportExportInfoFormGroup.getRawValue();
    let jsonObj = _.merge(masterJsonObj, formObj);

   jsonObj['methodName'] = "getSheetData";
   jsonObj['excelSheetList'] = this.excelSheetList;
   jsonObj['excelMasterList'] = this.excelMasterList;
   jsonObj['manualMethodList'] = this.manualMethodList;
   
   let srcDataSource = null;
   let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
   if(dataForConnection && dataForConnection.srcDataSource){
     srcDataSource = dataForConnection.srcDataSource;
   }

   let reqObj = {
     apiCategory: 'excel_import_export', 
     newApiInfoObj: jsonObj,
     apiId: null,
     apijsonId: null,
     oldApiInfoObj: null,
     databaseConfig:srcDataSource
   }

   this.autoJavacodeService.generateJavaNewCode(reqObj).subscribe(res => {
     if (res.status == 200) {
       success(res["msg"]);
       this.validateExcelData(res.excelSheetList); 
       
       let apiInfo = res.generatedJavaApiInfo

       let apiObj = {
         uniqId: `${new Date().getTime()}${1}`,
         baseUrl: 'apiConstant.projectBaseUrl',
         failedMsg: 'error',
         run: false,
         expand: false,
         numberOfReq: 1,
         excutionTime: 0,
         argument: '',
         methodName: '',
         apiType: `${apiInfo.apiType}`,
         request: '',
         response: '',
         successMsg: 'scccessfull fetch',
         url: `${apiInfo.apiName}`,
         fullUrl: '',
         apiList: [],
         expectedReq: ``,
         expectedRes: ``,
         desc: '',
         apiResType: null,
         errorCode: "",
         msg: "",
         apiId:apiInfo.apiId  
       };
     } else if (res.status == 400) {
      alerts(res.msg);
      this.validateExcelData(res.excelSheetList); 
    } else {
      this.displayPopupForRights(true,res);
    }

   }, Error => {
     alerts("Error While Generating");
   })

}




initializeForm(projectName) {
 this.dbMappingform = this.formbuilder.group({
   projectName: [{ value: projectName, disabled: true }, [Validators.required]],
   versionNo: [{ value: "", disabled: true }, [Validators.required]],
   providerName: [{ value: "", disabled: true }, [Validators.required]],

   moduleName: [{ value: '', disabled: false }, [Validators.required]],
   packageName: [{ value: '', disabled: true }, [Validators.required]],
   PageWindowName: [{ value: '', disabled: false }, [Validators.required]],
   controllerName: [{ value: '', disabled: false }, [Validators.required]],
   serviceName: [{ value: '', disabled: false }, [Validators.required]],
   serviceImplName: [{ value: '', disabled: false }, [Validators.required]],
   daoName: [{ value: '', disabled: false }, [Validators.required]],
   daoImplName: [{ value: '', disabled: false }, [Validators.required]],
   classLevelApiName: [{ value: '', disabled: false }, [Validators.required]],
   projectSourcePath: [{ value: this.sagStudioService.getSagStudioData("autoGeneretedProjectPath"), disabled: false }, [Validators.required]],
   userName: [],
   userId: [],
   projectId: [],
   projectname: [],
   userwrokspace: [],
   menuId: [],
   javaApiType: [],
   modelPackage:[],
   entityPackage:[],
   documentation:[],
   apiId:[{ value: null, disabled: false }],
   apijsonId:[{ value: null, disabled: false }],
   controllerMethodList:[{ value: null, disabled: false }],
   repositoryMethodList:[{ value: null, disabled: false }],
   ngsrcfilePath:[{ value: '', disabled: false }],
})
 
}

setDefaultValueInDbMappingForm(){
 let projectName = this.dbMappingform.controls["projectName"].value;
 projectName=this.convertProjectNameToPackageName(projectName);
 
 const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
 if(sessionStoragedatauserId!=undefined){
   this.dbMappingform.controls["userName"].setValue(sessionStoragedatauserId.data.clientInfo.usrName);
   this.dbMappingform.controls["userId"].setValue(sessionStoragedatauserId.data.clientInfo.usrId);
 
 let setProjectInfo= this.shareService.getDataprotool("selectedProjectChooseData");
 if(setProjectInfo!=undefined){
   this.dbMappingform.controls["projectId"].setValue(setProjectInfo.projectId);
   this.dbMappingform.controls["projectname"].setValue(setProjectInfo.projectname);
   this.dbMappingform.controls["userwrokspace"].setValue(setProjectInfo.jwspace);
   let componentNode=  "src/app.gstr1.component.html";
   if(componentNode){
     //let projectPath=componentNode.projectPath;
   //  let uniqePath=projectPath.replace(setProjectInfo.projectname,"");
     //if(uniqePath.startsWith('/')){
     // uniqePath=uniqePath.replace('/',"");
    // }
    this.dbMappingform.controls["ngsrcfilePath"].setValue(componentNode);
   }
 }
 }else{
   alerts("user not found")
 }
 //  let menuId= this.shareService.getDatadbtool("ComponentMenuId");
 //  if(menuId && menuId!=null && menuId!="" ){
 //   this.dbMappingform.controls["menuId"].setValue(menuId);
 //  }else {
 //    alerts("menu not found")
 //  }
  
 let componentName= this.fileImportExportInfoFormGroup.controls['formName'].value;
 let versionNo= this.fileImportExportInfoFormGroup.controls['versionNo'].value;
 this.dbMappingform.controls["versionNo"].setValue(versionNo);
 let providerName= this.fileImportExportInfoFormGroup.controls['providerName'].value;
 this.dbMappingform.controls["providerName"].setValue(providerName);
 
 // let menuName= this.shareService.getDatadbtool("ComponentMenuName");
 // if(menuName!=undefined && menuName!=null && menuName!=""){
 //   let moduleName=this.convertMenuNameToModuleName(menuName);
 //   this.dbMappingform.controls["moduleName"].setValue(moduleName);
 //   this.onModuleNameChange(moduleName);
 // }else{
 //   if(componentName){
 //     this.dbMappingform.controls["moduleName"].setValue(componentName.toLowerCase());
 //     this.onModuleNameChange(componentName.toLowerCase());
 //   }
 // }
 if(componentName){
   this.dbMappingform.controls["moduleName"].setValue(componentName.toLowerCase());
   this.onModuleNameChange(componentName.toLowerCase());
 }

 if(componentName){
  componentName = componentName+""+providerName+versionNo.replace(/[^\w\s]/gi, '_');
   this.dbMappingform.controls["PageWindowName"].setValue(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
   this.onPageChange(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
  
  // this.onPageNameChange(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
 }

}

convertProjectNameToPackageName(projectName){
 projectName=projectName.replace(/\s/g, "").toLowerCase();
 projectName=projectName.replace(/[^\w\s]/gi, '')
 return projectName;
}
convertMenuNameToModuleName(menuName){
  
 menuName=menuName.replace(/\s/g, "").toLowerCase();
 menuName=menuName.replace(/[^\w\s]/gi, '')
 if(menuName == "return"){
   menuName = menuName+"1"
 }

 return menuName;
}

onModuleNameChange(filedName) {
 if(filedName == "return"){
   filedName = filedName+"1"
 }

 if(filedName==""){
   this.dbMappingform.controls["packageName"].setValue("");
     return;
  }
 let projectName = this.dbMappingform.controls["projectName"].value;
 let versionNo= this.fileImportExportInfoFormGroup.controls['versionNo'].value;
 let providerName= this.fileImportExportInfoFormGroup.controls['providerName'].value;
 

 this.dbMappingform.controls["packageName"].setValue(this._rootPackagePath+"." + projectName.toLowerCase() +".import_export"+ "." + filedName.toLowerCase());  
  //+providerName.toLowerCase()+".v"+versionNo.replace(/\./g,"_"));

 let PageWindowName=this.dbMappingform.controls["PageWindowName"].value;
 if(PageWindowName!=""){
  // this.onPageNameChange(PageWindowName);
 }



}

onPageChange(pageName) {

 if (pageName == "") {
   this.dbMappingform.patchValue({
     controllerName: "",
     serviceName: "",
     serviceImplName: "",
     daoName: "",
     daoImplName: "",
     classLevelApiName: "",
   })
 
   return;
 } else if (pageName != null) {
 
   this.dbMappingform.patchValue({
     controllerName: pageName + "Controller",
     serviceName: pageName + "Service",
     serviceImplName: pageName + "ServiceImpl",
     daoName: pageName + "Dao",
     daoImplName: pageName + "DaoImpl",
     classLevelApiName: pageName.toLowerCase(),
    
   })
   
 }
}


/*****************************************Display Configuration******************************************************************/

gridDynamicForDisplayConfiguration:any;

onClickDisplayConfiguration(){
 this.openDisplayConfigurationModal();
 this.excelSheetList.forEach(itm => itm.displayActive = false);

 let item = _.find(this.excelSheetList,{"name":this.sheet['name']}); 
 item['displayActive'] = true;

 if(item){
   this.onClickDisplayConfigurationTab(item,null);
 }
}

onClickDisplayConfigurationTab(item: any, index) {

  if(!item['isChildernSheet']){
    if(item['excelChildSheet']){
      this.childExcelSheetList = item['excelChildSheet'];
    }else{
      this.childExcelSheetList = [];
    }
  }
  if(!item['isChildernSheet']){
    this.excelSheetList.forEach(itm => itm.displayActive = false);
    if(this.childExcelSheetList){
      this.childExcelSheetList.forEach(itm => itm.displayActive = false);
    }
  }else{
    this.childExcelSheetList.forEach(itm => itm.displayActive = false);
  }

 
 item['displayActive'] = true;

 let iscellRefrenceWise = "fix" == item.type  && "cellRefrenceWise" == item.readDataRowCellWise;

 this.displayConfigurationGrid(item['sheetHeaderList'],iscellRefrenceWise); 
}
okDisplayConfigurationModal(){
 this.closeDisplayConfigurationModal();
}

openDisplayConfigurationModal(){
 $('#displayConfigurationModal').modal('show')
}

closeDisplayConfigurationModal(){
  $('#displayConfigurationModal').modal('hide')
}

displayConfigurationGrid(rowsData,iscellRefrenceWise) {
 var sourceDiv = document.getElementById("displayConfigurationGridId");
 let headerNameObj = {
  "header": "Name",
  "field": "name",
  "filter": true,
  "width": "200px",
  "editable": "false",
  "textalign": "center",
  "search": true,
  "component": 'label',
  "cellRenderView": false
}

 if(iscellRefrenceWise){
  headerNameObj = {
    "header": "Cell Desc",
    "field": "cellDesc",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  }
 }

 var columns = [
   {
     "header": "S.No",
     "field": "sno",
     "filter": true,
     "width": "50px",
     "editable": "false",
     "textalign": "center",
     "search": true,
   },
   headerNameObj,

   {
     "header": "Caption",
     "field": "caption",
     "filter": true,
     "width": "200px",
     "editable": "false",
     "textalign": "center",
     "search": true,
     "component": 'text',
     "cellRenderView": false
   },
   {
     "header": "Show Column",
     "field": "isDisplayColumn",
     "filter": true,
     "width": "150px",
     "editable": "false",
     "text-align": "center",
     "search": true,
     "component": 'checkbox',
     "cellRenderView": true
   },
   {
    "header": "Modify Column",
    "field": "isModifyColumn",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "center",
    "search": true,
    "component": 'checkbox',
    "cellRenderView": true,
  },
   {
     "header": "Text Align",
     "field": "textAlign",
     "filter": true,
     "width": "150px",
     "editable": "false",
     "text-align": "center",
     "search": true,
     "component": 'select',
     "cellRenderView": false
   },
 
   {
     "header": "Decimal Format",
     "field": "decimalFormat",
     "filter": true,
     "width": "150px",
     "editable": "false",
     "text-align": "center",
     "search": true,
     "component": 'multiSelect',
     "cellRenderView": true
   },
   {
     "header": "Decimal Digit",
     "field": "decimalDigit",
     "filter": true,
     "width": "150px",
     "editable": "false",
     "text-align": "center",
     "search": true,
     "component": 'text',
     "cellRenderView": false
   },
   // {
   //   "header": "Round Number",
   //   "field": "roundNumber",
   //   "filter": true,
   //   "width": "150px",
   //   "editable": "false",
   //   "text-align": "center",
   //   "search": true,
   //   "component": 'checkbox',
   //   "cellRenderView": true
   // },
   // {
   //   "header": "Round Digit",
   //   "field": "roundDigit",
   //   "filter": true,
   //   "width": "150px",
   //   "editable": "false",
   //   "text-align": "center",
   //   "search": true,
   //   "component": 'checkbox',
   //   "cellRenderView": true
   // },

 ];
 let self = this;
 
 let components = {};
 let numberFormate = [
   { "key": "decimal_format", "val": "Decimal Format" },
   { "key": "round_number", "val": "Round Number" },
  
   
  ];

 let textAlignList = [
   { "key": "", "val": "--Select--" },
   { "key": "left", "val": "LEFT" },
   { "key": "right", "val": "RIGHT" },
   { "key": "center", "val": "CENTER" },
  ];
  let sequenceList = [
   { "key": "", "val": "--Select--" }
  ]
  for (i = 1; i <= 100; i++) {
   let obj = { "key": i+"", "val":i+"" }
   sequenceList.push(obj);
 }

 var SagGridRowStatus = rowsData;
 for (var i = 0; i < SagGridRowStatus.length; i++) {
   SagGridRowStatus[i]["sno"] = i + 1;
 }

 
 if (undefined != sourceDiv) {
   var gridData = {
     columnDef: columns,
     rowDef: SagGridRowStatus,
     menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
     selection: "row",
     frezzManager: { "sno": "left", "name": "left"},
     rowCustomHeight :20,
     cellCustomPadding:5,
     components: components,
     clientSidePagging: true,
     recordPerPage: 20,
     recordNo: true,
     callBack: {},

     dropDownJson_textAlign: textAlignList,
     //dropDownJson_columnSequence: sequenceList,
     multidropDownJson_decimalFormat: numberFormate,

    
     
   };
   this.gridDynamicForDisplayConfiguration = SdmtGridT(sourceDiv, gridData, true, true);
  
   return this.gridDynamicForDisplayConfiguration;
 }
 }


 onChangeSheetColumnType(columnType, rowIndex){
 
  let textAlign = null;
  let decimalFormat = [];
  
  switch (columnType.toLowerCase()) {
    case "string":
        textAlign = "left";
      break;
    case "boolean":
        textAlign = "center";
      break;
    case "date":
        textAlign = "center";
      break;
    case "numeric":
        textAlign = "right";
        decimalFormat =  ["decimal_format"];
       break;
  
    }
    this.gridDynamicForSheetMapping.updateCell(rowIndex, "textAlign", textAlign);
    this.gridDynamicForSheetMapping.updateCell(rowIndex, "decimalFormat", decimalFormat);
     
 }

/***************************************Ellipsis********************************************************* */
 
copyRow(ele,param){
  let rowValue = param.rowValue;
  this.copyPastEllipsisValue = JSON.parse(JSON.stringify(rowValue)); 
}

pasteRowSheetMapping(index){
 let data = this.copyPastEllipsisValue;
  if(data){
    let details = this.sheet['sheetHeaderList'];
    this.isRecursionOff = false;
    this.addRecursionRow(details,index,data);
    this.sagSheetMappingGrid(this.sheet['sheetHeaderList']);
  }
}


addRowEllipsis(index){
  let details = this.sheet['sheetHeaderList'];
  this.isRecursionOff = false;
  this.addRecursionRow(details,index,this.getEmptyObjForAddRow());
 

  this.sagSheetMappingGrid(this.sheet['sheetHeaderList']);
   
}

getEmptyObjForAddRow(){
  let obj = {
    "dataBindFrom":"",
    "name": "",
    "modelFieldName": "",
    "index": "",
    "validation":[],
    "minimumLength":"",
    "maxLength":"",
    "formName":"",
    "field":"",
    "fieldProperties":"",
    "tableName":"",
    "tableField":"",
    "tableProperties":"",
    "isMaster":"",
    "excelMaster":"",
    "tableMaster":"",
    "masterColumnName":"",
  }
return obj;
}



addRecursionRow(details,sag_G_Index,data){
  if(this.isRecursionOff){
    return;
  }
  if(details){
   for (let index = 0; index < details.length; index++) {
    if(this.isRecursionOff){
      break;
    }
     const rowData = details[index];
     if(rowData.sag_G_Index == sag_G_Index){
      details.splice(index+1, 0,data);
      this.autoSetFormula(rowData.sag_G_Index,"add");
      this.isRecursionOff = true;
      break;
    }else{
      this.addRecursionRow(rowData.details,sag_G_Index,data)
    };

   }
  }
}

addExtraMasterField(rowIndex){
  this.openAddMasterExtraColumnModal();
  let selectedRowData = this.gridDynamicForSheetMapping.getSeletedRowData();

  let childMasterExtraFields = selectedRowData.childMasterExtraFields;
  if(childMasterExtraFields){
    this.addMasterExtraColumnGrid(childMasterExtraFields);
    setTimeout(() => {
      this.bindSheetDataForMasterExtraFields();
     
    }, 500);
    
  }else{
    this.addMasterExtraColumnGrid([]);
  }
 
}

bindSheetDataForMasterExtraFields(){
  if(this.gridDynamicAddMasterExtraColumn){
   let gridData = this.gridDynamicAddMasterExtraColumn.getGridData();
   if(gridData){
     gridData.forEach(rowData => {
       if(rowData.tableName && rowData.tableField){
         this.onChangeTableForMasterExtraColumn(rowData.tableName, rowData.sag_G_Index,rowData.tableField);
         this.setTableNameIntoDataBindFromForMaster(rowData.tableName);
       }
     });
   }
  }
}

okMasterExtraColumn(){
  let selectedRowData = this.gridDynamicForSheetMapping.getSeletedRowData();
  let gridData = this.gridDynamicAddMasterExtraColumn.getGridData();
  if(gridData){
    this.gridDynamicForSheetMapping.updateCell(selectedRowData.sag_G_Index, "childMasterExtraFields",gridData);
  }else{
    this.gridDynamicForSheetMapping.updateCell(selectedRowData.sag_G_Index, "childMasterExtraFields",[]);
  }
  

  this.closeAddMasterExtraColumnModal();
 }

openAddMasterExtraColumnModal(){
  $('#addMasterExtraColumnModal').modal('show')
 }
 
 closeAddMasterExtraColumnModal(){
   $('#addMasterExtraColumnModal').modal('hide')
 }

 addMasterExtraColumnGrid(rowsData) {
  var sourceDiv = document.getElementById("addMasterExtraColumnGridId");
  var columns:any = [
    {
      "header": "S.No",
      "field": "sno",
      "filter": true,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
    {
      "header": "Header Name",
      "field": "name",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false,
    },
    {
      "header": "Data Find From",
      "field": "dataFindFrom",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Sheet Column",
      "field": "sheetColumnReference",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Column Type",
      "field": "columnType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Date Format",
      "field": "dateFormat",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Table Name",
      "field": "tableName",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "left",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Table Field",
      "field": "tableField",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Table Properties",
      "field": "tableProperties",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": true
    },
    
    {
      "header": "Unique Constraint",
      "field": "uniqueConstraint",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": 'checkbox',
      "cellRenderView": true
    },
    {
      "header": "Formula/Static Value/Method Calling",
      "field": "formulaStaticValue",
      "filter": true,
      "width": "250px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    },
    
  ];

  let self = this;

  let fieldTypeList = [
    { "key": "", "val": "--Select--" },
    { "key": "STRING", "val": "STRING" },
    { "key": "NUMERIC", "val": "NUMERIC" },
    { "key": "BOOLEAN", "val": "BOOLEAN" },
    { "key": "DATE", "val": "DATE" },

  ];
 
 
 
   let dataFindFrom = [
    { "key": "", "val": "--Select--" },
    { "key": "_sheet", "val": "Sheet" },
    { "key": "client_side", "val": "Client Side" },
    { "key": "by_manual_method", "val": "Manual Method With static" },
    { "key": "static_value", "val": "Static Value" },
   ];


  var SagGridRowStatus = rowsData;
  for (var i = 0; i < SagGridRowStatus.length; i++) {
    SagGridRowStatus[i]["sno"] = i + 1;
    
  }

  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      frezzManager: { "sno": "left", "name": "left","cellDesc":"left","cellRefrence":"left" },
      components: {},
      rowCustomHeight :20,
      cellCustomPadding:5,
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
      callBack: {
        "onChangeSelect_tableName": function (ele, params) {
          let value = ele.value;
          ele.onkeydown = function (event) {
            if (event.keyCode == 13) {
              self.fillTableNameSameValueForMasterExtraColumn(params, value);
              
            }
          }
          self.onChangeTableForMasterExtraColumn(ele.value, params.rowIndex,null);
          this.setTableNameIntoDataBindFromForMaster(ele.value);
        },
        "onChangeSelect_dataFindFrom": function (ele, params) {
         if("_sheet"==ele.value){
          self.gridDynamicAddMasterExtraColumn.enableCell(params.rowIndex, "sheetColumnReference");
         
         }else{
          self.gridDynamicAddMasterExtraColumn.disableCell(params.rowIndex, "sheetColumnReference");
          self.gridDynamicAddMasterExtraColumn.updateCell(params.rowIndex, "sheetColumnReference","");
         }
        },
        "onChangeSelect_tableField": function (ele, params) {
          self.onChangeTableFieldForMasterExtraFields(ele.value, params)
        },
       
      },
   
      dropDownJson_columnType: fieldTypeList,
      dropDownJson_tableName: this.tableListDropdownList,
      dropDownJson_tableField: [{ "key": "", "val": "--Select--" }],
      dropDownJson_dataFindFrom: dataFindFrom, 
      dropDownJson_sheetColumnReference: this._getSheetColumnRefernce(), 
      dropDownJson_dateFormat:this.dateFormateList,
    };
  

    this.gridDynamicAddMasterExtraColumn = SdmtGridT(sourceDiv, gridData, true, true);
  
    this.disableSheetColumnRef();
    return this.gridDynamicAddMasterExtraColumn;
  }
}

async fillTableNameSameValueForMasterExtraColumn(params, tableName){
  if (await ui.confirm('Do You Want To Fill Same Value In Next Remainig Row ?')) {
   let gridsize = this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length;
   for (let i = params.rowIndex; i < gridsize; i++) {
     this.gridDynamicAddMasterExtraColumn.updateCell(i, "tableName", tableName);
     this.onChangeTableForMasterExtraColumn(tableName, i,null);
     this.setTableNameIntoDataBindFromForMaster(tableName);
    
   }
  }
 }

disableSheetColumnRef(){
  let gridData =  this.gridDynamicAddMasterExtraColumn.getGridData();
  if(gridData){
    gridData.forEach(element => {
      if("_sheet"==element.dataFindFrom){
        this.gridDynamicAddMasterExtraColumn.enableCell(element.sag_G_Index, "sheetColumnReference");
       }else{
        this.gridDynamicAddMasterExtraColumn.disableCell(element.sag_G_Index, "sheetColumnReference");
        this.gridDynamicAddMasterExtraColumn.updateCell(element.sag_G_Index, "sheetColumnReference","");
       }
    });
  }
 

}

_getSheetColumnRefernce(){

  let sheetColumnDrodown = [{ "key": "", "val": "--Select--" }];

let selectedRowData =  this.gridDynamicForSheetMapping.getSeletedRowData();
let rowIndex = selectedRowData.sag_G_Index;

let gridData =  this.gridDynamicForSheetMapping.getGridData();

  if (gridData) {
    gridData.forEach(element => {
      if (element.sag_G_Index <= rowIndex || "client_side" == element.dataFindFrom) {
        let obj = {
          "key": element.name,
          "val": element.name
        }

        sheetColumnDrodown.push(obj);
      }
    });
  }
return sheetColumnDrodown;

}


onChangeTableForMasterExtraColumn(tableName, rowIndex,tableFieldBind) {
  if (tableName) {

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
      "dbtype": "master",
      "tableName": tableName
    }
    this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
      if (res) {
        this.setTableFieldDropdownForMasterExtraColumn(res, rowIndex,tableFieldBind,tableName);
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }

}

setTableFieldDropdownForMasterExtraColumn(res, rowIndex,tableFieldBind,tableName) {
  this.tableFieldDropdownList = [{ "key": "", "val": "--Select--" }];;

  let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);
 
  tableFieldsInfo.forEach(tableColumn => {
    let obj = {
      "key": tableColumn['columnName'],
      "val": tableColumn['columnName']
    }
   this.tableFieldDropdownList.push(obj);
  });
  this.tableFieldsMap.set(tableName, tableFieldsInfo);

  if (this.gridDynamicAddMasterExtraColumn && this.gridDynamicAddMasterExtraColumn.sagGridObj.components['tableField']) {
    this.gridDynamicAddMasterExtraColumn.sagGridObj.components['tableField'].setOptionRow(this.tableFieldDropdownList, "tableField", rowIndex);
    if(tableFieldBind){ 
     this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableField", tableFieldBind);

     let tableFieldsList = this.tableFieldsMap.get(tableName);
     let item = _.find(tableFieldsList, { "columnName": tableFieldBind });
     if (item) {
     
       this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
       this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", item.dataType);
     }

     let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
     if(pkObj){
      this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKey", pkObj.columnName);
      this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
     }

    }
  }
}

onChangeTableFieldForMasterExtraFields(tableField, params) {
  let rowIndex = params.rowIndex;
  if (tableField) {
    let tableName = params.rowValue.tableName;
  
    let tableFieldsList = this.tableFieldsMap.get(tableName);
    let item = _.find(tableFieldsList, { "columnName": tableField });
    if (item) {
      
      this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
      this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", item.dataType);
   }
    let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
    if(pkObj){
     this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKey", pkObj.columnName);
     this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
    }

  }else{
    this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties", '');
    this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", );
  }
}

addRowMasterExtraColumn(){

  let selectedRowData = this.gridDynamicForSheetMapping.getSeletedRowData();
  let tableMaster = selectedRowData.tableMaster

  let index = this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length;
  let obj = {
        "dataBindFrom":"",
        "name": "",
				"modelFieldName": "",
				"index": "",
				"tableName":tableMaster,
				"tableField":"",
				"tableProperties":"",
			
   }

   this.gridDynamicAddMasterExtraColumn.addRowByIndex(index, obj);
   setTimeout(() => {
    this.onChangeTableForMasterExtraColumn(tableMaster, index,null);
    this.setTableNameIntoDataBindFromForMaster(tableMaster);
   }, 500);
   
}

deleteRowMasterExtraColumn(){
  let selectedRowData = this.gridDynamicAddMasterExtraColumn.getSeletedRowData();
  if(selectedRowData){
    this.gridDynamicAddMasterExtraColumn.deleteRow(selectedRowData.sag_G_Index);
    if (this.gridDynamicAddMasterExtraColumn.sagGridObj
      && this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length == 0) {
      this.addMasterExtraColumnGrid([]); 
}
  }

}

setTableNameIntoDataBindFromForMaster(tableName){

  // let dataFindFrom = [
  //   { "key": "", "val": "--Select--" },
  //   { "key": "_sheet", "val": "Sheet" },
  //   { "key": "client_side", "val": "Client Side" },
  //   { "key": "by_manual_method", "val": "Manual Method With static" },
  //   { "key": "static_value", "val": "Static Value" },
  //  ];

  // let gridData = this.gridDynamicAddMasterExtraColumn.getGridData();
  // let tableList = _.map(gridData, 'tableName');
  // tableList.push(tableName);
  // tableList = _.uniq(tableList);


  // if(tableList){
  //   tableList.forEach(element => {
  //     if(element){
  //       dataFindFrom.push({
  //         "key": "pk_of_"+element, "val": "Pk of "+element
  //       });
  //     }
      
  //   });
  // }
  // if(this.gridDynamicAddMasterExtraColumn && this.gridDynamicAddMasterExtraColumn.sagGridObj.components['dataFindFrom']){
  //   this.gridDynamicAddMasterExtraColumn.sagGridObj.components['dataFindFrom'].setOption(dataFindFrom);
  // }
 
}


  validateExcelData(excelSheetList) {
    this.excelSheetList = excelSheetList;

    let item = _.find(this.excelSheetList, { active: true });
    if (item) {
      setTimeout(() => {
        this.onClickSheet(item, 1);
      }, 100);
    }

  }

  setValidationRowProperty(rowsData) {

    for (let i = 0; i < rowsData.length; i++) {
      const element = rowsData[i];
      if (element.isInvalid) {
        let colorProperty = { "background-color": "rgb(255, 204, 203)" }
        this.gridDynamicForSheetMapping.setRowProperty(element.sag_G_Index, colorProperty);
        let errorResponse = element['toolTipMsg'];
        for (let key in errorResponse) {
          if (errorResponse.hasOwnProperty(key)) {
            let value = errorResponse[key];
            let cellColorProperty = { "background-color": "#dc3545" }
            this.gridDynamicForSheetMapping.setColRowProperty(element.sag_G_Index, key, cellColorProperty);
          }
        }
      }
      if (element.details) {
        this.setValidationRowProperty(element.details);
      }
    }

  }

  /**************************************Validation*********************************************************** */

  onClickValidation(params) {

    let index = params.rowIndex

    if (params.rowValue.columnType) {

      let columnType = params.rowValue.columnType;
      let validation = params.rowValue.validation

      const ref = this.dialogService.open(ImportExportValidationComponent, {
        header: "Validation",
        width: "100%",
        contentStyle: { "margin-top": "0px", "height": "100%" },
        styleClass: "service_full_model excel-demo-view",
        data: { "columnType": columnType, "validation": validation },

      });
      ref.onClose.subscribe((res) => {
        if (res) {
          this.gridDynamicForSheetMapping.updateCell(index, "validation", res);
        }
      });
    } else{
     alerts("Please select first column type");
    }
  }

 /**************************************Auto set Formula*********************************************************** */


  autoSetFormula(rowIndex,opName:String){ 
  let  gridData =  this.sheet['sheetHeaderList'];
   for (let index = rowIndex; index < gridData.length; index++) {
     const element = gridData[index];
     if("Formula" == element.dataFindFrom){
      let formulaStaticValue = element.formulaStaticValue;
      if(formulaStaticValue){
        let replaceValue =  this._getCalculateValueBodyForDisplay(this.sheet['sheetHeaderList'],formulaStaticValue,rowIndex,opName)
        gridData[index]["formulaStaticValue"] = replaceValue;
      }
     }

     if("by_manual_method_with_aliase" == element.dataFindFrom){
      let formulaStaticValue = element.formulaStaticValue;
      if(formulaStaticValue){
        const argument = formulaStaticValue.substring(formulaStaticValue.indexOf("(") + 1, formulaStaticValue.indexOf(")"));
        let replaceArgument =  this._getCalculateValueBodyForDisplay(this.sheet['sheetHeaderList'],argument,rowIndex,opName);
        const methodName = formulaStaticValue.substring(0, formulaStaticValue.indexOf("("));
        const changeMethod = `${methodName}(${replaceArgument})`;
        gridData[index]["formulaStaticValue"] = changeMethod;
      }
     }

    }
  }


  _getCalculateValueBodyForDisplay(sheetHeaderList, formulaStaticValue,rowIndex,opName:String) {
    let split = formulaStaticValue.split(/[^\w\s]/gi);
  
    let list = split.slice();

    list  = _.map(list,_.trim)

    list.sort((a, b) => b.length - a.length);
  
    let number = 0;
    for (let value of list) {
      if (this.isValidFormulaAliase(formulaStaticValue, value)) {
        let findAny = sheetHeaderList.find(ele => value === ele.headerAlias);
        if (findAny) {
          if(rowIndex < findAny.sag_G_Index){
            number++;
            formulaStaticValue = formulaStaticValue.replace(value, `%${number}$s`);
          }
         
        }
      }
    }
  
    let replaceNumber = 0;
    for (let value of list) {
      if (this.isValidFormulaAliase(formulaStaticValue, value)) {
        let findAny = sheetHeaderList.find(ele => value === ele.headerAlias);
        if (findAny) {
          if(rowIndex < findAny.sag_G_Index){
          replaceNumber++;
         let replaceIndex = findAny.sag_G_Index + 2;
          if("delete" == opName){
            replaceIndex = findAny.sag_G_Index - 1
          } 

          let replaceValue = this.sheetHeaderAlias[replaceIndex];
          formulaStaticValue = formulaStaticValue.replace(`%${replaceNumber}$s`, replaceValue);
          }
        }
      }
    }
    return formulaStaticValue;
  }
  
   isValidFormulaAliase(formula, value) {
    let isValid = this.isAlphabet(value);
    if (isValid) {
      if (formula.includes(`'${value}'`) || formula.includes(`"${value}"'`) || value.trim() === "null") {
        return false;
      }
    }
    return isValid;
  }
  
   isAlphabet(value) {
    return /^[a-zA-Z]+$/.test(value);
  }
  
   checkHeaderAliaseUsage(rowIndex){
    let selectedRowData = this.gridDynamicForSheetMapping.getSeletedRowData();
    let selectedRowHeaderAlias = selectedRowData.headerAlias;

    let useAliaseList = new Map(); 
    let  gridData =  this.sheet['sheetHeaderList'];

    for (let index = rowIndex; index < gridData.length; index++) {
    const element = gridData[index];
    if("Formula" == element.dataFindFrom){
     let formulaStaticValue = element.formulaStaticValue;
     if(formulaStaticValue){
       let split = formulaStaticValue.split(/[^\w\s]/gi);
       let list = split.slice();
       list  = _.map(list,_.trim)
       if(list){
         list.forEach(al => {
           useAliaseList.set(al, element['name']); 
         });
      }
     }
    }

    if("by_manual_method_with_aliase" == element.dataFindFrom){
     let formulaStaticValue = element.formulaStaticValue;
     if(formulaStaticValue){
       const argument = formulaStaticValue.substring(formulaStaticValue.indexOf("(") + 1, formulaStaticValue.indexOf(")"));
      
       let split = argument.split(/[^\w\s]/gi);
       let list = split.slice();
       list  = _.map(list,_.trim)
       if(list){
         list.forEach(al => {
           useAliaseList.set(al, element['name']);
         });
      }
     }
    }

   }

 let aliaseUsageHeader =   useAliaseList.get(selectedRowHeaderAlias);



 return aliaseUsageHeader;

  }

 
 /********************* Context Menu ***************************************** */
 
  @ViewChild("editSheetTabName", { static: false }) editSheetTabName: ElementRef;
  displayContextMenu(event, item) {
    if (this.sheet.name != item.name) {
      this.onClickSheet(item, 1);
    }
    let self = this;
    event.preventDefault();

    let synonymList = [];

    if (this.sheet['synonymList'] && this.sheet['synonymList'].length > 0) {
      synonymList = this.sheet['synonymList'];
    } else {
      synonymList = []
      this.sheet['synonymList'] =[]; 
    };


    let submenu = [
       new ContextualItem({ label: 'Add New', cssIcon: "fa fa-plus" ,onClick: () => { self.addSynonymList() }})
    ]

    for (let index = 0; index < synonymList.length; index++) {
      const element = synonymList[index];
      submenu.push(new ContextualItem({
        label: element.name,
        submenu: [
          new ContextualItem({ label: 'Modify', cssIcon: "fa fa-edit" ,onClick: () => { self.modifySynonymList(element.name,index) }}),
          new ContextualItem({ label: 'Delete', cssIcon: "fa fa-trash",onClick: () => { self.deleteSynonymList(index) } }),
        ]
      })
      )
    }
    

    new Contextual({
      isSticky: false,
      items: [
        new ContextualItem({ label: 'Rename', onClick: () => { self.renameSheetName() } }),
        new ContextualItem({
          label: 'Synonym', "submenu": submenu
        }),
      ]
    });

  }

  deleteSynonymList(index){
   this.sheet['synonymList'].splice(index, 1);
  }
  modifySynonymList(name,index){
    this.openCloseSynonymModal();
    this.synonymIndex = index;
    this.synonymName = name;
  }

  addSynonymList(){
    this.synonymName = "";
    this.synonymIndex = null;
    this.openCloseSynonymModal();
  }

  synonymName:"";
  synonymIndex :0;
  okSynonym(){

    let obj={
      "name":this.synonymName,
    }

    if(this.synonymIndex!=undefined && this.synonymIndex!=null){
      this.sheet['synonymList'].splice(this.synonymIndex, 1, obj);
    } else {
      this.sheet['synonymList'].push(obj);
    }

    this.closeSynonymModal();
    this.synonymIndex = null;
    this.synonymName = "";
   
  }

  openCloseSynonymModal(){
    $('#addSynonymModal').modal('show')
   }
  
   closeSynonymModal(){
     $('#addSynonymModal').modal('hide')
     this.synonymIndex = null;
      this.synonymName = "";
   }


 @HostListener('document:click', ['$event', '$event.target'])
  public onClick(event: MouseEvent, targetElement: HTMLElement): void {
      if (!targetElement) {
          return;
      }
      
      if(this.editSheetTabName){
        const clickSheetTabName = this.editSheetTabName.nativeElement.contains(targetElement);
        if (!clickSheetTabName) {
           this.sheet['isRename'] = false;
        }
      }
      if(this.editMasterTabName){
        const clickMasterTabName = this.editMasterTabName.nativeElement.contains(targetElement);
        if (!clickMasterTabName) {
           this.excelMasterInfo['isRename'] = false;
        }
      }

     
  }

  renameSheetName(){
    this.sheet['isRename'] = true;
  }

  @ViewChild("editMasterTabName", { static: false }) editMasterTabName: ElementRef;
  displayContextMenuForMaster(event,item){
    if(this.excelMasterInfo['name'] != item.name){
      this.onClickMasterHeader(item, 1);
    }
    let self = this;
    event.preventDefault();
    new Contextual({
      isSticky: false,
      items: [
        new ContextualItem({ cssIcon:"fa fa-edit", label: 'Rename', onClick: () => { self.renameMasterName() } }),
        new ContextualItem({ cssIcon:"fa fa-plus", label: 'Add Master', onClick: () => { self.addMasterName() } }),
        new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Master', onClick: () => { self.deleteMasterName() } }),
      ]
    });

  }

 
  renameMasterName(){
    this.excelMasterInfo['isRename'] = true;
  }
 

  /*******************************User Rights ******************************************************** */
  
  gridDynamicapiAlreadyAssign:any
  isAccessToCreateNewPackageGridColmn = [
    {
      header: "Sr.No",
      field: "sno",
      "editable": false,
      width: "50px",
      "align": "center",
      "ng-dblclick": "dblClickSection()"
    },
    {
      header: "Package Name",
      field: "packageName",
      filter: true,
      width: "300px",
      "editable": false,
      "text-align": "left",
      search: true,
      "ng-dblclick": "dblClickSection()"
    },
    {
      header: "Package Path",
      field: "packagePath",
      filter: true,
      width: "300px",
      "editable": false,
      "text-align": "left",
      search: true,
      "ng-dblclick": "dblClickSection()",
    },
    
  ];
  isCreateFileToAnotherUserGridColmn = [
    {
      header: "Sr.No",
      field: "sno",
      "editable": false,
      width: "50px",
      "align": "center",
      "ng-dblclick": "dblClickSection()"
    },
    {
      header: "File Name",
      field: "srcFilePath",
      filter: true,
      width: "500px",
      "editable": false,
      "text-align": "left",
      search: true,
      "ng-dblclick": "dblClickSection()"
    },
    {
      header: "User Name",
      field: "userName",
      filter: true,
      width: "168px",
      "editable": false,
      "text-align": "left",
      search: true,
      "ng-dblclick": "dblClickSection()",
    },
    
  ];
  isAccessToCreateNewFileGridColmn = [
    {
      header: "Sr.No",
      field: "sno",
      "editable": false,
      width: "50px",
      "align": "center",
      "ng-dblclick": "dblClickSection()"
    },
    {
      header: "Package Name",
      field: "packageName",
      filter: true,
      width: "400px",
      "editable": false,
      "text-align": "left",
      search: true,
      "ng-dblclick": "dblClickSection()"
    }
   
    
  ];
  isAccessToCreateNewApiColmn = [
    {
      header: "Sr.No",
      field: "sno",
      "editable": false,
      width: "50px",
      "align": "center",
      "ng-dblclick": "dblClickSection()"
    },
    {
      header: "File Name",
      field: "fileName",
      filter: true,
      width: "500px",
      "editable": false,
      "text-align": "left",
      search: true,
      "ng-dblclick": "dblClickSection()"
    }
    
  ];

  isAccessToModifyApiColumn = [
    {
      header: "Sr.No",
      field: "sno",
      "editable": false,
      width: "50px",
      "align": "center",
      "ng-dblclick": "dblClickSection()"
    },
    {
      header: "File Path",
      field: "srcfileUniqePath",
      filter: true,
      width: "600px",
      "editable": false,
      "text-align": "left",
      search: true,
      "ng-dblclick": "dblClickSection()"
    }
    
  ];
  
  accessRightErrorMsg=""

  isUserValid = false;

  displayPopupForRights(flag,res) {
    if (res.isValid) {
      this.isUserValid = true;
    } else {
      this.isUserValid = false;
      if(flag){
        if(res.status == 401){
          this.accessRightErrorMsg = res.msg;
          $("#apiAlreadyAssignId").modal('show');
          this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewPackageGridColmn);
        } else  if(res.status == 402){
          this.accessRightErrorMsg = res.msg;
          $("#apiAlreadyAssignId").modal('show');
          this.apiAlreadyAssignGrid(res.data,this.isAccessToModifyApiColumn);
        } else  if(res.status == 403){
          this.accessRightErrorMsg = res.msg;
          $("#apiAlreadyAssignId").modal('show');
          this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewFileGridColmn);
        }else if(res.status == 404){
          this.accessRightErrorMsg = res.msg;
          $("#apiAlreadyAssignId").modal('show');
          this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewApiColmn);
        } else{
         alerts(res.msg)
        }
       }
     
    }
  }

  
apiAlreadyAssignGrid(rowsData,columns) {
  const sourceDiv = document.getElementById("apiAlreadyAssignIdGrid");
  
  var self = this;

  let SagGridRowStatus = rowsData;
  for (let i = 0; i < SagGridRowStatus.length; i++) {
    SagGridRowStatus[i]["sno"] = i + 1;
  }

  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      components: {},
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
     
    };
    this.gridDynamicapiAlreadyAssign = SagGridMPT(sourceDiv, gridData, true, true);
    this.setColorOnGrid1();
  }
}

setColorOnGrid1() {
  let self = this;
  let gridRowsData = self.gridDynamicapiAlreadyAssign.sagGridObj.originalRowData;
  gridRowsData.forEach((ele, index) => {
    // change Row Color
    if (ele.apiName || ele.apiType || ele.assignTo || ele.assignBy) {
      self.gridDynamicapiAlreadyAssign.setColRowProperty(index, 'srcFilePath', { "background": "#fff8e1" });
      self.gridDynamicapiAlreadyAssign.setColRowProperty(index, 'userName', { "background": "#f8d7da" });
    }
  });

}


isGeneratedFileValid:boolean = false;
isCreatedFileValid(flag) {
  let masterJsonObj = this.dbMappingform.getRawValue();
  let formObj = this.fileImportExportInfoFormGroup.getRawValue();
  let jsonObj = _.merge(masterJsonObj, formObj);

    this.autoJavacodeService.isCreatedFileValid(jsonObj,"excel_import_export").subscribe(res => {
      this.isGeneratedFileValid = res.isValid;
    if (!res.isValid) {
      alerts(res.msg)
    } 
  }, Error => {
    alerts("Error While validate generated file");
  });
  
}

/*****************TABLE FIELD WITH CUSTOM KEY ************************** */
getTableInfoWithCustomKeys(res, tableName) {
  let tableFields = [];

  if (res) {
    res.forEach(tableColumn => {
      let tableFieldInfo = {};
      tableFieldInfo['columnName'] = tableColumn['name'];
      tableFieldInfo['pkey'] = tableColumn['pkey'];
      tableFieldInfo['fkey'] = tableColumn['fkey'];
      tableFieldInfo['dataType'] = tableColumn['type'];
      tableFieldInfo['entityColumn'] = tableColumn['entitylabel'];
      tableFieldInfo['tableName'] = tableName;

      tableFieldInfo['parentTable'] = tableColumn['parenttbl'];
      tableFieldInfo['dbColumnSize'] = tableColumn['size'];
      tableFieldInfo['uniquecol'] = tableColumn['uniquecol'];
      tableFieldInfo['entityName'] = tableColumn['entityName'];
      tableFieldInfo['pkeyName'] = tableColumn['pkeyName'];

      tableFields.push(tableFieldInfo);
    });
  }
  return tableFields;
}

getTableProperties(item):String{
  if(item){
    return item.dataType+"("+item.dbColumnSize+")";
  }
 return ""
}

}



