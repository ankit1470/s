import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef, DialogService } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { WriteNgFilesService } from 'src/app/services/writeStudio/write-ng-files.service';
import { forkJoin } from 'rxjs';
import { ToastService } from 'src/app/core/services/toast.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';

declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var SagGridMPT;
declare var $: any;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;

@Component({
  selector: 'app-save-all-file',
  templateUrl: './save-all-file.component.html',
  styleUrls: ['./save-all-file.component.scss'],
  providers: [DialogService]

})
export class SaveAllFileComponent implements OnInit {
  saveAllFileData = {
    columns: [
      {
        field: "checkbox",
        filter: false,
        width: "50px",
        "editable": false,
        search: false,
        "text-align": "center",
        "colType": "checkBox"
      },
      {
        "header": "Sr.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",
      },
      {
        "header": "matchableId",
        "field": "matchableId",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",
        "hidden": true
      },
      {
        "header": "File Name",
        "field": "fName",
        "filter": true,
        "width": "400px",
        "editable": "false",
        "text-align": "left",
        "search": true,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",

      },
      {
        "header": "Path",
        "field": "path",
        "filter": true,
        "width": "500px",
        "editable": "false",
        "text-align": "left",
        "search": true,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",
      },
      {
        "header": "projectSubtype",
        "field": "projectSubtype",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",
        "hidden": true
      },
    ],
    rows: [

    ],
    gridData: {},
    gridDynamicObj: null,
  }

  constructor(
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public procomparetoolService: ProcomparetoolService,
    public sagStudioService: SagStudioService,
    private _writeNgFile: WriteNgFilesService,
    public toast: ToastService,
    public commonDragDropService:CommonStudioDragDropService 
  ) { }

  ngOnInit() {
    this.showFilesInGrid();
  }



  showFilesInGrid() {
    let self = this;
    self.saveAllFileData.gridData = {
      columnDef: self.saveAllFileData.columns,
      rowDef: self.sagStudioService.unSavedFileList,
      totalNoOfRecord_hide: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      dragDropCol_hide: true,
    };
    let sourceDiv = document.getElementById("allSaveFileGrid");
    self.saveAllFileData.gridDynamicObj = SagGridMPT(sourceDiv, self.saveAllFileData.gridData, true, true);
  }

  closeModal(flag) {
    this.modalRef.close(flag);
  }
//Need to remove after check


  // async saveAll() {
  //   // const allRows = this.sagStudioService.unSavedFileList;
    
  //   this.saveUnSaveMethod();
  //   this.modalRef.close(false);
  // }

  // async saveUnSaveMethod(){
  //   const allRows = this.sagStudioService.unSavedFileList;
  //   let forkJoinArray = [];
  //   if (allRows.length > 0) {
  //     this.shareService.loading++;
  //     for (let i = 0; i < allRows.length; i++) {
  //       const obj = allRows[i];
  //       let projectSagJson = this.sagStudioService.sagWorkSpace.projectList
  //         .find(item => item.id == this.sagStudioService.sagWorkSpace.currentActiveProjectId);
  //       let completeJsonWithContainer = projectSagJson.subDataArray.find(item => item.matchableId == obj.matchableId);
  //       const allServiceList = projectSagJson.serviceList || [];
  //       const filecontent = await this._writeNgFile.genJsonToCodeByProjSubtype(obj.projectSubtype, completeJsonWithContainer, allServiceList);
  //       forkJoinArray.push(this.shareService.writeFile(obj.path, new Blob([filecontent], { type: "application/html" })));
  //     }

  //     forkJoin(forkJoinArray).subscribe((res) => {
  //       let resStatusArr = res.filter(itm => itm.status == 200);
  //       if (res.length == resStatusArr.length) {
  //         this.shareService.loading--;
  //         this.sagStudioService.writeStudioJsonInProject();
  //         let ids = allRows.map((ele) => ele.matchableId);
  //         this.sagStudioService.unSavedFileList = this.sagStudioService.unSavedFileList.filter((itm) => !ids.includes(itm.matchableId));
  //        this._writeNgFile.multiLangWrite("write",this.sagStudioService.projectConfig);
  //         this.showFilesInGrid();
  //         this.toast.launch_toast({
  //           type: 'success',
  //           position: 'bottom-right',
  //           message: 'Files Saved Successfully!!!...',
  //         });
  //       }
  //       else {
  //         this.shareService.loading--;
  //         this.toast.launch_toast({
  //           type: 'alert',
  //           position: 'bottom-right',
  //           message: 'Something Went Wrong',
  //         });
  //       }
  //     });
  //   }
  // }

  // async saveSelected(){
  //   let checkedFiles = this.saveAllFileData.gridDynamicObj.getCheckedDataParticularColumnWise();
  //   let forkJoinArray = [];
  //   if (checkedFiles.length > 0) {
  //     this.shareService.loading++;
  //     for (let i = 0; i < checkedFiles.length; i++) {
  //       const obj = checkedFiles[i];
  //       let projectSagJson = this.sagStudioService.sagWorkSpace.projectList
  //         .find(item => item.id == this.sagStudioService.sagWorkSpace.currentActiveProjectId);
  //       let completeJsonWithContainer = projectSagJson.subDataArray.find(item => item.matchableId == obj.matchableId);
  //       const allServiceList = projectSagJson.serviceList || [];
  //       const filecontent = await this._writeNgFile.genJsonToCodeByProjSubtype(obj.projectSubtype, completeJsonWithContainer, allServiceList);
  //       forkJoinArray.push(this.shareService.writeFile(obj.path, new Blob([filecontent], { type: "application/html" })));
  //     }

  //     forkJoin(forkJoinArray).subscribe((res) => {
  //       let resStatusArr = res.filter(itm => itm.status == 200);
  //       if (res.length == resStatusArr.length) {
  //         this.shareService.loading--;
  //         this.sagStudioService.writeStudioJsonInProject();
  //         let ids = checkedFiles.map((ele) => ele.matchableId);
  //         this.sagStudioService.unSavedFileList = this.sagStudioService.unSavedFileList.filter((itm) => !ids.includes(itm.matchableId));
  //        this._writeNgFile.multiLangWrite("write",this.sagStudioService.projectConfig);
  //         this.showFilesInGrid();
  //         this.toast.launch_toast({
  //           type: 'success',
  //           position: 'bottom-right',
  //           message: 'Files Saved Successfully!!!...',
  //         });
  //       }
  //       else {
  //         this.shareService.loading--;
  //         this.toast.launch_toast({
  //           type: 'alert',
  //           position: 'bottom-right',
  //           message: 'Something Went Wrong',
  //         });
  //       }
  //     });
  //   }
  // }
  
 async saveModified(type){
    switch (type) {
      case 'saveAll': {
        const allRows = this.sagStudioService.unSavedFileList;
         await this._writeNgFile.saveUnSaveMethod(allRows); 
          this.closeModal(true);
        break;
      }
      case 'saveSelected': {
        let checkedFiles = this.saveAllFileData.gridDynamicObj.getCheckedDataParticularColumnWise();
        await this._writeNgFile.saveUnSaveMethod(checkedFiles);
         this.showFilesInGrid();
         this.closeModal(true);
        break;
      }
         
      default:
        break;
    }
  }

}
