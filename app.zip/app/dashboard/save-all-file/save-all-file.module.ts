import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SaveAllFileRoutingModule } from './save-all-file-routing.module';
import { SaveAllFileComponent } from './save-all-file.component';


@NgModule({
  declarations: [SaveAllFileComponent],
  imports: [
    CommonModule,
    SaveAllFileRoutingModule
  ],
  exports:[SaveAllFileComponent]
})
export class SaveAllFileModule { }
