import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SaveAllFileComponent } from './save-all-file.component';


const routes: Routes = [{
  path : "",
  component : SaveAllFileComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SaveAllFileRoutingModule { }
