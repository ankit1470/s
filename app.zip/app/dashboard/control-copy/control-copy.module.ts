import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ControlCopyRoutingModule } from './control-copy-routing.module';
import { ControlCopyComponent } from './control-copy.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TemplatePagesModule } from 'src/app/dashboard/sdmtTools/template-pages/template-pages.module';


@NgModule({
  declarations: [ControlCopyComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    ControlCopyRoutingModule,
    TemplatePagesModule
  ],
  exports:[ControlCopyComponent]
})
export class ControlCopyModule { }
