import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { DialogService, DynamicDialogRef } from 'primeng/primeng';
import { ToastService } from 'src/app/core/services/toast.service';
import { DbcomparetoolFirststepService } from 'src/app/services/database/dbcomparetool-firststep.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { TemplatePagesComponent } from '../sdmtTools/template-pages/template-pages.component';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
declare function alerts(m: any): any;
declare function success(m: any): any;
@Component({
  selector: 'app-control-copy',
  templateUrl: './control-copy.component.html',
  styleUrls: ['./control-copy.component.scss']
})
export class ControlCopyComponent implements OnInit {

  sourForm: any;
  targForm: any;
  TemplatePagesData: any;

  constructor(
    private shareService: SagShareService,
    public _router: Router,
    private formbuilder: FormBuilder,
    public toast: ToastService,
    public dialogService: DialogService,
    public modalRef: DynamicDialogRef,
    public firststepDbcompareService: DbcomparetoolFirststepService,
    private dbcomparetoolService: ProcomparetoolService,
    private _shareService: SagShareService
  ) { }

  ngOnInit() {
    this.sourForm = this.formbuilder.group({
      vendor: ['MySQL'],
      hostName: ['192.168.0.170'],
      portNumber: ['3306'],
      userName: ['root'],
      password: ['Matrix@123'],
      databaseName: ['svn_db_all_3005'],

    });
    this.targForm = this.formbuilder.group({
      vendor: ['MySQL'],
      hostName: ['192.168.0.170'],
      portNumber: ['3306'],
      userName: ['root'],
      password: ['root'],
      databaseName: [''],
    });

  }


  testConnection() {
    const finalDataForConnection = {
      "srcDataSource": this.sourForm.value,
      "targetDataSource": this.targForm.value,
      "operation": "TEST",
      "connectionRoleType": 'admin'
    }
    this.firststepDbcompareService.testConnectionByPost(finalDataForConnection).subscribe((res) => {
      if (res['src'] == true) {
        let projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
        if (projectInfo) {
          let setConn = {
            "projectPath": projectInfo ? projectInfo.awspace + `/prjconn.json` : "",
            "confobj": JSON.parse(JSON.stringify(finalDataForConnection)),
          }
          this.setDbConnnectionObj(setConn);
        }

        finalDataForConnection['operation'] = 'COMPARESINGLE';
        finalDataForConnection['targetDataSource'] = {};
        finalDataForConnection['details'] = {
          software: [],
          year: [],
          client: [],
          columns: [],
          operation: ['']
        }
        this.shareService.setDatadbtool('finalDataForConnection', finalDataForConnection);


      }

      else {
        alerts('Test Connection : Fail !!!...');
      }
    })
  }
  async setDbConnnectionObj(data) {
    await this.shareService.savePrjConfObject(data).subscribe((res) => {
      if (res['status'] == 'success') {
        success('Test Connection : Success !!!...');
      }
    });
  }
  private dynamicDialogRef: DynamicDialogRef[] = [];
  // close previous open dialogs while opening another dialogs.
  private closePreviousDialog() {
    for (const dialogRef of this.dynamicDialogRef) {
      dialogRef.close();
    }
    this.dynamicDialogRef = [];
  }

  moduleData() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(TemplatePagesComponent, {
      header: "Templates",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.TemplatePagesData = res;
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }

  save() {
    let data = this.TemplatePagesData
    const finalData = {
      "srcDataSource": this.sourForm.value,
      "targetDataSource": this.targForm.value,
      "operation": "TEST",
      "connectionRoleType": 'admin',
      "pageTemplateId": parseInt(this.TemplatePagesData.pTmId),
      "toolName": this.TemplatePagesData.pmLabel,
      "pageCodeId": parseInt(this.TemplatePagesData.pageCodeId),
      "pageMasterId": parseInt(this.TemplatePagesData.pmId)
    }
    this.firststepDbcompareService.copyToolsData(finalData).subscribe((res) => {
      if (res['msg']['flag'] == true) {
        success('Copy Tools Data !!!...');
      }
      else {
        alerts('Cannot Copy Tools data !!!...');
      }
    })

  }
}
