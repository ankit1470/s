import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ControlCopyComponent } from './control-copy.component';


const routes: Routes = [{
  path : "",
  component:ControlCopyComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ControlCopyRoutingModule { }
