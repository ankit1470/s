import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { TemplateService } from '../template.service';
import { DynamicDialogConfig } from 'primeng/primeng';
import { SageditorService } from '../../sageditor/services/sageditor.service';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  selector: 'app-file-template-mapping',
  templateUrl: './file-template-mapping.component.html',
  styleUrls: ['./file-template-mapping.component.scss']
})
export class FileTemplateMappingComponent implements OnInit {
  grid:boolean = true;
  reporting:boolean = false;
  gridDynamicForTemplateImportExportMapping:any
  mappingRefrenceList: any[];
  templateList = [];
  fileProviderList =[];
  fileImportExportInfoFormGroup: FormGroup;
  submittedFileImportExport: boolean = false;
  constructor( private sageditorService: SageditorService,private formbuilder: FormBuilder, public templateService: TemplateService,public config: DynamicDialogConfig,) { }

  ngOnInit() {
    this.getFileProviderList()
    this.initializeFormGroup();
    if(this.config.data){
      this.fileImportExportInfoFormGroup.patchValue(this.config.data); 
    }
    this.getFileImportExportMapping()
  }

  initializeFormGroup() {
    this.fileImportExportInfoFormGroup = this.formbuilder.group({
      mappingId: [{ value: '', disabled: false }],
      softwareName: [{ value: '', disabled: false }],
      softwareId: [{ value: null, disabled: false }],
      formName: [{ value: '', disabled: false }],
      softwareFormId: [{ value: '', disabled: false }, [Validators.required]],
      file: [{ value: '', disabled: false }],
      fileName: [{ value: '', disabled: false }, [Validators.required]],
      type: [{ value: '', disabled: false }, [Validators.required]],
      fileType: [{ value: '', disabled: false }, [Validators.required]],
      providerId: [{ value: '', disabled: false }, [Validators.required]],
      providerName:[{ value: '', disabled: false }],
      versionNo: [{ value: '', disabled: false }, [Validators.required]],
      fileExtention: [{ value: '', disabled: true }, [Validators.required]],
      fromDate: [{ value: '', disabled: false }, [Validators.required]],
      toDate: [{ value: '', disabled: false }, [Validators.required]],
      dataInsertType: [{ value: 'hibernate_query', disabled: false }],
      databaseType: [{ value: 'mysql', disabled: false }],
      viceVersaId: [{ value: '', disabled: false }],
      viceVersaFileType: [{ value: '', disabled: false }],
      
    });
  }

  getFileProviderList() {
    this.templateService.getFileProviderList().subscribe(res => {
      if (res.status == 200) {
        this.fileProviderList = res.data;
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }
  getFileImportExportMapping() {
    let softwareFormId = this.fileImportExportInfoFormGroup.controls["softwareFormId"].value;
    if (!softwareFormId) {
      this.sagFileMappingInfoGrid([]);
      return;
    }

    this.templateService.getFileImportExportMapping(softwareFormId).subscribe(res => {
      if (res.status == 200) {
        this.sagFileMappingInfoGrid(res.data);
      } else {
        this.sagFileMappingInfoGrid([]);
      }
    }, Error => {
      this.sagFileMappingInfoGrid([]);
      alerts("Error While Fetching Data");
    });

  }
  sagFileMappingInfoGrid(rowsData) {
    var sourceDiv = document.getElementById("fileTemplateGrid");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Form Name",
        "field": "formName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
     
      {
        "header": "Version",
        "field": "versionNo",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Type",
        "field": "type",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Provider",
        "field": "providerName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "File Type",
        "field": "fileType",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      
      {
        "header": "File Name",
        "field": "fileName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "File Extention",
        "field": "fileExtention",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "No Of Sheet",
        "field": "noOfSheet",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "From Date",
        "field": "fromDate",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "To Date",
        "field": "toDate",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Software version",
        "field": "softwareVersion",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },

    ];
    let self = this;

    let components = {};

    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",

        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
           "onRowDbleClick": (ele,params)=> {
            debugger
            console.log(ele,params)
            let data = this.gridDynamicForTemplateImportExportMapping.getSeletedRowData();
              let mappingId =data.mappingId;
              let sheetName ='master';
              let headerRow = data.sno;
              let formName= data.formName;
              let versionNo= data.versionNo;
              
              // let DefaultString = `<html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Document</title></head><body><div style='text-align:center'><h1>Business-ready</h1></div></body></html>`;
              
            this.templateService.getSpecificTemp(mappingId,sheetName,headerRow,formName,versionNo).subscribe((res)=>{
              sessionStorage.setItem("fileData",res.data);
              this.sageditorService.setData('formName',res.formName);
              this.sageditorService.setData('versionNo',res.versionNo);
              this.sageditorService.setData('mappingId',mappingId);
              this.grid = false;
              this.reporting = true;
            })

          }
        }
      };
      this.gridDynamicForTemplateImportExportMapping = SagGridMPT(sourceDiv, gridData, true, true);
      return this.gridDynamicForTemplateImportExportMapping;
    }
  }
  addTemplateMappingInfo(){
    this.resetFileImportExportInfoForm();
    this.mappingRefrenceList = [];
    $('#addExcelInfoModel').modal('show')
  }
  modifyFileTemplateMapping(){
      let selectedRowData = this.gridDynamicForTemplateImportExportMapping.getSeletedRowData();
      if (!selectedRowData) {
        alerts("Please select row");
        return;
      }
  
      this.fileImportExportInfoFormGroup.patchValue(selectedRowData);

      $('#addExcelInfoModel').modal('show')
    
  }
  deleteFileTemplateMapping(){

  }
  onCloseTemplateInfo(){

  }
  resetFileImportExportInfoForm() {
    this.fileImportExportInfoFormGroup.patchValue({
      "mappingId": "",
      "file": "",
      "fileName": "",
      "type": "",
      "fileType": "",
      "providerId": "",
      "noOfSheet": "",
      "versionNo": "",
      "fileExtention": "",
      "fromDate": "",
      "toDate": "",
      "dataInsertType": "hibernate_query",
      "databaseType": "mysql",
      "viceVersaId":"",
      "viceVersaFileType":""
    })
  }

  fileChange(event) {
    let fileList: FileList = event.target.files;
    if (fileList && fileList.length > 0) {
      this.getFileInfo(fileList[0]);
      this.fileImportExportInfoFormGroup.controls["file"].patchValue(fileList[0]);
     
    } else {
      this.fileImportExportInfoFormGroup.controls["file"].patchValue(null);
    }
 }
 getFileInfo(file){
  
  let formData = new FormData();
  formData.set('file', file);

  this.templateService.getFileInfo(formData).subscribe(res => {
      this.fileImportExportInfoFormGroup.controls["fileName"].patchValue(res.fileNameWithoutExtension);
      this.fileImportExportInfoFormGroup.controls["fileType"].patchValue(res.fileType);
      this.fileImportExportInfoFormGroup.controls["fileExtention"].patchValue(res.fileExtension);
  }, Error => {

  });
}



saveFileImportExportMapping() {
  this.submittedFileImportExport = true;

  let formObj = this.fileImportExportInfoFormGroup.getRawValue();
  let formData = new FormData();

  if("Report" != this.fileImportExportInfoFormGroup.controls['type'].value){
    if (!this.fileImportExportInfoFormGroup.valid) {
      alerts("Please Fill All Requird Fields")
      return;
    }
    this.submittedFileImportExport = false;

    let file = this.fileImportExportInfoFormGroup.controls["file"].value;
   
    if (!formObj.mappingId && (file == null || file == "" || file == undefined)) {
      alerts("Please Choose file first")
      return;
    }

  
  }
  let obj = JSON.parse(JSON.stringify(formObj));
  obj['file'] = null;
  formData.set('file', this.fileImportExportInfoFormGroup.controls["file"].value);
  formData.set('modelStr', JSON.stringify(obj));

  this.templateService.saveFileTemplateMapping(formData).subscribe(res => {
    if (res.status == 200) {
      // this.getFileImportExportMapping();
      success(res.msg);
      // this.onCloseAddExcelMappingInfo();
    } else {
      alerts(res.msg);
    }
  }, Error => {
    alerts("Error While saving data");
  });


}

}
