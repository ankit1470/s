import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TemplateMappingRoutingModule } from './template-mapping-routing.module';
import { TemplateMappingComponent } from './template-mapping.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileTemplateMappingComponent } from './file-template-mapping/file-template-mapping.component';
import { CalendarModule } from 'primeng/calendar';
import { SageditorModule } from '../sageditor/sageditor.module';

@NgModule({
  declarations: [TemplateMappingComponent, FileTemplateMappingComponent],
  imports: [
    CommonModule,
    CalendarModule,
    TemplateMappingRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SageditorModule
  ],
  exports:[TemplateMappingComponent,]
})
export class TemplateMappingModule { }
