import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiConstant } from 'src/app/config/apiconfig';
const baseurl = apiConstant.baseurl;
const projectinfourl = apiConstant.projectinfourl;
const projectInfoBaseUrl = apiConstant.projectinfourl;
const proDatajectInfoBaseUrl = "http://192.168.0.70:8080"
@Injectable({
  providedIn: 'root'
})
export class TemplateService {

  constructor(private http:HttpClient) { }

  // Template Mapping
  public saveFileTemplateMapping(formData): Observable<any> {
    return this.http.post(`${projectInfoBaseUrl}/template-import-export/save-file-import-export-mapping`, formData);
  }

  public getSoftwareList(): Observable<any> {
    return this.http.get(`${projectInfoBaseUrl}/template-import-export/get-software-list`);
  }

  public getSoftwareFormList(softwareId): Observable<any> {
    return this.http.get(`${projectInfoBaseUrl}/template-import-export/get-software-form-list/${softwareId}`);
  }

  public saveSoftwareForm(reqObj): Observable<any> {
    return this.http.post(`${projectInfoBaseUrl}/template-import-export/save-software-form`, reqObj);
  }

  public getFileProviderList(): Observable<any> {
    return this.http.get(`${projectInfoBaseUrl}/template-import-export/get-file-provider-list`);
  }

  public getFileImportExportMapping(softwareFormId): Observable<any> {
    return this.http.get(`${projectInfoBaseUrl}/template-import-export/get-file-import-export-mapping/${softwareFormId}`);
  }

  public getFileInfo(formData): Observable<any> {
    return this.http.post(`${projectInfoBaseUrl}/template-import-export/get-file-info`, formData);
  }

  // public getSpecificTemp(formData): Observable<any> {
  //   return this.http.post(`${projectInfoBaseUrl}/template-import-export/get-master-mapping`, formData);
  // }
  public getSpecificTemp(mappingId,sheetName,headerRow,formName,versionNo): Observable<any> {
    return this.http.get(`${projectInfoBaseUrl}/template-import-export/get-master-mapping?mappingId=${mappingId}&sheetName=${sheetName}&headerRow=${headerRow}&formName=${formName}&versionNo=${versionNo}`);
  }
}
