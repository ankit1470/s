import { Component } from '@angular/core';
import { FileImportExportMappingComponent } from '../import-export-mapping/file-import-export-mapping/file-import-export-mapping.component';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { FileTemplateMappingComponent } from './file-template-mapping/file-template-mapping.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { TemplateService } from './template.service';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: {
    class: "d-flex flex-column h-100 ", 
  },
  selector: 'app-template-mapping',
  templateUrl: './template-mapping.component.html',
  styleUrls: ['./template-mapping.component.scss']
})
export class TemplateMappingComponent {
  templateMappingGrid:any
  toggleCheck: any
 

  softwareFormFormGroup: FormGroup;
  submittedSoftwareForm: boolean = false;
  softwareList = [];

constructor( private formbuilder: FormBuilder,public modalRef: DynamicDialogRef,
  public shareService: SagShareService,
  public dialogService: DialogService,
  public templateService:TemplateService,
){
  
}

  ngOnInit(){
    this.initializeFormGroup();
    this.getSoftwareList();
  }
  initializeFormGroup() {

    this.softwareFormFormGroup = this.formbuilder.group({
      softwareName: [{ value: '', disabled: false }],
      softwareId: [{ value: null, disabled: false }, [Validators.required]],
      formName: [{ value: '', disabled: false }, [Validators.required]],
      softwareFormId: [{ value: '', disabled: false }],
    });

  }
  templateMappingGridFn(rowsData?) {
    var sourceDiv = document.getElementById("templateMappingGrid");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Software Name",
        "field": "softwareName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Form Name",
        "field": "formName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },


    ];
    let self = this;

    let components = {};

    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",

        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowDbleClick": function () {
            self.onClickFileMappingInfo()
          }
        }
      };
      this.templateMappingGrid = SagGridMPT(sourceDiv, gridData, true, true);
      return this.templateMappingGrid;
    }
  }

  showGrid:boolean =  false;
  fileOutput(event) {
    if (event.target.checked) {
      this.showGrid = true;
      let selectedProject = JSON.parse(localStorage.getItem('selectedProjectChooseData'))
      let json= {
        path : selectedProject.jwspace,
        projectName: selectedProject.projectname
      }
      this.getSoftwareFormList(this.softwareFormFormGroup.controls['softwareId'].value);
      this.shareService.reportingFileOutput(json).subscribe((res: any) => {
        console.log(res)
      })
    }
    else{
      this.showGrid =  false;
    }
  }


  onClickFileMappingInfo() {
  
    if (!this.shareService.getDatadbtool("finalDataForConnection")) {
      alerts("DataBase Connection are not established")
      return;
    }

    let selectedRowData = this.templateMappingGrid.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row")
      return;
    }

    this.openFileTemplateModal(selectedRowData);
  }

  openFileTemplateModal(selectedRowData){
    const ref = this.dialogService.open(FileTemplateMappingComponent, {
      header: "File Mapping Info",
      width: "100%",
      contentStyle: {"margin-top": "0px", "height": "100%" },
      styleClass: "service_full_model excel-demo-view",
      data: selectedRowData
    });
    ref.onClose.subscribe((res) => {
  
    });
  }

  onClickTemplateMappingInfo(){

  }
  onClickAddForm() {

    this.softwareFormFormGroup.patchValue({
      "softwareName":"",
      "formName":"",
      "softwareFormId":"",
    })

    $('#addFormModal').modal('show')
  }
  modifyTemplateForm(){
  let selectedRowData = this.templateMappingGrid.getSeletedRowData();
    if (!selectedRowData) {
      alerts("Please select row")
      return;
    }
    this.onClickAddForm();

    this.softwareFormFormGroup.patchValue(selectedRowData);
  }
  deleteTemplateForm(){
    $('#addFormModal').modal('hide')
  };

  getSoftwareFormList(softwareId) {
    if (!softwareId) {
      this.templateMappingGridFn([]);
      return;
    }

    this.softwareFormFormGroup.controls['softwareId'].setValue(Number(softwareId));

    this.templateService.getSoftwareFormList(softwareId).subscribe(res => {
      if (res.status == 200) {
        this.templateMappingGridFn(res.data);
      } else {
        this.templateMappingGridFn([]);
      }
    }, Error => {
      this.templateMappingGridFn([]);
      alerts("Error While Fetching Data");
    });

  }

  getSoftwareList() {
 
    this.templateService.getSoftwareList().subscribe(res => {
      if (res.status == 200) {
        this.softwareList = res.data;
        const setProjectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
        if (setProjectInfo && setProjectInfo.jwspace) {
          const projectId = setProjectInfo.projectId
          this.softwareFormFormGroup.controls['softwareId'].setValue(projectId);
          this.getSoftwareFormList(projectId);
        }
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  saveFormName() {
    if (!this.softwareFormFormGroup.valid) {
      alerts("Data not valid")
      return;
    }
    this.templateService.saveSoftwareForm(this.softwareFormFormGroup.getRawValue()).subscribe(res => {
      if (res.status == 200) {
        success(res.msg);
        this.getSoftwareFormList(this.softwareFormFormGroup.controls['softwareId'].value);
        this.softwareFormFormGroup.controls['formName'].setValue('');
        this.onCloseAddForm();
      } else {
        alerts(res.msg);
      }
    }, Error => {
      alerts("Error While saving data");
    });

  }
  onCloseAddForm() {
    $('#addFormModal').modal('hide')
  }
}
