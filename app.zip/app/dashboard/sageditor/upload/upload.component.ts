import { HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UploadService } from '../../sageditor/services/upload.service';


@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent implements OnInit {

  uploadForm:any = FormGroup; 
  selectedFiles:any= FileList;
  currentFileUpload:any= File;
  loading: boolean = false;
  wordEditor: boolean= false;
  wordUplod: boolean = true;
  constructor(private formBuilder: FormBuilder,private uploadService: UploadService,private router : Router,private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.uploadForm = this.formBuilder.group({
      profile: ['']
    });
    document.getElementById('saggstloader').style.display = "none";
  }

  onFileSelect(event:any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadForm.get('profile').setValue(file);
      this.selectedFiles = event.target.files;
    }
  }

  onSubmit() {

    this.loading = true;
    //sessionStorage.clear(); 
    const formData = new FormData();
    formData.append('wordfile', this.uploadForm.get('profile').value);
    this.uploadService.uploadFile(formData).subscribe(
      (res) => {
        if (res instanceof HttpResponse) {
        if(res.status == 200){
             this.loading = false;
             console.log('File is completely uploaded!');
             sessionStorage.setItem('isUpload','true'); 
             sessionStorage.setItem('fileData',res.body); 
            // this.router.navigate(["wordFileUpload"]);
            //  this.router.navigateByUrl(this.router.url.replace('fileUpload', 'wordFileUpload'));
            this.wordEditor = true;
            this.wordUplod = false;
        }else{
          alert("Fail Upload File");
        }
      }
      },
      (err) => console.log(err)
    );
  }

  reset(){
    this.uploadForm.get('profile').setValue('');
    this.selectedFiles = '';
  }

}
