import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest} from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { apiConstant } from 'src/app/config/apiconfig';


const projectInfoBaseUrl = apiConstant.projectinfourl;

@Injectable({
  providedIn: 'root'
})
export class SageditorService {

  constructor(private http: HttpClient) { }

  downloadWordFile(formData:FormData): Observable<any> {
    return;
   /* const req = new HttpRequest('POST', `${masterCommonConstant.genBillBaseUrl}` +`/invoice/exportWordFile`, formData, {responseType: 'text'});
    return this.http.request(req);*/
  }
  getInvoiceData(data): Observable<any> {
     return this.http.post(
       `${projectInfoBaseUrl}/frontendinfo/getInvoiceDataCustom`,
       data
     );
    /* return this.http.post(
       `${masterCommonConstant.genBillBaseUrl}` +
         "/invoice/getInvoiceDataCustom",
       data
     );*/
  }

  old_downloadWordFilesAfterChanges(formData,filename){
    /*return this.http.post(
      `${masterCommonConstant.sag_word_editerBaseUrl}` +
        "/downloadWordFiles?${filename}",
      formData,
      { responseType: "text" }
    );*/
  }


  uploadToPrint(formData): Observable<any>{
    const req = new HttpRequest<any>('POST',`${projectInfoBaseUrl}/frontendinfo/downloadWordFilesAfterChanges`,formData,{responseType: 'text'});
    return this.http.request(req);
   }

   uploadToPrintPreview(formData): Observable<any>{

  
    const req = new HttpRequest<any>('POST',`${projectInfoBaseUrl}/frontendinfo/downloadWordFilesAfterChangesForPriview`,formData,{responseType: 'text'});
    return this.http.request(req);
   }
   public data = {};
   setData(key: any, data: any) {
    this.data[key] = data;
  }
  getData(key: any) {
    return this.data[key];
  }

  getFormData(){
    return this.http.get(`${projectInfoBaseUrl}/import-export/get-software-form-list/${577}`)
  }

  getUserFileList(userId:any){
    return this.http.get(`${projectInfoBaseUrl}/frontendinfo/getAllTemplates/${userId}`)
  }
  getapiListData(projectDetail:any){
    return this.http.post(`${projectInfoBaseUrl}/auto-code/get-java-api-info-list`,projectDetail)
  }

  geFormiListData(){
    return this.http.get(`${projectInfoBaseUrl}/frontendinfo/get-software-form-list/${577}`)
  }

  getKeyValJson(api:string,){
    return this.http.get( api);
    // return this.http.get(`http://localhost:7780/`+ api);
  }

  getFormMapping(formId:any){
    return this.http.get(`${projectInfoBaseUrl}/import-export//${formId}`);
  }
}