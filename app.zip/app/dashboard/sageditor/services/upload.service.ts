import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest} from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { apiConstant } from 'src/app/config/apiconfig';


const projectInfoBaseUrl = apiConstant.projectinfourl;
@Injectable({
  providedIn: 'root'
})
export class UploadService {

  private data :any

  constructor(private http: HttpClient) { }

 private setData(key: any, data: any) {
    this.data[key] = data;
  }
  private getData(key: any) {
    return this.data[key];
  }
  private removeData(key:any) {
    delete this.data[key];
  }
  uploadFile(formdata: FormData): Observable<any> {
    const req = new HttpRequest('POST', `${projectInfoBaseUrl}/frontendinfo/wordFileUpload`, formdata, {responseType: 'text'});
    return this.http.request(req);
  }

}
