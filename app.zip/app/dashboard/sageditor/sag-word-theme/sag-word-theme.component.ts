import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sag-word-theme',
  templateUrl: './sag-word-theme.component.html',
  styleUrls: ['./sag-word-theme.component.scss']
})
export class SagWordThemeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
