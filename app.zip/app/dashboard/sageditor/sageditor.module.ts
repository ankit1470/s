import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SageditorRoutingModule } from './sageditor-routing.module';
import { UploadComponent } from './upload/upload.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SagWordThemeComponent } from './sag-word-theme/sag-word-theme.component';
import { SagWordEditorComponent } from './sag-word-editor/sag-word-editor.component';
import {TreeModule} from 'primeng/tree';



@NgModule({
  declarations: [
    UploadComponent,
    SagWordThemeComponent,
    SagWordEditorComponent
  ],
  imports: [
    CommonModule,
    SageditorRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    TreeModule,
    
  ],
  exports:[SagWordEditorComponent]
})
export class SageditorModule { }
