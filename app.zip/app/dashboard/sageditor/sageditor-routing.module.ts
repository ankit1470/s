import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SagWordEditorComponent } from './sag-word-editor/sag-word-editor.component';
import { SagWordThemeComponent } from './sag-word-theme/sag-word-theme.component';
import { UploadComponent } from './upload/upload.component';

const routes: Routes = [
  {path : 'fileUpload', component : UploadComponent},
  {path: '', redirectTo: 'fileUpload', pathMatch: 'full'},
  {path : 'wordFileUpload', component : SagWordEditorComponent},
  {path : 'sagWordTheme', component : SagWordThemeComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SageditorRoutingModule { }
