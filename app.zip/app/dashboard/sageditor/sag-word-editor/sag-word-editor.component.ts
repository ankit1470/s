import { style } from "@angular/animations";
import { HttpResponse } from "@angular/common/http";
import {
  Component,
  ElementRef,
  OnInit,
  Renderer2,
  ViewChild,
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
// import { ShareService } from "../../services/share.service";
import { SageditorService } from "../services/sageditor.service";
import { element } from "protractor";
import { stringify } from "querystring";
import {TreeNode} from 'primeng/api';
import { SagShareService } from "src/app/services/sagshare.service";

declare const $: any;
declare var htmlDocx: any;
declare var ui;
declare function alerts(message);
declare function success(m);

@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: "app-sag-word-editor",
  templateUrl: "./sag-word-editor.component.html",
  styleUrls: ["./sag-word-editor.component.scss"],
})
export class SagWordEditorComponent implements OnInit {
  apiList:[]=[];
  formList:[]=[];
  selectedFiles:any = [];
  projectData: any;
  xmlString: any;
  DocumentContainer: any;
  resizeMode: boolean = false;
  filedata: any;
  fileType: any;
  fileSizeBytes: any;
  fileSize: any;
  creationTime: any;
  lastModifiedTime: any;
  lastAccessTime: any;
  selectedOption: any = [];
  selectedSizeOption: any = [];
  // jsonOption:any=[];
  text_box: any[] = [];
  rowAfterList: any[] = [];
  columnBeforeList: any[] = [];
  columnAfterList: any[] = [];
  @ViewChild("container", { static: false })
  container!: ElementRef;
  @ViewChild("editer", { static: false })
  editer!: ElementRef;
  @ViewChild("test", { static: false })
  el!: ElementRef;
  respSheet: any;
  methodBody: any;
  cursor: any;
  rn: any;
  cn: any;
  // search: any | null;
  Find: any | null;
  uploadimage: any;
  srcUrl: any;
  dynamicJsonTextNode: any;
  dynamicJsonTextNodeNested: any;
  wordEditor: boolean = true;
  wordUplod: boolean = false;
  userFileList:any
  constructor(
    public router: Router,
    public activateRouter: ActivatedRoute,
    private sageditorService: SageditorService,
    public shareService: SagShareService,
    private renderer: Renderer2,
    private elementRef: ElementRef
  ) {}
list:TreeNode[]
  ngOnInit(): void {
    this.apiListDrp();
    this.formListDrp();
    // document.getElementById("saggstloader").style.display = "none";
    const billId = {
      billId: "08",
    };

    this.sageditorService.getInvoiceData(billId).subscribe((res) => {
      this.list = res.dataList[0].keyfullName.data
    })
    // this.tableSelectRC()
    document.addEventListener('dblclick', (e: any) => {
      if ((e.target as HTMLElement).tagName === "TD") {
        if (this.selectedCell) {
          this.selectedCell.style.backgroundColor = ''
        }
        e.target.style.backgroundColor = 'orange'
        this.selectedCell = e.target
      }
    })
    const projectSessionData = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    const userId = projectSessionData.data.clientInfo.usrId;
    this.sageditorService.getUserFileList(userId).subscribe((res)=>{
           console.log(res)
           this.userFileList = res
    })
  }

  apiListDrp(){
    const projectDetail = this.shareService.getDataprotool("selectedProjectChooseData");
    this.list = []
    //projectDetail['projectPath'] = projectDetail['jwspace'];
    let obj = {
      "projectId":projectDetail["projectId"],
      "userId":  projectDetail["userId"],
      "projectPath" : projectDetail['jwspace']
    }

    this.sageditorService.getapiListData(obj).subscribe((res:[]) => {
      this.apiList = res['data'];
    })
  }

  formListDrp(){
   // const projectDetail = this.shareService.getDataprotool("selectedProjectChooseData");
    this.sageditorService.geFormiListData().subscribe((res:[]) => {
      this.formList = res['data'];
    })
  }
  fileChange(){
     
  }

  async preview(){
    const projectSessionData = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    const userId = projectSessionData.data.clientInfo.usrId;

    let filename: string;

    let ask =await ui.confirm("Do you want to save it as default file?");

    if (ask== true) {
       // *****pm sir start****** this is done on pm sir instruction!
      let newFile = confirm("Save As 'DefaultFile'")
      //  prompt("Save As", "DefaultFile");
      if (newFile) {
        filename = "DefaultFile";
      }else{
        alerts("Failed To Save")
        return
      }
      // *****pm sir end******
      // filename = "DefaultFile";
    } else {
      let fileName = sessionStorage.getItem('fileName');
      let newFile = prompt("Please enter the file name", fileName ? fileName.split('.docx')[0] : "PrintTempFile");
      if (newFile) {
        filename = newFile;
      }else{
        alerts("Failed To Save")
        return
      }
      
    }

    this.DocumentContainer = this.editer.nativeElement;

    var HtmlHead =
      "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></meta><title>Export HTML To Doc</title></head><body style='font-family:Microsoft Sans Serif,Arial,Georgia,Serif;'>";
    var EndHtml = "</body></html>";
    var html =
      HtmlHead +
      this.DocumentContainer.innerHTML.replace(/&nbsp;/g, " ") +
      EndHtml;

  // let converted = htmlDocx.asBlob(html)
    let formData = new FormData();
    formData.append("x", html);
    formData.append("y", filename);
    formData.append("z", this.sageditorService.getData('selectedClientGstn'));
    formData.append("z1", sessionStorage.getItem('isUpload') ? sessionStorage.getItem('isUpload') : 'false');
    formData.append("userId", userId);

    //  let data={
    //   'x':html,
    //   'filename':filename
    // } 
    this.sageditorService.uploadToPrintPreview(formData).subscribe(
      // this.sageditorService.downloadWordFile(formData).subscribe(
      (res) => {
        if (res instanceof HttpResponse) {
          if (res.status == 200) {
            let data = JSON.parse(res['body']);
            sessionStorage.setItem("fileName", data['fileName']);
            this.container.nativeElement.innerHTML = data['data'].replace("<div class=\"Section0\">",'<div style=\"display:flex;justify-content:center\" class=\"Section0\">');
            success("sucesssfully downloaded!");
          } else {
            alerts("Fail downloaded File");
          }
        }
      },
      (error) => {
        console.error("error", error);
      }
    );
  }


  ngAfterViewInit() {
    this.xmlString = sessionStorage.getItem("fileData");
    var doc = new DOMParser().parseFromString(this.xmlString, "text/html");
    // doc.getElementsByClassName("document")[0].attributes['style']='width:800px,margin:0 auto;'

    doc.getElementsByClassName("document").length > 0 ? doc.getElementsByClassName("document")[0].setAttribute("style"," margin:0 auto; padding:10px 0px;") : doc.body.children[0].className = 'document';;
    doc.getElementsByClassName("document")[0].setAttribute("style","display:flex;justify-content:center;align-item:center")
    this.container.nativeElement.innerHTML = doc.children[0].outerHTML;
    if (document.getElementsByTagName("table").length > 1) {
      for (let index = 0; index < document.getElementsByTagName("table").length; index++) {
        document.getElementsByTagName("table")[index].attributes.removeNamedItem('class');
        
      }
    } else {
      if (document.getElementsByTagName("table")[0].attributes.hasOwnProperty('class')) {
        document.getElementsByTagName("table")[0].attributes.removeNamedItem('class'); 
      }

    }
      // this.unnecessaryStyle()
  }


// toggle(event:any){
//   console.log(event)
//   if(event.target.classList.contains('ui-tree-toggler') ){
//     event.stopPropagation();
//   }
// }
//   nodeSelect(event) { 
//     console.log(event.node) 
//   expandRecursive(event.node, true);
//   function expandRecursive(node:TreeNode, isExpand:boolean){
//     node.expanded = isExpand;
//     if (node.children){
     
//         node.children.forEach( childNode => {
//             this.expandRecursive(childNode, isExpand);
//         } );
//     }
// }

//   function recursionPath(event) {
//     if (event.parent === undefined) {
//         return event.name;
//     } else {
//         var parentPath = recursionPath(event.parent);
//         return parentPath + '.' + event.name;
//     }
// }
// function recursionType(event) {
//   if (event.parent === undefined) {
//       return event.type;
//   } else {
//       var parentPath = recursionType(event.parent);
//       return parentPath + '@' + event.type;
//   }
// }
//     this.storePath =  recursionPath(event.node)
//     this.selectedJsonName = event.node.name
//     this.selectedJsonLabel = event.node.label
//     this.selectedJsonType = recursionType(event.node);
// }
// paste(){
//   let html = `<span class=${this.selectedJsonName} path=${this.storePath} type=${this.selectedJsonType}>${this.selectedJsonName}
//   <span style="display:none">${this.storePath}::${this.selectedJsonType}</span><span>`
//    this.getSelect(html)
// }

  // getSelect(html) {
  //   var sel, range, expandedSelRange, node;
  // let document  = window.document as any;
  // let selection = window.getSelection() as any;
  // if (selection.focusNode.parentElement.closest("#cont").id != "cont" ) {
  //   return;
  // }
  //   if (window.getSelection) {
  //       sel = window.getSelection();
  //       if (sel.getRangeAt && sel.rangeCount) {
  //           range = window.getSelection().getRangeAt(0);
  //           expandedSelRange = range.cloneRange();
  //           range.collapse(false);

  //           var el = document.createElement("div");
  //           el.innerHTML = html;
  //           var frag = document.createDocumentFragment(), node, lastNode;
  //           while ( (node = el.firstChild) ) {
  //               lastNode = frag.appendChild(node);
  //           }
  //           range.insertNode(frag);

  //           if (lastNode) {
  //               expandedSelRange.setEndAfter(lastNode);
  //               sel.removeAllRanges();
  //               sel.addRange(expandedSelRange);
  //           }
  //       }
  //   } else if (document.selection && document.selection.createRange) {
  //       range = document.selection.createRange();
  //       expandedSelRange = range.duplicate();
  //       range.collapse(false);
  //       range.pasteHTML(html);
  //       expandedSelRange.setEndPoint("EndToEnd", range);
  //       expandedSelRange.select();
  //   }
  //   // let setPath = document.getElementById(this.selectedJsonName)
  //   // setPath.setAttribute('path',this.storePath)
  // }
 unnecessaryStyle(){
 let unnecessaryStyleArray =[
    "border-bottom-style",
    "border-bottom-width",
    "border-bottom-color",
    "border-left-style",
    "border-left-width",
    "border-left-color",
    "border-right-style",
    "border-right-style",
    "border-right-width",
    "border-right-color",
    "border-top-style",
    "border-top-width",
    "border-top-color"
  ]
  for (let index = 0; index < unnecessaryStyleArray.length; index++) {
    const element = unnecessaryStyleArray[index];
         if (document.getElementsByTagName("table").length > 1) {
          for (let index = 0; index < document.getElementsByTagName("table").length; index++) {
            if (document.getElementsByTagName("table")[index].style.hasOwnProperty(element)) {
              document.getElementsByTagName("table")[index].style.removeProperty(element);   
            }
     
          }
         } else {
          if (document.getElementsByTagName("table")[0].style.hasOwnProperty(element)) {
            document.getElementsByTagName("table")[0].style.removeProperty(element);   
          }
         }  
  }
 }
  onBold(): void {
    document.execCommand("bold");
  }

  onCut() {
    document.execCommand("cut");
  }

  onCopy() {
    document.execCommand("copy");
  }

  onPaste() {
    // document.execCommand("paste");
    if (this.elementclicked == undefined) {
      alerts("Select the text box to paste !!");
      return;
    }

    let textBox = document.getElementById("cont")
    textBox.style.whiteSpace = 'pre-line'
    navigator.clipboard.readText().then(function (text) {


      let selection = window.getSelection();

      if (selection) {
        document.execCommand('insertHTML', true, text);

      }
    });

  }

  onItalic() {
    document.execCommand("italic");
  }

  onUnderLine() {
    document.execCommand("underline");
  }

  deleteRow() {
    if (this.xPostion == undefined && this.yPostion == undefined) {
      alerts("Double click the mouse pointer");
    }
    let currentRow: HTMLElement;
    let tableRef = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    ) as any;

    for ([]; tableRef; tableRef = tableRef.parentNode) {
      if (tableRef.nodeName == "TR") {
        currentRow = tableRef;
        break;
      }
    }

    currentRow.remove();
  }

  onFontName() {
    document.execCommand("fontname", false, this.selectedOption);
  }

  onFontSize() {
    document.execCommand("fontSize", false, this.selectedSizeOption);
  }

  onTextColor() {
    var textColor = prompt("Enter Font Color");
    if (textColor) {
      document.execCommand("forecolor", false, textColor);
    }
  }
  history: any = {
    back: [],
    forward: []
  };
  onRedo() {
    // document.execCommand("redo");
    let editor = document.getElementById('cont');
    if (this.history.forward.length > 0) {
      this.history.back.push(editor.innerHTML);
      editor.innerHTML = this.history.forward.pop();

      let tables = document.getElementsByTagName('table') as any;
      for (let i = 0; i < tables.length; i++) {
        this.resizableGrid(tables[i]);
        this.resizeImage(tables[i]);
        tables[i].addEventListener("mouseover", function () {
          this.style.outline = 'solid #0000ff';
        });
        tables[i].addEventListener("mouseout", function () {
          this.style.outline = 'solid transparent';
        });
      }
      // console.log(this.history, "rb");
    }
    editor.focus();
  }


  onUndo() {
    // document.execCommand("undo");

    let editor = document.getElementById('cont')

    if (this.history.back.length > 0) {
      this.history.forward.push(editor.innerHTML);
      editor.innerHTML = this.history.back.pop();
      // console.log(this.history, "uf")
    }
    editor.focus();
  }

  onSelectAll() {
    document.execCommand("selectall");
  }

  onJustifyCenter() {
    document.execCommand("justifycenter");
  }

  onJustifyLeft() {
    document.execCommand("justifyleft");
  }

  onJustifyRight() {
    document.execCommand("justifyright");
  }

  onJustifyFull() {
    document.execCommand("justifyfull");
  }

  onRemoveFormate() {
    document.execCommand("removeformat");
  }

  onStrikThrough() {
    document.execCommand("strikethrough");
  }

  onInsertHorizontalRule() {
    document.execCommand("inserthorizontalrule");
  }

  onJustifyJustify() {}

  onEqual() {}
  // reset
  // onResetMe() {
  //   const originalSize = $('div').css('font-size');
  //   $('div').css('font-size', originalSize);
  // }

  // Increase Font Size
  onIncrease() {
    var elem: any = document.documentElement;
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.webkitRequestFullscreen) {
      elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) {
      elem.msRequestFullscreen();
    }
  }

  // Minimize Screen
  onDecrease() {
    var elem: any = document
    if (elem.exitFullscreen) {
      elem.exitFullscreen();
    } else if (elem.webkitExitFullscreen) {
      elem.webkitExitFullscreen();
    } else if (elem.msExitFullscreen) {
      elem.msExitFullscreen();
    }
  }

  onSavePdf() {
    var DocumentContainer = this.editer.nativeElement;
    var WindowObject = window.open(
      "",
      "PrintWindow",
      "width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes"
    );
    if (DocumentContainer && WindowObject) {
      WindowObject.document.writeln(DocumentContainer.innerHTML);
      WindowObject.document.close();
      WindowObject.focus();
      WindowObject.print();
      WindowObject.close();
    }
  }

  exportAsDoc() {
    const preHtml =
      "<html xmlns:o='urn:schemas-microsoft-com:office:office' " +
      "" +
      " xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'>" +
      "<title>Export HTML To Doc</title></head><body>";
    const postHtml = "</body></html>";

    let innerHtml = this.editer.nativeElement.innerHTML;
    const filename = "test.doc";
    const html = preHtml + innerHtml.replace(/&nbsp;/g, " ") + postHtml;

    const blob = new Blob(["\ufeff", html], {
      type: "application/msword",
    });

    // Specify link url
    const url =
      "data:application/vnd.ms-word;charset=utf-8," + encodeURIComponent(html);

    // Create download link element
    const downloadLink = document.createElement("a");

    document.body.appendChild(downloadLink);

    if ((navigator as any).msSaveOrOpenBlob) {
      (navigator as any).msSaveOrOpenBlob(blob, filename);
    } else {
      // Create a link to the file
      downloadLink.href = url;

      // Setting the file name
      downloadLink.download = filename;

      // triggering the function
      downloadLink.click();
    }

    document.body.removeChild(downloadLink);
  }

  // onSaveWord() {
  //   this.DocumentContainer = this.editer.nativeElement;
  //   var HtmlHead =
  //     "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></meta><title>Export HTML To Doc</title></head><body style='font-family:Microsoft Sans Serif,Arial,Georgia,Serif;'>";
  //   var EndHtml = "</body></html>";
  //   var html =
  //     HtmlHead +
  //     this.DocumentContainer.innerHTML.replace(/&nbsp;/g, " ") +
  //     EndHtml;

  //   const formData = new FormData();
  //   formData.append("x", html);
  //   this.sageditorService.downloadWordFile(formData).subscribe(
  //     (res) => {
  //       if (res instanceof HttpResponse) {
  //         if (res.status == 200) {
  //           success("sucesssfully downloaded!");
  //         } else {
  //           alerts("Fail downloaded File");
  //         }
  //       }
  //     },
  //     (error) => {
  //       console.error("error", error);
  //     }
  //   );
  // }
  async onSaveWord() {
    let filename: string;

    // let ask =await ui.confirm("Do you want to save it as default file?");

    // if (ask== true) {
    //    // *****pm sir start****** this is done on pm sir instruction!
    //   let newFile = confirm("Save As 'DefaultFile'")
    //   //  prompt("Save As", "DefaultFile");
    //   if (newFile) {
    //     filename = "DefaultFile";
    //   }else{
    //     alerts("Failed To Save")
    //     return
    //   }
    //   // *****pm sir end******
    //   // filename = "DefaultFile";
    // } else {
    //   let fileName = sessionStorage.getItem('fileName');
    //   let newFile = prompt("Please enter the file name", fileName ? fileName.split('.docx')[0] : "PrintTempFile");
    //   if (newFile) {
    //     filename = newFile;
    //   }else{
    //     alerts("Failed To Save")
    //     return
    //   }
      
    // }

    this.DocumentContainer = this.editer.nativeElement;

    var HtmlHead =
      "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></meta><title>Export HTML To Doc</title></head><body style='font-family:Microsoft Sans Serif,Arial,Georgia,Serif;'>";
    var EndHtml = "</body></html>";
    var html =
      HtmlHead +
      this.DocumentContainer.innerHTML.replace(/&nbsp;/g, " ") +
      EndHtml;

  // let converted = htmlDocx.asBlob(html)
    let formData = new FormData();
    formData.append("x", html);
    // formData.append("y", filename);
    formData.append("z", this.sageditorService.getData('selectedClientGstn'));
    formData.append("z1", sessionStorage.getItem('isUpload') ? sessionStorage.getItem('isUpload') : 'false');
    formData.append("z2", sessionStorage.getItem('docFile') ? sessionStorage.getItem('docFile') : 'false');

    //  let data={
    //   'x':html,
    //   'filename':filename
    // } 
    this.sageditorService.downloadWordFile(formData).subscribe(
      // this.sageditorService.downloadWordFile(formData).subscribe(
      (res) => {
        if (res instanceof HttpResponse) {
          if (res.status == 200) {
            success("sucesssfully downloaded!");
          } else {
            alerts("Fail downloaded File");
          }
        }
      },
      (error) => {
        console.error("error", error);
      }
    );
  }
  // js fucntions////
  isOrIsAncestorOf(ancestor: any, descendant: any) {
    var n = descendant;
    while (n) {
      if (n === ancestor) {
        return true;
      } else {
        n = n.parentNode;
      }
    }
    return false;
  }

  nodeContainsSelection(node: any) {
    var sel: any, range;
    if ((window.getSelection && (sel = window.getSelection())).rangeCount) {
      range = sel.getRangeAt(0);
      return this.isOrIsAncestorOf(node, range.commonAncestorContainer);
    }
    return false;
  }

  insertHTML() {
    var a: any;
    var b: any;
    a = prompt("Input number of rows", "1");
    b = prompt("Input number of columns", "1");
    var sel: any, range: any;
    if ((window.getSelection && (sel = window.getSelection())).rangeCount) {
      range = sel.getRangeAt(0);
      range.collapse(true);

      var tbl = document.createElement("table");
      tbl.style.width = "20%";
      tbl.setAttribute("border", "1");
      var tbdy = document.createElement("tbody");
      for (var i = 0; i < parseInt(a); i++) {
        var tr = document.createElement("tr");
        for (var j = 0; j < parseInt(b); j++) {
          if (i == parseInt(a) && j == parseInt(b)) {
            break;
          } else {
            var td = document.createElement("td");
            td.appendChild(document.createTextNode("\u0020"));
            tr.appendChild(td);
          }
        }
        tbdy.appendChild(tr);
      }
      tbl.appendChild(tbdy);
      range.insertNode(tbl);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
    }
  }

  onload() {
    const self = this;
    var inserter = document.getElementById("inserter");
    if (inserter)
      inserter.onmousedown = function () {
        var editor = document.getElementById("editor");
        self.DocumentContainer = editor;
        self.insertHTML();
        return false;
      };
  }
  /** ********************************************************* */

  /** **************************************************** */

  index: any;
  tr: any;
  td: any;
  tdIndex: any;
  onload2() {
    const self = this;
    if (!document.getElementsByTagName || !document.createTextNode) return;
    $(".document table").each(function (_index: any, table: any) {
      $(table)
        .find("tr")
        .each(function (_rowIndex: any, tempTr: any) {
          $(tempTr).click(function (event: any) {
            self.tr = $(event);
          });
          $(tempTr)
            .find("td")
            .each(function (tempTdIndex: any, tempTd: any) {
              $(tempTd).click(function (event: any) {
                self.td = $(event);
                self.tdIndex = tempTdIndex;
              });
            });
        });
    });
  }

  cloneRow() {
    var row = document.getElementsByTagName("tr")[this.index]; // find row to
    var cloneRow = row.cloneNode(true); // copy children too
    if (row.parentNode) row.parentNode.insertBefore(cloneRow, row.nextSibling);
  }
  onDelete() {
    document.execCommand("delete");
  }

  deleteColumn(target) {
    if (this.xPostion == undefined && this.yPostion == undefined) {
      alerts("Double click the mouse pointer");
    }
    let tableRef = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    ) as HTMLTableElement;
    let colgroup: any;
    let cell: any;
    const getParents = (el: any) => {
                      if (target == 'TABLE') {
            for (var parents: any = []; el; el = el.parentNode) {
        if (el.nodeName == "TD") {
             cell =el.cellIndex

            }
            if (el.nodeName == "TABLE") {
              for (let index = 0; index < el.childNodes.length; index++) {
                if (el.childNodes[index].tagName == 'TBODY') {
                  for (let i = 0; i < el.childNodes[index].children.length; i++) {
                   el.childNodes[index].children[i].cells[cell].remove();
                    
                  }
                }
                break;
              }
        }  }
         return  } ;

      for (var parents: any = []; el; el = el.parentNode) {
          if (el.nodeName == "TD") {
             cell =el

          // el.remove()
        }

        if (el.nodeName == "TR") {
          if (cell.parentElement.children.length <= 1) {
            alerts("Doesn't Have Column !")
            break
          }
          el.children[cell.cellIndex].remove();

          // el.remove()
        }

        if (el.nodeName == "TABLE") {
          colgroup = el.childNodes[0].childNodes[cell.cellIndex];
          colgroup.remove();
        }
      }
      return parents;
    };
    const el = tableRef;
    getParents(el);
  }

  deleteLastColumn() {
    let a = this.editer.nativeElement.childNodes[0].childNodes;
    for (let i = 0; i < a.length; i++) {
      let b = a[i];
      if (b.className == "document") {
        // console.log(b.filter("table"));
      }
    }
    if (this.xPostion == undefined && this.yPostion == undefined) {
      alerts("Double click the mouse pointer");
    }
    let tableRef = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    ) as HTMLTableElement;
    let colgroup: any;

    const getParents = (el: any) => {
      for (var parents: any = []; el; el = el.parentNode) {
        if (el.nodeName == "TR") {
          el.children[0].remove();

          // el.remove()
        }

        if (el.nodeName == "TABLE") {
          colgroup = el.childNodes[0].childNodes[0];
          colgroup.remove();
        }
      }
      return parents;
    };
    const el = tableRef;
    getParents(el);
  }

  columnafterlist = [];
  columnInsertAfter() {
    let obj = {
      name: "",
    };
    this.columnAfterList.push(obj);
  }

  showCoords(event: any) {
    var cX = event.clientX;
    var sX = event.screenX;
    var cY = event.clientY;
    var sY = event.screenY;
    var coords1 = "client - X: " + cX + ", Y coords: " + cY;
    var coords2 = "screen - X: " + sX + ", Y coords: " + sY;
  }

  getTrClone(obj: any) {
    const self = this;
    var trStyle = $(obj).css([
      "alignContent",
      "alignItems",
      "alignSelf",
      "alignmentBaseline",
      "all",
      "animation",
      "animationDelay",
      "animationDirection",
      "animationDuration",
      "animationFillMode",
      "animationIterationCount",
      "animationName",
      "animationPlayState",
      "animationTimingFunction",
      "appearance",
      "ascentOverride",
      "backdropFilter",
      "backfaceVisibility",
      "background",
      "backgroundAttachment",
      "backgroundBlendMode",
      "backgroundClip",
      "backgroundColor",
      "backgroundImage",
      "backgroundOrigin",
      "backgroundPosition",
      "backgroundPositionX",
      "backgroundPositionY",
      "backgroundRepeat",
      "backgroundRepeatX",
      "backgroundRepeatY",
      "backgroundSize",
      "baselineShift",
      "blockSize",
      "border",
      "borderBlock",
      "borderBlockColor",
      "borderBlockEnd",
      "borderBlockEndColor",
      "borderBlockEndStyle",
      "borderBlockEndWidth",
      "borderBlockStart",
      "borderBlockStartColor",
      "borderBlockStartStyle",
      "borderBlockStartWidth",
      "borderBlockStyle",
      "borderBlockWidth",
      "borderBottom",
      "borderBottomColor",
      "borderBottomLeftRadius",
      "borderBottomRightRadius",
      "borderBottomStyle",
      "borderBottomWidth",
      "borderCollapse",
      "borderColor",
      "borderImage",
      "borderImageOutset",
      "borderImageRepeat",
      "borderImageSlice",
      "borderImageSource",
      "borderImageWidth",
      "borderInline",
      "borderInlineColor",
      "borderInlineEnd",
      "borderInlineEndColor",
      "borderInlineEndStyle",
      "borderInlineEndWidth",
      "borderInlineStart",
      "borderInlineStartColor",
      "borderInlineStartStyle",
      "borderInlineStartWidth",
      "borderInlineStyle",
      "borderInlineWidth",
      "borderLeft",
      "borderLeftColor",
      "borderLeftStyle",
      "borderLeftWidth",
      "borderRadius",
      "borderRight",
      "borderRightColor",
      "borderRightStyle",
      "borderRightWidth",
      "borderSpacing",
      "borderStyle",
      "borderTop",
      "borderTopColor",
      "borderTopLeftRadius",
      "borderTopRightRadius",
      "borderTopStyle",
      "borderTopWidth",
      "borderWidth",
      "bottom",
      "boxShadow",
      "boxSizing",
      "breakAfter",
      "breakBefore",
      "breakInside",
      "bufferedRendering",
      "captionSide",
      "caretColor",
      "clear",
      "clip",
      "clipPath",
      "clipRule",
      "color",
      "colorInterpolation",
      "colorInterpolationFilters",
      "colorRendering",
      "colorScheme",
      "columnCount",
      "columnFill",
      "columnGap",
      "columnRule",
      "columnRuleColor",
      "columnRuleStyle",
      "columnRuleWidth",
      "columnSpan",
      "columnWidth",
      "columns",
      "contain",
      "containIntrinsicSize",
      "content",
      "contentVisibility",
      "counterIncrement",
      "counterReset",
      "counterSet",
      "cssFloat",
      "cssText",
      "cursor",
      "cx",
      "cy",
      "d",
      "descentOverride",
      "direction",
      "display",
      "dominantBaseline",
      "emptyCells",
      "fill",
      "fillOpacity",
      "fillRule",
      "filter",
      "flex",
      "flexBasis",
      "flexDirection",
      "flexFlow",
      "flexGrow",
      "flexShrink",
      "flexWrap",
      "float",
      "floodColor",
      "floodOpacity",
      "font",
      "fontDisplay",
      "fontFamily",
      "fontFeatureSettings",
      "fontKerning",
      "fontOpticalSizing",
      "fontSize",
      "fontStretch",
      "fontStyle",
      "fontVariant",
      "fontVariantCaps",
      "fontVariantEastAsian",
      "fontVariantLigatures",
      "fontVariantNumeric",
      "fontVariationSettings",
      "fontWeight",
      "gap",
      "grid",
      "gridArea",
      "gridAutoColumns",
      "gridAutoFlow",
      "gridAutoRows",
      "gridColumn",
      "gridColumnEnd",
      "gridColumnGap",
      "gridColumnStart",
      "gridGap",
      "gridRow",
      "gridRowEnd",
      "gridRowGap",
      "gridRowStart",
      "gridTemplate",
      "gridTemplateAreas",
      "gridTemplateColumns",
      "gridTemplateRows",
      "height",
      "hyphens",
      "imageOrientation",
      "imageRendering",
      "inherits",
      "initialValue",
      "inlineSize",
      "inset",
      "insetBlock",
      "insetBlockEnd",
      "insetBlockStart",
      "insetInline",
      "insetInlineEnd",
      "insetInlineStart",
      "isolation",
      "justifyContent",
      "justifyItems",
      "justifySelf",
      "left",
      "length",
      "letterSpacing",
      "lightingColor",
      "lineBreak",
      "lineGapOverride",
      "lineHeight",
      "listStyle",
      "listStyleImage",
      "listStylePosition",
      "listStyleType",
      "margin",
      "marginBlock",
      "marginBlockEnd",
      "marginBlockStart",
      "marginBottom",
      "marginInline",
      "marginInlineEnd",
      "marginInlineStart",
      "marginLeft",
      "marginRight",
      "marginTop",
      "marker",
      "markerEnd",
      "markerMid",
      "markerStart",
      "mask",
      "maskType",
      "maxBlockSize",
      "maxHeight",
      "maxInlineSize",
      "maxWidth",
      "maxZoom",
      "minBlockSize",
      "minHeight",
      "minInlineSize",
      "minWidth",
      "minZoom",
      "mixBlendMode",
      "objectFit",
      "objectPosition",
      "offset",
      "offsetDistance",
      "offsetPath",
      "offsetRotate",
      "opacity",
      "order",
      "orientation",
      "orphans",
      "outline",
      "outlineColor",
      "outlineOffset",
      "outlineStyle",
      "outlineWidth",
      "overflow",
      "overflowAnchor",
      "overflowWrap",
      "overflowX",
      "overflowY",
      "overscrollBehavior",
      "overscrollBehaviorBlock",
      "overscrollBehaviorInline",
      "overscrollBehaviorX",
      "overscrollBehaviorY",
      "padding",
      "paddingBlock",
      "paddingBlockEnd",
      "paddingBlockStart",
      "paddingBottom",
      "paddingInline",
      "paddingInlineEnd",
      "paddingInlineStart",
      "paddingLeft",
      "paddingRight",
      "paddingTop",
      "page",
      "pageBreakAfter",
      "pageBreakBefore",
      "pageBreakInside",
      "pageOrientation",
      "paintOrder",
      "parentRule",
      "perspective",
      "perspectiveOrigin",
      "placeContent",
      "placeItems",
      "placeSelf",
      "pointerEvents",
      "position",
      "quotes",
      "r",
      "resize",
      "right",
      "rowGap",
      "rubyPosition",
      "rx",
      "ry",
      "scrollBehavior",
      "scrollMargin",
      "scrollMarginBlock",
      "scrollMarginBlockEnd",
      "scrollMarginBlockStart",
      "scrollMarginBottom",
      "scrollMarginInline",
      "scrollMarginInlineEnd",
      "scrollMarginInlineStart",
      "scrollMarginLeft",
      "scrollMarginRight",
      "scrollMarginTop",
      "scrollPadding",
      "scrollPaddingBlock",
      "scrollPaddingBlockEnd",
      "scrollPaddingBlockStart",
      "scrollPaddingBottom",
      "scrollPaddingInline",
      "scrollPaddingInlineEnd",
      "scrollPaddingInlineStart",
      "scrollPaddingLeft",
      "scrollPaddingRight",
      "scrollPaddingTop",
      "scrollSnapAlign",
      "scrollSnapStop",
      "scrollSnapType",
      "shapeImageThreshold",
      "shapeMargin",
      "shapeOutside",
      "shapeRendering",
      "size",
      "speak",
      "src",
      "stopColor",
      "stopOpacity",
      "stroke",
      "strokeDasharray",
      "strokeDashoffset",
      "strokeLinecap",
      "strokeLinejoin",
      "strokeMiterlimit",
      "strokeOpacity",
      "strokeWidth",
      "syntax",
      "tabSize",
      "tableLayout",
      "textAlign",
      "textAlignLast",
      "textAnchor",
      "textCombineUpright",
      "textDecoration",
      "textDecorationColor",
      "textDecorationLine",
      "textDecorationSkipInk",
      "textDecorationStyle",
      "textDecorationThickness",
      "textIndent",
      "textOrientation",
      "textOverflow",
      "textRendering",
      "textShadow",
      "textSizeAdjust",
      "textTransform",
      "textUnderlineOffset",
      "textUnderlinePosition",
      "top",
      "touchAction",
      "transform",
      "transformBox",
      "transformOrigin",
      "transformStyle",
      "transition",
      "transitionDelay",
      "transitionDuration",
      "transitionProperty",
      "transitionTimingFunction",
      "unicodeBidi",
      "unicodeRange",
      "userSelect",
      "userZoom",
      "vectorEffect",
      "verticalAlign",
      "visibility",
      "webkitAlignContent",
      "webkitAlignItems",
      "webkitAlignSelf",
      "webkitAnimation",
      "webkitAnimationDelay",
      "webkitAnimationDirection",
      "webkitAnimationDuration",
      "webkitAnimationFillMode",
      "webkitAnimationIterationCount",
      "webkitAnimationName",
      "webkitAnimationPlayState",
      "webkitAnimationTimingFunction",
      "webkitAppRegion",
      "webkitAppearance",
      "webkitBackfaceVisibility",
      "webkitBackgroundClip",
      "webkitBackgroundOrigin",
      "webkitBackgroundSize",
      "webkitBorderAfter",
      "webkitBorderAfterColor",
      "webkitBorderAfterStyle",
      "webkitBorderAfterWidth",
      "webkitBorderBefore",
      "webkitBorderBeforeColor",
      "webkitBorderBeforeStyle",
      "webkitBorderBeforeWidth",
      "webkitBorderBottomLeftRadius",
      "webkitBorderBottomRightRadius",
      "webkitBorderEnd",
      "webkitBorderEndColor",
      "webkitBorderEndStyle",
      "webkitBorderEndWidth",
      "webkitBorderHorizontalSpacing",
      "webkitBorderImage",
      "webkitBorderRadius",
      "webkitBorderStart",
      "webkitBorderStartColor",
      "webkitBorderStartStyle",
      "webkitBorderStartWidth",
      "webkitBorderTopLeftRadius",
      "webkitBorderTopRightRadius",
      "webkitBorderVerticalSpacing",
      "webkitBoxAlign",
      "webkitBoxDecorationBreak",
      "webkitBoxDirection",
      "webkitBoxFlex",
      "webkitBoxOrdinalGroup",
      "webkitBoxOrient",
      "webkitBoxPack",
      "webkitBoxReflect",
      "webkitBoxShadow",
      "webkitBoxSizing",
      "webkitClipPath",
      "webkitColumnBreakAfter",
      "webkitColumnBreakBefore",
      "webkitColumnBreakInside",
      "webkitColumnCount",
      "webkitColumnGap",
      "webkitColumnRule",
      "webkitColumnRuleColor",
      "webkitColumnRuleStyle",
      "webkitColumnRuleWidth",
      "webkitColumnSpan",
      "webkitColumnWidth",
      "webkitColumns",
      "webkitFilter",
      "webkitFlex",
      "webkitFlexBasis",
      "webkitFlexDirection",
      "webkitFlexFlow",
      "webkitFlexGrow",
      "webkitFlexShrink",
      "webkitFlexWrap",
      "webkitFontFeatureSettings",
      "webkitFontSmoothing",
      "webkitHighlight",
      "webkitHyphenateCharacter",
      "webkitJustifyContent",
      "webkitLineBreak",
      "webkitLineClamp",
      "webkitLocale",
      "webkitLogicalHeight",
      "webkitLogicalWidth",
      "webkitMarginAfter",
      "webkitMarginBefore",
      "webkitMarginEnd",
      "webkitMarginStart",
      "webkitMask",
      "webkitMaskBoxImage",
      "webkitMaskBoxImageOutset",
      "webkitMaskBoxImageRepeat",
      "webkitMaskBoxImageSlice",
      "webkitMaskBoxImageSource",
      "webkitMaskBoxImageWidth",
      "webkitMaskClip",
      "webkitMaskComposite",
      "webkitMaskImage",
      "webkitMaskOrigin",
      "webkitMaskPosition",
      "webkitMaskPositionX",
      "webkitMaskPositionY",
      "webkitMaskRepeat",
      "webkitMaskRepeatX",
      "webkitMaskRepeatY",
      "webkitMaskSize",
      "webkitMaxLogicalHeight",
      "webkitMaxLogicalWidth",
      "webkitMinLogicalHeight",
      "webkitMinLogicalWidth",
      "webkitOpacity",
      "webkitOrder",
      "webkitPaddingAfter",
      "webkitPaddingBefore",
      "webkitPaddingEnd",
      "webkitPaddingStart",
      "webkitPerspective",
      "webkitPerspectiveOrigin",
      "webkitPerspectiveOriginX",
      "webkitPerspectiveOriginY",
      "webkitPrintColorAdjust",
      "webkitRtlOrdering",
      "webkitRubyPosition",
      "webkitShapeImageThreshold",
      "webkitShapeMargin",
      "webkitShapeOutside",
      "webkitTapHighlightColor",
      "webkitTextCombine",
      "webkitTextDecorationsInEffect",
      "webkitTextEmphasis",
      "webkitTextEmphasisColor",
      "webkitTextEmphasisPosition",
      "webkitTextEmphasisStyle",
      "webkitTextFillColor",
      "webkitTextOrientation",
      "webkitTextSecurity",
      "webkitTextSizeAdjust",
      "webkitTextStroke",
      "webkitTextStrokeColor",
      "webkitTextStrokeWidth",
      "webkitTransform",
      "webkitTransformOrigin",
      "webkitTransformOriginX",
      "webkitTransformOriginY",
      "webkitTransformOriginZ",
      "webkitTransformStyle",
      "webkitTransition",
      "webkitTransitionDelay",
      "webkitTransitionDuration",
      "webkitTransitionProperty",
      "webkitTransitionTimingFunction",
      "webkitUserDrag",
      "webkitUserModify",
      "webkitUserSelect",
      "webkitWritingMode",
      "whiteSpace",
      "widows",
      "width",
      "willfon",
      "wordBreak",
      "wordSpacing",
      "wordWrap",
      "writingMode",
      "x",
      "y",
      "zIndex",
      "zoom",
    ]);
    const createTr = document.createElement("tr");
    $(createTr).css("alignContent", trStyle["alignContent"]);
    $(createTr).css("alignItems", trStyle["alignItems"]);
    $(createTr).css("alignSelf", trStyle["alignSelf"]);
    $(createTr).css("alignmentBaseline", trStyle["alignmentBaseline"]);
    $(createTr).css("all", trStyle["all"]);
    $(createTr).css("animation", trStyle["animation"]);
    $(createTr).css("animationDelay", trStyle["animationDelay"]);
    $(createTr).css("animationDirection", trStyle["animationDirection"]);
    $(createTr).css("animationDuration", trStyle["animationDuration"]);
    $(createTr).css("animationFillMode", trStyle["animationFillMode"]);
    $(createTr).css(
      "animationIterationCount",
      trStyle["animationIterationCount"]
    );
    $(createTr).css("animationName", trStyle["animationName"]);
    $(createTr).css("animationPlayState", trStyle["animationPlayState"]);
    $(createTr).css(
      "animationTimingFunction",
      trStyle["animationTimingFunction"]
    );
    $(createTr).css("appearance", trStyle["appearance"]);
    $(createTr).css("ascentOverride", trStyle["ascentOverride"]);
    $(createTr).css("backdropFilter", trStyle["backdropFilter"]);
    $(createTr).css("backfaceVisibility", trStyle["backfaceVisibility"]);
    $(createTr).css("background", trStyle["background"]);
    $(createTr).css("backgroundAttachment", trStyle["backgroundAttachment"]);
    $(createTr).css("backgroundBlendMode", trStyle["backgroundBlendMode"]);
    $(createTr).css("backgroundClip", trStyle["backgroundClip"]);
    $(createTr).css("backgroundColor", trStyle["backgroundColor"]);
    $(createTr).css("backgroundImage", trStyle["backgroundImage"]);
    $(createTr).css("backgroundOrigin", trStyle["backgroundOrigin"]);
    $(createTr).css("backgroundPosition", trStyle["backgroundPosition"]);
    $(createTr).css("backgroundPositionX", trStyle["backgroundPositionX"]);
    $(createTr).css("backgroundPositionY", trStyle["backgroundPositionY"]);
    $(createTr).css("backgroundRepeat", trStyle["backgroundRepeat"]);
    $(createTr).css("backgroundRepeatX", trStyle["backgroundRepeatX"]);
    $(createTr).css("backgroundRepeatY", trStyle["backgroundRepeatY"]);
    $(createTr).css("backgroundSize", trStyle["backgroundSize"]);
    $(createTr).css("baselineShift", trStyle["baselineShift"]);
    $(createTr).css("blockSize", trStyle["blockSize"]);
    $(createTr).css("border", trStyle["border"]);
    $(createTr).css("borderBlock", trStyle["borderBlock"]);
    $(createTr).css("borderBlockColor", trStyle["borderBlockColor"]);
    $(createTr).css("borderBlockEnd", trStyle["borderBlockEnd"]);
    $(createTr).css("borderBlockEndColor", trStyle["borderBlockEndColor"]);
    $(createTr).css("borderBlockEndStyle", trStyle["borderBlockEndStyle"]);
    $(createTr).css("borderBlockEndWidth", trStyle["borderBlockEndWidth"]);
    $(createTr).css("borderBlockStart", trStyle["borderBlockStart"]);
    $(createTr).css("borderBlockStartColor", trStyle["borderBlockStartColor"]);
    $(createTr).css("borderBlockStartStyle", trStyle["borderBlockStartStyle"]);
    $(createTr).css("borderBlockStartWidth", trStyle["borderBlockStartWidth"]);
    $(createTr).css("borderBlockStyle", trStyle["borderBlockStyle"]);
    $(createTr).css("borderBlockWidth", trStyle["borderBlockWidth"]);
    $(createTr).css("borderBottom", trStyle["borderBottom"]);
    $(createTr).css("borderBottomColor", trStyle["borderBottomColor"]);
    $(createTr).css(
      "borderBottomLeftRadius",
      trStyle["borderBottomLeftRadius"]
    );
    $(createTr).css(
      "borderBottomRightRadius",
      trStyle["borderBottomRightRadius"]
    );
    $(createTr).css("borderBottomStyle", trStyle["borderBottomStyle"]);
    $(createTr).css("borderBottomWidth", trStyle["borderBottomWidth"]);
    $(createTr).css("borderCollapse", trStyle["borderCollapse"]);
    $(createTr).css("borderColor", trStyle["borderColor"]);
    $(createTr).css("borderImage", trStyle["borderImage"]);
    $(createTr).css("borderImageOutset", trStyle["borderImageOutset"]);
    $(createTr).css("borderImageRepeat", trStyle["borderImageRepeat"]);
    $(createTr).css("borderImageSlice", trStyle["borderImageSlice"]);
    $(createTr).css("borderImageSource", trStyle["borderImageSource"]);
    $(createTr).css("borderImageWidth", trStyle["borderImageWidth"]);
    $(createTr).css("borderInline", trStyle["borderInline"]);
    $(createTr).css("borderInlineColor", trStyle["borderInlineColor"]);
    $(createTr).css("borderInlineEnd", trStyle["borderInlineEnd"]);
    $(createTr).css("borderInlineEndColor", trStyle["borderInlineEndColor"]);
    $(createTr).css("borderInlineEndStyle", trStyle["borderInlineEndStyle"]);
    $(createTr).css("borderInlineEndWidth", trStyle["borderInlineEndWidth"]);
    $(createTr).css("borderInlineStart", trStyle["borderInlineStart"]);
    $(createTr).css(
      "borderInlineStartColor",
      trStyle["borderInlineStartColor"]
    );
    $(createTr).css(
      "borderInlineStartStyle",
      trStyle["borderInlineStartStyle"]
    );
    $(createTr).css(
      "borderInlineStartWidth",
      trStyle["borderInlineStartWidth"]
    );
    $(createTr).css("borderInlineStyle", trStyle["borderInlineStyle"]);
    $(createTr).css("borderInlineWidth", trStyle["borderInlineWidth"]);
    $(createTr).css("borderLeft", trStyle["borderLeft"]);
    $(createTr).css("borderLeftColor", trStyle["borderLeftColor"]);
    $(createTr).css("borderLeftStyle", trStyle["borderLeftStyle"]);
    $(createTr).css("borderLeftWidth", trStyle["borderLeftWidth"]);
    $(createTr).css("borderRadius", trStyle["borderRadius"]);
    $(createTr).css("borderRight", trStyle["borderRight"]);
    $(createTr).css("borderRightColor", trStyle["borderRightColor"]);
    $(createTr).css("borderRightStyle", trStyle["borderRightStyle"]);
    $(createTr).css("borderRightWidth", trStyle["borderRightWidth"]);
    $(createTr).css("borderSpacing", trStyle["borderSpacing"]);
    $(createTr).css("borderStyle", trStyle["borderStyle"]);
    $(createTr).css("borderTop", trStyle["borderTop"]);
    $(createTr).css("borderTopColor", trStyle["borderTopColor"]);
    $(createTr).css("borderTopLeftRadius", trStyle["borderTopLeftRadius"]);
    $(createTr).css("borderTopRightRadius", trStyle["borderTopRightRadius"]);
    $(createTr).css("borderTopStyle", trStyle["borderTopStyle"]);
    $(createTr).css("borderTopWidth", trStyle["borderTopWidth"]);
    $(createTr).css("borderWidth", trStyle["borderWidth"]);
    $(createTr).css("bottom", trStyle["bottom"]);
    $(createTr).css("boxShadow", trStyle["boxShadow"]);
    $(createTr).css("boxSizing", trStyle["boxSizing"]);
    $(createTr).css("breakAfter", trStyle["breakAfter"]);
    $(createTr).css("breakBefore", trStyle["breakBefore"]);
    $(createTr).css("breakInside", trStyle["breakInside"]);
    $(createTr).css("bufferedRendering", trStyle["bufferedRendering"]);
    $(createTr).css("captionSide", trStyle["captionSide"]);
    $(createTr).css("caretColor", trStyle["caretColor"]);
    $(createTr).css("clear", trStyle["clear"]);
    $(createTr).css("clip", trStyle["clip"]);
    $(createTr).css("clipPath", trStyle["clipPath"]);
    $(createTr).css("clipRule", trStyle["clipRule"]);
    $(createTr).css("color", trStyle["color"]);
    $(createTr).css("colorInterpolation", trStyle["colorInterpolation"]);
    $(createTr).css(
      "colorInterpolationFilters",
      trStyle["colorInterpolationFilters"]
    );
    $(createTr).css("colorRendering", trStyle["colorRendering"]);
    $(createTr).css("colorScheme", trStyle["colorScheme"]);
    $(createTr).css("columnCount", trStyle["columnCount"]);
    $(createTr).css("columnFill", trStyle["columnFill"]);
    $(createTr).css("columnGap", trStyle["columnGap"]);
    $(createTr).css("columnRule", trStyle["columnRule"]);
    $(createTr).css("columnRuleColor", trStyle["columnRuleColor"]);
    $(createTr).css("columnRuleStyle", trStyle["columnRuleStyle"]);
    $(createTr).css("columnRuleWidth", trStyle["columnRuleWidth"]);
    $(createTr).css("columnSpan", trStyle["columnSpan"]);
    $(createTr).css("columnWidth", trStyle["columnWidth"]);
    $(createTr).css("columns", trStyle["columns"]);
    $(createTr).css("contain", trStyle["contain"]);
    $(createTr).css("containIntrinsicSize", trStyle["containIntrinsicSize"]);
    $(createTr).css("content", trStyle["content"]);
    $(createTr).css("contentVisibility", trStyle["contentVisibility"]);
    $(createTr).css("counterIncrement", trStyle["counterIncrement"]);
    $(createTr).css("counterReset", trStyle["counterReset"]);
    $(createTr).css("counterSet", trStyle["counterSet"]);
    $(createTr).css("cssFloat", trStyle["cssFloat"]);
    $(createTr).css("cssText", trStyle["cssText"]);
    $(createTr).css("cursor", trStyle["cursor"]);
    $(createTr).css("cx", trStyle["cx"]);
    $(createTr).css("cy", trStyle["cy"]);
    $(createTr).css("d", trStyle["d"]);
    $(createTr).css("descentOverride", trStyle["descentOverride"]);
    $(createTr).css("direction", trStyle["direction"]);
    $(createTr).css("display", trStyle["display"]);
    $(createTr).css("dominantBaseline", trStyle["dominantBaseline"]);
    $(createTr).css("emptyCells", trStyle["emptyCells"]);
    $(createTr).css("fill", trStyle["fill"]);
    $(createTr).css("fillOpacity", trStyle["fillOpacity"]);
    $(createTr).css("fillRule", trStyle["fillRule"]);
    $(createTr).css("filter", trStyle["filter"]);
    $(createTr).css("flex", trStyle["flex"]);
    $(createTr).css("flexBasis", trStyle["flexBasis"]);
    $(createTr).css("flexDirection", trStyle["flexDirection"]);
    $(createTr).css("flexFlow", trStyle["flexFlow"]);
    $(createTr).css("flexGrow", trStyle["flexGrow"]);
    $(createTr).css("flexShrink", trStyle["flexShrink"]);
    $(createTr).css("flexWrap", trStyle["flexWrap"]);
    $(createTr).css("float", trStyle["float"]);
    $(createTr).css("floodColor", trStyle["floodColor"]);
    $(createTr).css("floodOpacity", trStyle["floodOpacity"]);
    $(createTr).css("font", trStyle["font"]);
    $(createTr).css("fontDisplay", trStyle["fontDisplay"]);
    $(createTr).css("fontFamily", trStyle["fontFamily"]);
    $(createTr).css("fontFeatureSettings", trStyle["fontFeatureSettings"]);
    $(createTr).css("fontKerning", trStyle["fontKerning"]);
    $(createTr).css("fontOpticalSizing", trStyle["fontOpticalSizing"]);
    $(createTr).css("fontSize", trStyle["fontSize"]);
    $(createTr).css("fontStretch", trStyle["fontStretch"]);
    $(createTr).css("fontStyle", trStyle["fontStyle"]);
    $(createTr).css("fontVariant", trStyle["fontVariant"]);
    $(createTr).css("fontVariantCaps", trStyle["fontVariantCaps"]);
    $(createTr).css("fontVariantEastAsian", trStyle["fontVariantEastAsian"]);
    $(createTr).css("fontVariantLigatures", trStyle["fontVariantLigatures"]);
    $(createTr).css("fontVariantNumeric", trStyle["fontVariantNumeric"]);
    $(createTr).css("fontVariationSettings", trStyle["fontVariationSettings"]);
    $(createTr).css("fontWeight", trStyle["fontWeight"]);
    $(createTr).css("gap", trStyle["gap"]);
    $(createTr).css("grid", trStyle["grid"]);
    $(createTr).css("gridArea", trStyle["gridArea"]);
    $(createTr).css("gridAutoColumns", trStyle["gridAutoColumns"]);
    $(createTr).css("gridAutoFlow", trStyle["gridAutoFlow"]);
    $(createTr).css("gridAutoRows", trStyle["gridAutoRows"]);
    $(createTr).css("gridColumn", trStyle["gridColumn"]);
    $(createTr).css("gridColumnEnd", trStyle["gridColumnEnd"]);
    $(createTr).css("gridColumnGap", trStyle["gridColumnGap"]);
    $(createTr).css("gridColumnStart", trStyle["gridColumnStart"]);
    $(createTr).css("gridGap", trStyle["gridGap"]);
    $(createTr).css("gridRow", trStyle["gridRow"]);
    $(createTr).css("gridRowEnd", trStyle["gridRowEnd"]);
    $(createTr).css("gridRowGap", trStyle["gridRowGap"]);
    $(createTr).css("gridRowStart", trStyle["gridRowStart"]);
    $(createTr).css("gridTemplate", trStyle["gridTemplate"]);
    $(createTr).css("gridTemplateAreas", trStyle["gridTemplateAreas"]);
    $(createTr).css("gridTemplateColumns", trStyle["gridTemplateColumns"]);
    $(createTr).css("gridTemplateRows", trStyle["gridTemplateRows"]);
    $(createTr).css("height", trStyle["height"]);
    $(createTr).css("hyphens", trStyle["hyphens"]);
    $(createTr).css("imageOrientation", trStyle["imageOrientation"]);
    $(createTr).css("imageRendering", trStyle["imageRendering"]);
    $(createTr).css("inherits", trStyle["inherits"]);
    $(createTr).css("initialValue", trStyle["initialValue"]);
    $(createTr).css("inlineSize", trStyle["inlineSize"]);
    $(createTr).css("inset", trStyle["inset"]);
    $(createTr).css("insetBlock", trStyle["insetBlock"]);
    $(createTr).css("insetBlockEnd", trStyle["insetBlockEnd"]);
    $(createTr).css("insetBlockStart", trStyle["insetBlockStart"]);
    $(createTr).css("insetInline", trStyle["insetInline"]);
    $(createTr).css("insetInlineEnd", trStyle["insetInlineEnd"]);
    $(createTr).css("insetInlineStart", trStyle["insetInlineStart"]);
    $(createTr).css("isolation", trStyle["isolation"]);
    $(createTr).css("justifyContent", trStyle["justifyContent"]);
    $(createTr).css("justifyItems", trStyle["justifyItems"]);
    $(createTr).css("justifySelf", trStyle["justifySelf"]);
    $(createTr).css("left", trStyle["left"]);
    //    $(createTr).css("length",trStyle["length"]);
    $(createTr).css("letterSpacing", trStyle["letterSpacing"]);
    $(createTr).css("lightingColor", trStyle["lightingColor"]);
    $(createTr).css("lineBreak", trStyle["lineBreak"]);
    $(createTr).css("lineGapOverride", trStyle["lineGapOverride"]);
    $(createTr).css("lineHeight", trStyle["lineHeight"]);
    $(createTr).css("listStyle", trStyle["listStyle"]);
    $(createTr).css("listStyleImage", trStyle["listStyleImage"]);
    $(createTr).css("listStylePosition", trStyle["listStylePosition"]);
    $(createTr).css("listStyleType", trStyle["listStyleType"]);
    $(createTr).css("margin", trStyle["margin"]);
    $(createTr).css("marginBlock", trStyle["marginBlock"]);
    $(createTr).css("marginBlockEnd", trStyle["marginBlockEnd"]);
    $(createTr).css("marginBlockStart", trStyle["marginBlockStart"]);
    $(createTr).css("marginBottom", trStyle["marginBottom"]);
    $(createTr).css("marginInline", trStyle["marginInline"]);
    $(createTr).css("marginInlineEnd", trStyle["marginInlineEnd"]);
    $(createTr).css("marginInlineStart", trStyle["marginInlineStart"]);
    $(createTr).css("marginLeft", trStyle["marginLeft"]);
    $(createTr).css("marginRight", trStyle["marginRight"]);
    $(createTr).css("marginTop", trStyle["marginTop"]);
    $(createTr).css("marker", trStyle["marker"]);
    $(createTr).css("markerEnd", trStyle["markerEnd"]);
    $(createTr).css("markerMid", trStyle["markerMid"]);
    $(createTr).css("markerStart", trStyle["markerStart"]);
    $(createTr).css("mask", trStyle["mask"]);
    $(createTr).css("maskType", trStyle["maskType"]);
    $(createTr).css("maxBlockSize", trStyle["maxBlockSize"]);
    $(createTr).css("maxHeight", trStyle["maxHeight"]);
    $(createTr).css("maxInlineSize", trStyle["maxInlineSize"]);
    $(createTr).css("maxWidth", trStyle["maxWidth"]);
    $(createTr).css("maxZoom", trStyle["maxZoom"]);
    $(createTr).css("minBlockSize", trStyle["minBlockSize"]);
    $(createTr).css("minHeight", trStyle["minHeight"]);
    $(createTr).css("minInlineSize", trStyle["minInlineSize"]);
    $(createTr).css("minWidth", trStyle["minWidth"]);
    $(createTr).css("minZoom", trStyle["minZoom"]);
    $(createTr).css("mixBlendMode", trStyle["mixBlendMode"]);
    $(createTr).css("objectFit", trStyle["objectFit"]);
    $(createTr).css("objectPosition", trStyle["objectPosition"]);
    $(createTr).css("offset", trStyle["offset"]);
    $(createTr).css("offsetDistance", trStyle["offsetDistance"]);
    $(createTr).css("offsetPath", trStyle["offsetPath"]);
    $(createTr).css("offsetRotate", trStyle["offsetRotate"]);
    $(createTr).css("opacity", trStyle["opacity"]);
    $(createTr).css("order", trStyle["order"]);
    $(createTr).css("orientation", trStyle["orientation"]);
    $(createTr).css("orphans", trStyle["orphans"]);
    $(createTr).css("outline", trStyle["outline"]);
    $(createTr).css("outlineColor", trStyle["outlineColor"]);
    $(createTr).css("outlineOffset", trStyle["outlineOffset"]);
    $(createTr).css("outlineStyle", trStyle["outlineStyle"]);
    $(createTr).css("outlineWidth", trStyle["outlineWidth"]);
    $(createTr).css("overflow", trStyle["overflow"]);
    $(createTr).css("overflowAnchor", trStyle["overflowAnchor"]);
    $(createTr).css("overflowWrap", trStyle["overflowWrap"]);
    $(createTr).css("overflowX", trStyle["overflowX"]);
    $(createTr).css("overflowY", trStyle["overflowY"]);
    $(createTr).css("overscrollBehavior", trStyle["overscrollBehavior"]);
    $(createTr).css(
      "overscrollBehaviorBlock",
      trStyle["overscrollBehaviorBlock"]
    );
    $(createTr).css(
      "overscrollBehaviorInline",
      trStyle["overscrollBehaviorInline"]
    );
    $(createTr).css("overscrollBehaviorX", trStyle["overscrollBehaviorX"]);
    $(createTr).css("overscrollBehaviorY", trStyle["overscrollBehaviorY"]);
    $(createTr).css("padding", trStyle["padding"]);
    $(createTr).css("paddingBlock", trStyle["paddingBlock"]);
    $(createTr).css("paddingBlockEnd", trStyle["paddingBlockEnd"]);
    $(createTr).css("paddingBlockStart", trStyle["paddingBlockStart"]);
    $(createTr).css("paddingBottom", trStyle["paddingBottom"]);
    $(createTr).css("paddingInline", trStyle["paddingInline"]);
    $(createTr).css("paddingInlineEnd", trStyle["paddingInlineEnd"]);
    $(createTr).css("paddingInlineStart", trStyle["paddingInlineStart"]);
    $(createTr).css("paddingLeft", trStyle["paddingLeft"]);
    $(createTr).css("paddingRight", trStyle["paddingRight"]);
    $(createTr).css("paddingTop", trStyle["paddingTop"]);
    $(createTr).css("page", trStyle["page"]);
    $(createTr).css("pageBreakAfter", trStyle["pageBreakAfter"]);
    $(createTr).css("pageBreakBefore", trStyle["pageBreakBefore"]);
    $(createTr).css("pageBreakInside", trStyle["pageBreakInside"]);
    $(createTr).css("pageOrientation", trStyle["pageOrientation"]);
    $(createTr).css("paintOrder", trStyle["paintOrder"]);
    //    $(createTr).css("parentRule",trStyle["parentRule"]);
    $(createTr).css("perspective", trStyle["perspective"]);
    $(createTr).css("perspectiveOrigin", trStyle["perspectiveOrigin"]);
    $(createTr).css("placeContent", trStyle["placeContent"]);
    $(createTr).css("placeItems", trStyle["placeItems"]);
    $(createTr).css("placeSelf", trStyle["placeSelf"]);
    $(createTr).css("pointerEvents", trStyle["pointerEvents"]);
    $(createTr).css("position", trStyle["position"]);
    $(createTr).css("quotes", trStyle["quotes"]);
    $(createTr).css("r", trStyle["r"]);
    $(createTr).css("resize", trStyle["resize"]);
    $(createTr).css("right", trStyle["right"]);
    $(createTr).css("rowGap", trStyle["rowGap"]);
    $(createTr).css("rubyPosition", trStyle["rubyPosition"]);
    $(createTr).css("rx", trStyle["rx"]);
    $(createTr).css("ry", trStyle["ry"]);
    $(createTr).css("scrollBehavior", trStyle["scrollBehavior"]);
    $(createTr).css("scrollMargin", trStyle["scrollMargin"]);
    $(createTr).css("scrollMarginBlock", trStyle["scrollMarginBlock"]);
    $(createTr).css("scrollMarginBlockEnd", trStyle["scrollMarginBlockEnd"]);
    $(createTr).css(
      "scrollMarginBlockStart",
      trStyle["scrollMarginBlockStart"]
    );
    $(createTr).css("scrollMarginBottom", trStyle["scrollMarginBottom"]);
    $(createTr).css("scrollMarginInline", trStyle["scrollMarginInline"]);
    $(createTr).css("scrollMarginInlineEnd", trStyle["scrollMarginInlineEnd"]);
    $(createTr).css(
      "scrollMarginInlineStart",
      trStyle["scrollMarginInlineStart"]
    );
    $(createTr).css("scrollMarginLeft", trStyle["scrollMarginLeft"]);
    $(createTr).css("scrollMarginRight", trStyle["scrollMarginRight"]);
    $(createTr).css("scrollMarginTop", trStyle["scrollMarginTop"]);
    $(createTr).css("scrollPadding", trStyle["scrollPadding"]);
    $(createTr).css("scrollPaddingBlock", trStyle["scrollPaddingBlock"]);
    $(createTr).css("scrollPaddingBlockEnd", trStyle["scrollPaddingBlockEnd"]);
    $(createTr).css(
      "scrollPaddingBlockStart",
      trStyle["scrollPaddingBlockStart"]
    );
    $(createTr).css("scrollPaddingBottom", trStyle["scrollPaddingBottom"]);
    $(createTr).css("scrollPaddingInline", trStyle["scrollPaddingInline"]);
    $(createTr).css(
      "scrollPaddingInlineEnd",
      trStyle["scrollPaddingInlineEnd"]
    );
    $(createTr).css(
      "scrollPaddingInlineStart",
      trStyle["scrollPaddingInlineStart"]
    );
    $(createTr).css("scrollPaddingLeft", trStyle["scrollPaddingLeft"]);
    $(createTr).css("scrollPaddingRight", trStyle["scrollPaddingRight"]);
    $(createTr).css("scrollPaddingTop", trStyle["scrollPaddingTop"]);
    $(createTr).css("scrollSnapAlign", trStyle["scrollSnapAlign"]);
    $(createTr).css("scrollSnapStop", trStyle["scrollSnapStop"]);
    $(createTr).css("scrollSnapType", trStyle["scrollSnapType"]);
    $(createTr).css("shapeImageThreshold", trStyle["shapeImageThreshold"]);
    $(createTr).css("shapeMargin", trStyle["shapeMargin"]);
    $(createTr).css("shapeOutside", trStyle["shapeOutside"]);
    $(createTr).css("shapeRendering", trStyle["shapeRendering"]);
    $(createTr).css("size", trStyle["size"]);
    $(createTr).css("speak", trStyle["speak"]);
    $(createTr).css("src", trStyle["src"]);
    $(createTr).css("stopColor", trStyle["stopColor"]);
    $(createTr).css("stopOpacity", trStyle["stopOpacity"]);
    $(createTr).css("stroke", trStyle["stroke"]);
    $(createTr).css("strokeDasharray", trStyle["strokeDasharray"]);
    $(createTr).css("strokeDashoffset", trStyle["strokeDashoffset"]);
    $(createTr).css("strokeLinecap", trStyle["strokeLinecap"]);
    $(createTr).css("strokeLinejoin", trStyle["strokeLinejoin"]);
    $(createTr).css("strokeMiterlimit", trStyle["strokeMiterlimit"]);
    $(createTr).css("strokeOpacity", trStyle["strokeOpacity"]);
    $(createTr).css("strokeWidth", trStyle["strokeWidth"]);
    $(createTr).css("syntax", trStyle["syntax"]);
    $(createTr).css("tabSize", trStyle["tabSize"]);
    $(createTr).css("tableLayout", trStyle["tableLayout"]);
    $(createTr).css("textAlign", trStyle["textAlign"]);
    $(createTr).css("textAlignLast", trStyle["textAlignLast"]);
    $(createTr).css("textAnchor", trStyle["textAnchor"]);
    $(createTr).css("textCombineUpright", trStyle["textCombineUpright"]);
    $(createTr).css("textDecoration", trStyle["textDecoration"]);
    $(createTr).css("textDecorationColor", trStyle["textDecorationColor"]);
    $(createTr).css("textDecorationLine", trStyle["textDecorationLine"]);
    $(createTr).css("textDecorationSkipInk", trStyle["textDecorationSkipInk"]);
    $(createTr).css("textDecorationStyle", trStyle["textDecorationStyle"]);
    $(createTr).css(
      "textDecorationThickness",
      trStyle["textDecorationThickness"]
    );
    $(createTr).css("textIndent", trStyle["textIndent"]);
    $(createTr).css("textOrientation", trStyle["textOrientation"]);
    $(createTr).css("textOverflow", trStyle["textOverflow"]);
    $(createTr).css("textRendering", trStyle["textRendering"]);
    $(createTr).css("textShadow", trStyle["textShadow"]);
    $(createTr).css("textSizeAdjust", trStyle["textSizeAdjust"]);
    $(createTr).css("textTransform", trStyle["textTransform"]);
    $(createTr).css("textUnderlineOffset", trStyle["textUnderlineOffset"]);
    $(createTr).css("textUnderlinePosition", trStyle["textUnderlinePosition"]);
    $(createTr).css("top", trStyle["top"]);
    $(createTr).css("touchAction", trStyle["touchAction"]);
    $(createTr).css("transform", trStyle["transform"]);
    $(createTr).css("transformBox", trStyle["transformBox"]);
    $(createTr).css("transformOrigin", trStyle["transformOrigin"]);
    $(createTr).css("transformStyle", trStyle["transformStyle"]);
    $(createTr).css("transition", trStyle["transition"]);
    $(createTr).css("transitionDelay", trStyle["transitionDelay"]);
    $(createTr).css("transitionDuration", trStyle["transitionDuration"]);
    $(createTr).css("transitionProperty", trStyle["transitionProperty"]);
    $(createTr).css(
      "transitionTimingFunction",
      trStyle["transitionTimingFunction"]
    );
    $(createTr).css("unicodeBidi", trStyle["unicodeBidi"]);
    $(createTr).css("unicodeRange", trStyle["unicodeRange"]);
    $(createTr).css("userSelect", trStyle["userSelect"]);
    $(createTr).css("userZoom", trStyle["userZoom"]);
    $(createTr).css("vectorEffect", trStyle["vectorEffect"]);
    $(createTr).css("verticalAlign", trStyle["verticalAlign"]);
    $(createTr).css("visibility", trStyle["visibility"]);
    $(createTr).css("webkitAlignContent", trStyle["webkitAlignContent"]);
    $(createTr).css("webkitAlignItems", trStyle["webkitAlignItems"]);
    $(createTr).css("webkitAlignSelf", trStyle["webkitAlignSelf"]);
    $(createTr).css("webkitAnimation", trStyle["webkitAnimation"]);
    $(createTr).css("webkitAnimationDelay", trStyle["webkitAnimationDelay"]);
    $(createTr).css(
      "webkitAnimationDirection",
      trStyle["webkitAnimationDirection"]
    );
    $(createTr).css(
      "webkitAnimationDuration",
      trStyle["webkitAnimationDuration"]
    );
    $(createTr).css(
      "webkitAnimationFillMode",
      trStyle["webkitAnimationFillMode"]
    );
    $(createTr).css(
      "webkitAnimationIterationCount",
      trStyle["webkitAnimationIterationCount"]
    );
    $(createTr).css("webkitAnimationName", trStyle["webkitAnimationName"]);
    $(createTr).css(
      "webkitAnimationPlayState",
      trStyle["webkitAnimationPlayState"]
    );
    $(createTr).css(
      "webkitAnimationTimingFunction",
      trStyle["webkitAnimationTimingFunction"]
    );
    $(createTr).css("webkitAppRegion", trStyle["webkitAppRegion"]);
    $(createTr).css("webkitAppearance", trStyle["webkitAppearance"]);
    $(createTr).css(
      "webkitBackfaceVisibility",
      trStyle["webkitBackfaceVisibility"]
    );
    $(createTr).css("webkitBackgroundClip", trStyle["webkitBackgroundClip"]);
    $(createTr).css(
      "webkitBackgroundOrigin",
      trStyle["webkitBackgroundOrigin"]
    );
    $(createTr).css("webkitBackgroundSize", trStyle["webkitBackgroundSize"]);
    $(createTr).css("webkitBorderAfter", trStyle["webkitBorderAfter"]);
    $(createTr).css(
      "webkitBorderAfterColor",
      trStyle["webkitBorderAfterColor"]
    );
    $(createTr).css(
      "webkitBorderAfterStyle",
      trStyle["webkitBorderAfterStyle"]
    );
    $(createTr).css(
      "webkitBorderAfterWidth",
      trStyle["webkitBorderAfterWidth"]
    );
    $(createTr).css("webkitBorderBefore", trStyle["webkitBorderBefore"]);
    $(createTr).css(
      "webkitBorderBeforeColor",
      trStyle["webkitBorderBeforeColor"]
    );
    $(createTr).css(
      "webkitBorderBeforeStyle",
      trStyle["webkitBorderBeforeStyle"]
    );
    $(createTr).css(
      "webkitBorderBeforeWidth",
      trStyle["webkitBorderBeforeWidth"]
    );
    $(createTr).css(
      "webkitBorderBottomLeftRadius",
      trStyle["webkitBorderBottomLeftRadius"]
    );
    $(createTr).css(
      "webkitBorderBottomRightRadius",
      trStyle["webkitBorderBottomRightRadius"]
    );
    $(createTr).css("webkitBorderEnd", trStyle["webkitBorderEnd"]);
    $(createTr).css("webkitBorderEndColor", trStyle["webkitBorderEndColor"]);
    $(createTr).css("webkitBorderEndStyle", trStyle["webkitBorderEndStyle"]);
    $(createTr).css("webkitBorderEndWidth", trStyle["webkitBorderEndWidth"]);
    $(createTr).css(
      "webkitBorderHorizontalSpacing",
      trStyle["webkitBorderHorizontalSpacing"]
    );
    $(createTr).css("webkitBorderImage", trStyle["webkitBorderImage"]);
    $(createTr).css("webkitBorderRadius", trStyle["webkitBorderRadius"]);
    $(createTr).css("webkitBorderStart", trStyle["webkitBorderStart"]);
    $(createTr).css(
      "webkitBorderStartColor",
      trStyle["webkitBorderStartColor"]
    );
    $(createTr).css(
      "webkitBorderStartStyle",
      trStyle["webkitBorderStartStyle"]
    );
    $(createTr).css(
      "webkitBorderStartWidth",
      trStyle["webkitBorderStartWidth"]
    );
    $(createTr).css(
      "webkitBorderTopLeftRadius",
      trStyle["webkitBorderTopLeftRadius"]
    );
    $(createTr).css(
      "webkitBorderTopRightRadius",
      trStyle["webkitBorderTopRightRadius"]
    );
    $(createTr).css(
      "webkitBorderVerticalSpacing",
      trStyle["webkitBorderVerticalSpacing"]
    );
    $(createTr).css("webkitBoxAlign", trStyle["webkitBoxAlign"]);
    $(createTr).css(
      "webkitBoxDecorationBreak",
      trStyle["webkitBoxDecorationBreak"]
    );
    $(createTr).css("webkitBoxDirection", trStyle["webkitBoxDirection"]);
    $(createTr).css("webkitBoxFlex", trStyle["webkitBoxFlex"]);
    $(createTr).css("webkitBoxOrdinalGroup", trStyle["webkitBoxOrdinalGroup"]);
    $(createTr).css("webkitBoxOrient", trStyle["webkitBoxOrient"]);
    $(createTr).css("webkitBoxPack", trStyle["webkitBoxPack"]);
    $(createTr).css("webkitBoxReflect", trStyle["webkitBoxReflect"]);
    $(createTr).css("webkitBoxShadow", trStyle["webkitBoxShadow"]);
    $(createTr).css("webkitBoxSizing", trStyle["webkitBoxSizing"]);
    $(createTr).css("webkitClipPath", trStyle["webkitClipPath"]);
    $(createTr).css(
      "webkitColumnBreakAfter",
      trStyle["webkitColumnBreakAfter"]
    );
    $(createTr).css(
      "webkitColumnBreakBefore",
      trStyle["webkitColumnBreakBefore"]
    );
    $(createTr).css(
      "webkitColumnBreakInside",
      trStyle["webkitColumnBreakInside"]
    );
    $(createTr).css("webkitColumnCount", trStyle["webkitColumnCount"]);
    $(createTr).css("webkitColumnGap", trStyle["webkitColumnGap"]);
    $(createTr).css("webkitColumnRule", trStyle["webkitColumnRule"]);
    $(createTr).css("webkitColumnRuleColor", trStyle["webkitColumnRuleColor"]);
    $(createTr).css("webkitColumnRuleStyle", trStyle["webkitColumnRuleStyle"]);
    $(createTr).css("webkitColumnRuleWidth", trStyle["webkitColumnRuleWidth"]);
    $(createTr).css("webkitColumnSpan", trStyle["webkitColumnSpan"]);
    $(createTr).css("webkitColumnWidth", trStyle["webkitColumnWidth"]);
    $(createTr).css("webkitColumns", trStyle["webkitColumns"]);
    $(createTr).css("webkitFilter", trStyle["webkitFilter"]);
    $(createTr).css("webkitFlex", trStyle["webkitFlex"]);
    $(createTr).css("webkitFlexBasis", trStyle["webkitFlexBasis"]);
    $(createTr).css("webkitFlexDirection", trStyle["webkitFlexDirection"]);
    $(createTr).css("webkitFlexFlow", trStyle["webkitFlexFlow"]);
    $(createTr).css("webkitFlexGrow", trStyle["webkitFlexGrow"]);
    $(createTr).css("webkitFlexShrink", trStyle["webkitFlexShrink"]);
    $(createTr).css("webkitFlexWrap", trStyle["webkitFlexWrap"]);
    $(createTr).css(
      "webkitFontFeatureSettings",
      trStyle["webkitFontFeatureSettings"]
    );
    $(createTr).css("webkitFontSmoothing", trStyle["webkitFontSmoothing"]);
    $(createTr).css("webkitHighlight", trStyle["webkitHighlight"]);
    $(createTr).css(
      "webkitHyphenateCharacter",
      trStyle["webkitHyphenateCharacter"]
    );
    $(createTr).css("webkitJustifyContent", trStyle["webkitJustifyContent"]);
    $(createTr).css("webkitLineBreak", trStyle["webkitLineBreak"]);
    $(createTr).css("webkitLineClamp", trStyle["webkitLineClamp"]);
    $(createTr).css("webkitLocale", trStyle["webkitLocale"]);
    $(createTr).css("webkitLogicalHeight", trStyle["webkitLogicalHeight"]);
    $(createTr).css("webkitLogicalWidth", trStyle["webkitLogicalWidth"]);
    $(createTr).css("webkitMarginAfter", trStyle["webkitMarginAfter"]);
    $(createTr).css("webkitMarginBefore", trStyle["webkitMarginBefore"]);
    $(createTr).css("webkitMarginEnd", trStyle["webkitMarginEnd"]);
    $(createTr).css("webkitMarginStart", trStyle["webkitMarginStart"]);
    $(createTr).css("webkitMask", trStyle["webkitMask"]);
    $(createTr).css("webkitMaskBoxImage", trStyle["webkitMaskBoxImage"]);
    $(createTr).css(
      "webkitMaskBoxImageOutset",
      trStyle["webkitMaskBoxImageOutset"]
    );
    $(createTr).css(
      "webkitMaskBoxImageRepeat",
      trStyle["webkitMaskBoxImageRepeat"]
    );
    $(createTr).css(
      "webkitMaskBoxImageSlice",
      trStyle["webkitMaskBoxImageSlice"]
    );
    $(createTr).css(
      "webkitMaskBoxImageSource",
      trStyle["webkitMaskBoxImageSource"]
    );
    $(createTr).css(
      "webkitMaskBoxImageWidth",
      trStyle["webkitMaskBoxImageWidth"]
    );
    $(createTr).css("webkitMaskClip", trStyle["webkitMaskClip"]);
    $(createTr).css("webkitMaskComposite", trStyle["webkitMaskComposite"]);
    $(createTr).css("webkitMaskImage", trStyle["webkitMaskImage"]);
    $(createTr).css("webkitMaskOrigin", trStyle["webkitMaskOrigin"]);
    $(createTr).css("webkitMaskPosition", trStyle["webkitMaskPosition"]);
    $(createTr).css("webkitMaskPositionX", trStyle["webkitMaskPositionX"]);
    $(createTr).css("webkitMaskPositionY", trStyle["webkitMaskPositionY"]);
    $(createTr).css("webkitMaskRepeat", trStyle["webkitMaskRepeat"]);
    $(createTr).css("webkitMaskRepeatX", trStyle["webkitMaskRepeatX"]);
    $(createTr).css("webkitMaskRepeatY", trStyle["webkitMaskRepeatY"]);
    $(createTr).css("webkitMaskSize", trStyle["webkitMaskSize"]);
    $(createTr).css(
      "webkitMaxLogicalHeight",
      trStyle["webkitMaxLogicalHeight"]
    );
    $(createTr).css("webkitMaxLogicalWidth", trStyle["webkitMaxLogicalWidth"]);
    $(createTr).css(
      "webkitMinLogicalHeight",
      trStyle["webkitMinLogicalHeight"]
    );
    $(createTr).css("webkitMinLogicalWidth", trStyle["webkitMinLogicalWidth"]);
    $(createTr).css("webkitOpacity", trStyle["webkitOpacity"]);
    $(createTr).css("webkitOrder", trStyle["webkitOrder"]);
    $(createTr).css("webkitPaddingAfter", trStyle["webkitPaddingAfter"]);
    $(createTr).css("webkitPaddingBefore", trStyle["webkitPaddingBefore"]);
    $(createTr).css("webkitPaddingEnd", trStyle["webkitPaddingEnd"]);
    $(createTr).css("webkitPaddingStart", trStyle["webkitPaddingStart"]);
    $(createTr).css("webkitPerspective", trStyle["webkitPerspective"]);
    $(createTr).css(
      "webkitPerspectiveOrigin",
      trStyle["webkitPerspectiveOrigin"]
    );
    $(createTr).css(
      "webkitPerspectiveOriginX",
      trStyle["webkitPerspectiveOriginX"]
    );
    $(createTr).css(
      "webkitPerspectiveOriginY",
      trStyle["webkitPerspectiveOriginY"]
    );
    $(createTr).css(
      "webkitPrintColorAdjust",
      trStyle["webkitPrintColorAdjust"]
    );
    $(createTr).css("webkitRtlOrdering", trStyle["webkitRtlOrdering"]);
    $(createTr).css("webkitRubyPosition", trStyle["webkitRubyPosition"]);
    $(createTr).css(
      "webkitShapeImageThreshold",
      trStyle["webkitShapeImageThreshold"]
    );
    $(createTr).css("webkitShapeMargin", trStyle["webkitShapeMargin"]);
    $(createTr).css("webkitShapeOutside", trStyle["webkitShapeOutside"]);
    $(createTr).css(
      "webkitTapHighlightColor",
      trStyle["webkitTapHighlightColor"]
    );
    $(createTr).css("webkitTextCombine", trStyle["webkitTextCombine"]);
    $(createTr).css(
      "webkitTextDecorationsInEffect",
      trStyle["webkitTextDecorationsInEffect"]
    );
    $(createTr).css("webkitTextEmphasis", trStyle["webkitTextEmphasis"]);
    $(createTr).css(
      "webkitTextEmphasisColor",
      trStyle["webkitTextEmphasisColor"]
    );
    $(createTr).css(
      "webkitTextEmphasisPosition",
      trStyle["webkitTextEmphasisPosition"]
    );
    $(createTr).css(
      "webkitTextEmphasisStyle",
      trStyle["webkitTextEmphasisStyle"]
    );
    $(createTr).css("webkitTextFillColor", trStyle["webkitTextFillColor"]);
    $(createTr).css("webkitTextOrientation", trStyle["webkitTextOrientation"]);
    $(createTr).css("webkitTextSecurity", trStyle["webkitTextSecurity"]);
    $(createTr).css("webkitTextSizeAdjust", trStyle["webkitTextSizeAdjust"]);
    $(createTr).css("webkitTextStroke", trStyle["webkitTextStroke"]);
    $(createTr).css("webkitTextStrokeColor", trStyle["webkitTextStrokeColor"]);
    $(createTr).css("webkitTextStrokeWidth", trStyle["webkitTextStrokeWidth"]);
    $(createTr).css("webkitTransform", trStyle["webkitTransform"]);
    $(createTr).css("webkitTransformOrigin", trStyle["webkitTransformOrigin"]);
    $(createTr).css(
      "webkitTransformOriginX",
      trStyle["webkitTransformOriginX"]
    );
    $(createTr).css(
      "webkitTransformOriginY",
      trStyle["webkitTransformOriginY"]
    );
    $(createTr).css(
      "webkitTransformOriginZ",
      trStyle["webkitTransformOriginZ"]
    );
    $(createTr).css("webkitTransformStyle", trStyle["webkitTransformStyle"]);
    $(createTr).css("webkitTransition", trStyle["webkitTransition"]);
    $(createTr).css("webkitTransitionDelay", trStyle["webkitTransitionDelay"]);
    $(createTr).css(
      "webkitTransitionDuration",
      trStyle["webkitTransitionDuration"]
    );
    $(createTr).css(
      "webkitTransitionProperty",
      trStyle["webkitTransitionProperty"]
    );
    $(createTr).css(
      "webkitTransitionTimingFunction",
      trStyle["webkitTransitionTimingFunction"]
    );
    $(createTr).css("webkitUserDrag", trStyle["webkitUserDrag"]);
    $(createTr).css("webkitUserModify", trStyle["webkitUserModify"]);
    $(createTr).css("webkitUserSelect", trStyle["webkitUserSelect"]);
    $(createTr).css("webkitWritingMode", trStyle["webkitWritingMode"]);
    $(createTr).css("whiteSpace", trStyle["whiteSpace"]);
    $(createTr).css("widows", trStyle["widows"]);
    $(createTr).css("width", trStyle["width"]);
    $(createTr).css("willChange", trStyle["willChange"]);
    $(createTr).css("wordBreak", trStyle["wordBreak"]);
    $(createTr).css("wordSpacing", trStyle["wordSpacing"]);
    $(createTr).css("wordWrap", trStyle["wordWrap"]);
    $(createTr).css("writingMode", trStyle["writingMode"]);
    $(createTr).css("x", trStyle["x"]);
    $(createTr).css("y", trStyle["y"]);
    $(createTr).css("zIndex", trStyle["zIndex"]);
    $(createTr).css("zoom", trStyle["zoom"]);
    $(createTr).click(function (_event: any) {
      self.tr = createTr;
    });
    return createTr;
  }
  getTdClone(obj: any) {
    const self = this;
    var tdStyle = $(obj).css([
      "borderBottom",
      "borderBottomColor",
      "borderBottomStyle",
      "borderBottomWidth",
      "borderColor",
      "borderLeft",
      "borderLeftColor",
      "borderLeftStyle",
      "borderLeftWidth",
      "borderRight",
      "borderRightColor",
      "borderRightStyle",
      "borderRightWidth",
      "borderSpacing",
      "borderStyle",
      "borderTop",
      "borderTopColor",
      "borderTopStyle",
      "borderTopWidth",
      "borderWidth",
      "cssText",
      "length",
      "padding",
      "paddingBottom",
      "paddingLeft",
      "paddingRight",
      "paddingTop",
    ]);
    const createTd = document.createElement("td");
    $(createTd).css("borderBottom", tdStyle["borderBottom"]);
    $(createTd).css("borderBottomColor", tdStyle["borderBottomColor"]);
    $(createTd).css("borderBottomStyle", tdStyle["borderBottomStyle"]);
    $(createTd).css("borderBottomWidth", tdStyle["borderBottomWidth"]);
    $(createTd).css("borderColor", tdStyle["borderColor"]);
    $(createTd).css("borderLeft", tdStyle["borderLeft"]);
    $(createTd).css("borderLeftColor", tdStyle["borderLeftColor"]);
    $(createTd).css("borderLeftStyle", tdStyle["borderLeftStyle"]);
    $(createTd).css("borderLeftWidth", tdStyle["borderLeftWidth"]);
    $(createTd).css("borderRight", tdStyle["borderRight"]);
    $(createTd).css("borderRightColor", tdStyle["borderRightColor"]);
    $(createTd).css("borderRightStyle", tdStyle["borderRightStyle"]);
    $(createTd).css("borderRightWidth", tdStyle["borderRightWidth"]);
    $(createTd).css("borderSpacing", tdStyle["borderSpacing"]);
    $(createTd).css("borderStyle", tdStyle["borderStyle"]);
    $(createTd).css("borderTop", tdStyle["borderTop"]);
    $(createTd).css("borderTopColor", tdStyle["borderTopColor"]);
    $(createTd).css("borderTopStyle", tdStyle["borderTopStyle"]);
    $(createTd).css("borderTopWidth", tdStyle["borderTopWidth"]);
    $(createTd).css("borderWidth", tdStyle["borderWidth"]);
    $(createTd).css("cssText", tdStyle["cssText"]);
    //            $(createTd).css("length", tdStyle["length"]);
    $(createTd).css("padding", tdStyle["padding"]);
    $(createTd).css("paddingBottom", tdStyle["paddingBottom"]);
    $(createTd).css("paddingLeft", tdStyle["paddingLeft"]);
    $(createTd).css("paddingRight", tdStyle["paddingRight"]);
    $(createTd).css("paddingTop", tdStyle["paddingTop"]);
    $(createTd).click(function (_event: any) {
      self.td = createTd;
    });
    return createTd;
  }

  changeFont() {
    var fontName = prompt("Enter font name");
    if (fontName) document.execCommand("fontname", false, this.selectedOption);
  }

  changeFontSize() {
    var fontSize = prompt("Enter Font Size");
    if (fontSize) document.execCommand("fontSize", false, fontSize);
  }

  // rowafterList = []
  cloneRowInsertAfter() {
    const self = this;
    var cloneTr = this.tr.clone(true);
    $(cloneTr).click(function (_event: any) {
      self.tr = cloneTr;
    });
    $(cloneTr).find("*").text("");
    $(this.tr).after(cloneTr);
  }
  // carot position cordinates
  elementclicked: any;
  xPostion: any;
  yPostion: any;

  carotPosition(event: any) {

    this.xPostion = event.clientX;
    this.yPostion = event.clientY;

    this.elementclicked = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    );



    return this.elementclicked
  }


  // minified table reziable code ///

  resizabletable(e: any) {
    var t = e.getElementsByTagName("td")[0],
      n = t ? t.children : void 0;
    if (n) {
      e.style.overflow = "hidden";
      for (var i = e.offsetHeight, o = 0; o < n.length; o++) {
        var r = s(i);
        n[o].appendChild(r), (n[o].style.position = "relative"), d(r);
      }
    }
    function d(e: any) {
      var t: any, n: any, i: any, o: any, r: any;
      e.addEventListener("mousedown", function (e: any) {
        (n = e.target.parentElement), (i = n.nextElementSibling), (t = e.pageX);
        var d = (function (e) {
          if ("border-box" == l(e, "box-sizing")) return 0;
          var t = l(e, "padding-left"),
            n = l(e, "padding-right");
          return parseInt(t) + parseInt(n);
        })(n);
        (o = n.offsetWidth - d), i && (r = i.offsetWidth - d);
      }),
        e.addEventListener("mouseover", function (e: any) {
          e.target.style.borderRight = "2px solid #0000ff";
        }),
        e.addEventListener("mouseout", function (e: any) {
          e.target.style.borderRight = "";
        }),
        document.addEventListener("mousemove", function (e) {
          if (n) {
            var d = e.pageX - t;
            i && (i.style.width = r - d + "px"), (n.style.width = o + d + "px");
          }
        }),
        document.addEventListener("mouseup", function (e) {
          (n = void 0), (i = void 0), (t = void 0), (r = void 0), (o = void 0);
        });
    }
    function s(e: any) {
      var t = document.createElement("div") as any;
      return (
        (t.style.top = 0),
        (t.style.right = 0),
        (t.style.width = "5px"),
        (t.style.position = "absolute"),
        (t.style.cursor = "col-resize"),
        (t.style.userSelect = "none"),
        (t.style.height = e + "px"),
        t
      );
    }
    function l(e: any, t: any) {
      return window.getComputedStyle(e, null).getPropertyValue(t);
    }
  }

  columnInsert(position: any) {

    if (this.xPostion == undefined && this.yPostion == undefined) {
      alerts("Double click the mouse pointer");
    }
    let tableRef = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    ) as HTMLTableElement;
    let countTd: any;
    let colToClone: any;
    let originalNode: any;
    let clone: any;
    let cursorElement: any;
    let cursorElementIndex: number;
    let parentEle: any
    let table: any
    const getParents = (el: any) => {
      for (var parents: any = []; el; el = el.parentNode) {
        if (el.nodeName == "TD") {
          cursorElement = el;
          parentEle = el.parentElement
          cursorElementIndex = cursorElement.cellIndex;
        }
        if (el.nodeName == "TABLE") {

          table = el
          originalNode = el.childNodes[0];
          colToClone = originalNode.childNodes[0];
          for (let index = 0; index < el.children.length; index++) {
            if (el.children[index].tagName == 'TBODY') {
              countTd = el.children[index].childNodes;
              return
            }
          }
        }
      }
      return parents;
    };
    const el = tableRef;
    getParents(el);

    let array = []
    for (let i = 0; i < countTd.length; i++) {
      if (countTd[i].children.length == parentEle.children.length) {
        for (var j = 0; j < parentEle.children.length; j++) {
          if (countTd[i].children[j].colSpan == parentEle.children[j].colSpan) {
            if (j == parentEle.children.length - 1) {

              array.push(countTd[i])

            }
          }
        }
      }
    }

    function colNew(pos) {
      let indexArray = []
      for (let i = 0; i < array.length; i++) {
        let rowIndex = array[i];
        indexArray.push(rowIndex.rowIndex)
        let cell: any = document.createElement("td");
        let span = document.createElement("span");
        span.setAttribute('style', rowIndex.children[0].children[0].children.length > 1 ? rowIndex.children[0].children[0].children[0].attributes['style'].value : "font-weight: bold;color: #000000;font-size: 8.0pt;font-family: 'Verdana';")
        let cellText = document.createTextNode("New Column");
        span.appendChild(cellText);
        cell.appendChild(span);
        // cell.setAttribute(
        //   "style",
        //   rowIndex.children[0].attributes.hasOwnProperty("style") ? rowIndex.children[0].attributes['style'].value : "color:black; border: 1px solid #bfbfbf; border-collapse: collapse;"
        // );
        cell.setAttribute('contenteditable', 'true');

        let newCellPOs = rowIndex.children[cursorElementIndex];
        if (!rowIndex.children[cursorElementIndex]) {
          newCellPOs = rowIndex.children[rowIndex.children.length - 1]
        }
        if (i == array.length - 1) {
          let row = newCellPOs.parentElement
          let max = 0

          for (var a = 0; a <= newCellPOs.cellIndex; a++) {
            max += Number(row.children[a].colSpan) || 1
          }
          let tr = document.getElementsByTagName('tr') as any;
          for (var j = 0; j < tr.length; j++) {
            let cells = tr[j].getElementsByTagName("td");
            let maxColspan = 0
            let count = 0

            if (!indexArray.includes(j)) {
              for (var k = 0; k < cells.length; k++) {
                maxColspan += cells[k].colSpan

                if (maxColspan >= max && count == 0) {
                  cells[k].colSpan += 1
                  count++
                }
              }
            }
          }
        }
        if (pos == "prepend") {
          rowIndex.insertBefore(cell, newCellPOs);
        }
        if (pos == "appendChild") {

          rowIndex.insertBefore(cell, newCellPOs.nextSibling);
        }
      }
      clone = colToClone.cloneNode(true);
      if (originalNode.nodeName == "COLGROUP") {
        if (pos == "prepend") {
          originalNode.prepend(clone);
        }
        if (pos == "appendChild") {
          originalNode.appendChild(clone);
          let firstRowCells: any = el.children;

          for (var j = 1; j < firstRowCells.length; j++) {
            let existingDiv = firstRowCells[j].querySelector('.increase');
            if (existingDiv) {
              firstRowCells[j].style.position = '';
            }
          }
        }
      }
    }


    //  insert column
    if (position == "before") {
      colNew("prepend");
    }
    if (position == "after") {
      colNew("appendChild");
    }

    this.resizableGrid(table)

  }

  // newRow:any;
  rowInsert(position: string) {
    if (this.xPostion == undefined && this.yPostion == undefined) {
      alert("Double click the mouse pointer");
    }
    let tableRef = (
      document.elementFromPoint(this.xPostion, this.yPostion) as any
    ).parentNode;

    let countTd: any;
    let newRow: any;

    function rowNew(pos: string) {
      for ([]; tableRef; tableRef = tableRef.parentNode) {
        if (tableRef.nodeName == "TR") {
          newRow = tableRef;
          break;
        }
      }
      let row = document.createElement("tr");
      countTd = newRow.children;
      let maxRowspan = 0;
      for (var j = 0; j < countTd.length; j++) {
        let colspanValue = countTd[j].colSpan;
        console.log(countTd[j].rowSpan, "rfjrfuijfirejnfirjnrjnie")
        if (countTd[j].rowSpan > maxRowspan) {
          maxRowspan = countTd[j].rowSpan
        }
        let cell = document.createElement("td");
        cell.classList.add('cell')
        cell.colSpan = colspanValue;
        let span = document.createElement("p");
        span.classList.add('spanText');
        let cellText = document.createElement("br");

        span.appendChild(cellText);
        let newText = document.createTextNode("New row");
        span.appendChild(newText);
        cell.appendChild(span);
        cell.setAttribute(
          "style",
          "color:black; border: 1px solid #bfbfbf; border-collapse: collapse;cursor:text;word-break:break-all;min-width:31px;"
        );
        cell.setAttribute('contenteditable', 'true');

        row.appendChild(cell);
      }
      let cell = document.getElementsByClassName('cell') as any
      for (var i = 0; i < cell.length; i++) {
        cell[i].style.width = null
      }
      function upTo(el, tagName) {
        tagName = tagName.toLowerCase();

        while (el && el.parentNode) {
          el = el.parentNode;
          if (el.tagName && el.tagName.toLowerCase() == tagName) {
            return el;
          }
        }

        return null;
      }

      if (pos == "after") {
        if (maxRowspan > 1) {
          console.log("greater", newRow.rowIndex)
          let table = upTo(newRow, 'table')
          let rows = table.getElementsByTagName('TR')
          let index = newRow.rowIndex + maxRowspan
          newRow.parentNode.insertBefore(row, rows[index]);
        } else {
          newRow.parentNode.insertBefore(row, newRow.nextSibling);
        }
      }
      if (pos == "before") {
        //  document.querySelectorAll('.increase')
        let firstRowCells: any = newRow.children;

        for (var j = 0; j < firstRowCells.length; j++) {
          let existingDiv = firstRowCells[j].querySelector('.increase');
          if (existingDiv) {
            firstRowCells[j].style.position = '';
            existingDiv.remove();
          }
        }
        newRow.parentNode.insertBefore(row, newRow);
      }

    }


    if (position == "after") {
      rowNew("after");
    }
    if (position == "before") {
      rowNew("before");
    }


    let tables = document.getElementsByTagName('table') as any;
    this.resizableGrid(tables[0]);

  }

  resizeTable(tbl) {
    var tables = tbl;
   
    for (let index = 0; index < tables.children[1].children.length; index++) {
      const element = tables.children[1].children[index];
       resizableGrid(tables,element);
    }
    function resizableGrid(table,rowIndex) {
      var row = rowIndex,
      // table.getElementsByTagName("tr")[0],
        cols = row ? row.children : undefined;
      if (!cols) return;

      table.style.overflow = "hidden";

      var tableHeight = table.offsetHeight;

      for (var i = 0; i < cols.length; i++) {
        var div = createDiv(tableHeight);
        cols[i].appendChild(div);
        cols[i].style.position = "relative";
        setListeners(div);
      }

      function setListeners(div) {
        var pageX, curCol, nxtCol, curColWidth, nxtColWidth, tableWidth;

        div.addEventListener("mousedown", function (e) {
          tableWidth = table.offsetWidth;
          curCol = e.target.parentElement;
          nxtCol = curCol.nextElementSibling;
          pageX = e.pageX;

          var padding = paddingDiff(curCol);

          curColWidth = curCol.offsetWidth - padding;
          //  if (nxtCol)
          //nxtColWidth = nxtCol.offsetWidth - padding;
        });

        div.addEventListener("mouseover", function (e) {
          e.target.style.borderRight = "2px solid #0000ff";
        });

        div.addEventListener("mouseout", function (e) {
          e.target.style.borderRight = "";
        });

        document.addEventListener("mousemove", function (e) {
          if (curCol) {
            var diffX = e.pageX - pageX;

            // if (nxtCol)
            //nxtCol.style.width = (nxtColWidth - (diffX)) + 'px';

            curCol.style.width = curColWidth + diffX + "px";
            table.style.width = tableWidth + diffX + "px";
          }
        });

        document.addEventListener("mouseup", function (e) {
          curCol = undefined;
          nxtCol = undefined;
          pageX = undefined;
          nxtColWidth = undefined;
          curColWidth = undefined;
        });
      }

      function createDiv(height) {
        var div = document.createElement("div") as any;
        div.style.top = 0;
        div.style.right = 0;
        div.style.width = "5px";
        div.style.position = "absolute";
        div.style.cursor = "col-resize";
        div.style.userSelect = "none";
        div.style.height = height + "px";
        return div;
      }

      function paddingDiff(col) {
        if (getStyleVal(col, "box-sizing") == "border-box") {
          return 0;
        }

        var padLeft = getStyleVal(col, "padding-left");
        var padRight = getStyleVal(col, "padding-right");
        return parseInt(padLeft) + parseInt(padRight);
      }

      function getStyleVal(elm, css) {
        return window.getComputedStyle(elm, null).getPropertyValue(css);
      }
    }
  }

  newresizetable(table) {
    let row = table.getElementsByTagName("tr")[0];

    let cols = row ? row.children : undefined;
    if (!cols) return;

    for (var i = 0; i < cols.length; i++) {
      let divr = createDivR();
      let divb = createDivB();
      cols[i].appendChild(divr);
      cols[i].appendChild(divb);
      cols[i].style.position = "relative";
    }

    function createDivR() {
      let div = document.createElement("div") as any;
      div.setAttribute("class", "resizer");
      div.style.top = 0;
      div.style.right = 0;
      div.style.width = "5px";
      div.style.position = "relative";
      div.style.cursor = "col-resize";
      div.style.userSelect = "none";
      div.style.height = "100%";
      return div;
    }

    function createDivB() {
      let div = document.createElement("div") as any;
      div.setAttribute("class", "resizer");
      div.style.bottom = 0;
      div.style.left = 0;
      div.style.position = "relative";
      div.style.width = "100%";
      div.style.cursor = "row-resize";
      div.style.height = "5px";
      return div;
    }

    // Query the element
    const ele = table;

    // The current position of mouse
    let x = 0;
    let y = 0;

    // The dimension of the element
    let w = 0;
    let h = 0;

    // Handle the mousedown event
    // that's triggered when user drags the resizer
    const mouseDownHandler = function (e) {
      // Get the current mouse position
      x = e.clientX;
      y = e.clientY;

      // Calculate the dimension of element
      const styles = window.getComputedStyle(ele);
      w = parseInt(styles.width, 10);
      h = parseInt(styles.height, 10);

      // Attach the listeners to `document`
      document.addEventListener("mousemove", mouseMoveHandler);
      document.addEventListener("mouseup", mouseUpHandler);
    };

    const mouseMoveHandler = function (e) {
      // How far the mouse has been moved
      const dx = e.clientX - x;
      const dy = e.clientY - y;

      // Adjust the dimension of element
      ele.style.width = `${w + dx}px`;
      ele.style.height = `${h + dy}px`;
    };

    const mouseUpHandler = function () {
      // Remove the handlers of `mousemove` and `mouseup`
      document.removeEventListener("mousemove", mouseMoveHandler);
      document.removeEventListener("mouseup", mouseUpHandler);
    };

    const resizers = ele.querySelectorAll(".resizer");

    // Loop over them
    [].forEach.call(resizers, function (resizer) {
      resizer.addEventListener("mousedown", mouseDownHandler);
    });
  }

  createTable(row, col) {
    const body = this.elementclicked as HTMLTableElement;
    let tbl = document.createElement("table");
    tbl.setAttribute("id", "tbl_created");
    let tblBody = document.createElement("tbody");
    let colgroup = document.createElement("colgroup");
    // let container = document.createElement("div");
    // container.classList.add('moveTable');
    // container.setAttribute('style', 'position:relative;min-width:30%;width:50%;');
    // // container.setAttribute('draggable', 'true');
    // container.setAttribute('contenteditable', 'false');
    // container.classList.add('moveTable');

    for (let index = 0; index < col; index++) {
      let colEle = document.createElement("col");
      let width = 100 / col;
      colgroup.appendChild(colEle);
      colEle.setAttribute("style", "border-collapse: collapse;");
    }


    tbl.classList.add('tableW');
    tbl.setAttribute("style", "width:40%;height:30%;border-collapse: collapse;border:1px solid #b1b1b9;margin:auto;max-width:100%;margin-bottom:20px");


    tblBody.setAttribute("style", "width:100%;max-width:100%;border-collapse: collapse");

    for (let j = 1; j <= row; j++) {
      let row = document.createElement("tr");
      row.setAttribute("style", "color:black; border: 1px solid #bfbfbf; border-collapse: collapse;");

      for (let i = 1; i <= col; i++) {
        let cell = document.createElement("td");
        cell.classList.add('cell');
        cell.setAttribute('contenteditable', 'true');
        let span = document.createElement("p");
        span.classList.add('spanText');
        span.style.height = '-webkit-fill-available'
        let cellText = document.createElement("br");

        span.appendChild(cellText);
        cell.appendChild(span);
        cell.setAttribute("style", `color:black; border: 1px solid #bfbfbf; border-collapse: collapse;cursor:text;word-break:break-all;min-width:31px`);
        cell.oninput = function () {
          // container.style.height = tbl.offsetHeight  + 'px'
          var tableHeight = tbl.offsetHeight;
          document.querySelectorAll('.increase').forEach(function (el: any) {
            el.style.height = `calc(${tableHeight}px - 1px)`;
          });

        }
        row.appendChild(cell);
      }

      tblBody.appendChild(row);

    }

    tbl.appendChild(colgroup);
    tbl.appendChild(tblBody);
    body.appendChild(tbl);


    this.resizableGrid(tbl);
    this.resizeImage(tbl);

    return;
  }
  deleteTable() {
    // document.execCommand("delete", true, this.createTable);
  }
  openFileloader() {
    var element = document.getElementById("inputImage_id") as HTMLElement;
    element.click();
  }
  //this function is for the resize of the image inserted
  resizeImage(varii?: any) {
    // "use strict";
    if (varii) {
      // Minimum resizable area
      var minWidth = 60;
      var minHeight = 40;

      // Thresholds
      var FULLSCREEN_MARGINS = -10;
      var MARGINS = 7;

      // End of what's configurable.
      var clicked: {
        isResizing: any;
        onRightEdge: any;
        onBottomEdge: any;
        onLeftEdge: any;
        cx: any;
        w: any;
        onTopEdge: any;
        cy: any;
        h: any;
        isMoving: any;
        y: any;
        x: any;
      } | null = null;
      var onRightEdge: boolean,
        onBottomEdge: boolean,
        onLeftEdge: boolean,
        onTopEdge: boolean;

      var rightScreenEdge: number, bottomScreenEdge: number;

      var preSnapped: { width: any; height: any } | null;

      var b: DOMRect, x: number, y: number;

      var redraw = false;

      var pane: any = varii as HTMLTableElement;


      function setBounds(
        element: any,
        x: string | number,
        y: string | number,
        w: string | number,
        h: string | number
      ) {
        // element.style.left = x + "px";
        // element.style.top = y + "px";
        // element.style.width = w + "px";
        // element.style.height = h + "px";
      }

      // // Mouse events
      pane.addEventListener("mousedown", onMouseDown);
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);

      // // Touch events
      pane.addEventListener("touchstart", onTouchDown);
      document.addEventListener("touchmove", onTouchMove);
      document.addEventListener("touchend", onTouchEnd);

      function onTouchDown(e: { touches: any[]; preventDefault: () => void }) {
        onDown(e.touches[0]);

        // e.preventDefault();
      }

      function onTouchMove(e: any) {
        onMove(e.touches[0]);

      }

      function onTouchEnd(e: { touches: any; changedTouches: any }) {
        if (e.touches.length == 0) onUp(e.changedTouches[0]);

      }

      function onMouseDown(e) {
        if(e.target.tagName=='TABLE'){
          e.preventDefault()
          onDown(e as any); 
        }
        else{
          onDown(e as any); 
        }
        // moveTable[0].minHeight =varii.offsetHeight
        // e.preventDefault();
      }

      function onDown(e: any) {

        calc(e);
        e.target.style.userSelect = 'none'
        var isResizing = onRightEdge || onBottomEdge || onTopEdge || onLeftEdge;

        clicked = {
          x: x,
          y: y,
          cx: e.clientX,
          cy: e.clientY,
          w: b.width,
          h: b.height,
          isResizing: isResizing,
          isMoving: !isResizing && canMove(),
          onTopEdge: onTopEdge,
          onLeftEdge: onLeftEdge,
          onRightEdge: onRightEdge,
          onBottomEdge: onBottomEdge,
        };
      }

      function canMove() {

        return x > 0 && x < b.width && y > 0 && y < b.height && y < 30;
      }

      function calc(e: { clientX: number; clientY: number }) {
        b = pane.getBoundingClientRect();
        x = e.clientX - b.left;
        y = e.clientY - b.top;

        onTopEdge = y < MARGINS;
        onLeftEdge = x < MARGINS;
        onRightEdge = x >= b.width - MARGINS;
        onBottomEdge = y >= b.height - MARGINS;

        rightScreenEdge = window.innerWidth - MARGINS;
        bottomScreenEdge = window.innerHeight - MARGINS;
      }

      var e: { clientX: any; clientY: any };

      function onMove(ee: any) {
        calc(ee);
        e = ee;
        redraw = true;
      }

      function animate() {
        requestAnimationFrame(animate);

        if (!redraw) return;

        redraw = false;

        if (clicked && clicked.isResizing) {
          if (clicked.onRightEdge)
            pane.style.width = Math.max(x, minWidth) + "px";
          if (clicked.onBottomEdge)
            pane.style.height = Math.max(y, minHeight) + "px";

          if (clicked.onLeftEdge) {
            var currentWidth = Math.max(
              clicked.cx - e.clientX + clicked.w,
              minWidth
            );
            if (currentWidth > minWidth) {
              pane.style.width = currentWidth + "px";
              // pane.style.left = e.clientX + "px";
            }
          }

          if (clicked.onTopEdge) {
            var currentHeight = Math.max(
              clicked.cy - e.clientY + clicked.h,
              minHeight
            );
            if (currentHeight > minHeight) {
              pane.style.height = currentHeight + "px";
              pane.style.top = e.clientY + "px";
            }
          }

          return;
        }

        // This code executes when mouse moves without clicking

        // style cursor
        if ((onRightEdge && onBottomEdge) || (onLeftEdge && onTopEdge)) {
          pane.style.cursor = "nwse-resize";
        } else if ((onRightEdge && onTopEdge) || (onBottomEdge && onLeftEdge)) {
          pane.style.cursor = "nesw-resize";
        } else if (onRightEdge || onLeftEdge) {
          pane.style.cursor = "ew-resize";
        } else if (onBottomEdge || onTopEdge) {
          pane.style.cursor = "ns-resize";
        }
        //  else if (canMove()) {
        //   pane.style.cursor = "move";
        // } 
        else {
          pane.style.cursor = "default";
        }
      }

      animate();

      function onUp(e: any) {
        var colgroup = varii.getElementsByTagName('colgroup')[0];
        var colsW = colgroup.getElementsByTagName('col') as any;
        for (var i = 0; i < colsW.length; i++) {
          colsW[i].style.width = colsW[i].offsetWidth + 'px'
        }
        calc(e);

        if (clicked && clicked.isMoving) {
          // Snap
          var snapped = {
            width: b.width,
            height: b.height,
          };

          if (
            b.top < FULLSCREEN_MARGINS ||
            b.left < FULLSCREEN_MARGINS ||
            b.right > window.innerWidth - FULLSCREEN_MARGINS ||
            b.bottom > window.innerHeight - FULLSCREEN_MARGINS
          ) {
            // hintFull();
            setBounds(pane, 0, 0, window.innerWidth, window.innerHeight);
            preSnapped = snapped;
          } else if (b.top < MARGINS) {
            // hintTop();
            setBounds(pane, 0, 0, window.innerWidth, window.innerHeight / 2);
            preSnapped = snapped;
          } else if (b.left < MARGINS) {
            // hintLeft();
            setBounds(pane, 0, 0, window.innerWidth / 2, window.innerHeight);
            preSnapped = snapped;
          }
          else if (b.right > rightScreenEdge) {
            // hintRight();
            setBounds(
              pane,
              window.innerWidth / 2,
              0,
              window.innerWidth / 2,
              window.innerHeight
            );
            preSnapped = snapped;
          }
          else if (b.bottom > bottomScreenEdge) {
            // hintBottom();
            setBounds(
              pane,
              0,
              window.innerHeight / 2,
              window.innerWidth,
              window.innerWidth / 2
            );
            preSnapped = snapped;
          } else {
            preSnapped = null;
          }

          // hintHide();
        }

        clicked = null;
      }
    }
  }
   resizeBase64Img(base64, newWidth, newHeight) {
    return new Promise(async(resolve, reject)=>{
        let img = document.createElement("img");
        img.src = base64;
        img.onload = function () {
        var canvas = document.createElement("canvas");
        canvas.width = newWidth;
        canvas.height = newHeight;
        canvas.style.width = newWidth.toString()+"px";
        canvas.style.height = newHeight.toString()+"px";
        let context = canvas.getContext("2d");
            context.scale(newWidth/img.width,  newHeight/img.height);
            context.drawImage(img, 0, 0); 
            resolve(canvas.toDataURL());               
        }
    });
}
  insertImage(picture: any) {
    const self = this;
    let resizedImage;
    if (this.xPostion == undefined && this.yPostion == undefined) {
      alerts("Double click the mouse pointer");
    }
    var appendPos = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    ) as HTMLTableElement;
    this.uploadimage = picture;
    const file = this.uploadimage.target.files[0];
    const reader = new FileReader();
    reader.addEventListener(
      "load",
      async function () {
        // convert image file to base64 string
       await self.resizeBase64Img(reader.result,200,150).then(resized=>{ resizedImage = resized});
        var resizeD1 = document.createElement("div");
        resizeD1.id = "imgdiv1";
        resizeD1.setAttribute("style", "width:150px;height:150px;");
        var img = document.createElement("img");
        img.setAttribute("style", "width:100%;height:100%");
        img.src =
         resizedImage as string;
        // reader.result as string;
        resizeD1.appendChild(img);
        self.resizeImage(resizeD1);
        appendPos.appendChild(resizeD1);
      },
      false
    );

    if (file) {
      reader.readAsDataURL(file);
    }
  }
  searchInput() {
    let ref = this.editer.nativeElement;
    let $box = ref;
    this.Find = window.prompt("Enter word to find");

    let seacrh_Val = this.Find;
    const regex = new RegExp(seacrh_Val, "gi");
    let text = $box;

    if (seacrh_Val.length > 1) {
      text = text.innerHTML.replace(
        /(<mark class="highlight">|<\/mark>)/gim,
        ""
      );
      const newText = text.replace(regex, '<mark class="highlight">$&</mark>');
      $box = newText;
      this.editer.nativeElement.innerHTML = $box;
    } else {
      alerts("write more then one word to search");
    }
  }
  replace() {
    const targetText = window.prompt("Enter word to replace") as any;
    const regex = new RegExp(targetText, "gi");
    var replacedText = window.prompt("Enter new word") as any;
    // document.body.innerHTML = document.body.innerHTML.replace(regex, replacedText);
    let ref = this.editer.nativeElement;
    let curHtml = ref;

    if (replacedText.length > 1) {
      curHtml = curHtml.innerHTML.replace(/(<mark><\/mark>)/gim, "");
      const replacedHtml = curHtml.replace(regex, replacedText);
      curHtml = replacedHtml;
      this.editer.nativeElement.innerHTML = curHtml;

      setTimeout(function () {
        success("Replaced");
      }, 300);
    } else {
      alerts("enter complete word");
    }
  }
  styleChangeOnSagWordTheme() {
    $("#sag_word_theme_btn").addClass("sag_word_theme_btn");
    $("#div_btn_part").addClass("div_btn_part");
    $("#div_btn_part button").addClass("editor_inner_buttons");
  }

  setWordThemeDefault() {
    $("#sag_word_theme_btn").removeClass("sag_word_theme_btn");
    $("#div_btn_part").removeClass("div_btn_part");
    $("#div_btn_part button").removeClass("editor_inner_buttons");
  }

  keyDropdownOP() {
    (document.querySelector("#first_choice") as any).firstChild.innerText =
      "Please Choose";
// temporay static bill id once will active have to make dynamic
    const billId = {
      billId: "08",
    };

    this.sageditorService.getInvoiceData(billId).subscribe((res) => {
      let mainData = res.dataList[0];
      let data = mainData['keyfullName'];

      var firstChoice = document.getElementById("first_choice") as any;
      var sec = document.getElementById("second_choice") as any;
      var first = Object.keys(data);

     for (let [key, value] of Object.entries(data).sort()) {
        firstChoice.innerHTML +=
          '<option value="' + value + '">' + key + "</option>";
      }

      firstChoice.addEventListener("change", () => {});

      firstChoice.addEventListener("change", () => {
        let strUser = firstChoice.options[firstChoice.selectedIndex].value;
        this.dynamicJsonTextNode = strUser;

        if (Array.isArray(mainData[strUser])) {
          sec.attributes.style.nodeValue = 'display: block;'
          secondDropDown(firstChoice.value);
        } else {
          sec.innerHTML = "";
          sec.style['display'] = 'none';
          (( document.getElementById(
            "keyDropdownAppendkeyNested"
          ))as any).style['display']= 'none';
          ((document.getElementById(
            "keyDropdownAppendkey"
          )as any)).disabled = false;

        }
      });

      const secondDropDown = (x: any) => {
        sec.innerHTML = "<option selected>Please Select Option</option>";

        let Nestedkey = mainData[x];
        if (Array.isArray(Nestedkey)) {
          const keyDropdownAppendkey = document.getElementById(
            "keyDropdownAppendkey"
          ) as any;
          keyDropdownAppendkey.disabled = true;

          const keyDropdownAppendkeyNested = document.getElementById(
            "keyDropdownAppendkeyNested"
          ) as any;
          keyDropdownAppendkeyNested.childNodes[0].parentNode.attributes[3].nodeValue =
            "display: inline-block;";

          for (let index = 0; index < [Nestedkey[0]].length; index++) {
            const element = Nestedkey[index];
            for (const [key, value] of Object.entries(element).sort()) {
              sec.innerHTML +=
                '<option value="' + key + '">' + key + "</option>";
            }
          }
        } else {
          const keyDropdownAppendkey = document.getElementById(
            "keyDropdownAppendkey"
          ) as any;
          keyDropdownAppendkey.disabled = false;
          sec.innerHTML = '<option value="">Not Available Keys </option>';
        }

        sec.addEventListener("change", () => {
          let strUser = sec.options[sec.selectedIndex].value;
          this.dynamicJsonTextNodeNested = strUser;
        });
      };

      const keyDropdownAppendkey = document.getElementById(
        "keyDropdownAppendkey"
      ) as any;
      keyDropdownAppendkey.childNodes[0].parentNode.attributes[3].nodeValue =
        "display: inline-block;";

      const button = document.getElementById("BUTTON") as any;
      button.disabled = true;

      const save_word_new = document.getElementById("save_word_new") as any;
      save_word_new.childNodes[0].parentNode.attributes[3].nodeValue =
        "display: inline-block;";
    });
  }


catchStyle(ele){
if (ele.hasAttribute('style') && ele.style['font-size'] != '' && ele.style['font-family']) {
        this.appendStyle = ele.style;
     return this.appendStyle
}else{
  if (ele.previousElementSibling || ele.nextElementSibling) {
  if (ele.previousElementSibling) {
  if (ele.previousElementSibling.hasAttribute('style') && ele.previousElementSibling.style['font-size'] != '' && ele.previousElementSibling.style['font-family']) {
     this.appendStyle = ele.previousElementSibling.style;
     return this.appendStyle
  }
    if(ele.previousElementSibling.children.length > 0 && ele.previousElementSibling.children[0].hasAttribute('style') && ele.previousElementSibling.children[0].style['font-size'] != '' && ele.previousElementSibling.children[0].style['font-family']){
      this.appendStyle = ele.previousElementSibling.children[0].style;
     return this.appendStyle
    }
  
  };
  if (ele.nextElementSibling) {
      if (ele.nextElementSibling.hasAttribute('style') && ele.nextElementSibling.style['font-size'] != '' && ele.nextElementSibling.style['font-family']) {
          this.appendStyle = ele.nextElementSibling.style;
     return this.appendStyle
  }
  if(ele.nextElementSibling.children.length > 0 && ele.nextElementSibling.children[0].hasAttribute('style') && ele.nextElementSibling.children[0].style['font-size'] != '' && ele.nextElementSibling.children[0].style['font-family']){
      this.appendStyle = ele.nextElementSibling.children[0].style;
      return this.appendStyle
    }
  
  }
  }

   if (ele.parentNode) {
      if (ele.parentElement.hasAttribute('style') && ele.parentElement.style['font-size'] != '' && ele.parentElement.style['font-family']) {
          this.appendStyle = ele.parentElement.style;
     return this.appendStyle
    }
    if (ele.parentNode.previousElementSibling || ele.parentNode.nextElementSibling) {
      if (ele.parentNode.previousElementSibling) {
        for (let i = 0; i < ele.parentNode.previousElementSibling.children.length; i++) {
          let childEle = ele.parentNode.previousElementSibling.children[i];
                  if (childEle.children.length > 0 && childEle.hasAttribute('style') && childEle.style['font-size'] != '' && childEle.style['font-family']) {
                    this.appendStyle = childEle.style;
                    return this.appendStyle
        }
                if (childEle.children.length > 0) {
                  if (childEle.children.length > i && childEle.children[i].hasAttribute('style') && childEle.children[i].style['font-size'] != '' && childEle.children[i].style['font-family']) {
                    this.appendStyle = childEle.children[i].style;
                    return this.appendStyle
        }
        }
        }
      }
      if (ele.parentNode.nextElementSibling) {
                for (let i = 0; i < ele.parentNode.nextElementSibling.children.length; i++) {
          let childEle = ele.parentNode.nextElementSibling.children[i];
                  if (childEle.children.length > 0 && childEle.hasAttribute('style') && childEle.style['font-size'] != '' && childEle.style['font-family']) {
                    this.appendStyle = childEle.style;
                    return this.appendStyle
        }
                if (childEle.children.length > 0) {
                  if (childEle.children.length > i && childEle.children[i].hasAttribute('style') && childEle.children[i].style['font-size'] != '' && childEle.children[i].style['font-family']) {
                    this.appendStyle = childEle.children[i].style;
                    return this.appendStyle
        }
        }
        }
      }
    }
    }
  
}
return this.appendStyle
}
  keytxt: any;
  keytxtNested: any;
  appendStyle:ElementRef;
  keyDropdownAppendkey() {
    if (this.xPostion == undefined && this.yPostion == undefined) {
      alerts("Double click the mouse pointer");
    }
    let curser_pos = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    ) as any;  
    let defaultStyle = document.createAttribute('style');
    defaultStyle['font-size'] = '7.0pt';defaultStyle['font-family'] = 'verdana';defaultStyle['color'] = 'black';

    let span_cr_style = this.catchStyle(curser_pos) != undefined ? this.catchStyle(curser_pos) : defaultStyle  ;
    let span_cr = document.createElement("span");
    span_cr.setAttribute("style",`font-size: ${span_cr_style['font-size']};font-family: ${span_cr_style['font-family']}; color: ${span_cr_style['color']}`);
    this.keytxt =document.createTextNode(this.dynamicJsonTextNode)
    //  document.createTextNode("$" + this.dynamicJsonTextNode + "$");
    const el = curser_pos;

    if (el.children.length > 1 && el.children[0].localName == "br") {
      const getParents = (el: any) => {
        for (var parents = []; el; el = el.previousSibling[1]) {
          if (el.childNodes[0].localName == "br") {
            el.childNodes[0].remove();
          }
          parents.push(el);
        }
        return parents;
      };

      getParents(el);
    }
      if (this.dynamicJsonTextNode == 'qrcodeImage') {
       let img = document.createElement("img");
       img.setAttribute("style","height:150px;width:150px;")
       img.src = this.dynamicJsonTextNode;
       img.alt = "Qrcode"
       curser_pos.appendChild(img);
       return
       }
    span_cr.appendChild(this.keytxt);
    curser_pos.appendChild(span_cr);
  }

  keyDropdownAppendkeyNested() {
    if (this.xPostion == undefined && this.yPostion == undefined) {
      alerts("Double click the mouse pointer");
    }
    let curser_pos = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    ) as any;

    const getParents = (el: any) => {
      for (var parents = []; el; el = el.previousSibling[1]) {
        if (el.childNodes[0].localName == "br") {
          el.childNodes[0].remove();
        }
        parents.push(el);
      }
      return parents;
    };
    const el = curser_pos;
    getParents(el);

    let span_cr_style =this.catchStyle(curser_pos);
    let span_cr = document.createElement("span");
    span_cr.setAttribute("style",`font-size: ${span_cr_style['font-size']};font-family: ${span_cr_style['font-family']}; color: ${span_cr_style['color']}`)
    this.keytxtNested =  document.createTextNode( this.dynamicJsonTextNodeNested );
    span_cr.appendChild(this.keytxtNested);
    curser_pos.appendChild(span_cr);
  }

  previewforappendkey() {
    let a = (document.getElementById("cont") as any).innerHTML;
    var kk = this.keytxt.data;
    const re = new RegExp(kk, "g");

    let b = a.match(re);
  }

  async onSaveWordNew() {

    const projectSessionData = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    const userId = projectSessionData.data.clientInfo.usrId;
    const projectDetail = this.shareService.getDataprotool("selectedProjectChooseData");
    let filename: string;

    let ask =await ui.confirm("Do you want to save it as default file?");

    if (ask== true) {
       // *****pm sir start****** this is done on pm sir instruction!
      let newFile = confirm("Save As 'DefaultFile'")
      //  prompt("Save As", "DefaultFile");
      if (newFile) {
        filename = "DefaultFile";
      }else{
        alerts("Failed To Save")
        return
      }
      // *****pm sir end******
      // filename = "DefaultFile";
    } else {
      let fileName = sessionStorage.getItem('fileName');
      let newFile = prompt("Please enter the file name", fileName ? fileName.split('.docx')[0] : "PrintTempFile");
      if (newFile) {
        filename = newFile;
      }else{
        alerts("Failed To Save")
        return
      }
      
    }

    this.DocumentContainer = this.editer.nativeElement;

    var HtmlHead =
      "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></meta><title>Export HTML To Doc</title></head><body style='font-family:Microsoft Sans Serif,Arial,Georgia,Serif;'>";
    var EndHtml = "</body></html>";
    var html =
      HtmlHead +
      this.DocumentContainer.innerHTML.replace(/&nbsp;/g, " ") +
      EndHtml;

  // let converted = htmlDocx.asBlob(html)
    let formData = new FormData();
    formData.append("x", html);
    formData.append("y", filename);
    formData.append("z", this.sageditorService.getData('selectedClientGstn'));
    formData.append("z1", sessionStorage.getItem('isUpload') ? sessionStorage.getItem('isUpload') : 'false');
    formData.append("userId", userId);
    formData.append("projectWorkSpace", projectDetail.jwspace);
    formData.append("projectId", projectDetail.projectId);
    formData.append("projectName", projectDetail.projectname);
    formData.append("formName", this.sageditorService.getData('formName'));
    formData.append("versionNo", this.sageditorService.getData('versionNo'));
    formData.append("mappingId", this.sageditorService.getData('mappingId'));
    formData.append("apiName", this.list.length>0 ?this.apiName:'');
    formData.append("name", this.list.length>0 ?this.apiEndPoint:'');
    

    //  let data={
    //   'x':html,
    //   'filename':filename
    // } 
    this.sageditorService.uploadToPrint(formData).subscribe(
      // this.sageditorService.downloadWordFile(formData).subscribe(
      (res) => {
        if (res instanceof HttpResponse) {
          if (res.status == 200) {
            let data = JSON.parse(res['body']);
            sessionStorage.setItem("fileName", data['fileName']);
            this.container.nativeElement.innerHTML = data['data'].replace("<div class=\"Section0\">",'<div style=\"display:flex;justify-content:center\" class=\"Section0\">');
            success("sucesssfully downloaded!");
          } else {
            alerts("Fail downloaded File");
          }
        }
      },
      (error) => {
        console.error("error", error);
      }
    );
  }
  // confirm("Save it as default templete?");

  onUploadNew() {
    this.wordEditor = false;
    this.wordUplod = true;
  }

  reset() {
    return this.ngAfterViewInit();
  }

  resizeTd(tbl) {
    var col_element,
      next_element,
      cursorStart = 0,
      dragStart = false,
      width,
      height,
      th_width,
      next_width = undefined,
      next_height,
      resize,
      resize_left,
      table_wt,
      resizeCheck;
    var container = tbl,
      // document.getElementById("container"),
      table = tbl,
      // document.getElementById("table_resize"),
      table_th = table.getElementsByTagName("td"),
      bodyRect = document.body.getBoundingClientRect();

    container.style.position = "relative";

    function mouseDown() {
      resize = this;
      resizeCheck = resize.classList.contains("y_resize");
      var col_index = parseInt(resize.getAttribute("data-resizecol")) - 1;
      col_element = table_th[col_index];
      next_element = table_th[col_index + 1];
      dragStart = true;
      cursorStart = resizeCheck ? (event as any).pageX : (event as any).pageY;
      var elm_bound = col_element.getBoundingClientRect();
      width = elm_bound.width;
      table_wt = table.offsetWidth;
      if (next_element != undefined) {
        var next_bound = next_element.getBoundingClientRect();
        next_width = next_bound.width;
      }
      resize_left = this.getBoundingClientRect().left - bodyRect.left;
    }
    function mouseMove() {
      if (dragStart) {
        var cursorPosition = resizeCheck
          ? (event as any).pageX
          : (event as any).pageY;
        var mouseMoved = cursorPosition - cursorStart;
        var newLeft = resize_left + mouseMoved;
        var newWidth = width + mouseMoved;
        var new_nextWidth, new_nextHeight;
        if (next_element != undefined) {
          new_nextWidth = next_width - mouseMoved;
        }
        if (
          newWidth > 30 &&
          (new_nextWidth > 30 || next_element == undefined)
        ) {
          col_element.style.cssText = "width: " + newWidth + "px;";
          if (next_element != undefined) {
            next_element.style.cssText = "width: " + new_nextWidth + "px";
          } else {
            table.style.width = table_wt + mouseMoved + "px";
          }
          resize.style.cssText = "left: " + newLeft + "px;";
        }
      }
    }
    function mouseUp() {
      if (dragStart) {
        dragStart = false;
      }
    }
    function initEvents(table_th) {
      var tb_resize = container.getElementsByTagName("td");
      // container.getElementsByClassName("tb_resize");
      var th_length = table_th.length;
      for (var i = 0; i < th_length; i++) {
        table.addEventListener("mousemove", mouseMove);
        tb_resize[i].addEventListener("mousedown", mouseDown);
        tb_resize[i].addEventListener("mouseup", mouseUp);
        table_th[i].style.width = th_width + "px";
      }
    }
    function setTdWidth() {
      var elm_bound = table.getBoundingClientRect();
      var table_wt = elm_bound.width;
      var th_length = table_th.length;
      th_width = table_wt / th_length;
    }
    function createResizeDiv() {
      var cont = tbl;
      var th_length = table_th.length;
      for (var i = 1; i <= th_length; i++) {
        var yDiv = document.createElement("div") as any;
        yDiv.className = "y_resize tb_resize";
        yDiv.setAttribute("data-resizecol", i);
        var leftPos = i * th_width + 0.5;
        yDiv.style.cssText = "left: " + leftPos + "px;";
        cont.append(yDiv);
      }
    }

    setTdWidth();
    createResizeDiv();
    initEvents(table_th);
  }


  splitColumn() {
    if (this.xPostion == undefined && this.yPostion == undefined) {
      alerts("Double click the mouse pointer")
    }

    // let countTd: any
    let currentRow: HTMLElement;
    let tableRef = (document.elementFromPoint(this.xPostion, this.yPostion) as any);
    let currentEle: HTMLElement;
    let newColVal: number;
    let maxTDCount;
    let cursorTd: any;
    function checkmaxTD(params) {
      if (params.tagName == "TD") {
        cursorTd = params
      }
      if (params.tagName == "TR") {
        maxTDCount = params.children.length;
        return
      }
      checkmaxTD(params.parentElement)
    };
    checkmaxTD(tableRef);
    // if (maxTDCount >= 10) {
    //   alerts('maximum split limit reached!')
    //   return
    // }


    // function nextElementSibling(nextES) {
    //   if (nextES) {
    //     if (nextES.children[0].attributes.hasOwnProperty("colspan")) {
    //       let colval = nextES.children[0].attributes['colspan'].value;
    //       let numColval = Number(colval);
    //       numColval++
    //       nextES.children[0].attributes['colspan'].value = numColval.toString();
    //       nextElementSibling(nextES.nextElementSibling)
    //     } else {
    //       newColVal = 2;
    //       nextES.children[0].setAttribute("colspan", newColVal.toString());
    //       nextElementSibling(nextES.nextElementSibling)
    //     }

    //   }
    // };
    // function previousSibling(previoustS) {
    //   if (previoustS) {
    //     if (previoustS.children[0].attributes.hasOwnProperty("colspan")) {
    //       let colval = previoustS.children[0].attributes['colspan'].value;
    //       let numColval = Number(colval);
    //       numColval++
    //       previoustS.children[0].attributes['colspan'].value = numColval.toString();;
    //       previousSibling(previoustS.previousSibling)
    //     } else {
    //       newColVal = 2;
    //       previoustS.children[0].setAttribute("colspan", newColVal.toString());
    //       previousSibling(previoustS.previousSibling)
    //     }

    //   }
    // };


    for ([]; tableRef; tableRef = tableRef.parentNode) {
      if (tableRef.nodeName == 'TD') {
        currentEle = tableRef
      }
      if (tableRef.nodeName == 'TR') {
        currentRow = tableRef;
        break
      }
    };

    if (currentEle.nodeName == 'TD' && !currentEle.attributes.hasOwnProperty("colspan")) {
      let nxtTr = currentEle.parentElement.nextElementSibling;
      let preTr = currentEle.parentElement.previousElementSibling;

      // newColVal=2;

      // if (!!nxtTr && nxtTr.children[0].attributes.hasOwnProperty('colspan')) {
      //   nextElementSibling(nxtTr);
      //   previousSibling(preTr);
      // }
      // else {
      //   if (!!preTr && preTr.children[0].attributes.hasOwnProperty('colspan')) {
      //     nextElementSibling(nxtTr);
      //     previousSibling(preTr);
      //   }
      // }



      this.createTd(newColVal, currentRow, currentEle, tableRef);
      // this.resizeTable(currentRow.parentElement.parentElement);

      // if (!!nxtTr && !nxtTr.children[0].attributes.hasOwnProperty('colspan')) {

      //   nextElementSibling(nxtTr);
      //   previousSibling(preTr);

      // }
      // if (!!preTr && !preTr.children[0].attributes.hasOwnProperty('colspan')) {

      //   nextElementSibling(nxtTr);
      //   previousSibling(preTr);

      // }
    } else {

      // colspan value find for specific td

      // let colspanValue = currentEle.attributes['colspan'].value;
      // let newColspan = parseInt(colspanValue)
      // if (newColspan % 2 !== 0) {
      //   newColVal = newColspan / 2
      //   currentEle.attributes['colspan'].value = (newColVal + 1 / 2).toString();
      //   (newColVal - 1 / 2)
      // };
      // if (newColspan % 2 == 0) {
      //   if (newColspan == 1) {
      //     newColVal = newColspan = 0;
      //     currentEle.attributes['colspan'].value = newColVal.toString();
      //   } else {
      //     newColVal = (newColspan) / 2
      //     currentEle.attributes['colspan'].value = newColVal.toString();
      //   }
      // }

      this.createTd(newColVal, currentRow, currentEle, tableRef);

      // this.resizeTable(currentRow.parentElement.parentElement);
    }

  }
  // createTd(newColVal, currentRow, currentEle) {
  //   console.log(newColVal, currentRow, currentEle)


  //   var cell = document.createElement("td");
  //   if (newColVal != undefined || null) {
  //     cell.setAttribute("colspan", newColVal.toString());
  //   }
  //   // if (currentRow.children[0].children[0].children[0]) {
  //   //   altStyle = currentRow.children[0].children[0].children[0].attributes['style'].value;
  //   // }

  //   var span = document.createElement("span");
  //   span.setAttribute('style', 'height: -webkit-fill-available')
  //   span.setAttribute('class','spanText')
  //   let newText = document.createTextNode('New cell');
  //   cell.appendChild(span);
  //   span.appendChild(newText);
  //   // currentRow.children[0].attribute.hasOwnProperty('style') ? currentRow.children[0].attribute['style'].value : "color:black; border: 1px solid black;  border-collapse: collapse;"
  //   cell.setAttribute("style", "color:black; border: 1px solid black;  border-collapse: collapse;width:0px");
  //   currentRow.insertBefore(cell, currentEle)
  //   let table = document.getElementsByClassName('tableW') as any;
  //   this.resizableGrid(table[0])

  //   // if (!currentEle.nextElementSibling) {
  //   //   currentEle.after(cell)
  //   // } else { }
  // }


  createTd(newColVal, currentRow, currentEle, tableRef) {
    var cell = document.createElement("td");
    var span = document.createElement("span");
    span.setAttribute('style', 'height: -webkit-fill-available');
    span.setAttribute('class', 'spanText');
    let newText = document.createTextNode('New cell');
    span.appendChild(newText);
    cell.appendChild(span);
    cell.setAttribute("style", "color:black; border: 1px solid #bfbfbf; border-collapse: collapse;cursor:text;word-break:break-all;min-width:31px");
    cell.setAttribute('contenteditable', "true");

    currentRow.insertBefore(cell, currentEle.nextElementSibling);


    let columnIndex = Array.from(currentRow.children).indexOf(currentEle);


    let table = tableRef.parentElement.parentElement

    console.log(tableRef.parentElement.parentElement, "fyertfggfgewufguwerfugrfugerigfgefuerfigfer")
    // let rows = table.rows;

    let row = currentRow
    let max = 0

    for (var a = 0; a <= currentEle.cellIndex; a++) {
      max += Number(row.children[a].colSpan) || 1
    }
    let tr = document.getElementsByTagName('tr') as any;
    for (var j = 0; j < tr.length; j++) {
      if (row.rowIndex != j) {
        let cells = tr[j].getElementsByTagName("td");
        let maxColspan = 0
        let count = 0

        if (currentEle.colSpan > 1) {
          currentEle.setAttribute('colspan', currentEle.colSpan - 1)
          break;
        }
        else {
          for (var k = 0; k < cells.length; k++) {
            maxColspan += cells[k].colSpan
            if (maxColspan >= max && count == 0) {
              cells[k].colSpan += 1
              count++
            }
          }
        }
      }
    }
    // for (let i = 0; i < rows.length; i++) {

    //   let cells = rows[i].cells;
    //   for (let j = 0; j < cells.length; j++) {

    //     if (j === columnIndex && cells[j] !== currentEle && cells[j] !== cell) {

    //       if (cells[j].getAttribute('colspan') != null) {
    //         //console.log(cells[j].getAttribute('colspan')+1,(Number(cells[j].getAttribute('colspan'))+1).toString())
    //         cells[j].setAttribute('colspan', (Number(cells[j].getAttribute('colspan')) + 1).toString());


    //       }
    //       else {
    //         cells[j].setAttribute('colspan', '2');

    //       }
    //     }
    //   }
    // }
    this.resizableGrid(table);
  }





  rowH: any; //highlighted row H(highlight);
  colH: any; //highlighted column H(highlight);



  tableSelectRC() {
    const tableGridDesign = document.getElementsByClassName(
      "table-dropdown-grid-box"
    );
    let rowval: number;
    let colval: number;
    let clicked = "No";

    if (this.elementclicked == undefined) {
      alerts("First, Click The Location To Insert Table !!");
      return;
    }

    for (let index = 0; index < tableGridDesign.length; index++) {
      let element = tableGridDesign[index];

      element.addEventListener(
        "mousemove",
        (event) => {
          event.target["style"].backgroundColor = "orange";
          this.rowH = Number(event.target["dataset"].row);
          this.colH = Number(event.target["dataset"].column);

          let colNo = Number(event.target["dataset"].column);
          selection(event.target["previousElementSibling"], colNo);

          function selection(params: any, colNo) {
            if (params) {
              if (Number(params.dataset.column) <= colNo) {
                params.style.backgroundColor = "orange";
                selection(params["previousElementSibling"], colNo);
              } else {
                params.style.backgroundColor = "";
                selection(params["previousElementSibling"], colNo);
              }
            }
          }
        },
        false
      );

      element.addEventListener(
        "mouseout",
        (event) => {
          removeSelection(event.target["nextElementSibling"]);

          function removeSelection(params: any) {
            if (params) {
              params.style.backgroundColor = "";
              removeSelection(params["nextElementSibling"]);
            }
          }
        },
        false
      );

      element.addEventListener(
        "click",
        (event) => {
          if (clicked == "Yes") {
            return;
          }
          rowval = Number(event.target["dataset"].row);
          colval = Number(event.target["dataset"].column);
          this.createTable(rowval, colval);
          clicked = "Yes";
          return;
        },
        false
      );
    }
    return;
  }

  exit_editor(){
      document.getElementById('dashSideBar').classList.add('d-none');
      this.router.navigate(["dashboard/database/projectToolFirst/newprojectinfo/project_type"]);
  }

  resize(target: string) {
    // if (this.xPostion == undefined && this.yPostion == undefined) {
    //   alerts("Double click the mouse pointer");
    // }
    let tables = document.getElementsByTagName('table')
    for (var i = 0; i < tables.length; i++) {
      this.resizableGrid(tables[i]);
      this.resizeImage(tables[i])
    }
  }
resizableGrid(table) {
  let tableRef = document.elementFromPoint(
    this.xPostion,
    this.yPostion
  ) as HTMLElement;
  let td
  let tables
  if (tableRef.nodeName == 'TD') {
    td = tableRef
  }
 
  console.log(tableRef,td,tableRef.parentElement.parentElement,"tableRef")
  table.addEventListener("mouseover", function () {
    this.style.outline = 'solid #0000ff';
  });
  table.addEventListener("mouseout", function () {
    this.style.outline = 'solid transparent';
  });
  // removeEventListeners();
  table.style.margin = 'auto'
  table.style.maxWidth = '90%'
  addColgroupToTable(table)
  var colgroup = table.getElementsByTagName('colgroup')[0];
  if (!colgroup) return;

  var cols = colgroup.getElementsByTagName('col');
  var cells = table.getElementsByTagName('td');
  var rows = table.getElementsByTagName('tr');
  let curCol, nxtCol, curColIndex, nxtColIndex;

  function addColgroupToTable(table) {
    let group = table.getElementsByTagName('colgroup')[0]
    if (group != null || group != undefined) {
      group.remove()
    }
    var colgroup = document.createElement('colgroup');
    var maxCols = 0;
    var firstRow = table.rows[0];
    for (var j = 0; j < firstRow.cells.length; j++) {
      var colspan = firstRow.cells[j].colSpan || 1;
      maxCols += colspan;
    }
    for (var k = 0; k < maxCols; k++) {
      var col = document.createElement('col');
      colgroup.appendChild(col);
    }
    table.insertBefore(colgroup, table.firstChild);
    var colsW = colgroup.getElementsByTagName('col') as any;
    for (var i = 0; i < colsW.length; i++) {
      colsW[i].style.width = colsW[i].offsetWidth + 'px'
      colsW[i].style.minWidth = '31px'
    }
  }


  function styleCell(cell, last?) {
    cell.setAttribute('style', 'color:black; border: 1px solid #bfbfbf; border-collapse: collapse; cursor: text; word-break: break-all; min-width: 31px;');
    if (last != 'last') {
      const div = createDiv();
      cell.appendChild(div);
    }
    cell.style.position = 'relative';
    cell.style.height = '25px'
    addEventListeners();

  }

  function createDiv() {
    const div = document.createElement('div') as any;
    div.classList.add('increase');
    div.style.top = 0;
    div.style.right = 0;
    div.style.width = '7px';
    div.style.position = 'absolute';
    div.style.cursor = 'col-resize';
    div.style.userSelect = 'none';
    div.style.height = '100%';
    div.setAttribute('contenteditable', 'false');
    return div;
  }


  //  function removeEventListeners() {
  //      const divs = document.querySelectorAll('.increase');
  //      divs.forEach(div => {
  //       div.removeEventListener('mousedown', handleMouseDown);
  //       div.removeEventListener('mouseover', mouseover);
  //       div.removeEventListener('mouseout', mouseout);
  //         });
  //         document.removeEventListener('mousemove', handleMouseMove);
  //         document.removeEventListener('mouseup', handleMouseUp);
  //  }

  function addEventListeners() {

    const divs = table.querySelectorAll('.increase');
    divs.forEach(div => {
      div.addEventListener('mousedown', handleMouseDown);
      div.addEventListener('mouseover', mouseover);
      div.addEventListener('mouseout', mouseout);
    });
    table.addEventListener('mousemove', handleMouseMove);
    table.addEventListener('mouseup', handleMouseUp);
  }

  function mouseover(e) {
    e.target.style.height = table.offsetHeight + 'px'
    e.target.style.marginRight = '-4px'

    e.target.style.top = -e.target.parentElement.parentElement.offsetTop + 'px'
    e.target.style.backgroundColor = '#0d65ff';
    e.target.style.opacity = '0.25';
  }

  function mouseout(e) {
    // if(bool){
    e.target.style.backgroundColor = null;
    e.target.style.opacity = null;
    e.target.style.top = 0
    // }
  }


  let resizing;
  let startX = 0;
  let startWidth = 0;
  let startNextWidth = 0;
  let storeEvent
  let bool = true
  function handleMouseDown(e) {

    resizing = true;
    startX = e.pageX;
    curCol = e.target.parentElement;
    nxtCol = curCol.nextElementSibling;
    curColIndex = Array.from(curCol.parentElement.children).indexOf(curCol);
    var children = curCol.parentElement.children
    for (var i = 0; i < children.length; i++) {
      var colspan = children[i].colSpan || 1;
      if (colspan > 1) {
        curColIndex += colspan - 1;
      }
      if (children[i] === curCol) {
        break;
      }
    }
    nxtColIndex = curColIndex + 1;
    const padding = paddingDiff(cols[curColIndex]);
    startWidth = cols[curColIndex].offsetWidth - padding
    startNextWidth = cols[nxtColIndex].offsetWidth - padding
    bool = false
  }

  function handleMouseMove(e) {

    if (!resizing) return;

    const diffX = e.pageX - startX;
    const newCurColWidth = startWidth + diffX;
    const newNxtColWidth = startNextWidth - diffX;

    if (newCurColWidth >= 31 && newNxtColWidth >= 31) {
      cols[curColIndex].style.width = `${newCurColWidth}px`;
      cols[nxtColIndex].style.width = `${newNxtColWidth}px`;
    }
  }

  function handleMouseUp(e) {
    curCol = undefined;
    nxtCol = undefined;
    curColIndex = undefined;
    nxtColIndex = undefined
    resizing = false;
    bool = true
  }


  function paddingDiff(col) {
    if (getStyleValue(col, 'box-sizing') === 'border-box') {
      return 0;
    }
    const padLeft = parseInt(getStyleValue(col, 'padding-left'));
    const padRight = parseInt(getStyleValue(col, 'padding-right'));
    return padLeft + padRight;
  }

  function getStyleValue(element, styleProperty) {
    const style = window.getComputedStyle(element);
    return style.getPropertyValue(styleProperty);
  }

  for (let i = 0; i < rows.length; i++) {
    let cell = rows[i].getElementsByTagName('td')
    for (let j = 0; j < cell.length; j++) {
      let existingDiv = cell[j].querySelector('.increase');
      if (existingDiv) {
        existingDiv.remove();
      }
      if (j == cell.length - 1) {
        styleCell(cell[j], 'last');

      }
      else {
        styleCell(cell[j]);
      }
    }
  }
}

collector=[];
mouseSelect1(){
  let doc :any= document.getElementsByClassName("document");

  doc[0].addEventListener("dblclick",(event:any) => {
if (event.target.nodeName == "TD") {
  event.target["style"].backgroundColor = "orange";
      if (!this.collector.hasOwnProperty(event.target)) {
        event.target.id = 'collector_'+ event.timeStamp;
           this.collector.push(event.target)
    }
  }else{
    let tdele = event.target.parentNode
    if (tdele.nodeName == 'TD') {
      tdele["style"].backgroundColor = "orange";
      if (!this.collector.hasOwnProperty(tdele)) {
        tdele.id = 'collector_'+ event.timeStamp;
           this.collector.push(tdele)
    }
    }
  }
  },false);

  doc[0].addEventListener("click",(event:any) => {
  let unselect = (param)=>{ if ( param["style"].backgroundColor = "orange") {
      param["style"].backgroundColor = "";
  
      this.collector.forEach((ele)=>{
        if (ele == param) {
          const index = this.collector.indexOf(ele);
                  if (index > -1) {
                    this.collector.splice(index, 1);
                  }
      }
      })
    }
  } 
if (event.target.nodeName == "TD") {
  unselect(event.target)
}else{
  let parent_node = event.target.parentNode;
  if (parent_node.nodeName == "TD") {
    unselect(parent_node)
  }
}
},false);


  // mousedrag
// let mousepressed = false;
//   doc[0].addEventListener("mousedown",(event:any) => {
//     event.preventDefault();
//     mousepressed = true
//   },false)

//   doc[0].addEventListener("mousemove", (e:any) => {
//     if (mousepressed) {
  
//   if (e.target.nodeName == 'TD') {
//   if (!this.collector.hasOwnProperty(e.target)) {
//     this.collector.push(e.target)
//   }
//   if (e.target["style"].backgroundColor == "orange") {
//     e.target["style"].backgroundColor = "";
//   }else{
//     e.target["style"].backgroundColor = "orange";
//   }
//   }
// }
// },false);

// doc[0].addEventListener("mouseup", (e:any) => {
//   e.preventDefault();
//   if (mousepressed) {
//     mousepressed = false;
//   }
// },false);
}

selectedCell: any
  nextCell: any
  previousCell: any
  upCell: any
  downCell: any

  upBtn: any = false
  downBtn: any = false
  leftBtn: any = false
  rightBtn: any = false

  merge(first?: any) {
    // this.selectedCell =null
    this.nextCell = null
    this.previousCell = null
    this.upCell = null
    this.downCell = null
    let upEle = document.getElementById('upBtn') as any;
    let downEle = document.getElementById('downBtn') as any;
    let rightEle = document.getElementById('rightBtn') as any;
    let leftEle = document.getElementById('leftBtn') as any;
    let row = document.getElementsByTagName('tr') as any
    this.upBtn = false
    this.downBtn = false
    this.leftBtn = false
    this.rightBtn = false
    upEle.style.pointerEvents = 'none'
    upEle.style.opacity = '0.4'
    downEle.style.pointerEvents = 'none'
    downEle.style.opacity = '0.4'
    leftEle.style.pointerEvents = 'none'
    leftEle.style.opacity = '0.4'
    rightEle.style.pointerEvents = 'none'
    rightEle.style.opacity = '0.4'
   

    document.addEventListener('click', (e: any) => {
      if ((e.target as HTMLElement).tagName === "TD") {
        if (this.selectedCell) {
          this.selectedCell.style.backgroundColor = ''
          this.selectedCell = null
        }
      }
    })


    function findSameCell(previousCell,rowIndex,currentRow){
      let index = rowIndex
  console.log("entered",row[index].children.length>currentRow.children.length,row[index].children.length,currentRow.children.length,index)
       while(row[index].children.length==currentRow.children.length){
           console.log(row[index],currentRow)
           index--;
       }
      return index--
    }

   function findGap(previousCell,selectedCell){
      var td1 = previousCell
      var td2 = selectedCell

      var leftEdge1 = td1.offsetLeft;
      var rightEdge1 = leftEdge1 + td1.offsetWidth;
      var leftEdge2 = td2.offsetLeft;
      var rightEdge2 = leftEdge2 + td2.offsetWidth;

     
      var gap = leftEdge2 - rightEdge1;
      console.log("Gap between TDs: " + gap + "px");
     
       if(gap>0){
        return false
       }
       else{
        return true
       }
  
    }

    if (this.selectedCell) {
      this.nextCell = this.selectedCell.nextElementSibling;
      let gapRight = true;
      if( this.nextCell){
      if(this.nextCell.rowSpan<=1){
        console.log("finding gapRight")
          gapRight = findGap(this.selectedCell,this.nextCell)
          if(gapRight==false){
            this.nextCell = null
          }
      }
    }

      this.previousCell = this.selectedCell.previousElementSibling;
      let gapLeft = true;
      if(this.previousCell){
      if(this.previousCell.rowSpan<=1){
          gapLeft = findGap(this.previousCell,this.selectedCell)
          if(gapLeft==false){
            this.previousCell = null
          }
      }
    }
      


    
      if (this.selectedCell.parentElement.previousElementSibling) {
        let count=0
        // this.upCell = this.selectedCell.parentElement.previousElementSibling.children[this.selectedCell.cellIndex]
        let checkRowspan = row[this.selectedCell.parentElement.previousElementSibling.rowIndex].children
        for (var i = 0; i <=this.selectedCell.cellIndex+count && i <checkRowspan.length; i++) {
          if (checkRowspan[i].hasAttribute('rowspan')) {
            count++
          }
        }
        if (count > 1) {
          this.upCell =this.selectedCell.parentElement.previousElementSibling.children[this.selectedCell.cellIndex + count]
        }
        else {
          this.upCell = this.selectedCell.parentElement.previousElementSibling.children[this.selectedCell.cellIndex]  
        }
        console.log(this.upCell,"errrrrrrgvetrgtgkotkgrtgortkgo")
          }
         

      if (this.selectedCell.parentElement.nextElementSibling) {
        let count = 0
        if (this.selectedCell.parentElement.nextElementSibling.children.length >= this.selectedCell.cellIndex) {
          if (this.selectedCell.rowSpan > 1) {
            let index = this.selectedCell.parentElement.rowIndex + this.selectedCell.rowSpan;
            this.downCell = row[index].children[this.selectedCell.cellIndex]
            let checkRowspan = row[this.selectedCell.parentElement.rowIndex].children
            for (var i = 0; i < this.selectedCell.cellIndex; i++) {
              if (checkRowspan[i].hasAttribute('rowspan')) {
                count++
              }
            }
            if (count >= 1) {
              this.downCell = row[index].children[this.selectedCell.cellIndex - count]
            }
            else {
              this.downCell = row[index].children[this.selectedCell.cellIndex]
            }
          }
          else {
            let checkRowspan = row[this.selectedCell.parentElement.rowIndex].children
            for (var i = 0; i < this.selectedCell.cellIndex; i++) {
              if (checkRowspan[i].hasAttribute('rowspan')) {
                count++
              }
            }
            if (count >= 1) {
              this.downCell = this.selectedCell.parentElement.nextElementSibling.children[this.selectedCell.cellIndex - count]
            }
            else {
              this.downCell = this.selectedCell.parentElement.nextElementSibling.children[this.selectedCell.cellIndex]
            }
          }
        }
      }

      if (this.upCell) {
        if (this.upCell.colSpan != this.selectedCell.colSpan) {
          this.upCell = null
          this.upBtn = false
          upEle.style.pointerEvents = 'none'
          upEle.style.opacity = '0.4'
        }
        else {
          this.upBtn = true
          upEle.style.pointerEvents = 'all'
          upEle.style.opacity = ''
        }
      }
      if (this.downCell) {
        if (this.downCell.colSpan != this.selectedCell.colSpan) {
          this.downCell = null
          this.downBtn = false
          downEle.style.pointerEvents = 'none'
          downEle.style.opacity = '0.4'
        }
        else {
          this.downBtn = true
          downEle.style.pointerEvents = 'all'
          downEle.style.opacity = ''
        }
      }
      if (this.nextCell) {
        if (this.nextCell.rowSpan != this.selectedCell.rowSpan) {
          this.nextCell = null
          this.rightBtn = false
          rightEle.style.pointerEvents = 'none'
          rightEle.style.opacity = '0.4'
        }
        else {
          this.rightBtn = true
          rightEle.style.pointerEvents = 'all'
          rightEle.style.opacity = ''
        }
      }
      if (this.previousCell) {
        if (this.previousCell.rowSpan != this.selectedCell.rowSpan) {
          this.previousCell = null
          this.leftBtn = false
          leftEle.style.pointerEvents = 'none'
          leftEle.style.opacity = '0.4'
        }
        else {
          this.leftBtn = true
          leftEle.style.pointerEvents = 'all'
          leftEle.style.opacity = ''
        }
      }

    }
    else {
      if (!first)
        alerts('Double click to select a cell first!')
    }
    console.log(this.upCell,this.downCell,this.previousCell,this.nextCell,this.selectedCell)
  }

  mergeCell(position: any) {

    let storeText
    let innerText
    if (this.previousCell && position == 'left') {
      // if(this.selectedCell.rowSpan>1){
      //   let rowspan = Number(this.selectedCell.rowSpan)
      //   for(let i=0;i<rowspan;i++){
      //     if(this.previousCell.parentElement.nextElementSibling.children[this.previousCell.cellIndex]){
      //       console.log(this.previousCell.parentElement.nextElementSibling.children[this.previousCell.cellIndex],"row")
      //       this.previousCell.parentElement.nextElementSibling.children[this.previousCell.cellIndex].remove()
      //     }
      //   }
      // }
      storeText = this.previousCell.innerText
      this.previousCell.remove()
      this.selectedCell.colSpan = this.selectedCell.colSpan + this.previousCell.colSpan
      innerText = this.selectedCell.innerText
      this.selectedCell.innerText = storeText + '\n' + innerText
    }
    else if (this.downCell && position == 'down') {
      storeText = this.downCell.innerText
      this.downCell.remove()
      let rowspan = Number(this.selectedCell.rowSpan || 1)
      this.selectedCell.rowSpan = rowspan + 1
      innerText = this.selectedCell.innerText
      this.selectedCell.innerText = innerText + '\n' + storeText
    }
    else if (this.upCell && position == 'up') {
      storeText = this.selectedCell.innerText
      this.selectedCell.remove()
      this.upCell.rowSpan = this.selectedCell.rowSpan + 1
      innerText = this.upCell.innerText
      this.upCell.innerText = innerText + '\n' + storeText
    }
    else if (this.nextCell && position == 'right') {
      storeText = this.nextCell.innerText
      this.nextCell.remove()
      this.selectedCell.colSpan = this.selectedCell.colSpan + this.nextCell.colSpan
      innerText = this.selectedCell.innerText
      this.selectedCell.innerText = innerText + '\n' + storeText
    }
    this.selectedCell.style.backgroundColor = ''
    let cell = this.selectedCell || this.upCell
    let table = this.upTo(cell, 'table')
    console.log(table,cell,"tableeeeeeeeeeeeeeeeeeee")
    this.resizableGrid(table)
  }
  upTo(el, tagName) { 
    let currentRow;
    let tableRef = document.elementFromPoint(
      this.xPostion,
      this.yPostion
    ) as HTMLElement;
    let td
    let table
    if (tableRef.nodeName == 'TD') {
      td = tableRef
    }
    if (tableRef.nodeName == 'TABLE') {
      table = tableRef
    }
    console.log(tableRef,td,table,"tableRef")
    tagName = tagName.toLowerCase();
    while (el && el.parentNode) {
      el = el.parentNode;
      if (el.tagName && el.tagName.toLowerCase() == tagName) {
        return el;
      }
    }

    return null;
  }

  



splitColumnH(){
  function getTr(params:any) {
    if (params.parentElement.nodeName == 'TD') {
      orignialTD = params.parentElement;
      orignialTD.style["border-style"] = 'solid';
      orignialRow = params.parentElement.parentElement;
      trAttr = params.parentElement.parentElement.attributes;
      tdAttr = params.parentElement.attributes;
    }else{
      getTr(params.parentElement);
    }
  };
  function checkRowSpan(params) {
    if (params.previousSibling.children.length > 1) {
                for (let i = 0; i < params.previousSibling.children.length; i++) {
      if (params.previousSibling.children[i].hasAttribute('rowSpan')) {
        let rowspanVal = Number(params.previousSibling.children[i].rowSpan) + 1;
        let val = rowspanVal.toString()
        params.previousSibling.children[i].setAttribute('rowSpan',val);
      }
    }
    }else{
      checkRowSpan(params.previousSibling);
    }

  };
  
  let trAttr,tdAttr,orignialRow,orignialTD;
  let tableRef = (document.elementFromPoint(this.xPostion, this.yPostion) as any);
  if (tableRef.nodeName == 'TD') {
    orignialTD = tableRef;
    orignialTD.style["border-style"] = 'solid';
    orignialRow = tableRef.parentElement;
    trAttr = tableRef.parentElement.attributes;
    tdAttr = tableRef.attributes;
  }else{
    getTr(tableRef)
  }

  let newRow = document.createElement('tr');
    if (trAttr.length > 0) {
      this.setAttrib(newRow,trAttr)
    }


  let newTD = document.createElement('td');
  if (tdAttr.length > 0) {
      this.setAttrib(newTD,tdAttr)
  };
  newTD.style["border-style"] = 'solid';
  // newTD.style.removeProperty("border-style");

  let newSpan = document.createElement('span');
  newSpan.textContent = 'New cell';
  newTD.appendChild(newSpan);
  newRow.appendChild(newTD);

  orignialRow.parentElement.insertBefore(newRow,orignialRow.nextElementSibling);
  for (let index = 0; index < orignialRow.children.length; index++) {
    if (orignialRow.children[index] != orignialTD) {
      if (orignialRow.children[index].hasAttribute('rowSpan')) {
        let rowspanVal = Number(orignialRow.children[index].rowSpan) + 1;
        let val = rowspanVal.toString()
        orignialRow.children[index].setAttribute('rowSpan',val);
      }else{
      orignialRow.children[index].setAttribute('rowSpan','2');
    }
    }else{
      if (orignialRow.children.length < 2) {
        checkRowSpan(orignialRow);
      }else{
        if (orignialTD.hasAttribute('rowSpan')) {
          orignialTD.removeAttribute('rowSpan');
        }
      }
    }
  }


}
 setAttrib(element,params) {
  for (let index = 0; index < params.length; index++) {
    element.setAttribute(params[index].name,params[index].nodeValue);
  }
};
formData: any
  selectedJsonName: any = null;
  selectedJsonLabel: any = null;
  selectedJsonType: any = null;
  storePath: string = ''
  dropdownShow() {
    let ele = document.getElementById('mainCont') as any;
    ele.classList.toggle('d-none');
    if(ele.classList.contains('d-none')){
    const allNestedDropdowns = document.querySelectorAll('.positionedSubChild');
    allNestedDropdowns.forEach((dropdown: HTMLElement) => {
        dropdown.classList.add('d-none');
    });
  }
  }
  subDropdown(event: any) {
    event.preventDefault();
    event.stopPropagation();
    let currentLi = event.target.tagName === 'SPAN' ? event.target.parentElement : event.target;
    let nestedDropdown = currentLi.querySelector('.positionedSubChild');
    const allNestedDropdowns = currentLi.parentElement.querySelectorAll('.positionedSubChild');
   
    allNestedDropdowns.forEach((dropdown: HTMLElement) => {
      if (dropdown !== nestedDropdown) {
        dropdown.classList.add('d-none');
        const liItems = dropdown.getElementsByTagName('li');
        Array.from(liItems).forEach(li => li.classList.remove('selected'));
      }
    });
    let ul = currentLi.parentElement;
    Array.from(ul.children).forEach((li: any) => {
      if (!li.isEqualNode(currentLi)) {
        li.classList.remove('selected');
      }
    });
    currentLi.classList.add('selected');
    if (nestedDropdown) {
      nestedDropdown.classList.toggle('d-none');
      nestedDropdown.style.top = currentLi.getBoundingClientRect().top - currentLi.parentElement.parentElement.getBoundingClientRect().top + 'px';
    }
  }
  currentDrop: any
  getRecData(data) {
    if (!data.hasOwnProperty('child')) {
      function findPathToFieldPath(data, fieldName, currentPathPath = '') {
        for (const obj of data) {
          // console.log(data);
          const path = currentPathPath
            ? `${currentPathPath}.${obj.name}`
            : obj.name;
          if (obj.name === fieldName) {
            return path;
          }
          if (obj.child) {
            const foundPath = findPathToFieldPath(obj.child, fieldName, path);

            if (foundPath) {
              return foundPath;
            }
          }
        }
        return null;
      }
      function findPathToFieldType(
        data,
        fieldType,
        fieldName,
        currentPathPath = ''
      ) {
        for (const obj of data) {
          // console.log(data);
          const path = currentPathPath
            ? `${currentPathPath}.${obj.type}`
            : obj.type;
          if (obj.type === fieldType && obj.name === fieldName) {
            return path;
          }
          if (obj.child) {
            const foundPath = findPathToFieldType(
              obj.child,
              fieldType,
              fieldName,
              path
            );
            if (foundPath) {
              return foundPath;
            }
          }
        }
        return null;
      }
      this.selectedJsonName = data.name
      this.selectedJsonLabel = data.caption
      this.selectedJsonType = findPathToFieldType(this.list, data.type, data.name);
      this.storePath = findPathToFieldPath(this.list, data.name);
      return false;
    }
  }

  insertHtmlInEditor(evt) {
    evt = evt || window.event;
    let ele = document.getElementById('mainCont') as any;
    if (!ele.classList.contains('d-none')) {
      if (evt.keyCode == 13 && evt.key == 'Enter') {
        let html = `<span class=${this.selectedJsonName} path=${this.storePath} type=${this.selectedJsonType}>${this.selectedJsonName}
    <span style="display:none">${this.storePath}::${this.selectedJsonType}</span><span>`
        this.getSelect(html)
        return false;
      }
    }
  };


  getSelect(html) {
    var sel, range, expandedSelRange, node;
    let document = window.document as any;
    let selection = window.getSelection() as any;
    if (window.getSelection) {
      sel = window.getSelection();
      if (sel.getRangeAt && sel.rangeCount) {
        range = window.getSelection().getRangeAt(0);
        expandedSelRange = range.cloneRange();
        range.collapse(false);

        var el = document.createElement("div");
        el.innerHTML = html;
        var frag = document.createDocumentFragment(), node, lastNode;
        while ((node = el.firstChild)) {
          lastNode = frag.appendChild(node);
        }
        range.insertNode(frag);

        if (lastNode) {
          expandedSelRange.setEndAfter(lastNode);
          sel.removeAllRanges();
          sel.addRange(expandedSelRange);
        }
      }
    } else if (document.selection && document.selection.createRange) {
      range = document.selection.createRange();
      expandedSelRange = range.duplicate();
      range.collapse(false);
      range.pasteHTML(html);
      expandedSelRange.setEndPoint("EndToEnd", range);
      expandedSelRange.select();
    }
    this.selectedJsonName = '';
    this.selectedJsonLabel = '';
    this.selectedJsonType = '';
    this.storePath = ''
  }

  apiName:any
  apiEndPoint:any
  getDataApiClick(event){
   this.list = []
    this.apiName = event.target.value
    this.apiEndPoint=  event.target.options[event.target.options.selectedIndex].text
   this.sageditorService.getKeyValJson(this.apiName).subscribe((res:any)=>{
    this.list = res['data'];
   })
  }
  
  SoftwareFormList: any
  getSoftwareFormList(formId, event) {
    this.SoftwareFormList = []
    this.sageditorService.getFormMapping(formId).subscribe((res: any) => {
      this.SoftwareFormList = res['data'];
    })
    const parentItem = event.target.parentElement;
    const ul = event.target.parentElement.parentElement;
    const child = ul.children;

    for (let i = 0; i < child.length; i++) {
      const submenu = child[i].querySelector('.dropdown-menu');
      if (submenu && submenu !== parentItem.querySelector('.dropdown-menu')) {
        submenu.classList.remove('show');
      }
    }

    if (event.target.tagName == 'A') {
      for (let i = 0; i < child.length; i++) {
        ul.children[i].classList.remove('selected');
      }
      parentItem.classList.add('selected');
    }

    let ele = event.target.nextSibling
    ele.classList.toggle('show') 
  }

  formDropdown(event) {
    const ul = event.target.nextSibling.children;
    for (let i = 0; i < ul.length; i++) {
      ul[i].children[1].classList.remove('show')
    }
    let ele = document.getElementById('formDropdown') as any;
    ele.classList.toggle('show') 
  }



}
