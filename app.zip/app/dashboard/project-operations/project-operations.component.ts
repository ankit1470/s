import { Component, OnInit } from '@angular/core';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var SdmtGridT;
@Component({
  selector: 'app-project-operations',
  templateUrl: './project-operations.component.html',
  styleUrls: ['./project-operations.component.scss']
})
export class ProjectOperationsComponent implements OnInit {
  selectedProject: any;
  projectFiles = [];
  classesChanges:boolean = false;
  class1:boolean = false;
  switch_expression:any = '';
  operationName = '';
  pageOperationsList = [
    {
      name:'design',
      label:'Control properties',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    { 
      name:'event',
      label:'Events',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      name:'formValidation',
      label:'Validation',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      index:3,
      name:'dBMapping',
      label:'DBMapping',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      name:'language',
      label:'Language',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      name:'voice',
      label:'Voice',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      name:'multilingual',
      label:'Multiligual Input',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      name:'toolTipMessage',
      label:'Tooltip Message',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      name:'themes',
      label:'Themes',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      name:'cloneDesign',
      label:'Buttons Rights data extract',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
    {
      name:'imagesDetails',
      label:'Image Details',
      toolTipMsg:'All Correct',
      setActive:false,
      error:false,
    },
  ];
  errorShowForDb:boolean=false;
  showValidationIcons:boolean=false;
  languageStatus:any;
  allImagesOfProject: any;

  constructor(
    public shareService: SagShareService,
    public studioDragDropService: CommonStudioDragDropService,
    public sagStudioService: SagStudioService,
    public _dbcomparetoolService: DbcomparetoolService
    ) { }

  ngOnInit() {
    this.sagStudioService.stopHorizontalTabsForPage = false;
    this.selectedProject = this.shareService.getDataprotool("selectedProjectChooseData");
    this.getFileTree();
    this.switch_expression = '';
    // IMAGE JSON DATA API
    this.getImagesFromJsonFile()
    //image count
    this.allImagesOfProject = []
    this.getImgProperty()
    
  }
  getFileTree() {
    if (this.selectedProject) {
      let obj = {
        "projectName": this.selectedProject.projectname,
        "projectId": this.selectedProject.projectId
      }
      this.shareService.getMenuForVoice(obj).subscribe((res) => {
        if (res) {
          this.projectFiles = res['menujson'];
        }
      });
    }
  }
  openOperationDetails(open){
    this.operationName = open.label;
    this.pageOperationsList.forEach(dataObj=>{
      if(open.name == dataObj.name){
        dataObj.setActive = true;
      }else{
        dataObj.setActive = false;
      }
    })
    this.switch_expression = open.name;
    this.sagStudioService.mappingControlTabType = open.name;
  }
  async onComponentSelect(event:any,){
    this.showValidationIcons = false;
    this.operationName = '';
    this.pageOperationsList.forEach(dataObj=>{
      dataObj.setActive = false;
      dataObj.error = false;
      dataObj.toolTipMsg='All Correct'
    })
    this.sagStudioService.mappingControlTabType = ''
    this.class1 = false;
    this.switch_expression = false;
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    const currentPagePath = `${selectedProjectChooseData.projectname}/${event.node.routehtml}`;
    const parentNodePath = currentPagePath.substring(0, currentPagePath.lastIndexOf("/"));
    const selectedPageFileNode = await this.studioDragDropService.getExplorerNodeByProjectPath(currentPagePath, 'from');
    const parentNode = await this.studioDragDropService.getExplorerNodeByProjectPath(parentNodePath, 'from');
    if(event.node.routehtml != null){
      this.class1 = true;
      if (selectedPageFileNode) {
        await this.studioDragDropService.fileShow(selectedPageFileNode, '', parentNode);
      }
    }else{
      alert("Path does not exist !!!")
    }
    // 
  //  await this.checkForInvalidData()
  // await this.checkForLanguageEnable(selectedProjectChooseData)
  }
 
  async checkForInvalidData(){
    let controls = await this.sagStudioService.allFromControlsForProps;
    if(controls && controls.length > 0){
      for (let index = 0; index < controls.length; index++) {
        const element = controls[index];
        if(element && element.database && element.database.dbMappingState && element.database.dbMappingState == "invalid"){
          this.pageOperationsList.forEach(op=>{
            if(op.name == 'dBMapping'){
              op.error = true;
              op.toolTipMsg = 'Error In '+ element.subtype
            }
          })
        }
      }
    }
  }
  async checkForLanguageEnable(node){
    let obj ={
      projectPath:node.awspace,
      pageId:`${this.sagStudioService.completeJsonWithContainer.fileId}`
    }
    let langResp = await this.shareService.checkLangEnable(obj).toPromise();
    if(langResp){
      this.languageStatus =  langResp;
      // check for language Error
      this.languageStatus = this.languageStatus.filter(x=>x.lang != 'en')
      this.checkErrorWithLanguage(this.languageStatus)
    }
  }
  checkErrorWithLanguage(langStatus){
    let checkForLangStatus = '';
    if(langStatus && langStatus.length > 0){
      for (let index = 0; index < langStatus.length; index++) {
        const element = langStatus[index];
        if(element.status == false || element.latest == false){
          checkForLangStatus = 'error Occure';
        }
      }
    }
    if(checkForLangStatus == 'error Occure'){
      this.pageOperationsList.forEach(dataObj=>{
        if(dataObj.name == 'language'){
          dataObj.error = true;
          dataObj.toolTipMsg = 'Error In '+ dataObj.name;
        }
      })
    }
  }
  checkIssues(){
    // used for default language open
    let language = this.pageOperationsList.filter(x => x.name == "language")
    this.openOperationDetails(language[0]);
    this.showValidationIcons = true;
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    this.checkForInvalidData()
    this.checkForLanguageEnable(selectedProjectChooseData)
  }

  // IMAGE JSON DATA
  async getImagesFromJsonFile() {
    try {
      const projectPath = this.shareService.getDataprotool("selectedProjectChooseData");
      let dataJson = {
        projectPath: `${projectPath.awspace}/src/assets/img.json`
      };
      const res = await this.shareService.getPrjConfObject(dataJson).toPromise();
      if (res['status'] === 'success') {
        this.shareService.imgJsonData.next(res['confobj'])

      } else {
        console.error('Failed to load image data');
      }
    } catch (error) {
      console.error('Error in getImagesFromJsonFile:', error);
    }
  }
  async getImgProperty() {
    const projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    const allAvailageImagesRes = await this.shareService.getImageData({ projectId: projectInfo["projectId"] }).toPromise();
    let dataImg = allAvailageImagesRes["data"];
    await this.returnRes(dataImg)
  }
  async returnRes(dataImg) {
    this.allImagesOfProject = dataImg.map(ele => {
      if (ele.fullPath.includes('src')) {
        const fullPath = ele.fullPath;
        ele.fullPath = fullPath.split('\\src\\')[1].replace(/\\/g, '/'); // Replace backslashes with forward slashes
      }
      return {
        size: ele.size,
        path: ele.fullPath,
        useCount: ele.usecount
      };
    });
    this.shareService.imageList.next(this.allImagesOfProject)
  }
}
