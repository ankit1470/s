import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {TreeModule} from 'primeng/tree';
import { ProjectOperationsRoutingModule } from './project-operations-routing.module';
import { ProjectOperationsComponent } from './project-operations.component';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ProjectOperationsRoutingModule,
    TreeModule,
  ],
  exports:[]
})
export class ProjectOperationsModule { }
