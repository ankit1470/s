import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ImgMappingRoutingModule } from './img-mapping-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ImgMappingRoutingModule
  ]
})
export class ImgMappingModule { }
