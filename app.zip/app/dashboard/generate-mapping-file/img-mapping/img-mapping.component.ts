import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { SagShareService } from 'src/app/services/sagshare.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
declare var SdmtGridT: any;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
@Component({
  selector: 'app-img-mapping',
  templateUrl: './img-mapping.component.html',
  styleUrls: ['./img-mapping.component.scss']
})
export class ImgMappingComponent implements OnInit {
  @Input() pagesList;
  selectedProject: any;
  componentOptions:any=[]
  imgMapcomponentFiles: any = [];
  genMapcomponentFiles: any = [];
  allImagesOfProject: any;
  constructor(public shareService: SagShareService,
    public studioDragDropService: CommonStudioDragDropService,
    public sagStudioService: SagStudioService,
  ) { }
  @ViewChild('genMapreff', {static: false}) genMapreff!: ElementRef;
  ngOnInit() {
    this.selectedProject = this.shareService.getDataprotool("selectedProjectChooseData");
    this.getImagesFromJsonFile()
    this.allImagesOfProject = []
    this.getImgProperty()
  }

  getFileTree() {
    if (this.selectedProject) {
      let obj = {
        "projectName": this.selectedProject.projectname,
        "projectId": this.selectedProject.projectId
      }
      this.shareService.getMenuForVoice(obj).subscribe((res) => {
        if (res) {
          this.componentOptions = res['menujson'];
          console.log(this.genMapreff,"Generate Mapping Refference")
        }
      });
    }
  }

  gridData_generatemappingfile: any;
  gridDynamicObj_generatemappingfile: any;
  columnData_generatemappingfile: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "",
      "field": "checkbox",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "headerCheckBox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Type",
      "field": "type",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File Name",
      "field": "fName",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Source Code",
      "field": "src",
      "filter": true,
      "width": "120px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Meta",
      "field": "meta",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File Path",
      "field": "filePath",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_generatemappingfile: any = [
    {},
    {},
    {},
    {}
  ];
  validationgeneratemappingfile: any = {}

  generatemappingfile(rowData?: any, colData?: any) {
    let self = this;
    this.gridData_generatemappingfile = {
      columnDef: colData ? colData : this.columnData_generatemappingfile,
      rowDef: rowData ? rowData : this.rowData_generatemappingfile,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationgeneratemappingfile,
      newPagination: false,
      recordPerPage: 10,
      exportBtn: false,
      newExpandExportTotalRecord_hide: undefined,

      commonSearchSelect_hide: false,
      commonFilterSelect_hide: false,
      orderArray: ["checkbox", "sno", "type", "fName", "src", "meta", "filePath"],
      ellipsisV: {},
      gridRowAddDeleteButton: "undefined",
      components: {},
      callBack: {
      }
      ,

      rowCustomHeight: 20,
      plusButton_obj: {},




    };
    let sourceDiv: any;
    sourceDiv = document.getElementById("genmapp") ;
    this.gridDynamicObj_generatemappingfile = SdmtGridT(sourceDiv, this.gridData_generatemappingfile, true, true);
  }


  async onComponentSelect(event,eve:any) {
    if(event.routehtml != null){
      const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
      const currentPagePath = `${selectedProjectChooseData.projectname}/${event.routehtml}`;
      const parentNodePath = currentPagePath.substring(0, currentPagePath.lastIndexOf("/"));
      const selectedPageFileNode = await this.studioDragDropService.getExplorerNodeByProjectPath(currentPagePath, 'from');
      const parentNode = await this.studioDragDropService.getExplorerNodeByProjectPath(parentNodePath, 'from');
      if (selectedPageFileNode) {
        await this.studioDragDropService.fileShow(selectedPageFileNode, '', parentNode);
        this.sagStudioService.mappingControlTabType = 'imagesDetails';
      }
    }
  }

  onuncheckedSelectComp(event: any,allFiles:any,tabName:any) {
    switch (tabName) {
        case 'genMapping' :
          this.genMapcomponentFiles.filter((res: any, ind: any) => {
            var data: any
            switch (res['type']) {
              case 'COMPONENT':
              case 'SCSS':
              case 'MODULE':   
              case 'HTML': 
                data = res['fName'].split('.')[0]
              break;
              case 'ROUTING':
                data = res['fName'].split('-')[0]
              break;
            }
            let eve: any = event.routehtml.split('/').filter(res => res == data)
      
            if (data == eve[0])
              this.genMapcomponentFiles.splice(ind, 1)
          })
          break;

      default:
        break;
    }

    this.generatemappingfile();
  }

  async getImagesFromJsonFile() {
    try {
      const projectPath = this.shareService.getDataprotool("selectedProjectChooseData");
      let dataJson = {
        projectPath: `${projectPath.awspace}/src/assets/img.json`
      };
      const res = await this.shareService.getPrjConfObject(dataJson).toPromise();
      if (res['status'] === 'success') {
        this.shareService.imgJsonData.next(res['confobj'])

      } else {
        console.error('Failed to load image data');
      }
    } catch (error) {
      console.error('Error in getImagesFromJsonFile:', error);
    }
  }

  async getImgProperty() {
    const projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    const allAvailageImagesRes = await this.shareService.getImageData({ projectId: projectInfo["projectId"] }).toPromise();
    let dataImg = allAvailageImagesRes["data"];
    await this.returnRes(dataImg)
  }
  async returnRes(dataImg) {
    this.allImagesOfProject = dataImg.map(ele => {
      if (ele.fullPath.includes('src')) {
        const fullPath = ele.fullPath;
        ele.fullPath = fullPath.split('\\src\\')[1].replace(/\\/g, '/'); // Replace backslashes with forward slashes
      }
      return {
        size: ele.size,
        path: ele.fullPath,
        useCount: ele.usecount
      };
    });
    this.shareService.imageList.next(this.allImagesOfProject)
  }

}
