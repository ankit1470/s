import { Component, Input, OnInit } from '@angular/core';
import { DynamicDialogRef } from 'primeng/primeng';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var SdmtGridT: any;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
@Component({
  selector: 'app-lang-content-mapping',
  templateUrl: './lang-content-mapping.component.html',
  styleUrls: ['./lang-content-mapping.component.scss']
})
export class LangContentMappingComponent implements OnInit {
  @Input() langComponentsOptions;
  selectedProject: any;
  // langComponentsOptions = [];
  listOfFiles: any = [];
  componentFiles: any = [];
  genMapcomponentFiles: any = [];
  deleteSourceFiles: any = [];
  excelFile: any;
  activeTab: any;
  nma:any
  constructor(public shareService: SagShareService,public modalRef: DynamicDialogRef,) { }

  ngOnInit() {
    this.activeTab = 'generateMapping';
    this.selectedProject = this.shareService.getDataprotool("selectedProjectChooseData");
  }


  gridData_generatemappingfile: any;
  gridDynamicObj_generatemappingfile: any;
  columnData_generatemappingfile: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "",
      "field": "checkbox",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "headerCheckBox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Type",
      "field": "type",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File Name",
      "field": "fName",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Source Code",
      "field": "src",
      "filter": true,
      "width": "120px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Meta",
      "field": "meta",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File Path",
      "field": "filePath",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_generatemappingfile: any = [
    {},
    {},
    {},
    {}
  ];
  validationgeneratemappingfile: any = {}

  generatemappingfile(rowData?: any, colData?: any) {
    let self = this;
    this.gridData_generatemappingfile = {
      columnDef: colData ? colData : this.columnData_generatemappingfile,
      rowDef: rowData ? rowData : this.rowData_generatemappingfile,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationgeneratemappingfile,
      newPagination: false,
      recordPerPage: 10,
      exportBtn: false,
      newExpandExportTotalRecord_hide: undefined,

      commonSearchSelect_hide: false,
      commonFilterSelect_hide: false,
      orderArray: ["checkbox", "sno", "type", "fName", "src", "meta", "filePath"],
      ellipsisV: {},
      gridRowAddDeleteButton: "undefined",
      components: {},
      callBack: {
      }
      ,

      rowCustomHeight: 20,
      plusButton_obj: {},




    };
    let sourceDiv: any;
    (this.activeTab == 'generateMapping') ? sourceDiv = document.getElementById("generatemappingfile") : (this.activeTab == 'importExcelGrid') ? sourceDiv = document.getElementById("importExcelGrid") : false;
    this.gridDynamicObj_generatemappingfile = SdmtGridT(sourceDiv, this.gridData_generatemappingfile, true, true);
  }

  importExcel() {
    let data = this.gridDynamicObj_generatemappingfile.getCheckedDataParticularColumnWise()
    let moduleList = data.map((item: any) => {
      let newitem:any;
      newitem = item.fName.split('.')[0]
      return newitem
    })
    let formData = new FormData()
    formData.append("projectPath", this.selectedProject.awspace);
    formData.append("projectId", this.selectedProject.projectId);
    formData.append("modules", moduleList.join(','));
    formData.append("file", this.excelFile);
    this.shareService.excelImportCopyConten(formData).subscribe((res: any) => {
      if (res['status'] == 'success') {
        success(res['msg']);
        $("#importExcel").modal('hide');
      } else {
        alerts(res['msg'])
      }
    })
  }


  generateMappingFile() {
    let data = this.gridDynamicObj_generatemappingfile.getCheckedDataParticularColumnWise()
    let moduleList = data.map((item: any) => {
      let newitem: any = {}
      newitem["name"] = item.fName.split('.')[0],
        newitem['path'] = item.projectPath
      newitem['moduleId'] = item.ngmoduleId
      return newitem
    })
    let obj = {
      'projectPath': this.selectedProject.awspace,
      "moduleList": moduleList
    }
    this.shareService.generateMappingLangJson(obj).subscribe((res: any) => {
      if (res['status'] == 'success') {
        success(res['msg'])
      } else {
        alerts(res['msg'])
      }
    })
  }
  closeModal(flag) {
    this.modalRef.close(flag);
  }

  onComponentSelect(event,eve:any) {
    let dataRes: any;
    let obj = {
      "projectId": this.selectedProject.projectId,
      "menudetId": event.menuid,
      "projectName": this.selectedProject.projectname,
      "projectPath": this.selectedProject.awspace,
    }

    this.shareService.getMenuRelatedFile(obj).subscribe(res => {
      dataRes = res;
      if (dataRes && dataRes.length > 0) {
        for (let index = 0; index < dataRes.length; index++) {
          const element = dataRes[index];
          let obj = element;
          obj["projectName"] = this.selectedProject.projectname;
          obj["path"] = this.selectedProject.awspace + '/' + element.filePath;
          obj["projectPath"] = this.selectedProject.projectname + '/' + element.filePath;
          if (this.activeTab == 'generateMapping') {
            if(obj.type == 'MODULE')
            this.genMapcomponentFiles.push(obj)
          } else {
            if(obj.filePath == event.routehtml)
              this.componentFiles.push(obj)
          }
        }
      }
      (this.activeTab == 'generateMapping') ? this.rowData_generatemappingfile = this.genMapcomponentFiles : this.rowData_generatemappingfile = this.componentFiles;
      this.generatemappingfile();
    })
  }

  onuncheckedSelectComp(event: any,allFiles:any,tabName:any) {
    switch (tabName) {
      case 'impExcel':
        this.componentFiles.filter((res: any, ind: any) => {
          var data: any
          switch (res['type']) {
            case 'COMPONENT':
            case 'SCSS':
            case 'MODULE':   
            case 'HTML': 
              data = res['fName'].split('.')[0]
            break;
            case 'ROUTING':
              data = res['fName'].split('-')[0]
              break;
          }
          let eve: any = event.routehtml.split('/').filter(res => res == data)
          if (data == eve[0]) 
            this.componentFiles.splice(ind, 1)
        })
        break;
        case 'genMapping' :
          this.genMapcomponentFiles.filter((res: any, ind: any) => {
            var data: any
            switch (res['type']) {
              case 'COMPONENT':
              case 'SCSS':
              case 'MODULE':   
              case 'HTML': 
                data = res['fName'].split('.')[0]
              break;
              case 'ROUTING':
                data = res['fName'].split('-')[0]
              break;
            }
            let eve: any = event.routehtml.split('/').filter(res => res == data)
            if (data == eve[0])
              this.genMapcomponentFiles.splice(ind, 1)
          })
          break;

      default:
        break;
    }

    this.generatemappingfile();
  }

  exportExcel() {
    let obj:any={
      "projectPath" : this.selectedProject.awspace,
    "projectId"   : this.selectedProject.projectId
    }
    this.shareService.excelExportCopyContent(obj).subscribe((res:any)=>{
      if(res['status'] == 'success')
        success(res['msg']);
      else
        alerts(res['msg'])
    })
  }

  onFileSelect(event: any) {
    if (event.target.files.length > 0) {
      this.excelFile = event.target.files[0];
      // this.selectedFiles = event.target.files;
    }
  }

}
