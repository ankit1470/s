import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LangContentMappingRoutingModule } from './lang-content-mapping-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    LangContentMappingRoutingModule
  ]
})
export class LangContentMappingModule { }
