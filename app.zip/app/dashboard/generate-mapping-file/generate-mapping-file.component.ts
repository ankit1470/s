import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DynamicDialogRef } from 'primeng/primeng';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var SdmtGridT: any;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
@Component({
  selector: 'app-generate-mapping-file',
  templateUrl: './generate-mapping-file.component.html',
  styleUrls: ['./generate-mapping-file.component.scss']
})
export class GenerateMappingFileComponent implements OnInit {
  activeImgLangTab: any;
  selectedProject: any;
  componentsOptions = [];
  listOfFiles: any = [];
  componentFiles: any = [];
  genMapcomponentFiles: any = [];
  deleteSourceFiles: any = [];
  excelFile: any;
  activeTab: any;
  nma:any
  @ViewChild('genMapReff', {static: false}) genMapReff!: ElementRef;
  constructor(public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
  ) {
   }

  ngOnInit() {
    this.activeImgLangTab = 'langContent';
    this.activeTab = 'generateMapping';
    this.selectedProject = this.shareService.getDataprotool("selectedProjectChooseData");
    this.getFileTree();
  }

  getFileTree() {
    if (this.selectedProject) {
      let obj = {
        "projectName": this.selectedProject.projectname,
        "projectId": this.selectedProject.projectId
      }
      this.shareService.getMenuForVoice(obj).subscribe((res) => {
        if (res) {
          this.componentsOptions = res['menujson'];
          console.log(this.genMapReff,"Generate Mapping Refference")
        }
      });
    }
  }





}
