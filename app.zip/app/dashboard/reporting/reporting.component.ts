import { Component, OnInit } from '@angular/core';
import { SagShareService } from 'src/app/services/sagshare.service';

@Component({
  selector: 'app-reporting',
  templateUrl: './reporting.component.html',
  styleUrls: ['./reporting.component.scss']
})
export class ReportingComponent implements OnInit {
  toggleCheck: any
  constructor(   public shareService: SagShareService,) { }

  ngOnInit() {

  }


  fileOutput(event) {
    if (event.target.checked) {
      let selectedProject = JSON.parse(localStorage.getItem('selectedProjectChooseData'))
      let json= {
        path : selectedProject.jwspace,
        projectName: selectedProject.projectname
      }
      this.shareService.reportingFileOutput(json).subscribe((res: any) => {
        console.log(res)
      })
    }
  }
}
