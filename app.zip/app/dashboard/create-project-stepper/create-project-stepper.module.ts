import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateProjectStepperRoutingModule } from './create-project-stepper-routing.module';
import { CreateProjectStepperComponent } from './create-project-stepper.component';
import { ColorPickerModule } from 'ngx-color-picker';
import { SharedModule } from 'src/app/core/shared/shared.module';


@NgModule({
  declarations: [CreateProjectStepperComponent],
  imports: [
    CommonModule,
    CreateProjectStepperRoutingModule,
    SharedModule,
    ColorPickerModule
  ]
})
export class CreateProjectStepperModule { }
