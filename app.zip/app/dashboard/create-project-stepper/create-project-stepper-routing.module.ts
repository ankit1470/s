import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateProjectStepperComponent } from './create-project-stepper.component';


const routes: Routes = [
  {
    path : "",
    component : CreateProjectStepperComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreateProjectStepperRoutingModule { }
