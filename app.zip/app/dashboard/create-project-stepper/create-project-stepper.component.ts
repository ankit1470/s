import { Component, OnInit, } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolFirststepService } from 'src/app/services/database/dbcomparetool-firststep.service';
import { ProcomparetoolFirststepService } from 'src/app/services/project-utility-tool/procomparetool-firststep.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { VersionControlMappingComponent } from '../version-control-mapping/version-control-mapping.component';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  selector: 'app-create-project-stepper',
  templateUrl: './create-project-stepper.component.html',
  styleUrls: ['./create-project-stepper.component.scss'],
  providers: [DialogService]
})
export class CreateProjectStepperComponent implements OnInit {
  // database configuration variables
  databaseConnForm: any;
  creationTable: any;
  creationTableForm: any;
  readonlyInput: boolean=false;
  


  getUserWiseLocalProjectPathResponce:any;
  createProjLoad:any={}
  createProjectInfo: any;
  saveUserWiseLocalProjectPathresponce:any;
  SecurityType = [{ key: "jwt", value: "JWT" }, { key: "simple", value: "SIMPLE" }]
  projectCreationForm: any;
  backEndConfigForm: any;
  comparingProjInfo:any;
  selectedTab: string;
  theme: any = {
    "section_name": "Other Button",
    "section_fields": [
      { "label": "Default BG", "id": "custom28", "inputType": "color", "--value": "rgb(238, 238, 238)", "name": "defaultBgClr" },
      { "label": "Default Text", "id": "custom29", "inputType": "color", "--value": "rgb(238, 238, 111)", "name": "defaultTxtClr" },
      { "label": "Primary BG", "id": "custom30", "inputType": "color", "--value": "rgb(238, 121, 111)", "name": "primaryBgClr" },
      { "label": "Primary Text", "id": "custom31", "inputType": "color", "--value": "rgb(111, 242, 111)", "name": "primaryTxtClr" },
      { "label": "Success Bg", "id": "custom32", "inputType": "color", "--value": "rgb(123, 232, 145)", "name": "successBgClr" },
      { "label": "Success Text", "id": "custom33", "inputType": "color", "--value": "rgb(300, 122, 222)", "name": "successTxtClr" },
      { "label": "Danger BG", "id": "custom34", "inputType": "color", "--value": "rgb(222, 054, 111)", "name": "dangerBgClr" },
      { "label": "Danger Text", "id": "custom35", "inputType": "color", "--value": "rgb(33, 238, 111)", "name": "dangerTxtClr" },
      { "label": "Info BG", "id": "custom36", "inputType": "color", "--value": "rgb(238, 44, 111)", "name": "infoBgClr" },
      { "label": "Info Text", "id": "custom37", "inputType": "color", "--value": "rgb(238, 55, 22)", "name": "infoTxtClr" },
      { "label": "Warning BG", "id": "custom38", "inputType": "color", "--value": "rgb(66, 238, 111)", "name": "warningBgClr" },
      { "label": "Warning Text", "id": "custom39", "inputType": "color", "--value": "rgb(238, 77, 77)", "name": "warningTxtClr" },
      { "label": "Secondary BG", "id": "custom40", "inputType": "color", "--value": "rgb(238, 66, 111)", "name": "secondaryBgClr" },
      { "label": "Secondary Text", "id": "custom41", "inputType": "color", "--value": "rgb(238, 238, 77)", "name": "secondaryTxtClr" },
    ]

  }

  stepperItems :any[] = [
    {
      label : "Name Of Project",
      value : "projNameDetails",
      id    : "projNameDetails",
    },
    {
      label : "Repository Details",
      value : "repoDetails",
      id    : "repoDetails"
    },
    {
      label : " Work Space Path",
      value : "lclWrkSpace",
      id    : "lclWrkSpace"
    },
    {
      label : "Technology Stack",
      value : "techStack",
      id    : "techStack"
    },
    {
      label : "Database Configuration",
      value : "dbConfig",
      id    : "dbConfig"
    },
    // {
    //   label : "Logo & Styling",
    //   value : "logoNStyling",
    //   id    : "logoNStyling"
    // },
    {
      label : "Team & Roles",
      value : "teamNRoles",
      id    : "teamNRoles"
    },
  ];
  activeStepId: string = "projNameDetails";
  projectPathResponce=815;  
  projectId:any
  gitRepoPath:any;
  svnRepoPath:any;
  sessionStoragedata:any;
  getDefaultProj: any;
  pltform:any=[]
  constructor(
    public _router: Router,
    private formbuilder: FormBuilder,
    public dialogService: DialogService,
    public firststepDbcompareService: DbcomparetoolFirststepService,
    private shareService: SagShareService,
    public _sagStudioService: SagStudioService,
    private dbcomparetoolService: ProcomparetoolService,
    public toast: ToastService,
    public StudioDragDropService: CommonStudioDragDropService,
    public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public firststepProjectService: ProcomparetoolFirststepService,
    public autoJavacodeService:AutoJavacodeService) {

  }

  ngOnInit() { 
    this.pltform=['W','D','A']
    window['angularComponentRef'] = window['angularComponentRef'] || {};

    window['angularComponentRef'].newFunc = this.newFunc.bind(this);

    // this.activeStepId = 'projNameDetails' 
     this.sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'))
     this.initDbConnectionForms(); 
    this.initalizeEditForm();
    this.projectCreationForm.patchValue({
      frntEndUsrname: this.sessionStoragedata.username,
      frntEndPasswd: this.sessionStoragedata.password,
      backEndUsrname: this.sessionStoragedata.username,
      backEndPasswd: this.sessionStoragedata.password,
    })
    this.projectCreationForm.controls["SecretKey"].disable();

    if(this.creationTable != 'creationTable'){
      let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
      if(dataForConnection && dataForConnection.srcDataSource){
        this.databaseConnForm.setValue(dataForConnection.srcDataSource);
      }
    }
    this.getuserWrkSpacePath();
    document.querySelector('.ui-dialog-mask-scrollblocker').classList.add('sdmtDarkModeModal')
  }


    //  F O R M   I N I T I A L I Z E D    H E R E
    initDbConnectionForms() {
      this.databaseConnForm = this.formbuilder.group({
        vendor: ['MySQL'],
        databaseName: [''],
        hostName: ['localhost'],
        portNumber: ['3306'],
        userName: ['root'],
        password: ['root'],
      });
    }

    testConnection() {
      const finalDataForConnection = {
        "srcDataSource": this.databaseConnForm.value,
        "operation": "TEST",
        "connectionRoleType": 'admin'
      }
      this.firststepDbcompareService.testConnectionByPost(finalDataForConnection).subscribe((res) => {
        if (res['src'] == true) {
          const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
        //  let projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
        let awpace= `${newProj[0].awspace}/${newProj[0].projectname}`
         if(newProj[0]){
          let setConn={
            "projectPath": newProj[0] ? awpace+`/prjconn.json` :"" ,
            "confobj":JSON.parse(JSON.stringify(finalDataForConnection)),
          }
          this.setDbConnnectionObj(setConn);
         }
        
       
          finalDataForConnection['operation'] = 'COMPARESINGLE';
          finalDataForConnection['targetDataSource']  = {};
          finalDataForConnection['details'] = {
            software: [],
            year: [],
            client: [],
            columns: [],
            operation: ['']
          }
          this.shareService.setDatadbtool('finalDataForConnection', finalDataForConnection);
          // this.modalRef.close(true);
        } 
        else {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: 'Test Connection : Fail !!!...',
          });
        }
      })
    }

    
  setDatabaseConfiguration(){
    let setProjectInfo= this.shareService.getDataprotool("selectedProjectChooseData");
    // if(setProjectInfo!=undefined ){
      const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
      let javaworkspace=`${newProj[0].jwspace}/${newProj[0].projectname}`;
      
      if(javaworkspace!=undefined && javaworkspace!=null && javaworkspace!=""){

        let reqObj =this.databaseConnForm.value
        reqObj["projectPath"]=javaworkspace;
    
        this.autoJavacodeService.setDatabaseConfiguration(reqObj).subscribe(res => {
          if(res.status==200){ 
            this.toast.launch_toast({
              type: 'success',
              position: 'bottom-right',
              message: res.msg,
            });
            // this.testConnection()
          }else{
            this.toast.launch_toast({
              type: 'alert',
              position: 'bottom-right',
              message: res.msg,
            });
          }
        
        }, Error => {
        
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: 'Set Database Configuration : Fail !!!...',
          });
        });
      }
    // }
    // else {
    //   this.toast.launch_toast({
    //     type: 'alert',
    //     position: 'bottom-right',
    //     message: 'java workspace not set',
    //   });
    // }

  
  }

  // dBCreationConnection(){
  //  // this.databaseConnForm.disable();
  //  const finalDataDBCreation = {
  //   "srcDataSource": this.databaseConnForm.value,
  //   "connectionRoleType": "admin",
  //   "operation": "COMPARESINGLE"
  //  }
  //  this.shareService.setDBCreation('dbCreationTable', finalDataDBCreation);
  //  this.modalRef.close(true);
  // }
  

  async setDbConnnectionObj(data){
   await this.shareService.savePrjConfObject(data).subscribe((res)=>{
      if(res['status']=='success'){
        this.setDatabaseConfiguration()
        this.toast.launch_toast({
          type: 'success',
          position: 'bottom-right',
          message: 'Test Connection : Success !!!...',
        });
      }
    });
  }


  initalizeEditForm() {
    this.projectCreationForm = this.formbuilder.group({
      projectName: ["", Validators.required],
      web: [true],
      desktop: [true],
      appMobile: [true],
      projectStartDate: [new Date()],
      tentativeEndDate: [new Date()],
      // setAngPath: ["", Validators.required],
      // setJavaPath: ["", Validators.required],
      SecretKey: ["", Validators.required],
      angularVersion: ["8", Validators.required],
      javaVersion: ["8", Validators.required],
      SecurityType: ["SIMPLE", Validators.required],
      chackBoxValue: [true],
      projectDesc  : [""],
      gitRepoPath  : [""],
      svnRepoPath  : [""],
      // projectType  : [""],
      // deployCat  : [""],
      awspace: [""],
      frntEndUsrname: [""],
      frntEndPasswd: [""],
      jwspace: [""],
      backEndUsrname: [""],
      backEndPasswd: [""],
    });

    this.backEndConfigForm = this.formbuilder.group({
      projectname: [''],
      technology: ['java'],
      version: ['java8'],

    });
  }
  // isEnabled:boolean
  getuserWrkSpacePath(){
    this.shareService.getUserWrkSpacePath(this.sessionStoragedata.username).subscribe((res:any)=>{
      if(res['status']=='200'){
        let awId= document.getElementById('aw')
        let jwId= document.getElementById('jw')
        if(res['angWorkspace'] != '' &&  res['javaWorkspace'] !=''){
          // this.isEnabled=true
        awId.setAttribute('disabled','true')
        jwId.setAttribute('disabled','true')
        }
        else{
          awId.removeAttribute('disabled')
          jwId.removeAttribute('disabled')
          // this.isEnabled = false
        }
        this.projectCreationForm.patchValue({
          awspace:res['angWorkspace'],
          jwspace:res['javaWorkspace']
        })
        console.log(res,"This is the res")
      }
    })
  }
  // ProjectFilesSave() {
  //   this.StudioDragDropService.projectSaveJsonData(this.projectCreationForm.value);
  //   this.StudioDragDropService.saveProjectSubDataArray(this.projectCreationForm.value);
  // }

  createProject(prjLoadOrnOt:any,platForm:any) {
    this.createProjLoad['prjLoad'] = prjLoadOrnOt
    this.createProjLoad['platForm'] = platForm
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'))
    const chackBoxValue = this.projectCreationForm.value.chackBoxValue
    if (chackBoxValue == true) {
      if (this.projectCreationForm.valid) {
        this.shareService.loading++;
        if(this.projectCreationForm.value.awspace == this.projectCreationForm.value.jwspace && (this.projectCreationForm.value.awspace !='' ||  this.projectCreationForm.value.jwspace !='') && (this.projectCreationForm.value.awspace !=null ||  this.projectCreationForm.value.jwspace != null) ){
          alerts("Frontend and Backend path should not be same")
          this.shareService.loading--;
          let ele = document.getElementById('btn-lclWrkSpace')
          ele.classList.add('active')
          this.activeStepId = 'lclWrkSpace'
          return
        }
        else if(this.projectCreationForm.value.awspace == '' && this.projectCreationForm.value.jwspace == ''){
          alerts("Please specify atleast one path!!")
          this.shareService.loading--;
          let ele = document.getElementById('btn-lclWrkSpace')
          ele.classList.add('active')
          this.activeStepId = 'lclWrkSpace'
          return
        }
        else{
          this.shareService.loading--;
          this.createProjectDb(this.gitRepoPath, this.svnRepoPath);
          this.createProjectPmt();
        }

      } else if (this.projectCreationForm.invalid) {
        alerts("Please Enter Project Name");
        let ele = document.getElementById('btn-projNameDetails')
        ele.classList.add('active')
        this.activeStepId = 'projNameDetails'        
      }
    }
    else {
      this.createProjectWithOutRepo();
    }


  }
  // =========================Project Create ==============================================
  repoPrjExst:boolean;
  createProjectDb(gitRepoPath, svnRepoPath) {
    const postData = {
      projectName: this.projectCreationForm.value.projectName,
      gitrepopath: gitRepoPath,
      svnrepopath: svnRepoPath,
      securityType: this.projectCreationForm.value.SecurityType,
      secretKey: this.projectCreationForm.value.SecretKey,
      platform:this.pltform
    };
    this.shareService.loading++;    
      this.dbcomparetoolService.createProjectDbData(postData).subscribe(
        (response: any) => {
          this.shareService.loading--;
          if (response['status'] == 200) {
            this.projectId =response['pId']
            // success(response.msg);
            this.saveUserWiseLocalProjectPath(gitRepoPath,svnRepoPath,true)
          }
          if (response['status'] == 500) {
            alerts(response.msg);
          }
        },
        err => {
          this.shareService.loading--;
          alerts("Error While Fetching")
        }
      )
    
  }
  createProjectPmt() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const postData = {
      projectName: this.projectCreationForm.value.projectName,
      userId: sessionStoragedatauserId.data.clientInfo.usrId
    };
    this.shareService.loading++;
    this.dbcomparetoolService.createProjectPmtData(postData).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response['status'] == 200) {
          // success("Successfully create Project ");
        }
        if (response['status'] == 500) {
          this.shareService.loading++;
          alerts(response.msg);
        }
      },
      (err) => {
        this.shareService.loading--;
      }
    )
  }
  createProjectWithOutRepo() {
    if (this.projectCreationForm.valid) {
      const postData = {
        projectName: this.projectCreationForm.value.projectName,
        gitrepopath: "",
        svnrepopath: "",
        securityType: this.projectCreationForm.value.SecurityType,
        secretKey: this.projectCreationForm.value.SecretKey,
        platform:this.pltform
      };
      this.shareService.loading++;
      if(this.projectCreationForm.value.awspace == this.projectCreationForm.value.jwspace && (this.projectCreationForm.value.awspace !='' ||  this.projectCreationForm.value.jwspace !='') && (this.projectCreationForm.value.awspace !=null ||  this.projectCreationForm.value.jwspace != null) ){
        alerts("Frontend and Backend path should not be same")
        this.shareService.loading--;
        let ele = document.getElementById('btn-lclWrkSpace')
        ele.classList.add('active')
        this.activeStepId = 'lclWrkSpace'
        return
      }
      else if(this.projectCreationForm.value.awspace == '' && this.projectCreationForm.value.jwspace == ''){
        alerts("Please Specify At Least One Path..!")
        this.shareService.loading--;
        let ele = document.getElementById('btn-lclWrkSpace')
        ele.classList.add('active')
        this.activeStepId = 'lclWrkSpace'
        return
      }
      else{
        this.dbcomparetoolService.createProjectDbData(postData).subscribe(
          (response: any) => {
            this.shareService.loading--;
            if (response['status'] == 200) {
              this.projectId =response['pId']
              // let gitPath=''
              // let svnPath=''
              this.saveUserWiseLocalProjectPath("","",false)
              // this.getUserWiseProjectPath()
              
  
            }
            if (response['status'] == 500) {
              alerts(response.msg);
            }
          },
          (err) => {
            this.shareService.loading--;
          }
        )
      }
    }
    else if(this.projectCreationForm.invalid){
      alerts("Please Enter Project Name");
      let ele = document.getElementById('btn-projNameDetails')
      ele.classList.add('active')
      this.activeStepId = 'projNameDetails' 
    } 
    // else {
    //   alerts("Please fill Required field");
    // }
  }
  SecurityTypeChack(event) {
    if (event == "JWT") {
      this.projectCreationForm.controls["SecretKey"].enable();
    } else if (event == "SIMPLE") {
      this.projectCreationForm.controls["SecretKey"].disable();
    }
  }

  // code functionality @rohit 
  
 async getUserWiseLocalProjectPath() {
    debugger
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
      (response: any) => {
        if (response) {
          this.getUserWiseLocalProjectPathResponce = response['data']
          this.shareService.addPrjFromStepper.next(this.getUserWiseLocalProjectPathResponce)
          this.shareService.setDataprotool("getUserWiseLocalProjectPathResponce", response['data']);
          if(this.getUserWiseLocalProjectPathResponce){
                  this.getUserWiseLocalProjectPathResponce.filter((prjName:any)=>{
                    if(prjName.projectname == this.projectCreationForm.value.projectName){
                      this.comparingProjInfo= prjName
                      this.prjPath=`/${this.comparingProjInfo['projectname']}`;
                    }
                  })
              this.awSpace= this.comparingProjInfo['awspace'].concat(this.prjPath)
              this.jwSpace=  this.comparingProjInfo['jwspace'].concat(this.prjPath)
              const checkBoxValue = this.projectCreationForm.value.chackBoxValue
              if(checkBoxValue == true){
                if(this.comparingProjInfo['awspace']){
                  this.gitCloneClick()
                }
              if(this.comparingProjInfo['jwspace']){
                this.svnCheckOutClick()
              }
              }
              else{
                this.checkPrjExist()
              }
          }
        }
      }
    );
  }


  saveUserWiseLocalProjectPath(gitRepoPath:any,svnrepopath:any,prjOnrepo) {
    this.repoPrjExst = prjOnrepo
    // let selectedObj = this.gridDynamicForChooseProject.getSeletedRowData();
    let postdata = { data: [] };
    let projInfoObj= {
      awspace:this.projectCreationForm.value.awspace ? this.projectCreationForm.value.awspace : '',
      jwspace:this.projectCreationForm.value.jwspace ? this.projectCreationForm.value.jwspace : '',
      projectGitPath:gitRepoPath != '' ? gitRepoPath : '',
      projectId : this.projectId,
      projectSvnPath : svnrepopath !='' ? svnrepopath : '',
      projectname:this.projectCreationForm.value.projectName,
      sag_G_Index:this.projectPathResponce,
      sno:this.projectPathResponce + 1,
      usrprojId:null
    }
    postdata['data'].push(projInfoObj)
    console.log('postData choose project ',postdata)
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.saveUserWiseLocalProjectPath(userId, postdata).subscribe(
       (response: any) => {
        if (response['status'] == 200) {
          // this.toast.launch_toast({
          //   type: 'success',
          //   position: 'bottom-right',
          //   message: 'Successfully Updated !!!',
          // });
          this.getUserWiseLocalProjectPath();
          this.saveUserWiseLocalProjectPathresponce = response['data']
          
          // this.shareService.setDataprotool("getProgrammersNameListData", response["result"]);
        }
        else if (response['status'] == 406) {
          // this.toast.launch_toast({
          //   type: 'alert',
          //   position: 'bottom-right',
          //   message: response['message'],
          // });
          alerts(response['message'])
          let ele = document.getElementById('btn-lclWrkSpace')
          ele.classList.add('active')
          this.activeStepId = 'lclWrkSpace'
          
        }
      }
    );
  }


  /** TO CHANGE VALUE OF CSS VARIABLE I THEME */
  changeColor(value: any, propName: string) {
    // const [r, g, b] = value.match(/\w\w/g).map((x) => parseInt(x, 16));
    // const _val = [r, g, b].toString(); 
    const _val = value.match(/\((.+)\)/)[1].toString()
    const el: HTMLElement = document.querySelector("app-root");
    el.style.setProperty("--" + propName, _val);

    if (propName == 'topMenuTxtClr') {
      let topList = document.querySelectorAll<HTMLElement>("#top_nav_bar .navbar-nav li a#navbarDropdown");
      Array.from(topList).forEach((element) => {
        element.style.setProperty("color", "rgba(var(--topMenuTxtClr))", "important");
      });
    }
  }

  iconBehaviorHandler(elem: any, ev: any, propName: any) {
    const _value = ev.target.value;
    elem['--' + 'value'] = _value;
    const el: HTMLElement = document.querySelector("#mainComp");
    // const _val : string = _value.replace(/rgba\(|\)/g, '');
    el.style.setProperty("--" + propName, _value);
  } 

  closeModel() {
    this.modalRef.close();
    if (document.querySelector(".close-project-creation")) {
      document.querySelector(".close-project-creation").closest("p-dynamicdialog").remove();
    }

  }

  onClickStepper(stepItem:any,stepperId:any) {
    this.activeStepId = stepperId;
    var id = document.getElementById(`btn-${this.activeStepId}`)
    var projid = document.getElementById(`btn-projNameDetails`)
    var lclWrkid = document.getElementById(`btn-lclWrkSpace`)
    var techStackid = document.getElementById(`btn-techStack`)
    var repoDtlsId = document.getElementById(`btn-repoDetails`)
    var dbConfigId = document.getElementById(`btn-dbConfig`)
    if(this.projectCreationForm.value.chackBoxValue == false && this.projectCreationForm.value.projectName != ''){

    }
    if(this.projectCreationForm.value.projectName != ''){
      projid.classList.remove('bg-danger-new')
      projid.classList.add('bg-success-new')
    }else{
      projid.classList.remove('bg-success-new')
      projid.classList.add('bg-danger-new')
    }
    if(this.activeStepId == 'lclWrkSpace'){
      if(this.projectCreationForm.value.projectName ==''){
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }else{
        if(this.projectCreationForm.value.chackBoxValue == true && this.projectCreationForm.value.projectName !=''){
          repoDtlsId.classList.add('bg-success-new')
          repoDtlsId.classList.remove('bg-danger-new')
        }
        if(this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != ''){
          lclWrkid.classList.remove('bg-danger-new')
          lclWrkid.classList.add('bg-success-new')
        }else{
          lclWrkid.classList.remove('bg-success-new')
          lclWrkid.classList.add('bg-danger-new')
        }
      }

    }
    if(this.activeStepId == 'techStack'){
      if(this.projectCreationForm.value.projectName ==''){
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }
        else{
          if(this.projectCreationForm.value.chackBoxValue == true && this.projectCreationForm.value.projectName !=''){
            repoDtlsId.classList.add('bg-success-new')
            repoDtlsId.classList.remove('bg-danger-new')
          }
          if(this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != ''){
            lclWrkid.classList.remove('bg-danger-new')
            lclWrkid.classList.add('bg-success-new')
          }else{
            lclWrkid.classList.add('bg-danger-new')
            lclWrkid.classList.remove('bg-success-new')
          }
          if(this.projectCreationForm.value.SecurityType != ''){
            techStackid.classList.remove('bg-danger-new')
            techStackid.classList.add('bg-success-new')
          }else{
            techStackid.classList.remove('bg-success-new')
            techStackid.classList.add('bg-danger-new')
          }
        }

    }
    if(this.activeStepId == 'dbConfig'){
      if(this.projectCreationForm.value.chackBoxValue == true && this.projectCreationForm.value.projectName !=''){
        repoDtlsId.classList.add('bg-success-new')
        repoDtlsId.classList.remove('bg-danger-new')
      }
      if(this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != ''){
        lclWrkid.classList.remove('bg-danger-new')
        lclWrkid.classList.add('bg-success-new')
      }else{
        lclWrkid.classList.add('bg-danger-new')
        lclWrkid.classList.remove('bg-success-new')
      }
      
      if(this.projectCreationForm.value.SecurityType != ''){
        techStackid.classList.remove('bg-danger-new')
        techStackid.classList.add('bg-success-new')
      }else{
        techStackid.classList.remove('bg-success-new')
        techStackid.classList.add('bg-danger-new')
      }
      if(this.projectCreationForm.value.jwspace !=''){
        id.classList.add('bg-success-new')
      }
    }
    if(this.activeStepId == 'teamNRoles'){
      if(this.projectCreationForm.value.projectName ==''){
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }else{
        if(this.projectCreationForm.value.chackBoxValue == true && this.projectCreationForm.value.projectName !=''){
          repoDtlsId.classList.add('bg-success-new')
          repoDtlsId.classList.remove('bg-danger-new')
        }
        if(this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != ''){
          lclWrkid.classList.remove('bg-danger-new')
          lclWrkid.classList.add('bg-success-new')
        }
        else{
          lclWrkid.classList.add('bg-danger-new')
          lclWrkid.classList.remove('bg-success-new')
        }
        if(this.projectCreationForm.value.jwspace !=''){
          dbConfigId.classList.add('bg-success-new')
          dbConfigId.classList.remove('bg-danger-new')
          
        }
        if(this.projectCreationForm.value.SecurityType != ''){
          techStackid.classList.remove('bg-danger-new')
          techStackid.classList.add('bg-success-new')
        }else{
          techStackid.classList.remove('bg-success-new')
          techStackid.classList.add('bg-danger-new')
        }
        if(this.projectCreationForm.value.projectName != ''){
          id.classList.add('bg-success-new')
          id.classList.remove('bg-danger-new')
        }
        else{
          id.classList.remove('bg-success-new')
          id.classList.add('bg-danger-new')
  
        }
      }
      // id.classList.add('bg-success-new')
      
    }

    if(this.activeStepId == 'repoDetails'){
      debugger
      if(this.projectCreationForm.value.chackBoxValue == true){
        if(this.pathCreated == true){
          return;
        }
        else{
          if(this.projectCreationForm.valid){
            this.isRunning_Git_Svn_Server();
          }else{
            // id.classList.remove('bg-success-new')
            // id.classList.add('bg-danger-new')
            this.activeStepId = 'projNameDetails' 
            alerts('Please Enter Project Name')
          }
        }

      }
      
      else{
        // if(this.projectCreationForm.value.projectName ==''){
        //   this.activeStepId = 'projNameDetails' 
        //   alerts('Please fill project name')
        // }
        if(this.projectCreationForm.value.projectName !='' && this.projectCreationForm.value.chackBoxValue == false){
          let ele = document.getElementById('btn-lclWrkSpace')
          ele.classList.add('active')
          this.activeStepId = 'lclWrkSpace'
          // this.activeStepId ='repoDetails' 
          return
        }
        if(this.projectCreationForm.value.projectName =='' && this.projectCreationForm.value.chackBoxValue == false){
          this.activeStepId = 'projNameDetails' 
          alerts('Please Enter Project Name')
        }
        else{
          // let ele = document.getElementById('btn-lclWrkSpace')
          // ele.classList.add('active')
          // this.activeStepId = 'lclWrkSpace' 
          // id.classList.add('bg-success-new')
          // id.classList.remove('bg-danger-new')
          this.projectCreationForm.controls["gitRepoPath"].disable();
          this.projectCreationForm.controls["frntEndUsrname"].disable();
          this.projectCreationForm.controls["frntEndPasswd"].disable();
          this.projectCreationForm.controls["svnRepoPath"].disable();
          this.projectCreationForm.controls["backEndUsrname"].disable();
          this.projectCreationForm.controls["backEndPasswd"].disable();
        }
      }
  }

   
  }

  pathCreated:boolean
  onPrevNext(activeStepId,type){
    var id = document.getElementById(`btn-${this.activeStepId}`)
    var projid = document.getElementById(`btn-projNameDetails`)
    var lclWrkid = document.getElementById(`btn-lclWrkSpace`)
    var techStackid = document.getElementById(`btn-techStack`)
    var teamNRolesId = document.getElementById(`btn-teamNRoles`)
    var dbConfigId = document.getElementById(`btn-dbConfig`)
    if(type == 'prev'){
      if(this.activeStepId == 'teamNRoles'){
        activeStepId = 'dbConfig'
        if(this.projectCreationForm.value.jwspace !=''){
          dbConfigId.classList.remove('bg-danger-new')
          dbConfigId.classList.add('bg-success-new')
        }
        // else{
        //   dbConfigId.classList.add('bg-danger-new')
        //   dbConfigId.classList.remove('bg-success-new')
        // }
        
      }
    }
    if(this.projectCreationForm.value.chackBoxValue == false && type != 'next'){
      if(this.activeStepId =='lclWrkSpace'){
        activeStepId = 'repoDetails'
        if(this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != ''){
          lclWrkid.classList.remove('bg-danger-new')
          lclWrkid.classList.add('bg-success-new')
        }else{
          lclWrkid.classList.remove('bg-success-new')
          lclWrkid.classList.add('bg-danger-new')
        }
      }
    }
   let findInd = this.stepperItems.findIndex(elm => elm.id == activeStepId );
   this.activeStepId = ( type =="next") ? this.stepperItems[findInd+1]["id"] : this.stepperItems[findInd-1]["id"];

    if(this.projectCreationForm.value.projectName != ''){
      projid.classList.remove('bg-danger-new')
      projid.classList.add('bg-success-new')
    }else{
      projid.classList.remove('bg-success-new')
      projid.classList.add('bg-danger-new')
    }
    if(this.activeStepId == 'lclWrkSpace'){
        if(this.projectCreationForm.value.projectName !='' && this.projectCreationForm.value.chackBoxValue == true){
          id.classList.remove('bg-danger-new')
          id.classList.add('bg-success-new')
        }
      if(this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != ''){
        lclWrkid.classList.remove('bg-danger-new')
        lclWrkid.classList.add('bg-success-new')
      }else{
        lclWrkid.classList.remove('bg-success-new')
        lclWrkid.classList.add('bg-danger-new')
      }

    }
    if(this.activeStepId == 'techStack'){
      if(this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != ''){
        lclWrkid.classList.remove('bg-danger-new')
        lclWrkid.classList.add('bg-success-new')
      }
      else{
        lclWrkid.classList.add('bg-danger-new')
        lclWrkid.classList.remove('bg-success-new')
      }
      if(this.projectCreationForm.value.SecurityType != ''){
        techStackid.classList.remove('bg-danger-new')
        techStackid.classList.add('bg-success-new')
      }else{
        techStackid.classList.remove('bg-success-new')
        techStackid.classList.add('bg-danger-new')
      }

    }
    if(this.activeStepId == 'dbConfig'){
      if(this.projectCreationForm.value.SecurityType != ''){
        techStackid.classList.remove('bg-danger-new')
        techStackid.classList.add('bg-success-new')
      }
      if(this.projectCreationForm.value.jwspace !=''){
        dbConfigId.classList.add('bg-success-new')
        dbConfigId.classList.remove('bg-danger-new')
      }
      else{
        var ele = document.getElementById(`btn-teamNRoles`)
        ele.classList.add('active')
        this.activeStepId = 'teamNRoles' 
      }
    }
    if(this.activeStepId == 'teamNRoles'){
      if(this.projectCreationForm.value.projectName != ''){
        id.classList.add('bg-success-new')
        id.classList.remove('bg-danger-new')
      }
      else{
        id.classList.remove('bg-success-new')
        id.classList.add('bg-danger-new')

      }
    }
    if(this.activeStepId == 'repoDetails'){
        if(this.projectCreationForm.value.chackBoxValue == true){
          if(this.pathCreated == true){
            return;
          }
          else{
            if(this.projectCreationForm.valid){
              this.isRunning_Git_Svn_Server();
            }else{
              // id.classList.remove('bg-success-new')
              // id.classList.add('bg-danger-new')
              this.activeStepId = 'projNameDetails' 
              alerts('Please Enter Project Name')
            }
          }
  
        }
        else{
          if(this.projectCreationForm.value.projectName ==''){
            this.activeStepId = 'projNameDetails' 
            alerts('Please Enter Project Name')
          }
          else{
            // this.getuserWrkSpacePath()
            let ele = document.getElementById('btn-lclWrkSpace')
            ele.classList.add('active')
            this.activeStepId = 'lclWrkSpace' 
            // id.classList.add('bg-success-new')
            // id.classList.remove('bg-danger-new')
            this.projectCreationForm.controls["gitRepoPath"].disable();
            this.projectCreationForm.controls["frntEndUsrname"].disable();
            this.projectCreationForm.controls["frntEndPasswd"].disable();
            this.projectCreationForm.controls["svnRepoPath"].disable();
            this.projectCreationForm.controls["backEndUsrname"].disable();
            this.projectCreationForm.controls["backEndPasswd"].disable();
          }
        }
    }
    
  }

  // check angular and java both path exists or not
  angProj:boolean
  javProj:boolean 
  prjPath:any
  awSpace:any
  jwSpace:any
  checkPrjExistOrNot() {
    if(this.comparingProjInfo['awspace']){
      this.dbcomparetoolService.checkProjectPath({ 'projectPath': this.awSpace , }).subscribe((res) => {
        if (res) {
          if (res['count'] == '0') {
          console.log('write angular project')
          if(((this.awSpace != null || this.jwSpace != null) && (this.awSpace != '' || this.jwSpace != '') &&
          (this.awSpace != null || this.jwSpace != '') && (this.awSpace != '' || this.jwSpace != '') && (this.awSpace != this.jwSpace))){
            this.writeAngularProject(this.comparingProjInfo)
          }
              //     else if ((this.awSpace == this.jwSpace)
              //   && (this.awSpace != '' || this.jwSpace != '')
              //   && (this.awSpace != null || this.jwSpace != null)) {
              //     alerts("Frontend & Backend path can't be same..!!")
            
              // }
          }
           else if(res['count'] == '1') {
            if(((this.awSpace != null || this.jwSpace != null) && (this.awSpace != '' || this.jwSpace != '') &&
            (this.awSpace != null || this.jwSpace != '') && (this.awSpace != '' || this.jwSpace != '') && (this.awSpace != this.jwSpace))){
              this.writeAngularProject(this.comparingProjInfo)
            }
          }
          else if(res['count'] == 'N'){
            // this.shareService.loading ++
            alerts(res['msg'])
            return
          }
        }
      });
    }

  }
  checkSvnPrjExistOrNot() {
    if(this.comparingProjInfo['jwspace']){
      this.dbcomparetoolService.checkProjectPath({ 'projectPath': this.comparingProjInfo['jwspace'].concat(this.prjPath) }).subscribe((res) => {
        if (res) {
          // this.checksvnFolder = res['status']
          if (res['count'] == '0') {
            this.WriteJavaProjectClick(this.comparingProjInfo)
            console.log("Write Java Project")
          }else if(res['count'] == '1'){
            this.WriteJavaProjectClick(this.comparingProjInfo)
          }
          
          else if(res['count'] == 'N'){
            alerts(res['msg'])
            return
          }
        }
      });
    }

  }
   checkPrjExist(){   
      this.checkPrjExistOrNot()
      this.checkSvnPrjExistOrNot()
   }


   //save-angular-project
   async writeAngularProject(selectedObj:any) {
    let  angPrjPath=`/${selectedObj['projectname']}`
     const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
     const userId = sessionStoragedatauserId.data.clientInfo.usrId
    //  let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
     const postData = {
       destpath: selectedObj['awspace'].concat(angPrjPath),
       projectname: selectedObj.projectname,
       projectId: selectedObj.projectId,
       userId: userId,
       ngprojectversion:this.projectCreationForm.value.angularVersion
     }//get-loadproject-json
     this.shareService.loading++;
     let resp = await this.dbcomparetoolService.writeNgProject(postData).toPromise();
     if (resp['status'] == 'success') {
      success("Successfully created your project");
      if(this.createProjLoad['prjLoad'] == false){
        this.closeModel()
      }
      //  success("Successfully Write Your Project !!!");
       // this.toast.launch_toast({
       //   type: 'success',
       //   position: 'bottom-right',
       //   message: 'Successfully Cloned Your Project !!!',
       // });
       this.setPrjVersionObject(postData);
       this.setRepositoryInfoObject(postData)
      //  this.setDatabaseConfiguration()
      this.testConnection()
       if(this.createProjLoad['prjLoad'] == true && this.createProjLoad['platForm'] == 'uiBuilder' ){
          this.getLocalProject()
       }
       if(this.createProjLoad['prjLoad'] == true && this.createProjLoad['platForm'] == 'theiaEditor'){
        this.getLocalProjectForTheia()
       }
       this.shareService.loading--;
     }
     else {
       this.shareService.loading--;
       alerts("There is already a project in the specified directory !!!...");
       // this.toast.launch_toast({
       //   type: 'alert',
       //   position: 'bottom-right',
       //   message: 'There is already a project in the specified directory !!!...',
       // });
     }
    //  this.modalRef.close(true);
   }
 

     /********* Write java Project **********/
  async WriteJavaProjectClick(selectProjectPath:any) {
    let javaPrjPath = `/${selectProjectPath['projectname']}`
    this.shareService.loading++;
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    if (sessionStoragedatauserId != undefined) {
      let userId = sessionStoragedatauserId.data.clientInfo.usrId;
      const postData = {
        projectName: selectProjectPath.projectname,
        path: selectProjectPath['jwspace'].concat(javaPrjPath),
        projectId: selectProjectPath.projectId,
        userId: userId,
        //path: selectProjectPath.jwspace
      }
      this.dbcomparetoolService.javaProjectCreate(postData).subscribe(
        (response: any) => {
          this.shareService.loading--;
          //this.saveUserWiseLocalProjectPath()
          if (response) {
            let status = response["data"];
            if(this.comparingProjInfo['awspace'] == ''){
              success('Successfully created your project')
            }
            // success("Write Successfully !!!...");
            // this.toast.launch_toast({
            //   type: 'success',
            //   position: 'bottom-right',
            //   message: 'Write Successfully !!!...',
            // });
          }
        },
        err => {
          this.shareService.loading--;
        }
      );
    }


    /* }  else {
       this.shareService.loading--;
       this.toast.launch_toast({
         type: 'alert',
         position: 'bottom-right',
         message: 'There is already a project in the specified directory !!!...',
       });
     } */
    // this.modalRef.close(true);
  }

 
   setPrjVersionObject(projectInfo) {
    let angversion:any = this._sagStudioService.versionControlInfo.filter((x:any)=>{
      let ang = x['angular'].split('.')
      if(projectInfo['ngprojectversion'] == ang[0]){
        return x
      }
    })
     if (projectInfo) {
       let data = {
         "projectPath": projectInfo.destpath ? projectInfo.destpath + `/projectVersion.json` : "",
         "confobj": angversion[0], 
       }
       this.shareService.savePrjConfObject(data).subscribe((res) => {
       });
     }
   }
   setRepositoryInfoObject(projectInfo) {
    console.log("Project on repository exist or not ",this.repoPrjExst)
     if (projectInfo) {
       let repoInfoObj = {
         'projectName': projectInfo.projectname,
         'projectOnRepository': this.repoPrjExst,
       }
       let data = {
         "projectPath": projectInfo.destpath ? projectInfo.destpath + `/repositoryInfo.json` : "",
         "confobj": repoInfoObj,
       }
       this.shareService.savePrjConfObject(data).subscribe((res) => {
       });
     }
   }

  //  git clone functionality
  async gitCloneClick() {
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'))

    const reqObj = {
      "projectName": this.projectCreationForm.value.projectName,
      "userName": sessionStoragedata.username,
    }
    this.shareService.loading++;
    this.dbcomparetoolService.getProjectAlreadyAccessMemberList(reqObj).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response["status"] == 200) {
          this.CloneClick();
        }
        else if (response["status"] == 500) {
          alerts(response.message)
        }
        else if (response["status"] == 409) {
          alerts(response.message)
        }
      }, error => {
        this.shareService.loading--;
        alerts("Error While Fetching")
      }
    );

  }

  // git clone for angular (frontend)
  CloneClick() {
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const usersessionStorageData = JSON.parse(sessionStorage.getItem('loginFormValue'))
    const postdata = {
      "projectpath": this.awSpace,
      "userName": usersessionStorageData.username,
      "password": usersessionStorageData.password,
      "repositoryPath": this.gitRepoPath,
      "userId": sessionStoragedata.data.clientInfo.usrId.toString(),
      "projectId": this.projectId
    }
    if ((postdata.repositoryPath != '' && postdata.userName != '' && postdata.password != '') &&
      (postdata.repositoryPath != null && postdata.userName != null && postdata.password != null)) {
      this.shareService.loading++;
      this.dbcomparetoolService.gitprojectclone(postdata).subscribe(
        (response: any) => {
          if (response["status"] == 200) {
            this.shareService.loading--;
            // success("successFully Clone !!!...");
            this.checkPrjExistOrNot()
          }
          else if (response["status"] == 500) {
            this.shareService.loading--;
            alerts(response.msg)
          }

        },
        err => {
          this.shareService.loading--;
        }
      );
    }
    else {
      alerts("Please Enter Required  Fields !!!")
    }

  }

  //svn clone for java (backend) and java functionality
  async svnCheckOutClick() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    const usersessionStorageData = JSON.parse(sessionStorage.getItem('loginFormValue'))
    const postdata = {
      "checkoutPath": this.comparingProjInfo['jwspace'],
      "username": usersessionStorageData.username,
      "password": usersessionStorageData.password,
      "repositoryPath": this.svnRepoPath,
      "userId": userid,
      "projectPath": this.jwSpace,
      "projectId": this.projectId,
      "selectedPath": this.jwSpace,
    }
    this.shareService.loading++;
    if ((postdata.repositoryPath != '' && postdata.username != '' && postdata.password != '') &&
      (postdata.repositoryPath != null && postdata.username != null && postdata.password != null)) {
      this.dbcomparetoolService.svnProjectChackOut(postdata).subscribe(
        (response: any) => {
          this.shareService.loading--;
          if (response['status'] == 200) {
            if(this.comparingProjInfo['awspace'] == ''){
              success("successfully CheckOut !!!...")
            }
            this.checkSvnPrjExistOrNot()
          }
          else if (response['status'] == 500) {
            alerts(response['message'])
          }
        }
      );
      err => {
        this.shareService.loading--;
      }

    } else {
      alerts("Please Enter Required  Fields !!!");
    }

  }
  

  




  async getLocalProject() {
this.closeModel()
  debugger
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    await this.setPathButtonClick();
    // let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    // this.getDefaultProj = this.shareService.getDataprotool("selectedProjectChooseData")
    if (newProj[0]) {
      const postData = {
        destpath: `${newProj[0].awspace}/${newProj[0].projectname}`,
        projectname: newProj[0].projectname,
      }
      this.shareService.loading++;
      const resSagStudioJson = await this.dbcomparetoolService.loadProjectJson(postData).toPromise();
      this.shareService.setData('ctrlopType',resSagStudioJson[0]['projectList'][0]['ctrlsOptType'])
      this.shareService.loading--;
      // this._sagStudioService.projectExploralFileList = resSagStudioJson
      this._sagStudioService.sagWorkSpace = resSagStudioJson[0];
  
  

      if (this._sagStudioService.sagWorkSpace && this._sagStudioService.sagWorkSpace !== undefined) {
        let path = `${newProj[0].awspace}/${newProj[0].projectname}`
        this.getDbConnObj(newProj[0].awspace + `/prjconn.json`);
        await this.getPrjConfObj(newProj[0].awspace + `/projectVersion.json`);
        await this.projectPathReplaceProjectWise()
        this.getpStylesScss();
        this.getFontFamily(path);
        this.shareService.setDataprotool('UIBuilder', 'true');
        localStorage.setItem('UIBuilder', 'true');
      } else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Something went Wrong !!!',
        });
      }
   
      this.shareService.propertyWindowJsonData().subscribe(jsonData => {
        this._sagStudioService.propertyWindowJson = jsonData["data"];
      })
      if(window['angularComponentRef'].generateJSON){
        window['angularComponentRef'].generateJSON();
      }
    }

    if(newProj[0] && newProj[0].projectId){
      let getResData;
      let obj={
        "projectId":newProj[0].projectId
      }
       this.shareService.getUsedCssJsProject(obj).subscribe(getRes=>{
        getResData = getRes
        if(getResData && getResData != undefined && getResData != null){
          let recordListOfIndex = {
            "css":[],
            "js":[],
            "projectId":newProj[0].projectId
          };
          for(let res = 0; res<getResData.length;res++){
            if(getResData[res].type == 'CSS'){
              let cssObj={
                "fileCode":getResData[res].fileCode,
                "count":getResData[res].fileCount,
                // "usedFileJson":getResData[res].usedFileJson
              }
              recordListOfIndex["css"].push(cssObj);
            }
            if(getResData[res].type == 'JS'){
              let jsObj={
                "fileCode":getResData[res].fileCode,
                "count":getResData[res].fileCount,
                // "usedFileJson":getResData[res].usedFileJson
              }
              recordListOfIndex["js"].push(jsObj);
            }
          }
          this._sagStudioService.recondForIndexFile = recordListOfIndex;
        }
      })
     }
     let mainBody = document.querySelector("body");
     mainBody.classList.add("uiEditorNew");
     this._router.navigate(['dashboard/UIbuilder'])
  }

  setPathButtonClick(setDefault?) {
    debugger
    let selectedObj: any;
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    let pm: any;
    return pm = new Promise((res, rej) => {
      if (setDefault && this._sagStudioService.selectedProjectData) {
        const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
        const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
        this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
          async (response: any) => {
            if (response) {
              this.getUserWiseLocalProjectPathResponce = await response['data'];
              // await this.SagGridChooseProj(this.getUserWiseLocalProjectPathResponce)
              this.shareService.setDataprotool("getUserWiseLocalProjectPathResponce", response['data']);

              if (this.getUserWiseLocalProjectPathResponce.find((e) => e.projectname == this._sagStudioService.selectedProjectData.projectname)) {
                selectedObj = JSON.parse(JSON.stringify(newProj));
                selectedObj[0].awspace ? selectedObj[0].awspace = `${selectedObj[0].awspace}/${selectedObj[0].projectname}` : false;
                selectedObj[0].jwspace ? selectedObj[0].jwspace = `${selectedObj[0].jwspace}/${selectedObj[0].projectname}` : false;
                //Projects avalable on Repository auther@CP
                if (selectedObj[0] && selectedObj[0].projectGitPath && (selectedObj[0].projectGitPath != null) && (selectedObj[0].projectGitPath != '')
                  && (selectedObj[0].projectGitPath != null) && (selectedObj[0].projectSvnPath != '')) {
                  selectedObj[0]['projectOnRepository'] = true;
                } else {
                  selectedObj[0]['projectOnRepository'] = false;
                }
                this.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj[0])));
                localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj[0]));
                this.shareService.setDatadbtool("projectNameValue", selectedObj[0].projectId);
                this.shareService.setDataprotool("selectedAngularProject", selectedObj[0].awspace);
                return res(true);
              } else {
                this.config.styleClass = "visible";
                return res(false);
              }
            }
          }
        );
      } else {
        // const checkSelectedArray = this.gridDynamicForChooseProject.getSeletedRowData();
        const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
        if (newProj.length == 0) {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: `Please Select At Least One File..!`,
          });
          return rej(false);

        }
        // selectedObj = this.gridDynamicForChooseProject.getSeletedRowData();
        selectedObj = JSON.parse(JSON.stringify(newProj));
        selectedObj[0].awspace ? selectedObj[0].awspace = `${selectedObj[0].awspace}/${selectedObj[0].projectname}` : false;
        selectedObj[0].jwspace ? selectedObj[0].jwspace = `${selectedObj[0].jwspace}/${selectedObj[0].projectname}` : false;
        //Projects avalable on Repository auther@CP
        if (selectedObj[0] && selectedObj[0].projectGitPath && (selectedObj[0].projectGitPath != null) && (selectedObj[0].projectGitPath != '')
          && (selectedObj[0].projectGitPath != null) && (selectedObj[0].projectSvnPath != '')) {
          selectedObj[0]['projectOnRepository'] = true;
        } else {
          selectedObj[0]['projectOnRepository'] = false;
        }
        this.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj[0])));
        localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj[0]));
        this.shareService.setDatadbtool("projectNameValue", selectedObj[0].projectId);
        this.shareService.setDataprotool("selectedAngularProject", selectedObj[0].awspace);
        res(true);
      }
    });
  }
  
  getDbConnObj(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getPrjConfObject(dataJson).subscribe((res) => {
      if (res['status'] == 'success') {
        let dbInfo = res['confobj'];
        dbInfo['operation'] = 'COMPARESINGLE';
        dbInfo['targetDataSource'] = {};
        dbInfo['details'] = {
          software: [],
          year: [],
          client: [],
          columns: [],
          operation: ['']
        }
        this.shareService.setDatadbtool('finalDataForConnection', dbInfo);
      }
    });
  }
    // get project conf Object
    getPrjConfObj(path) {
      let dataJson = {
        projectPath: path
      }
      this.shareService.getPrjConfObject(dataJson).subscribe(async (res) => {
        this.shareService.setData('angversnObj',res['confobj'])
        let versionControl = this._sagStudioService.versionObject(res)
        if (res['status'] == 'success' && !ObjectCompare(versionControl[0], res['confobj'])) {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: "PROJECT JSON VERSION  MISMATCH",
          });
          let conf = await ui.confirm("Do You Want To Update Project JSON Version? ");
          if (conf == true) {
            await this.openVersionCheckMappingModal(res['confobj']);
          }
          // log out code
          else {
            this.firststepProjectService.logout().subscribe(
              (data) => {
                localStorage.clear();
                this.shareService.clearAllData();
                this.firststepProjectService.unAuthorizeCalllback();
              }
            );
          }
        }
        // project loaded successfull
        else {
          this.toast.launch_toast({
            type: 'success',
            position: 'bottom-right',
            message: 'Successfully Loaded Your Project !!!',
          });
          this._sagStudioService.currentActiveProject = this._sagStudioService.sagWorkSpace.projectList.find(item => item.id == 'defaultProject1618079400000');
          this._sagStudioService.initSagWorkSpaceJSON("arg1", "arg2");
          this.onGetMobileTheme();
          this._sagStudioService.getAvailModsList();
          // this.close('projectLoaded');
        }
      });
  
      function ObjectCompare(o1, o2) {
  
        if (typeof o1 !== 'object' || typeof o2 !== 'object') {
          return false; // we compare objects only!
        }
        // when one object has more attributes than the other - they can't be eq
        if (Object.keys(o1).length !== Object.keys(o2).length) {
          return false;
        }
        for (let k of Object.keys(o1)) {
          if (o1[k] !== o2[k]) {
            return false;
          }
        }
        return true;
      }
    }

    projectPathReplaceProjectWise() {
      const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
      const reqObj = {
        javaworkspace: `${newProj[0].jwspace}/${newProj[0].projectname}`,
        angworkspace: `${newProj[0].awspace}/${newProj[0].projectname}`,
      }
      this.shareService.loading++;
      this.dbcomparetoolService.projectPathReplace(reqObj).subscribe(
        (response: any) => {
          this.shareService.loading--;
          if (response['status'] == 200) {
          }
          else if (response['status'] == 500) {
            alerts(response.msg);
          }
        }, error => {
        }
      );
    }
    projectPathReplaceProjectWiseForTheia() {
      const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
      const reqObj = {
        javaworkspace: `${newProj[0].jwspace}/${newProj[0].projectname}`,
        angworkspace: `${newProj[0].awspace}/${newProj[0].projectname}`,
      }
      this.shareService.loading++;
      this.dbcomparetoolService.projectPathReplace(reqObj).subscribe(
        (response: any) => {
          this.shareService.loading--;
          if (response['status'] == 200) {
            this.shareService.loading++;
            this.shareService.setDataprotool("loadDataTreeType", "projectType");
            if (!document.getElementById('scriptLoadID')) {
              localStorage.setItem('editorLoading', 'true');
              this.addScript(this.shareService.editorLoadPath);
            }else {
              this.shareService.showEditor('show');
            }
  
            localStorage.setItem('openProject', 'false');
            localStorage.setItem('projectUtility', 'true');
  
          }
          else if (response['status'] == 500) {
            alerts(response.msg);
          }
        }, error => {
        }
      );
    }



    addScript(path) {
      var head = document.getElementsByTagName("head")[0];
      var s = document.createElement("script");
      s.type = "text/javascript";
      s.src = path;
      s.id = "scriptLoadID";
      var script = document.getElementById('scriptLoadID');
      if (script != null) {
        head.removeChild(script);
      }
      head.appendChild(s);
    }
  
    async newFunc(): Promise<void>{
      //  setTimeout( () => {
         document.querySelector('body').classList.remove('uiEditorNew');
         document.getElementById('sdmtDarkModeId').classList.contains('sdmtDarkMode') ?  document.getElementById('sdmtDarkModeId').classList.remove('sdmtDarkMode') : false;
        // await this.shareService.getAccessRights();
         this.newContact('project_type');
         this.shareService.loading--;
         success("Project Loaded Successfully !!!...");
         localStorage.setItem('editorLoading', 'false');
      // }, 4500);
   }

   newContact(route) {
    this.selectedTab = route;
    this.firststepProjectService.projectHeaderActiveTab.next(route);
    this._router.navigate(["dashboard/database/projectToolFirst/newprojectinfo/project_type"]).then(()=>{
    this.closeModel()

    });
  }
  theiaProjectLoad(){
    this.createProject(true,'theiaEditor');
  }
  
    async getpStylesScss() {
      debugger
      const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
      const fullPath = this._sagStudioService.getLocalFilePath("/src/styles.scss");
      const postData = {
        "destpath":`${newProj[0].awspace}/${newProj[0].projectname}/src/styles.scss` ,
        "projectName": `${newProj[0].projectname}`,
        "projectSubtype": "scss"
      };
      this.shareService
        .getPageJson(postData)
        .subscribe((respJson) => {
          this._sagStudioService.currentActiveProject.subDataArray.push(...respJson['data']);
          const styleScssObj = this._sagStudioService.currentActiveProject.subDataArray.find(e => e["matchableId"] == `customfile~${newProj[0].projectname}$src$styles.scss`)
          this._sagStudioService.pStylesScss = styleScssObj;
        });
    }


       // get Font FamilyList in  project
   getFontFamily(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getFontFamilyList(dataJson).subscribe(async (res) => {
      this._sagStudioService.fontFamilyList=res || [];

    });


  }
  onGetMobileTheme() {
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    const postData = {
      "projectName": `${newProj[0].projectname}`,
    };
    this.shareService
      .getMobileTheme(postData)
      .subscribe(res => {
        if (res) {
          this._sagStudioService.mobileAppTheme = res["mobileTheme"];
          // this.toast.launch_toast({
          //   type:   res["status"] == "success" ? "success" :"alert",
          //   position: 'bottom-right',
          //   message: res["msg"]
          // });
        }
      });
  }
  openVersionCheckMappingModal(data) {
    const ref = this.dialogService.open(VersionControlMappingComponent, {
      header: "Version Control",
      width: "80%",
      contentStyle: { height: "500px" },
      data: data
    });

    ref.onClose.subscribe((res) => {

    });
  }

  browseFile(event:any,langName:any){
    if(langName == 'setAngular'){
      console.log(event.target.files.webkitRelativePath,"event targetter files")
    }
    if(langName == 'setJava'){}
  }

  setErrorSuccess(){

  }

  async isRunning_Git_Svn_Server() {
    let res_checkGitServer:any = await this.dbcomparetoolService.checkRemoteGitServer().toPromise().catch((err) => {this.shareService.loading--; alerts("Error While Fetching") });
    if (res_checkGitServer['status'] == 200) {
      let res_checkSvnServer:any = await this.dbcomparetoolService.checkRemoteSvnServer().toPromise().catch((err) => { this.shareService.loading--;alerts("Error While Fetching") });
      if (res_checkSvnServer['status'] == 200) {
        this.createGit_SvnRepoServer();
      } else if (res_checkSvnServer['status'] == 500) {
        alerts(res_checkSvnServer['message']);
      }
    } else if (res_checkGitServer['status'] == 500) {
      alerts(res_checkGitServer['message']);
    }

  }

  async createGit_SvnRepoServer(){
    var id = document.getElementById(`btn-${this.activeStepId}`)

      const gitpostData = {
        "userName": this.sessionStoragedata.username,
        "projectName": this.projectCreationForm.value.projectName
      };
      const svnpostData = {
        "repoName": this.projectCreationForm.value.projectName,
        "username": this.sessionStoragedata.username,
      };

      let res_createGitRepo: any = await this.dbcomparetoolService.createGitRepoServer(gitpostData).toPromise().catch(err => { this.shareService.loading--; alerts("Error While Fetching") });
      if (res_createGitRepo['status'] == 200) {

        let res_createSvnRepo: any = await this.dbcomparetoolService.createSvnRepoServer(svnpostData).toPromise().catch(err => { this.shareService.loading--; alerts("Error While Fetching") });
        if (res_createSvnRepo['status'] == 200) {
          id.classList.remove('bg-danger-new')
          id.classList.add('bg-success-new')
          this.gitRepoPath = res_createGitRepo.gitRepoPath;
          this.svnRepoPath = res_createSvnRepo.svnRepoPath;
          
          this.projectCreationForm.patchValue({
            gitRepoPath: this.gitRepoPath,
            svnRepoPath: this.svnRepoPath
          })
            this.pathCreated = true;

        } else if (res_createSvnRepo['status'] == 500 || res_createSvnRepo['status'] == 409 || res_createSvnRepo['status'] == 204) {
          id.classList.remove('bg-success-new')
          id.classList.add('bg-danger-new')
          alerts(res_createSvnRepo['msg']);
        }

      }
      else if (res_createGitRepo['status'] == 500 || res_createGitRepo['status'] == 409) {
        id.classList.remove('bg-success-new')
        id.classList.add('bg-danger-new')
        alerts(res_createGitRepo['msg']);
      }
    
  }
 

  createBlnkProj(){
    console.log()
    var id = document.getElementById(`btn-${this.activeStepId}`)
    // if(this.projectCreationForm.value.chackBoxValue == true){
    //   if(this.projectCreationForm.valid){
    //     const gitpostData = {
    //       "userName": this.sessionStoragedata.username,
    //       "projectName": this.projectCreationForm.value.projectName
    //     };
    //     const svnpostData = {
    //       "repoName": this.projectCreationForm.value.projectName,
    //       "username": this.sessionStoragedata.username,
    //     };
    //     let forkJoinArray = [];
    //     forkJoinArray.push(this.dbcomparetoolService.createGitRepoServer(gitpostData));
    //     forkJoinArray.push(this.dbcomparetoolService.createSvnRepoServer(svnpostData));
    //     forkJoin(forkJoinArray).subscribe((res) => {
    //       // this.shareService.loading--;
    //       if (res[0]['status'] == 500) {
    //         id.classList.remove('bg-success-new')
    //         id.classList.add('bg-danger-new')
    //         alerts(res[0].message);
    //       }
    //       else if (res[0]['status'] == 409) {
    //         id.classList.remove('bg-success-new')
    //         id.classList.add('bg-danger-new')
    //         alerts(res[0].message);
    //       }
    //       else if (res[1]['status'] == 500) {
    //         id.classList.remove('bg-success-new')
    //         id.classList.add('bg-danger-new')
    //         alerts(res[1].message);
    //       }
    //       else if (res[1]['status'] == 409) {
    //         id.classList.remove('bg-success-new')
    //         id.classList.add('bg-danger-new')
    //         alerts(res[1].message);
    //       }
    //       else if (res[0]['status'] == 200) {
    //         id.classList.remove('bg-danger-new')
    //         id.classList.add('bg-success-new')
    //          this.gitRepoPath = res[0].gitRepoPath;
    //          this.svnRepoPath = res[1].svnRepoPath;
    //         this.projectCreationForm.patchValue({
    //           gitRepoPath : this.gitRepoPath,
    //           svnRepoPath : this.svnRepoPath
    //         })
    //       }
    //     },
    //       err => {
    //         this.shareService.loading--;
    //         alerts("Error While Fetching")
    //       }
    //     )
    //     const postData = {
    //       projectName: this.projectCreationForm.value.projectName,
    //       gitrepopath: this.gitRepoPath,
    //       svnrepopath: this.svnRepoPath,
    //       securityType: this.projectCreationForm.value.SecurityType,
    //       secretKey: this.projectCreationForm.value.SecretKey
    //     };
    //     this.shareService.loading++;    
    //       this.dbcomparetoolService.createProjectDbData(postData).subscribe(
    //         (response: any) => {
    //           this.shareService.loading--;
    //           if (response['status'] == 200) {
    //             // this.projectId =response['pId']
    //             success(response.msg);
    //           }
    //           if (response['status'] == 500) {
    //             alerts(response.msg);
    //           }
    //         },
    //         err => {
    //           this.shareService.loading--;
    //           alerts("Error While Fetching")
    //         }
    //       )
    //   }else{
    //     this.activeStepId = 'projNameDetails' 
    //     alerts('Please Enter Project Name')
    //   }
    // }
    // else{
      if(this.projectCreationForm.valid){
        const postData = {
          projectName: this.projectCreationForm.value.projectName,
          gitrepopath: this.gitRepoPath,
          svnrepopath: this.svnRepoPath,
          securityType: this.projectCreationForm.value.SecurityType,
          secretKey: this.projectCreationForm.value.SecretKey,
          platform:this.pltform
        };
        this.shareService.loading++;    
          this.dbcomparetoolService.createProjectDbData(postData).subscribe(
            (response: any) => {
              this.shareService.loading--;
              if (response['status'] == 200) {
                // this.projectId =response['pId']
                success(response.msg);
              }
              if (response['status'] == 500) {
                alerts(response.msg);
              }
            },
            err => {
              this.shareService.loading--;
              alerts("Error While Fetching")
            }
          )
      }
      else{
        id.classList.add('bg-danger-new')
        id.classList.remove('bg-success-new')
        this.activeStepId = 'projNameDetails' 
        alerts('Please Enter Project Name')
      }
    // }
  }

  async getLocalProjectForTheia() {
    this.shareService.projectUtility=false;
    await this.setPathButtonClick();
    this.shareService.setDataprotool('modeTreeData', []);
    this.shareService.setDataprotool('lockUnlockData', []);
    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    this.shareService.modeBoolean = true;
    if (window['angularComponentRef'].setProjectAlldetails) {
      const callFun = window['angularComponentRef'].setProjectAlldetails;
      callFun(selectedObj);
    }
    await this.shareService.getAccessRights();
    if (selectedObj) {
      const postData = {
        destpath: selectedObj.awspace,
        projectname: selectedObj.projectname,
      }
      this.shareService.loading++;
      const resSagStudioJson = await this.dbcomparetoolService.loadProjectJson(postData).toPromise();
      this.shareService.setData('ctrlopType',resSagStudioJson[0]['projectList'][0]['ctrlsOptType'])
      this.shareService.loading--;
      this._sagStudioService.sagWorkSpace = resSagStudioJson[0];
      if (this._sagStudioService.sagWorkSpace || this._sagStudioService.sagWorkSpace == undefined) {
        this.getDbConnObj(selectedObj.awspace + `/prjconn.json`);
        await this.getPrjConfObj(selectedObj.awspace + `/projectVersion.json`);
        this.getpStylesScssforTheia();
        this.getFontFamilyforTheia(selectedObj.awspace);
        // this.close('projectLoaded');
        this.selectedTab = 'project_type';
        this.projectPathReplaceProjectWiseForTheia();
        // localStorage.setItem('UIBuilder', 'true');

      } else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Something went Wrong !!!',
        });
      }
      this.shareService.propertyWindowJsonData().subscribe(jsonData => {
        this._sagStudioService.propertyWindowJson = jsonData["data"];
      })
      setTimeout(() => {
        document.getElementById('dashSideBar').classList.add('d-none');
      }, 100)
    }
  }
  async getpStylesScssforTheia() {
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    const fullPath = this._sagStudioService.getLocalFilePath("/src/styles.scss");
    const postData = {
      "destpath": fullPath,
      "projectName": `${selectedProjectChooseData.projectname}`,
      "projectSubtype": "scss"
    };
    this.shareService
      .getPageJson(postData)
      .subscribe((respJson) => {
        this._sagStudioService.currentActiveProject.subDataArray.push(...respJson['data']);
        const styleScssObj = this._sagStudioService.currentActiveProject
          .subDataArray
          .find(e => e["matchableId"] == `customfile~${selectedProjectChooseData.projectname}$src$styles.scss`)
        this._sagStudioService.pStylesScss = styleScssObj;
      });
  }
  getFontFamilyforTheia(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getFontFamilyList(dataJson).subscribe(async (res) => {
      this._sagStudioService.fontFamilyList=res || [];

    });
  }

  //select angular version
  selectVersion(event:any){
    this.projectCreationForm.value.angularVersion = event.target.value
  }
  selectPlatform(event:any,platformType:any){
    
    if(event == true){
      switch (platformType) {
        case 'W':
        this.pltform.push('W')
        break;
        case 'D':
        this.pltform.push('D')
        break;
        case 'A':
        this.pltform.push('A')
        break;
        default:
        break;
      }
    }
    if(event == false){
      if(this.pltform.includes(platformType)){
        let index = this.pltform.indexOf(platformType)
        this.pltform.splice(index,1)
      }else{
        this.pltform = []
      }
    }

   }
}
