import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ActivateButtonRightsRoutingModule } from './activate-button-rights-routing.module';
import { ActivateButtonRightsComponent } from './activate-button-rights.component';
import { TreeModule } from 'primeng/tree';


@NgModule({
  declarations: [ActivateButtonRightsComponent],
  imports: [
    CommonModule,
    ActivateButtonRightsRoutingModule,
    TreeModule
  ],exports:[ActivateButtonRightsComponent]
})
export class ActivateButtonRightsModule { }
