import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DialogService, DynamicDialogRef } from 'primeng/primeng';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';

@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: 'app-activate-button-rights',
  templateUrl: './activate-button-rights.component.html',
  styleUrls: ['./activate-button-rights.component.scss']
})
export class ActivateButtonRightsComponent implements OnInit {
  _activateButtonJsonTree: boolean = false;
  treeOptionsData = []
  btnjsonData: any;
  
  constructor( private formbuilder: FormBuilder,
    public dialogService: DialogService,
    public shareService: SagShareService,
    public modalRef: DynamicDialogRef,
    private buttonRightsServices: ProcomparetoolService) { }

  ngOnInit() {
    this.__getPageBtnJson();
  }
  _activateButtonRights() {
    this._activateButtonJsonTree = !this._activateButtonJsonTree;
  }

  __getPageBtnJson() {
    const __prjDetails = this.shareService.getDataprotool("selectedProjectChooseData");
    const __sessionInfo = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    if (__prjDetails) {
      let reqJson = {
        "projectName": __prjDetails['projectname'],
        "userId": __sessionInfo['data']['clientInfo']['usrId']
      };
      this.buttonRightsServices.getPageBtnJson(reqJson).subscribe(
        (response: any) => {
          if (response) {
            this.btnjsonData = response['btnjson'];
            let mappedResponse = this.btnjsonData.map(_item => {
              let newitem = _item;
              newitem['Kdetails'] = _item['children'];
              if (_item.children !== undefined) {
                _item.children
                this.__recursiveFunction(_item.children);
              }
              return newitem;
            })
            this.shareService.setDataprotool("projectMenuTreeFiles", this.btnjsonData);
            this.treeOptionsData = mappedResponse;
          }
        }
      );
    }
  }
  __recursiveFunction(param) {
    param.map(item => {
      let __newItem = item;
      __newItem['Kdetails'] = item['children'];
      if (item['children']) {
        this.__recursiveFunction(item['children'])
      }
      return __newItem
    })
  }

  onNodeSelect(event){
    console.log( event['node'])
    event['node']
  }
}
