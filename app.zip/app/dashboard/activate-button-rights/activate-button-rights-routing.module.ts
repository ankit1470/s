import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivateButtonRightsComponent } from './activate-button-rights.component';


const routes: Routes = [
  {
    path:"",
    component:ActivateButtonRightsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ActivateButtonRightsRoutingModule { }
