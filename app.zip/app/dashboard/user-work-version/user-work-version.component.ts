/**
 * @author P A N K A J   S I N G H
 * @var  User Work Version in Git Svn
 */
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DialogService } from 'primeng/api';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { JavaUpdateVersionFileComponent } from './java-update-version-file/java-update-version-file.component';
import { AngUpdateVersionFileComponent } from './ang-update-version-file/ang-update-version-file.component';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: { class: 'd-flex flex-column h-100' },
  selector: 'app-user-work-version',
  templateUrl: './user-work-version.component.html',
  styleUrls: ['./user-work-version.component.scss']
})
export class UserWorkVersionComponent implements OnInit {
  userLists = []
  gridDynamicCodeHelp: any;
  gridDynamicCodeWorkVersion: any;
  workVersionForm: any;
  users = []
  constructor(public shareService: SagShareService,
    private ProcomparetoolService: ProcomparetoolService,
    private ProCompareToolService: ProcomparetoolService,
    public dialogService: DialogService,
    private formbuilder: FormBuilder,) { }

  ngOnInit() {
    this.initworkVersion();
    this.__usersList();
    this.__getProjectList();
    this.__gitSvn_WorkVersionList();
  }



  /**
    *
    * Initializing form here
    */
  initworkVersion() {
    this.workVersionForm = this.formbuilder.group({
      user: [null, Validators.required],
      ProjectName: [null, Validators.required],
    });
  }



  onOpChangeProjectName(event) {
    this.getWorkVersionListChange();
  }
  // ===========================user Work Version Api  start=====================================================
  __gitSvn_WorkVersionList() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    const __prj_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    const user_Id = parseInt(sessionStoragedatauserId.data.clientInfo.usrId);
    const Project_Id = __prj_Details['projectId']
    this.ProCompareToolService.getWorkVersion(Project_Id, user_Id).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.workVersionForm.controls['user'].patchValue(user_Id.toString());
          this.workVersionForm.controls['ProjectName'].patchValue(Project_Id);
          this.userWorkVersion(response["data"]);
        }
        else if (response["status"] == 500) {
          this.userWorkVersion([])
          alerts(response.msg)
        } else {
        }
      }, error => {
        this.userWorkVersion([])
        alerts("Error While Fetching")
      }
    );
  }


  getWorkVersionListChange() {
    if (this.workVersionForm.valid) {
      const Project_Id = parseInt(this.workVersionForm.value.ProjectName);
      const user_Id = parseInt(this.workVersionForm.value.user);
      this.ProCompareToolService.getWorkVersion(Project_Id, user_Id).subscribe(
        (response: any) => {
          if (response["status"] == 200) {
            this.userWorkVersion(response["data"]);
          }
          else if (response["status"] == 500) {
            this.userWorkVersion([])
            alerts(response.msg)
          } else {
          }
        }, error => {
          ////this.shareService.loading--;
          this.userWorkVersion([])
          alerts("Error While Fetching")
        }
      );
    }
    else {
      alerts("Please fill the Form")
    }
  }


  __usersList() {
    this.ProcomparetoolService.getUserListGitPermission().subscribe(
      (response) => {
        this.users = response["usersList"]
        this.userLists = this.users.map(item => {
          let newItem = item;
          newItem['label'] = item.usrCode,
            newItem['value'] = item.usrId
          return newItem
        })
      }
    )
  }

  projectLists = []
  __getProjectList() {
    this.ProcomparetoolService.getProjectNameList().subscribe(
      (response) => {
        if (response['status'] == 200) {
          this.projectLists = response["data"].map(item => {
            let newItem = item;
            newItem['label'] = item.projectName,
              newItem['value'] = item.projectId
            return newItem
          })
        }
        else if (response['status'] == 500) {
          this.projectLists = [];
        }

      }, error => {
        this.projectLists = [];
        alerts("Error While Fetching")
      }

    )
  }
  userWorkVersion(rowsData) {
    const sourceDiv = document.getElementById("userWorkVersionGridId");
    const columns = [
      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },

      {
        header: "User Name",
        field: "userName",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Project Name",
        field: "projectName",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "java Current Version",
        field: "javaRevision",
        "editable": false,
        width: "180px",
        "text-align": "center",
        search: true,
        columnGroup: "Java Code Version ",
        style: "background-color :  #f3e8c5",
        "styles": {
          "background-color": " #f3e8c5"
        }
      },
      {
        header: "Repository Version",
        field: "latestRevisonSvn",
        "editable": false,
        width: "132px",
        "text-align": "center",
        search: true,
        columnGroup: "Java Code Version ",
        style: "background-color :  #f3e8c5",
        "styles": {
          "background-color": " #f3e8c5"
        }
      },
      {
        header: " angular Current Version",
        field: "angRevision",
        "editable": false,
        width: "180px",
        "text-align": "center",
        search: true,
        columnGroup: "Angular Code Version ",
        style: "background-color :  #f3e8c5",
        "styles": {
          "background-color": " #f3e8c5"
        }
      },
      {
        header: "Repository Version",
        field: "latestRevisonGit",
        "editable": false,
        width: "132px",
        "text-align": "center",
        search: true,
        columnGroup: "Angular Code Version ",
        style: "background-color :  #f3e8c5",
        "styles": {
          "background-color": " #f3e8c5"
        }
      },
      {
        header: "Java Update Date Time ",
        field: "javaUpdateDate",
        filter: true,
        width: "211px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
     
      {
        header: "Angular Update Date Time  ",
        field: "angUpdateDate",
        filter: true,
        width: "240px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "Java Update Version File (Partial Update Taken) ",
        field: "JavaUpdateVersionFile",
        filter: true,
        width: "240px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": 'button',
      },
      {
        header: "Angular Update Version File (Partial Update Taken) ",
        field: "angularUpdateVersionFile",
        filter: true,
        width: "240px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": 'button',
      },

    ];
    var self = this;
    SagDynamicComp.prototype.getObject = function (params) {
      if (params['colKey'] == "JavaUpdateVersionFile") {
        return new ButtonComponent({
          "visibility": true, buttonValue: 'JavaUpdateVersionFile', classes: ['btn', 'btn-primary'],
          styles: { 'padding': '0px !important', 'font-size': '11px !important' }
        }, function (ele, params) {
          self.Java_UpdateVersionFile_Click(params);
        })
      }
      else if (params['colKey'] == "angularUpdateVersionFile") {
        return new ButtonComponent({
          "visibility": true, buttonValue: 'angularUpdateVersionFile', classes: ['btn', 'btn-primary'],
          styles: { 'padding': '0px !important', 'font-size': '11px !important' }
        }, function (ele, params) {
          self.angular_UpdateVersionFile_Click(params);
        })
      }
      else {
        return this;
      }

    }


    let components = {
      "descriptionComp": new SagInputText({}, function () {
      }),
      "textInputObj": new SagInputText({}, function () {
      }),
      "button": new SagDynamicComp({}, function (ele, param) {

      }),

    };


    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            //self.onRowSelectApprovalCommitedListGrid(event);
          },
          "onRowDbleClick": function () {
            //self.onSelectedRowDoubleClick(event);
          }
        }
      };
      this.gridDynamicCodeWorkVersion = SagGridMPT(sourceDiv, gridData, true, true);
      this.setColorOnGrid();
    }
  }

  Java_UpdateVersionFile_Click(param) {
    const ref = this.dialogService.open(JavaUpdateVersionFileComponent, {
      header: "Java Update Version in File ( Partial Update Taken)",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model ",
      data: { JavaUpdateVersion: parseInt(this.workVersionForm.value.user) }
    });
    ref.onClose.subscribe((res) => { });
  }

  angular_UpdateVersionFile_Click(param) {
    const ref = this.dialogService.open(AngUpdateVersionFileComponent, {
      header: " angular Update Version in File ( Partial Update Taken)",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model ",
      data: { angUpdateVersion: parseInt(this.workVersionForm.value.user), usrList: this.users }
    });
    ref.onClose.subscribe((res) => { });
  }

  setColorOnGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicCodeWorkVersion.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      // change Row Color
      if (ele.userName || ele.projectName) {
        self.gridDynamicCodeWorkVersion.setColRowProperty(index, 'userName', { "background": "#fff8e1" });
        self.gridDynamicCodeWorkVersion.setColRowProperty(index, 'projectName', { "background": "#f8d7da" });
      }
      ;
    });

  }
}
