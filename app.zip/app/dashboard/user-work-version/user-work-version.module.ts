import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserWorkVersionRoutingModule } from './user-work-version-routing.module';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DropdownModule,
    FormsModule,
    ReactiveFormsModule,
    UserWorkVersionRoutingModule
  ]
})
export class UserWorkVersionModule { }
