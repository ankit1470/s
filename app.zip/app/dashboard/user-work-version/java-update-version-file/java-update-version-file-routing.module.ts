import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { JavaUpdateVersionFileComponent } from './java-update-version-file.component';


const routes: Routes = [
  {
    path:"",
    component:JavaUpdateVersionFileComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class JavaUpdateVersionFileRoutingModule { }
