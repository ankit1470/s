/**
 * @author P A N K A J   S I N G H
 * @var  java-update-version-file in svn
 */
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DialogService, DynamicDialogConfig } from 'primeng/api';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
   host: { class: 'd-flex flex-column h-100' },
  selector: 'app-java-update-version-file',
  templateUrl: './java-update-version-file.component.html',
  styleUrls: ['./java-update-version-file.component.scss']
})
export class JavaUpdateVersionFileComponent implements OnInit {
  gridDynamicCodeWorkVersion: any;
  Usr_Id: any;

  constructor(public shareService: SagShareService,
    private ProCompareToolService: ProcomparetoolService,
    public dialogService: DialogService,
    private formbuilder: FormBuilder ,
     public config: DynamicDialogConfig) { }

  ngOnInit() {
    this.Usr_Id = this.config.data.JavaUpdateVersion
    this.getJavaWorkVersionFile();
  }

  getJavaWorkVersionFile() {
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    const Project_Id = __project_Details.projectId
    this.shareService.loading++;
    this.ProCompareToolService.getJavaWorkVersionFile(Project_Id,this.Usr_Id).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.shareService.loading--;
          this.userWorkVersionfile(response["data"])
        }
        else if (response["status"] == 500) {
          this.shareService.loading--;
          this.userWorkVersionfile([])
          alerts(response.msg)
        } else {
        }
      }, error => {
        this.shareService.loading--;
        this.userWorkVersionfile([])
        alerts("Error While Fetching")
      }
    );
  }
  userWorkVersionfile(rowsData) {
    const sourceDiv = document.getElementById("userWorkVersionfileFileGridId");
    const columns = [
      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },

      {
        header: "User Name",
        field: "userName",
        filter: true,
        width: "220px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Project Name",
        field: "projectName",
        filter: true,
        width: "270px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "file Name",
        field: "fileName",
        filter: true,
        width: "521px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "java Current Version",
        field: "javaRevision",
        "editable": false,
        width: "180px",
        "text-align": "center",
        search: true,
        columnGroup: "Java Code Version ",
        style: "background-color :  #f3e8c5",
        "styles": {
          "background-color": " #f3e8c5"
        }
      },
      {
        header: "Repository Version",
        field: "maxJavaRevision",
        "editable": false,
        width: "132px",
        "text-align": "center",
        search: true,
        columnGroup: "Java Code Version ",
        style: "background-color :  #f3e8c5",
        "styles": {
          "background-color": " #f3e8c5"
        }
      },
    
      {
        header: "Java Update Date Time ",
        field: "lastUpdatedOn",
        filter: true,
        width: "290px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",
      
      },
      
    


    ];  
    var self = this;
    let dropDownValue = [
      { "key": null, "val": "--Select--" },
      { "key": "Y", "val": "YES" },
      { "key": "N", "val": "NO" },
    ];

    let selectDropDown = new SagSelectBox(dropDownValue, function (ele, params) {
      ele.onkeydown = function (event) {

      }
    });

    let components = {
      "selectselectDropDown": selectDropDown,
      "descriptionComp": new SagInputText({}, function () {
      }),
      "textInputObj": new SagInputText({}, function () {
      }),
     
    };


    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            //self.onRowSelectApprovalCommitedListGrid(event);
          },
          "onRowDbleClick": function () {
            self.onSelectedRowDoubleClick(event);
          }
        }
      };
      this.gridDynamicCodeWorkVersion = SagGridMPT(sourceDiv, gridData, true, true);
      this.setColorOnGrid();
    }
  }
  JavaUpdateVersionFileClick(params: any) {
  
  }
  onSelectedRowDoubleClick(event: Event) {
    
  }
  setColorOnGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicCodeWorkVersion.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      if (ele.userName || ele.projectName || ele.javaRevision) {
        self.gridDynamicCodeWorkVersion.setColRowProperty(index, 'userName', { "background": "#fff8e1" });
        self.gridDynamicCodeWorkVersion.setColRowProperty(index, 'projectName', { "background": "#f8d7da" });
        self.gridDynamicCodeWorkVersion.setColRowProperty(index, 'javaRevision', { "background": "#f8d7da" });
      }

      ;
    });

  }
}
