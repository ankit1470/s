import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JavaUpdateVersionFileRoutingModule } from './java-update-version-file-routing.module';
import { JavaUpdateVersionFileComponent } from './java-update-version-file.component';


@NgModule({
  declarations: [JavaUpdateVersionFileComponent],
  imports: [
    CommonModule,
    JavaUpdateVersionFileRoutingModule
  ],
})
export class JavaUpdateVersionFileModule { }
