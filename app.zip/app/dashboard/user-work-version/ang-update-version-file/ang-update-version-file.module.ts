import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AngUpdateVersionFileRoutingModule } from './ang-update-version-file-routing.module';
import { AngUpdateVersionFileComponent } from './ang-update-version-file.component';


@NgModule({
  declarations: [AngUpdateVersionFileComponent],
  imports: [
    CommonModule,
    AngUpdateVersionFileRoutingModule
  ]
})
export class AngUpdateVersionFileModule { }
