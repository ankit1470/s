/**
 * @author P A N K A J   S I N G H
 * @var  Angular-Update-version-file in Git
 */

import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DialogService, DynamicDialogConfig } from 'primeng/api';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  selector: 'app-ang-update-version-file',
  templateUrl: './ang-update-version-file.component.html',
  styleUrls: ['./ang-update-version-file.component.scss']
})

export class AngUpdateVersionFileComponent implements OnInit {
  gridDynamicCodeWorkVersion: any;
  Usr_Id: any;
  _usr__List: any;

  constructor(public shareService: SagShareService,
    private ProCompareToolService: ProcomparetoolService,
    public dialogService: DialogService,
    private formbuilder: FormBuilder,
    public config: DynamicDialogConfig) { }

  ngOnInit() {
    this._usr__List = this.config['data']['angUpdateVersion'];
    const Usr_Value = this.config['data']['usrList'].filter((item)=>item.usrId ==  this._usr__List)
    this.__get_Angular_WorkVersionFile(Usr_Value[0]);
  }

  __get_Angular_WorkVersionFile(Usr_Value) {
    const __prj_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    const Project_Id = __prj_Details['projectId'];
    const __reqObj = {
      "username": Usr_Value['usrCode'],
      "projectId": Project_Id,
      "userId": parseInt(Usr_Value['usrId'])
    }
    this.ProCompareToolService.get_Ang_WorkVersionFile(__reqObj).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.ang_UserWorkVersionfile(response["data"])
        }
        else if (response["status"] == 500) {
          this.ang_UserWorkVersionfile([])
          alerts(response.msg)
        } else {
        }
      }, error => {
        this.ang_UserWorkVersionfile([])
        alerts("Error While Fetching")
      }
    );
  }
  ang_UserWorkVersionfile(rowsData) {
    const sourceDiv = document.getElementById("ang_UserWorkVersionfileGridId");
    const columns = [
      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },

      {
        header: "User Name",
        field: "userName",
        filter: true,
        width: "220px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Project Name",
        field: "projectName",
        filter: true,
        width: "270px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "file Name",
        field: "fileName",
        filter: true,
        width: "521px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Angular Code Version",
        field: "angularRevision",
        filter: true,
        width: "160px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",


      },
      {
        header: "Angular Update Date Time ",
        field: "createdOn",
        filter: true,
        width: "290px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },




    ];
    var self = this;
    let dropDownValue = [
      { "key": null, "val": "--Select--" },
      { "key": "Y", "val": "YES" },
      { "key": "N", "val": "NO" },
    ];

    let selectDropDown = new SagSelectBox(dropDownValue, function (ele, params) {
      ele.onkeydown = function (event) {

      }
    });

    let components = {
      "selectselectDropDown": selectDropDown,
      "descriptionComp": new SagInputText({}, function () {
      }),
      "textInputObj": new SagInputText({}, function () {
      }),

    };


    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            //self.onRowSelectApprovalCommitedListGrid(event);
          },
          "onRowDbleClick": function () {
           // self.onSelectedRowDoubleClick(event);
          }
        }
      };
      this.gridDynamicCodeWorkVersion = SagGridMPT(sourceDiv, gridData, true, true);
      this.setColorOnGrid();
    }
  }

  setColorOnGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicCodeWorkVersion.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      if (ele.userName || ele.projectName  || ele.angularRevision) {
        self.gridDynamicCodeWorkVersion.setColRowProperty(index, 'userName', { "background": "#fff8e1" });
        self.gridDynamicCodeWorkVersion.setColRowProperty(index, 'projectName', { "background": "#f8d7da" });
        self.gridDynamicCodeWorkVersion.setColRowProperty(index, 'angularRevision', { "background": "#f8d7da" });
      };
    });

  }
}

