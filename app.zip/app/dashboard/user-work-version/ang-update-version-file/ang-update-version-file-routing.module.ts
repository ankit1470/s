import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AngUpdateVersionFileComponent } from './ang-update-version-file.component';


const routes: Routes = [
  {
    path:"",
    component:AngUpdateVersionFileComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AngUpdateVersionFileRoutingModule { }
