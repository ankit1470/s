import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserWorkVersionComponent } from './user-work-version.component';


const routes: Routes = [
  {
    path:"",
    component:UserWorkVersionComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserWorkVersionRoutingModule { }
