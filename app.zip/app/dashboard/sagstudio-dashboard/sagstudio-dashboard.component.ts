import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DialogService } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { TaskProgressComponent } from 'src/app/modules/database/project-utility-tool/procompare-tool/pmt/task-progress/task-progress.component';
import { ProcomparetoolFirststepService } from 'src/app/services/project-utility-tool/procomparetool-firststep.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { CreateProjectStepperComponent } from '../create-project-stepper/create-project-stepper.component';

declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var SdmtGridT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: 'app-sagstudio-dashboard',
  templateUrl: './sagstudio-dashboard.component.html',
  styleUrls: ['./sagstudio-dashboard.component.scss'],
  // providers: [DialogService],  
})
export class SagstudioDashboardComponent implements OnInit, AfterViewInit {
  gridDynamicForProjectDetail: any;
  gridDynamicForProjectModuleList: any;
  gridDynamicForProjectTaskDetails: any;
  RecentPostOnProject: any;
  data = [
    {
      "children": [],
      "label": "Pmt Testing Demo1",
      "id": "dashboardId"
    },
    {
      "children": [],
      "label": "Demo Pmt Task",
      "id": "commonId"
    },
    {
      "children": [],
      "label": "sdmt Testing",
      "id": "mediaLayoutId"
    },
    {
      "children": [
        {

          "label": "task 1",
          "id": "task1Id"
        },
        {
          "label": "addtask",
          "id": "addtaskId"
        }
      ],
      "label": "Application Bug",
      "id": "templateControlsId"
    },
    {
      "children": [
        {

          "label": "task 2",
          "id": "task2Id"
        },
        {
          "label": "addtask2",
          "id": "addtask2Id"
        }
      ],
      "label": "New Enhance",
      "id": "dynTemplateControlsId"
    },
    {
      "children": [],
      "label": "New Require",
      "id": "specializedControlsId"
    },
    {
      "children": [],
      "label": "Suggestions",
      "id": "suggestionsId"
    },
    {
      "children": [],
      "label": "Other",
      "id": "otherId"
    },
    {
      "children": [],
      "label": "New Enhencement",
      "id": "newenhencementId"
    },
    {
      "children": [],
      "label": "bug Testing",
      "id": "bugtestingId"
    }
  ]
  gridDynamicForProjectMyTaskList: any;
  projectDetail: any = [
    {
      "projectName": "genofficemanagement",
      "open": "1",
      "inprogress": "8",
      "close": "97",
      "total": 106
    }
  ];
  projectTaskDetails: any = [
    {
      "module": "Super Admin",
      "critical": 0,
      "major": 11,
      "moderate": 26,
      "minor": 3
    },
    {
      "module": "Banner",
      "critical": 0,
      "major": 1,
      "moderate": 0,
      "minor": 0
    }
  ];
  projectMyTaskList: any = [
    {
      "taskName": "Work on designer for Responsive Design",
      "projectName": "genOfficemanagement",
      "moduleName": "Pan Module",
      "startDate": "12/11/2023",
      "taskseverity": "Critical",
      "taskpriority": "High",
      "tasktype": "New Require",
      "detail": ""
    },

  ];
  getAllProjects: any;
  getUserWiseLocalProjectPathResponce: any;
  selectedTab: any;
  taskTableDataList: any;


  constructor(public _sagStudioService: SagStudioService, private procomparetool: ProcomparetoolService,
    public firststepProjectService: ProcomparetoolFirststepService,
    //  public modalRef: DynamicDialogRef,
    public toast: ToastService,
    public _router: Router,
    public dialogService: DialogService,
    //  public config: DynamicDialogConfig,
    private shareService: SagShareService) {

    window['angularComponentRef'] = window['angularComponentRef'] || {};
    window['angularComponentRef'].getAccessRights = this.shareService.getAccessRights.bind(this.shareService);
    window['angularComponentRef'].getAccessTreeRightsJson = this.shareService.getAccessTreeRightsJson.bind(this.shareService);

    window['angularComponentRef'].newFunc = this.newFunc.bind(this);
    if (document.getElementById('scriptLoadID')) {
      this.shareService.showEditor('hide');
    }
  }

  ngOnInit() {
    let projectData=JSON.parse(localStorage.getItem("checkProjectData"));
    if(projectData){
      this.getLocalProject(projectData);
      localStorage.removeItem("checkProjectData");
     // this.shareService.projectUtility = false;

    }
    this.shareService.showBar.next(true);
    document.getElementById('sdmtDarkModeId').classList.contains('sdmtDarkMode') ?  document.getElementById('sdmtDarkModeId').classList.remove('sdmtDarkMode') : false;
    if( document.getElementById('dashSideBar')){
      document.getElementById('dashSideBar').classList.remove('d-none');
    }
    this.getTaskTableData();
    this.getProjectTaskDetails();
    this.getAllProjectFrontBackend();
    this.getUserWiseLocalProjectPath();
  }

  getAllProjectFrontBackend() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId
    //   this.shareService.loading++;
    this.procomparetool.AllProjectFrontBackend(userid).subscribe(
      (response: any) => {
        this.shareService.setDatadbtool("AllProjectFrontBackendData", response["data"])
        //  this.shareService.loading--;
        if (response) {
          this.getAllProjects = response["data"];
        }
      },
      err => {
        //  this.shareService.loading--;
      } 
    );

  }

  getUserWiseLocalProjectPath() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    //  this.shareService.loading++;
    this.procomparetool.getUserWiseLocalProjectPath(userId).subscribe(
      (response: any) => {
        //  this.shareService.loading--;
        if (response["status"] == 200) {
          this.getUserWiseLocalProjectPathResponce = response['data']
          // this.SagGridChooseProj(this.getUserWiseLocalProjectPathResponce)
          this.shareService.setDataprotool("getUserWiseLocalProjectPathResponce", response['data']);
        }
        else if (response["status"] == 500) {
          //   this.shareService.loading--;
          //  this.SagGridChooseProj([]);
        }
      },
      error => {
        //  this.shareService.loading--;
        alerts("Error While Fetching")

      }
    );
  }

  ngAfterViewInit() {
    sessionStorage.setItem('newDashboard','false')
    // this.projectModuleListGrid([]);
    this.projectTaskDetailsGrid([]);
   // this.projectMyTaskListGrid([]);
   this.projectMyTaskListGridNew([])


  }

  //============ Project Detail Grid =============
  // projectDetailGrid(rowsData) {
  //   const sourceDiv = document.getElementById("ProjectDetailId");
  //   const columns = [
  //     {
  //       "header": "Sr.No",
  //       "field": "sno",
  //       "filter": false,
  //       "width": "50px",
  //       "editable": "false",
  //       "textalign": "center",
  //       "search": false,
  //       style: "font-weight: bold;",
  //       //"ngclick": "selectRowImport($event)",
  //       //"ngdblclick": "selectRowImportDblClick($event)",

  //     },
  //     {
  //       header: "Project Name",
  //       field: "projectname",
  //       filter: false,
  //       width: "350px",
  //       "editable": false,
  //       "text-align": "left",
  //       search: false,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },

  //     {
  //       header: "Open",
  //       field: "totalopen",
  //       filter: false,
  //       width: "190px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: false,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },
  //     {
  //       header: "In-Progress",
  //       field: "totalinprogress",
  //       filter: false,
  //       width: "190px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: false,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },
  //     {
  //       header: "Close",
  //       field: "totalclose",
  //       filter: false,
  //       width: "190px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: false,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },
  //     {
  //       header: "Total",
  //       field: "Totaltask",
  //       filter: false,
  //       width: "227px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: false,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },


  //   ];
  //   var self = this;
  //   let components = {
  //     "checkbox1": new SagCheckBox({}, function () {
  //     }),
  //     "checkbox2": new SagCheckBox({}, function () {
  //     }),
  //     "checkbox3": new SagCheckBox({}, function () {
  //     }),
  //     "checkbox4": new SagCheckBox({}, function () {
  //     }),
  //     "checkbox5": new SagCheckBox({}, function () {
  //     }),
  //     "headerCheckBox1": new headerCheckBox({}, function () {
  //     }),
  //     "headerCheckBox2": new headerCheckBox({}, function () {
  //     }),
  //     "headerCheckBox3": new headerCheckBox({}, function () {
  //     }),
  //     "headerCheckBox4": new headerCheckBox({}, function () {
  //     }),
  //     "headerCheckBox5": new headerCheckBox({}, function () {
  //     }),
  //   };


  //   let frezColumn = { "sno1": "left", "modulePath": "left", "FileName": "left", "Type": "left" };
  //   let SagGridRowStatus = rowsData;
  //   for (let i = 0; i < SagGridRowStatus.length; i++) {
  //     SagGridRowStatus[i]["sno"] = i + 1;
  //   }

  //   if (undefined != sourceDiv) {
  //     var gridData = {
  //       columnDef: columns,
  //       rowDef: SagGridRowStatus,
  //       menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
  //       selection: "row",
  //       components: components,
  //       frezzManager: frezColumn,
  //       clientSidePagging: false,
  //       recordPerPage: 20,
  //       recordNo: false,
  //       totalNoOfRecord_hide: true,
  //       sml_expandGrid_hide: true,
  //       exportXlsxPage_hide: true,
  //       exportXlsxAllPage_hide: true,
  //       exportPDFLandscape_hide: true,
  //       exportPDFPortrait_hide: true,
  //       ariaHidden_hide: true,
  //       // disableAllSearch: true,
  //       // wordBreak: false,
  //       // wordBreakHeader: false,
  //       // cellHover: false,
  //       // rowHover: false,
  //       // rowBorder_hide: false,
  //       // columnBorder_hide: true,
  //       // header_hide: false,
  //       // common_search: false,
  //       // common_search_column: "",
  //       rowCustomHeight: 40,
  //       header: {
  //         style: { "background-color": "#ffffff", "border": "1px solid #ffffff", "importantArr": ["text-align"], "text-shadow": "0px 0px 0px #ffffff", "color": "#000000", "font-weight": "700", "float": "none", "text-align": "left" },
  //         filter: false,
  //       },
  //       callBack: {
  //         "onRowClick": function () {
  //           self.onRowSelectProjectDetail(event);
  //         },
  //         "onRowDbleClick": function () {
  //           self.onRowSelectDBProjectDetail(event);
  //         },
  //         "onCellClick": function (event) {
  //           // self.onCellSelectFnJA(event)
  //         }
  //       }




  //     };




  //     this.gridDynamicForProjectDetail = SdmtGridT(sourceDiv, gridData, true, true);
  //     self.setColorSubOnGrid();
  //     return this.gridDynamicForProjectDetail;
  //   }
  // }
  // onRowSelectProjectDetail(event: Event) {
  //   const projectId = this.gridDynamicForProjectDetail.getSeletedRowData()["projectId"];
  //   this.getRecentPostOnProject(projectId);
  // }
  // onRowSelectDBProjectDetail(event: Event) {
  //   const projectId = this.gridDynamicForProjectDetail.getSeletedRowData()["projectId"];
  //   console.log(projectId);
  //   // this.projectTaskDetailsGrid(this.projectTaskDetails);
  //   // this.projectMyTaskListGrid(this.projectMyTaskList);
  //   this.projectMyTaskListGrid(this.taskTableDataList);

  //   // this.getProjectMyTaskList(projectId);
  // }
   setColorSubOnGrid() {

   }

  //============ Module List Grid =============
  projectModuleListGrid(rowsData) {
    const sourceDiv = document.getElementById("projectModuleListId");
    const columns = [
      {
        "header": "Sr.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        //"ngclick": "selectRowImport($event)",
        //"ngdblclick": "selectRowImportDblClick($event)",

      },
      {
        header: "Module Name",
        field: "moduleName",
        filter: true,
        width: "250px",
        "editable": false,
        "text-align": "left",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },

      {
        header: "Assigned Team",
        field: "assignedTeam",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "left",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },
      {
        header: "Assigned TL",
        field: "assignedTl",
        filter: true,
        width: "100px",
        "editable": false,
        "text-align": "center",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },
      {
        header: "Assigned On",
        field: "assignedOn",
        filter: true,
        width: "400px",
        "editable": false,
        "text-align": "left",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },
      {
        header: "Current Status",
        field: "currentStatus",
        filter: true,
        width: "100px",
        "editable": false,
        "text-align": "center",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },



    ];
    var self = this;
    let components = {
      "checkbox1": new SagCheckBox({}, function () {
      }),
      "checkbox2": new SagCheckBox({}, function () {
      }),
      "checkbox3": new SagCheckBox({}, function () {
      }),
      "checkbox4": new SagCheckBox({}, function () {
      }),
      "checkbox5": new SagCheckBox({}, function () {
      }),
      "headerCheckBox1": new headerCheckBox({}, function () {
      }),
      "headerCheckBox2": new headerCheckBox({}, function () {
      }),
      "headerCheckBox3": new headerCheckBox({}, function () {
      }),
      "headerCheckBox4": new headerCheckBox({}, function () {
      }),
      "headerCheckBox5": new headerCheckBox({}, function () {
      }),
    };


    let frezColumn = { "sno1": "left", "modulePath": "left", "FileName": "left", "Type": "left" };
    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        frezzManager: frezColumn,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.onRowSelectProjectModuleList(event);
          },
          "onRowDbleClick": function () {
            self.onRowSelectDBProjectModuleList(event);
          },
          "onCellClick": function (event) {
            // self.onCellSelectFnJA(event)
          }
        }
      };
      this.gridDynamicForProjectModuleList = SagGridMPT(sourceDiv, gridData, true, true);
      self.setColorSubOnGrid();
      return this.gridDynamicForProjectModuleList;
    }
  }
  onRowSelectProjectModuleList(event: Event) {

  }
  onRowSelectDBProjectModuleList(event: Event) {

  }

  //============ Task Details Grid =============
  projectTaskDetailsGrid(rowsData) {
    const sourceDiv = document.getElementById("projectTaskDetailsId");
    const columns = [
      {
        "header": "Sr.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        //"ngclick": "selectRowImport($event)",
        //"ngdblclick": "selectRowImportDblClick($event)",

      },
      {
        header: "Module",
        field: "module",
        filter: true,
        width: "350px",
        "editable": false,
        "text-align": "left",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },

      {
        header: "Critical",
        field: "critical",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "left",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },
      {
        header: "Major",
        field: "major",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "left",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },
      {
        header: "Moderate",
        field: "moderate",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "left",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },
      {
        header: "Minor",
        field: "minor",
        filter: true,
        width: "250px",
        "editable": false,
        "text-align": "left",
        search: true,
        //"ng-dblclick": "dblClickSection()"
      },



    ];
    var self = this;
    let components = {
      "checkbox1": new SagCheckBox({}, function () {
      }),
      "checkbox2": new SagCheckBox({}, function () {
      }),
      "checkbox3": new SagCheckBox({}, function () {
      }),
      "checkbox4": new SagCheckBox({}, function () {
      }),
      "checkbox5": new SagCheckBox({}, function () {
      }),
      "headerCheckBox1": new headerCheckBox({}, function () {
      }),
      "headerCheckBox2": new headerCheckBox({}, function () {
      }),
      "headerCheckBox3": new headerCheckBox({}, function () {
      }),
      "headerCheckBox4": new headerCheckBox({}, function () {
      }),
      "headerCheckBox5": new headerCheckBox({}, function () {
      }),
    };


    let frezColumn = { "sno1": "left", "modulePath": "left", "FileName": "left", "Type": "left" };
    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        frezzManager: frezColumn,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: false,
        // footer_hide:true,

        // columnDef: colData ? colData : this.columnData_libraryfonts,
        // rowDef: rowData ? rowData : this.rowData_libraryfonts,
        // footer_hide: false,
        totalNoOfRecord_hide: true,
        sml_expandGrid_hide: true,
        exportXlsxPage_hide: true,
        exportXlsxAllPage_hide: true,
        exportPDFLandscape_hide: true,
        exportPDFPortrait_hide: true,
        ariaHidden_hide: true,
        // disableAllSearch: false,
        // wordBreak: false,
        // wordBreakHeader: false,
        // cellHover: false,
        // rowHover: false,
        // rowBorder_hide: false,
        // columnBorder_hide: false,
        // header_hide: false,
        // common_search: false,
        // common_search_column: "",
        // gridbody_hide: false,
        // rowLineSpace: 0,
        callBack: {
          "onRowClick": function () {
            self.onRowSelectProjectTaskDetails(event);
          },
          "onRowDbleClick": function () {
            self.onRowSelectDBProjectTaskDetails(event);
          },
          "onCellClick": function (event) {
            // self.onCellSelectFnJA(event)
          }
        }
      };
      this.gridDynamicForProjectTaskDetails = SagGridMPT(sourceDiv, gridData, true, true);
      self.setColorSubOnGrid();
      return this.gridDynamicForProjectTaskDetails;
    }
  }
  onRowSelectProjectTaskDetails(event: Event) {

  }
  onRowSelectDBProjectTaskDetails(event: Event) {

  }

  //============ My Task List Grid =============
  // projectMyTaskListGrid(rowsData) {
  //   const sourceDiv = document.getElementById("projectMyTaskListId");
  //   const columns = [
  //     {
  //       "header": "Sr.No",
  //       "field": "sno",
  //       "filter": true,
  //       "width": "50px",
  //       "editable": "false",
  //       "textalign": "center",
  //       "search": false,
  //       //"ngclick": "selectRowImport($event)",
  //       //"ngdblclick": "selectRowImportDblClick($event)",

  //     },
  //     {
  //       header: "Task Name",
  //       field: "task_name",
  //       filter: true,
  //       width: "300px",
  //       "editable": false,
  //       "text-align": "left",
  //       search: true,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },

  //     // {
  //     //   header: "Project Name",
  //     //   field: "project_name",
  //     //   filter: true,
  //     //   width: "200px",
  //     //   "editable": false,
  //     //   "text-align": "center",
  //     //   search: true,
  //     //   //"ng-dblclick": "dblClickSection()"
  //     // },
  //     // {
  //     //   header: "Module Name",
  //     //   field: "module_name",
  //     //   filter: true,
  //     //   width: "200px",
  //     //   "editable": false,
  //     //   "text-align": "center",
  //     //   search: true,
  //     //   //"ng-dblclick": "dblClickSection()"
  //     // },



  //     {
  //       header: "Start Date",
  //       field: "start_date",
  //       filter: true,
  //       width: "100px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: true,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },
  //     {
  //       header: "Task Severity",
  //       field: "severity",
  //       filter: true,
  //       width: "140px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: true,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },
  //     {
  //       header: "Task Priority",
  //       field: "priority",
  //       filter: true,
  //       width: "150px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: true,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },
  //     {
  //       header: "Task Type",
  //       field: "type",
  //       filter: true,
  //       width: "150px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: true,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //     },
  //     {
  //       header: "Action",
  //       field: "action",
  //       filter: true,
  //       width: "150px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: true,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //       "cellRenderView": "actionComponentObj",
  //     },
  //     {
  //       header: "Load Project",
  //       field: "loadproject",
  //       filter: true,
  //       width: "150px",
  //       "editable": false,
  //       "text-align": "center",
  //       search: true,
  //       style: "font-weight: bold;",
  //       //"ng-dblclick": "dblClickSection()"
  //       "cellRenderView": "loadProjectComponentObj",
  //     },



  //   ];
  //   var self = this;
  //   let components = {
  //     "checkbox1": new SagCheckBox({}, function () {
  //     }),
  //     "checkbox2": new SagCheckBox({}, function () {
  //     }),
  //     "checkbox3": new SagCheckBox({}, function () {
  //     }),
  //     "checkbox4": new SagCheckBox({}, function () {
  //     }),
  //     "checkbox5": new SagCheckBox({}, function () {
  //     }),
  //     "headerCheckBox1": new headerCheckBox({}, function () {
  //     }),
  //     "headerCheckBox2": new headerCheckBox({}, function () {
  //     }),
  //     "headerCheckBox3": new headerCheckBox({}, function () {
  //     }),
  //     "headerCheckBox4": new headerCheckBox({}, function () {
  //     }),
  //     "headerCheckBox5": new headerCheckBox({}, function () {
  //     }),
  //     "actionComponentObj": new ButtonComponent({
  //       "visibility": true, buttonValue: `Action`, classes: ['btn', 'btn-primary'],
  //       styles: { 'padding': '0px !important', 'font-size': '11px !important' }
  //     }, function (ele, params) {
  //       ele.onclick = function (evt) {
  //         const data = {
  //           apiId: params.rowValue.apiId
  //         }
  //         // self.modifyJavaApi(data);
  //         self.openTaskProgressComponentModal();
  //       }

  //     }),
  //     "loadProjectComponentObj": new ButtonComponent({
  //       "visibility": true, buttonValue: `Load Project`, classes: ['btn', 'btn-primary'],
  //       styles: { 'padding': '0px !important', 'font-size': '11px !important' }
  //     }, function (ele, params) {
  //       ele.onclick = function (evt) {
  //         const data = {
  //           apiId: params.rowValue.apiId
  //         }

  //         self.getLocalProject();
  //         // self.modifyJavaApi(data);
  //       }

  //     }),
  //   };


  //   let frezColumn = { "action": "right", "loadproject": "right" };
  //   let SagGridRowStatus = rowsData;
  //   for (let i = 0; i < SagGridRowStatus.length; i++) {
  //     SagGridRowStatus[i]["sno"] = i + 1;
  //   }

  //   if (undefined != sourceDiv) {
  //     var gridData = {
  //       columnDef: columns,
  //       rowDef: SagGridRowStatus,
  //       menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
  //       selection: "row",
  //       components: components,
  //       frezzManager: frezColumn,
  //       clientSidePagging: true,
  //       recordPerPage: 20,
  //       recordNo: true,
  //       totalNoOfRecord_hide: true,
  //       sml_expandGrid_hide: true,
  //       exportXlsxPage_hide: true,
  //       exportXlsxAllPage_hide: true,
  //       exportPDFLandscape_hide: true,
  //       exportPDFPortrait_hide: true,
  //       ariaHidden_hide: true,
  //       callBack: {
  //         "onRowClick": function () {
  //           self.onRowSelectProjectMyTaskList(event);
  //         },
  //         "onRowDbleClick": function () {
  //           self.onRowSelectDBProjectMyTaskList(event);
  //         },
  //         "onCellClick": function (event) {
  //           // self.onCellSelectFnJA(event)
  //         }
  //       }
  //     };
  //     this.gridDynamicForProjectMyTaskList = SagGridMPT(sourceDiv, gridData, true, true);
  //     self.setColorSubOnGrid();
  //     return this.gridDynamicForProjectMyTaskList;
  //   }
  // }
  // onRowSelectProjectMyTaskList(event: Event) {

  // }
  // onRowSelectDBProjectMyTaskList(event: Event) {

  // }

  getProjectTaskDetails() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    const userId = sessionStoragedatauserId["data"]["clientInfo"]["usrId"];
    this.procomparetool.getSagStudioProjectDetailList(userId).subscribe(res => {
      if (res["status"] == 200) {
       // this.projectDetailGrid(res["data"]);
      this.projectlistnew(res["data"]);
      }
      else {
       // this.projectDetailGrid([]);
        this.projectlistnew([]);
      }
    })
  }

  getProjectMyTaskList(projectId) {
    // const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    // const userId =16;//sessionStoragedatauserId["data"]["clientInfo"]["usrId"];
    const userid = projectId;
    this.procomparetool.getSagStudioProjectMyTaskListList(userid).subscribe(res => {
 
      if (res["status"] == 200) {
       // this.projectMyTaskListGrid(res["data"]);
        this.projectMyTaskListGridNew(res["data"])
      }
      else {
        //this.projectMyTaskListGrid([]);
        this.projectMyTaskListGridNew([])
      }
    })

  }
  getRecentPostOnProject(projectId: any) {

    this.procomparetool.getRecentPostOnProject(projectId).subscribe(res => {

      if (res["status"] == 200) {
        this.RecentPostOnProject = res["data"];
      }

    })
  }

  async getLocalProject(proData?) {
    let projectData = this.shareService.getDataprotool("selectedProjectChooseData");
    this.shareService.projectUtility = false;
    await this.setPathButtonClick(proData);
    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    if (document.getElementById('scriptLoadID')) {
      if (projectData && selectedObj) {
        if (projectData.awspace == selectedObj.awspace) {
          this._router.navigate(['dashboard/database/projectToolFirst/newprojectinfo/project_type']);
          return;
        } else {
          await this.shareService.closeAllTerminalServers();
          if (window['angularComponentRef'].callStoreLayout) {
            await window['angularComponentRef'].callStoreLayout();
          }
          localStorage.setItem("checkProjectData", JSON.stringify(selectedObj));
          if (window['angularComponentRef'].getCheckClickOnLogout) {
            const checkClickOnLogout = await window['angularComponentRef'].getCheckClickOnLogout;
            checkClickOnLogout(true);
          }
          window.location.reload();
        }

      }
    }

    this.shareService.modeBoolean = true;
    if (window['angularComponentRef'].setProjectAlldetails) {
      const callFun = window['angularComponentRef'].setProjectAlldetails;
      callFun(selectedObj);
    }
    await this.shareService.getAccessRights();
    if (selectedObj) {
      const postData = {
        destpath: selectedObj.awspace,
        projectname: selectedObj.projectname,
      }
      this.shareService.loading++;
      const resSagStudioJson = await this.procomparetool.loadProjectJson(postData).toPromise().catch(console.warn);
      this.shareService.loading--;
      this._sagStudioService.sagWorkSpace = resSagStudioJson[0];
      if (this._sagStudioService.sagWorkSpace || this._sagStudioService.sagWorkSpace == undefined) {
        this.getDbConnObj(selectedObj.awspace + `/prjconn.json`);
        await this.getPrjConfObj(selectedObj.projectId);
        //  this.getpStylesScss();
        this.getFontFamily(selectedObj.awspace);
        // this.close('projectLoaded');
        this.selectedTab = 'project_type';
        this.projectPathReplaceProjectWise();

      } else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Something went Wrong !!!',
        });
      }
      this.shareService.propertyWindowJsonData().subscribe(jsonData => {
        this._sagStudioService.propertyWindowJson = jsonData["data"];
      })
     setTimeout(() => {
       document.querySelector('.sidebarArea').classList.add('d-none');
     document.getElementById('dashSideBar').classList.add('d-none');
      }, 100)
    }
  }

  getTaskTableData() {
    this.shareService.loading++;
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId
    this.procomparetool.getTaskTable(userid).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response) {
          this.taskTableDataList = response["data"];
        //  this.myTaskListGridNew1(this.taskTableDataList)
        }
      },
      err => {
        this.shareService.loading--;
        console.error('err response');
      }
    );
  }

  projectPathReplaceProjectWise() {
    const ProjectPath = this.shareService.getDataprotool("selectedProjectChooseData");
    const reqObj = {
      javaworkspace: ProjectPath.jwspace,
      angworkspace: ProjectPath.awspace,
    }
    this.shareService.loading++;
    this.procomparetool.projectPathReplace(reqObj).subscribe(
      async (response: any) => {
        this.shareService.loading--;
        if (response['status'] == 200) {
          this.shareService.loading++;
          this.shareService.setDataprotool("loadDataTreeType", "projectType");
          if (!document.getElementById('scriptLoadID')) {
            localStorage.setItem('editorLoading', 'true');
            this.addScript(this.shareService.editorLoadPath);
          }else {
            this.shareService.showEditor('show');
          }

          localStorage.setItem('openProject', 'false');
          localStorage.setItem('projectUtility', 'true');

        }
        else if (response['status'] == 500) {
          alerts(response.msg);
        }
      }, error => {
      }
    );
  }


  async newFunc(): Promise<void>{
    // setTimeout( () => {
     await this.shareService.getAccessRights();
      document.querySelector('body').classList.remove('uiEditorNew');
      document.getElementById('sdmtDarkModeId').classList.contains('sdmtDarkMode') ?  document.getElementById('sdmtDarkModeId').classList.remove('sdmtDarkMode') : false;
      // await this.shareService.getAccessRights();
      this.shareService.loading--;
      this.newContact('project_type');
 
      success("Project Loaded Successfully !!!...");
      localStorage.setItem('editorLoading', 'false');
    // }, 4500);
  }

  addScript(path) {
    var head = document.getElementsByTagName("head")[0];
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = path;
    s.id = "scriptLoadID";
    head.appendChild(s);
  }

  // close(res) {
  //   this.modalRef.close(res);
  // }

  getFontFamily(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getFontFamilyList(dataJson).subscribe(async (res) => {
      this._sagStudioService.fontFamilyList = res || [];

    });
  }

  getDbConnObj(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getPrjConfObject(dataJson).subscribe((res) => {
      if (res['status'] == 'success') {
        let dbInfo = res['confobj'];
        dbInfo['operation'] = 'COMPARESINGLE';
        dbInfo['targetDataSource'] = {};
        dbInfo['details'] = {
          software: [],
          year: [],
          client: [],
          columns: [],
          operation: ['']
        }
        this.shareService.setDatadbtool('finalDataForConnection', dbInfo);
      }
    });
  }
  // get project conf Object
  async getPrjConfObj(path) {
    let dataJson = {
      projectId: path
    }
    this.shareService.getProjectVersion(dataJson).subscribe(async (res) => {
      this.shareService.setData('angversnObj',res)
      let versionControl = this._sagStudioService.versionObject(res)
      if (res['status'] == 'success' && !ObjectCompare(versionControl[0], res)) {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: "PROJECT JSON VERSION  MISMATCH",
        });
        let conf = await ui.confirm("Do You Want To Update Project JSON Version? ");
        if (conf == true) {
          //  await this.openVersionCheckMappingModal(res['confobj']);
        }
        // log out code
        else {
          this.firststepProjectService.logout().subscribe(
            (data) => {
              //  this.close('projectLoaded');
              localStorage.clear();
              this.shareService.clearAllData();
              this.firststepProjectService.unAuthorizeCalllback();
            }
          );
        }
      }
      // project loaded successfull
      else {
        //success("Successfully Loaded Your Project !!!");
        // this.toast.launch_toast({
        //   type: 'success',
        //   position: 'bottom-right',
        //   message: 'Successfully Loaded Your Project !!!',
        // });

        this._sagStudioService.currentActiveProject = this._sagStudioService.sagWorkSpace.projectList.find(item => item.id == 'defaultProject1618079400000');
        this._sagStudioService.initSagWorkSpaceJSON("arg1", "arg2");
        this.onGetMobileTheme();
        //   this.close('projectLoaded');
      }
    });

    function ObjectCompare(o1, o2) {

      if (typeof o1 !== 'object' || typeof o2 !== 'object') {
        return false; // we compare objects only!
      }
      // when one object has more attributes than the other - they can't be eq
      if (Object.keys(o1).length !== Object.keys(o2).length) {
        return false;
      }
      for (let k of Object.keys(o1)) {
        if (o1[k] !== o2[k]) {
          return false;
        }
      }
      return true;
    }
  }

  onGetMobileTheme() {
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    const postData = {
      "projectName": `${selectedProjectChooseData.projectname}`,
    };
    this.shareService
      .getMobileTheme(postData)
      .subscribe(res => {
        if (res) {
          this._sagStudioService.mobileAppTheme = res["mobileTheme"];
        }
      });
  }

  async openTaskProgressComponentModal() {
    const ref = this.dialogService.open(TaskProgressComponent, {
      header: "Version Control",
      width: "80%",
      contentStyle: { height: "75vh" },
    //  styleClass: "sdmtDarkMode",
    });

    ref.onClose.subscribe((res) => {

    });
  }

  OpenCrtPrjtStepper() {
    const ref = this.dialogService.open(CreateProjectStepperComponent, {
      header: "create Project",
      width: "60%",
    //  contentStyle: { height: "70.5vh" },
      showHeader: false,
      styleClass: "service_full_model stappermain_modal",
    });
  }

  // async openVersionCheckMappingModal(data) {
  //   const ref = this.dialogService.open(VersionControlMappingComponent, {
  //     header: "Version Control",
  //     width: "80%",
  //     contentStyle: { height: "500px" },
  //     data: data
  //   });

  //   ref.onClose.subscribe((res) => {

  //   });
  // }

  newContact(route) {
    this.selectedTab = route;
    this.firststepProjectService.projectHeaderActiveTab.next(route);
    this._router.navigate(["dashboard/database/projectToolFirst/newprojectinfo/project_type"]);
  }

  setPathButtonClick(setDefault?) {
    const loginUserInfo = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = Number(loginUserInfo.data.clientInfo.usrId);
    let selectedObj: any;
    if(setDefault){
      selectedObj=setDefault;
    }else{
      selectedObj = this.gridDynamicObj_projectlistnew.getSeletedRowData();

    }
    selectedObj = JSON.parse(JSON.stringify(selectedObj));
    
    return new Promise((res, rej) => {
      if(selectedObj){
        selectedObj['userId'] = userId;
       selectedObj.awspace ? (setDefault && setDefault.awspace) ? false : selectedObj.awspace = `${selectedObj.awspace}/${selectedObj.projectname}` : false;
        selectedObj.jwspace ? (setDefault && setDefault.jwspace) ? false :selectedObj.jwspace = `${selectedObj.jwspace}/${selectedObj.projectname}` : false;
        //Projects avalable on Repository auther@CP
        if (selectedObj.projectGitPath &&selectedObj.projectSvnPath) {
          selectedObj['projectOnRepository'] = true;
        } else {
          selectedObj['projectOnRepository'] = false;
        }
        this.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj)));
        localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj));
        this.shareService.setDatadbtool("projectNameValue", selectedObj.projectId);
        this.shareService.setDataprotool("selectedAngularProject", selectedObj.awspace);
        res(true);
      }else{
        rej(false);
      }
    });
  }
  async getpStylesScss() {
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    const fullPath = this._sagStudioService.getLocalFilePath("/src/styles.scss");
    const postData = {
      "destpath": fullPath,
      "projectName": `${selectedProjectChooseData.projectname}`,
      "projectSubtype": "scss"
    };
    this.shareService
      .getPageJson(postData)
      .subscribe((respJson) => {
        this._sagStudioService.currentActiveProject.subDataArray.push(...respJson['data']);
        const styleScssObj = this._sagStudioService.currentActiveProject
          .subDataArray
          .find(e => e["matchableId"] == `customfile~${selectedProjectChooseData.projectname}$src$styles.scss`)
        this._sagStudioService.pStylesScss = styleScssObj;
      });
  }

  gridData_projectlistnew:any;
  gridDynamicObj_projectlistnew: any;
columnData_projectlistnew: any = [ 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"center",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"sno",
"freezecol":"null",
"width":"50px",
"header":"SNo",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"projectname",
"freezecol":"null",
"width":"350px",
"header":"Project Name",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"totalopen",
"freezecol":"null",
"width":"160px",
"header":"Open",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"totalinprogress",
"freezecol":"null",
"width":"160px",
"header":"In-Progress",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"totalclose",
"freezecol":"null",
"width":"160px",
"header":"Close",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"Totaltask",
"freezecol":"null",
"width":"160px",
"header":"Total",
"cellRenderView":false,

}, 
];
  
rowData_projectlistnew: any = [
{
// "date": "14-12-2023",
// "#": "1",
// "handle": "@mark",
// "projectName": "Mark",
// "Column1": "1"
// },
// {
// "date": "14-12-2023",
// "#": "2",
// "handle": "@jocob",
// "projectName": "Jacob",
// "Column1": "2"
// },
// {
// "date": "14-12-2023",
// "#": "3",
// "handle": "@larry",
// "projectName": "Larry",
// "Column1": "3"
 }
];

projectlistnew(rowData?,colData?) {
let self = this;

this.gridData_projectlistnew = {
columnDef: colData ? colData : this.columnData_projectlistnew,
rowDef: rowData ? rowData :this.rowData_projectlistnew,
footer_hide: false,
totalNoOfRecord_hide: true,
sml_expandGrid_hide: true,
exportXlsxPage_hide: true,
exportXlsxAllPage_hide: true,
exportPDFLandscape_hide: true,
exportPDFPortrait_hide: true,
ariaHidden_hide: true,
disableAllSearch: true,
wordBreak: false,
wordBreakHeader: false,
cellHover: false,
rowHover: false,
rowBorder_hide: false,
columnBorder_hide: true,
header_hide: false,
common_search: false,
common_search_column: "",
gridbody_hide: false,
rowLineSpace: 0,

components : {},
callBack: {

"onCellClick": function(ele) {

   self.onprojectlistnewCellClick();
   },
   "onRowClick": function() {
   self.onprojectlistnewClick();
  },
  "onRowDbleClick": function() {
  self.onprojectlistnewdblClick();
  }}
,


rowCustomHeight: 40,
header: {
style: {"background-color":"#ffffff","border":"1px solid #ffffff","text-shadow":"0px 0px 0px #ffffff","color":"#000000","font-weight":"700","float":"none","text-align":"left"},
filter: false,
},



};

let sourceDiv = document.getElementById("projectlistnew");
this.gridDynamicObj_projectlistnew = SdmtGridT(sourceDiv, this.gridData_projectlistnew, true, true);
return this.gridDynamicObj_projectlistnew;
}

onprojectlistnewCellClick(){

}

onprojectlistnewClick(){
  const projectId = this.gridDynamicObj_projectlistnew.getSeletedRowData()["projectId"];
    this.getRecentPostOnProject(projectId);
}

onprojectlistnewdblClick(){
  const projectId = this.gridDynamicObj_projectlistnew.getSeletedRowData()["projectId"];
  this.projectMyTaskListGridNew(this.taskTableDataList)
    // let mainBody = document.querySelector("body");
    // mainBody.classList.add("theiaEditor");
    // if (!document.getElementById('scriptLoadID')) {
    //   this.addScript(this.shareService.editorLoadPath);
    //   this.shareService.loading++;
    //   setTimeout(() => {
    //     this.shareService.loading--;
    //   }, 4500);
    // } else {
    //   this.showEditor('show');
    // }
  
}


///// my task list  
gridData_projectMyTaskListGridNew:any;
gridDynamicObj_projectMyTaskListGridNew: any;
columnData_projectMyTaskListGridNew: any = [ 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"center",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"sno",
"freezecol":"null",
"width":"50px",
"header":"SNo",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"task_name",
"freezecol":"null",
"width":"350px",
"header":"Task Name",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"start_date",
"freezecol":"null",
"width":"160px",
"header":"Start Date",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"severity",
"freezecol":"null",
"width":"160px",
"header":"Task Severity",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"priority",
"freezecol":"null",
"width":"160px",
"header":"Task Priority",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"cellHover":false,
"text-align":"left",
"editable":"false",
"sort":false,
"filter":true,
"component":"label",
"field":"type",
"freezecol":"null",
"width":"250px",
"header":"Task Type",
"cellRenderView":false,

}, 
{"hidden":false,
"search":true,
"button": { "visibility": true, "classes": ["btngrid_action"], "name": "Action", "styles": "background-color:red", "attribute": "", "cellValue": "" },
"cellHover":false,
"text-align":"center",
"editable":"false",
"sort":false,
"filter":true,
"component":"button", 
"field":"action",
"freezecol":"null",
"width":"150px",
"header":"Action",
"cellRenderView":true,
"justifyContent":"start",

}, {"hidden":false,
"search":true,
"button": { "visibility": true, "classes": ["btngrid_loadproject"], "name": "Load Project", "styles": "background-color:red", "attribute": "", "cellValue": "" },
"cellHover":false,
"text-align":"center",
"editable":"false",
"sort":false,
"filter":true,
"component":"button",
"field":"loadproject",
"freezecol":"null",
"width":"150px",
"header":"Load Project",
"cellRenderView":true,

}, 
];
  
rowData_projectMyTaskListGridNew: any = [
{

 }
];

projectMyTaskListGridNew(rowData?,colData?) {

var self = this;
let frezColumn = { "action": "right", "loadproject": "right" };
this.gridData_projectMyTaskListGridNew = {
columnDef: colData ? colData : this.columnData_projectMyTaskListGridNew,
rowDef: rowData ? rowData :this.rowData_projectlistnew,
footer_hide: false,
totalNoOfRecord_hide: true,
sml_expandGrid_hide: true,
exportXlsxPage_hide: true,
exportXlsxAllPage_hide: true,
exportPDFLandscape_hide: true,
exportPDFPortrait_hide: true,
frezzManager: frezColumn,
ariaHidden_hide: true,
disableAllSearch: true,
wordBreak: false,
wordBreakHeader: false,
cellHover: false,
rowHover: false,
rowBorder_hide: false,
columnBorder_hide: true,
header_hide: false,
common_search: false,
common_search_column: "",
gridbody_hide: false,
rowLineSpace: 0,

components : {},
callBack: {
   "onButton_loadproject":function (ele, param) {
    console.log(param);
   // alert("hello");
    // ele.click = function (evt) {
            const data = {
              apiId: param.rowValue.apiId
            }
      
            self.getLocalProject();
            // self.modifyJavaApi(data);
       //   }
  },
  
  "onButton_action":function (ele, param) {
    console.log(param);
   // alert("hello");
    // ele.onclick = function (evt) {
            const data = {
              apiId: param.rowValue.apiId
            }
            // self.modifyJavaApi(data);
            self.openTaskProgressComponentModal();
         // }
  },
"onCellClick": function(ele) {

   self.onprojectMyTaskListGridNewCellClick();
   },
   "onRowClick": function() {
   self.onprojectMyTaskListGridNewClick();
  },
  "onRowDbleClick": function() {
  self.onprojectMyTaskListGridNewdblClick();
  }}
,


rowCustomHeight: 40,
header: {
style: {"background-color":"#ffffff","border":"1px solid #ffffff","importantArr":["text-align"],"text-shadow":"0px 0px 0px #ffffff","color":"#000000","font-weight":"700","float":"none","text-align":"left"},
filter: false,
},



};

let sourceDiv = document.getElementById("projectMyTaskListGridNewId");
this.gridDynamicObj_projectMyTaskListGridNew = SdmtGridT(sourceDiv, this.gridData_projectMyTaskListGridNew, true, true);
return this.gridDynamicObj_projectMyTaskListGridNew;
}

onprojectMyTaskListGridNewCellClick(){

}

onprojectMyTaskListGridNewClick(){
  
}

onprojectMyTaskListGridNewdblClick(){
  

  // this.getProjectMyTaskList(projectId);
}
}
