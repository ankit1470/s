import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SagstudioDashboardRoutingModule } from './sagstudio-dashboard-routing.module';
import { SagstudioDashboardComponent } from './sagstudio-dashboard.component';



@NgModule({
  declarations: [SagstudioDashboardComponent],
  imports: [
    CommonModule,
    SagstudioDashboardRoutingModule,

  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class SagstudioDashboardModule { }
