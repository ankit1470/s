import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SagstudioDashboardComponent } from './sagstudio-dashboard.component';


const routes: Routes = [

  {
    path: "",
    component: SagstudioDashboardComponent
  },
  {
    path: "database",
    data: { kind: "database" },
    loadChildren: () =>
      import("../../modules/database/database.module").then(
        (mod) => mod.DatabaseModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SagstudioDashboardRoutingModule { }
