import { Component, OnInit } from '@angular/core';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { ToastService } from 'src/app/core/services/toast.service';
// this is sag grid declaration  
declare var SagGridMPT;
declare var $;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
@Component({
  selector: 'app-version-control-mapping',
  templateUrl: './version-control-mapping.component.html',
  styleUrls: ['./version-control-mapping.component.scss'],
  providers: [DialogService]

})
export class VersionControlMappingComponent implements OnInit {
  prjVersionData: any = [];
  oldPrjVersionData: any = [];

  gridData: any;
  gridDynamicObj: any;
  columnData: any = [
    {
      "header": "S.No",
      "field": "sno",
      "filter": true,
      "width": "50px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "ngclick": "selectRowImport($event)",
      "ngdblclick": "selectRowImportDblClick($event)",
    },
    {
      "header": "Name",
      "field": "name",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "ngclick": "selectRowImport($event)",
      "ngdblclick": "selectRowImportDblClick($event)",

    },
    {
      "header": "Existing Version",
      "field": "existVersion",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "ngclick": "selectRowImport($event)",
      "ngdblclick": "selectRowImportDblClick($event)",

    },
    {
      "header": "Required Version",
      "field": "reqVersion",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "ngclick": "selectRowImport($event)",
      "ngdblclick": "selectRowImportDblClick($event)",

    },
    {
      "header": "update",
      "field": "update",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "textalign": "center",
      "search": false,
      "component": 'versionCtrl', // Params Icon
    },

  ];
  rowData: any = [];

  constructor(
    public _sagStudioService: SagStudioService,
    public config: DynamicDialogConfig,
    public modalRef: DynamicDialogRef,
    public toast: ToastService
  ) {
    debugger
    this.prjVersionData = this.config.data;
    this.oldPrjVersionData =  this._sagStudioService.versionControlInfo.filter((x:any)=>{
      if(x.angular == this.prjVersionData['angular']){
        return x
      }
    })
    for (const key in this.prjVersionData) {
      if (this.prjVersionData.hasOwnProperty(key) && this.oldPrjVersionData[0].hasOwnProperty(key)) {
        const oldValue = this.prjVersionData[key];
        const newValue = this.oldPrjVersionData[0][key];

        let obj = {
          "name": key,
          "existVersion": oldValue,
          "reqVersion": newValue
        }
        this.rowData.push(obj);
      }
    }

  }

  ngOnInit() {
    this.createGrid(this.columnData, this.rowData, "parm");
  }


  // Create Grid  for Version check 
  createGrid(column, rows, prm) {
    let self = this
    SagDynamicComp.prototype.getObject = function (params) {
      return setColumnCellType(params, this);
    };

    //  create a function for column  Type
    function setColumnCellType(params, this_) {
      //  For Delete Icon 
      if (params.colKey == 'update' && params.rowValue['existVersion'] != params.rowValue['reqVersion']) {

        return new ButtonComponent({
          "visibility": true, buttonValue: `<i class="fas fa-gear"></i>`,
          styles: { 'padding': '0px !important', 'color': "red", 'font-size': '40px !important', },
          classes: ['btn'],
        }, function (ele) {
          ele.onclick = function (evt) {
            // self.updateVersion(params);
          }
        });

      } else {
        params.value = "";
        return this_;
      }

    }
    let componentObj = {
      "versionCtrl": new SagDynamicComp({}, function (ele, param) {
      })
    }

    self.gridData = {
      columnDef: column,
      rowDef: rows,

      components: componentObj,
      callBack: {
        "onRowClick": function () {
        },
      },
      rowSelection: false,
      rowDataViewTotal: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,

    };

    let sourceDiv = document.getElementById("versionCheckGrid");
    self.gridDynamicObj = SagGridMPT(sourceDiv, self.gridData, true, true);
    this.updateGridColor();
  }

  updateGridColor() {
    this.gridDynamicObj.sagGridObj.originalRowData.forEach((row) => {
      if (row['existVersion'] != row['reqVersion']) {
        this.gridDynamicObj.setColRowProperty(row.sag_G_Index, "existVersion", { "color": "black","background":"#ed0000d4" });
        this.gridDynamicObj.setColRowProperty(row.sag_G_Index, "reqVersion", { "color": "black","background":"#16f11663" });
      }
    });
  }
  closeModel(res) {
    this.modalRef.close(res);
  }

  updateVersion() {
    let selectedPackage = this.gridDynamicObj.getCheckedDataParticularColumnWise();
    if (selectedPackage.length == 0) {
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Please Select At Least One File..!`,
      });
      return;

    } else {
      console.log(selectedPackage);

    }

  }

}
