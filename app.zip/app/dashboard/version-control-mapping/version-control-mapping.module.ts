import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VersionControlMappingRoutingModule } from './version-control-mapping-routing.module';
import { VersionControlMappingComponent } from './version-control-mapping.component';


@NgModule({
  declarations: [VersionControlMappingComponent],
  imports: [
    CommonModule,
    VersionControlMappingRoutingModule
  ],
  exports:[
    VersionControlMappingComponent
  ]
})
export class VersionControlMappingModule { }
