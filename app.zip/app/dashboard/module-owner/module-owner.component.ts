/**
 * @author P A N K A J   S I N G H
 * @var  Module Assign || Module Owner
 */

import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Dropdown } from 'primeng/dropdown';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  selector: 'app-module-owner',
  templateUrl: './module-owner.component.html',
  styleUrls: ['./module-owner.component.scss']
})
export class ModuleOwnerComponent implements OnInit {
  projectLists = []
  MprojectLists = []
  OprojectLists = []
  gridDynamicOwnerList: any;
  updateButtonDisplay: boolean = false;
  saveButtonDisplay: boolean = true
  angJava = [
    {
      "label": "----Select----",
      "value": null
    },
    {
      "label": "frontend",
      "value": "F"
    }, {
      "label": "Backend",
      "value": "B"
    }
  ]
  ModuleOwnerForm: any;
  SubModuleAngularJava: any;
  projectId: any;
  moduleName: any;
  ownerName: any;
  OwnerList: any;
  ViewProjectName: any;
  onwerProjectViewData: any;
  getByIdData: any;
  constructor(private ProcomparetoolService: ProcomparetoolService,
    private shareService: SagShareService,
    private formBuilder: FormBuilder) {

  }

  ngOnInit() {
    this.initModuleOwner();
    this.getProjectList();
    this.getOwnerList();
    this.getOwnerListGrid([]);
  }
  initModuleOwner() {
    this.ModuleOwnerForm = this.formBuilder.group({
      projectId: [null, Validators.required],
      type: [null, Validators.required],
      moduleId: [null, Validators.required],
      ownerId: [null, Validators.required],
      fromDate: [null, Validators.required],
      toDate: [null, Validators.required],
      ViewProjectName: [null, Validators.required],
      moduleownrId: [null]

    });
  }

  // =========================================Dropdown Value's===============================================
  onOpChangeModuleName(event) {
    this.moduleName = event.value
  }
  onOpChangeOwnerName(event) {
    this.ownerName = event.value
  }
  onOpChangeProjectName(event) {
    this.projectId = event.value

  }
  onOpChangeType(event) {
    if (event.value == "F") {
      this.getSubModuleAngular(this.ModuleOwnerForm.value.projectId);
    }
    else if (event.value == "B") {
      this.getSubModuleJava(this.ModuleOwnerForm.value.projectId);
    }
  }
  onOpChangeTypeById(event) {
    if (event.type == "F") {
      this.getSubModuleAngular(this.ModuleOwnerForm.value.projectId);
    }
    else if (event.type == "B") {
      this.getSubModuleJava(this.ModuleOwnerForm.value.projectId);
    }
  }
  getViewOwnerListData(event) {
    this.ViewProjectName = event.value
    this.getViewOwnerList(this.ViewProjectName)
  }
  // =======================================Api Calling=======================================================
  getProjectList() {
    //this.shareService.loading++;
    this.ProcomparetoolService.getProjectNameList().subscribe(
      (response) => {
        if (response['status'] == 200) {
          this.projectLists = response["data"].map(item => {
            let newItem = item;
            newItem['label'] = item.projectName,
              newItem['value'] = item.projectId
            return newItem
          })
        }
        //this.shareService.loading--;
      }
      , error => {
        alerts("Error While ")
      }
    )
  }
  getOwnerList() {
    this.ProcomparetoolService.getUserList().subscribe(
      (response) => {
        this.OwnerList = response["result"];
        this.OwnerList = this.OwnerList.map(item => {
          let newItem = item;
          newItem['label'] = item.usrName,
          newItem['value'] = item.usrId
          return newItem
        })
      }, error => {
        alerts("Error While ")
      }
    )
  }


  getViewOwnerList(ViewProjectName) {
    if (ViewProjectName) {
      this.ProcomparetoolService.getViewonwerListData(ViewProjectName).subscribe(
        (response) => {
          this.onwerProjectViewData = response["result"]
          this.getOwnerListGrid(this.onwerProjectViewData);
        }, error => {
          alerts("Error While ")
        }
      )
    }
    else {
      alerts("Please Select Project Name")
    }
  }
  ModuleLists = []
  getSubModuleAngular(projectId) {
    if (projectId) {
      this.ProcomparetoolService.getAngularModule(projectId).subscribe(
        (response: any) => {
          if (response['status'] == 200) {
            this.ModuleLists = response["result"].map(item => {
              let newItem = item;
              newItem['label'] = item.moduleName,
                newItem['value'] = item.moduleId
              return newItem
            })
          }
        }, error => {
          alerts("Error While ")
        }
      );
    } else {
      alerts("Please Select Project Name")
    }
  }
  getSubModuleJava(projectId) {
    if (projectId) {
      this.ProcomparetoolService.getjavaPackage(projectId).subscribe(
        (response: any) => {
          if (response['status'] == 200) {
            this.ModuleLists = response["result"].map(item => {
              let newItem = item;
              newItem['label'] = item.moduleName,
                newItem['value'] = item.moduleId
              return newItem
            })
          }
        }
      );
    }
    else {
      alerts("Please Select Project Name")
    }
  }


  ModuleOwnerSaveClick() {
      const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
      const reqJson = {
        "projectId": Number(this.ModuleOwnerForm.value.projectId),
        "usrId": Number(this.ModuleOwnerForm.value.ownerId),
        "moduleownrFromdt": this.ModuleOwnerForm.value.fromDate,
        "moduleownrTodt": this.ModuleOwnerForm.value.toDate,
        "usrMid": Number(sessionStoragedatauserId.data.clientInfo.usrId),
        "moduleId": this.ModuleOwnerForm.value.moduleId
      }
      if (this.ModuleOwnerForm.value.type == "F") {
        this.assignAngularModule(reqJson);
      }
      else {
        this.assignJavaModule(reqJson);
      }


    // } else if(this.ModuleOwnerForm.invalid) {
    //   alerts("Please fill the form")
    // }
  }

  assignJavaModule(reqJson) {
    //this.shareService.loading++;
    this.ProcomparetoolService.saveTxnModuleOwnrJava(reqJson).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          //this.shareService.loading--;
          success(response.message);
          this.ModuleOwnerForm.reset();
        }
        else if (response["status"] == 500) {
          //this.shareService.loading--;
          alerts(response.message);
        } else {
        }
      }, error => {
        //this.shareService.loading--;
        alerts("Error While Fetching")
      }
    );
  }
  assignAngularModule(reqJson) {
    //this.shareService.loading++;
    this.ProcomparetoolService.saveTxnModuleOwnrAngular(reqJson).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          //this.shareService.loading--;
          success(response.message);
          this.ModuleOwnerForm.reset();
        }
        else if (response["status"] == 500) {
          //this.shareService.loading--;
          alerts(response.message)
        } else {
        }
      }, error => {
        //this.shareService.loading--;
        alerts("Error While Fetching")
      }
    );
  }

  moduleOwnerUpdateClick() {
    if (this.ModuleOwnerForm.value.projectId) {
      const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
      const reqJson = {
        "projectId": Number(this.ModuleOwnerForm.value.projectId),
        "usrId": Number(this.ModuleOwnerForm.value.ownerId),
        "moduleownrFromdt": this.ModuleOwnerForm.value.fromDate,
        "moduleownrTodt": this.ModuleOwnerForm.value.toDate,
        "usrMid": Number(sessionStoragedatauserId.data.clientInfo.usrId),
        "moduleId": this.ModuleOwnerForm.value.moduleId,
        "moduleownrId": this.ModuleOwnerForm.controls["moduleownrId"].value
      }
      if (this.ModuleOwnerForm.value.type == "F") {
        this.updateAssignAngularModule(reqJson);
      }
      else {
        this.updateAssignJavaModule(reqJson);

      }


    } else {
      alerts("Please select Project Name")
    }
  }


  updateAssignJavaModule(reqJson) {
    //this.shareService.loading++;
    this.ProcomparetoolService.updateTxnModuleOwnrJava(reqJson).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          //this.shareService.loading--;
          success(response.message);
          this.saveButtonDisplay = true;
          this.updateButtonDisplay = false;
          this.ModuleOwnerForm.reset();
        }
        else if (response["status"] == 500) {
          //this.shareService.loading--;
          alerts(response.message)
        } else {
        }
      }, error => {
        //this.shareService.loading--;
        alerts("Error While Fetching")
      }
    );
  }
  updateAssignAngularModule(reqJson) {
    //this.shareService.loading++;
    this.ProcomparetoolService.updateTxnModuleOwnrAngular(reqJson).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          //this.shareService.loading--;
          success(response.message);
          this.saveButtonDisplay = true;
          this.updateButtonDisplay = false;
          this.ModuleOwnerForm.reset();
        }
        else if (response["status"] == 500) {
          //this.shareService.loading--;
          alerts(response.message)
        } else {
        }
      }, error => {
        //this.shareService.loading--;
        alerts("Error While Fetching")
      }
    );
  }
  getByIdModule(moduleownrId) {
    if (moduleownrId) {
      this.ProcomparetoolService.getByIdData(moduleownrId).subscribe(
        (response: any) => {
          if (response['status'] == 200) {
            this.getByIdData = response["result"][0]
            this.ModuleOwnerForm.patchValue(this.getByIdData);
            this.onOpChangeTypeById(this.getByIdData);
          }
        }, error => {
          //this.shareService.loading--;
          alerts("Error While Fetching")
        }
      );
    } else {
      alerts("Please Select Project Name")
    }
  }
  // ============================================Grid Calling=====================================
  getOwnerListGrid(rowsData) {
    const sourceDiv = document.getElementById("getOwnerListGridId");
    const columns = [
      {
        header: "Sr.No",
        field: "sno",
        "editable": false,
        width: "50px",
        "align": "center",
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Project Name",
        field: "projectName",
        filter: true,
        width: "250px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()"
      },
      {
        header: "Type",
        field: "mtype",
        filter: true,
        width: "100px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "Module Name",
        field: "moduleName",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "Owner Name",
        field: "ownerName",
        filter: true,
        width: "200px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "From date",
        field: "moduleownrFromdt",
        filter: true,
        width: "100px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
      {
        header: "To date",
        field: "moduleownrTodt",
        filter: true,
        width: "100px",
        "editable": false,
        "text-align": "center",
        search: true,
        "ng-dblclick": "dblClickSection()",

      },
    ];
    var self = this;


    let components = {
      "descriptionComp": new SagInputText({}, function () {
      }),
    };



    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.onRowSelectGrid(event);
          },
          "onRowDbleClick": function () {
            self.onSelectedRowDoubleClick(event);

          }
        }
      };
      this.gridDynamicOwnerList = SagGridMPT(sourceDiv, gridData, true, true);
      this.setColorOnApiGrid();
    }
  }
  onRowSelectGrid(event: Event) {
  }
  setColorOnApiGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicOwnerList.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      // change Row Color
      if (ele.ownerName || ele.moduleName || ele.projectName) {
        self.gridDynamicOwnerList.setColRowProperty(index, 'ownerName', { "background": "#fff8e1" });
        self.gridDynamicOwnerList.setColRowProperty(index, 'moduleName', { "background": "#f8d7da" });
        self.gridDynamicOwnerList.setColRowProperty(index, 'projectName', { "background": "#fff8e1" });
        //self.gridDynamicJavaApiList.setColRowProperty(index, 'CreatedBy',{ "background": "#43ac6a" });
      }

      ;
    });

  }
  onSelectedRowDoubleClick(event: Event) {
    $('[href="#ModuleOwner"]').tab('show');
    this.updateButtonDisplay = true;
    this.saveButtonDisplay = false;
    const selectedOwnerData = this.gridDynamicOwnerList.getSeletedRowData();
    this.ModuleOwnerForm.controls["moduleownrId"].setValue(selectedOwnerData.moduleownrId);
    this.getByIdModule(selectedOwnerData.moduleownrId);



  }

}
