import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ModuleOwnerComponent } from './module-owner.component';


const routes: Routes = [{
  path:"",
  component:ModuleOwnerComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ModuleOwnerRoutingModule { }
