import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModuleOwnerRoutingModule } from './module-owner-routing.module';
import { ModuleOwnerComponent } from './module-owner.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { CalendarModule } from 'primeng/calendar';


@NgModule({
  declarations: [ModuleOwnerComponent],
  imports: [
    CommonModule,
    ModuleOwnerRoutingModule,
    DropdownModule,
    ReactiveFormsModule,
    CalendarModule,
    FormsModule,
  
  ],exports:[ModuleOwnerComponent]
})
export class ModuleOwnerModule { }
