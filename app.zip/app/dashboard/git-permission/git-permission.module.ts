import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GitPermissionRoutingModule } from './git-permission-routing.module';
import { GitPermissionComponent } from './git-permission.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'primeng/primeng';

import {DropdownModule} from 'primeng/dropdown';

@NgModule({
  declarations: [GitPermissionComponent],
  imports: [
    CommonModule,
    GitPermissionRoutingModule,
    ReactiveFormsModule,
    SharedModule,
    DropdownModule
  ],
  exports:[GitPermissionComponent]
})
export class GitPermissionModule { }
