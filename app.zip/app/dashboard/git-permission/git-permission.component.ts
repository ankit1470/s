/**
 * @author P A N K A J   S I N G H
 * @var  Project ---permission || project Rights
 */

import { Component, OnInit } from '@angular/core';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { FormGroup, FormsModule, FormControl, FormBuilder, Validators } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { SagShareService } from 'src/app/services/sagshare.service';
declare function alerts(m): any;
declare function success(m): any;
@Component({
  selector: 'app-git-permission',
  templateUrl: './git-permission.component.html',
  styleUrls: ['./git-permission.component.scss']
})
export class GitPermissionComponent implements OnInit {
  projectLists = [];
  userLists: any;
  gitPermissionForm: any
  rolePermissions = [{
    "label": "Guest",
    "value": "Guest"
  }, {
    "label": "Reporter",
    "value": "Reporter"
  }, {
    "label": "Developer",
    "value": "Developer"
  }, {
    "label": "Maintainer",
    "value": "Maintainer"
  }]
  constructor(private dbcomparetoolService: ProcomparetoolService,
    private shareService: SagShareService,
    private formBuilder: FormBuilder) {

  }

  ngOnInit() {
    this.initgitPermissionForm();
    this.getProjectAndUserList();

  }

  initgitPermissionForm() {
    this.gitPermissionForm = this.formBuilder.group({
      projectName: [null, Validators.required],
      userName: [null, Validators.required],
      rolePermission: [null, Validators.required]
    });
  }
  submitSvnGitProject() {
    const _UserDetails = this.userLists.find(_itm => _itm.label == this.gitPermissionForm.value.userName)
    const _prjDetails = this.projectLists.find(_itm => _itm.label == this.gitPermissionForm.value.projectName)
    if (this.gitPermissionForm.valid) {
      let gitReqObj = {
        "projectName": this.gitPermissionForm.value.projectName,
        "userName": this.gitPermissionForm.value.userName,
        "accessLevel": this.gitPermissionForm.value.rolePermission,
        "sdmtUserId": parseInt(_UserDetails['usrId']),
        "sdmtProjectId": _prjDetails['sdmtProjectId']
      };
      let svnReqObj = {
        repoName: this.gitPermissionForm.value.projectName,
        username: this.gitPermissionForm.value.userName,
        accessType: this.gitPermissionForm.value.rolePermission
      };
      let forkJoinArray = [];
      forkJoinArray.push(this.dbcomparetoolService.saveGitPermissionData(gitReqObj));
      forkJoinArray.push(this.dbcomparetoolService.saveSvnPermissionData(svnReqObj));
      forkJoin(forkJoinArray).subscribe(
        (response) => {
          this.gitPermissionForm.reset();
          if (response[0]['status'] == 200) {
            success(response[0]['message']);
          }
          if (response[0]['status'] == 401) {
            alerts(response[0]['message']);
          }
          else if (response[0]['status'] == 500) {
            alerts(response[0]['message'])
          }

          // if (response[1]['status'] == 200) {
          //   success(response[1]['message']);
          // }
          // else if (response[1]['status'] == 500) {
          //   alerts(response[1]['message'])
          // }
          //this.shareService.loading--;


        }
        , error => {
          //this.shareService.loading--;
          alerts("Error While ")
        }
      );
    } else if (this.gitPermissionForm.invalid) {
      alerts("Please fill the form")
    }
  }
  getProjectAndUserList() {

    let forkJoinArray = [];
    forkJoinArray.push(this.dbcomparetoolService.getProjectListGitPermission());
    forkJoinArray.push(this.dbcomparetoolService.getUserListGitPermission());
    forkJoin(forkJoinArray).subscribe(
      (response) => {
        //this.projectLists = response[0].getGitLabProjetList;
        this.projectLists = response[0].getGitLabProjetList.map(item => {
          let newItem = item;
          newItem['label'] = item.projectName,
            newItem['value'] = item.projectName
          return newItem
        })
        this.userLists = response[1].usersList.map(item => {
          let newItem = item;
          newItem['label'] = item.usrCode,
            newItem['value'] = item.usrCode
          return newItem
        })




      }, error => {

        alerts("Error While ")
      }
    );
  }
}
