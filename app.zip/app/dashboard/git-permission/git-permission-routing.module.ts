import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GitPermissionComponent } from './git-permission.component';


const routes: Routes = [
  {
    path:"",
    component:GitPermissionComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GitPermissionRoutingModule { }
