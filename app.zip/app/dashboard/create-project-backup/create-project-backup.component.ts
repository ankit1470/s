import { Component, OnInit, OnDestroy } from '@angular/core';
 
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
 
import { SagShareService } from 'src/app/services/sagshare.service';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/primeng';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
 
 


declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-create-project-backup',
  templateUrl: './create-project-backup.component.html',
  styleUrls: ['./create-project-backup.component.scss']
})
export class CreateProjectBackupComponent implements OnInit,OnDestroy {
 
  projectType = "java";

  constructor(public shareService: SagShareService,
    public dialogService: DialogService,
    private service: AutoJavacodeService,
    private formbuilder: FormBuilder,
    public config: DynamicDialogConfig,
    public modalRef: DynamicDialogRef) { }

  ngOnInit() {
    this.getProjectBackupList(this.projectType);
    this.projectSecurityGridForModal([]);
  }

  ngOnDestroy(): void {
    throw new Error("Method not implemented.");
  }


  getProjectBackupList(projectType){
    let selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
   
    let projectPath = "java" == projectType ? selectedProjectChooseData.jwspace  : selectedProjectChooseData.awspace  

    let reqObj = {
      "projectPath": projectPath
    }


    this.service.getProjectBackupList(reqObj).subscribe(res => {
     if(res && res['status'] == 200){
         this.projectSecurityGridForModal(res['data']);
      }else{
        this.projectSecurityGridForModal([]); 
        alerts(res["msg"])
      }
    
   })
  }

  createProjectBackup(){
  let gridData =   this.gridDynamicObj_projectBackupGrid.getGridData();

  if(gridData && gridData.length >=3){
    alerts("You have already created 3 backups. The maximum allowed is 3 backups. Please delete an existing backup if you wish to create a new one");
    return
  }

    let selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    let projectPath = "java" == this.projectType ? selectedProjectChooseData.jwspace  : selectedProjectChooseData.awspace  

    let reqObj = {
      "projectPath": projectPath
    }
    
    this.service.createProjectBackup(reqObj).subscribe(res => {
      if(res && res['status'] == 200){
        this.getProjectBackupList(this.projectType);
       } else {
         alerts(res["msg"])
       }
     
    })

  }

  deleteBackup(params){
    let selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");

    let projectPath = "java" == this.projectType ? selectedProjectChooseData.jwspace  : selectedProjectChooseData.awspace  

    let rowValue = params.rowValue;

    let reqObj = {
      "projectPath":projectPath,
      "backupFileName": rowValue.backupName
    }
    this.service.deleteProjectBackup(reqObj).subscribe(res => {
      if(res && res['status'] == 200){
        this.getProjectBackupList(this.projectType);
       }else{
         alerts(res["msg"])
       }
     
    })

  }


   validationprojectsecuritygrid: any = {}
   gridDynamicObj_projectBackupGrid:any
   gridData_projectBackupGrid: any;
   columnData_projectBackupGrid: any = [
     {
       "hidden": false,
       "editable": "false",
       "filter": true,
       "search": true,
       "component": "label",
       "field": "sno",
       "freezecol": "null",
       "width": "50px",
       "header": "S.No",
       "text-align": "left",
 
     },
      
     {
       "header": "File Name",
       "field": "backupName",
       "filter": true,
       "width": "350px",
       "editable": "false",
       "text-align": "left",
       "search": true,
       "component": "label",
       "cellRenderView": false,
       "freezecol": "null",
       "hidden": false,
       "sort": false,
       "cellHover": false
     },
     {
       "header": "Last Modified",
       "field": "lastModifiedDate",
       "filter": true,
       "width": "150px",
       "editable": "false",
       "text-align": "left",
       "search": true,
       "component": "label",
       "cellRenderView": false,
       "freezecol": "null",
       "hidden": false,
       "sort": false,
       "cellHover": false,
     },
     {
      "header": "Action",
      "field": "delete",
      "filter": false,
      "width": "80px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "buttonIcon",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "imgsrc": "", "iconclass": "fas fa-trash", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-danger"], "attribute": "", "styles": "" },
    },
     
   ];
 
 
    projectSecurityGridForModal(rowData?: any, colData?: any) {
      let self = this;

     this.gridData_projectBackupGrid = {
       columnDef: colData ? colData : this.columnData_projectBackupGrid,
       rowDef: rowData ? rowData : [],
       footer_hide: true,
       totalNoOfRecord_hide: true,
       sml_expandGrid_hide: true,
       exportXlsxPage_hide: true,
       exportXlsxAllPage_hide: true,
       exportPDFLandscape_hide: true,
       exportPDFPortrait_hide: true,
       ariaHidden_hide: true,
       disableAllSearch: true,
       wordBreak: false,
       wordBreakHeader: false,
       cellHover: false,
       rowHover: false,
       rowBorder_hide: false,
       columnBorder_hide: false,
       header_hide: false,
       gridbody_hide: false,
       rowLineSpace: 0,
       multiHeader: false,
       common_search: false,
       common_search_column: "",
       common_filter: false,
       common_filter_column: "",
       validation: this.validationprojectsecuritygrid,
       newPagination: false,
       recordPerPage: 10,
       newExpandExportTotalRecord_hide: undefined,
       ellipsisV: {},
       gridCustomButtonsArr: "",
       cellCustomPadding: NaN,
       sml_expandGrid_position: "bottom",
       totalNoOfRecord_position: "bottom",
       toggleViewButton: false,
       gridConfigrationBtn: false,
       rowAutoSelection: false,
       gridRowAddDeleteButton: false,
       components: {},
       callBack: {
        "onButtonIcon_delete": function (ele, params) {
          self.deleteBackup(params)
       },
       },
 
       rowCustomHeight: 20,
       plusButton_obj: {},
     };
 
     let sourceDiv = document.getElementById("projectBackupGridId");
     this.gridDynamicObj_projectBackupGrid = SdmtGridT(sourceDiv, this.gridData_projectBackupGrid, true, true);
   }

   onClose() {
    this.modalRef.close();
    this.ngOnDestroy();
   }

}
