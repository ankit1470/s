import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UpdateJavaBaseProjectRoutingModule } from './update-java-base-project-routing.module';
import { UpdateJavaBaseProjectComponent } from './update-java-base-project.component';
import { EditorDiffChangeModule } from 'src/app/modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-diff-change/editor-diff-change.module';


@NgModule({
  declarations: [UpdateJavaBaseProjectComponent],
  imports: [
    CommonModule,
    UpdateJavaBaseProjectRoutingModule,
    EditorDiffChangeModule
    
  ],
  exports:[UpdateJavaBaseProjectComponent]
})
export class UpdateJavaBaseProjectModule { }
