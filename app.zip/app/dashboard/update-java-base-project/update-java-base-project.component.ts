import { Component, OnInit, } from '@angular/core';
import { DialogService } from 'primeng/primeng';
import { EditorDiffChangeComponent } from 'src/app/modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-diff-change/editor-diff-change.component';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-update-java-base-project',
  templateUrl: './update-java-base-project.component.html',
  styleUrls: ['./update-java-base-project.component.scss']
})
export class UpdateJavaBaseProjectComponent implements OnInit {
  gridDynamicObj_UpdateJavaBasePro: any;
  gridData_UpdateJavaBasePro: any;
  butt: string = ""
  subBtn: string = "";
  resList: any = [];
  updateAvailable:any=[];
  key: string = "";
  openHtmlFlag: boolean;
  compareToolDisplay: boolean;
  cdRef: any;
  modelType: string;

  constructor(public shareService: SagShareService,
    public dialogService: DialogService,
    private ProCompareToolService: ProcomparetoolService,

  ) {

  }

  ngOnInit() {
    this.UpdateJavaBaseProGrid();
    this.getJavaBaseFileStatus();

  }
  getJavaFileData(data) {
    //this.butt = data;
    this.key = data;
    switch (data) {
      case "common":
        this.butt = data;
        //this.subBtn = data;
        this.subBtn = "";
        this.UpdateJavaBaseProGrid([]);
        break;
      case "configuration":
        this.butt = data;
        this.UpdateJavaBaseProGrid(this.resList["app_config"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              label:"Update Available",
              iconclass: "fa fa-exclamation-circle text-success"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "context":
        this.butt = data;
        this.UpdateJavaBaseProGrid(this.resList["context_bean"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              label:"Update Available",
              iconclass: "fa fa-exclamation-circle text-success"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "dbScript":
        this.butt = data;
        this.UpdateJavaBaseProGrid(this.resList["dbscript"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              label:"Update Available",
              iconclass: "fa fa-exclamation-circle text-success"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "mainApp":
        this.butt = data;
        this.UpdateJavaBaseProGrid(this.resList["main_app"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              label:"Update Available",
              iconclass: "fa fa-exclamation-circle text-success"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "advice":

        this.subBtn = data;
        this.butt = "common";
        this.UpdateJavaBaseProGrid(this.resList["common-advice"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              label:"Update Available",
              iconclass: "fa fa-exclamation-circle text-success"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "controller":
        this.subBtn = data;
        this.butt = "common";
        this.UpdateJavaBaseProGrid(this.resList["common-controller"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              iconclass: "fa fa-exclamation-circle text-success",
              label:"Update Available"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "exception":
        this.subBtn = data;
        this.butt = "common";
        this.UpdateJavaBaseProGrid(this.resList["common-exception"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              iconclass: "fa fa-exclamation-circle text-success",
              label:"Update Available"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "mail":
        this.subBtn = data;
        this.butt = "common";
        this.UpdateJavaBaseProGrid(this.resList["common-mail"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              iconclass: "fa fa-exclamation-circle text-success",
              label:"Update Available"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "service":
        this.subBtn = data;
        this.butt = "common";
        this.UpdateJavaBaseProGrid(this.resList["common-service"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              iconclass: "fa fa-exclamation-circle text-success",
              label:"Update Available"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "util":
        this.subBtn = data;
        this.butt = "common";
        this.UpdateJavaBaseProGrid(this.resList["common-util"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              iconclass: "fa fa-exclamation-circle text-success",
              label:"Update Available"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      case "validation":
        this.subBtn = data;
        this.butt = "common";
        this.UpdateJavaBaseProGrid(this.resList["common-validation"].map((ele) => {
          let obj = JSON.parse(JSON.stringify(ele));
          if (ele["status"] == "Update Available") {
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
            obj['status']={
              iconclass: "fa fa-exclamation-circle text-success",
              label:"Update Available"
            }
          }
          // else if(ele["status"] == "New"){
          //   obj["action"] = "Add";
          //   obj["dynamicCompName_action"] = 'button';
          //   obj["dynamicCompCellRenderView_action"] = true;
          // }
          else {
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = false;
            obj['status']={
              label:ele['status']
            }
          }
          return obj;
        }));
        break;
      default:

        break;
    }
  }
  getCommonFileData(data) {
    this.subBtn = data;
  }


  columnData_UpdateJavaBasePro: any = [
    {
      "header": "S.No",
      "field": "sno",
      "width": "50px",
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "freezecol": "null",
      "text-align": "center"
    },
    {
      "header": "File Name",
      "field": "fileName",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Package Name",
      "field": "packageName",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Tech Version",
      "field": "techVersion",
      "filter": true,
      "width": "120px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Status",
      "field": "status",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      
    },
    {
      "header": "Action",
      "field": "action",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "dynamicComponent",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "", "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },
    },
    {
      "header": "Compare",
      "field": "compare",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Compare", "classes": ["btn", "btn-info", "w-70"], "attribute": "", "styles": "" },

    },

  ];
  rowData_UpdateJavaBasePro: any = [

  ];
  validation: any = {}

  UpdateJavaBaseProGrid(rowData?, colData?) {
    let self = this;
    let mobileWebItem = ""
    this.gridData_UpdateJavaBasePro = {
      columnDef: colData ? colData : this.columnData_UpdateJavaBasePro,
      rowDef: rowData ? rowData : this.rowData_UpdateJavaBasePro,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validation,
      newPagination: false,
      recordPerPage: 10,
      exportBtn: (mobileWebItem == 'mobile') ? false : false,
      newExpandExportTotalRecord_hide: undefined,
      commonSearchSelect_hide: (mobileWebItem == 'mobile') ? false : false,
      commonFilterSelect_hide: (mobileWebItem == 'mobile') ? false : false,
      orderArray: (mobileWebItem == 'mobile') ? ["sno", "fileName", "packageName", "status", "action", "compare"] : ["sno", "fileName", "packageName", "techVersion" ,"status" ,"action", "compare"],
      ellipsisV: {},
      gridRowAddDeleteButton: "undefined",

      components: {},
      callBack: {
        "onButton_action": function (ele, params) {
          self.updateBaseFile(params.rowValue);

        },
        "onButton_compare": function (ele, params) {
          self.compareBasefile(params.rowValue);

        },
        "onCellClick": function (ele) {

          //self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          // self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          // self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("UpdateJavaBaseProGridId");
    if (sourceDiv != null) {
      this.gridDynamicObj_UpdateJavaBasePro = SdmtGridT(sourceDiv, this.gridData_UpdateJavaBasePro, true, true);
      return this.gridDynamicObj_UpdateJavaBasePro;

    }
  }




  updateBaseFile(rowData) {

    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");

    let postData =
    {
      "projectName": __project_Details.projectname,
      "projectPath": __project_Details.jwspace,
      "projectId": __project_Details.projectId,
      "userId": __project_Details.userId,
      "fileName": rowData.fileName,
      "key": rowData.key,
      "checksumId": rowData.checksumId,
      "status": rowData.status,
      "srcFileId": rowData.srcFileId
    }

    this.ProCompareToolService.updateJavaBaseFile(postData).subscribe(async (res) => {
      if (res["status"] == 200) {
        success(res["message"]);
        await this.getJavaBaseFileStatus();
        this.getJavaFileData(this.key);

      } else {
        alerts(res["message"]);
      }
    });
  }

  compareBasefile(rowData) {

    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");

    let postData =
    {
      "projectName": __project_Details.projectname,
      "projectPath": __project_Details.jwspace,
      "projectId": __project_Details.projectId,
      "fileName": rowData.fileName,
      "key": rowData.key,
    }


    this.ProCompareToolService.compareJavaBaseFile(postData).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          this.shareService.setDataprotool("leftSideCode", response["data"]["main"]);
          this.shareService.setDataprotool("rightSideCode", response["data"]["local"]);
          this.shareService.setDataprotool("leftSideCodeFile", response.currentRivison);
          this.shareService.setDataprotool("rightSideCodeFile", response.preRivison);
          this.shareService.setDataprotool("filePathEditorDiff", {
            path: response["data"]['localFilePath'],
            projectpath: undefined
          });

          this.modelType = 'UpdateJavaBaseProjectComponent'
          this.openHtmlFlag = false;
          this.compareToolDisplay = true;
          this.compareToolDisplay ? $("#CompareToolforUpdateJavaBaseProject").modal('show') : false;
        }
        else if (response['status'] == 500) {
          alerts(response['message']);
        }
        else {
          alerts(response['message']);
        }
      }
    );
  }

  updateAllBaseFile() {

    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");

    let postData =
    {
      "userId": __project_Details.userId,
      "projectPath": __project_Details.jwspace,
      "projectId": __project_Details.projectId,
      "data": {"files" : this.resList} 
    }

    this.ProCompareToolService.updateAllBaseFile(postData).subscribe(res => {
      if (res['status'] == 200) {
        success(res['message']);
        this.getJavaBaseFileStatus();
        this.UpdateJavaBaseProGrid();
        this.updateAvailable=[];
      }else{
        alerts(res['message']);
      }
    
      
  });
  }

  async getJavaBaseFileStatus() {
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    let postObj = {
      "projectId": __project_Details.projectId,
      "projectPath": __project_Details.jwspace,
      "userId": __project_Details.userId,
      "projectName": __project_Details.projectname,
    };

      let res = await this.ProCompareToolService.getJavaBaseFileStatus(postObj).toPromise();

      this.resList = res['data'];

      this.UpdateJavaBaseProGrid(res['data'].map((ele, ind) => {
       
        let obj = ele;

        obj['sno'] = ele['sno'];
        obj['fileName'] = ele['fileName'];
        obj['packageName'] = ele['packageName'];
        obj['techVersion'] = ele['techVersion'];
        // obj['compare'] = ele['ind_ctperson'];
        obj['status']=ele['status']

        if( obj['status'] == "Update Available"){
            obj["dynamicCompName_action"] = 'button';
            obj["action"] = "Update";
            obj["dynamicCompCellRenderView_action"] = true;
          //   obj['action']={
          //   label:"Update Available",
          //   iconclass: "fa fa-exclamation-circle text-success"
          // }
        }else{
            obj["action"] = "";
            obj["dynamicCompName_action"] = 'label';
            obj["dynamicCompCellRenderView_action"] = true;
        //     obj['action']={
        //       label:ele['status']
        // }
        }


        return obj;
  }));


  }
}
