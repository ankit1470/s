import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/primeng';
import { SagShareService } from 'src/app/services/sagshare.service';

@Component({
  selector: 'app-copy-content',
  templateUrl: './copy-content.component.html',
  styleUrls: ['./copy-content.component.scss'],
  
})
export class CopyContentComponent implements OnInit {
  projectInfo: any;
  projectLagData :any;
  getAllFileData:any;
  checkedURL=false
  selectedURLs: any[]=[]
  sitemap=false
  domainName:string
  selectAll=false
  constructor(
    private fb:FormBuilder,
    public ref: DynamicDialogRef, 
    public config: DynamicDialogConfig,
    private shareService: SagShareService,
    public modalRef: DynamicDialogRef,
    ) { 
      
    }

  ngOnInit() {
    this.domainName=this.config.data.domainName;
    this.sitemap=this.config.data.isSitemap;
    this.projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    if(!this.sitemap)this.getProjectText()
  }
  getProjectText(){
    debugger
    let dataJson = {
      projectPath: this.projectInfo.awspace+'/src/assets/i18n/en.json'
    }
    this.shareService.getPrjConfObject(dataJson).subscribe((res) => {
      if (res['status'] == 'success') {
        this.projectLagData = res['confobj']
      }
    });
  }
  convertToJsonObject:any;
  getFileMethod(){
    // content not fixed yet so changes require according to need
    this.convertToJsonObject = JSON.parse(this.getAllFileData)
    const file = new Blob(([this.getAllFileData]), { type: "application/json" });
    
    // let projectPath = this.projectInfo.awspace.replace(this.projectInfo.projectname,this.config.data.projectName.projectname);
    let projectPath = (this.config.data.projectName.awspace != null) ? this.config.data.projectName.awspace+'/'+this.config.data.projectName.projectname : '';
    let projectId = this.projectInfo.projectId;
    let oldProjectName = this.projectInfo.projectname;
    const copyDataOnServerData = new FormData();
    copyDataOnServerData.append('file', file);
    copyDataOnServerData.append('projectPath', projectPath);
    copyDataOnServerData.append('projectId', this.config.data.projectName.projectId);
    copyDataOnServerData.append('oldProjectName', oldProjectName);
    this.shareService.setCopyContent(copyDataOnServerData).subscribe(res=>{
      res
    })
  }
  
  showPreviewFile(event){
    this.getAllFileData = '';
    debugger
      let fr=new FileReader();
      fr.onload = () =>{
       this.getAllFileData=fr.result;
      };
      fr.readAsText(event.target.files[0]);
   debugger
  }
  closeModel() {
    this.modalRef.close(true);
  }

  onChange(url:string, isChecked: boolean,index:number) {
    if(isChecked) {
      let domianURL=Array.isArray(url)?url['LOC'][0]:url['LOC']
      if(this.domainName.length>0) {
        let concatDomainName =JSON.parse(JSON.stringify(url))
         concatDomainName['LOC'] = this.domainName+'/'+domianURL
        this.selectedURLs.push(concatDomainName);
      }else  this.selectedURLs.push(url);
    } else {
      this.selectedURLs.splice(index,1);
    }
}

  selectAllURL(url) {
    if (this.domainName.length > 0) {
      this.selectedURLs = url.map(ele => ({
        ...ele,
        LOC: this.domainName + '/' + ele.LOC
    }));     
    } else {
      this.selectedURLs=[...url]
    }
}

  saveSiteMapURL(){
    this.sitemap=false
    this.modalRef.close(this.selectedURLs) 
  }
}
