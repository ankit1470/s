import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CopyContentRoutingModule } from './copy-content-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CopyContentRoutingModule
  ]
})
export class CopyContentModule { }
