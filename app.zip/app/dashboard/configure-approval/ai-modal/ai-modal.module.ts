import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DndModule } from 'ngx-drag-drop';
import { AiModalRoutingModule } from './ai-modal-routing.module';
import { SharedModule } from 'src/app/core/shared/shared.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AiModalRoutingModule,
    SharedModule,
    DndModule
  ]
})
export class AiModalModule { }
