import { Component, OnInit } from '@angular/core';
import { SagShareService } from 'src/app/services/sagshare.service';
import { DndDropEvent } from 'ngx-drag-drop';
import { ToastService } from 'src/app/core/services/toast.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var ButtonComponent;

interface TableRow { 
  operation: string;
  modal: string;
  temperature: string; 
  apiKey: string
}

@Component({
  host: { class: 'd-flex flex-column h-100' },
  selector: 'app-ai-modal',
  templateUrl: './ai-modal.component.html',
  styleUrls: ['./ai-modal.component.scss']
})
export class AiModalComponent implements OnInit {

  items: TableRow[] = [
    { operation: 'Op1', modal: 'Modal1', temperature: 'Temp1', apiKey: 'Key1' },
    { operation: 'Op2', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key2' },
    { operation: 'Op3', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key3' },
    { operation: 'Op4', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key4' },
    { operation: 'Op5', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key5' },
    { operation: 'Op6', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key6' },
    { operation: 'Op7', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key7' },
    { operation: 'Op8', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key8' },
    { operation: 'Op9', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key9' },
    { operation: 'Op10', modal: 'Modal2', temperature: 'Temp2', apiKey: 'Key10' },
  ]
  modalListForSet:any=[]
  mode:any
  hideShowTabs:boolean;
  modalOptList:any=[];
  modalOperationList:any=[]
  gridRowObj:any={}
  options: any[];
  gridData_totalActOpt: any;
  gridDynamicObj_totalActOpt: any;
  gridData_metaGrid1: any;
  gridDynamicObj_metaGrid1: any;
  constructor(private _shareService: SagShareService,public toast: ToastService,public studioDragDropService :CommonStudioDragDropService ) { 
 
  this.options = [
  {label:'gemma2-9b-it',value:'gemma2-9b-it'},
  {label:'gemma-7b-it',value:'gemma-7b-it'},
  {label:'llama3-8b-8192',value:'llama3-8b-8192'},
  {label:'llama3-70b-8192',value:'llama3-70b-8192'},
  {label:'llama-3.1-8b-instant',value:'llama-3.1-8b-instant'},
  {label:'llama-3.3-70b-versatile',value:'llama-3.3-70b-versatile'},
  {label:'mixtral-8x7b-32768',value:'mixtral-8x7b-32768'},
  {label:'llama-3.2-1b-preview',value:'llama-3.2-1b-preview'},
  {label:'llama-3.2-90b-vision-preview',value:'llama-3.2-90b-vision-preview'},
  {label:'llama-3.2-11b-vision-preview',value:'llama-3.2-11b-vision-preview'},
  {label:'llama-3.2-3b-preview',value:'llama-3.2-3b-preview'},
  {label:'llama-3.2-1b-preview',value:'llama-3.2-1b-preview'},
  {label:'llama-3.1-70b-specdec',value:'llama-3.1-70b-specdec'},
  {label:'llama-3.3-70b-specdec',value:'llama-3.3-70b-specdec'},
  {label:'Stable-diffusion-xl-base-1.0',value:'Stable-diffusion-xl-base-1.0'},
  {label:'Salesforce blip-image-captioning-large',value:'Salesforce blip-image-captioning-large'}
  ];

  

}

  async ngOnInit() {
    this.gridRowObj['metaOperation'] = "select";
   
    // this.getPrjAiModelOpt()
    await this.getTotalActOpt();
    if(this.gridRowObj['metaOperation'] == 'select'){
      this.rowData_metaGrid1 = []
      this.gridRowObj['modal'] = []
      this.modalOperationList['modals'] = []
    }
    // else{
    // }
    await this.getmodelOperationList()

  }


  columnData_totalActOpt: any = [
    {
      hidden: false,
      editable: "false",
      filter: false,
      search: true,
      component: "label",
      field: "sno",
      freezecol: "left",
      width: "50px",
      header: "S.No",
      "text-align": "center",
    },
    {
      header: "AI Operation",
      field: "operation",
      filter: false,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: false,
      component: "label",
      cellRenderView: true,
      freezecol: "left",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Default Modal",
      field: "modelName",
      filter: false,
      width: "300px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "left",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Modal Active",
      field: "modalList",
      filter: false,
      width: "300px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "iconLabel",
      cellRenderView: false,
      freezecol: "left",
      hidden: false,
      sort: false,
      cellHover: false,
    },

    {"header":"Action",
      "field":"action",
      "filter":false,
      "width":"200px",
      "editable":"false",
      "text-align":"left",
      "search":true,
      "component":"dynamicComponent",
      "cellRenderView":true,
      "freezecol":"null",
      "hidden":false,
      "sort":false,
      "cellHover":false,
      "button":{"imgsrc":"","iconclass":"","iconPosition":"","name":"Edit","classes":["btn","btn-outline-primary"],"attribute":"","styles":" color: #fff; ,background-color: #5cb85c !important; , border-color: #4cae4c !important;"},     
      }, 

  ];
 rowData_totalActOpt:any =[];
  totalActOpt(colData?: any, rowData?: any) {
    let self = this;

    this.gridData_totalActOpt = {
      columnDef: colData ? colData : this.columnData_totalActOpt,
      rowDef: rowData ? rowData : this.rowData_totalActOpt,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,
      components: {},
        callBack: {
        "onDynamicButton_action": function (ele, param) {
          self.open(param,'Set')
        },
        "onButtonIcon_action": function (ele, param) {

          self.open(param,'Edit')
        },
        onCellClick: function (ele) {
        },
        onRowClick: function () {
        },
        onRowDbleClick: function () {
        }
      },
      rowCustomHeight: 20
    }
    if(self.gridData_totalActOpt && self.gridData_totalActOpt['rowDef'].length > 0)
    for (let ind = 0; ind < self.gridData_totalActOpt['rowDef'].length; ind++) {
      const element = self.gridData_totalActOpt['rowDef'][ind];
      if(element['defmodal'] == 1){
        element['action'] = 'disable';
        element['dynamicCompName_action'] = 'buttonIcon';
      }else{
        element['dynamicCompName_action'] = 'dynamicButton';
        element['action'] = 'Set';
      }
      element['dynamicCompCellRenderView_action'] = true;
    }
    let sourceDiv = document.getElementById("seoMetaGrid1");
    if (sourceDiv != null) {
      this.gridDynamicObj_totalActOpt = SdmtGridT(sourceDiv, this.gridData_totalActOpt, true, true);
    }
  }



  // columnData_metaGrid1: any = [
  //   {
  //     hidden: false,
  //     editable: "false",
  //     filter: false,
  //     search: true,
  //     component: "label",
  //     field: "sno",
  //     freezecol: "left",
  //     width: "50px",
  //     header: "S.No",
  //     "text-align": "center",
  //   },
  //   {
  //     header: "Operation",
  //     field: "optName",
  //     filter: false,
  //     width: "140px",
  //     editable: "false",
  //     "text-align": "left",
  //     search: true,
  //     component: "label",
  //     cellRenderView: false,
  //     freezecol: "left",
  //     hidden: false,
  //     sort: false,
  //     cellHover: false,
  //   },

  //   {
  //     header: "Modal",
  //     field: "modelName",
  //     filter: false,
  //     width: "300px",
  //     editable: "false",
  //     "text-align": "left",
  //     search: true,
  //     component: "label",
  //     cellRenderView: false,
  //     freezecol: "left",
  //     hidden: false,
  //     sort: false,
  //     cellHover: false,
  //   },
  //   {
  //     header: "Default Modal",
  //     field: "defmodal",
  //     filter: false,
  //     width: "200px",
  //     editable: "false",
  //     "text-align": "left",
  //     search: false,
  //     component: "checkbox",
  //     properties:{selection:"single"},
  //     cellRenderView: true,
  //     freezecol: "left",
  //     hidden: false,
  //     sort: false,
  //     cellHover: false,
  //   },

  //   {
  //     header: "Temperature",
  //     field: "temperature",
  //     filter: false,
  //     width: "100px",
  //     editable: "false",
  //     "text-align": "left",
  //     search: true,
  //     component: "text",
  //     cellRenderView: false,
  //     freezecol: "null",
  //     hidden: false,
  //     sort: false,
  //     cellHover: false,
  //   },
  //   {
  //     header: "Api Key",
  //     field: "apikey",
  //     filter: false,
  //     width: "150px",
  //     editable: "false",
  //     "text-align": "left",
  //     search: true,
  //     component: "text",
  //     cellRenderView: false,
  //     freezecol: "null",
  //     hidden: false,
  //     sort: false,
  //     cellHover: false,
  //   },
  //   {
  //     "header": "Delete",
  //     "field": "delete",
  //     "filter": false,
  //     "width": "100px",
  //     "editable": "false",
  //     "text-align": "left",
  //     "search": false,
  //     "component": "rowDelete",
  //     "cellRenderView": true,
  //     "freezecol": "null",
  //     "hidden": false, 
  //     "sort": false,
  //     "cellHover": false,
  //   } 
   
  // ];
 rowData_metaGrid1:any =[];
  // metaGrid1(colData?: any, rowData?: any) {
  //   let self = this;

  //   this.gridData_metaGrid1 = {
  //     columnDef: colData ? colData : this.columnData_metaGrid1,
  //     rowDef: rowData ? rowData : this.rowData_metaGrid1,
  //     footer_hide: true,
  //     totalNoOfRecord_hide: false,
  //     sml_expandGrid_hide: false,
  //     exportXlsxPage_hide: false,
  //     exportXlsxAllPage_hide: false,
  //     exportPDFLandscape_hide: false,
  //     exportPDFPortrait_hide: false,
  //     ariaHidden_hide: false,
  //     disableAllSearch: false,
  //     wordBreak: false,
  //     wordBreakHeader: false,
  //     cellHover: false,
  //     rowHover: false,
  //     rowBorder_hide: false,
  //     columnBorder_hide: false,
  //     header_hide: false,
  //     common_search: false,
  //     common_search_column: "",
  //     gridbody_hide: false,
  //     rowLineSpace: 0,
  //     components: {},
  //     callBack: {
  //       "onRowDelete_delete": function (ele: any, param: any) {
  //         self.rowData_metaGrid1.splice(param.rowIndex, 1);
  //         // success("Deleted Successfully!");
  //         self.metaGrid1()
  //       }
  //     },
  //     rowCustomHeight: 20
  //   }

  //   let sourceDiv = document.getElementById("seoMetaGrid2");
  //   if (sourceDiv != null) {
  //     this.gridDynamicObj_metaGrid1 = SdmtGridT(sourceDiv, this.gridData_metaGrid1, true, true);
    
  //   }
  // }


  getmodelOperationList(){
    return new Promise((resolve, reject) => {
      this._shareService.getmodelOperationList().subscribe((res:any)=>{
        if(res){
          // this.modalOperationList = res
          this.modalListForSet = res['modals']
        }
        resolve(true)
      })
    })
  }
  getPrjAiModelOpt(){
    let projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
    let obj={
      "projectId": projectInfo.projectId
    }
    this._shareService.getaiModelOpt(obj).subscribe((res:any)=>{
      if(res){
      let newRes: any =  res.filter((value, index, self) =>
          index === self.findIndex((t) => (
            t.modelName === value.modelName && t.optName === value.optName
          ))
        )
        this.rowData_metaGrid1 = newRes;
        // this.metaGrid1()
      }
    })
  }



  saveAiModalInPrj(){
    let projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
          var allGridData = this.rowData_metaGrid1
    let projaidata:any=[]
    if(allGridData.length > 0){
        allGridData.forEach((res:any,ind:any)=>{
          (ind == 0) ? res['defmodal'] = 1 : res['defmodal'] = 0 
          let obj:any={
            "optId":res['optId'],
            "modelId":res['modelId'],
            "defmodal":res['defmodal'],
            "apikey" : res['apikey'],
            "temperature" : res['temperature']
          }
          projaidata.push(obj)
        })
      let obj={
        "projectId" : projectInfo.projectId,
        "prjaidata" :projaidata,
        "operationId" :allGridData[0].optId,
      }
      this._shareService.saveAiModalInPrj(obj).subscribe((res:any)=>{
        
        if (res['status'] == "success") {
            success(res['msg']);
            this.gridRowObj['metaOperation'] = 'select'
            this.gridRowObj['modal'] = []
            this.rowData_metaGrid1 = []
            // this.getPrjAiModelOpt()
            this.getTotalActOpt()
        } else {
            alerts(res['msg']);
        }
      })
    }
    else{
      alerts('Add data in grid')
    }
  }


  getTotalActOpt(){
    return new Promise((resolve, reject) => {
      let projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
      let obj={
        "projectId" : projectInfo.projectId,
      }
      this._shareService.getTotalActOpt(obj).subscribe((res:any)=>{
        if(res){
          res.forEach((ele:any) => {
            if(ele['ismodelset'] > 0){
              ele['modalList'] ={ iconclass: 'fa fa-check text-success', label: '' }
            }else{
              ele['modalList'] = {iconclass:'fa fa-times text-danger',label:''}
            }
            return ele
          });
          this.rowData_totalActOpt = res
          this.totalActOpt();
        }
        resolve(true)
      })
    })
  }

  addPageOpt(){
    let operation:any = this.gridRowObj['metaOperation']
    let modal:any = this.gridRowObj['modal']
    // let defmodal:any  = this.gridRowObj['defmodal']
    if(operation != 'select' && (modal !=undefined && modal.length > 0)){
      if(this.mode == 'set'){
        this.rowData_metaGrid1 =[]
      } 
      for (let ind = 0; ind < this.rowData_totalActOpt.length; ind++) {
        const opt = this.rowData_totalActOpt[ind];
        if(opt.operation == this.gridRowObj['metaOperation'])
          this.gridRowObj['optId'] = opt.optId      
      }
  
      for (let ind = 0; ind < this.modalOperationList['modals'].length; ind++) {
        const modal = this.modalOperationList['modals'][ind];
        this.gridRowObj['modal'].forEach((element:any) => {        
          if(modal.value == element.value)
            element['modelId'] = modal.modelId 
        }); 
      }
      let activeModalList:any = []
      this.gridRowObj['modal'].forEach((element:any) => {
        let obj:any=  {
          "optName": this.gridRowObj['metaOperation'],
          "modelName": element.value,
          "defmodal": (this.gridRowObj['defmodal'] == element.value) ? true : false ,
          "modelId" : element['modelId'],
          "optId" :  this.gridRowObj['optId'],
          "temperature": "",
          "apikey": "",
           }
            this.rowData_metaGrid1.push(obj)
            activeModalList.push(element.value)
          
      });

      let newModalOperationList = this.modalOperationList['modals'].filter((x:any)=>{
        return !activeModalList.includes(x.label)
      })
      this.gridRowObj['modal'] = []
      this.modalOperationList['modals'] = newModalOperationList

    }else{
      if(operation == 'select' && (modal == undefined || modal.length == 0)){
        alerts("Please select Operation and Modal fields")
      }
      else if(operation == 'select'){
        alerts("Please select Operation field")
      }
      else if(modal == undefined || modal.length == 0){
        alerts("Please select Modal field")
      }
    }
  }
  goBack(){
    let id:any= document.getElementById('aitab1')
    document.getElementById('aitab1-tab').classList.add('active')
    id.classList.add('active','show')
    let previd = document.getElementById('aitab2')
    document.getElementById('aitab2-tab').classList.remove('active')
    previd.classList.remove('active','show')
  }

 async open(operation:any,mode:any){
    this.mode = mode
    this.modalOperationList['modals'] = this.modalListForSet
    // await this.getmodelOperationList()
    if(mode == 'Edit'){
      let projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
      let obj:any={
        "operationId" : operation.rowValue.optCode,
        "projectName" : projectInfo.projectname 
      }
      
      this.getModalLiastOPt(obj,operation,true)
    }else{
      this.modalOperationList['modals'] = this.modalListForSet
      this.rowData_metaGrid1 = []
      // this.metaGrid1()
    }
    this.hideShowTabs = true
    this.gridRowObj['metaOperation'] = operation.rowValue.operation
    let id:any= document.getElementById('aitab2')
    document.getElementById('aitab2-tab').classList.add('active')
    id.classList.add('active','show')
    let previd = document.getElementById('aitab1')
    document.getElementById('aitab1-tab').classList.remove('active')
    previd.classList.remove('active','show')
  }

  removeItem(index: number,item:any): void {
    let selectedModel:any= this.modalListForSet.filter(x=> item == x.label)
    this.modalOperationList['modals'].push(selectedModel[0])
    let modals:any = this.modalOperationList['modals'].sort((a, b) => a.modelId - b.modelId);
    this.gridRowObj['modal'] = []
    this.modalOperationList['modals'] = []
    for (let i = 0; i < modals.length; i++) {
      const element = modals[i];
      this.modalOperationList['modals'].push(element)
    }
    
    this.rowData_metaGrid1.splice(index, 1);
  }

  drop(event: CdkDragDrop<any[]>) {
    if (event.previousIndex !== event.currentIndex) {
      moveItemInArray(this.rowData_metaGrid1, event.previousIndex, event.currentIndex);
    }
  }



  async changeModalOpts(){
    if(this.gridRowObj['metaOperation'] == 'select'){
      this.rowData_metaGrid1 = []
      this.gridRowObj['modal'] = []
      this.modalOperationList['modals'] = []
    }else{
      this.modalOperationList['modals'] = this.modalListForSet
      // await this.getmodelOperationList()
      let optCode = this.rowData_totalActOpt.filter(x =>  this.gridRowObj['metaOperation'] == x.operation )
      if(optCode[0].ismodelset == 0){
        this.rowData_metaGrid1 =[]
        this.gridRowObj['modal'] = []
        this.modalOperationList['modals'] = this.modalListForSet
      }else{
        let projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
        let obj:any={
          "operationId" : optCode[0].optCode,
          "projectName" : projectInfo.projectname 
        }
        this.getModalLiastOPt(obj,optCode[0],false)
      }
    }
  }


  getModalLiastOPt(obj:any,operation:any,editMode:any){
    this._shareService.getModalListOpt(obj).subscribe((res:any)=>{
      if(res){
        let newGridRowdata:any = []
        let activeModalList:any = []
        for (let i = 0; i < res['modals'].length; i++) {
          const element = res['modals'][i];
          let obj:any = {}
          // obj['active'] = element['defaultmodel'],
          obj['defmodal'] = element['defaultmodel'] == '1' ? 1 : false
          obj['modelId'] = element['value'],
          obj['modelName'] = element['label'],
          obj['optId'] = editMode == true ? operation.rowValue.optId : operation.optId,
          obj['optName'] = editMode == true ? operation.rowValue.operation : operation.operation,
          obj['apikey'] = element['apikey'],
          obj['temperature'] = element['temp'] ,
          newGridRowdata.push(obj)
          activeModalList.push(element.label)
        }
        this.rowData_metaGrid1 = newGridRowdata
        // this.metaGrid1()
       let newModalOperationList = this.modalOperationList['modals'].filter((x:any)=>{
          return !activeModalList.includes(x.label)
        })
        this.gridRowObj['modal'] = []
        // this.modalOperationList['modals'] = []
        this.modalOperationList['modals'] = newModalOperationList
      }
    })
  }

  tabClick(){
    if(this.mode == 'set'){
      this.modalOperationList['modals'] = this.modalListForSet
    }
  }
  
}
