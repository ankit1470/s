import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MetaDataRoutingModule } from './meta-data-routing.module';
import { ImagePreviewComponent } from './image-preview/image-preview.component';


@NgModule({
  declarations: [ImagePreviewComponent],
  imports: [
    CommonModule,
    MetaDataRoutingModule
  ]
})
export class MetaDataModule { }
