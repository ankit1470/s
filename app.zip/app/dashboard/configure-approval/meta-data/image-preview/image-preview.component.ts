import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/primeng';

declare function alerts(m:any);

@Component({
  selector: 'app-image-preview',
  templateUrl: './image-preview.component.html',
  styleUrls: ['./image-preview.component.scss']
})
export class ImagePreviewComponent implements OnInit {

  imgCollection: any;
  selectedImage: any = ''

  constructor(
    private config: DynamicDialogConfig,
    private modalRef: DynamicDialogRef
  ) {
    this.imgCollection = this.config.data;
  }

  ngOnInit() {
  }

  setImage() {
    if (this.selectedImage) {
      this.modalRef.close(this.selectedImage)
    } else {
      alerts("Please select image first!")
    }

  }

}
