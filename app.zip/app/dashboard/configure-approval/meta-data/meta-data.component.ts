import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/primeng';
import { ToastService } from 'src/app/core/services/toast.service';
import { ApiServiceService } from 'src/app/services/http/api-service.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DefaultMetaComponent } from '../default-meta/default-meta.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ImagePreviewComponent } from './image-preview/image-preview.component';

declare var SdmtGridT;
declare var $: any;
declare function success(m: any): any;
declare function alerts(m: any): any;
declare var SdmtDynamicComp;
@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: 'app-meta-data',
  templateUrl: './meta-data.component.html',
  styleUrls: ['./meta-data.component.scss'],
  providers: [DialogService]
})
export class MetaDataComponent implements OnInit {
  selectedPageModule:any
  markashome:any;
  defaultMeta:any;
  metaSectionCheck : boolean = true
  showVar: boolean = false;
  radioValue : any = 'static'
  metaInfo : any = { route_from : '', route_to : '', pageRoute : ''}
  fixedMetaData = []
  hideArea: boolean = false;
  disableModify : boolean = false
  metaData: any;
  createArr = []
  selectedMetaArr = [];
  selectedPath: string = '';
  metaDataRowGrid: any
  routeFileName: string = '';
  filePath1: string = '';
  projectInfo1: any = null;
  projectInfo: any = null;
  availableMenuFiles: any = [];
  isMetaDataRefresh: boolean = false
  metaForm : FormGroup ;
  @Input() isSeoTabClick:boolean
  constructor( 
    private _shareService: SagShareService,
    private _apiService: ApiServiceService,
    public toast: ToastService,
    public modalRef: DynamicDialogRef,
    public sagStudioService: SagStudioService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    private formBuilder : FormBuilder
  ) { 
    this.metaForm = this.formBuilder.group({
      title : ['This is dummy content', [Validators.maxLength(100)]],
      description : ['This is dummy content',[Validators.maxLength(200)]]
    });
  }
  ngOnInit() { 
    this.markashome = false
    this.projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
    if(this.isSeoTabClick){
      this.getMetaList()
    }

    Object.keys(this.metaForm.controls).forEach(element => {
      this.metaForm.controls[element].valueChanges.subscribe((res:any) => {
        if(this.gridDynamicObj_metadata) {
          let toBeUpdatedRow = this.gridDynamicObj_metadata.sagGridObj.rowDef.filter(res => res.defaultcol == element);
          if(toBeUpdatedRow && toBeUpdatedRow.length) {
            toBeUpdatedRow.forEach(response => {
              this.gridDynamicObj_metadata.updateCell(response.sag_G_Index, "svalue", res)
            });
          }
        }
      })
    });
  }

  metaKeywordList: any = [
    {
      "label": "Select",
      "value": ""
    },
    {
      "label": "CHARSET",
      "value": "charset"
    },
    {
      "label": "CONTENT",
      "value": "content"
    },
    {
      "label": "HTTP-EQUIV",
      "value": "http-equiv"
    },
    {
      "label": "ID",
      "value": "id"
    },
    {
      "label": "ITEMPROP",
      "value": "itemprop"
    },
    {
      "label": "NAME",
      "value": "name"
    },
    {
      "label": "PROPERTY",
      "value": "property"
    },
    {
      "label": "SCHEME",
      "value": "scheme"
    },
    {
      "label": "URL",
      "value": "url"
    },

  ];
  gridData_metadata: any;
  gridDynamicObj_metadata: any;
  columnData_metadata: any = [
    {
      hidden: false,
      editable: "false",
      filter: false,
      search: true,
      component: "label",
      field: "sno",
      freezecol: "null",
      width: "50px",
      header: "S.No",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: false,
      search: true,
      component: "text",
      field: "fkey",
      freezecol: "null",
      width: "150px",
      header: "Key",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: false,
      search: true,
      component: "text",
      field: "fvalue",
      freezecol: "null",
      width: "150px",
      header: "Value",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: false,
      search: true,
      component: "text",
      field: "skey",
      freezecol: "null",
      width: "150px",
      header: "Key",
      "text-align": "left",
    },
    {
      "hidden": false,
      "search": false,
      "cellHover": false,
      "text-align": "center",
      "editable": "false",
      "sort": false,
      "filter": false,
      "component": "dynamicComponent",
      "field": "svalue",
      "freezecol": "null",
      "width": "200px",
      "header": "Value",
      "cellRenderView": true,
    },
    {
      header: "Default",
      field: "defaultcol",
      hidden: false,
      search: false,
      cellHover: false,
      "text-align": "left",
      editable: "false",
      sort: false,
      filter: false,
      component: "select",
      freezecol: "null",
      width: "auto",
      cellRenderView: false,
    },
    {
      "hidden": false,
      "search": false,
      "cellHover": false,
      "text-align": "center",
      "editable": "false",
      "sort": false,
      "filter": false,
      "component": "dynamicComponent",
      "field": "imgtype",
      "freezecol": "null",
      "width": "200px",
      "header": "Image Type",
      "cellRenderView": true,
    },
    {
      "header": "Image Selection",
      "field": "image",
      "filter": false,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },
    },
    {
      "header": "Delete",
      "field": "delete",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "rowDelete",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false, 
      "sort": false,
      "cellHover": false,
    } 
  ];
  rowData_metadata: any = [];
  validationmetadata: any = {}
  currentPageImageData : any = []
  svalueJSON : any = [ { "key": "", "val": "-Select-" }, { "key" : "website", "val" : "website"}, { "key" : "article", "val" : "article"}, { "key" : "book", "val" : "book"}, { "key" : "profile", "val" : "profile"}, { "key" : "music.song", "val" : "music.song"}, { "key" : "music.album", "val" : "music.album"}, { "key" : "music.playlist", "val" : "music.playlist"}, { "key" : "music.radio_station", "val" : "music.radio_station"}, { "key" : "video.movie", "val" : "video.movie"}, { "key" : "video.episode", "val" : "video.episode"}, { "key" : "video.tv_show", "val" : "video.tv_show"}, { "key" : "video.other", "val" : "video.other"} ]
  imgtypeJson : any = [
    { "key": "", "val": "-Select-" },
    { "key" : "image/png", "val" : "image/png"},
    { "key" : "image/jpg", "val" : "image/jpg"},
    { "key" : "image/webp", "val" : "image/webp"}
  ]

  metadata(rowData?: any, colData?: any) {
    let self = this;
    let daynamicComp = new SdmtDynamicComp({}, function (ele, params) { });
    this.gridData_metadata = {
      columnDef: colData ? colData : this.columnData_metadata,
      rowDef: rowData ? rowData : this.rowData_metadata,
      footer_hide: true,
      totalNoOfRecord_hide: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: true,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationmetadata,
      newPagination: false,
      recordPerPage: 10,
      ellipsisV: {},
      components: {},
      callBack: {
        "onRowDelete_delete": function (ele: any, param: any) {
          self.rowData_metadata.splice(param.rowIndex, 1);
          success("Deleted Successfully!");
          self.metadata()
        },
        "onButton_image": function (ele, params) {
          const modalRef = self.dialogService.open(ImagePreviewComponent, {
            width: "70%",
            header : 'Image Selection',
            contentStyle: { height: "575px" },
            data : self.currentPageImageData
          })
          modalRef.onClose.subscribe((res:any) => {
            if(res) {
              self.gridDynamicObj_metadata.updateCell(params.rowIndex, "svalue", res)
            }
          }) 
        },
        "onTextChange_svalue" : function (ele, params) {
          if(ele.value.trim() == self.metaForm.value.title.trim()) {
            self.gridDynamicObj_metadata.updateCell(params.rowIndex, "defaultcol", 'title')
          } else if(ele.value.trim() == self.metaForm.value.description.trim()) {
            self.gridDynamicObj_metadata.updateCell(params.rowIndex, "defaultcol", 'description')
          } else {
            self.gridDynamicObj_metadata.updateCell(params.rowIndex, "defaultcol", '')
          }
        },
        "onChangeSelect_defaultcol": function (ele, params) {
          self.gridDynamicObj_metadata.updateCell(params.rowIndex, "svalue", self.metaForm.value[ele.value])
        },
        "onChangeSelect_imgtype": function (ele, params) {
          self.gridDynamicObj_metadata.updateCell(params.rowIndex, "svalue", ele.value)
        },
        "onCellClick": function (ele: any,param: any) {
          self.onmetadataCellClick();
        },
        "onRowClick": function () {
          self.onmetadataClick();
        },
        "onRowDbleClick": function () {
          self.onmetadatadblClick();
        }
      }
      ,
      dropDownJson_defaultcol: [{ "key": "", "val": "-Select-" }, {val : "Title", key : "title"}, {val : "Description", key : "description"}],
      dropDownJson_imgtype: self.imgtypeJson,
      dropDownJson_svalue: self.svalueJSON,
      rowCustomHeight: 20,
      plusButton_obj: {},
      rowGrouping: {
        "enable": true,
        "allowClick": true,
        "groupType": "custome",
        "groupBy": "meta",
      },



    };
    for(let i = 0; i < this.gridData_metadata.rowDef.length; i++) {
      let obj = this.gridData_metadata.rowDef[i];
      if(obj.fvalue == 'og:image:type') {
        obj.dynamicCompName_imgtype = 'select';
        obj.dynamicCompCellRenderView_imgtype = true;
      } else {
        obj.dynamicCompName_imgtype = 'label';
        obj.dynamicCompCellRenderView_imgtype = false;
      }

      if(obj.fvalue == 'og:type') {
        obj.dynamicCompName_svalue = 'select';
        obj.dynamicCompCellRenderView_svalue = true;
      } else {
        obj.dynamicCompName_svalue = 'text';
        obj.dynamicCompCellRenderView_svalue = false;
      }

      if(obj.defaultcol) {
        obj.svalue = this.metaForm.value[obj.defaultcol]
      } else if(Object.values(this.metaForm.value).includes(obj.svalue)) {
        obj.defaultcol = (obj.svalue.trim() == this.metaForm.value.title.trim()) ? 'title' : 'description'
      }
    }

    let sourceDiv = document.getElementById("metadata");
    if(sourceDiv !=null) this.gridDynamicObj_metadata = SdmtGridT(sourceDiv, this.gridData_metadata, true, true);
  }

  onmetadataCellClick() { }

  onmetadataClick() { }

  onmetadatadblClick() { }

  showSections(check : boolean) {
    this.metaSectionCheck = check
    if(check===false) {
      this._shareService.getPageWiseImageData({ pageId: this.sagStudioService.completeJsonWithContainer.fileId }).subscribe(((res:any) => {
        if(res) {
          this.currentPageImageData = Object.values(res);
          this.currentPageImageData.forEach(element => {
            element.image = element.src;
            let imgName = element.src.split("/");
            element.name = imgName[imgName.length-1]
          });
        }
      }))
      setTimeout(() => {
      this.metadata(this.rowData_metadata);
      }, 100)
    }    
  }
  addRow(metaList) {
    let obj = {
      'metaKey': '',
      'metaValue': ''
    }
    metaList.push(obj)
  }

  deleteRow(metaList, index) {
    if(index !==0) metaList.splice(index, 1);
  }

  updateMetaKey1(event, meta) {
    meta.metaKey = event;
  }
  updateMetaValue1(event, meta) {
    meta.metaValue = event.target.value;
  }
  selectedMetaRow(event:any) {
    this.createArr = []
    this.radioValue = 'static'
    this.selectPageOption({target : {value : event.route_from}}, event);
    this.metaInfo.route_from = event.route_from;
    this.metaInfo.route_to = event.module;
    this.metaInfo.pageRoute = event.metaUrl[0];
    this.markashome = (event.markashome == 0) ? false : true
    this.showRoutesData();
    let element = document.getElementById('pills-tag-tab');
    element.click()
    this.disableModify = true
  }
// sag
  selectPageOption(event, edit?) {
    this.rowData_metadata = []
    this.metaData = []
    let selectNode = this.availableMenuFiles.filter(x => x.moduleName == event.target.value)[0];

    this.projectInfo1 = this._shareService.getDataprotool("selectedProjectChooseData");
    if (this.projectInfo1) {
      let obj = {
        "projectId": this.projectInfo1['projectId'],
        "unifilepath": selectNode.matchableId
      }
      this._apiService.getRouteArray(obj).subscribe((res: any) => {
        this.metaData = res.map((e) => { return e; });;
        if(edit) {
          let idx = this.metaData.findIndex(res => res.module == edit.module);
          this.selectPageRouteOption({srcElement : {options : {selectedIndex : idx+1}}})
        }
      });
    }
  }
  //show button
  showRoutesData() {
    if(this.radioValue == 'manual') {
      this.selectPageRouteOption()
    }
    this.fixedMetaData = [{'metaKey': '','metaValue': ''},{'metaKey': '','metaValue': ''}];
    this.showVar = true;
    this.hideArea = true;
    this.rowData_metadata = []
    this.rowData_metadata = this.createArr
    setTimeout(() => {
      this.rowData_metadata=this.createArr
       this.metadata();
       for (let ind = 0; ind < this.metaData.length; ind++) {
        const element = this.metaData[ind];
        if(element['markashome'] ==0){
          return
        }
        if(element.name == this.selectedPageModule.name){
          if(element.markashome == 1){
            this.markashome = true;
          } else{
            this.toast.launch_toast({
              type: 'alert',
              position: 'bottom-right',
              message: `mark as home is already checked to ${element.name} page`,
            }); 
            this.markashome = false
          }     
        }
      }
    }, 100)
  }
  // modules
  selectPageRouteOption(event?) {
    this.markashome = this.metaData[event.srcElement.options.selectedIndex-1].markashome
    let selectedPage;
    this.rowData_metadata = [];
    this.createArr = []
    if(this.radioValue == 'manual') {
      selectedPage = {
        module : this.metaInfo.route_to,
        moduleName : this.metaInfo.route_from,
        metaUrl : this.metaInfo.pageRoute
      }
    } else {
      selectedPage = this.metaData[event.srcElement.options.selectedIndex - 1] != undefined ? this.metaData[event.srcElement.options.selectedIndex - 1] : '';
      this.selectedPageModule = selectedPage
    }
    this.selectedMetaArr = [];
    this.selectedPath = '';
    this.selectedPath = selectedPage.path;
    this.selectedMetaArr.push(selectedPage);
    // this.fixedMetaData.push(selectedPage.data[0])
    this.metaForm.controls['title'].setValue(this.selectedMetaArr[0].title ? this.selectedMetaArr[0].title : "")
    this.metaForm.controls['description'].setValue(this.selectedMetaArr[0].desc ? this.selectedMetaArr[0].desc : "")

    if (selectedPage && selectedPage.meta && selectedPage.meta.length > 0) {

      for (let index = 0; index < selectedPage.meta.length; index++) {
        let keyVal = selectedPage.meta[index];;
        let keys = Object.keys(keyVal);
        let values = Object.values(keyVal);
        let obj = {
          delete : "",
          fkey : keys[0] ? keys[0] : "",
          skey : keys[1] ? keys[1] : "",
          fvalue : values[0] ? values[0] : "",
          svalue : values[1] ? values[1] : "",
        };
        this.createArr.push(obj)
        this.rowData_metadata.push(obj)
      }
      this.metadata()
    }
  }

  finalMetaSave() {
    if(this.metaForm.valid) {
      try {
      this.rowData_metadata=this.gridDynamicObj_metadata.getGridData()
      let json = {
        "projectId": this.projectInfo1['projectId'],
        "filePath": this.radioValue == 'manual' ? '' : this.filePath1,
        "title": this.metaForm.controls['title'].value.trim(),
        "pageRoute": this.radioValue == 'manual' ? 
        (this.metaInfo.pageRoute.includes('/') ? this.metaInfo.pageRoute : '/'+this.metaInfo.pageRoute) 
        : this.selectedMetaArr[0]['metaUrl'][0],
        "meta": [],
        "desc":this.metaForm.controls['description'].value.trim(),
        "markashome":this.markashome ? true : false
      }
  
      let pageData = [];
      for (let index = 0; index < this.rowData_metadata.length; index++) {
        let objec = {};
        let elem = this.rowData_metadata[index];
        objec[elem.fkey] = elem.fvalue
        objec[elem.skey] = elem.svalue
        pageData.push(objec)
      }
      json['meta'] = pageData;
      this._apiService.saveMetaInfo(json).subscribe((res) => {
        if (res && res['status'] == 'success') {
          this.toast.launch_toast({
            type: 'success',
            position: 'bottom-right',
            message: res['msg'],
          });
          if(this.disableModify) {
            let element = document.getElementById('pills-list-tab');
            element.click()
          }
          this.disableModify = false
          this.modifyRoutesData();
          this.metaInfo = { route_from : '', route_to : '', pageRoute : '',};
          this.refreshMetaDataGrid()
        }
  
      });
    } catch (error) {
        throw error
    }
    } else {
      Object.keys(this.metaForm.controls).forEach(element => {
        let control = this.metaForm.controls[element];
        if(control.errors) {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: `${element} length should be ${control.errors.maxlength.requiredLength}`,
          }); 
        }
      });
    }
  }
  modifyRoutesData() {
    if(!this.disableModify) {
      this.showVar = false;
      this.hideArea = false;
    }
  }
  // titleContentMethod(event) {
  //   this.titleContent = event.target.value
  //   // if(this.titleContent.length > 55){
  //   //   alert("Your title length reached above 55 characters")
  //   // }
  // }
  metaDataShowInGrid1(data) {
    let obj = {};
  
    let dCheck : any[] = this.rowData_metadata.filter(res => res.fvalue == this.fixedMetaData[0].metaValue);
    if(!dCheck.length) {
      obj = {
        delete : "",
        fkey : this.fixedMetaData[0].metaKey,
        skey : this.fixedMetaData[1].metaKey,
        fvalue : this.fixedMetaData[0].metaValue,
        svalue : this.fixedMetaData[1].metaValue,
      }
      this.rowData_metadata.push(obj)
      this.metadata();
      this.fixedMetaData = [{'metaKey': '','metaValue': ''},{'metaKey': '','metaValue': ''}];
      $('#metamodal').modal('hide')
    } else {
      alerts("Meta value record already exist!")
    }
  }
  exportMetaData() {
    const projectDetails = this._shareService.getDataprotool("selectedProjectChooseData");
    let projectName = this.projectInfo1.projectname
    const projectInfo = {
      "projectPath": projectDetails['awspace'],
      "projectId": projectDetails.projectId,
      "projectName": projectName,
      "staticonpage": 0
    }
    this._apiService.exportProjectMetaData(projectInfo).subscribe(res => {
      if (res['status'] === 'success'){
        this.toastNotifications('success',res['msg'])
        let obj={
          "projectPath": projectDetails['awspace'],
          "projectId": projectDetails.projectId,
          "filePath": `${projectDetails['awspace']}/src/app/config/meta.config.ts`,
          "fileName": "meta.config.ts",
          "usrId": projectDetails['userId']
        }
        this._shareService.saveFileInfo(obj).subscribe((res:any)=>{

        })

      } 
      else this.toastNotifications('alert',res['msg'])
    })
  }

  toastNotifications(msgType, msg) {
    this.toast.launch_toast({
      type: msgType,
      position: 'bottom-right',
      message: msg
    })
  }
  
  close() {
    this.modalRef.close();
  }

  //  meta grid
  async getMetaList() {
    let payloadObj = {
      "projectId": this.projectInfo.projectId
    };
     this._shareService.getMetaList(payloadObj).subscribe(res=>{
      this.metaDataRowGrid = res;
      this.metaDataRowGrid.forEach(element => {
        element.meta = JSON.stringify(element.meta);
        let path = element.frmroute.split("/");
        let filename = path[path.length - 1].split("-");
        element.route_from = filename[0];
        element.status = element.meta !== '[]'
          ? { iconclass: 'fa fa-check text-success', label: '' }
          : { iconclass: 'fa fa-times text-danger', label: '' };
      });
    if(!this.isMetaDataRefresh) this.getMenu();
    });
  }

  async getMenu() {
    if (this.projectInfo) {
      let obj = { "projectId": this.projectInfo.projectId }
      const res = await this._shareService.getTotalroutesProject(obj).toPromise()
      this.availableMenuFiles = res;
      this.getRouteArrayOfPage();
    }
  }
  getRouteArrayOfPage() {
    this.metaKeywordList = [
      {
        "label": "Select",
        "value": ""
      },
      {
        "label": "CHARSET",
        "value": "charset"
      },
      {
        "label": "CONTENT",
        "value": "content"
      },
      {
        "label": "HTTP-EQUIV",
        "value": "http-equiv"
      },
      {
        "label": "ID",
        "value": "id"
      },
      {
        "label": "ITEMPROP",
        "value": "itemprop"
      },
      {
        "label": "NAME",
        "value": "name"
      },
      {
        "label": "PROPERTY",
        "value": "property"
      },
      {
        "label": "SCHEME",
        "value": "scheme"
      },
      {
        "label": "URL",
        "value": "url"
      },

    ];
    this.routeFileName = this.sagStudioService.currentActiveProject.currentActiveFileNode.id.replace(".component", "-routing.module.ts");
    let projectPathName = this.sagStudioService.currentActiveProject.currentActiveFileNode.projectPath
    this.filePath1 = projectPathName.substring(projectPathName.indexOf("src"))
    this.projectInfo1 = this._shareService.getDataprotool("selectedProjectChooseData");
  }
  async refreshMetaDataGrid() {
    this.isMetaDataRefresh=true
    await this.getMetaList()
  }

  openDefaultMeta(type:any){

    const ref = this.dialogService.open(DefaultMetaComponent, {
      header: type == 'setMetaSchema' ? "Set Meta From Schema" : 'Default Meta Tag' ,
      width: "80%",
      contentStyle: { height: "575px" },
      data: (type == 'defaultMeta') ? 'defaultMeta' : 'setMetaSchema'
      // styleClass: "service_full_model excel_import_export",
    });
    ref.onClose.subscribe((res) => {
      if(res && res.length){
        for(let i = 0; i < res.length; i++) {
          this.rowData_metadata = this.gridDynamicObj_metadata.sagGridObj.rowDef
          let dCheck = this.rowData_metadata.findIndex(resp => resp && resp.fvalue && resp.fvalue == res[i].fvalue);
          if(dCheck == -1) {
            this.rowData_metadata.push(res[i])
          } else {
            this.rowData_metadata[dCheck] = res[i];
          }
        }
        this.metadata();
      }
    });
  }

  checkMarkHomeStatus(event:any){
    console.log(this.metaData,"This is the meta data")
    if(event.target.checked == true){
      for (let ind = 0; ind < this.metaDataRowGrid.length; ind++) {
        const element = this.metaDataRowGrid[ind];
        if(element.markashome == 1){
          alerts(`mark as home is already checked to ${element.name} page`)
          this.markashome = false;
          event.preventDefault()
        } else{
          this.markashome = false
        }     
      }
    }else{
      this.markashome = false
    }


  }
}
