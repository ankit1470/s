import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { ToastService } from 'src/app/core/services/toast.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
declare var ui
@Component({
  selector: 'app-pwa',
  templateUrl: './pwa.component.html',
  styleUrls: ['./pwa.component.scss']
})
export class PwaComponent implements OnInit {

  constructor(
    private shareService: SagShareService,
    private proService: ProcomparetoolService,
    private toast: ToastService,
    private _sagStudioService: SagStudioService,
    private dragDropService: CommonStudioDragDropService,
    private formBuilder: FormBuilder
  ) {
  }

  fileJson: any = {}

  apiEndPoints: any = []

  async ngOnInit() {
    const currPath = this._sagStudioService.currentActiveProject.id + '/' + 'ngsw-config.json';
    const fileCodeRes = await this.dragDropService.getFileContentByPath(currPath);
    this.fileJson = JSON.parse(fileCodeRes.fileContent)

    this.apiEndPoints = JSON.parse(JSON.stringify(this._sagStudioService.sagWorkSpace.projectList[0].apiList))
    this.apiEndPoints.forEach(element => {
      element.url = '/' + element.url
    });
    if (this.fileJson.dataGroups && this.fileJson.dataGroups.length) {
      let dataGroup = this.fileJson.dataGroups;
      for (let j = 0; j < dataGroup.length; j++) {
        let obj = this.apiEndPoints.filter(res => dataGroup[j].urls.includes(res.url))
        this.fileJson.dataGroups[j].urls = []
        if (obj && obj.length) {
          this.fileJson.dataGroups[j].urls.push(...obj)
        }
      }
    }
  }

  addPwa() {
    let apiArr = []
    const chooseProjectPathID = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );
    let path: any = chooseProjectPathID.awspace;
    apiArr.push(this.proService.runCommandApi(path, 'npm install @angular/service-worker --force'))
    apiArr.push(this.proService.runCommandApi(path, 'ng add @angular/pwa --skip-confirmation --force'))
    this.shareService.loading++;
    forkJoin(apiArr).subscribe((res: any) => {
      this.shareService.loading--;
      if (res.status == 200) {
        this.toast.launch_toast({
          type: 'success',
          position: 'bottom-right',
          message: 'Package added successfully!!',
        });
      }
    })
  }

  saveServiceWorkerJsonFile() {
    let finaldata = JSON.parse(JSON.stringify(this.fileJson))
    if (finaldata.dataGroups && finaldata.dataGroups.length) {
      let dataGroup = finaldata.dataGroups;
      for (let j = 0; j < dataGroup.length; j++) {
        const element = dataGroup[j];
        let urlArr = []
        for (let i = 0; i < element.urls.length; i++) {
          urlArr.push(element.urls[i].url)
        }
        finaldata.dataGroups[j].urls = JSON.parse(JSON.stringify(urlArr))
      }
    }
    let proj = this.shareService.getDataprotool("selectedProjectChooseData")
    const currPath = proj.awspace + '/' + 'ngsw-config.json';
    this.shareService.writeFile(currPath, new Blob([JSON.stringify(finaldata, null, 2)], { type: "application/html" })).subscribe((res: any) => {
      this.toast.launch_toast({
        type: 'success',
        position: 'bottom-right',
        message: 'File saved successfully!!',
      })
    })
  }

  addDataGroup() {
    let obj =
    {
      "name": "api-perform",
      "urls": [],
      "cacheConfig": {
        "strategy": "freshness",
        "maxSize": 100,
        "maxAge": "3d",
        "timeout": "10s"
      }
    }
    this.fileJson.dataGroups && this.fileJson.dataGroups.length ? this.fileJson.dataGroups.push(obj) : this.fileJson.dataGroups = [obj]
  }
}
