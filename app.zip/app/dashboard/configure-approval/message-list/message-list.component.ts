import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';

declare var SdmtGridT;
declare var SdmtGridT;

@Component({
  selector: 'app-message-list',
  templateUrl: './message-list.component.html',
  styleUrls: ['./message-list.component.scss']
})
export class MessageListComponent implements OnInit {
  messageListContent = 1;
  constructor(
    private _shareService: SagShareService,
    public _router: Router,
    public toast: ToastService,
    public studioDragDropService: CommonStudioDragDropService,
    public sagStudioService: SagStudioService,
  ) { }

  ngOnInit() {
    this.availableMessage()
  }


  availableMessage() {
    let selectedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    const postData = {
      "projectId": selectedObj.projectId
    };
    this._shareService.getDefaultMessageList(postData).subscribe(res => {
      this.rowData_libraryfonts = res['prjmsglist'];
      this.availableinproject(this.rowData_libraryfonts);
    })

  }


  libraryMessageMethod() {
    let selectedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    const postData = {
      "projectId": selectedObj.projectId
    };
    this._shareService.getDefaultMessageList(postData).subscribe(res => {
      this.rowData_libraryfonts = res['allmsglist'];
      this.libraryfonts();
    })
  }


  columnData_allMessages: any = [
    {
      "header": "",
      "field": "selected",
      "filter": false,
      "width": "50px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "headerCheckBox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "center"
    },
    {
      "header": "Message ",
      "field": "msg",
      "filter": true,
      "width": "350px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    // {
    //   "header": "File path",
    //   "field": "filePath",
    //   "filter": true,
    //   "width": "300px",
    //   "editable": "false",
    //   "text-align": "left",
    //   "search": true,
    //   "component": "label",
    //   "cellRenderView": false,
    //   "freezecol": "null",
    //   "hidden": false,
    //   "sort": false,
    //   "cellHover": false
    // },
    // {
    //   "header": "Font class",
    //   "field": "fontclass",
    //   "filter": true,
    //   "width": "400px",
    //   "editable": "false",
    //   "text-align": "left",
    //   "search": true,
    //   "component": "label",
    //   "cellRenderView": false,
    //   "freezecol": "null",
    //   "hidden": false,
    //   "sort": false,
    //   "cellHover": false
    // },
  ];


  gridData_libraryfonts: any;
  gridDynamicObj_libraryfonts: any;
  rowData_libraryfonts: any = [
    {},
    {},
    {},
    {}
  ];

  libraryfonts(rowData?, colData?) {
    let self = this;
    let columnDataLibraryfonts
    columnDataLibraryfonts = this.columnData_allMessages
    this.gridData_libraryfonts = {
      columnDef: colData ? colData : columnDataLibraryfonts,
      rowDef: rowData ? rowData : this.rowData_libraryfonts,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onlibraryfontsCellClick();
        },
        "onRowClick": function () {
          self.onlibraryfontsClick();
        },
        "onRowDbleClick": function () {
          self.onlibraryfontsdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };
    let sourceDiv
    sourceDiv = document.getElementById("allMessages");
    if (sourceDiv != null) {
      this.gridDynamicObj_libraryfonts = SdmtGridT(sourceDiv, this.gridData_libraryfonts, true, true);
    }
  }

  onlibraryfontsCellClick() {

  }

  onlibraryfontsClick() {

  }

  onlibraryfontsdblClick() {

  }



  gridData_availableinproject: any;
  gridDynamicObj_availableinproject: any;
  columnData_availableMessageList: any = [
    {
      "header": "",
      "field": "Column2",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "headerCheckBox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    {
      "hidden": false,
      "editable": "false",
      "filter": false,
      "search": false,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "100px",
      "header": "S.No",
      "text-align": "center"
    },
    {
      "header": "Message",
      "field": "msg",
      "filter": false,
      "width": "87%",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];
  rowData_availableinproject: any = [
    {},
    {},
    {},
    {}
  ];

  availableinproject(rowData?, colData?) {
    let self = this;
    let columnData
    columnData = this.columnData_availableMessageList
    this.rowData_availableinproject = rowData
    this.gridData_availableinproject = {
      columnDef: colData ? colData : columnData,
      rowDef: rowData ? rowData : this.rowData_availableinproject,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("availableinprojectFonts");
    if (sourceDiv != null) {
      this.gridDynamicObj_availableinproject = SdmtGridT(sourceDiv, this.gridData_availableinproject, true, true);
    }
  }

  onavailableinprojectCellClick() {

  }

  onavailableinprojectClick() {

  }

  onavailableinprojectdblClick() {

  }


}
