import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RobotsTxtGeneratorRoutingModule } from './robots-txt-generator-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RobotsTxtGeneratorRoutingModule
  ]
})
export class RobotsTxtGeneratorModule { }
