import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormBuilder,FormArray, FormControl, FormGroup } from '@angular/forms';
import { ToastService } from 'src/app/core/services/toast.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var SdmtGridT;
declare var ButtonComponent;
declare var SagGridMPT; // Module Work
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var ui;
@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: 'app-robots-txt-generator',
  templateUrl: './robots-txt-generator.component.html',
  styleUrls: ['./robots-txt-generator.component.scss']
})
export class RobotsTxtGeneratorComponent implements OnInit, OnChanges {
  isRobotTxtExist: any;
  pathList!: FormGroup;
  generateUrlList: any;
  googleBot: any = [];
  robotsTxtData: any
  sameAsDefaultpathSet: any = `\n`
  siteMapUrl: any = []
  siteMapUrlForm!: FormGroup
  defaultPathList: any;
  finalSiteMap = '\n';
  preViewdata: any;
  sameAsDefaultpathSetListSorted: any = []
  sameAsDefaultpathSetList: any = new Set();
  crawlDelay: any;
 projectInfo: any = null;
 urlPathList: any = [];
 @Input() isSeoTabClick:boolean

  constructor(
    private _shareService: SagShareService,
    public toast: ToastService,
    private FormBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
    this.pathList = new FormGroup({
      selectedPathList: new FormControl([]),
      default: new FormControl(''),
      crawlDelay: new FormControl(),

    });
    this.siteMapUrlForm = this.FormBuilder.group({
      arr: this.FormBuilder.array([this.createItem()])
    });
    if(this.isSeoTabClick) this.getRobotTxtData()
  
  }
  ngOnChanges() {
  }
  getRobotTxtData(){
    let projectId = { "projectId": this.projectInfo.projectId }
    this._shareService.getUrl(projectId).subscribe((res) => {
      if (res) {
        this.urlPathList = JSON.parse(JSON.stringify(res));
        this.robotTxtExist()
        this.urlPathList = this.urlPathList.map((res) => {
          return { label: `${res.LOC}`, value: `${res.LOC}` }
        });
        setTimeout(() => {
          this.robotTxtGrid()
        }, 50);
      } else {
        this.toastNotification("alert", res["msg"])  
      }
    });
  }
  gridData_axis: any;
  gridDynamicObj_axis: any;
  columnData_axis: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": false,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",
    },
    {
      "hidden": false,
      "search": true,
      "cellHover": false,
      "text-align": "left",
      "editable": "false",
      "sort": false,
      "filter": false,
      "component": "text",
      "field": "url",
      "freezecol": "null",
      "width": "200px",
      "header": "Url",
      "cellRenderView": false,
    },
    {
      "header": "Allowed",
      "field": "allowed",
      "filter": false,
      "width": "250px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "multiSelect",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Refused",
      "field": "refused",
      "filter": false,
      "width": "250px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "multiSelect",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "same as default",
      "field": "sameAsDefault",
      "filter": false,
      "width": "250px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "multiSelect",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Add Row",
      "field": "addRow",
      "filter": false,
      "width": "260px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "plusButton",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Delete Row",
      "field": "deleteRow",
      "filter": false,
      "width": "245px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "rowDelete",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
  ];

  rowData_axis: any = [
    { url: "url" },
    {},
    {},
    {}
  ];
  validationaxis: any = {}
  crawler: any = [{ "key": 'Google', "val": 'Googlebot' },
  { "key": 'Google Image', "val": 'googlebot-image' },
  { "key": 'Google Mobile', "val": 'googlebot-mobile' },
  { "key": 'MSN Search', "val": 'MSNBot' },
  { "key": 'Yahoo', "val": 'Slurp' },
  { "key": 'Yahoo MM', "val": 'yahoo-mmcrawler' },
  { "key": 'Yahoo Blogs', "val": ' yahoo-blogs/v3.9' },
  { "key": 'Ask/Teoma', "val": 'Teoma' },
  { "key": 'GigaBlast', "val": 'Gigabot' },
  { "key": 'DMOZ Checker', "val": 'Robozilla' },
  { "key": 'Nutch', "val": 'Nutch' },
  { "key": 'Alexa/Wayback', "val": 'ia_archiver' },
  { "key": 'Baidu', "val": 'baiduspider' },
  { "key": 'Naver', "val": 'naverbot' },
  { "key": 'MSN PicSearch', "val": 'psbot' }]

  robotTxtGrid(rowData?: any, colData?: any) {
    let self = this;
    let mobileWebItem = ""
    let allowed_Json: any = this.crawler;
    let refused_Json: any = this.crawler;
    let sameAsDefault_Json: any = this.crawler;
    this.gridData_axis = {
      columnDef: colData ? colData : this.columnData_axis,
      rowDef: rowData ? rowData : this.rowData_axis,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationaxis,
      newPagination: false,
      recordPerPage: 10,
      exportBtn: (mobileWebItem == 'mobile') ? false : false,
      newExpandExportTotalRecord_hide: undefined,
      commonSearchSelect_hide: (mobileWebItem == 'mobile') ? false : false,
      commonFilterSelect_hide: (mobileWebItem == 'mobile') ? false : false,
      orderArray: (mobileWebItem == 'mobile') ? ["sno", "url", "allowed", "refused", "sameAsDefault", "addRow", "deleteRow"] : ["sno", "url", "allowed", "refused", "sameAsDefault", "addRow", "deleteRow"],
      ellipsisV: {},
      gridRowAddDeleteButton: "undefined",
      components: {},
      callBack: {
        "onPlusButton_addRow": function (ele: any, param: any) {
        },
        "onCellClick": function (ele: any) {

          self.onaxisCellClick();
        },
        "onRowClick": function () {
          self.onaxisClick();
        },
        "onRowDbleClick": function () {
          self.onaxisdblClick();
        }
      },
      rowCustomHeight: 20,
      plusButton_obj: {},
      "multidropDownJson_allowed": allowed_Json,
      "multidropDownJson_refused": refused_Json,
      "multidropDownJson_sameAsDefault": sameAsDefault_Json,
    };
    let sourceDiv = document.getElementById("robotsgrid");
    this.gridDynamicObj_axis = SdmtGridT(sourceDiv, this.gridData_axis, true, true);
  }

  onaxisCellClick() {

  }

  onaxisClick() {

  }

  onaxisdblClick() {

  }
  robotTxtExist() {
    // const __prjDetails = this._shareService.getDataprotool("selectedProjectChooseData")
    let postdata = {
      "projectPath": this.projectInfo['awspace']
    }
    this._shareService.robotTxtExist(postdata).subscribe((res: any) => {
      this.isRobotTxtExist = res
    })
  }
  checkResult() {
    const result = document.getElementById('check_content').classList.toggle('show');
    this.generateUrlList = JSON.parse(JSON.stringify(this.gridDynamicObj_axis.sagGridObj.rowData));
    this.generateRobotTxtFormate();
  }

  hidepopup() {
    const showpop = document.getElementById('check_content').classList.remove('show');
  }

  getRobotsTxtPathList() {
    let projectId = { "projectId": this.projectInfo.projectId }
    this._shareService.getUrl(projectId).subscribe((res) => {
      this.urlPathList = JSON.parse(JSON.stringify(res));
      if (res) {
        this.urlPathList = this.urlPathList.map((res) => {
          return { label: `${res.LOC}`, value: `${res.LOC}` }
        });
      } else {
        this.toastNotification("alert", res["msg"])
      }
    });
  }

  gridSelectedList() {
    let selectedUrlList = this.pathList.get('selectedPathList').value.map((res) => {
      return { url: `${res}`, default: this.pathList.get('default').value }
    });
    this.robotTxtGrid(selectedUrlList);
  }

  generateRobotTxtFormate() {
    this.preViewdata = ''
    this.sameAsDefaultpathSetList = []
    this.finalSiteMap = ''
    this.sameAsDefaultpathSet = ''
    this.robotsTxtData = ''
    let userAgentData = {};
    this.generateUrlList.forEach(item => {
      if (item.hasOwnProperty('allowed')) {
        item.allowed.forEach(agent => {
          if (!userAgentData.hasOwnProperty(agent)) {
            userAgentData[agent] = { user_agent: agent, allow: [], disallowed: [], sameAsDefault: [] };
          }
          userAgentData[agent].allow.push(item.url);
        });
      }
      if (item.hasOwnProperty('refused')) {
        item.refused.forEach(agent => {
          if (!userAgentData.hasOwnProperty(agent)) {
            userAgentData[agent] = { user_agent: agent, allow: [], disallowed: [], sameAsDefault: [] };
          }
          userAgentData[agent].disallowed.push(item.url);
        });
      }
      if (item.hasOwnProperty('sameAsDefault')) {
        item.sameAsDefault.forEach(agent => {
          if (!userAgentData.hasOwnProperty(agent)) {
            userAgentData[agent] = { user_agent: agent, allow: [], disallowed: [], sameAsDefault: [] };
          }
          userAgentData[agent].sameAsDefault.push(item.url);
        });
      }
    });
    let result = Object.values(userAgentData);
    this.finalFormate(result);
  }

  finalFormate(data: any) {
    data.forEach(element => {
      switch (element.user_agent) {
        case 'Google':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Googlebot\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Google Image':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: googlebot-image\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Google Mobile':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: googlebot-mobile\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'MSN Search':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: MSNBot\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Yahoo':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Slurp\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Yahoo MM':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: yahoo-mmcrawler\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Yahoo Blogs':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: yahoo-blogs/v3.9\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Ask/Teoma':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Teoma\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'GigaBlast':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Gigabot\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'DMOZ Checker':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Robozilla\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Nutch':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Nutch\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Alexa/Wayback':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: ia_archiver\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Baidu':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: baiduspider\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'Naver':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: naverbot\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        case 'MSN PicSearch':
          this.robotsTxtData = this.robotsTxtData + `\nUser-agent: psbot\n`
          element.allow.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
          });
          element.disallowed.forEach(path => {
            this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
          });
          element.sameAsDefault.forEach(path => {
            this.sameAsDefaultFormate(path, element);
          });
          break;

        default:
          break;
      }
    });
    this.addCrawlDelay();
  }

  sameAsDefaultFormate(path: any, element: any) {
    if (this.generateUrlList.length > 0) {
      this.sameAsDefaultpathSetList.push(path);
    }
    this.sameAsDefaultpathSetListSorted = [...new Set(this.sameAsDefaultpathSetList)];
  }

  addCrawlDelay() {
    this.crawlDelay = this.pathList.get('crawlDelay').value ? `\nCrawl-delay: ${this.pathList.get('crawlDelay').value}\n` : "";
    this.addSiteMapUrl();
  }

  addSiteMapUrl() {
    this.siteMapUrlForm.get('arr').value.forEach((item) => {
      this.finalSiteMap = this.finalSiteMap.concat(item.siteMapUrl ? `sitemap: ${item.siteMapUrl}\n` : "");
    })
    this.onClickCheckResult();
  }

  createItem(): FormGroup {
    return this.FormBuilder.group({
      siteMapUrl: ''
    });
  }
  addItem(): void {
    const addresses = this.siteMapUrlForm.get('arr') as FormArray; // Get the FormArray
    addresses.push(this.createItem()); // Push a new item into the FormArray
  }
  get arr(): FormArray {
    return this.siteMapUrlForm.get('arr') as FormArray;
  }
  onRemoveAddress(index: number): void {
    const addresses = this.siteMapUrlForm.get('arr') as FormArray;
    addresses.removeAt(index);
  }

  sameAsDefaultPathSet() {
    // const sameAsDefaultTxtData = '\nUser-agent: *\n\nAllow: /'
    this.sameAsDefaultpathSetListSorted.map((path) => {
      return this.sameAsDefaultpathSet = this.sameAsDefaultpathSet + `\n${this.generateUrlList[0].default}: /${path}`
    });
    this.defaultPathList = '\nUser-agent: *\n\nAllow: /' + `${this.sameAsDefaultpathSet}\n`
    if (this.sameAsDefaultpathSet === "" || this.generateUrlList[0].default === undefined) {
      this.preViewdata = '\nUser-agent: *\n\nAllow: /'

    }
  }

  defaultChangeReset() {
    this.pathList.get('crawlDelay').reset();
    this.pathList.get('selectedPathList').reset();
    this.siteMapUrlForm.reset();
    this.preViewdata = ''
    this.robotTxtGrid();
  }

  robotReset() {
    this.robotTxtGrid();
    this.pathList.reset();
    this.siteMapUrlForm.reset();
    this.preViewdata = ''
    const arr = <FormArray>this.siteMapUrlForm.controls.arr;
    arr.clear()
    arr.push(new FormGroup({
      siteMapUrl: new FormControl(null)
    }));

  
  }

  onClickCheckResult() {
    this.sameAsDefaultPathSet();
    if (this.generateUrlList[0].default === '' || this.generateUrlList[0].default === null) {
      this.preViewdata = this.robotsTxtData + this.crawlDelay + this.finalSiteMap;
    }
    else if (this.generateUrlList[0].default === 'Allow' || this.generateUrlList[0].default === 'Disallow') {
      this.preViewdata = this.defaultPathList + this.crawlDelay + this.finalSiteMap;
    }
  }

  robotTXTcreated() {
    const projectDetails = this._shareService.getDataprotool("selectedProjectChooseData");
    if (this.preViewdata === '' || this.preViewdata === null || this.preViewdata === undefined) {
      alerts('Please review the results before generating the robots.txt file.');
    } else {
      let path = this._shareService.getDataprotool("selectedProjectChooseData").awspace + `/src/robots.txt`;
      this._shareService.writeRobotsTxt(path, new Blob([this.preViewdata], { type: "application/txt" })).subscribe(res => {
        if (res['status'] == 200){
          let obj={
            "projectPath": projectDetails['awspace'],
            "projectId": projectDetails.projectId,
            "filePath": `${projectDetails['awspace']}/src/robots.txt`,
            "fileName": "robots.txt ",
            "usrId": projectDetails['userId']
          }
          this._shareService.saveFileInfo(obj).subscribe((res:any)=>{})
          this.toastNotification("success", res["msg"])
        } 
        else this.toastNotification("alert", res["msg"])
      });
    }
  }
  toastNotification(type, msg) {
    this.toast.launch_toast({
      type: type,
      position: "bottom-right",
      message: msg,
    });
  }
}
