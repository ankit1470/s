import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MetaDataGridRoutingModule } from './meta-data-grid-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MetaDataGridRoutingModule
  ]
})
export class MetaDataGridModule { }
