import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { DialogService } from 'primeng/primeng';
import { TempPageModalComponent } from '../../sdmtTools/template-pages/temp-page-modal/temp-page-modal.component';
import { ToastService } from 'src/app/core/services/toast.service';
declare var SdmtGridT;
declare var alerts;
declare var ButtonComponent;

@Component({
  selector: 'app-meta-data-grid',
  templateUrl: './meta-data-grid.component.html',
  styleUrls: ['./meta-data-grid.component.scss']
})
export class MetaDataGridComponent implements OnInit {
  @Input() projectInfo: any;
  @Output() metaRowData = new EventEmitter<object>();
  @Input() metaDataRowGrid: any
  gridData_metaGrid: any;
  gridDynamicObj_metaGrid: any;
  rowData_metaGrid: any = [];
  columnData_metaGrid: any = [
    {
      hidden: false,
      editable: "false",
      filter: false,
      search: false,
      component: "label",
      field: "sno",
      freezecol: "left",
      width: "50px",
      header: "S.No",
      "text-align": "center",
    },
    {
      header: "URL",
      field: "metaUrl",
      filter: false,
      width: "140px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "left",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    // {
    //   header: "Status",
    //   field: "status",
    //   filter: false,
    //   width: "100px",
    //   editable: "false",
    //   "text-align": "left",
    //   search: false,
    //   component: "iconLabel",
    //   cellRenderView: true,
    //   freezecol: "left",
    //   hidden: false,
    //   sort: false,
    //   cellHover: false,

    // },
    {
      header: "Title",
      field: "title",
      filter: false,
      width: "300px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "left",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Description",
      field: "desc",
      filter: false,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: true,
      freezecol: "left",
      hidden: false,
      sort: false,
      cellHover: false,
    },

    {
      header: "Route From",
      field: "route_from",
      filter: false,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Route To",
      field: "module",
      filter: false,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Route From path",
      field: "frmroute",
      filter: false,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: true,
      sort: false,
      cellHover: false,
    },
    {
      header: "Route To Path",
      field: "srcpath",
      filter: false,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: true,
      sort: false,
      cellHover: false,
    },
    // {
    //   header: "Data",
    //   field: "data",
    //   filter: true,
    //   width: "200px",
    //   editable: "false",
    //   "text-align": "left",
    //   search: true,
    //   component: "label",
    //   cellRenderView: false,
    //   freezecol: "null",
    //   hidden: false,
    //   sort: false,
    //   cellHover: false,
    // },
    {
      "header": "Meta JSON",
      "field": "show",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "dynamicComponent",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button":{
        classes: ['btn', 'btn-primary'],
        styles: { 'padding': '0px !important', 'font-size': '11px !important' } 
      },
    },
  ];

  constructor(
    private dialogService: DialogService,
    private toast : ToastService
  ) { }

  ngOnInit() {
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.metaDataRowGrid && this.metaDataRowGrid && this.metaDataRowGrid.length > 0) {

      for (let index = 0; index < this.metaDataRowGrid.length; index++) {
        const element = this.metaDataRowGrid[index];
        if (JSON.parse(element.meta).length) {
          element['show'] = 'Show';
        } else{
          element['show'] = 'Add';
        }
        element['dynamicCompName_show'] = 'dynamicButton';
        element['dynamicCompCellRenderView_show'] = true;
      }

      this.rowData_metaGrid = this.metaDataRowGrid
      this.metaGrid();
    }
  }

  metaGrid(colData?: any, rowData?: any) {
    let self = this;

    this.gridData_metaGrid = {
      columnDef: colData ? colData : this.columnData_metaGrid,
      rowDef: rowData ? rowData : this.rowData_metaGrid,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,
      // frezzManager: {"sno":"left","metaUrl":"left","title":"left","status":"left"},
      components: {},//'dynamicComponent': daynamicComp
      callBack: {
        "onDynamicButton_show":function (ele, param) {
          if (ele.target.innerText == "Add") {
            self.onbundlegriddblClick();
          }else{
            self.gridDynamicObj_metaGrid.selectedRowINdex = param.rowIndex
            let selectedRow = self.gridDynamicObj_metaGrid.getSeletedRowData();
            if (selectedRow !== null) {
              self.openMetaJson(JSON.parse(selectedRow.meta), 'show');
            }
          }
          
        },
        "onButton_show": function (ele, param) {
          self.gridDynamicObj_metaGrid.selectedRowINdex = param.rowIndex
          let selectedRow = self.gridDynamicObj_metaGrid.getSeletedRowData();
          if (selectedRow !== null) {
            self.openMetaJson(JSON.parse(selectedRow.meta), 'show');
          }
        },
        onCellClick: function (ele) {
          self.onbundlegridCellClick();
        },
        onRowClick: function () {
          self.onbundlegridClick();
        },
        onRowDbleClick: function () {
          self.onbundlegriddblClick();
        }
      },
      rowCustomHeight: 20
    }

    let sourceDiv = document.getElementById("seoMetaGrid");
    if (sourceDiv != null) {
      this.gridDynamicObj_metaGrid = SdmtGridT(sourceDiv, this.gridData_metaGrid, true, true);
      self.setColorOnGrid();
    }
  }

  setColorOnGrid() {
    let self = this;
    let gridRowsData = self.gridDynamicObj_metaGrid.sagGridObj.originalRowData;
    gridRowsData.forEach((ele, index) => {
      let checkarr: any;
      checkarr = JSON.parse(ele.meta)
      if (checkarr.length == 0) {
        // self.designObj.gridDynamicObj.setColRowProperty(index, 'required', { "background": "#f8d7da" });
        self.gridDynamicObj_metaGrid.setRowProperty(index, { "background": "#34384899" });
      }
    });
  }

  openMetaJson(data: any, btnMode: any, name?: any, themecssdetId?: any, themecssId?: any, value?: any) {
    const ref = this.dialogService.open(TempPageModalComponent, {
      header: '                       ',
      width: '90%',
      contentStyle: { "box-shdow": "none" },
      styleClass: "validation_comp_data modal-compdata",
      data: {
        item: data,
        buttonMode: btnMode,
        label: name,
        themecssdetId: themecssdetId,
        themecssId: themecssId,
        value: value
      }
    });
    ref.onClose.subscribe((res) => {
      if (res) { }
    });
  }

  onbundlegriddblClick() {
    let selectedRow = JSON.parse(JSON.stringify(this.gridDynamicObj_metaGrid.getSeletedRowData()));
    if (selectedRow)
      selectedRow.meta = JSON.parse(selectedRow.meta)
    this.metaRowData.emit(selectedRow);
  }
  onbundlegridClick() { }
  onbundlegridCellClick() { }

  addMetaThroughMenu() {
    let element = document.getElementById("metathroughmenu");
    if(element['value']) {
      let selectedRow =  JSON.parse(JSON.stringify(this.metaDataRowGrid[Number(element['value'])-1]));
      if (selectedRow)
        selectedRow.meta = JSON.parse(selectedRow.meta)
        this.metaRowData.emit(selectedRow);
    } else {
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Please select menu first!!`,
      })
    }
  }


}
