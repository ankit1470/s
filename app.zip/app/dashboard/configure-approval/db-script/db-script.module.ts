import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DbScriptRoutingModule } from './db-script-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DbScriptRoutingModule
  ]
})
export class DbScriptModule { }
