import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-db-script',
  templateUrl: './db-script.component.html',
  styleUrls: ['./db-script.component.scss']
})
export class DbScriptComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
