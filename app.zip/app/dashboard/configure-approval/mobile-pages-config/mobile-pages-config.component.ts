import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/primeng';
import { SagShareService } from 'src/app/services/sagshare.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
declare var $: any;
declare var SdmtGridT;
declare function alerts(m: any): any;
declare function success(m: any): any;
@Component({
  selector: 'app-mobile-pages-config',
  templateUrl: './mobile-pages-config.component.html',
  styleUrls: ['./mobile-pages-config.component.scss']
})
export class MobilePagesConfigComponent implements OnInit {

  constructor(
    public modalRef: DynamicDialogRef,
    private shareService: SagShareService,
    public config: DynamicDialogConfig,
    private sagStudioService : SagStudioService
  ) {

  }

  extraPageList : any = []
  extraPageListGroupBy : any = []
  selectedModule : any = ''
  gridData_mobilepages: any;
  gridDynamicObj_mobilepages: any;
  columnData_mobilepages: any = [
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "sno",
      freezecol: "null",
      width: "50px",
      header: "S.No",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: true,
      search: true,
      component: "label",
      field: "module_name",
      freezecol: "null",
      width: "250px",
      header: "Module Name",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: true,
      search: true,
      component: "label",
      field: "extpages_name",
      freezecol: "null",
      width: "250px",
      header: "Mobile Page Name",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: true,
      search: true,
      component: "label",
      field: "extpages_path",
      freezecol: "null",
      width: "350px",
      header: "Mobile Page Path",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: true,
      search: true,
      component: "checkbox",
      cellRenderView : true,
      field: "extpages_status",
      freezecol: "null",
      width: "250px",
      header: "Set as Default",
      "text-align": "left",
    }
  ]
  rowData_mobilepages: any = [];

  ngOnInit() {
    let selectedProject = this.shareService.getDataprotool("selectedProjectChooseData")
    this.shareService.getExtraPageList(selectedProject.projectId).then((res:any) => {
      this.extraPageList = res.pageList;
      this.rowData_mobilepages = res.pageList;
      this.groupWiseData();
      this.mobilepages()
    })
  }

  ngAfterViewInit() {
    document.getElementById("allmpages")['checked'] = true;
  }

  mobilepages(rowData?: any, colData?: any) {
    let self = this;

    this.gridData_mobilepages = {
      columnDef: colData ? colData : this.columnData_mobilepages,
      rowDef: rowData ? rowData : this.rowData_mobilepages,
      footer_hide: true,
      totalNoOfRecord_hide: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      newPagination: false,
      recordPerPage: 10,
      ellipsisV: {},
      components: {},
      callBack: {
        "onCellClick": function (ele: any, param: any) {
          self.onmobilepagesCellClick();
        },
        "onRowClick": function () {
          self.onmobilepagesClick();
        },
        "onRowDbleClick": function () {
          self.onmobilepagesdblClick();
        },
        "onCheckBox_extpages_status":function (ele,param) {
          self.checkBoxClick(ele,param);
        },
      }
      ,

      rowCustomHeight: 20,
      plusButton_obj: {},
    };
    let sourceDiv = document.getElementById("mobilepages");
    if (sourceDiv != null) this.gridDynamicObj_mobilepages = SdmtGridT(sourceDiv, this.gridData_mobilepages, true, true);
  }


  checkBoxClick(ele: any, param : any) {
    if(!this.selectedModule) {
      let val = this.extraPageListGroupBy.filter(res => res.key == param.rowValue.module_name)
      this.rowData_mobilepages = val[0].value
      this.selectedModule = val[0].key
      document.getElementById("allmpages")['checked'] = false;
      this.mobilepages()
    }
  }

  onmobilepagesCellClick() { }

  onmobilepagesClick() { }

  onmobilepagesdblClick() { }

  onChangeModule(event:any) {
    if(event.target.value) {
      let val = this.extraPageListGroupBy.filter(res => res.key == event.target.value)
      this.rowData_mobilepages = val[0].value
    } else {
      this.rowData_mobilepages = []
    }
    document.getElementById("allmpages")['checked'] = false
    this.mobilepages()
  }
  
  onChangeAllPages(event:any) {
    if(event.target.checked) {
      this.rowData_mobilepages = this.extraPageList;
    } else {
      this.rowData_mobilepages = []
    }
    this.selectedModule = ''
    this.mobilepages()
  }

  saveMobileStatus() {
    let checkedValue = this.gridDynamicObj_mobilepages.sagGridObj.rowDef.filter(res => JSON.parse(res.extpages_status));
    if(this.selectedModule) {
      let modId = this.extraPageListGroupBy.filter(res => res.key == this.selectedModule)
      if(checkedValue.length <= 1) {
        let selectedProject = this.shareService.getDataprotool("selectedProjectChooseData")
        let postObj = {
          extraPageId : checkedValue.length ? checkedValue[0].extpages_id : 0,
          moduleId : modId[0].value[0].module_id,
          projectId : selectedProject.projectId
        }
        this.shareService.updateExtraPageStatus(postObj).then((res:any) => {
          console.log(res);
          success("Status updated successfully!")
        })
      } else {
        alerts("Can not check more the one checbox to save default mobile page!")
      }
    } else {
      alerts("Kindly click on checkbox to update the value!")
    }
  }

  groupWiseData() {
    let obj = {}
    for(let i = 0 ; i < this.extraPageList.length; i++) {
      let data = this.extraPageList[i];
      if(obj[data.module_name]) {
        obj[data.module_name].push(data);
      } else {
        obj[data.module_name] = [data]
      }
    }
    Object.keys(obj).forEach((item:any, index:any) => {
      this.extraPageListGroupBy.push({key : item, value : obj[item]});
    });
  }
}
