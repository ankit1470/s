import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MobilePagesConfigRoutingModule } from './mobile-pages-config-routing.module';
import { MobilePagesConfigComponent } from './mobile-pages-config.component';
import { SharedModule } from 'src/app/core/shared/shared.module';


@NgModule({
  declarations: [MobilePagesConfigComponent],
  imports: [
    CommonModule,
    MobilePagesConfigRoutingModule,
    SharedModule
  ],
  exports : [MobilePagesConfigComponent]
})
export class MobilePagesConfigModule { }
