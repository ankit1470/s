import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MobilePagesConfigComponent } from './mobile-pages-config.component';

const routes: Routes = [{ path: '', component: MobilePagesConfigComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MobilePagesConfigRoutingModule { }
