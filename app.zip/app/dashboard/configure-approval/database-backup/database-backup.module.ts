import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DatabaseBackupRoutingModule } from './database-backup-routing.module';
import { DatabaseBackupComponent } from './database-backup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';



@NgModule({
  declarations: [DatabaseBackupComponent],
  imports: [
    CommonModule,
    DatabaseBackupRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DropdownModule
  ],
  exports:[DatabaseBackupComponent]
})
export class DatabaseBackupModule { }
