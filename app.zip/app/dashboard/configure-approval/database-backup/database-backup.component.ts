import { Component, OnInit, AfterViewInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { DialogService, DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';

import { ApiServiceService } from 'src/app/services/http/api-service.service';

import { DomSanitizer } from '@angular/platform-browser';

import { Router } from '@angular/router';

import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';

import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';

import {  FormBuilder } from '@angular/forms';

declare var $: any;
declare var SdmtGridT;
declare var ButtonComponent;
declare var SagGridMPT; // Module Work
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var ui;
@Component({
  selector: 'app-database-backup',
  templateUrl: './database-backup.component.html',
  styleUrls: ['./database-backup.component.scss']
})
export class DatabaseBackupComponent implements OnInit {
  dbConnection: any;
  databaseConnForm : any;
  projectList: any = []
  _projectList_: any;
  
  projectStatus = {
    projectCategoryName: '',
    projectCategoryList: '',
    projectTableChildData : '',
    projectTableData : '',
  }
  constructor( public cdref: ChangeDetectorRef,
    private _shareService: SagShareService,
    public dialogService: DialogService,
    private _apiService: ApiServiceService,
    private dbcomparetoolService: ProcomparetoolService,
    public sanitizer: DomSanitizer,
    public _router: Router,
    public toast: ToastService,
    public studioDragDropService: CommonStudioDragDropService,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private FormBuilder: FormBuilder,) { }

  ngOnInit() {
    this.databaseConnForm = this.FormBuilder.group({
      vendor: ['MySQL'],
      databaseName: [''],
      hostName: ['localhost'],
      portNumber: ['3306'],
      userName: ['root'],
      password: ['root'],
    });
    
    this.getTableData();
    this.getProjectBundleList();
    this.dbConnection = this._shareService.getDatadbtool("finalDataForConnection") && this._shareService.getDatadbtool("finalDataForConnection").srcDataSource;
    this.databaseConnForm.setValue(this.dbConnection);
    this.demo1()
  }

  credentials : any;
  databaseCopy(){

    const arrTbl = [];
    for (let index = 0; index < this.dataArr.length; index++) {
      const element = this.dataArr[index];
      arrTbl.push(element.TableName)
      
    }
    // alert(arrTbl);
    const _reqJson = {
         "arrTable": arrTbl,
         "credential":this.credentials
    }
    this._shareService.projectDataBaseTableCopy(_reqJson).subscribe(response =>{
      if (response["rslt"]) { //response["status"] == "true"
        success(response['msg']);
      }else if (response["status"] == "failure") {
        alerts(response['msg'])
      }
    }, error => {
      alerts("Error While copy");
    });

  }

 _startDataBaseCopy() {
  
   
  // this.databaseConnForm.setValue(this.dbConnection);
    const _prjDetails_New = this.projectList.find(_itm => _itm.projectId == this.projectStatus.projectCategoryList);
    const _prjTableData = this.tabledataArr.find(_itm => _itm.tableId == this.projectStatus.projectTableData);
    const _prjTableChildData = this.tablechildDataArr.find(_itm => _itm.tblstrctId == this.projectStatus.projectTableChildData);
    if (!_prjDetails_New) {
      alerts('Please Select At Least One Project ..!!!');
      return;
    }

    // console.log( this.dbConnection);


    const _reqJson = {
      // "prjNm": _prjDetails_New['projectname'],
      "prjId": _prjDetails_New['projectId'],
      "tblNm": _prjTableData['tableName'],
      "tblColNm": _prjTableChildData['tblstrctColname'],
      "vendor" : this.databaseConnForm.controls['vendor'].value,
      "userName" : this.databaseConnForm.controls['userName'].value,
      "portNumber" : this.databaseConnForm.controls['portNumber'].value,
      "password" : this.databaseConnForm.controls['password'].value,
      "databaseName" : this.databaseConnForm.controls['databaseName'].value,
      "hostName" : this.databaseConnForm.controls['hostName'].value,
    }
    // alert('Please _reqJson .....'+_reqJson['prjId']+' -  '+_reqJson['tblNm']+'  -  '+_reqJson['tblColNm']);        
    this._shareService.projectDataBaseCopy(_reqJson).subscribe(response =>{
      if (response["rslt"]) { //response["status"] == "true"
        success(response['msg']);
        this.credentials = response["credentials"];
        debugger
        this.rowData_demo1 = [];
        for (let index = 0; index < response["gridData"].length; index++) {
          const element = response["gridData"][index];
          
          let obj = {
            "TableId": element.tableId,
            "TableName": element.tableName,
            "TableExportFlag":element.ImportTable=='Yes' ? 'Yes' : 'No',
            "TableRecordCount":parseInt(element.recordCount) > 0 ? element.recordCount : '-'
          };
          this.rowData_demo1.push(obj)
        }
        this.demo1();
      }
      else if (response["status"] == "failure") {
        alerts(response['msg'])
      }
    }, error => {
      alerts("Error While copy");
    });
         
    // this.demo1();
  }


  dataArr:any;
  gridData_demo1:any;
  gridDynamicObj_demo1: any;
 columnData_demo1: any = [ 
   {"header":"Check",
     "field":"checkbox",
     "filter":true,
     "width":"150px",
     "editable":"false",
     "text-align":"center",
     "search":true,
     "component":"headerCheckBox",
     "cellRenderView":true,
     "freezecol":"null",
     "hidden":false,
     "sort":false,
     "cellHover":false,     
     },
 {"hidden":false,
 "editable":"false",
 "filter":true,
 "search":true,
 "component":"label",
 "field":"sno",
 "freezecol":"null",
 "width":"120px",
 "header":"S.No",
 "text-align":"left",
 
 }, 
 {"header":"TableId",
 "field":"TableId",
 "filter":true,
 "width":"250px",
 "editable":"false",
 "text-align":"left",
 "search":true,
 "component":"label",
 "cellRenderView":false,
 "freezecol":"null",
 "hidden":true,
 "sort":false,
 "cellHover":false,
 
 }, 
 {"header":"TableName",
 "field":"TableName",
 "filter":true,
 "width":"300px",
 "editable":"false",
 "text-align":"left",
 "search":true,
 "component":"label",
 "cellRenderView":false,
 "freezecol":"null",
 "hidden":false,
 "sort":false,
 "cellHover":false,
 
 }, 
 {"header":"TableExportFlag",
   "field":"TableExportFlag",
   "filter":true,
   "width":"250px",
   "editable":"false",
   "text-align":"left",
   "search":true,
   "component":"label",
   "cellRenderView":false,
   "freezecol":"null",
   "hidden":false,
   "sort":false,
   "cellHover":false,
   
   }, 
   {"header":"TableRecordCount",
     "field":"TableRecordCount",
     "filter":true,
     "width":"250px",
     "editable":"false",
     "text-align":"left",
     "search":true,
     "component":"label",
     "cellRenderView":false,
     "freezecol":"null",
     "hidden":false,
     "sort":false,
     "cellHover":false,
     
     }, 
 ];
  
 rowData_demo1: any = [
 // {
 // "Column2": "1",
 // "Column3": "5"
 // },
 // {
 // "Column2": "2",
 // "Column3": "6"
 // },
 // {
 // "Column2": "2",
 // "Column3": "7"
 // },
 // {
 // "Column2": "4",
 // "Column3": "8"
 // }
 
 ];
 validationdemo1: any = {}
 
 demo1(rowData?:any,colData?:any) {
 let self = this;
 
 
 // let mobileWebItem = this.common.getEnvironment();
 
 this.gridData_demo1 = {
 columnDef: colData ? colData : this.columnData_demo1,
 rowDef: rowData ? rowData :this.rowData_demo1,
 footer_hide: false,
 totalNoOfRecord_hide: false,
 sml_expandGrid_hide: false,
 exportXlsxPage_hide: false,
 exportXlsxAllPage_hide: false,
 exportPDFLandscape_hide: false,
 exportPDFPortrait_hide: false,
 ariaHidden_hide: false,
 disableAllSearch: false,
 wordBreak: false,
 wordBreakHeader: false,
 cellHover: false,
 rowHover: false,
 rowBorder_hide: false,
 columnBorder_hide: false,
 header_hide: false,
 gridbody_hide: false,
 rowLineSpace: 0,
 multiHeader: false,
 common_search: false,
 common_search_column: "",
 common_filter: false,
 common_filter_column: "",
 validation:this.validationdemo1,
 newPagination:true,
 recordPerPage:10,
 // exportBtn:(mobileWebItem == 'mobile') ? false : false  ,
 newExpandExportTotalRecord_hide:undefined,
 
 // commonSearchSelect_hide:(mobileWebItem == 'mobile') ? false : false  ,
 // commonFilterSelect_hide:(mobileWebItem == 'mobile') ? false : false  ,
 // orderArray : (mobileWebItem == 'mobile')?["sno","column2","Column3"]:["sno","Column2","Column3"],
 ellipsisV:{},
 gridRowAddDeleteButton:"undefined",
 components : {},
 callBack: {
 
 "onCellClick": function(ele:any) {
 
   self.ondemo1CellClick();
   },
   "onRowClick": function() {
   self.ondemo1Click();
  },
  "onRowDbleClick": function() {
  self.ondemo1dblClick();
  },
  "onHeaderCheckBox_checkbox": function(ele, gridObj) {
 //  alert('hello Rh');
  
  console.log(self.gridDynamicObj_demo1.getCheckedDataParticularColumnWise());
  self.dataArr = self.gridDynamicObj_demo1.getCheckedDataParticularColumnWise()
  },
  "onCheckBox_checkbox": function(ele, gridObj) {
   console.log(self.gridDynamicObj_demo1.getCheckedDataParticularColumnWise());
   self.dataArr = self.gridDynamicObj_demo1.getCheckedDataParticularColumnWise()
   },
  
 }
 ,
 
 rowCustomHeight: 20,
 plusButton_obj:  {},
 
 
 
 
 };
 
 let sourceDiv = document.getElementById("demo1");
 this.gridDynamicObj_demo1 = SdmtGridT(sourceDiv, this.gridData_demo1, true, true);
 }
 
 ondemo1CellClick(){debugger
 console.log(this.gridDynamicObj_demo1.getCheckedDataParticularColumnWise())
 }
 
 ondemo1Click(){
 debugger
 console.log(this.gridDynamicObj_demo1.getCheckedDataParticularColumnWise())
 }
 
 ondemo1dblClick(){
 debugger
 console.log(this.gridDynamicObj_demo1.getCheckedDataParticularColumnWise())
 }
 
 //------------second------------
 
 
 dataArr1:any;
 gridData_demo2:any;
 gridDynamicObj_demo2: any;
 columnData_demo2: any = [ 
  {"header":"Check",
    "field":"checkbox",
    "filter":true,
    "width":"100px",
    "editable":"false",
    "text-align":"center",
    "search":true,
    "component":"headerCheckBox",
    "cellRenderView":true,
    "freezecol":"null",
    "hidden":false,
    "sort":false,
    "cellHover":false,     
    },
 {"hidden":false,
 "editable":"false",
 "filter":true,
 "search":true,
 "component":"label",
 "field":"sno",
 "freezecol":"null",
 "width":"50px",
 "header":"S.No",
 "text-align":"left",
 
 }, 
 {"header":"Project Name",
 "field":"ProjectNm",
 "filter":true,
 "width":"100px",
 "editable":"false",
 "text-align":"left",
 "search":true,
 "component":"label",
 "cellRenderView":false,
 "freezecol":"null",
 "hidden":true,
 "sort":false,
 "cellHover":false,
 
 }, 
 {"header":"Status",
 "field":"Status",
 "filter":true,
 "width":"100px",
 "editable":"false",
 "text-align":"left",
 "search":true,
 "component":"label",
 "cellRenderView":false,
 "freezecol":"null",
 "hidden":false,
 "sort":false,
 "cellHover":false,
 
 }, 
 {"header":"Complete Date",
  "field":"CompleteDate",
  "filter":true,
  "width":"100px",
  "editable":"false",
  "text-align":"left",
  "search":true,
  "component":"label",
  "cellRenderView":false,
  "freezecol":"null",
  "hidden":false,
  "sort":false,
  "cellHover":false,
  
  }, 
  {"header":"DownloadLink",
    "field":"DownloadLink",
    "filter":true,
    "width":"100px",
    "editable":"false",
    "text-align":"left",
    "search":true,
    "component":"label",
    "cellRenderView":false,
    "freezecol":"null",
    "hidden":false,
    "sort":false,
    "cellHover":false,
    
    }, 
 ];
 
 rowData_demo2: any = [
 // {
 // "Column2": "1",
 // "Column3": "5"
 // },
 // {
 // "Column2": "2",
 // "Column3": "6"
 // },
 // {
 // "Column2": "2",
 // "Column3": "7"
 // },
 // {
 // "Column2": "4",
 // "Column3": "8"
 // }
 
 ];
 validationdemo2: any = {}
 
 demo2(rowData?:any,colData?:any) {
 let self = this;
 
 
 // let mobileWebItem = this.common.getEnvironment();
 
 this.gridData_demo2 = {
 columnDef: colData ? colData : this.columnData_demo2,
 rowDef: rowData ? rowData :this.rowData_demo2,
 footer_hide: false,
 totalNoOfRecord_hide: false,
 sml_expandGrid_hide: false,
 exportXlsxPage_hide: false,
 exportXlsxAllPage_hide: false,
 exportPDFLandscape_hide: false,
 exportPDFPortrait_hide: false,
 ariaHidden_hide: false,
 disableAllSearch: false,
 wordBreak: false,
 wordBreakHeader: false,
 cellHover: false,
 rowHover: false,
 rowBorder_hide: false,
 columnBorder_hide: false,
 header_hide: false,
 gridbody_hide: false,
 rowLineSpace: 0,
 multiHeader: false,
 common_search: false,
 common_search_column: "",
 common_filter: false,
 common_filter_column: "",
 validation:this.validationdemo2,
 newPagination:true,
 recordPerPage:10,
 // exportBtn:(mobileWebItem == 'mobile') ? false : false  ,
 newExpandExportTotalRecord_hide:undefined,
 
 // commonSearchSelect_hide:(mobileWebItem == 'mobile') ? false : false  ,
 // commonFilterSelect_hide:(mobileWebItem == 'mobile') ? false : false  ,
 // orderArray : (mobileWebItem == 'mobile')?["sno","column2","Column3"]:["sno","Column2","Column3"],
 ellipsisV:{},
 gridRowAddDeleteButton:"undefined",
 components : {},
 callBack: {
 
 "onCellClick": function(ele:any) {
 
  self.ondemo2CellClick();
  },
  "onRowClick": function() {
  self.ondemo2Click();
 },
 "onRowDbleClick": function() {
 self.ondemo2dblClick();
 },
 "onHeaderCheckBox_checkbox": function(ele, gridObj) {
 alert('hello Rh');
 
 console.log(self.gridDynamicObj_demo2.getCheckedDataParticularColumnWise());
 self.dataArr = self.gridDynamicObj_demo2.getCheckedDataParticularColumnWise()
 },
 "onCheckBox_checkbox": function(ele, gridObj) {
  console.log(self.gridDynamicObj_demo2.getCheckedDataParticularColumnWise());
  self.dataArr = self.gridDynamicObj_demo2.getCheckedDataParticularColumnWise()
  },
 
 }
 ,
 
 rowCustomHeight: 20,
 plusButton_obj:  {},
 };
 let sourceDiv = document.getElementById("demo2");
 this.gridDynamicObj_demo2 = SdmtGridT(sourceDiv, this.gridData_demo2, true, true);
 }
 
 ondemo2CellClick(){debugger
 console.log(this.gridDynamicObj_demo2.getCheckedDataParticularColumnWise())
 }
 
 ondemo2Click(){
 console.log(this.gridDynamicObj_demo2.getCheckedDataParticularColumnWise())
 }
 
 ondemo2dblClick(){
 console.log(this.gridDynamicObj_demo2.getCheckedDataParticularColumnWise())
 }
 
 getProjectBundleList() {
  const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
  const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
  this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
    (response: any) => {
      if (response) {
        this.projectList = response["data"];
        this._projectList_ = response["data"].map(_item => {
          let _newItem = _item;
          _newItem['label'] = _item['projectname'],
            _newItem['value'] = _item['projectId']
          return _newItem
        })
      }
    }
  );
}

tabledataArr : any;
getTableData() {    
  this.dbcomparetoolService.getTableDataProj().subscribe(
    (response: any) => {
      if (response) {
        this.tabledataArr = response["data"];
        this.tabledataArr = response["data"].map(_item => {
          let _newItem = _item;
          _newItem['label'] = _item['tableName'],
            _newItem['value'] = _item['tableId']
          return _newItem
        })
      }
    }
  );
}

 
tablechildDataArr : any;
getTableChildData(id) {
  this.dbcomparetoolService.getTableChildDataProj(id).subscribe(
    (response: any) => {
      if (response) {
        this.tablechildDataArr = response["data"];
        this.tablechildDataArr = response["data"].map(_item => {
          let _newItem = _item;
          _newItem['label'] = _item['tblstrctColname'],
            _newItem['value'] = _item['tblstrctId']
          return _newItem
        })
      }
    }
  );
}

closeModel() {
  this.modalRef.close(true);
}
}
