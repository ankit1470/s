import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [{ path: 'databaseBackup', loadChildren: () => import('./database-backup/database-backup.module').then(m => m.DatabaseBackupModule) }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigureApprovalRoutingModule { }
