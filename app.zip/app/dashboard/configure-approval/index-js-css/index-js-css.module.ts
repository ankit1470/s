import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IndexJsCssRoutingModule } from './index-js-css-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    IndexJsCssRoutingModule
  ]
})
export class IndexJsCssModule { }
