import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { SagShareService } from 'src/app/services/sagshare.service';
import { DropEffect, DndDropEvent } from 'ngx-drag-drop';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/primeng';
import { FormBuilder } from '@angular/forms';
import { ToastService } from 'src/app/core/services/toast.service';
import { AddIndexHtmlLinkScriptComponent } from '../add-index-html-link-script/add-index-html-link-script.component';
import { ApiServiceService } from 'src/app/services/http/api-service.service';
declare var SdmtGridT: any;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-index-js-css',
  templateUrl: './index-js-css.component.html',
  styleUrls: ['./index-js-css.component.scss'],
  providers: [DialogService]
})
export class IndexJsCssComponent implements OnInit {

  fileTypeContent: any = []
  totalFileTypeContent: any = []
  fileTypeIndex: number = 0;
  totalFileTypeIndex: number = 0;
  js:any={};
  jsBody:any=[];
  css:any={};
  projectInfo:any;
  constructor(private shareService:SagShareService,
    public cdref: ChangeDetectorRef,
    public dialogService: DialogService,
    public studioDragDropService: CommonStudioDragDropService,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public toast: ToastService,
    private FormBuilder: FormBuilder,
    private _apiService: ApiServiceService
  ) { 
    // this.css['filePath']=[]
    // this.css['fileId']=[]
    // this.js['filePath']=[]
    // this.js['fileId']=[]
  }
  ngOnInit() {
    this.projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    this.getUsedCssJsProject()
    this.totalCssJs()
    // this.allCssJs();
  }

  totalCssJs(){
    this.shareService.getAllCssJs().subscribe((res:any)=>{
      this.totalFileTypeContent[0] = res['CSS']
      this.totalFileTypeContent[1] = res['JS']
      this.allCssJs(this.totalFileTypeContent[0])
    })
  }

  getUsedCssJsProject() {
    let selectedProject: any = this.shareService.getDataprotool("selectedProjectChooseData")
    let obj = {
      projectId: selectedProject.projectId
    }
    this.shareService.getUsedCssJsProject(obj).subscribe((res: any) => {
      res.map((x)=>(x.fileCount == 1 || x.fileCount > 1) ? x['selected'] = true : x['selected'] = false)

      this.fileTypeContent[0] = res.filter((x) =>x.type == 'CSS')
      this.fileTypeContent[1] = res.filter((x) => x.type == 'JS' && x.fileName != 'cordova.js' && x.fileName != 'plugin.js')

    })
  }

  saveList() {
    this.css['filePath']=[];
    this.css['fileId']=[];
    this.js['filePath'] =[];
    this.js['fileId'] =[];
    this.jsBody =[];

    this.fileTypeContent[0].filter((css:any)=>{
      if(css.selected == true){
        const link = `<link rel="stylesheet" href="${css.filePath}">`
        this.css['filePath'].push(link)
        this.css['fileId'].push(css.fileCode)
      }
    })

    this.fileTypeContent[1].filter((js:any)=>{
      if(js.selected == true){
        if(js.filePath == 'assets/SdmtGrid/js/gridOnload/gridOnload.js'){
          this.jsBody.push(`<script src="${js.filePath}"></script>`)
          this.js['fileId'].push(js.fileCode)
        }else{
          const link = `<script src="${js.filePath}"></script>`
          this.js['filePath'].push(link)
          this.js['fileId'].push(js.fileCode)
        }
      }
    })
    let fileId:any = this.css['fileId'].concat(this.js['fileId']) 
    let obj={
      "projectPath":this.projectInfo.awspace,
      "projectId":this.projectInfo.projectId,
      "cssList":this.css['filePath'],
      "jsList":this.js['filePath'],
      "fileIds":fileId,
      "jsbodyList":this.jsBody,
    }

    this.shareService.generateIndexHtml(obj).subscribe((res:any)=>{
      this.toast.launch_toast({
        type: "success",
        position: "bottom-right",
        message: res["msg"],
      });
    })
  }

  onMovePosition(event: DndDropEvent, list, currentIndex) {
    if (event.data) {
      let index = list.findIndex((m) => m.fileCode == event.data.fileCode);
      if (index == -1) {
        return this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: `DOESN'T MOVE OUT OF BLOCK`,
        });
      } else {
        list.splice(index, 1);
        (index > currentIndex) ? list.splice(currentIndex + 1, 0, event.data) : list.splice(currentIndex, 0, event.data);
      }
    }
  }

  deleteMenu(item, ind) {
    item.fileCount = 0;
    // arrObj.splice(ind, 1);
  }

  addMenu(item, indexHtmlObj, ind) {
    const ref = this.dialogService.open(AddIndexHtmlLinkScriptComponent, {
      header: 'Index Html Link Script Component',
      width: '30%',
      data: { "list": indexHtmlObj, "index": ind }
    });
    ref.onClose.subscribe((res: any) => {
    })
  }

  addSelectedCssJs(event:any,item:any){
    event == true ? item['selected'] = true : item['selected'] = false;
  }
  showTotalCssJS(type:any,ind:any){
    this.allCssJs(this.totalFileTypeContent[ind])
    // this.totalFileTypeIndex = ind
  }

  gridData_allCssJs: any;
  gridDynamicObj_allCssJs: any;
  columnData_allCssJs: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "File Name",
      "field": "fname",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File Code",
      "field": "fcode",
      "filter": true,
      "width": "120px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File Path",
      "field": "filePath",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_allCssJs: any = [
    {},
    {},
    {},
    {}
  ];
  validationallcssjs: any = {}

  allCssJs(rowData?: any, colData?: any) {
    let self = this;
    this.gridData_allCssJs = {
      columnDef: colData ? colData : this.columnData_allCssJs,
      rowDef: rowData ? rowData : this.rowData_allCssJs,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationallcssjs,
      newPagination: false,
      recordPerPage: 10,
      exportBtn: false,
      newExpandExportTotalRecord_hide: undefined,

      commonSearchSelect_hide: false,
      commonFilterSelect_hide: false,
      orderArray: ["sno","fname","fcode","filePath"],
      ellipsisV: {},
      gridRowAddDeleteButton: "undefined",
      components: {},
      callBack: {
      }
      ,

      rowCustomHeight: 20,
      plusButton_obj: {},




    };
    let sourceDiv: any;
     sourceDiv = document.getElementById("allCssJs");
    this.gridDynamicObj_allCssJs = SdmtGridT(sourceDiv, this.gridData_allCssJs, true, true);
  }


}
