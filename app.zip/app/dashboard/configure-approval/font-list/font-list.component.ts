import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';

declare var $: any;
declare var SdmtGridT;
declare var ButtonComponent;
declare var SagGridMPT; // Module Work
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;

@Component({
  selector: 'app-font-list',
  templateUrl: './font-list.component.html',
  styleUrls: ['./font-list.component.scss']
})
export class FontListComponent implements OnInit {

  fontListContent = 1;
  constructor(
    public cdref: ChangeDetectorRef,
    private _shareService: SagShareService,
    public _router: Router,
    public toast: ToastService,
    public studioDragDropService: CommonStudioDragDropService,
    public sagStudioService: SagStudioService
  ) { }

  ngOnInit() {
    this.availableInProject();
  }

  availableInProject() {
    let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    let dataObj = {
      "projectPath": seletedObj.awspace,
      "type": "PROJ"
    }
    this._shareService.getDefaultfontList(dataObj).subscribe(res => {
      this.rowData_availableinproject = res['project'];
      this.availableinproject();
    })
  }

  // Function for delete the fonts
  deleteFonts() {
    let selectedData = [];
    this.gridDynamicObj_availableinproject.sagGridObj.rowData.forEach(sel => {
      if (sel.Column2 && sel.Column2 == 1) {
        selectedData.push(sel.filePath.split('/')[1]);
      }
    })
    let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    let dataObj = {
      "projectPath": seletedObj.awspace,
      "fontList": selectedData
    }
    this._shareService.deleteProjectFont(dataObj).subscribe(res => {
      this.toast.launch_toast({
        type: res['status'],
        position: 'bottom-right',
        message: res['msg'],
      });
      if (res['status'] == 'success') {
        this.availableInProject()
      }
    })
  }

  libraryFontMethod() {
    let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    let dataObj = {
      "projectPath": seletedObj.awspace,
      "type": "LIB"
    }
    this._shareService.getDefaultfontList(dataObj).subscribe(res => {
      this.rowData_libraryfonts = res['library'];
      this.libraryfonts();
    })

  }

  importFontInProject() {
    let selectedLibraryData = [];
    this.gridDynamicObj_libraryfonts.sagGridObj.rowData.forEach(sel => {
      if (sel.selected && sel.selected == 1) {
        selectedLibraryData.push(sel)
      }
    })
    let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    let dataObj = {
      "projectPath": seletedObj.awspace,
      "fonts": selectedLibraryData
    }
    this._shareService.copyFontInProject(dataObj).subscribe(res => {
      this.toast.launch_toast({
        type: 'success',
        position: 'bottom-right',
        message: 'Imported Successfully!!!...',
      });
    })
  }


  // Grid Making

  gridData_libraryfonts: any;
  gridDynamicObj_libraryfonts: any;
  columnData_libraryfonts: any = [
    {
      "header": "",
      "field": "selected",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "headerCheckBox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    {
      "hidden": false,
      "editable": "false",
      "filter": false,
      "search": false,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "100px",
      "header": "S.No",
      "text-align": "center"
    },
    {
      "header": "Font name",
      "field": "fontName",
      "filter": false,
      "width": "87%",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    // {
    //   "header": "File path",
    //   "field": "filePath",
    //   "filter": true,
    //   "width": "300px",
    //   "editable": "false",
    //   "text-align": "left",
    //   "search": true,
    //   "component": "label",
    //   "cellRenderView": false,
    //   "freezecol": "null",
    //   "hidden": false,
    //   "sort": false,
    //   "cellHover": false
    // },
    // {
    //   "header": "Font class",
    //   "field": "fontclass",
    //   "filter": true,
    //   "width": "400px",
    //   "editable": "false",
    //   "text-align": "left",
    //   "search": true,
    //   "component": "label",
    //   "cellRenderView": false,
    //   "freezecol": "null",
    //   "hidden": false,
    //   "sort": false,
    //   "cellHover": false
    // },
  ];

  rowData_libraryfonts: any = [
    {},
    {},
    {},
    {}
  ];

  libraryfonts(rowData?, colData?) {
    let self = this;
    let columnDataLibraryfonts
    columnDataLibraryfonts = this.columnData_libraryfonts
    this.gridData_libraryfonts = {
      columnDef: colData ? colData : columnDataLibraryfonts,
      rowDef: rowData ? rowData : this.rowData_libraryfonts,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onlibraryfontsCellClick();
        },
        "onRowClick": function () {
          self.onlibraryfontsClick();
        },
        "onRowDbleClick": function () {
          self.onlibraryfontsdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };
    let sourceDiv
    sourceDiv = document.getElementById("libraryfonts");
    if (sourceDiv != null) {
      this.gridDynamicObj_libraryfonts = SdmtGridT(sourceDiv, this.gridData_libraryfonts, true, true);
    }
  }

  onlibraryfontsCellClick() {

  }

  onlibraryfontsClick() {

  }

  onlibraryfontsdblClick() {

  }



  // Availabele in Project Grid
  gridData_availableinproject: any;
  gridDynamicObj_availableinproject: any;
  columnData_availableinproject: any = [
    {
      "header": "",
      "field": "Column2",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "headerCheckBox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    {
      "hidden": false,
      "editable": "false",
      "filter": false,
      "search": false,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "100px",
      "header": "S.No",
      "text-align": "center"
    },
    {
      "header": "Font name",
      "field": "fontName",
      "filter": false,
      "width": "87%",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_availableinproject: any = [
    {},
    {},
    {},
    {}
  ];

  availableinproject(rowData?, colData?) {
    let self = this;
    let columnData
    columnData = this.columnData_availableinproject
    this.gridData_availableinproject = {
      columnDef: colData ? colData : columnData,
      rowDef: rowData ? rowData : this.rowData_availableinproject,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("availableinprojectFonts");
    if (sourceDiv != null) {
      this.gridDynamicObj_availableinproject = SdmtGridT(sourceDiv, this.gridData_availableinproject, true, true);
    }
  }

  onavailableinprojectCellClick() {

  }

  onavailableinprojectClick() {

  }

  onavailableinprojectdblClick() {

  }

}
