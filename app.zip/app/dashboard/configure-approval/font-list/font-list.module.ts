import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FontListRoutingModule } from './font-list-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FontListRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class FontListModule { }
