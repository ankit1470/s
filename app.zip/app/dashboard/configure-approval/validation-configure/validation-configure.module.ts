import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ValidationConfigureRoutingModule } from './validation-configure-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ValidationConfigureRoutingModule
  ]
})
export class ValidationConfigureModule { }
