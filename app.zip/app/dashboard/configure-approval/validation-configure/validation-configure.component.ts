
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { ToastService } from 'src/app/core/services/toast.service';
import { SagShareService } from 'src/app/services/sagshare.service';

@Component({
  selector: 'app-validation-configure',
  templateUrl: './validation-configure.component.html',
  styleUrls: ['./validation-configure.component.scss']
})
export class ValidationConfigureComponent implements OnInit {

  angularValueForm: FormGroup;

  constructor(private sagshare: SagShareService,
    private fb: FormBuilder,
    public _toast: ToastService) {
    this.angularValueForm = this.fb.group({
      angular: this.fb.array([]),
      css: this.fb.array([]),
      java: this.fb.array([]),
      image: this.fb.array([])
    });
  }

  getValueOfFields(item: any) {
    let value;
    if (item.vldctrl == 'Toggle' || item.vldctrl == 'TOGGLE') {
      if (item.prjval == 'y' || item.prjval == 'Y') {
        value = true;
      }
      else {
        value = false;
      }
    }
    else if(item.vldctrl == 'MULTISELECT') {
      let a = item.prjval;
      let multiList = [];
        a.map(x=>{
          multiList.push(x.value);
        })
        value = multiList;
    }
    else  {
       value = item.prjval;
    
    }
    return value;
  }

  createItemGroup(item: any, name): FormGroup {
    const group = {
      vldId: item.techvldId,
      vldctrl: item.vldctrl,
      [`${name}InputValue`]: [this.getValueOfFields(item)],
    };

    return this.fb.group(group);
  }


  ngOnInit() {
    this.getValidationConfigureData();
  }

  initializeForm() {
    if (this.resData && this.resData.angular) {
      const controlArray = this.angularValueForm.get('angular') as FormArray;
      this.resData.angular.forEach(item => {
        controlArray.push(this.createItemGroup(item, 'angular'));
      });
    }
    if (this.resData && this.resData.css) {
      const controlArray = this.angularValueForm.get('css') as FormArray;
      this.resData.css.forEach(item => {
        controlArray.push(this.createItemGroup(item, 'css'));
      });
    }
    if (this.resData && this.resData.java) {
      const controlArray = this.angularValueForm.get('java') as FormArray;
      this.resData.java.forEach(item => {
        controlArray.push(this.createItemGroup(item, 'java'));
      });
    }
    if (this.resData && this.resData.image) {
      const controlArray = this.angularValueForm.get('image') as FormArray;
      this.resData.image.forEach(item => {
        controlArray.push(this.createItemGroup(item, 'image'));
      });
      console.log(this.angularValueForm.get("image").value, "a  ");
    }
  }



  onToggleChange(event: Event, val: any) {
    const isChecked = (event.target as HTMLInputElement).checked;
    this.angularValueForm.patchValue({ angularInputValue: isChecked ? val[0] : val[1] });
    this.angularValueForm.patchValue({ cssInputValue: isChecked ? val[0] : val[1] });
    this.angularValueForm.patchValue({ javaInputValue: isChecked ? val[0] : val[1] });
    this.angularValueForm.patchValue({ imageInputValue: isChecked ? val[0] : val[1] });
  }

  onMultiSelectChange(event: any) {
    const selectedValues = event.value;
    this.angularValueForm.patchValue({ angularInputValue: selectedValues });
    this.angularValueForm.patchValue({ cssInputValue: selectedValues });
    this.angularValueForm.patchValue({ javaInputValue: selectedValues });
    this.angularValueForm.patchValue({ imageInputValue: selectedValues });
  }

  onSubmit(name: any) {
    console.log(this.angularValueForm.value);
    this.saveValidationConfigureData(name);
  }

  obj: any = {
       "projectId": this.sagshare.getDataprotool("selectedProjectChooseData")['projectId']
      
   
  }



  resData: any;
  async getValidationConfigureData() {
    const commonValidationConfiguration = await this.sagshare.getValidationConfigureData(this.obj).toPromise();

      this.resData = commonValidationConfiguration;
      if (this.resData.hasOwnProperty('java')) {
        this.resData['java'].map((x) => {
          x.vldctrl == 'TOGGLE' ? x.vldval = JSON.parse(x.vldval) : x.vldval = x.vldval;
        })
      }
      if (this.resData.hasOwnProperty('angular')) {
        this.resData['angular'].map((x) => {
          x.vldctrl == 'TOGGLE' ? x.vldval = JSON.parse(x.vldval) : x.vldval = x.vldval;
        })
      }
      if (this.resData.hasOwnProperty('css')) {
        this.resData['css'].map((x) => {
          x.vldctrl == 'TOGGLE' ? x.vldval = JSON.parse(x.vldval) : x.vldval = x.vldval;
        })
      }
      if (this.resData.hasOwnProperty('image')) {
        this.resData['image'].map((x) => {
          x.vldctrl == 'TOGGLE' ? x.vldval = JSON.parse(x.vldval) : x.vldval = x.vldval;
        })
      }
      this.initializeForm();
  }

  getObjectForSave(val: any[], name) {
    let resList = [];
    val.forEach(ele => {
      if(ele.vldctrl === "MULTISELECT"){
        let list = [];
        ele[`${name}InputValue`].forEach(ele=>{
          let obj = {
            label : ele,
            value : ele
          };
          
           list.push(obj);
        });
        let msdata = JSON.stringify(list);
        ele[`${name}InputValue`] = msdata;
      }
      const saveObj = {
     
        "data": ele.vldctrl === "TOGGLE" ? ele[`${name}InputValue`] === true ? "Y" : "N" : ele[`${name}InputValue`],
        "vldid": ele.vldId != null ? ele.vldId : ""
      }
      resList.push(saveObj);
    });
    return resList;
  }

  saveValidationConfigureData(name) {
    const saveObj = {
      "projectId": this.sagshare.getDataprotool("selectedProjectChooseData")['projectId'],
      "codevalList": this.getObjectForSave(this.angularValueForm.value[`${name}`], name)
    }
    console.log(saveObj, "saveObj")
    if (saveObj.codevalList.length > 0) {
      this.sagshare.saveValidationConfigureData(saveObj).subscribe(res => {
        this._toast.launch_toast({
          type: `${res["status"] == 200 || res["status"] == 'success' ? "success" : "alert"}`,
          position: 'bottom-right',
          message: `${res['message']}`
        });
        if(res["status"] == 200 || res["status"] == 'success'){
        let data = {
          projectId: this.sagshare.getDataprotool("selectedProjectChooseData")['projectId'],
          projectPath : this.sagshare.getDataprotool("selectedProjectChooseData")['awspace']
        }
        this.sagshare.getValidationConfigurationList(data).subscribe(()=>{
            
        })
      }
      });
    }
  }

}
