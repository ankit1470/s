import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectCommonFileRoutingModule } from './project-common-file-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ProjectCommonFileRoutingModule
  ]
})
export class ProjectCommonFileModule { }
