import { ChangeDetectorRef, Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { DynamicDialogRef } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { ApiServiceService } from 'src/app/services/http/api-service.service';
import { SagShareService } from 'src/app/services/sagshare.service';

declare var SdmtGridT;
declare var $: any;

@Component({
  selector: 'app-project-common-file',
  templateUrl: './project-common-file.component.html',
  styleUrls: ['./project-common-file.component.scss']
})
export class ProjectCommonFileComponent implements OnInit {
  selectedRowdata
  moduleListSave: boolean = true
  isDiffEditorOpen = false;
  openHtmlFlag: boolean;
  compareToolDisplay: boolean;
  gridDataModuleList: any;
  gridDynamicObjModuleList: any;
  techVersion = [
    { 'version': 8 },
    { 'version': 17 }
  ]  
  projectInfo: any = null
  rowDataModuleList: any

  constructor(
    private _shareService: SagShareService,
    public toast: ToastService,
    public cdref: ChangeDetectorRef,
    private _apiService: ApiServiceService,
    public modalRef: DynamicDialogRef,
  ) { }

  ngOnInit() {
    this.projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
    this.getModuleLIst() 
  }

  getModuleLIst() {
    let version = this._shareService['data']['angversnObj']['angular']
    let prjDetails = {
      "projectId": this.projectInfo.projectId,
      "projectPath": this.projectInfo.awspace,
      "ngver": `${version.split(".")[0]}`,
    }
    this._apiService.getModuleList(prjDetails).subscribe(res => {
      this.rowDataModuleList = res
      this.createModuleListGrid()
    })
  }

  columnDataModuleList: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": false,
      "search": false,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "62px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "File Name",
      "field": "moduleName",
      "filter": false,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Module Path",
      "field": "modulePath",
      "filter": false,
      "width": "180px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Last Modified",
      "field": "lastModified",
      "filter": false,
      "width": "180px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Tech Version",
      "field": "techversion",
      "filter": false,
      "width": "180px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Project File Version",
      "field": "fileVersion",
      "filter": false,
      "width": "180px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Latest File Version",
      "field": "latestfilever",
      "filter": false,
      "width": "180px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Compare",
      "field": "compare",
      "filter": false,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Compare", "classes": ["btn", "btn-info", "w-70"], "attribute": "", "styles": "" },

    },

  ];

  createModuleListGrid(rowData?: any, colData?: any) {
    let self = this;

    this.gridDataModuleList = {
      columnDef: colData ? colData : this.columnDataModuleList,
      rowDef: rowData ? rowData : this.rowDataModuleList,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      newExpandExportTotalRecord_hide: undefined,
      ellipsisV: {},
      gridRowAddDeleteButton: "undefined",
      components: {},
      callBack: {
        "onButton_compare": function (ele, params) {
          self.compareCommonFiles(params)
        },
        "onCellClick": function (ele: any) {
          self.onModuleListCellClick();
        },
        "onRowClick": function () {
          self.onModuleListRowClick();
        },
        "onRowDbleClick": function () {
          self.onModuleListdblClick();
        },
      },
      rowCustomHeight: 20,
      plusButton_obj: {},
    };

    let sourceDiv = document.getElementById("moduleListGrid");
    this.gridDynamicObjModuleList = SdmtGridT(sourceDiv, this.gridDataModuleList, true, true);
  }
  onModuleListCellClick() {
  }
  onModuleListdblClick() {
  }
  onModuleListRowClick() {
    this.selectedRowdata = this.gridDynamicObjModuleList.getSeletedRowData();
    if (!this.selectedRowdata) {
      this.moduleListSave = true
      return
    }
    this.moduleListSave = false
  }
  compareCommonFiles(params) {
    let EndpathArray = params.rowValue.modulePath
    let index = EndpathArray.indexOf('src');
    let newEndPath = EndpathArray.slice(index)
    let moduleName = params.rowValue.moduleName
    this.getCompareFileCode(newEndPath, moduleName)
  }


  getCompareFileCode(newEndPath, fileName) {
    let version = this._shareService['data']['angversnObj']['angular']
    const files = {
      "projectPath": this.projectInfo.awspace,
      "ngver": `${version.split(".")[0]}`,
      "fileName": fileName
    }
    this._shareService.getFileCompareData(files).subscribe(
      (response: any) => {
        if (response) {
          this._shareService.setDataprotool("leftSideCode", response.actcontent);
          this._shareService.setDataprotool("rightSideCode", response.defcontent);
          this._shareService.setDataprotool("filePathEditorDiff", {
            path: `${this.projectInfo.awspace}/${newEndPath}`,
            projectpath: undefined
          });
          this.openHtmlFlag = false;
          this.compareToolDisplay = true;
          this.cdref.detectChanges();
          this.compareToolDisplay ? $("#VscodecompareToolCommonFile").modal('show') : false;

        }
      })
  }


  saveModuleList() {
    let { moduleName, modulePath } = this.selectedRowdata
    let version = this._shareService['data']['angversnObj']['angular']
    const saveModulePath = {
      "filePath": `${this.projectInfo.awspace}/${modulePath}`,
      "ngver": `${version.split(".")[0]}`,
      "name": moduleName
    }
    this._apiService.saveModuleList(saveModulePath).subscribe(res => {
      if (res['status'] === 'success') this.toastNotifications('success', res['msg'])
      else this.toastNotifications('alert', res['msg'])
    })
  }
  
  toastNotifications(msgType, msg) {
    this.toast.launch_toast({
      type: msgType,
      position: 'bottom-right',
      message: msg
    })
  }
  closeModal() {
    this.modalRef.close(false);
  }

}
