import { Component, OnInit, AfterViewInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { DialogService, DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { DatabaseConnectionComponent } from '../database-connection/database-connection.component';
import { ApiServiceService } from 'src/app/services/http/api-service.service';
import { apiConstant } from 'src/app/config/apiconfig';
import { DomSanitizer } from '@angular/platform-browser';
import { ChooseProjectComponent } from '../choose-project/choose-project.component';
import { Router } from '@angular/router';
// import { CreateProjectComponent } from 'src/app/modules/database/project-utility-tool/procompare-tool/pmt/create-project/create-project.component';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { MappingControlsComponent } from 'src/app/modules/sag-studio/property-window/mapping-controls/mapping-controls.component';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { CreateProjectStepperComponent } from '../create-project-stepper/create-project-stepper.component';
import { ImportExportMappingComponent } from '../import-export-mapping/import-export-mapping.component';
// import * as xml2js from 'xml2js';
// import { Calendar } from 'primeng/calendar';
import { CopyContentComponent } from './copy-content/copy-content.component';
// import { NotificationComponent } from 'src/app/core/shared/components/notification/notification.component';
import { FormControl, FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { VoiceControlComponent } from 'src/app/modules/sag-studio/voice-control/voice-control.component';
import { DbcomparetoolFirststepService } from 'src/app/services/database/dbcomparetool-firststep.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { MetaDataComponent } from './meta-data/meta-data.component';
import { SiteMapComponent } from './site-map/site-map.component';
import { RobotsTxtGeneratorComponent } from './robots-txt-generator/robots-txt-generator.component';

declare var $: any;
declare var SdmtGridT;
declare var ButtonComponent;
declare var SagGridMPT; // Module Work
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var ui;
@Component({
  host: { class: 'd-flex flex-column h-100' },
  selector: 'app-configure-approval',
  templateUrl: './configure-approval.component.html',
  styleUrls: ['./configure-approval.component.scss'],
  providers: [DialogService]
})
export class ConfigureApprovalComponent implements OnInit, AfterViewInit {
  // radioValue : any = 'static'
  // metaInfo : any = { route_from : '', route_to : '', pageRoute : ''}
  // metaSectionCheck : boolean = true
  // disableModify : boolean = false

  userId: number = 1;
  projectInfo: any = {};
  selectedLangArray: any = [];
  filteredLangList: any = [];
  ldvfilteredLangList: any = [];
  savedLangList: any = [];
  outdatedLangList: any = [];
  getUserWiseLocalProjectPathResponce: any;
  urlSafe: any;
  files: any;
  dbConnection: any;
  className: string = '';
  tranlateLanguage: boolean = false;
  ldvtranlateLanguage: boolean = false;
  selectedProject: any;
  selectedItem: any;
  _oldNewMenudetIds: any;
  frontendViewMore: boolean = true;
  BackendViewMore: boolean = false;
  versionListViewMore: boolean = false;
  projectTypeViewMore: boolean = false;
  configDataList: any = [];
  alertsmg:any;
  languageList: any = [
    {
      "label": "Afrikaans",
      "value": "af",
      "i18nJson": {

      }
    },
    {
      "label": "Albanian",
      "value": "sq",
      "i18nJson": {

      }
    },
    {
      "label": "Amharic",
      "value": "am",
      "i18nJson": {

      }
    },
    {
      "label": "Arabic",
      "value": "ar",
      "i18nJson": {

      }
    },
    {
      "label": "Armenian",
      "value": "hy",
      "i18nJson": {

      }
    },
    {
      "label": "Azerbaijani",
      "value": "az",
      "i18nJson": {

      }
    },
    {
      "label": "Basque",
      "value": "eu",
      "i18nJson": {

      }
    },
    {
      "label": "Belarusian",
      "value": "be",
      "i18nJson": {

      }
    },
    {
      "label": "Bengali",
      "value": "bn",
      "i18nJson": {

      }
    },
    {
      "label": "Bosnian",
      "value": "bs",
      "i18nJson": {

      }
    },
    {
      "label": "Bulgarian",
      "value": "bg",
      "i18nJson": {

      }
    },
    {
      "label": "Catalan",
      "value": "ca",
      "i18nJson": {

      }
    },
    {
      "label": "Cebuano",
      "value": "ceb",
      "i18nJson": {

      }
    },
    {
      "label": "Chichewa",
      "value": "ny",
      "i18nJson": {

      }
    },
    {
      "label": "Chinese Simplified",
      "value": "zh-CN",
      "i18nJson": {

      }
    },
    {
      "label": "Chinese Traditional",
      "value": "zh-TW",
      "i18nJson": {

      }
    },
    {
      "label": "Corsican",
      "value": "co",
      "i18nJson": {

      }
    },
    {
      "label": "Croatian",
      "value": "hr",
      "i18nJson": {

      }
    },
    {
      "label": "Czech",
      "value": "cs",
      "i18nJson": {

      }
    },
    {
      "label": "Danish",
      "value": "da",
      "i18nJson": {

      }
    },
    {
      "label": "Dutch",
      "value": "nl",
      "i18nJson": {

      }
    },

    {
      "label": "Esperanto",
      "value": "eo",
      "i18nJson": {

      }
    },
    {
      "label": "Estonian",
      "value": "et",
      "i18nJson": {

      }
    },
    {
      "label": "Filipino",
      "value": "tl",
      "i18nJson": {

      }
    },
    {
      "label": "Finnish",
      "value": "fi",
      "i18nJson": {

      }
    },
    {
      "label": "French",
      "value": "fr",
      "i18nJson": {

      }
    },
    {
      "label": "Frisian",
      "value": "fy",
      "i18nJson": {

      }
    },
    {
      "label": "Galician",
      "value": "gl",
      "i18nJson": {

      }
    },
    {
      "label": "Georgian",
      "value": "ka",
      "i18nJson": {

      }
    },
    {
      "label": "German",
      "value": "de",
      "i18nJson": {

      }
    },
    {
      "label": "Greek",
      "value": "el",
      "i18nJson": {

      }
    },
    {
      "label": "Gujarati",
      "value": "gu",
      "i18nJson": {

      }
    },
    {
      "label": "Haitian Creole",
      "value": "ht",
      "i18nJson": {

      }
    },
    {
      "label": "Hausa",
      "value": "ha",
      "i18nJson": {

      }
    },
    {
      "label": "Hawaiian",
      "value": "haw",
      "i18nJson": {

      }
    },
    {
      "label": "Hebrew",
      "value": "iw",
      "i18nJson": {

      }
    },
    {
      "label": "Hindi",
      "value": "hi",
      "i18nJson": {

      }
    },
    {
      "label": "Hmong",
      "value": "hmn",
      "i18nJson": {

      }
    },
    {
      "label": "Hungarian",
      "value": "hu",
      "i18nJson": {

      }
    },
    {
      "label": "Icelandic",
      "value": "is",
      "i18nJson": {

      }
    },
    {
      "label": "Igbo",
      "value": "ig",
      "i18nJson": {

      }
    },
    {
      "label": "Indonesian",
      "value": "id",
      "i18nJson": {

      }
    },
    {
      "label": "Irish",
      "value": "ga",
      "i18nJson": {

      }
    },
    {
      "label": "Italian",
      "value": "it",
      "i18nJson": {

      }
    },
    {
      "label": "Japanese",
      "value": "ja",
      "i18nJson": {

      }
    },
    {
      "label": "Javanese",
      "value": "jw",
      "i18nJson": {

      }
    },
    {
      "label": "Kannada",
      "value": "kn",
      "i18nJson": {

      }
    },
    {
      "label": "Kazakh",
      "value": "kk",
      "i18nJson": {

      }
    },
    {
      "label": "Khmer",
      "value": "km",
      "i18nJson": {

      }
    },
    {
      "label": "Korean",
      "value": "ko",
      "i18nJson": {

      }
    },
    {
      "label": "Kurdish (Kurmanji)",
      "value": "ku",
      "i18nJson": {

      }
    },
    {
      "label": "Kyrgyz",
      "value": "ky",
      "i18nJson": {

      }
    },
    {
      "label": "Lao",
      "value": "lo",
      "i18nJson": {

      }
    },
    {
      "label": "Latin",
      "value": "la",
      "i18nJson": {

      }
    },
    {
      "label": "Latvian",
      "value": "lv",
      "i18nJson": {

      }
    },
    {
      "label": "Lithuanian",
      "value": "lt",
      "i18nJson": {

      }
    },
    {
      "label": "Luxembourgish",
      "value": "lb",
      "i18nJson": {

      }
    },
    {
      "label": "Macedonian",
      "value": "mk",
      "i18nJson": {

      }
    },
    {
      "label": "Malagasy",
      "value": "mg",
      "i18nJson": {

      }
    },
    {
      "label": "Malay",
      "value": "ms",
      "i18nJson": {

      }
    },
    {
      "label": "Malayalam",
      "value": "ml",
      "i18nJson": {

      }
    },
    {
      "label": "Maltese",
      "value": "mt",
      "i18nJson": {

      }
    },
    {
      "label": "Maori",
      "value": "mi",
      "i18nJson": {

      }
    },
    {
      "label": "Marathi",
      "value": "mr",
      "i18nJson": {

      }
    },
    {
      "label": "Mongolian",
      "value": "mn",
      "i18nJson": {

      }
    },
    {
      "label": "Myanmar (Burmese)",
      "value": "my",
      "i18nJson": {

      }
    },
    {
      "label": "Nepali",
      "value": "ne",
      "i18nJson": {

      }
    },
    {
      "label": "Norwegian",
      "value": "no",
      "i18nJson": {

      }
    },
    {
      "label": "Pashto",
      "value": "ps",
      "i18nJson": {

      }
    },
    {
      "label": "Persian",
      "value": "fa",
      "i18nJson": {

      }
    },
    {
      "label": "Polish",
      "value": "pl",
      "i18nJson": {

      }
    },
    {
      "label": "Portuguese",
      "value": "pt",
      "i18nJson": {

      }
    },
    {
      "label": "Punjabi",
      "value": "ma",
      "i18nJson": {

      }
    },
    {
      "label": "Romanian",
      "value": "ro",
      "i18nJson": {

      }
    },
    {
      "label": "Russian",
      "value": "ru",
      "i18nJson": {

      }
    },
    {
      "label": "Samoan",
      "value": "sm",
      "i18nJson": {

      }
    },
    {
      "label": "Scots Gaelic",
      "value": "gd",
      "i18nJson": {

      }
    },
    {
      "label": "Serbian",
      "value": "sr",
      "i18nJson": {

      }
    },
    {
      "label": "Sesotho",
      "value": "st",
      "i18nJson": {

      }
    },
    {
      "label": "Shona",
      "value": "sn",
      "i18nJson": {

      }
    },
    {
      "label": "Sindhi",
      "value": "sd",
      "i18nJson": {

      }
    },
    {
      "label": "Sinhala",
      "value": "si",
      "i18nJson": {

      }
    },
    {
      "label": "Slovak",
      "value": "sk",
      "i18nJson": {

      }
    },
    {
      "label": "Slovenian",
      "value": "sl",
      "i18nJson": {

      }
    },
    {
      "label": "Somali",
      "value": "so",
      "i18nJson": {

      }
    },
    {
      "label": "Spanish",
      "value": "es",
      "i18nJson": {

      }
    },
    {
      "label": "Sundanese",
      "value": "su",
      "i18nJson": {

      }
    },
    {
      "label": "Swahili",
      "value": "sw",
      "i18nJson": {

      }
    },
    {
      "label": "Swedish",
      "value": "sv",
      "i18nJson": {

      }
    },
    {
      "label": "Tajik",
      "value": "tg",
      "i18nJson": {

      }
    },
    {
      "label": "Tamil",
      "value": "ta",
      "i18nJson": {

      }
    },
    {
      "label": "Telugu",
      "value": "te",
      "i18nJson": {

      }
    },
    {
      "label": "Thai",
      "value": "th",
      "i18nJson": {

      }
    },
    {
      "label": "Turkish",
      "value": "tr",
      "i18nJson": {

      }
    },
    {
      "label": "Ukrainian",
      "value": "uk",
      "i18nJson": {

      }
    },
    {
      "label": "Urdu",
      "value": "ur",
      "i18nJson": {

      }
    },
    {
      "label": "Uzbek",
      "value": "uz",
      "i18nJson": {

      }
    },
    {
      "label": "Vietnamese",
      "value": "vi",
      "i18nJson": {

      }
    },
    {
      "label": "Welsh",
      "value": "cy",
      "i18nJson": {

      }
    },
    {
      "label": "Xhosa",
      "value": "xh",
      "i18nJson": {

      }
    },
    {
      "label": "Yiddish",
      "value": "yi",
      "i18nJson": {

      }
    },
    {
      "label": "Yoruba",
      "value": "yo",
      "i18nJson": {

      }
    },
    {
      "label": "Zulu",
      "value": "zu",
      "i18nJson": {

      }
    }
  ];

  toolUpdateList: any;
  getToolUsedDataList: any;

  isRowView: any = "rowView";
  isColumnView: any;

  // rights on buttons
  treeOptionsData: any[] = [];
  listOfControls = [];
  //Update Available
  updateAvailabel: boolean = false;
  validationOptions = 1;
  // showControlsListInfo:boolean = false;
  // classChanges = 'col-xl-12 col-lg-12 col-md-12';
  // projectIdShowInCSSJSList;
  valdationItem: any
  _projectList_: any;
  // showHtml: boolean = false
  // rowWithoutColVal = []
  // columns: { name: string, value: string }[] = [];
  // selectedTags: any[] = [];
  // tagOptions: any[] = [
  //   { name: 'LASTMOD', value: '' },
  //   { name: 'CHANGEFREQ', value: '' },
  //   { name: 'PRIORITY', value: '' },
  // ];
  // domainName: string
  // locUrl: any[] = []
  // changeFreq = [
  //   'never',
  //   'yearly',
  //   'monthly',
  //   'weekly',
  //   'daily',
  //   'hourly',
  //   'always'
  // ]
  // priority = [
  //   0.0,
  //   0.1,
  //   0.2,
  //   0.3,
  //   0.4,
  //   0.5,
  //   0.6,
  //   0.7,
  //   0.8,
  //   0.9,
  //   1.0
  // ]
  // xml: string;
  // filePath: any
  // checkedXML: boolean = false;
  // calendarIndex = -1
  // previousDomain: any
  // isValidSiteMap = true
  // isCorrectSitemap = false
  // isEmptyCol = false
  // @ViewChild("calendar", { static: false }) private calendars: Calendar;
  isLangWork: boolean = false;
  // dateTime = new Date();
  // isDupUrlExist = false
  // isDomainNameExist = true
  // invalidDomainName = []
  // protocol: string = "https://"
  // isReload = false
  // sitemapData: any;
  // *************
  // routeFileName: string;
  // metaData: any;
  // metaKeywordList: any = [
  //   {
  //     "label": "Select",
  //     "value": ""
  //   },
  //   {
  //     "label": "CHARSET",
  //     "value": "charset"
  //   },
  //   {
  //     "label": "CONTENT",
  //     "value": "content"
  //   },
  //   {
  //     "label": "HTTP-EQUIV",
  //     "value": "http-equiv"
  //   },
  //   {
  //     "label": "ID",
  //     "value": "id"
  //   },
  //   {
  //     "label": "ITEMPROP",
  //     "value": "itemprop"
  //   },
  //   {
  //     "label": "NAME",
  //     "value": "name"
  //   },
  //   {
  //     "label": "PROPERTY",
  //     "value": "property"
  //   },
  //   {
  //     "label": "SCHEME",
  //     "value": "scheme"
  //   },
  //   {
  //     "label": "URL",
  //     "value": "url"
  //   },

  // ];
  // projectInfo1: any;
  // filePath1: string
  // selectedPage: string = ''
  // selectedPath: string = '';
  // startingData = {
  //   'metakey': '',
  //   'metaValue': ''
  // }
  // *************
  // pathList!: FormGroup;
  // public arr: FormArray;
  // generateUrlList: any;
  // googleBot: any = [];
  // robotsTxtData: any
  // sameAsDefaultpathSet: any = `\n`
  // siteMapUrl: any = []
  // siteMapUrlForm: any
  // defaultPathList: any;
  // finalSiteMap = '\n';
  // preViewdata: any;
  // urlPathList: any = []
  // sameAsDefaultpathSetListSorted: any = []
  // sameAsDefaultpathSetList: any = new Set();
  // crawlDelay: any;
  currentPagePathforcompare: string;
  // isSiteMapExist:any;
  // isRobotTxtExist:any;
  getProjectVersions:any;
  getplatform:any;
  showFirst:any=true
  techVersion:any=[]
  // seo page
  @ViewChild(MetaDataComponent, { static: false }) metaDataComponent!: MetaDataComponent; 
  @ViewChild(SiteMapComponent, { static: false }) SiteMapComponent!: SiteMapComponent; 
  @ViewChild(RobotsTxtGeneratorComponent, { static: false }) RobotsTxtGeneratorComponent!: RobotsTxtGeneratorComponent; 
  isSeoTabClick=false


  constructor(
    public cdref: ChangeDetectorRef,
    private _shareService: SagShareService,
    public dialogService: DialogService,
    private _apiService: ApiServiceService,
    private dbcomparetoolService: ProcomparetoolService,
    public sanitizer: DomSanitizer,
    public _router: Router,
    public toast: ToastService,
    public studioDragDropService: CommonStudioDragDropService,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private FormBuilder: FormBuilder,
    public autoJavacodeService:AutoJavacodeService,
    public firststepDbcompareService: DbcomparetoolFirststepService,
  ) {
    const loginUserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    this.projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
    if (loginUserId) {
      this.userId = Number(loginUserId.data.clientInfo.usrId);
      this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(apiConstant.sagTranslateUrl + `?uid=${this.userId}-${this.projectInfo.projectId}`);
    }



  }


  projectStatus = {
    projectCategoryName: '',
    projectCategoryList: '',
    projectTableChildData : '',
    projectTableData : '',
  }
  projectList: any = []


  configureProjectList = [
    // { "pName": "PROJECT INFO", "pCode": "projInfo", "className": "bg-success text-white", "iconName": "fas fa-info-circle" },
    // { "pName": "PROJECT TYPE", "pCode": "projType", "className": "bg-success text-white", "iconName": "fas fa-file" },
    // { "pName": "PROJECT PATH", "pCode": "proPath", "className": "bg-success text-white", "iconName": "fas fa-folder-open" },
    { "pName": "BASIC  INFORMATION", "pCode": "proDetails", "className": "bg-success text-white", "iconName": "fas fa-tasks" },
    { "pName": "DB CONNECTION STRING", "pCode": "dbString", "className": 'bg-success text-white ', "iconName": "fas fa-sitemap" },
    { "pName": "PROJECT FEATURES", "pCode": "proSummary", "className": "bg-success text-white", "iconName": "fas fa-list-alt" },
    // { "pName": "PROJECT DETAILS", "pCode": "proDetails", "className": "bg-success text-white", "iconName": "fas fa-tasks" },
    // { "pName": "PROJECT SUMMARY", "pCode": "proSummary", "className": "bg-success text-white", "iconName": "fas fa-list-alt" },
    { "pName": "UPDATES AVAILABLE", "pCode": "uControl", "className": "bg-success text-white", "iconName": "fas fa-download" },
   

   
    
  
    { "pName": "SEO - OPTIONS", "pCode": "assetsseo", "className": "bg-success text-white", "iconName": "fas fa-edit" },

    // {
    //   "pName": "DEPRECATED", "pCode": "assets", "className": "bg-success text-white", "iconName": "fas fa-edit", "children": [
    //      { "pName": "META TAG", "pCode": "metaData", "className": "bg-success text-white", "iconchildName": "fas fa-file-pdf" },
    //   { "pName": "SITE MAP", "pCode": "sitemap", "className": "bg-success text-white", "iconchildName": "fas fa-map-marker-alt" },
    //      { "pName": "ROBOTS TXT", "pCode": "robotstxt", "className": "bg-success text-white", "iconchildName": "fas fa-search-location" },
    //     { "pName": "SSR", "pCode": "ssr", "className": "bg-success text-white", "iconchildName": "fas fa-file-pdf" },]
    //    ]
    // },
    // { "pName": "SITE MAP", "pCode": "sitemap", "className": "bg-success text-white", "iconName": "fas fa-map-marker-alt" },
    {
      "pName": "ASSETS CONTENT", "pCode": "assets", "className": "bg-success text-white", "iconName": "fas fa-edit", "children": [
        { "pName": "FONT LIST", "pCode": "fontList", "className": 'bg-success text-white ', "iconchildName": "fas fa-list" },
        { "pName": "JS/CSS (COMMON)", "pCode": "indexHtmlContent", "className": 'bg-success text-white ', "iconchildName": "fas fa-code" },
        { "pName": "MEDIA", "pCode": "mediaContent", "className": 'bg-success text-white ', "iconchildName": "fas fa-image" },
        { "pName": "DOCUMENT", "pCode": "docContent", "className": 'bg-success text-white ', "iconchildName": "fas fa-file-pdf" },
        { "pName": "MESSAGE LIST ", "pCode": "messageList", "className": 'bg-success text-white ', "iconchildName": "fas fa-file-pdf" }

      ]
    },
    { "pName": "FORM VALIDATION", "pCode": "frmValidation", "className": "bg-success text-white", "iconName": "fas fa-code" },
    { "pName": "PAGE OPERATIONS", "pCode": "pageOperations", "className": "bg-success text-white", "iconName": "fas fa-wrench" }, 
    { "pName": "MOBILE PAGES", "pCode": "mobilePages", "className": "bg-success text-white", "iconName": "fas fa-mobile" }, 
    { "pName": "PWA", "pCode": "pwa", "className": "bg-success text-white", "iconName": "fas fa-desktop" }, 
    { "pName": "VOICE COMMAND", "pCode": "voiceCmd", "className": "bg-success text-white", "iconName": "fas fa-microphone-alt" },
    // { "pName": "LANGUAGE TRANSLATE(PRE)", "pCode": "langTranslate", "className": "bg-success text-white", "iconName": "fas fa-language" },
    // New list added @rohit_arya
    { "pName": "LANGUAGE TRANSLATE", "pCode": "langLdv", "className": "bg-success text-white", "iconName": "fas fa-language" },
    // { "pName": "THEME [ WEB / MOBILE ](PRE)", "pCode": "themeMob", "className": "bg-success text-white", "iconName": "fas fa-mobile" },
    { "pName": "THEME [ WEB / MOBILE ]", "pCode": "themeMobAdv", "className": "bg-success text-white", "iconName": "fas fa-mobile" },
    // { "pName": "MULTI-PAGES", "pCode": "multiPage", "className": "bg-success text-white", "iconName": "fas fa-file-alt" },

    { "pName": "EXCEL MAPPING", "pCode": "excelMapping", "className": "bg-success text-white", "iconName": "fas fa-industry" },
    { "pName": "TEMPLATE MAPPING", "pCode": "templateMapping", "className": "bg-success text-white", "iconName": "fas fa-file-word" },
    // { "pName": "REPORTING TOOL", "pCode": "reporting", "className": "bg-success text-white", "iconName": "fas fa-file-pdf" },
    { "pName": "LOG CREATION", "pCode": "logCreat", "className": "bg-success text-white", "iconName": "fas fa-user-cog" },
    { "pName": "LOCK MECHANISM", "pCode": "lockMech", "className": "bg-success text-white", "iconName": "fas fa-lock" },
    { "pName": "AUTHORIZATION", "pCode": "auth", "className": "bg-success text-white", "iconName": "fas fa-user-check" },
    {
      "pName": "USER RIGHTS", "pCode": "btnRight", "className": "bg-success text-white", "iconName": "fas fa-user-shield", "children": [
        // { "pName": "Add Rights", "pCode": "btnRight", "className": "bg-success text-white", "iconchildName": "fas fa-user-check"  },
        // { "pName": "Button Rights Dump", "pCode": "btnRight", "className": "bg-success text-white", "iconchildName": "fas fa-toggle-on"  },
        // { "pName": "Form Rights", "pCode": "btnRight", "className": "bg-success text-white", "iconchildName": "fas fa-file-excel" },
        { "pName": "MENU RIGHTS", "pCode": "btnRight", "className": "bg-success text-white", "iconchildName": "fas fa-ellipsis-v" },
        // { "pName": "PAGE Here..", "pCode": "rightsOnButtons", "className": 'bg-success text-white ', "iconchildName": "fas fa-file" }, 
        // { "pName": "Button Rights", "pCode": "buttonRights", "className": 'bg-success text-white ', "iconchildName": "fa fa-user-circle" }, 
        { "pName": "BUTTONS RIGHTS", "pCode": "Rights", "className": 'bg-success text-white ', "iconchildName": "fa fa-user-circle" },
        { "pName": "ACTIVATE BUTTON RIGHTS", "pCode": "activateButtonRights", "className": 'bg-success text-white ', "iconchildName": "fas fa-user-times" },

      ]
    },
    
{
      "pName": "PROJECT-CONTROL PROPERTY RIGHTS", "pCode": "userRole", "className": "bg-success text-white", "iconName": "fas fa-tasks", "children": [
        { "pName": "PARAGRAPH", "pCode": "paragraph", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-paragraph" },
        { "pName": "TEXTBOX", "pCode": "text", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-text-height" },
        { "pName": "PASSWORD", "pCode": "password", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-eye" },
        { "pName": "EMAIL", "pCode": "email", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-envelope" },
        { "pName": "PHONE", "pCode": "phone", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-phone-alt" },
        { "pName": "NUMBER", "pCode": "number", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-sort-numeric-up" },
        { "pName": "AMOUNT", "pCode": "amount", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-sort-amount-up-alt" },
        { "pName": "TEXTAREA", "pCode": "textarea", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-text-width" },
        { "pName": "FILE", "pCode": "file", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-file" },
        { "pName": "CHECKBOX", "pCode": "checkbox", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-check-square" },
        { "pName": "RADIO", "pCode": "radio", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-check-circle" },
        { "pName": "SELECT", "pCode": "select", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-clipboard-check" },
        { "pName": "PCALENDAR", "pCode": "pCalendar", "parent": 'userRole', "className": "bg-secondary text-white", "iconchildName": "fas fa-calendar-alt" },
      ]
    },
   
         
   
   
   
    { "pName": "PROJECT CODE SUMMARY", "pCode": "projectSummary", "className": "bg-success text-white", "iconName": "fa fa-bars" },
    
    {
      "pName": "BUILD", "build": "database", "className": "bg-success text-white", "iconName": "fas fa-project-diagram", "children": [
        { "pName": "DB SCRIPT", "pCode": "dbScript", "className": "bg-success text-white", "iconName": "fa fa-bars" },
        { "pName": "BUILD & DEPLOY", "pCode": "buildNDeploy", "className": "bg-secondary text-white", "iconName": "fas fa-project-diagram" },
        { "pName": "HELP", "pCode": "multiPage", "className": "bg-secondary text-white", "iconName": "fas fa-hands-helping" },
        { "pName": "DOCUMENTATION", "pCode": "multiPage", "className": "bg-secondary text-white", "iconName": "fas fa-book-open" },
        { "pName": "CLIENT DB", "pCode": "viewCode", "className": "bg-secondary text-white", "iconName": "fas fa-server" },
        { "pName": "CLIENT HOSTING", "pCode": "viewCode", "className": "bg-secondary text-white", "iconName": "fas fa-users" },
        { "pName": "DEFAULT VALUES", "pCode": "viewCode", "className": "bg-secondary text-white", "iconName": "fas fa-user-times" },
        { "pName": "GLOBAL PROPERTYS", "pCode": "globalpropertys", "className": "bg-success text-white", "iconName": "fas fa-globe" },
        { "pName": "MANUAL FILES", "pCode": "viewCode", "className": "bg-secondary text-white", "iconName": "fas fa-folder-minus" },
        { "pName": "VIEW CODE", "pCode": "viewCode", "className": "bg-secondary text-white", "iconName": "fas fa-code" }

      ]
    },{
      "pName": "DATABASE", "pCode": "database", "className": "bg-success text-white", "iconName": "fas fa-database", "children": [
        { "pName": "LOG CREATION", "pCode": "logCreat", "className": "bg-secondary text-white", "iconchildName": "fas fa-user-cog" },
        { "pName": "BACKUP – RESTORE", "pCode": "backup", "className": "bg-secondary text-white", "iconchildName": "fas fa-window-restore" },
        { "pName": "DATABASE UTILITY", "pCode": "multiPage", "className": "bg-secondary text-white", "iconchildName": "fas fa-tools" }
      ]
    },
    { "pName": "CODE VALIDATION CONFIGURE", "pCode": "validationConfigure", "className": "bg-success text-white", "iconName": "fa fa-bars" },
    {
      "pName": "PROJECT-CONTROL PROPERTY", "pCode": "controls", "className": "bg-success text-white", "iconName": "fas fa-project-diagram", "children": [
        { "pName": "PARAGRAPH", "pCode": "paragraph", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-paragraph" },
        { "pName": "TEXTBOX", "pCode": "text", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-text-height" },
        { "pName": "PASSWORD", "pCode": "password", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-eye" },
        { "pName": "EMAIL", "pCode": "email", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-envelope" },
        { "pName": "PHONE", "pCode": "phone", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-phone-alt" },
        { "pName": "NUMBER", "pCode": "number", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-sort-numeric-up" },
        { "pName": "AMOUNT", "pCode": "amount", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-sort-amount-up-alt" },
        { "pName": "TEXTAREA", "pCode": "textarea", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-text-width" },
        { "pName": "FILE", "pCode": "file", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-file" },
        { "pName": "CHECKBOX", "pCode": "checkbox", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-check-square" },
        { "pName": "RADIO", "pCode": "radio", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-check-circle" },
        { "pName": "SELECT", "pCode": "select", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-clipboard-check" },
        { "pName": "PCALENDAR", "pCode": "pCalendar", "parent": 'controls', "className": "bg-secondary text-white", "iconchildName": "fas fa-calendar-alt" },
      ]
    },
    {
      "pName": "Adv Operations", "pCode": "advOpt", "className": "bg-success text-white", "iconName": "fas fa-database", "children": [
        { "pName": "UPDATE JAVA VERSION", "pCode": "updateJavaVersion", "className": "bg-success text-white", "iconName": "fa fa-bars" },
        { "pName": "UPDATE JAVA BASE PROJECT", "pCode": "updateJavaBasePro", "className": "bg-success text-white", "iconName": "fa fa-bars" },
        { "pName": "ANGULAR COMMON FILE", "pCode": "moduleList", "className": "bg-success text-white", "iconName": "fa fa-bars" },
        { "pName": "PROJECT-COPY", "pCode": "projectCopy", "className": "bg-success text-white", "iconName": "fas fa-copy" },
        { "pName": "PROJECT-REGENERATE", "pCode": "regenerateCode", "className": "bg-success text-white", "iconName": "fas fa-sync-alt" },
        { "pName": "PROJECT-BACKUP/RESTORE", "pCode": "projectBackupRestore", "className": "bg-success text-white", "iconName": "fas fa-server" },
        { "pName": "VERSION UPDATE", "pCode": "viewCode", "className": "bg-secondary text-white", "iconName": "fas fa-arrow-alt-circle-down" },
        { "pName": "CHANGE TECHNOLOGY*", "pCode": "viewCode", "className": "bg-secondary text-white", "iconName": "fas fa-exchange-alt" },
        { "pName": "MICRO SERVICES", "pCode": "viewCode", "className": "bg-secondary text-white", "iconName": "fas fa-user-cog" },
        { "pName": "GENERATE MAPPING FILE", "pCode": "genMappingFile", "className": "bg-success text-white", "iconName": "fas fa-sync-alt" },
        { "pName": "PROJECT SECURITY", "pCode": "projectSecurity", "className": "bg-success text-white", "iconName": "fas fa-sync-alt" },
      ]
    },
    { "pName": "Key Notes", "pCode": "proCummunity", "className": "bg-success text-white", "iconName": "fas fa-users" },
  { "pName": "Ai Modal", "pCode": "aiModal", "className": "bg-success text-white", "iconName": "fas fa-users" },
    // { "pName": "UPDATE JAVA VERSION", "pCode": "updateJavaVersion", "className": "bg-success text-white", "iconName": "fa fa-bars" },
    // { "pName": "UPDATE JAVA BASE PROJECT", "pCode": "updateJavaBasePro", "className": "bg-success text-white", "iconName": "fa fa-bars" },
   
   

    // { "pName": "SEO - OPTIONS", "pCode": "assetsseo", "className": "bg-success text-white", "iconName": "fas fa-edit" }

    
  ]

  ngOnInit() {
   this.getProjectVersions = this._shareService.getData('angversnObj')
    this.getProjPlatfrm()

    this.newgrid();
    this.isLanguageEnableOnProjectMethod();
    this.ldvtranlateLanguage = true;
    let buttons = document.getElementById("pills-html-tab")
    this.getControlsList()
    this.getProjectBundleList();
    //this.getTreeData()
    this.selectedProject = this._shareService.getDataprotool("selectedProjectChooseData");
    this.selectedItem = { "pName": "BASIC INFORMATION", "pCode": "proDetails" };

    
    this.dbConnection = this._shareService.getDatadbtool("finalDataForConnection") && this._shareService.getDatadbtool("finalDataForConnection").srcDataSource;
    if (this.dbConnection) {
      this.className = 'bg-success';
      for (let index = 0; index < this.configureProjectList.length; index++) {
        const element = this.configureProjectList[index];
        if (element.pCode == 'dbString') {
          element.className = 'bg-success text-white';
        }
      }
    } else {
      this.className = 'bg-danger';
      for (let index = 0; index < this.configureProjectList.length; index++) {
        const element = this.configureProjectList[index];
        if (element.pCode == 'dbString') {
          element.className = 'bg-danger text-white';
        }
      }

    }

    this._apiService.getLangList(this.userId, this.projectInfo.projectId)
      .subscribe((res) => {
        if (res['langList']) {
          this.outdatedLangList = res['outdatedLangList'];
          this.selectedLangArray = this.savedLangList = res['langList'].map((e) => e.value != 'en' ? e.value : false).filter(Boolean) || [];
          this.filteredLangList = this.languageList.filter((lang) => this.selectedLangArray.includes(lang.value) ? lang : "");
          this.ldvfilteredLangList = this.languageList.filter((lang) => this.selectedLangArray.includes(lang.value) ? lang : "");
        }

      });

    // this.getFileTree();
    this.projectStatus.projectCategoryName = this.projectInfo.projectname

    // this.getTreeOptionData();

    // this.getMenuJson();
    // this.pathList = new FormGroup({
    //   selectedPathList: new FormControl([]),
    //   default: new FormControl(''),
    //   crawlDelay: new FormControl(),

    // });
    // this.siteMapUrlForm = this.FormBuilder.group({
    //   arr: this.FormBuilder.array([this.createItem()])
    // });
  }
  getProjPlatfrm(){
    let data={
      "projectName" : this.projectInfo.projectname
    }
    this._shareService.getPrjPlatForm(data).subscribe((res:any)=>{
      this.getplatform = res[0]
    })
  }

  // showSections(check : boolean) {
  //   this.metaSectionCheck = check
  // }

  // selectedMetaRow(event:any) {
  //   console.log(event);
  //   this.radioValue = 'static'
  //   this.selectPageOption({target : {value : event.route_from}}, event);
  //   this.metaInfo.route_from = event.route_from;
  //   this.metaInfo.route_to = event.module;
  //   this.metaInfo.pageRoute = event.metaUrl[0];
  //   this.showRoutesData();
  //   this.fixedMetaData = []
  //   event.meta.forEach(element => {
  //     for(let item in element) {
  //       let obj : any = {}
  //       obj.metaKey = item
  //       obj.metaValue = element[item]
  //       this.fixedMetaData.push(obj);
  //     }
  //   });
  //   let element = document.getElementById('pills-tag-tab');
  //   element.click()
  //   this.disableModify = true
  // }

  isLanguageEnableOnProjectMethod() {
    let obj = {
      'projectId': this.projectInfo.projectId
    }
    this._shareService.isLangEnableOnProject(obj).subscribe(res => {
      if (res && res['islang'] == 1) {
        this.isLangWork = true
      }
    })
  }
  getProjectBundleList() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
      (response: any) => {
        if (response) {
          this.projectList = response["data"];
          this._projectList_ = response["data"].map(_item => {
            let _newItem = _item;
            _newItem['label'] = _item['projectname'],
              _newItem['value'] = _item['projectId']
            return _newItem
          })
        }
      }
    );
  }

  // showXml() {
  //   this.showHtml = !this.showHtml
  // }
  closeModel() {
    this.modalRef.close(true);
  }
  // project load [data] in dropdown @faizan end



  ngAfterViewInit() {
    // this.getVieww()
  }
  toggleSidebar() {
    var toggledashbaord = document.querySelector(".full-screen");
    toggledashbaord.classList.toggle("dashboard-screen")
  }

  // getVieww() {
  //   let buttons = document.getElementById("pills-html-tab")
  //   if (buttons) {
  //     buttons.addEventListener("click", () => {
  //       document.getElementById("pills-view").classList.remove("show")
  //     });
  //   }

  // }


 
 

 

  


  selecteditem: any = [];
  user: any;
  selectedName: string
  userRoleArr = []; //get selected user role list 
  roleVisit = []; // visit role list
  multiValueList: any = {};
  callFirstTime = true
  projFeatureStat:any={}
  configureData(item) {
    this.isSeoTabClick=false
    if(item.pCode != 'proDetails'){
      this.showFirst = false
      let doc:any = document.getElementById('parent0')
      doc.classList.remove('active')
    }
    // this.projectIdShowInCSSJSList = this._shareService.getDataprotool("selectedProjectChooseData").projectId
    // this.showControlsListInfo = false;
    if(item.pCode == 'proSummary'){
      const data = {
        "projectId": this._shareService.getDataprotool("selectedProjectChooseData").projectId
      }
      this._shareService.getprjFtrStatus(data).subscribe((res:any)=>{
        this.projFeatureStat = res; 
      })
    }

    // if (item.pCode === "sitemap") {
    //   this.domainName = ""
    //   this.checkedXML = false
    //   this.getUrlSitemap()
    // }
    // if (item.pCode === "metaData") {
    //   this.getMenu();
    //   this.getRouteArrayOfPage();
    // }
    this.selectedItem = item;
    this.selecteditem = []
    if (item.pCode == 'uControl') {
      this.getToolVersion();
      setTimeout(() => {
        this.controlversion(this.toolUpdateList.menudetId);
      }, 100);
      
      this.getBackendToolVersion();
    }
    this.selectedName = item.pcode
    if (item.pCode == 'excelMapping') {
      this.excelImportExportMapping()
    }
    // if (item.pCode == 'indexHtmlContent') {
    //     this.resetList()
    // }
    // if (item.pCode == 'rightsOnButtons') {
    //   this.getTreeOptionData();
    // }
    if (item.pCode == 'mediaContent') {
      this.sagStudioService.imageCollectionsFlag = false;
      this.sagStudioService.isDocumentFolderUse = false;
    }
    if (item.pCode == 'docContent') {
      this.sagStudioService.imageCollectionsFlag = false;
      this.sagStudioService.isDocumentFolderUse = true;
    }
    if (item.pCode == 'frmValidation') {
      setTimeout(() => {
        this.allValidations();
      }, 50)
    }
    if (item.pCode == 'paragraph' || item.pCode == 'text' || item.pCode == 'password' || item.pCode == 'email' || item.pCode == 'phone' || item.pCode == 'number' || item.pCode == 'amount' || item.pCode == 'textarea' || item.pCode == 'file' || item.pCode == 'checkbox' || item.pCode == 'radio' || item.pCode == 'select' || item.pCode == 'pCalendar') {
      //  if(this.callFirstTime == true){

      //  }
      let propertyWindow = JSON.parse(JSON.stringify(this.sagStudioService.propertyWindowJson));
      this.sagStudioService.generalConfig.forEach((element) => {
        debugger
        if (element.id == 'userRoles') {
          this.user = element.child
        }
        if (element.id == 'controls') {
          this.user = element.child
        }
        else {
          return
        }
      });
      this.user.forEach(element => {
        // copied code from proj-config comp
        if (item.pCode == element.subtype) {
          this.configDataList = []
          this.selecteditem = element

          if (this.selectedItem.parent == 'controls') {
            const findProList = (proItem, prtEleName?) => {
              debugger
              proItem.forEach(pro => {
                if (element.projectConfigProperties && element.projectConfigProperties.includes(pro.id)) {
                  pro.name = prtEleName ? `${prtEleName}->${pro.name}` : `${pro.name}`;
                  if (pro.fieldType == "icon") {
                    pro.optionValue = [
                      { value: "true", label: "True" },
                      { value: "false", label: "False" }
                    ];
                  }
                  if (pro.fieldType == 'multiSelect' && pro.optionValue.length == 0) {
                    if (this.sagStudioService.allSagClassList[element.type][pro.ngModel]) {
                      pro.optionValue = this.sagStudioService.allSagClassList[element.type][pro.ngModel]
                    } else {
                      pro.optionValue = this.sagStudioService.allSagClassList[element.type][element.subtype];
                    }
                  }

                  ((pro.children && pro.children.length > 0) ? findProList(pro.children, pro.name) : this.configDataList.push(pro));
                }
              });
            }

            propertyWindow.forEach((ele) => {
              findProList(ele.properties);
            });

            if (this.roleVisit.indexOf(element.subtype.toUpperCase()) == -1) {
              this.roleVisit.push(element.subtype.toUpperCase());
            }
          }
          if (this.selectedItem.parent == 'userRole') {
            this.userRoleChk(this.selecteditem, propertyWindow, this.selecteditem, this.checkedItem)
          }

          // this.userRoles=element.projectConfigProperties
        }
      });


    }
    this.rights()
    /* ------------ robotstxt condition-------------*/
    // if (item.pCode === "robotstxt") {
    //   this.getRobotsTxtPathList();
    //   this.robotTxtExist()
    //   setTimeout(() => {
    //     this.robotTxtGrid()
    //   }, 50);
    // }

    // if (item.pCode === "backup") {
    //   setTimeout(() => {
    //     this.demo1()
    //   }, 50);
    // }
    // if (item.pCode === "restorePage") {
    //   setTimeout(() => {
    //     this.demo2()
    //   }, 50);
    // }
  }
  
  // robotTxtExist(){
  //   const __prjDetails = this._shareService.getDataprotool("selectedProjectChooseData")
  //   let postdata ={
  //     "projectPath":__prjDetails['awspace']
  //   }  
  //   this._shareService.robotTxtExist(postdata).subscribe((res:any)=>{
  //     this.isRobotTxtExist = res
  //     console.log(res,"This is the response")
  //   })
  // }

  excelImportExportMapping() {

    const ref = this.dialogService.open(ImportExportMappingComponent, {
      header: "Import Export Mapping",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model excel_import_export",
    });
    ref.onClose.subscribe((res) => {

    });
  }
  saveRoleData() {
    this.sagStudioService.roleUserProperties.filter((x: any) => {
      x.roleMode.filter((roleMode: any) => {
        this.userRoleArr.filter((roleArr: any) => {
          if (roleMode.label == roleArr.mid) {
            roleArr['role'] = x.roleName
          }
        })
      })
    })
    const data = {
      userRoleArr: this.userRoleArr,
      roleVisit: this.roleVisit,
    }
    this._apiService.saveRoleRights(data).subscribe((res) => {
      alert("Success");
    });
  }

  //update default ctrl item value
  async defaultCtrlSave() {
    if (this.projectInfo) {
      // let conf = await ui.confirm("Do You Want To Update Control Property ?");
      // if (conf == true) {
      let jsonData = {
        "projectId": this.projectInfo.projectId,
        "ctrlId": this.selecteditem.ctrlId,
        "properties": this.selecteditem.properties
      }
      this._shareService.setDefaultProperty(jsonData).subscribe((res) => {
        if (res) {
          if (res['status'] == 'success') {
            this.toast.launch_toast({
              type: 'success',
              position: 'bottom-right',
              message: res['msg'],
            });
          }

        } else {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: res['msg'],
          });
        }
      });

      // }

    }

  }

  fExpandView() {
    this.frontendViewMore = !this.frontendViewMore;
  }

  BExpandView() {
    this.BackendViewMore = !this.BackendViewMore;
  }

  viewVersionList() {
    this.versionListViewMore = !this.versionListViewMore;
  }

  projectType() {
    this.projectTypeViewMore = !this.projectTypeViewMore;
  }




  connectionStringDB() {
    const dbConnection = this.dialogService.open(
      DatabaseConnectionComponent,
      {
        header: "Database",
        width: "100%",
        transitionOptions: "00ms cubic-bezier(0.25, 0.8, 0.25, 1)",
        styleClass: "database_connection",
        contentStyle: { height: "200px", "background-color": "#faf0f0" },
      }
    );
    dbConnection.onClose.subscribe((res) => {
    });
  }


  languageTranlate() {
    this.tranlateLanguage = !this.tranlateLanguage;
  }

  getFileTree() {
    if (this.selectedProject) {
      let obj = {
        "projectName": this.selectedProject.projectname,
        "projectId": this.selectedProject.projectId
      }
      this._shareService.getMenuForVoice(obj).subscribe((res) => {
        if (res) {
          this.files = res['menujson'];
        }
      });
    }
  }

  loadProject() {
    const ref = this.dialogService.open(ChooseProjectComponent, {
      header: "Choose Project",
      width: "80%",
      contentStyle: { height: "500px" },

    });
    ref.onClose.subscribe((res) => {
      res == "projectLoaded"
        ? this._router.navigate(["dashboard/UIbuilder"])
        : false;
    });
  }

  createProject() {
    const ref = this.dialogService.open(CreateProjectStepperComponent, {
      header: "create Project",
      width: "100%",
      // styleClass: "service_full_model",
    });

  }

  async openMappingControlModal(menu) {
    const selectedProjectChooseData = this._shareService.getDataprotool("selectedProjectChooseData");
    const currentPagePath = `${selectedProjectChooseData.projectname}/${menu.routehtml}`;
    const parentNodePath = currentPagePath.substring(0, currentPagePath.lastIndexOf("/"));
    const selectedPageFileNode = await this.studioDragDropService.getExplorerNodeByProjectPath(currentPagePath, 'from');
    const parentNode = await this.studioDragDropService.getExplorerNodeByProjectPath(parentNodePath, 'from');
    if (selectedPageFileNode) {
      await this.studioDragDropService.fileShow(selectedPageFileNode, '', parentNode);

      const ref = this.dialogService.open(MappingControlsComponent, {
        header: 'Mapping Controls',
        width: '100%',
        styleClass: "service_full_model",
        contentStyle: { "height": "100%!important", "display": "flex", "flex-direction": "column", "overflow": "hidden" }
      });
      this.sagStudioService.mappingControlTabType = "multilingual";
    }
  }

  closeConfigureModel() {
    this.modalRef.close();
    if (document.querySelector(".close_configure")) {
      document.querySelector(".close_configure").closest("p-dynamicdialog").remove();
    }

  }

  configMenuList: any;
  getMenuJson() {
    let reqJson = {
      "projectName": this._shareService.getDataprotool("selectedProjectChooseData").projectname,
      "menuType": "top",
      "device": "web"
    };
    this._shareService.getMenuJson(reqJson).subscribe(async (res) => {
      if (res['length'] > 0) {
        this.configMenuList = res[0].children
        this.updateFile()
        //this.sagStudioService.menuDataItem = res;
      }
    })
  }

  updateFile() {
    let pstData = {
      "projectId": this._shareService.getDataprotool("selectedProjectChooseData").projectId
    };
    this._shareService.fileUpdateAviable(pstData).subscribe(res => {
      const updateVarv = res['menudetId'];
      for (let index = 0; index < this.configMenuList.length; index++) {
        const apidat = updateVarv.includes(this.configMenuList[index].menudetId);
        if (apidat) {
          this.configMenuList[index]['updateAvi'] = true;
        }

      }
    })
  }


  gridData_controlversion: any;
  gridDynamicObj_controlversion: any;
  columnData_controlversion: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "Tool Name",
      "field": "pagemasterLabel",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Old Version",
      "field": "oldVersion",
      "filter": true,
      "width": "90px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Current Version",
      "field": "currentVersion",
      "filter": true,
      "width": "90px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Count",
      "field": "count",
      "filter": true,
      "width": "90px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Used type",
      "field": "usedType",
      "filter": true,
      "width": "90px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "buttonIcon",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "imgsrc": "", "iconclass": "fas fa-eye", "iconPosition": "", "name": "View", "classes": "", "attribute": "", "styles": "" },

    },
    {
      "header": "Used In",
      "field": "usedIn",
      "filter": true,
      "width": "80px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Used", "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },
    },
    {
      "header": "Update",
      "field": "update",
      "filter": true,
      "width": "80px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Update", "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },
    }
  ];

  rowData_controlversion: any = [
    {},
    {},
    {},
    {}
  ];

  controlversion(rowData?, colData?) {
    let self = this;

    this.gridData_controlversion = {
      columnDef: colData ? colData : this.columnData_controlversion,
      rowDef: rowData ? rowData : this.rowData_controlversion,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,


      components: {},
      callBack: {
        "onButtonIcon_usedType": function (ele, param) {
          let setRowSelected = self.gridDynamicObj_controlversion.getSeletedRowData();
          self.selectedComponentOpen(setRowSelected)
        },
        "onButton_usedIn": function (ele) {
          self.rowData_useidetails = [];
          let projectDetails = self._shareService.getDataprotool("selectedProjectChooseData");
          let selectedRowData = self.gridDynamicObj_controlversion.getSeletedRowData();
          if (selectedRowData != null && selectedRowData.pagemasterId) {
            let toolUsedDataObj = {
              "projectId": projectDetails['projectId'],
              "pagemasterId": selectedRowData.pagemasterId
            }
            let getResData;
            self._shareService.getToolUsedData(toolUsedDataObj).subscribe(resUsedData => {
              getResData = resUsedData
              if (getResData && (getResData != undefined) && getResData.length > 0) {
                getResData.forEach(dataName => {
                  self.rowData_useidetails.push(
                    {
                      'type': dataName.type,
                      'menu': dataName.menu,
                      'caller': dataName.caller,
                      'callee': dataName.callee,
                      'navigateUrl': dataName.navigateUrl,
                    })
                })
              }
              self.useidetails();
            })
          }
        },
        "onButton_update": function (ele) {
          let setRowSelected = self.gridDynamicObj_controlversion.getSeletedRowData();
          self.callupdatebuttonforhtml()
          const postData = {
            "pagemasterid": setRowSelected.pagemasterId,
            "modId": setRowSelected.modId
          }
          self.fileWriteData(postData, setRowSelected);
        },

        "onCellClick": function (ele) {
          self.oncontrolversionCellClick();
        },
        "onRowClick": function () {
          self.oncontrolversionClick();
        },
        "onRowDbleClick": function () {
          self.oncontrolversiondblClick();
        }
      },
      rowCustomHeight: 30,
    };

    let sourceDiv = document.getElementById("controlversion");
    this.gridDynamicObj_controlversion = SdmtGridT(sourceDiv, this.gridData_controlversion, true, true);
  }

  oncontrolversionCellClick() { }

  oncontrolversionClick() { }

  oncontrolversiondblClick() { }
//Backend Version control start ========>

updatefile:boolean =false;
gridData_backendversioncontrol: any;
gridDynamicObj_backendversioncontrol: any;
columnData_backendversioncontrol: any = [
  {
    "hidden": false,
    "editable": "false",
    "filter": true,
    "search": true,
    "component": "label",
    "field": "sno",
    "freezecol": "null",
    "width": "50px",
    "header": "S.No",
    "text-align": "center",

  },
  {
    "header": "Tool Name",
    "field": "toolName",
    "filter": true,
    "width": "200px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "label",
    "cellRenderView": false,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,

  },
  {
    "header": "Current Version",
    "field": "currentVersion",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "label",
    "cellRenderView": false,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,

  },
  {
    "header": "New Version",
    "field": "newVersion",
    "filter": true,
    "width": "150px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "label",
    "cellRenderView": false,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,

    },
    // {
    //   "hidden": false,
    //   "search": true,
    //   "cellHover": false,
    //   "text-align": "center",
    //   "editable": "false",
    //   "sort": false,
    //   "filter": true,
    //   "component": "dynamicComponent",
    //   "field": "eventDate",
    //   "freezecol": "null",
    //   "width": "150px",
    //   "header": "Event Date",
    //   "cellRenderView": true,
    //   "button": { "visibility": true, "classes": ["btn-primary"], "iconPosition": "", "name": "", "styles": { "border-radius": "25px", "border": "1px #2aa5b9 solid", "padding": "2px", "color": "white", "width": "40px", "font-size": "14px", "line-height": "10px", "height": "16px" }, "iconclass": "fas fa-eye", "attribute": "", "imgsrc": "" },

  // },
  {
    "header": "Action",
    "field": "action",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "text-align": "left",
    "search": false,
    "component": "dynamicComponent",
    "cellRenderView": true,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,
    "button": { "cellValue": "", "visibility": true, "name": "Update", "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },
  }
];

rowData_backendversioncontrol: any = [
  {},
  {},
  {},
  {}
];

  backendversioncontrol(rowData?, colData?) {
    let self = this;
    //let mobileWebItem = this.common.getEnvironment();
    this.gridData_backendversioncontrol = {
      columnDef: colData ? colData : this.columnData_backendversioncontrol,
      rowDef: rowData ? rowData : this.rowData_backendversioncontrol,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,


      components: {},
      callBack: {
        "onButton_action": function (ele) {
          let setRowSelected = self.gridDynamicObj_backendversioncontrol.getSeletedRowData();
          self.alertsmg = "Alerts : Manual Changes for -> " + setRowSelected['toolName'] + " : " + setRowSelected["currentToolVersion"] + " -> " + setRowSelected["latestToolVersion"]
          //   const postData = {
          //     "pagemasterid": setRowSelected.pagemasterId,
          //     "modId": setRowSelected.modId
          //   }
          self.getBackendToolUpdateFileList();
        },

        "onCellClick": function (ele) {
          self.onbackendversioncontrolCellClick();
        },
        "onRowClick": function () {
          self.onbackendversioncontrolClick();
        },
        "onRowDbleClick": function () {
          self.onbackendversioncontroldblClick();
        }
      },
      rowCustomHeight: 25,
    };

    let sourceDiv = document.getElementById("backendversioncontrol");
    this.gridDynamicObj_backendversioncontrol = SdmtGridT(sourceDiv, this.gridData_backendversioncontrol, true, true);
  }

  onbackendversioncontrolCellClick() {

  }
  onbackendversioncontrolClick() {

  }
  onbackendversioncontroldblClick() {

  }

  getBackendToolVersion() {

    let projectId = this._shareService.getDataprotool("selectedProjectChooseData").projectId;
    this._shareService.getBackendToolversionproject(projectId).subscribe(res => {
      console.log(res);
      let backendVersionControl = res["data"];
      if (res["status"] == 200) {
        this.backendversioncontrol(backendVersionControl.map(ele => {
          let obj = ele;
          obj["toolName"] = ele["toolName"];
          obj["currentVersion"] = ele["currentToolVersion"];
          obj["newVersion"] = ele["latestToolVersion"];
          if (ele["currentToolVersion"] === ele["latestToolVersion"]) {

            obj.dynamicCompName_action = 'button';
            obj.dynamicCompCellRenderView_action = true;
          } else {
            obj.dynamicCompName_action = 'button';
            obj.dynamicCompCellRenderView_action = true;
          }
          return obj;
        }));
      } else {
        this.backendversioncontrol([]);
      }
    })

  }
  toolUpFileList: any;
  getBackendToolUpdateFileList() {
    const __prjDetails = this._shareService.getDataprotool("selectedProjectChooseData");
    let selectedRow = this.gridDynamicObj_backendversioncontrol.getSeletedRowData();
    let reqObj = {
      "projectPath": __prjDetails['jwspace'],
      "projectName": __prjDetails['projectname'],
      "toolName": selectedRow['toolName'],
      "projectId": __prjDetails['projectId']
    }
    this._shareService.getBackendToolUpdateFileList(reqObj).subscribe(res => {
      console.log(res["data"].length)
      this.toolUpFileList = res["data"];
      if (res["data"].length > 0) {
        this.updatefile = true;
        this.javaVersionUpdateFileList(this.toolUpFileList.map(ele => {
          let obj = ele;
          obj.dynamicCompName_action = 'text';
          obj.dynamicCompCellRenderView_action = false;
          return obj;
        }));
      } else {
        this.updatefile = false;
        this.updateBackendToolVersion(false);
      }
    }, error => {
      alerts("Error While");
    });

  }

updateBackendToolVersion(item) {
  let selectedRow = this.gridDynamicObj_backendversioncontrol.getSeletedRowData();
  const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
  const __prjDetails = this._shareService.getDataprotool("selectedProjectChooseData");
  let newArray = [];
  const reqObj = {
    "projectPath": __prjDetails['jwspace'],
    "projectName": __prjDetails['projectname'],
    "userName": sessionStoragedata.data.clientInfo.usrCode,
    "projectId": __prjDetails['projectId'],
    "toolName": selectedRow['toolName'],
    "userId": sessionStoragedata.data.clientInfo.usrId,
    "menuMapping": newArray,
    "isForceWriteModule": false,
    "isUpdate":true
  }
  this.dbcomparetoolService.writeJavaModule(reqObj).subscribe(
    (response: any) => {
      if(response["status"] == 200){
         success(response.message);
         if(item == true){
          this.javaVersionUpdateFileList(this.toolUpFileList.map(ele =>{
            let obj = ele;
            obj.dynamicCompName_action = 'button';
            obj.dynamicCompCellRenderView_action = true;
            return obj;
          }));
         }
         this.getBackendToolVersion();
        }else if(response["status"] == 500){
          alerts(response.message);
        }
    }, error => {
      alerts("Error While")
    }
  );

}

gridData_javaVersionUpdateFileList: any;
gridDynamicObj_javaVersionUpdateFileList: any;
columnData_javaVersionUpdateFileList: any = [
  {
    "hidden": false,
    "editable": "false",
    "filter": true,
    "search": true,
    "component": "label",
    "field": "sno",
    "freezecol": "null",
    "width": "50px",
    "header": "S.No",
    "text-align": "center",

  },
  {
    "header": "File Name",
    "field": "fileName",
    "filter": true,
    "width": "200px",
    "editable": "false",
    "text-align": "left",
    "search": true,
    "component": "label",
    "cellRenderView": false,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,

    },
    {
      "header": "Path",
      "field": "uniqePath",
      "filter": true,
      "width": "380px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

  },
  // {
  //   "hidden": false,
  //   "search": true,
  //   "cellHover": false,
  //   "text-align": "center",
  //   "editable": "false",
  //   "sort": false,
  //   "filter": true,
  //   "component": "dynamicComponent",
  //   "field": "eventDate",
  //   "freezecol": "null",
  //   "width": "150px",
  //   "header": "Event Date",
  //   "cellRenderView": true,
  //   "button": { "visibility": true, "classes": ["btn-primary"], "iconPosition": "", "name": "", "styles": { "border-radius": "25px", "border": "1px #2aa5b9 solid", "padding": "2px", "color": "white", "width": "40px", "font-size": "14px", "line-height": "10px", "height": "16px" }, "iconclass": "fas fa-eye", "attribute": "", "imgsrc": "" },

  // },
  {
    "header": "Action",
    "field": "action",
    "filter": true,
    "width": "100px",
    "editable": "false",
    "text-align": "left",
    "search": false,
    "component": "dynamicComponent",
    "cellRenderView": true,
    "freezecol": "null",
    "hidden": false,
    "sort": false,
    "cellHover": false,
    "button": { "cellValue": "", "visibility": true, "name": "Compare", "classes": ["btn", "btn-info", "w-70"], "attribute": "", "styles": "" },
  }
];

rowData_javaVersionUpdateFileList: any = [
  {},
  {},
  {},
  {}
];

  javaVersionUpdateFileList(rowData?, colData?) {
    let self = this;
    //let mobileWebItem = this.common.getEnvironment();
    this.gridData_javaVersionUpdateFileList = {
      columnDef: colData ? colData : this.columnData_javaVersionUpdateFileList,
      rowDef: rowData ? rowData : this.rowData_javaVersionUpdateFileList,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,


      components: {},
      callBack: {
        "onButton_action": function (ele) {
          self.onjavaVersionUpdateFileListactionbtnCompare()
        },

        "onCellClick": async function (ele) {

          self.onjavaVersionUpdateFileListCellClick();
        },
        "onRowClick": async function () {
          let setRowSelected = await self.gridDynamicObj_javaVersionUpdateFileList.getSeletedRowData();
          self.onjavaVersionUpdateFileListClick(setRowSelected);
        },
        "onRowDbleClick": function () {
          self.onjavaVersionUpdateFileListdblClick();
        }
      },
      rowCustomHeight: 25,
    };

    let sourceDiv = document.getElementById("javaVersionUpdateFileListId");
    this.gridDynamicObj_javaVersionUpdateFileList = SdmtGridT(sourceDiv, this.gridData_javaVersionUpdateFileList, true, true);
  }

  onjavaVersionUpdateFileListCellClick() {

  }
  onjavaVersionUpdateFileListClick(setRowSelected) {
    this.currentPagePathforcompare = setRowSelected.fullyQulifiedPath

}
onjavaVersionUpdateFileListdblClick(){

}

 onjavaVersionUpdateFileListactionbtnCompare() {
    if (window['angularComponentRef'].setNodeSelectedPath && this.currentPagePathforcompare) {
      let EndpathArray = this.currentPagePathforcompare.split('/')
      let index = EndpathArray.indexOf('src');
      let newEndPath = EndpathArray.slice(index).join('/')
      let firstpath = window['editorComponentRef'].editorRef.firstRootStore[0].id
      const fullPath = firstpath + '/' + newEndPath
      window['angularComponentRef'].openFileEditor(fullPath);
      const ele: any = document.querySelector('.hide_configureapproval')
      ele.style.display = 'none'
       window['angularComponentRef'].editorMethodCompare(true, fullPath)
    }
    else (
      alerts("Please Select a File")
    )
  }

  //end Backend Version Control ===========<>
  getToolVersion() {
    let toolVrs = {
      "projectId": this._shareService.getDataprotool("selectedProjectChooseData").projectId,
      "projectName": this._shareService.getDataprotool("selectedProjectChooseData").projectname
    };
    this._shareService.getToolversionproject(toolVrs).subscribe(res => {
      this.toolUpdateList = res;
      if (this.toolUpdateList != undefined && this.toolUpdateList.menudetId) {
        if (this.toolUpdateList.menudetId.length > 0) {
          this.toolUpdateList.menudetId.forEach(data => {
            if (data.oldVersion != data.currentVersion) {
              this.updateAvailabel = true
            }
          })
        }
      }
    })

  }

  gridData_useidetails: any;
  gridDynamicObj_useidetails: any;
  columnData_useidetails: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "center",

    },
    {
      "header": "Type",
      "field": "type",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Menu",
      "field": "menu",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Caller",
      "field": "caller",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Callee",
      "field": "callee",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Navigate Url",
      "field": "navigateUrl",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_useidetails: any = [];

  useidetails(rowData?, colData?) {
    let self = this;

    this.gridData_useidetails = {
      columnDef: colData ? colData : this.columnData_useidetails,
      rowDef: rowData ? rowData : this.rowData_useidetails,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onuseidetailsCellClick();
        },
        "onRowClick": function () {
          self.onuseidetailsClick();
        },
        "onRowDbleClick": function () {
          self.onuseidetailsdblClick();
        }
      }
      ,


      rowCustomHeight: 20,




    };

    let sourceDiv = document.getElementById("useidetails");
    this.gridDynamicObj_useidetails = SdmtGridT(sourceDiv, this.gridData_useidetails, true, true);
  }

  onuseidetailsCellClick() {
  }

  onuseidetailsClick() {

  }

  onuseidetailsdblClick() {

  }
  list: any = [];
  item: any = {};
  i: any;
  pagesData: any;

  async fileWriteData(postData, currentPagePath) {
    currentPagePath.projectPath = `${currentPagePath.projectPath}.component.html`
    //const parentNodePath = currentPagePath.substring(0, currentPagePath.lastIndexOf("/"));
    const currentPage = await this.studioDragDropService.getExplorerNodeByProjectPath(currentPagePath.projectPath, 'from');
    const parentNode = await this.studioDragDropService.getExplorerNodeByProjectPath(currentPagePath.parentPath, 'from');
    await this.studioDragDropService.setActiveJsonNode(parentNode, currentPage, '_from', '_selectProExplrValue', '_ngGenerateValue')
    this.sagStudioService['modifyhtmlTs'] = true;
    const resp = await this._shareService.getPageDetailData(postData).toPromise();
    this.pagesData = resp && resp["data"] ? this.sagStudioService.findPagesInModuleItemNew(resp["data"]) : false;
    const finData = {
      "filteredPages": this.pagesData,
      "dataForSelector": {}
    }
    let pPath = currentPagePath.parentPath.replaceAll(`/${currentPagePath.moduleName}`, '');


    this._shareService['changeProjectPath'] = {
      typepage: 'themePage',
      ngName: currentPage.angularScemeticName,
      projectPath: pPath
    }

    this.fileWriteModules(finData);
    this.modalRef.close();
  }

  async fileWriteModules(finData) {
    debugger
    await this.studioDragDropService.writeModules(finData, this.list, this.item, this.i);
  }




  // Rights on buttons





  async getTreeOptionData() {
    this.treeOptionsData = [];
    let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    let obj = {
      "projectName": seletedObj.projectname
    }
    this._shareService.getPageBtnJSON(obj).subscribe(async responseData => {
      // await this.treeOptionsData.push(responseData['btnjson'][0]);
      let getbtnsJsonData = await responseData['btnjson'][0];
      if (getbtnsJsonData != undefined) {

        let newJsonData = JSON.parse(JSON.stringify(getbtnsJsonData))
        this.changeChildrenToKdetailsMethod(newJsonData);
        this.treeOptionsData.push(newJsonData)
      }

      if (this.listOfControls && this.listOfControls.length > 0) {
        for (let c = 0; c < this.listOfControls.length; c++) {
          if (this.listOfControls[c].matchableId) {
            // addingControls in list to show

            if (this.listOfControls[c].controls && this.listOfControls[c].controls.length > 0) {
              this.controlsEnteryMethod(this.listOfControls[c].matchableId, this.treeOptionsData[0], this.listOfControls[c].controls)
            }
            if (this.listOfControls[c].tabsAndModelControlsList && this.listOfControls[c].tabsAndModelControlsList.length > 0) {
              this.listOfControls[c].tabsAndModelControlsList.forEach(d => {
                this.tabsAndModelControlsEntryMethod(d, this.treeOptionsData[0])
              })
            }
          }
        }
      }

      this.rowData_rights.push(this.treeOptionsData[0]);

    })
  }

  listOfControlsPageWise = [];
  justParent = '';
  modelsList = [];
  tabsList = [];


  changeChildrenToKdetailsMethod(obj) {

    this.listOfControlsPageWise = [];

    if (obj && obj.children) {
      obj['Kdetails'] = obj.children
    }
    if (obj.children && obj.children.length > 0) {
      for (let i = 0; i < obj.children.length; i++) {
        this.changeChildrenToKdetailsMethod(obj.children[i])
      }
    }
    if (this.sagStudioService.currentActiveProject.subDataArray.length > 0) {
      let allPages = this.sagStudioService.currentActiveProject.subDataArray;
      for (let j = 0; j < allPages.length; j++) {
        if (obj && (obj.matchableId == allPages[j].matchableId)) {
          this.justParent = '';
          this.modelsList = [];
          this.tabsList = [];

          this.pageWiseControlsSetMethod(allPages[j].subDataArray[0]);

          if (this.tabsList && this.tabsList.length > 0) {
            for (let eachTab = 0; eachTab < this.tabsList.length; eachTab++) {
              if (this.tabsList[eachTab] && this.tabsList[eachTab].subDataArray && this.tabsList[eachTab].subDataArray.length > 0) {
                this.tabsList[eachTab].subDataArray.forEach(data => {
                  this.checkForNestedTabs(data)
                })
              }
            }
          }
          debugger
          let allTabsList = [];
          // buttons available in Tabs
          if (this.tabsList && this.tabsList.length > 0) {
            debugger
            for (let tab = 0; tab < this.tabsList.length; tab++) {
              //again check for nested tabs
              let btnsBelongToTab = [];
              this.buttonsWhichBelongsToTab(this.tabsList[tab], btnsBelongToTab)

              let tabObj = {
                "label": this.tabsList[tab].properties.label,
                "controlId": this.tabsList[tab].id,
                "controlsBtns": btnsBelongToTab
              }
              allTabsList.push(tabObj)
            }
          }
          let allModelsList = [];
          // buttons available in models
          if (this.modelsList && this.modelsList.length > 0) {
            for (let mod = 0; mod < this.modelsList.length; mod++) {
              let btnsBelongToModel = [];
              if (this.modelsList[mod].modelHeader) {
                this.buttonsWhichBelongsToModel(this.modelsList[mod].modelHeader, btnsBelongToModel)
              }
              if (this.modelsList[mod].modelBody) {
                this.buttonsWhichBelongsToModel(this.modelsList[mod].modelBody, btnsBelongToModel)
              }
              if (this.modelsList[mod].modelFooter) {
                this.buttonsWhichBelongsToModel(this.modelsList[mod].modelFooter, btnsBelongToModel)
              }
              let modelObj = {
                "label": this.modelsList[mod].properties.name,
                "controlId": this.modelsList[mod].id,
                "controlsBtns": btnsBelongToModel
              }
              allModelsList.push(modelObj)
            }
          }
          let tabsAndModelControlsList = [...allModelsList, ...allTabsList];
          // let btnsNotInTabsAndModels = [];
          let tabsAndModelsBtns = [];
          // Btns availabel in tabs and Models
          if (tabsAndModelControlsList && tabsAndModelControlsList.length > 0) {
            for (let x = 0; x < tabsAndModelControlsList.length; x++) {
              if (tabsAndModelControlsList[x].controlsBtns && tabsAndModelControlsList[x].controlsBtns.length > 0) {
                tabsAndModelControlsList[x].controlsBtns.forEach(dataBtn => {
                  tabsAndModelsBtns.push(dataBtn)
                })
              }
            }
          }



          let ob = {
            "fileName": obj.label,
            "matchableId": obj.matchableId,
            "controls": this.listOfControlsPageWise,
            "tabsAndModelControlsList": tabsAndModelControlsList,
            "all": tabsAndModelsBtns
          }

          this.listOfControls.push(ob)
          debugger
        }
      }
    }
    delete obj.children;
  }

  checkForNestedTabs(tab) {
    // debugger
    if (tab.subtype == 'bootnavTab' && !tab.children) {
      this.tabsList.push(tab)
    }
    if (tab && tab.subDataArray && tab.subDataArray.length > 0) {
      tab.subDataArray.forEach(subTab => {
        this.checkForNestedTabs(subTab)
      })
    }
    if (tab && tab.children && tab.children.length > 0) {
      tab.children.forEach(chTab => {
        this.checkForNestedTabs(chTab)
      })
    }
  }

  pageWiseControlsSetMethod(cntrlGroup) {

    if (cntrlGroup.subtype == 'bootstrapModals') {
      this.modelsList.push(cntrlGroup)
    }

    if (cntrlGroup.subtype == 'button') {
      cntrlGroup['label'] = cntrlGroup.properties.label;
      this.listOfControlsPageWise.push(cntrlGroup)
    }
    if (cntrlGroup.subtype != 'bootstrapModals') {
      if (cntrlGroup && cntrlGroup.subDataArray && cntrlGroup.subDataArray.length > 0) {
        cntrlGroup.subDataArray.forEach(subDataControl => {
          if (subDataControl.subtype == 'bootnavTab') {
            if (subDataControl && subDataControl.children) {
              this.pageWiseControlsSetMethod(subDataControl)
            } else {
              this.tabsList.push(subDataControl)
            }
          } else {
            this.pageWiseControlsSetMethod(subDataControl)
          }
        })
      }
      if (cntrlGroup && cntrlGroup.children && cntrlGroup.children.length > 0) {
        cntrlGroup.children.forEach(childDataControl => {
          if (childDataControl.subtype == 'bootnavTab') {
            if (childDataControl && childDataControl.children) {
              this.pageWiseControlsSetMethod(childDataControl)
            } else {
              this.tabsList.push(childDataControl)
            }
          } else {
            this.pageWiseControlsSetMethod(childDataControl)
          }
        })
      }
    }
  }

  buttonsWhichBelongsToTab(cntl, bucketOfTabsBtn) {
    if (cntl.subtype == "button") {
      cntl['label'] = cntl.properties.label
      bucketOfTabsBtn.push(cntl)
    }
    if (cntl && cntl.subDataArray && cntl.subDataArray.length > 0) {
      cntl.subDataArray.forEach(subTab => {
        if (subTab.subtype != 'bootnavTab') {
          this.buttonsWhichBelongsToTab(subTab, bucketOfTabsBtn)
        }
      })
    }
    if (cntl && cntl.children && cntl.children.length > 0) {
      cntl.children.forEach(chTab => {
        if (chTab.subtype != 'bootnavTab') {
          this.buttonsWhichBelongsToTab(chTab, bucketOfTabsBtn)
        }
      })
    }
  }


  buttonsWhichBelongsToModel(cntl, bucketOfModelsBtn) {
    if (cntl.subtype == "button") {
      cntl['label'] = cntl.properties.label
      bucketOfModelsBtn.push(cntl)
    }
    if (cntl && cntl.subDataArray && cntl.subDataArray.length > 0) {
      cntl.subDataArray.forEach(subMod => {
        this.buttonsWhichBelongsToTab(subMod, bucketOfModelsBtn)
      })
    }
    if (cntl && cntl.children && cntl.children.length > 0) {
      cntl.children.forEach(chMod => {
        this.buttonsWhichBelongsToTab(chMod, bucketOfModelsBtn)
      })
    }
  }


  controlsEnteryMethod(matchableId, treeSet, remainButtons) {
    if (matchableId === treeSet.matchableId) {
      if (remainButtons && remainButtons.length > 0) {
        let obj = {
          'label': 'buttons',
          'Kdetails': remainButtons
        }
        treeSet.Kdetails.push(obj)
      }
    }
    if (treeSet && treeSet['Kdetails'] && treeSet['Kdetails'].length > 0) {
      treeSet['Kdetails'].forEach(dataC => {
        this.controlsEnteryMethod(matchableId, dataC, remainButtons)
      })
    }
  }
  tabsAndModelControlsEntryMethod(btnCtrl, treeSet) {
    if (btnCtrl.controlId == treeSet.htmlid) {
      treeSet['Kdetails'] = btnCtrl.controlsBtns;
    }
    if (treeSet && treeSet['Kdetails'] && treeSet['Kdetails'].length > 0) {
      treeSet['Kdetails'].forEach(dataC => {
        this.tabsAndModelControlsEntryMethod(btnCtrl, dataC)
      })
    }
  }



  gridData_rights: any;
  gridDynamicObj_rights: any;
  columnData_rights: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left"
    },
    {
      "header": "Label",
      "field": "label",
      "filter": true,
      "width": "500px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "rowGroupCheckbox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    }
  ];

  rowData_rights: any = [

  ];

  rights(rowData?, colData?) {
    let self = this;

    this.gridData_rights = {
      columnDef: colData ? colData : this.columnData_rights,
      rowDef: rowData ? rowData : this.rowData_rights,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onrightsCellClick();
        },
        "onRowClick": function () {
          self.onrightsClick();
        },
        "onRowDbleClick": function () {
          self.onrightsdblClick();
        }
      }
      ,


      rowCustomHeight: 20,




    };

    let sourceDiv = document.getElementById("rightsWorkHere");
    if (sourceDiv != null) {
      this.gridDynamicObj_rights = SdmtGridT(sourceDiv, this.gridData_rights, true, true);
    }
  }

  onrightsCellClick() {

  }

  onrightsClick() {

  }

  onrightsdblClick() {

  }

  async callupdatebuttonforhtml() {
    if(window['angularComponentRef'].openFileEditor){
      let setRowSelected = this.gridDynamicObj_controlversion.getSeletedRowData();
      this.selectedComponentOpen(setRowSelected)
      const currentPagePath = `${window['editorComponentRef'].editorRef.firstRootStore[1].id.split('/').slice(0, -1).join('/')}/${setRowSelected.projectPath}.component.html`;
      await window['angularComponentRef'].openFileEditor(currentPagePath);
      await this.studioDragDropService.showUpdateArea()
    }
  }

  async selectedComponentOpen(setRowSelected) {
    const currentPagePath = `${setRowSelected.projectPath}.component.html`;
    const parentNodePath = `${setRowSelected.parentPath}`;
    const newlyCreatedPageFileNode = await this.studioDragDropService.getExplorerNodeByProjectPath(currentPagePath, 'from');
    const parentNode = await this.studioDragDropService.getExplorerNodeByProjectPath(parentNodePath, 'from');
    await this.studioDragDropService.fileShow(newlyCreatedPageFileNode, '', parentNode);
    this.modalRef.close();
  }
  //   controlNameToShow = '';
  //   showControlsInformation(item){
  //     this.classChanges = 'col-xl-6 col-lg-6 col-md-6'
  //     this.controlNameToShow = '';
  //     this.controlNameToShow = item.fileName;

  //     this.rowData_controlinfo = []
  //     if(item && item.usedFileJson && item.usedFileJson.length > 0){
  //       item.usedFileJson.forEach(data=>{
  //         let obj ={
  //           // "type":item.type,
  //           "count":data['controlFileCount'],
  //           // "ctrlName":item.fileName,
  //           "filePath":data.filePath,
  //           "parentPath":data.parentPath,
  //           "projectPath":data.projectPath
  //         }

  //         this.rowData_controlinfo.push(obj)
  //       })
  //     }
  //     this.showControlsListInfo = true;
  //     setTimeout(() => {
  //       this.controlinfo();
  //     }, 100);
  //   }
  //   gridData_controlinfo: any;
  //   gridDynamicObj_controlinfo: any;
  //   columnData_controlinfo: any = [
  //     {
  //       "hidden": false,
  //       "editable": "false",
  //       "filter": true,
  //       "search": true,
  //       "component": "label",
  //       "field": "sno",
  //       "freezecol": "null",
  //       "width": "50px",
  //       "header": "S.No",
  //       "text-align": "left",

  //     },
  //     {
  //       "header": "File path",
  //       "field": "filePath",
  //       "filter": true,
  //       "width": "300px",
  //       "editable": "false",
  //       "text-align": "left",
  //       "search": true,
  //       "component": "label",
  //       "cellRenderView": false,
  //       "freezecol": "null",
  //       "hidden": false,
  //       "sort": false,
  //       "cellHover": false,

  //     },
  //     {
  //       "header": "Count",
  //       "field": "count",
  //       "filter": true,
  //       "width": "100px",
  //       "editable": "false",
  //       "text-align": "center",
  //       "search": true,
  //       "component": "label",
  //       "cellRenderView": false,
  //       "freezecol": "null",
  //       "hidden": false,
  //       "sort": false,
  //       "cellHover": false,

  //     },
  //     {
  //       "header": "Column2",
  //       "field": "Column2",
  //       "filter": true,
  //       "width": "100px",
  //       "editable": "false",
  //       "text-align": "left",
  //       "search": true,
  //       "component": "buttonIcon",
  //       "cellRenderView": true,
  //       "freezecol": "null",
  //       "hidden": false,
  //       "sort": false,
  //       "cellHover": false,
  //       "button": { "imgsrc": "", "iconclass": "fa fa-eye text-white", "iconPosition": "", "name": "View", "classes": ["btn", "btn-info","text-white"], "attribute": "", "styles": "" },

  //     },
  //   ];

  //   rowData_controlinfo: any = [
  //     {},
  //     {},
  //     {},
  //     {}
  //   ];

  //   controlinfo(rowData?, colData?) {
  //     let self = this;

  //     this.gridData_controlinfo = {
  //       columnDef: colData ? colData : this.columnData_controlinfo,
  //       rowDef: rowData ? rowData : this.rowData_controlinfo,
  //       footer_hide: false,
  //       totalNoOfRecord_hide: false,
  //       sml_expandGrid_hide: false,
  //       exportXlsxPage_hide: false,
  //       exportXlsxAllPage_hide: false,
  //       exportPDFLandscape_hide: false,
  //       exportPDFPortrait_hide: false,
  //       ariaHidden_hide: false,
  //       disableAllSearch: false,
  //       wordBreak: false,
  //       wordBreakHeader: false,
  //       cellHover: false,
  //       rowHover: false,
  //       rowBorder_hide: false,
  //       columnBorder_hide: false,
  //       header_hide: false,
  //       common_search: false,
  //       common_search_column: "",
  //       gridbody_hide: false,
  //       rowLineSpace: 0,

  //       components: {},
  //       callBack: {

  //         "onButtonIcon_Column2": function (ele, param) {
  //           debugger
  //           console.log(param)
  //           let setRowSelected = self.gridDynamicObj_controlinfo.getSeletedRowData();
  //           self.selectedComponentOpenForCsJS(setRowSelected)
  //         },
  //         "onCellClick": function (ele) {

  //           self.oncontrolinfoCellClick();
  //         },
  //         "onRowClick": function () {
  //           self.oncontrolinfoClick();
  //         },
  //         "onRowDbleClick": function () {
  //           self.oncontrolinfodblClick();
  //         }
  //       }
  //       ,


  //       rowCustomHeight: 20,




  //     };

  //     let sourceDiv = document.getElementById("controlinfo");
  //     this.gridDynamicObj_controlinfo = SdmtGridT(sourceDiv, this.gridData_controlinfo, true, true);
  //   }

  //   oncontrolinfoCellClick() {

  //   }

  //   oncontrolinfoClick() {

  //   }

  //   oncontrolinfodblClick() {

  //   }
  //   async selectedComponentOpenForCsJS(setRowSelected){
  //     let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
  //     const currentPagePath = `${seletedObj.projectname}/${setRowSelected.filePath}`;
  //     const parentNodePath = `${setRowSelected.parentPath}`;
  //     const newlyCreatedPageFileNode = await this.studioDragDropService.getExplorerNodeByProjectPath(currentPagePath, 'from');
  //     const parentNode = await this.studioDragDropService.getExplorerNodeByProjectPath(parentNodePath, 'from');
  //     await this.studioDragDropService.fileShow(newlyCreatedPageFileNode, '', parentNode);
  //     this.modalRef.close();
  // }
  // resetList(){
  //   this.classChanges = 'col-xl-12 col-lg-12 col-md-12'
  // }
  // checkValue(event,item){
  //   item.selected = event;
  //   debugger
  // }

  // getControls data List 
  getControlsList() {
    // debugger
    if (this.projectInfo) {
      this._shareService.getDefaultControl().subscribe((res) => {
        if (res['data']) {
          this.sagStudioService.generalConfig.map(async (item) => {
            if (item.id == 'controls' || item.id == 'userRoles') {
              item.child = JSON.parse(JSON.stringify(res['data']));
            }
            // Getting Menu 

            return item;
          });
        }
      });
    }
  }

  async getTreeData() {
    this.treeOptionsData = [];
    let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    let obj = {
      "projectName": seletedObj.projectname
    }
    this._shareService.getPageBtnJSON(obj).subscribe(async responseData => {
      await this.treeOptionsData.push(responseData['btnjson'][0]);
      this.sagStudioService.generalConfig.map(async (item) => {
        // Getting Menu 
        if (item.id == 'tree') {
          item.child = []
          item.child = JSON.parse(JSON.stringify(this.treeOptionsData));
        }
        return item;
      });
    })
  }
  // copied userRoles methods from proj-config comp @rohit arya
  userRoleChk(item, propertyWindow, selectedItem, checkedItem) {
    const userProList = (proItem, prtEleName?) => {
      proItem.forEach(pro => {
        if (item.projectConfigProperties && item.projectConfigProperties.includes(pro.id)) {
          pro.name = prtEleName ? `${prtEleName} ${pro.name}` : `${pro.name}`;
          if (pro.fieldType == "icon") {
            pro.optionValue = [
              { value: "true", label: "True" },
              { value: "false", label: "False" }
            ];
          }
          ((pro.children && pro.children.length > 0) ? userProList(pro.children, pro.name) : this.configDataList.push(pro));
        }
      });
    }
    propertyWindow.forEach(async (ele) => {
      await userProList(ele.properties);
    });
    this.cdref.detectChanges();
    this.checkedItem(selectedItem.subtype);

  }

  /* checked selected role  */
  checkedItem(eleData) {
    debugger
    if (this.roleVisit.indexOf(this.selecteditem.subtype.toUpperCase()) == -1) {
      this.roleVisit.push(this.selecteditem.subtype.toUpperCase());

      let arrEle = this.sagStudioService.userRolePermission.find((ele) => ele.pcode == eleData.toUpperCase());
      if (arrEle != undefined) {
        arrEle.prgts.forEach(ele => {
          let mname = ele.mname.toUpperCase();
          let val = ele.val;
          val.forEach(element => {
            var tmp = mname + element;
            const ele = document.getElementById(tmp) as HTMLInputElement;
            ele.checked = true;
            //document.getElementById(tmp).checked = true;
            //----------------
            const data = {
              mid: mname,
              pid: element,
              cntrl: this.selecteditem.subtype.toUpperCase()
            }
            this.userRoleArr.push(data);
          });
        });
      }
    } else {
      let tmpArr = this.userRoleArr.filter(ele => ele.cntrl == this.selecteditem.subtype.toUpperCase())
      tmpArr.forEach(ele => {
        var tmp = ele.mid + ele.pid;
        const eleVal = document.getElementById(tmp) as HTMLInputElement;
        eleVal.checked = true;
        //document.getElementById(tmp).checked = true;
      });
    }
  }



  perpareData(evt) {
    const data = {
      mid: evt.target.dataset.mid,
      pid: evt.target.dataset.prid,
      cntrl: this.selecteditem.subtype.toUpperCase()
    }
    if (evt.target.checked) {
      this.userRoleArr.push(data);
    } else {
      for (let i = 0; i < this.userRoleArr.length; i++) {
        if (this.userRoleArr[i].mid == data.mid && this.userRoleArr[i].pid == data.pid) {
          this.userRoleArr.splice(i, 1);
          break
        }
      }
    }
  }

  // setItemProperties
  setItemProperties(event, selectedItem, proItem) {
    if (proItem.id == 'formType') {
      selectedItem.angular.formType = event.target.value;
    } else {
      selectedItem.properties[proItem.ngModel] = ((event.target.value == 'true' || event.target.value == 'false') ? JSON.parse(event.target.value) : event.target.value);
    }
  }

  selectMultiValues(event, item, pKey, key) {
    item[pKey][key] = '';
    event.value.forEach(classElem => {
      item[pKey][key] += `${classElem} `;
    });
  }

  // list of multi value
  selectedItemValues(values, key) {
    if (values && values != "") {
      return this.multiValueList[key] = values.trim().split(" ");
    } else {
      return this.multiValueList[key] = [];
    }
  }
  // get role list api @rohit arya

  getRoleList() {
    let roleName = "ALL";
    this._apiService.userRolePre(roleName).subscribe((res) => {
      // this.callFirstTime = false
      this.sagStudioService.userRolePermission = JSON.parse(
        JSON.stringify(res[`roleRights`])
      );
      this.sagStudioService.roleUserProperties = JSON.parse(
        JSON.stringify(res[`roleProperties`])
      );
    });
  }
  openpropertyConfig(item: any, ind: any) {
    if (item == 'PROJECT-CONTROL PROPERTY' || item == 'PROJECT-CONTROL PROPERTY RIGHTS') {
      let id = document.getElementById(`headingThree${ind}`)
      let attr = id.getAttribute('aria-expanded')
      if (attr == 'true') {
        this.getRoleList()
      }

    }
  }
  usedValidations() {
    let listUsedValidations = [];
    let listOfValidations = this.sagStudioService.allValidationList;
    this.projectInfo;
    if (listOfValidations && listOfValidations.length > 0) {
      listOfValidations.forEach(data => {
        if (data.projectId != null && data.projectId == this.projectInfo.projectId) {
          listUsedValidations.push(data)
        }
      })
    }
    this.rowData_projectvalidation = listUsedValidations
    setTimeout(() => {
      this.projectvalidation();
    }, 50)
  }

  gridData_projectvalidation: any;
  gridDynamicObj_projectvalidation: any;
  columnData_projectvalidation: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "Label",
      "field": "label",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Message",
      "field": "msg",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Pattern",
      "field": "pattern",
      "filter": true,
      "width": "500px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_projectvalidation: any = [
    {},
    {},
    {},
    {}
  ];

  projectvalidation(rowData?, colData?) {
    let self = this;

    this.gridData_projectvalidation = {
      columnDef: colData ? colData : this.columnData_projectvalidation,
      rowDef: rowData ? rowData : this.rowData_projectvalidation,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onprojectvalidationCellClick();
        },
        "onRowClick": function () {
          self.onprojectvalidationClick();
        },
        "onRowDbleClick": function () {
          self.onprojectvalidationdblClick();
        }
      }
      ,


      rowCustomHeight: 20,




    };

    let sourceDiv = document.getElementById("projectvalidation");
    this.gridDynamicObj_projectvalidation = SdmtGridT(sourceDiv, this.gridData_projectvalidation, true, true);
  }

  onprojectvalidationCellClick() {

  }

  onprojectvalidationClick() {

  }

  onprojectvalidationdblClick() {

  }





  // all available Validations 

  gridData_allvalidation: any;
  gridDynamicObj_allvalidation: any;
  columnData_allvalidation: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "Label",
      "field": "label",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Message",
      "field": "msg",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Pattern",
      "field": "pattern",
      "filter": true,
      "width": "600px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_allvalidation: any = [
    {},
    {},
    {},
    {}
  ];

  allvalidation(rowData?, colData?) {
    let self = this;

    this.gridData_allvalidation = {
      columnDef: colData ? colData : this.columnData_allvalidation,
      rowDef: rowData ? rowData : this.rowData_allvalidation,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onallvalidationCellClick();
        },
        "onRowClick": function () {
          self.onallvalidationClick();
        },
        "onRowDbleClick": function () {
          self.onallvalidationdblClick();
        }
      }
      ,


      rowCustomHeight: 20,




    };

    let sourceDiv = document.getElementById("allAvailableValidation");
    this.gridDynamicObj_allvalidation = SdmtGridT(sourceDiv, this.gridData_allvalidation, true, true);
  }

  onallvalidationCellClick() {

  }

  onallvalidationClick() {

  }

  onallvalidationdblClick() {

  }

  allValidations() {
    let listOfValidations = this.sagStudioService.allValidationList;
    this.rowData_allvalidation = listOfValidations
    setTimeout(() => {
      this.allvalidation();
    }, 50)
  }




  async _startJavaCopy() {
    const projectCategoryName = this.projectStatus.projectCategoryName
    if (!projectCategoryName) {
      alerts('Please Select At Least One Project  ..!!!');
      return;
    }
    const _prjDetails_New = this.projectList.find(_itm => _itm.projectId == this.projectStatus.projectCategoryList);
    if (!_prjDetails_New) {
      alerts('Please Select At Least One Project ..!!!');
      return;
    }
    const _reqJson = {
      "newPrj": _prjDetails_New['projectname'],
      "oldPrj": this.projectStatus.projectCategoryName
    }
    this._shareService.getMenuDetId(_reqJson).subscribe(
      async (response: any) => {
        if (response["status"] == "success") {
          let conf = await ui.confirm(response['msg'] + " " + "Do You Want To Continue ??");
          if (conf == true) {
            this._javaProjectCopy(response["data"]);
          }
        }
        else if (response["status"] == "failure") {
          alerts(response['msg']);
        }
      }, error => {
        alerts("Error While copy");
      }
    );
  }
  oldIdsNewIds = []
  _javaProjectCopy(oldNewMenudetIds_) {
    this.oldIdsNewIds = []
    const projectCategoryName = this.projectStatus.projectCategoryName
    if (!projectCategoryName) {
      alerts('Please Select At Least One Project  ..!!!');
      return;
    }
    const _prjDetails_New = this.projectList.find(_itm => _itm.projectId == this.projectStatus.projectCategoryList);
    if (!_prjDetails_New) {
      alerts('Please Select At Least One Project ..!!!');
      return;
    }
    const _prjDetails_Old = this.projectList.find(_itm => _itm.projectname == this.projectStatus.projectCategoryName);
    const loginUserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    oldNewMenudetIds_.forEach(element => {
      const ids_json = {
        "oldMenudetId": element['oldmenudetId'],
        "newMenudetId": element['newmenudetId']
      }
      this.oldIdsNewIds.push(ids_json)
    });
    const _reqJson = {
      "oldProjectPath": _prjDetails_Old['jwspace'],
      "newProjectPath": _prjDetails_New['jwspace'],
      "oldProjectName": _prjDetails_Old['projectname'],
      "newProjectName": _prjDetails_New['projectname'],
      "oldProjectId": _prjDetails_Old['projectId'],
      "newProjectId": _prjDetails_New['projectId'],
      "userId": Number(loginUserId.data.clientInfo.usrId),
      "oldNewMenudetIds": this.oldIdsNewIds
    }
    this._shareService.javaProjectCopy(_reqJson).subscribe(
      (response: any) => {
        if (response["status"] == 200) {
          success(response['msg']);
        }
        else if (response["status"] == 500) {
          alerts(response['msg'])
        }
      }, error => {
        alerts("Error While copy");
      }
    );
  }

  _angProjectCopy() {
    const _prjDetails_New = this.projectList.find(_itm => _itm.projectId == this.projectStatus.projectCategoryList);
    const _prjDetails_Old = this.projectList.find(_itm => _itm.projectname == this.projectStatus.projectCategoryName);
    const projectCategoryName = this.projectStatus.projectCategoryName
    if (!projectCategoryName) {
      alerts('Please Select At Least One Project  ..!!!');
      return;
    }
    if (!_prjDetails_New) {
      alerts('Please Select At Least One Project ..!!!');
      return;
    }
    let postData = {
      "newPrj": _prjDetails_New['projectname'],
      "oldPrj": _prjDetails_Old['projectname'],
      "oldPrjPath": _prjDetails_Old['awspace'],
      "newPrjPath": _prjDetails_Old['awspace']
    }
    this._shareService.copyProjectData(postData).subscribe((response: any) => {
      if (response["status"] == "success") {
        success(response['msg']);
      }
      else if (response["status"] == "failure") {
        alerts(response['msg'])
      }
    }, error => {
      alerts("Error While copy");
    }
    )
  }

  async _startMenuCopy() {
    const projectCategoryName = this.projectStatus.projectCategoryName
    if (!projectCategoryName) {
      alerts('Please Select At Least One Project  ..!!!');
      return;
    }
    const _prjDetails_New = this.projectList.find(_itm => _itm.projectId == this.projectStatus.projectCategoryList);
    if (!_prjDetails_New) {
      alerts('Please Select At Least One Project ..!!!');
      return;
    }
    const _reqJson = {
      "newPrj": _prjDetails_New['projectname'],
      "oldPrj": this.projectStatus.projectCategoryName
    }
    this._shareService.startMenuCopy(_reqJson).subscribe(
      async (response: any) => {
        if (response["status"] == "success") {
          success(response['message']);
        }
        else if (response["status"] == "failure") {
          alerts(response['message']);
        }
      }, error => {
        alerts("Error While copy");
      }
    );
  }
  LanguageContentCopy() {
    const _prjDetails_New = this.projectList.find(_itm => _itm.projectId == this.projectStatus.projectCategoryList);
    const ref = this.dialogService.open(CopyContentComponent, {
      header: "Copy Content",
      width: "50%",
      contentStyle: { height: "275px" },
      styleClass: "",
      data: {
        'projectName': _prjDetails_New
      }
    });
    ref.onClose.subscribe((res) => {

    });
  }
  //**********************************xml generate**********************************

//   generateXmlSitemap() {
//     this.invalidDomainName = []
//     let emptyColVal = []
//     let xmlString = '';
//     let index = -1
//     let dupUrl = []
//     let isDuplicateURl = false
//     let duplicateUrlCount = 0
//     let duplicateUrlIndx = []
//     let totalCol = 0
//     let regx = /^(?!-)[A-Za-z0-9-]+([-\.]{1}[a-z0-9]+)*\.[A-Za-z]{2,6}$/;
//     const columnNames = this.selectedTags.map(column => column.name);
//     if (this.domainName.includes('http:') || this.domainName.includes('https:')) regx = /^((http|https):\/\/)(www.)?(?!-)[A-Za-z0-9-]+([\-\.]{1}[a-z0-9]+)*\.[A-Za-z]{2,6}$/
//     if (this.domainName.length > 0 && regx.test(this.domainName)) {
//       for (const row of this.locUrl) {
//         let countEmptyCol = 0
//         if (row['LOC'].length > 0) {
//           xmlString += '<url>';

//           if (row['LOC']) {
//             index++
//             let domain
//             let url = Array.isArray(row['LOC']) ? row['LOC'][0] : row['LOC']
//             const hasProtocol = url.startsWith('http://') || url.startsWith('https://');
//             if (hasProtocol) {
//               const parsedUrl = new URL(url);
//               domain = parsedUrl.origin;
//             }
//             else domain = url.split('/')[0]
//             if (regx.test(domain)) {
//               if (dupUrl.includes(url)) {
//                 let i = dupUrl.indexOf(url)
//                 duplicateUrlCount++
//                 duplicateUrlIndx.push(index, i)
//               }
//               dupUrl.push(url)
//               xmlString += `<loc>${this.protocol}${row.LOC}</loc>`;
//             } else {
//               this.invalidDomainName.push(index)
//             }
//           }
//           if (this.invalidDomainName.length === 0) {
//             if (columnNames.includes('LASTMOD') && row['LASTMOD'] !== undefined) {
//               let len = Array.isArray(row['LASTMOD']) ? row['LASTMOD'][0].length : row['LASTMOD'].length
//               if (len === 0) countEmptyCol++
//               if (!this.checkedXML || len > 0) xmlString += `<lastmod>${row['LASTMOD']}</lastmod>`
//             }
//             if (columnNames.includes('CHANGEFREQ') && row['CHANGEFREQ'] != undefined) {
//               let len = Array.isArray(row['CHANGEFREQ']) ? row['CHANGEFREQ'][0].length : row['CHANGEFREQ'].length
//               if (len === 0) countEmptyCol++
//               if (!this.checkedXML || len > 0) xmlString += `<changefreq>${row['CHANGEFREQ']}</changefreq>`;
//             }
//             if (columnNames.includes('PRIORITY') && row['PRIORITY'] != undefined) {
//               let len = Array.isArray(row['PRIORITY']) ? row['PRIORITY'][0].length : row['PRIORITY'].length
//               if (len === 0) countEmptyCol++
//               if (!this.checkedXML || len > 0) xmlString += `<priority>${row['PRIORITY']}</priority>`;
//             }
//             if (countEmptyCol > 0 && this.checkedXML) { emptyColVal.push(index), totalCol = countEmptyCol }
//             xmlString += '</url>';
//           }
//         }
//         else {
//           if (this.checkedXML) {
//             index++
//             emptyColVal.push(index)
//           }
//         }

//       }
//       if (totalCol === 0 && this.checkedXML && duplicateUrlCount > 0) {
//         isDuplicateURl = true
//         this.isDupUrlExist = true
//         emptyColVal = [...duplicateUrlIndx]
//       }
//       if (this.invalidDomainName.length === 0) {
//         xmlString = `<?xml version="1.0" encoding="UTF-8"?>
//         <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${xmlString}</urlset>`;
//         let item = isDuplicateURl ? `Rows Marked In Red Contains Duplicates Url.` : `Rows Marked In Red Contains Missing Values.`
//         if (!this.checkedXML && duplicateUrlCount > 0) {
//           this.rowWithoutColVal = []
//           emptyColVal = [...duplicateUrlIndx]
//           this.rowWithoutColVal = emptyColVal
//           let msg = `Rows Marked In Red Contains Duplicates Url.`
//           this.toastNotification(msg)
//         }
//         else if (totalCol === 0 && this.checkedXML && duplicateUrlCount > 0) {
//           emptyColVal = [...duplicateUrlIndx]
//           this.rowWithoutColVal = emptyColVal
//           let msg = `Rows Marked In Red Contains Duplicates Url.`
//           this.toastNotification(msg)
//         }
//         else if ((emptyColVal.length > 0 && this.checkedXML) || isDuplicateURl) {
//           this.rowWithoutColVal = []
//           this.rowWithoutColVal = emptyColVal
//           const refMethod = this.dialogService.open(NotificationComponent, {
//             width: '30%',
//             baseZIndex: 10000,
//             rtl: true,
//             styleClass: "customModal",
//             data: { methodData: 'siteMapAlert', item },
//             showHeader: false
//           });
//           refMethod.onClose.subscribe((res) => {
//             if (res) {
//               this.isEmptyCol = true
//             }
//             else {
//               if (duplicateUrlCount > 0) {
//                 this.isDupUrlExist = true
//                 this.finduplicateUrl()
//                 let msg = `Rows Marked In Red Contains Duplicates Url.`
//                 this.toastNotification(msg)
//               }
//               else this.writeFile(xmlString, 'xml')
//             }
//           });
//         } else {
//           if (this.locUrl.length > 0) { this.writeFile(xmlString, 'xml') }
//           else {
//             let msg = `Please add url before generating sitemap.`
//             this.toastNotification(msg)
//           }
//         }
//       } else {
//         this.rowWithoutColVal = [...this.invalidDomainName]
//         let msg = `Rows Marked In Red Contains Invalid Domain Name.`
//         this.toastNotification(msg)
//       }
//     } else {
//       this.isDomainNameExist = false
//       if (this.domainName.length === 0) {
//         let msg = `Please Enter Domain Name.`
//         this.toastNotification(msg)
//       } else {
//         let msg = `Invalid Domain Name.`
//         this.toastNotification(msg)
//       }
//     }
//   }
//   writeFile(xmlString, sitemap) {
//     this.rowWithoutColVal = []
//     let newPath = `${this.projectInfo.awspace}/src/sitemap.${sitemap}`;
//     const blob = new Blob(([xmlString]), { type: "application/xml" });
//     const writeFileOnServerData = new FormData();
//     writeFileOnServerData.append('flag', 'true');
//     writeFileOnServerData.append('path', newPath);
//     writeFileOnServerData.append('file', blob);
//     this._apiService.writeFileOnserver(writeFileOnServerData)
//       .subscribe(res => {
//         try {
//           if (res) {
//             this.toast.launch_toast({
//               type: 'success',
//               position: 'bottom-right',
//               message: res['msg']
//             })

//           }
//         } catch (error) {
//           throw error
//         }
//       });
//   }

//   openCalendar(event: any, index) {
//     this.calendarIndex = index
//     this.cdref.detectChanges();
//     if (this.calendars) {
//       this.calendars.showOverlay()
//     }
//     event.stopPropagation();
//   }
//   checkRows(row: any, i: number) {
//     if (this.rowWithoutColVal.length > 0) {
//       let noEmptyCol = false
//       for (const key of Object.keys(row)) {
//         let keys = Array.isArray(row[key]) ? row[key][0] : row[key]
//         if (keys.length > 0) {
//           noEmptyCol = true
//         }
//         else {
//           if (this.checkedXML === false && noEmptyCol) {
//             this.rowWithoutColVal = this.rowWithoutColVal.filter(ele => ele !== i)
//           }
//           noEmptyCol = false
//           break
//         }
//       }
//       if (noEmptyCol) {
//         this.rowWithoutColVal = this.rowWithoutColVal.filter(ele => ele !== i)
//       }

//       let url = Array.isArray(row['LOC']) ? row['LOC'][0] : row['LOC']
//       let name = url.split('/')[0]
//       if (this.checkedXML === false || this.isDupUrlExist && noEmptyCol) {
//         if (this.invalidDomainName.length > 0) {
//           let val = this.validateDomainName(name, 'rowsDoaminName')
//           if (val) {
//             this.rowWithoutColVal = this.rowWithoutColVal.filter(ele => ele !== i)
//             this.invalidDomainName = this.rowWithoutColVal
//           }
//           else this.rowWithoutColVal = this.invalidDomainName
//         }
//         else this.finduplicateUrl()

//       }
//       else if (this.checkedXML === true && this.isDupUrlExist || this.invalidDomainName.length > 0) {
//         if (this.invalidDomainName.length > 0) {
//           this.validateDomainName(name)
//           if (this.isDomainNameExist) this.rowWithoutColVal = this.rowWithoutColVal.filter(ele => ele !== i)
//         }
//         else this.finduplicateUrl()

//       }
//     }

//   }

//   addUrl() {
//     let id = {
//       "projectId": this.projectInfo.projectId
//     }
//     const res = new Promise<any[]>((resolve, reject) => {
//       this._shareService.getUrl(id).subscribe((res: any) => {
//         if (res.length > 0) {
//           this.isCorrectSitemap = true;
//           resolve(res);
//         } else {
//           resolve([]);
//         }
//       }, error => {
//         reject(error);
//       });
//     })
//     res.then((urlData: any[]) => {
//       const dialogRef = this.dialogService.open(CopyContentComponent, {
//         header: 'Select URL From Database',
//         width: '35%',
//         contentStyle: { "box-shdow": "none", height: "500px" },
//         styleClass: 'SelectDatabase',
//         data: {
//           sitemapData: urlData,
//           isSitemap: true,
//           domainName: this.domainName
//         }
//       });
//       dialogRef.onClose.subscribe((res) => {
//         if (res !== undefined && res.length > 0) {
//           for (const tag of res) {
//             this.columns.map(column => {
//               if (column && !tag.hasOwnProperty(column.name)) {
//                 tag[column.name] = column.value;
//               }
//             });
//           }
//           res = res.filter(ele => {
//             return !this.locUrl.some(url => {
//               let loc = Array.isArray(url['LOC']) ? url['LOC'][0] : url['LOC'];
//               return loc === ele['LOC'];
//             });
//           });

//           this.locUrl = this.locUrl.concat(res);
//         }
//       })
//     }).catch(error => {
//     });
//   }
//   addEntry() {
//     let columnsArr = []
//     this.isCorrectSitemap = true
//     this.columns.map(column => {
//       if (column && !columnsArr.hasOwnProperty(column.name)) {
//         columnsArr[column.name] = column.value;
//       }
//     });

//     if (this.domainName.length > 0) {
//       this.locUrl.push({ LOC: this.domainName + '/', ...columnsArr });
//     }
//     else this.locUrl.push({ LOC: '', ...columnsArr });
//   }

//   finduplicateUrl() {
//     this.rowWithoutColVal = []
//     let dupURL = []
//     this.locUrl.filter((ele, indx) => {
//       let loc = Array.isArray(ele['LOC']) ? ele['LOC'][0] : ele['LOC']
//       if (dupURL.includes(loc)) {
//         let i = dupURL.indexOf(loc)
//         this.rowWithoutColVal.push(indx, i)
//       }
//       dupURL.push(loc)
//     })
//   }

//   removeEntry(index: number) {
//     if (index >= 0 && index < this.locUrl.length) {
//       this.locUrl.splice(index, 1)
//       if (this.rowWithoutColVal.length > 0) {
//         this.rowWithoutColVal = this.rowWithoutColVal.filter(i => i !== index)
//         if (this.isDupUrlExist || this.checkedXML === false) this.finduplicateUrl()
//       }
//     }
//   }

//   updateColumns(loc) {
//     const updatedColumns = []
//     for (const tag of this.selectedTags) {
//       const existingColumn = this.columns.find(column => column.name === tag.name);
//       if (existingColumn) {
//         updatedColumns.push(existingColumn);
//       } else {
//         updatedColumns.push({ name: tag.name, value: tag.value });

//       }
//     }
//     this.columns = updatedColumns;
//     for (const tag of loc) {
//       this.columns.map(column => {
//         if (column && !tag.hasOwnProperty(column.name)) {
//           tag[column.name] = column.value;
//         }
//       });
//     }
//   }

//   handleInput(event: any, item): void {
//     const inputValue = event.target.value;
//     if (inputValue.startsWith(this.domainName)) {
//       item.LOC = item.LOC
//     }
//   }

//   getUrlSitemap() {
//     let filePath = {
//       filePath: `${this.projectInfo.awspace}/src/sitemap.xml`
//     }
//     let id = {
//       "projectId": this.projectInfo.projectId
//     }
//     this._shareService.getXml(filePath).subscribe(res => {
//       this.isSiteMapExist = res['isfileexist']
//       const parser = new xml2js.Parser({ strict: false, trim: true });
//       parser.parseString(res['xmlstr'], (err, result) => {
//         this.xml = result;
//         if (res['xmlstr'] !== "") {
//           this.sitemapData = result
//           let sitemap: [] = result['URLSET']['URL']
//           let domain = result['URLSET']['URL'][0].LOC[0]
//           let returnSitMap = this.checkEmptyCol(sitemap)
//           if (!this.isValidSiteMap) {
//             let item = "A URL in your sitemap is not valid."
//             const refMethod = this.dialogService.open(NotificationComponent, {
//               width: '30%',
//               baseZIndex: 10000,
//               rtl: true,
//               styleClass: "customModal",
//               data: { methodData: 'siteMapAlert', item },
//               showHeader: false
//             });
//             refMethod.onClose.subscribe((res) => {
//               if (res) {
//                 this.fetchingURL(id)
//                   .then((url: any[]) => {
//                     if (this.isReload) this.domainName = ''
//                     this.locUrl = url;
//                   })
//                   .catch(error => {
//                   });
//               }
//               else {
//                 this.getDomainName(returnSitMap, domain)
//               }
//             });
//           } else {
//             this.getDomainName(returnSitMap, domain)
//           }
//         }
//         else {
//           this.fetchingURL(id)
//             .then((url: any[]) => {
//               this.locUrl = url;
//             })
//             .catch(error => {
//             });
//         }
//       });

//     })
//   }
//   fetchingURL(id) {
//     this.locUrl = [];
//     this.columns = [];
//     this.selectedTags = [];
//     return new Promise<any[]>((resolve, reject) => {
//       this._shareService.getUrl(id).subscribe((res: any) => {
//         if (res.length > 0) {
//           this.isCorrectSitemap = true;
//           resolve(res);
//         } else {
//           resolve([]);
//         }
//       }, error => {
//         reject(error);
//       });
//     });
//   }
//   getDomainName(siteMap, domain) {
//     this.locUrl = siteMap['xmlData']
//     this.selectedTags = siteMap['selectedTags']
//     this.columns = this.selectedTags
//     this.isCorrectSitemap = true
//     for (const tag of this.locUrl) {
//       this.columns.map(column => {
//         if (column && !tag.hasOwnProperty(column.name)) {
//           tag[column.name] = column.value;
//         }
//       });
//     }
//     const hasProtocol = domain.startsWith('http://') || domain.startsWith('https://');
//     if (hasProtocol) {
//       const baseURL = new URL(domain).hostname
//       this.domainName = baseURL
//       this.previousDomain = baseURL
//     }
//     else {
//       if (domain.includes('/')) {
//         this.domainName = domain.split('/')[0]
//         this.previousDomain = this.domainName
//       }
//     }
//   }

//   checkEmptyCol(xmlData) {
//     let maxLenObject = [];
//     let compareKeys = []
//     xmlData = xmlData.filter((ele) => {
//       let url = Array.isArray(ele['LOC']) ? ele['LOC'][0] : ele['LOC']

//       if (ele.hasOwnProperty('LOC') && url.length > 0) {
//         if (ele['CHANGEFREQ'] !== undefined) {
//           let isFirstCapital: boolean = typeof ele['CHANGEFREQ'][0] === 'string' && ele['CHANGEFREQ'][0].charAt(0) === ele['CHANGEFREQ'][0].charAt(0).toUpperCase();
//           if (isFirstCapital) ele['CHANGEFREQ'] = Array.isArray(ele['CHANGEFREQ']) ? ele['CHANGEFREQ'][0].toLowerCase() : ele['CHANGEFREQ'].toLowerCase()
//         }

//         if (Array.isArray(ele.LASTMOD)) {
//           var dateObject = new Date(ele.LASTMOD[0])
//           if (!isNaN(dateObject.getTime())) {
//             var formattedDate = dateObject.toISOString().substring(0, 10);
//             ele.LASTMOD = formattedDate;
//           } else ele.LASTMOD = ele.LASTMOD[0]
//         }
//         if (url.includes('http:') || url.includes('https:')) {
//           url = url.split('/')
//           url = url.splice(2)
//           ele.LOC = url.join('/')
//         }

//         const uniqueKeys = Object.keys(ele).filter(item => !compareKeys.includes(item))
//         maxLenObject.push(uniqueKeys);
//         compareKeys.push(ele)
//         return true
//       }
//       else {
//         this.isValidSiteMap = false
//         return false
//       }
//     });
//     const uniqueKeys = maxLenObject.reduce((keys, arr) => {
//       arr.forEach(key => {
//         if (!keys.includes(key)) {
//           keys.push(key);
//         }
//       });
//       return keys;
//     }, []);

//     let selectedTags = this.tagOptions.filter(tag => uniqueKeys.includes(tag.name));
//     return {
//       'xmlData': xmlData,
//       'selectedTags': selectedTags
//     }
//   }
//   onKeydown(event: KeyboardEvent) {
//     const disallowedKeys = /[!@#$%^&*()+=[\]{};'"\\|,<>\/? `:_~]/;
//     if (disallowedKeys.test(event.key)) {
//       event.preventDefault();
//     }
//   }
//   onDomainName(domainName: string) {
//     const domainWithoutWww = domainName.replace(/^www\./, '');
//     const startsOrEndsWithHyphen = /^-|-\./;
//     const hasHyphenAfterCom = /\.com-/;
//     this.isDomainNameExist = true
//     if (!startsOrEndsWithHyphen.test(domainWithoutWww) && !hasHyphenAfterCom.test(domainWithoutWww)) {
//       this.locUrl = this.locUrl.map(ele => {
//         let name;
//         let urlNode = Array.isArray(ele.LOC) ? ele.LOC[0] : ele.LOC;
//         if (domainName.length > 0) {
//           if (urlNode.includes("/") || urlNode.includes("-")) {
//             if (this.previousDomain === undefined || this.previousDomain.length <= 0) {
//               ele['LOC'] = domainName + '/' + urlNode
//             }
//             else {
//               try {
//                 const parsedUrl = new URL(urlNode.includes('http:') || urlNode.includes('https:') ? urlNode : 'http://' + urlNode);
//                 name = parsedUrl.pathname.substring(1);
//                 const queryParams = parsedUrl.search;
//                 const fragment = parsedUrl.hash;
//                 let fullPath = name;
//                 if (queryParams) {
//                   fullPath += queryParams;
//                 }
//                 if (fragment) {
//                   fullPath += fragment;
//                 }
//                 if (parsedUrl.pathname === "/") {
//                   if (this.previousDomain + '/' === urlNode || this.previousDomain !== urlNode) ele['LOC'] = domainName + '/'
//                   else {
//                     if (urlNode.includes('//')) {
//                       let check = urlNode.split('//')
//                       check.slice(1)
//                       ele['LOC'] = domainName + check.slice(1)
//                     }
//                   }
//                 }

//                 else ele['LOC'] = domainName + '/' + fullPath

//               } catch (error) {
//                 let url = urlNode.split('/')
//                 url = url.splice(1)
//                 ele['LOC'] = domainName + '/' + url.join('/')

//               }
//             }
//           } else if (!urlNode) ele['LOC'] = domainName + '/'
//           else {
//             ele['LOC'] = domainName + '/' + urlNode
//           }
//         }
//         else {
//           if (urlNode.includes("/")) {
//             if (this.previousDomain === undefined || this.previousDomain.length <= 0) {
//               ele['LOC'] = urlNode
//             } else {
//               try {
//                 const parsedUrl = new URL(urlNode.includes('http:') || urlNode.includes('https:') ? urlNode : 'http://' + urlNode);
//                 if (parsedUrl.pathname === "/") ele['LOC'] = ""
//                 else {
//                   name = parsedUrl.pathname.substring(1);
//                   const queryParams = parsedUrl.search;
//                   const fragment = parsedUrl.hash;
//                   let fullPath = name;
//                   if (queryParams) {
//                     fullPath += queryParams;
//                   }
//                   if (fragment) {
//                     fullPath += fragment;
//                   }
//                   ele['LOC'] = fullPath
//                 }

//               } catch (error) {
//                 let url = urlNode.split('/')
//                 url = url.splice(1)
//                 ele['LOC'] = url.join('/')
//               }
//             }
//           }
//           else {
//             ele['LOC'] = ele['LOC']
//           }
//         }
//         return ele
//       });
//     }
//     this.previousDomain = domainName
//   }

  closeModal() {
    this.modalRef.close(false);
  }

//   removeValidation() {
//     if (this.rowWithoutColVal.length > 0 && !this.checkedXML) this.rowWithoutColVal = []
//   }

//   validateDomainName(domainName, rowsDoaminName?) {
//     let regx
//     if (domainName.includes('http:') || domainName.includes('https:')) regx = /^((http|https):\/\/)(www.)?(?!-)[A-Za-z0-9-]+([\-\.]{1}[a-z0-9]+)*\.[A-Za-z]{2,6}$/
//     else regx = /^(?!-)[A-Za-z0-9-]+([-\.]{1}[a-z0-9]+)*\.[A-Za-z]{2,6}$/;
//     if (regx.test(domainName)) {
//       this.isDomainNameExist = true
//       if (rowsDoaminName) return true
//       else { if (this.invalidDomainName.length > 0) this.rowWithoutColVal = [] }
//     } else {
//       if (this.invalidDomainName.length > 0) return false
//       else {
//         this.isDomainNameExist = false
//         let msg = `Invalid Domain Name `
//         this.toastNotification(msg)
//       }
//     }
//   }
//   toastNotification(msg) {
//     this.toast.launch_toast({
//       type: 'alert',
//       position: 'bottom-right',
//       message: msg
//     });
//   }

//   reloadSitemap() {
//     this.getUrlSitemap()
//     this.isReload = true
//   }
//   // ***********************HTML SITEMAP*************************************************
//   htmlSitemap: any
//   addChild: boolean = false
//   showHtmlPaths: Boolean = false
//   htmlsiteMapData: [] = []
//   countPage = 0
//   htmlDomainName = ''
//   htmlTab() {
//     this.showHtml = true
//     let reqJson = {
//       "device": "web",
//       "projectName": this.projectInfo.projectname
//     }
//     this._shareService.getMenuJson(reqJson).subscribe(((res: any) => {
//       this.htmlSitemap = res[0].children
//     }))
//   }
//   addChildEleRow(item) {
//     this.addChild = true
//     item['children'].push({
//       properties: {
//         name: ''
//       },
//       children: [],
//       collapsed: true,
//       routerLink: '',
//       routeLinkPath: ''
//     });
//   }
//   updateRouterLink(item, event) {
//     item.routeLinkPath = event.target.value
//   }
//   deleteHTMLRow(item, index) {
//     item.splice(index, 1);
//   }

//   showAllPaths() {
//     this.showHtmlPaths = true
//   }

//   generateHTMLSitemap(node) {
//     let html = ''
//     html += `<li class="lhead"> 
//     <a href="${this.htmlDomainName}/${node.routerLink}">
//     <span>${node.properties.name}</span></a></li>`;

//     if (node.children && node.children.length > 0 && node.children[0].properties.name !== '') {
//       html += '<li class="lpage last-page">';
//       html += '<ul>';
//       for (const childNode of node.children) {
//         html += this.generateHTMLSitemap(childNode);
//       }
//       html += '</ul>';
//       html += '</li>';
//     } else {
//       html += '<li class="lpage last-page">';
//       html += '</li>';
//     }
//     this.countPage++
//     return html;
//   }

//   saveHTMLSitemap() {
//     if(this.htmlDomainName.length>0 && this.htmlDomainName.includes('https://') || this.htmlDomainName.includes('http://')){this.htmlDomainName=this.htmlDomainName}
//     else{
//       if(this.htmlDomainName.length>0) this.htmlDomainName='http://'+this.htmlDomainName}
//     const lastUpdatedString = this.getLastUpdatedString();
//     let htmlstring = ''
//     for (const node of this.htmlSitemap) {
//       htmlstring += this.generateHTMLSitemap(node);
//     }
//     htmlstring = `<!DOCTYPE html>
//       <html lang="en">
//       <head>   
//       <meta charset="utf-8">
//       <title>${this.htmlDomainName} HTML SITE MAP</title>
//       <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
//       <style type="text/css">
//         body {
//           background-color: #fff;
//           font-family: "Roboto", "Helvetica", "Arial", sans-serif;
//           margin: 0;
//         } 
//         #top {
//           background-color: #b1d1e8;
//           font-size: 16px;
//           padding-bottom: 40px;
//         }
//         nav {
//           font-size: 24px;
//           margin: 0px 30px 0px;
//           border-bottom-left-radius: 6px;
//           border-bottom-right-radius: 6px;
//           background-color: #f3f3f3;
//           color: #666;
//           box-shadow: 0 10px 20px -12px rgba(0, 0, 0, 0.42), 0 3px 20px 0px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);
//           padding: 10px 0;
//           text-align: center;
//           z-index: 1;
//         }
  
//         h3 {
//           margin: auto;
//           padding: 10px;
//           max-width: 600px;
//           color: #666;
//         }
//         h3 span {
//           float: right;
//         }
//         h3 a {
//           font-weight: normal;
//           display: block;
//         }
//       #htmlsiteMap {
//         position: relative;
//         border-radius: 6px;
//         box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);
//         background: #f3f3f3;
//         margin: -20px 30px 0px 30px;
//         padding: 20px;
//       }
//       a{
//         cursor: pointer;
//       }
//       a:link,
//       a:visited {
//         color: black;
//         color: #0180AF;
//         text-decoration: underline;
//       }
//       a:hover {
//         color: #666;
//       }
//     ul {
//         margin: 0px;
//         padding: 0px;
//         list-style: none;
//     }
//     li {
//       margin: 0px;
//     }
//     li ul {
//       margin-left: 20px;
//     }
//     .lhead {
//       background: #ddd;
//       padding: 10px;
//         margin: 10px 0px;
//     }
//     .lpage {
//       border-bottom: #ddd 1px solid;
//       padding: 5px;
//     }
//     .last-page {
//       border: none;
//   }
//     </style>
//     </head>
//     <body>
//     <div id="top">
//    <nav>${this.htmlDomainName.split('//')[1]} HTML Site Map</nav>
//    <h3 >
//     <span>${lastUpdatedString}<br> Total pages: ${this.countPage}</span>
//     <a href="${this.htmlDomainName}" style="color: #0180AF;
//     text-decoration: underline; cursor: pointer;">${this.htmlDomainName.split('//')[1]} Homepage</a>
//     </h3>
//     </div> 
//     <div id="htmlsiteMap"><ul>${htmlstring}</ul></div>
//   </body>
//     </html> `
//     this.writeFile(htmlstring, 'html')
//   }
//   getLastUpdatedString(): string {
//     const currentDate = new Date();
//     const formattedDate = currentDate.toLocaleDateString('en-US', {
//       year: 'numeric',
//       month: 'long',
//       day: 'numeric'
//     });

//     return `Last updated: ${formattedDate}`;
//   }

//   // ************************************ Meta Tag Start ****************************
//   showVar: boolean = false;
//   hideArea: boolean = false;
//   titleContent = 'This is dummy content';

//   getRouteArrayOfPage() {

//     this.metaKeywordList = [
//       {
//         "label": "Select",
//         "value": ""
//       },
//       {
//         "label": "CHARSET",
//         "value": "charset"
//       },
//       {
//         "label": "CONTENT",
//         "value": "content"
//       },
//       {
//         "label": "HTTP-EQUIV",
//         "value": "http-equiv"
//       },
//       {
//         "label": "ID",
//         "value": "id"
//       },
//       {
//         "label": "ITEMPROP",
//         "value": "itemprop"
//       },
//       {
//         "label": "NAME",
//         "value": "name"
//       },
//       {
//         "label": "PROPERTY",
//         "value": "property"
//       },
//       {
//         "label": "SCHEME",
//         "value": "scheme"
//       },
//       {
//         "label": "URL",
//         "value": "url"
//       },

//     ];
//     this.routeFileName = this.sagStudioService.currentActiveProject.currentActiveFileNode.id.replace(".component", "-routing.module.ts");
//     let projectPathName = this.sagStudioService.currentActiveProject.currentActiveFileNode.projectPath
//     this.filePath1 = projectPathName.substring(projectPathName.indexOf("src"))
//     this.projectInfo1 = this._shareService.getDataprotool("selectedProjectChooseData");

//   }

//   addRow(metaList) {
//     let obj = {
//       'metaKey': '',
//       'metaValue': ''
//     }
//     metaList.push(obj)
//   }

//   deleteRow(metaList, index) {
//     metaList.splice(index, 1);
//   }

//   close() {
//     this.modalRef.close();
//   }
//   updateMetaKey1(event, meta) {
//     meta.metaKey = event;
//   }
//   updateMetaValue1(event, meta) {
//     meta.metaValue = event.target.value;
//   }


//   finalMetaSave() {
//     let json = {
//       "projectId": this.projectInfo1['projectId'],
//       "filePath": this.radioValue == 'manual' ? '' : this.filePath1,
//       "title": this.titleContent,
//       "pageRoute": this.radioValue == 'manual' ? 
//       (this.metaInfo.pageRoute.includes('/') ? this.metaInfo.pageRoute : '/'+this.metaInfo.pageRoute) 
//       : this.selectedMetaArr[0]['metaUrl'][0],
//       "meta": [],
//       "desc":this.descContent
//     }

//     let pageData = [];
//     for (let index = 0; index < this.rowData_metadata.length; index++) {
//       let objec = {};
//       let elem = this.rowData_metadata[index];
//       if (elem.details.length > 0) {
//         for (let i = 0; i < elem.details.length; i++) {
//           let el = elem.details[i];
//           objec[el.metaKey] = el.metaValue
//         }
//       }
//       pageData.push(objec)
//     }
//     json['meta'] = pageData;
//     this._apiService.saveMetaInfo(json).subscribe((res) => {
//       if (res && res['status'] == 'success') {
//         this.toast.launch_toast({
//           type: 'success',
//           position: 'bottom-right',
//           message: res['msg'],
//         });
//         if(this.disableModify) {
//           let element = document.getElementById('pills-list-tab');
//           element.click()
//         }
//         this.disableModify = false
//         this.modifyRoutesData();
//         this.metaInfo = { route_from : '', route_to : '', pageRoute : ''};
//       }
//     });

//   }
//   gridData_metadata: any;
//   gridDynamicObj_metadata: any;
//   columnData_metadata: any = [
//     {
//       "header": "Meta",
//       "field": "meta",
//       "filter": true,
//       "width": "100px",
//       "editable": "false",
//       "text-align": "left",
//       "search": true,
//       "component": "label",
//       "cellRenderView": false,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,

//     },
//     {
//       "header": "Meta Key",
//       "field": "metaKey",
//       "filter": true,
//       "width": "200px",
//       "editable": "false",
//       "text-align": "left",
//       "search": true,
//       "component": "label",
//       "cellRenderView": false,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,

//     },
//     {
//       "header": "Meta Value",
//       "field": "metaValue",
//       "filter": true,
//       "width": "200px",
//       "editable": "false",
//       "text-align": "left",
//       "search": true,
//       "component": "label",
//       "cellRenderView": false,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,

//     },
//     {
//       "header": "Delete",
//       "field": "Delete",
//       "filter": true,
//       "width": "100px",
//       "editable": "false",
//       "text-align": "left",
//       "search": true,
//       "component": "dynamicComponent",
//       "cellRenderView": true,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,
//       // "button": { "imgsrc": "", "iconclass": "fa fa-delete", "iconPosition": "", "name": "delete", "classes": ["btn", "btn-danger"], "attribute": "", "styles": "" },

//     },
//   ];

//   rowData_metadata: any = [];
//   validationmetadata: any = {}

//   metadata(rowData?: any, colData?: any) {
//     let self = this;

//     this.gridData_metadata = {
//       columnDef: colData ? colData : this.columnData_metadata,
//       rowDef: rowData ? rowData : this.rowData_metadata,
//       footer_hide: true,
//       totalNoOfRecord_hide: true,
//       sml_expandGrid_hide: true,
//       exportXlsxPage_hide: true,
//       exportXlsxAllPage_hide: true,
//       exportPDFLandscape_hide: true,
//       exportPDFPortrait_hide: true,
//       ariaHidden_hide: true,
//       disableAllSearch: false,
//       wordBreak: false,
//       wordBreakHeader: false,
//       cellHover: false,
//       rowHover: false,
//       rowBorder_hide: false,
//       columnBorder_hide: false,
//       header_hide: false,
//       gridbody_hide: false,
//       rowLineSpace: 0,
//       multiHeader: false,
//       common_search: false,
//       common_search_column: "",
//       common_filter: false,
//       common_filter_column: "",
//       validation: this.validationmetadata,
//       newPagination: false,
//       recordPerPage: 10,
//       ellipsisV: {},
//       components: {},
//       callBack: {
//         "rowDelete": function (ele: any, param: any) {
//           debugger
//           const pos = self.rowData_metadata.map(e => e.meta).indexOf(param.rowValue.meta);
//           self.rowData_metadata.splice(pos, 1);
//           self.metadata()
//         },
//         "onCellClick": function (ele: any) {
//           debugger
//           self.onmetadataCellClick();
//         },
//         "onRowClick": function () {
//           debugger
//           self.onmetadataClick();
//         },
//         "onRowDbleClick": function () {
//           debugger
//           self.onmetadatadblClick();
//         }
//       }
//       ,

//       rowCustomHeight: 20,
//       plusButton_obj: {},
//       rowGrouping: {
//         "enable": true,
//         "allowClick": true,
//         "groupType": "custome",
//         "groupBy": "meta",
//       },



//     };

//     let sourceDiv = document.getElementById("metadata");
//     this.gridDynamicObj_metadata = SdmtGridT(sourceDiv, this.gridData_metadata, true, true);
//   }

//   onmetadataCellClick() { }

//   onmetadataClick() { }

//   onmetadatadblClick() { }
//   selectedMetaArr = [];
//   fixedMetaData = []
//   createArr = []
//   selectPageRouteOption(event?) {
//     let selectedPage;
//     this.rowData_metadata = [];
//     this.createArr = []
//     if(this.radioValue == 'manual') {
//       selectedPage = {
//         module : this.metaInfo.route_to,
//         moduleName : this.metaInfo.route_from,
//         metaUrl : this.metaInfo.pageRoute
//       }
//     } else {
//       selectedPage = this.metaData[event.srcElement.options.selectedIndex - 1] != undefined ? this.metaData[event.srcElement.options.selectedIndex - 1] : '';
//     }
//     this.selectedMetaArr = [];
//     this.selectedPath = '';
//     this.selectedPath = selectedPage.path;
//     this.selectedMetaArr.push(selectedPage);
//     // this.fixedMetaData.push(selectedPage.data[0])
//     this.titleContent = this.selectedMetaArr[0].title
//     this.descContent = this.selectedMetaArr[0].desc

//     if (selectedPage && selectedPage.meta && selectedPage.meta.length > 0) {

//       for (let index = 0; index < selectedPage.meta.length; index++) {
//         let keyVal = selectedPage.meta[index];;
//         let keys = Object.keys(keyVal);
//         let values = Object.values(keyVal);
//         let obj = {};
//         obj["meta"] = `Meta${index + 1}`;
//         obj['dynamicCompName_Delete'] = 'rowDelete';
//         obj["details"] = []
//         for (let index = 0; index < keys.length; index++) {
//           const element = keys[index];
//           for (let i = 0; i < values.length; i++) {
//             const elem = values[i];
//             if (index == i) {
//               obj["details"].push(
//                 {
//                   "meta": index + 1,
//                   "metaKey": element,
//                   "metaValue": elem,
//                   'dynamicCompName_Delete': 'label',
//                   'Delete': '',
//                 }
//               )
//             }
//           }
//         }
//         this.createArr.push(obj)

//       }
//     }
//   }
//   metaDataShowInGrid1(data) {
//     let obj = {};
//     obj["meta"] = `Meta${this.rowData_metadata.length + 1}`;
//     obj["details"] = []
//     obj['dynamicCompName_Delete'] = 'rowDelete';
//     for (let index = 0; index < data.length; index++) {
//       const element = data[index];
//       obj["details"].push(
//         {
//           "meta": index + 1,
//           "metaKey": element.metaKey,
//           "metaValue": element.metaValue,
//           'dynamicCompName_Delete': 'label',
//           'Delete': '',
//         }
//       )
//       element.metaKey = '';
//       element.metaValue = '';
//     }
//     this.rowData_metadata.push(obj)
//     this.metadata();
//   }

//   addInTable() {
//     // this.fixedMetaData = [];
//     let defaultFileds = {
//       'metaKey': '',
//       'metaValue': ''
//     }
//     this.fixedMetaData.push(defaultFileds)

//   }

//   availableMenuFiles: any = [];
//   getMenu() {
//     if (this.selectedProject) {
//       let obj = {
//         // "projectName": this.selectedProject.projectname,
//         "projectId": this.selectedProject.projectId
//       }
//       this._shareService.getTotalroutesProject(obj).subscribe((res) => {
//         if (res) {
//           this.availableMenuFiles = res;
//         }
//       });
//     }
//   }
//   selectPageOption(event, edit?) {
//     this.rowData_metadata = []
//     this.metaData = []
//     let selectNode = this.availableMenuFiles.filter(x => x.moduleName == event.target.value)[0];

//     this.projectInfo1 = this._shareService.getDataprotool("selectedProjectChooseData");
//     if (this.projectInfo1) {
//       let obj = {
//         "projectId": this.projectInfo1['projectId'],
//         "unifilepath": selectNode.matchableId
//       }
//       this._apiService.getRouteArray(obj).subscribe((res: any) => {
//         this.metaData = res.map((e) => { return e; });;
//         if(edit) {
//           let idx = this.metaData.findIndex(res => res.module == edit.module);
//           this.selectPageRouteOption({srcElement : {options : {selectedIndex : idx+1}}})
//         }
//       });
//     }
//   }

//   showRoutesData() {
//     if(this.radioValue == 'manual') {
//       this.selectPageRouteOption()
//     }
//     this.fixedMetaData = [];
//     let defaultFileds = {
//       'metaKey': '',
//       'metaValue': ''
//     }
//     this.fixedMetaData.push(defaultFileds)
//     this.showVar = true;
//     this.hideArea = true;
//     this.rowData_metadata = []
//     this.rowData_metadata = this.createArr
//     setTimeout(() => {
//       this.metadata();
//     }, 100)
//   }
//   modifyRoutesData() {
//     if(!this.disableModify) {
//       this.showVar = false;
//       this.hideArea = false;
//     }
//   }
//   titleContentMethod(event) {
//     this.titleContent = event.target.value
//   }
//   gridData_axis: any;
//   gridDynamicObj_axis: any;
//   columnData_axis: any = [
//     {
//       "hidden": false,
//       "editable": "false",
//       "filter": false,
//       "search": true,
//       "component": "label",
//       "field": "sno",
//       "freezecol": "null",
//       "width": "50px",
//       "header": "S.No",
//       "text-align": "left",
//     },
//     {
//       "hidden": false,
//       "search": true,
//       "cellHover": false,
//       "text-align": "left",
//       "editable": "false",
//       "sort": false,
//       "filter": false,
//       "component": "text",
//       "field": "url",
//       "freezecol": "null",
//       "width": "200px",
//       "header": "Url",
//       "cellRenderView": false,
//     },
//     {
//       "header": "Allowed",
//       "field": "allowed",
//       "filter": false,
//       "width": "250px",
//       "editable": "false",
//       "text-align": "center",
//       "search": true,
//       "component": "multiSelect",
//       "cellRenderView": true,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,
//     },
//     {
//       "header": "Refused",
//       "field": "refused",
//       "filter": false,
//       "width": "250px",
//       "editable": "false",
//       "text-align": "center",
//       "search": true,
//       "component": "multiSelect",
//       "cellRenderView": true,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,
//     },
//     {
//       "header": "same as default",
//       "field": "sameAsDefault",
//       "filter": false,
//       "width": "250px",
//       "editable": "false",
//       "text-align": "center",
//       "search": true,
//       "component": "multiSelect",
//       "cellRenderView": true,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,
//     },
//     {
//       "header": "Add Row",
//       "field": "addRow",
//       "filter": false,
//       "width": "260px",
//       "editable": "false",
//       "text-align": "center",
//       "search": true,
//       "component": "plusButton",
//       "cellRenderView": true,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,
//     },
//     {
//       "header": "Delete Row",
//       "field": "deleteRow",
//       "filter": false,
//       "width": "245px",
//       "editable": "false",
//       "text-align": "center",
//       "search": true,
//       "component": "rowDelete",
//       "cellRenderView": true,
//       "freezecol": "null",
//       "hidden": false,
//       "sort": false,
//       "cellHover": false,
//     },
//   ];

//   rowData_axis: any = [
//     { url: "url" },
//     {},
//     {},
//     {}
//   ];
//   validationaxis: any = {}
//   crawler: any = [{ "key": 'Google', "val": 'Googlebot' },
//   { "key": 'Google Image', "val": 'googlebot-image' },
//   { "key": 'Google Mobile', "val": 'googlebot-mobile' },
//   { "key": 'MSN Search', "val": 'MSNBot' },
//   { "key": 'Yahoo', "val": 'Slurp' },
//   { "key": 'Yahoo MM', "val": 'yahoo-mmcrawler' },
//   { "key": 'Yahoo Blogs', "val": ' yahoo-blogs/v3.9' },
//   { "key": 'Ask/Teoma', "val": 'Teoma' },
//   { "key": 'GigaBlast', "val": 'Gigabot' },
//   { "key": 'DMOZ Checker', "val": 'Robozilla' },
//   { "key": 'Nutch', "val": 'Nutch' },
//   { "key": 'Alexa/Wayback', "val": 'ia_archiver' },
//   { "key": 'Baidu', "val": 'baiduspider' },
//   { "key": 'Naver', "val": 'naverbot' },
//   { "key": 'MSN PicSearch', "val": 'psbot' }]

//   robotTxtGrid(rowData?: any, colData?: any) {
//     let self = this;
//     let mobileWebItem = ""
//     let allowed_Json: any = this.crawler;
//     let refused_Json: any = this.crawler;
//     let sameAsDefault_Json: any = this.crawler;
//     this.gridData_axis = {
//       columnDef: colData ? colData : this.columnData_axis,
//       rowDef: rowData ? rowData : this.rowData_axis,
//       footer_hide: true,
//       totalNoOfRecord_hide: false,
//       sml_expandGrid_hide: false,
//       exportXlsxPage_hide: false,
//       exportXlsxAllPage_hide: false,
//       exportPDFLandscape_hide: false,
//       exportPDFPortrait_hide: false,
//       ariaHidden_hide: false,
//       disableAllSearch: false,
//       wordBreak: false,
//       wordBreakHeader: false,
//       cellHover: false,
//       rowHover: false,
//       rowBorder_hide: false,
//       columnBorder_hide: false,
//       header_hide: false,
//       gridbody_hide: false,
//       rowLineSpace: 0,
//       multiHeader: false,
//       common_search: false,
//       common_search_column: "",
//       common_filter: false,
//       common_filter_column: "",
//       validation: this.validationaxis,
//       newPagination: false,
//       recordPerPage: 10,
//       exportBtn: (mobileWebItem == 'mobile') ? false : false,
//       newExpandExportTotalRecord_hide: undefined,
//       commonSearchSelect_hide: (mobileWebItem == 'mobile') ? false : false,
//       commonFilterSelect_hide: (mobileWebItem == 'mobile') ? false : false,
//       orderArray: (mobileWebItem == 'mobile') ? ["sno", "url", "allowed", "refused", "sameAsDefault", "addRow", "deleteRow"] : ["sno", "url", "allowed", "refused", "sameAsDefault", "addRow", "deleteRow"],
//       ellipsisV: {},
//       gridRowAddDeleteButton: "undefined",
//       components: {},
//       callBack: {
//         "onPlusButton_addRow": function (ele: any, param: any) {
//         },
//         "onCellClick": function (ele: any) {

//           self.onaxisCellClick();
//         },
//         "onRowClick": function () {
//           self.onaxisClick();
//         },
//         "onRowDbleClick": function () {
//           self.onaxisdblClick();
//         }
//       },
//       rowCustomHeight: 20,
//       plusButton_obj: {},
//       "multidropDownJson_allowed": allowed_Json,
//       "multidropDownJson_refused": refused_Json,
//       "multidropDownJson_sameAsDefault": sameAsDefault_Json,
//     };
//     let sourceDiv = document.getElementById("robotsgrid");
//     this.gridDynamicObj_axis = SdmtGridT(sourceDiv, this.gridData_axis, true, true);
//   }

//   onaxisCellClick() {

//   }

//   onaxisClick() {

//   }

//   onaxisdblClick() {

//   }

//   // *********************************SEO CODE START***************************************************
//   checkResult() {
//     const result = document.getElementById('check_content').classList.toggle('show');
//     this.generateUrlList = JSON.parse(JSON.stringify(this.gridDynamicObj_axis.sagGridObj.rowData));
//     this.generateRobotTxtFormate();
//   }

//   hidepopup() {
//     const showpop = document.getElementById('check_content').classList.remove('show');
//   }

//   getRobotsTxtPathList() {
//     let projectId = { "projectId": this.projectInfo.projectId }
//     this._shareService.getUrl(projectId).subscribe((res) => {
//       this.urlPathList = JSON.parse(JSON.stringify(res));
//       if (res) {
//         this.urlPathList = this.urlPathList.map((res) => {
//           return { label: `${res.LOC}`, value: `${res.LOC}` }
//         });
//       } else {
//         this.toast.launch_toast({
//           type: 'alert',
//           position: 'bottom-right',
//           message: res['msg'],
//         });
//       }
//     });
//   }

//   gridSelectedList() {
//     let selectedUrlList = this.pathList.get('selectedPathList').value.map((res) => {
//       return { url: `${res}`, default: this.pathList.get('default').value }
//     });
//     this.robotTxtGrid(selectedUrlList);
//   }

//   generateRobotTxtFormate() {
//     this.preViewdata=''
//     this.sameAsDefaultpathSetList = []
//     this.finalSiteMap = ''
//     this.sameAsDefaultpathSet = ''
//     this.robotsTxtData = ''
//     let userAgentData = {};
//     this.generateUrlList.forEach(item => {
//       if (item.hasOwnProperty('allowed')) {
//         item.allowed.forEach(agent => {
//           if (!userAgentData.hasOwnProperty(agent)) {
//             userAgentData[agent] = { user_agent: agent, allow: [], disallowed: [], sameAsDefault: [] };
//           }
//           userAgentData[agent].allow.push(item.url);
//         });
//       }
//       if (item.hasOwnProperty('refused')) {
//         item.refused.forEach(agent => {
//           if (!userAgentData.hasOwnProperty(agent)) {
//             userAgentData[agent] = { user_agent: agent, allow: [], disallowed: [], sameAsDefault: [] };
//           }
//           userAgentData[agent].disallowed.push(item.url);
//         });
//       }
//       if (item.hasOwnProperty('sameAsDefault')) {
//         item.sameAsDefault.forEach(agent => {
//           if (!userAgentData.hasOwnProperty(agent)) {
//             userAgentData[agent] = { user_agent: agent, allow: [], disallowed: [], sameAsDefault: [] };
//           }
//           userAgentData[agent].sameAsDefault.push(item.url);
//         });
//       }
//     });
//     let result = Object.values(userAgentData);
//     this.finalFormate(result);
//   }

//   finalFormate(data: any) {
//     data.forEach(element => {
//       switch (element.user_agent) {
//         case 'Google':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Googlebot\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Google Image':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: googlebot-image\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Google Mobile':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: googlebot-mobile\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'MSN Search':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: MSNBot\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Yahoo':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Slurp\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Yahoo MM':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: yahoo-mmcrawler\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Yahoo Blogs':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: yahoo-blogs/v3.9\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Ask/Teoma':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Teoma\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'GigaBlast':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Gigabot\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'DMOZ Checker':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Robozilla\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Nutch':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: Nutch\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Alexa/Wayback':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: ia_archiver\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Baidu':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: baiduspider\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'Naver':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: naverbot\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         case 'MSN PicSearch':
//           this.robotsTxtData = this.robotsTxtData + `\nUser-agent: psbot\n`
//           element.allow.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Allow: /${path}\n`
//           });
//           element.disallowed.forEach(path => {
//             this.robotsTxtData = this.robotsTxtData + `Disallow: /${path}\n`
//           });
//           element.sameAsDefault.forEach(path => {
//             this.sameAsDefaultFormate(path, element);
//           });
//           break;

//         default:
//           break;
//       }
//     });
//     this.addCrawlDelay();
//   }

//   sameAsDefaultFormate(path: any, element: any) {
//     if (this.generateUrlList.length > 0) {
//       this.sameAsDefaultpathSetList.push(path);
//     }
//     this.sameAsDefaultpathSetListSorted = [...new Set(this.sameAsDefaultpathSetList)];
//   }

//   addCrawlDelay() {
//     this.crawlDelay = this.pathList.get('crawlDelay').value ? `\nCrawl-delay: ${this.pathList.get('crawlDelay').value}\n` : "";
//     this.addSiteMapUrl();
//   }

//   addSiteMapUrl() {
//     this.siteMapUrlForm.get('arr').value.forEach((item) => {
//       this.finalSiteMap = this.finalSiteMap.concat(item.siteMapUrl ? `sitemap: ${item.siteMapUrl}\n` : "");
//     })
//     this.onClickCheckResult();
//   }

//   createItem() {
//     return this.FormBuilder.group({
//       siteMapUrl: ""
//     })
//   }

//   addItem() {
//     this.arr = this.siteMapUrlForm.get('arr') as FormArray;
//     this.arr.push(this.createItem());
//   }

//   onRemoveAddress(index: number): void {
//     const addresses = this.siteMapUrlForm.controls.arr as FormArray;
//     addresses.removeAt(index);
//   }

//   sameAsDefaultPathSet() {
//     // const sameAsDefaultTxtData = '\nUser-agent: *\n\nAllow: /'
//     this.sameAsDefaultpathSetListSorted.map((path) => {
//       return this.sameAsDefaultpathSet = this.sameAsDefaultpathSet + `\n${this.generateUrlList[0].default}: /${path}`
//     });
//     this.defaultPathList = '\nUser-agent: *\n\nAllow: /' + `${this.sameAsDefaultpathSet}\n`
//     if(this.sameAsDefaultpathSet === "" || this.generateUrlList[0].default === undefined){
//       this.preViewdata = '\nUser-agent: *\n\nAllow: /'

//     }
//   }

//   defaultChangeReset(){
//     this.pathList.get('crawlDelay').reset();
//     this.pathList.get('selectedPathList').reset();
//     this.siteMapUrlForm.reset();
//     this.preViewdata = ''
//     this.robotTxtGrid();
//   }

//   robotReset() {
//     this.robotTxtGrid();
//     this.pathList.reset();
//     this.siteMapUrlForm.reset();
//     this.preViewdata = ''
//   }

//   onClickCheckResult() {
//     this.sameAsDefaultPathSet();
//     if (this.generateUrlList[0].default === '' || this.generateUrlList[0].default === null) {
//       this.preViewdata = this.robotsTxtData + this.crawlDelay + this.finalSiteMap;
//     }
//     else if (this.generateUrlList[0].default === 'Allow' || this.generateUrlList[0].default === 'Disallow') {
//       this.preViewdata = this.defaultPathList + this.crawlDelay + this.finalSiteMap;
//     }
//   }

//   robotTXTcreated() {
//     if(this.preViewdata === '' || this.preViewdata === null || this.preViewdata === undefined){
//       alerts('Generate Result robots.txt First');
//     } else {
//     let path = this._shareService.getDataprotool("selectedProjectChooseData").awspace + `/src/robots.txt`;
//     this._shareService.writeRobotsTxt(path, new Blob([this.preViewdata], { type: "application/txt" })).subscribe(res => {
//       if (res['status'] == 200) {
//         success(res['msg']);
//       } else {
//         alerts(res['msg']);
//       }
//     });
//   }
// }
// *********************************SEO CODE END***************************************************

  selectedLanguage : any;
  setDlanguage(){
  let eleData = this.languageList.filter(ele => ele.value == this.selectedLanguage);
  let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
  let angularVersion :any = this._shareService.getData('angversnObj')
  let postData = {
    "projectPath" : seletedObj.awspace,
    "ngprjver"    : angularVersion['angular'].split('.')[0],
    "defLang"     : eleData[0].label,
    "defLangCode" : eleData[0].value
  }
  this._shareService.defaultSetLanguage(postData).subscribe(res => {
    console.log(res);
  })

}




  
  gridData_newgrid: any;
  gridDynamicObj_newgrid: any;
  columnData_newgrid: any = [
    {
      "header": "Select",
      "field": "Select",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "checkbox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Module Name",
      "field": "Module Name",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Module Path",
      "field": "Module Path",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_newgrid: any = [
    {},
    {},
    {},
    {}
  ];
  validationnewgrid: any = {}

  newgrid(rowData?: any, colData?: any) {
    let self = this;


    // let mobileWebItem = this.common.getEnvironment();

    this.gridData_newgrid = {
      columnDef: colData ? colData : this.columnData_newgrid,
      rowDef: rowData ? rowData : this.rowData_newgrid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationnewgrid,
      newPagination: false,
      recordPerPage: 10,
      // exportBtn: (mobileWebItem == 'mobile') ? false : false,
      newExpandExportTotalRecord_hide: undefined,

      // commonSearchSelect_hide: (mobileWebItem == 'mobile') ? false : false,
      // commonFilterSelect_hide: (mobileWebItem == 'mobile') ? false : false,
      // orderArray: (mobileWebItem == 'mobile') ? ["sno", "column2", "column3"] : ["Column1", "Column2", "Column3"],
      ellipsisV: {},
      gridRowAddDeleteButton: "undefined",
      components: {},
      callBack: {

        "onCellClick": function (ele: any) {

          self.onnewgridCellClick();
        },
        "onRowClick": function () {
          self.onnewgridClick();
        },
        "onRowDbleClick": function () {
          self.onnewgriddblClick();
        }
      }
      ,

      rowCustomHeight: 20,
      plusButton_obj: {},




    };

    let sourceDiv = document.getElementById("newgrid");
    this.gridDynamicObj_newgrid = SdmtGridT(sourceDiv, this.gridData_newgrid, true, true);
  }

  onnewgridCellClick() {

  }

  onnewgridClick() {

  }

  onnewgriddblClick() {

  }

  columnView : any = true;
  rowView : any = false;
  showRow(rowView){
    if(rowView){
      document.querySelector(".accordianContainer").classList.toggle("flex_layout")
    }
    else{
      document.querySelector(".accordianContainer").classList.toggle("flex_layout") 
    }
  }


  

  
// *******************************************************FILTER OUT KEY-NOTES*****************************************************************
  filterLinks(event: any) {
    const searchTerm = event.target.value.toLowerCase();
    const links = document.querySelectorAll('[data-language]');
    if (searchTerm === '') {
        links.forEach((link: HTMLElement) => {
            link.style.display = 'flex';
        });
    } else {
        links.forEach((link: HTMLElement) => {
            const language = link.getAttribute('data-language').toLowerCase();
            if (language) {
                link.style.display = language.includes(searchTerm) ? 'flex' : 'none';
            }
        });
    }
}
//**********************************************************EXPORT PROJECT META DATA**************************************************************
descContent = 'This is dummy content';

exportMetaData() {
    const projectDetails = this._shareService.getDataprotool("selectedProjectChooseData");
    let projectName = this.projectInfo.projectname
    const projectInfo = {
      "projectPath": projectDetails['awspace'],
      "projectName": projectName,
      "staticonpage": 0
    }
    this._apiService.exportProjectMetaData(projectInfo).subscribe(res => {
      if (res['status'] === 'success')  this.toastNotifications('success',res['msg'])
      else this.toastNotifications('alert',res['msg'])
    })
  }
  descContentMethod(event){
    this.descContent = event.target.value
  }

  toastNotifications(msgType, msg) {
    this.toast.launch_toast({
      type: msgType,
      position: 'bottom-right',
      message: msg
    })
  }

  projFeatures(featureItem:any,actionType:any){
    switch (featureItem) {
      case 'voiceStatus':
        if(actionType == 'save'){
          let jsonData = {
        "projectName": this.projectInfo.projectname,
        "voiceActive": Number(this.projFeatureStat['voice'])
      }
      this._shareService.setVoiceStatus(jsonData).subscribe((res) => {
        this.showToast(res)
      });
        }else{
          const ref = this.dialogService.open(VoiceControlComponent, {
            width: "70%",
            contentStyle: { height: "575px" },
          });
          ref.onClose.subscribe((res) => {
            this.projFeatureStat['voice'] = res
          });
        }
        break;
      case 'themeStatus' :
        if(actionType == 'save'){
          const selectedObj = this._shareService.getDataprotool("selectedProjectChooseData"); 
          if (selectedObj) {
            let jsonData = {
              "projectName": selectedObj.projectname,
              "themeActive": Number(this.projFeatureStat['theme'])
            }
            this._shareService.setThemeStatus(jsonData).subscribe((res) => {
              this.showToast(res)
            })
          }
        }else{
          // const ref = this.dialogService.open(AdvMobileThemeComponent, {
          //   width: "70%",
          //   contentStyle: { height: "575px" },
          // });
          // ref.onClose.subscribe((res) => {
          //   this.projFeatureStat['theme'] = res
          // });
        }
        break;  
      default:
        break;
    }
  }

  showToast(res:any){
    if (res['status'] == 'success') {
      this.toast.launch_toast({
        type: 'success',
        position: 'bottom-right',
        message: res['message'],
      });
    }
  else {
    this.toast.launch_toast({
      type: 'alert',
      position: 'bottom-right',
      message: res['message'],
    });
  }
  }
  //****************************************************SET CONNECTION STRING IN DB************************************
  setDatabaseConfiguration(){
    let setProjectInfo= this._shareService.getDataprotool("selectedProjectChooseData");
    if(setProjectInfo!=undefined){
      let javaworkspace=setProjectInfo.jwspace;
      if(javaworkspace!=undefined && javaworkspace!=null && javaworkspace!=""){

        let reqObj =this.databaseConnForm.value
        reqObj["projectPath"]=javaworkspace;
    
        this.autoJavacodeService.setDatabaseConfiguration(reqObj).subscribe(res => {
          if(res.status==200){ 
            this.toast.launch_toast({
              type: 'success',
              position: 'bottom-right',
              message: res.msg,
            });
            this.testConnection()
          }else{
            this.toast.launch_toast({
              type: 'alert',
              position: 'bottom-right',
              message: res.msg,
            });
          }
        
        }, Error => {
        
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: 'Set Database Configuration : Fail !!!...',
          });
        });
      }
    }else{
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: 'java workspace not set',
      });
    }
  }  
 databaseConnForm = this.FormBuilder.group({
    vendor: ['MySQL'],
    databaseName: [''],
    hostName: ['localhost'],
    portNumber: ['3306'],
    userName: ['root'],
    password: ['root'],
  });
  setConnectionString() {
    if(this.dbConnection && this.dbConnection.projectPath) delete this.dbConnection.projectPath
    this.databaseConnForm.setValue(this.dbConnection);
  }

  testConnection() {
    const finalDataForConnection = {
      "srcDataSource": this.databaseConnForm.value,
      "operation": "TEST",
      "connectionRoleType": 'admin'
    }
    this.firststepDbcompareService.testConnectionByPost(finalDataForConnection).subscribe(async (res) => {
      if (res['src'] == true) {
        let projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
        if (projectInfo) {
          let setConn = {
            "projectPath": projectInfo ? projectInfo.awspace + `/prjconn.json` : "",
            "confobj": JSON.parse(JSON.stringify(finalDataForConnection)),
          }
          await this.setDbConnnectionObj(setConn);
        }
        finalDataForConnection['operation'] = 'COMPARESINGLE';
        finalDataForConnection['targetDataSource'] = {};
        finalDataForConnection['details'] = {
          software: [],
          year: [],
          client: [],
          columns: [],
          operation: ['']
        }
        this._shareService.setDatadbtool('finalDataForConnection', finalDataForConnection);
      }
      else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Test Connection : Fail !!!...',
        });
      }
    })
  }
  async setDbConnnectionObj(data) {
    this._shareService.savePrjConfObject(data).subscribe((res) => {
      if (res['status'] == 'success') {
        this.toast.launch_toast({
          type: 'success',
          position: 'bottom-right',
          message: 'Test Connection : Success !!!...',
        });
        $('#datastringmodal').modal('hide')
      }
    });
  }
  // ******************************* seo api's on tabs click*****************************
  seoTab = ''
  seoOptions(tabsName:string) {
    switch (tabsName) {
      case 'metaTagTab': this.isSeoTabClick = true;
        this.metaDataComponent.getMetaList();
        break;
      case 'sitemapTab': this.isSeoTabClick = true;
        this.SiteMapComponent.getSiteMap();
        break;
      case 'robotsTxtTab': this.isSeoTabClick = true;
        this.RobotsTxtGeneratorComponent.getRobotTxtData();
        break;
      default:
    }

  }
}

