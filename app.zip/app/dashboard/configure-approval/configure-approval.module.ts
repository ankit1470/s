import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfigureApprovalRoutingModule } from './configure-approval-routing.module';
import { SharedModule } from 'src/app/core/shared/shared.module';
import { VoiceControlModule } from 'src/app/modules/sag-studio/voice-control/voice-control.module';
import { ConfigureApprovalComponent } from './configure-approval.component';
import { MultiLanguageModule } from 'src/app/modules/sag-studio/multi-language/multi-language.module';
import { MobileThemeModule } from 'src/app/modules/sag-studio/project-explorer/project-config/mobile-theme/mobile-theme.module';
import { AddIndexHtmlLinkScriptComponent } from './add-index-html-link-script/add-index-html-link-script.component';
import { AddIndexHtmlLinkScriptModule } from './add-index-html-link-script/add-index-html-link-script.module';
import { ImageCollectionsModule } from 'src/app/modules/sag-studio/property-window/image-collections/image-collections.module';

import { ValidationModule } from 'src/app/modules/sag-studio/property-window/validation/validation.module';
import { ButtonRightsModule } from '../button-rights/button-rights.module';
import { ProjectInformationModule } from '../project-information/project-information.module';
import { ProjectExploralFileListModule } from '../project-exploral-file-list/project-exploral-file-list.module';
import { RightsModule } from '../rights/rights.module';
import { PropertyWindowModule } from 'src/app/modules/sag-studio/property-window/property-window.module';
import { RegenerateCodeModule } from '../regenerate-code/regenerate-code.module';
import { ActivateButtonRightsModule } from '../activate-button-rights/activate-button-rights.module';
import { DashboardModule } from '../dashboard.module';
import { GlobalPropertysModule } from '../global-propertys/global-propertys.module';
import { LdvModule } from 'src/app/modules/sag-studio/ldv/ldv.module';
import { AdvMobileThemeModule } from 'src/app/modules/sag-studio/project-explorer/project-config/adv-mobile-theme/adv-mobile-theme.module';
import { CopyContentComponent } from './copy-content/copy-content.component';
import { CopyContentModule } from './copy-content/copy-content.module';
import { UpdateJavaVersionModule } from '../update-java-version/update-java-version.module';
import { ServerSideRenderingModule } from '../server-side-rendering/server-side-rendering.module';
import { AuthenticationModule } from '../authentication/authentication.module';
import { SiteMapComponent } from './site-map/site-map.component';
import { MetaDataComponent } from './meta-data/meta-data.component';
import { MetaDataModule } from './meta-data/meta-data.module';
import { SiteMapModule } from './site-map/site-map.module';
import { UpdateJavaBaseProjectModule } from '../update-java-base-project/update-java-base-project.module';
import { RobotsTxtGeneratorModule } from './robots-txt-generator/robots-txt-generator.module';
import { RobotsTxtGeneratorComponent } from './robots-txt-generator/robots-txt-generator.component';
import { SsrInfoComponent } from './ssr-info/ssr-info.component';
import { SsrInfoModule } from './ssr-info/ssr-info.module';
import { MetaDataGridComponent } from './meta-data-grid/meta-data-grid.component';
import { MetaDataGridModule } from './meta-data-grid/meta-data-grid.module';
import { JavaSsrInfoComponent } from './java-ssr-info/java-ssr-info.component';
import { JavaSsrInfoModule } from './java-ssr-info/java-ssr-info.module';
import { EditorDiffChangeModule } from 'src/app/modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-diff-change/editor-diff-change.module';
import { ProjectCommonFileComponent } from './project-common-file/project-common-file.component';
import { ProjectCommonFileModule } from './project-common-file/project-common-file.module';
import { GenerateMappingFileComponent } from '../generate-mapping-file/generate-mapping-file.component';
import { LockModule } from 'src/app/dashboard/lock/lock.module';
import { LogModule } from '../log/log.module';
import { DbScriptComponent } from './db-script/db-script.component';
import { DbScriptModule } from './db-script/db-script.module';
import { SageditorModule } from '../sageditor/sageditor.module';
import { TemplateMappingModule } from '../template-mapping/template-mapping.module';
import { ValidationConfigureComponent } from './validation-configure/validation-configure.component';
import { IndexJsCssComponent } from './index-js-css/index-js-css.component';
import { IndexJsCssModule } from './index-js-css/index-js-css.module';
import { ReportingModule } from '../reporting/reporting.module';
import { FontListComponent } from './font-list/font-list.component';
import { FontListModule } from './font-list/font-list.module';
import { MessageListComponent } from './message-list/message-list.component';
import { MessageListModule } from './message-list/message-list.module';
import { DatabaseBackupModule } from './database-backup/database-backup.module';
import { DefaultMetaComponent } from './default-meta/default-meta.component';
import { DefaultMetaModule } from './default-meta/default-meta.module';
import { SeoDashboardComponent } from './seo-dashboard/seo-dashboard.component';
 
import { ProjectSecurityModule } from '../project-security/project-security.module';
import { MobilePagesConfigModule } from './mobile-pages-config/mobile-pages-config.module';
import { AiModalComponent } from './ai-modal/ai-modal.component';
import { AiModalModule } from './ai-modal/ai-modal.module';
import { PwaModule } from './pwa/pwa.module';






@NgModule({
  declarations: [ConfigureApprovalComponent,
    AddIndexHtmlLinkScriptComponent,
    CopyContentComponent,
    MetaDataComponent,
    SiteMapComponent,
    RobotsTxtGeneratorComponent,
    SsrInfoComponent,
    MetaDataGridComponent,
    JavaSsrInfoComponent,
    ProjectCommonFileComponent,
    GenerateMappingFileComponent,
    DbScriptComponent,
    ValidationConfigureComponent,
    IndexJsCssComponent,
    FontListComponent,
    MessageListComponent,
    DefaultMetaComponent,
    SeoDashboardComponent,
    AiModalComponent,
    
  ],
  imports: [
    CommonModule,
    ConfigureApprovalRoutingModule,
    SharedModule,
    VoiceControlModule,
    ImageCollectionsModule,
    MultiLanguageModule,
    MobileThemeModule,
    AddIndexHtmlLinkScriptModule,
    CopyContentModule,
    ValidationModule,
    ButtonRightsModule,
    ProjectInformationModule,
    ProjectExploralFileListModule,
    RightsModule,
    ActivateButtonRightsModule,
    PropertyWindowModule,
    RegenerateCodeModule,
    AuthenticationModule,
    LockModule,
    LogModule,
    DashboardModule,
    GlobalPropertysModule,
    LdvModule,
    AdvMobileThemeModule,
    UpdateJavaVersionModule,
    ServerSideRenderingModule,
    MetaDataModule,
    SiteMapModule,
    UpdateJavaBaseProjectModule,
    RobotsTxtGeneratorModule,
    SsrInfoModule,
    MetaDataGridModule,
    JavaSsrInfoModule,
    EditorDiffChangeModule,
    ProjectCommonFileModule,
    DbScriptModule,
    SageditorModule,
    AdvMobileThemeModule,
    TemplateMappingModule,
    IndexJsCssModule,
    ReportingModule,
    FontListModule,
    MessageListModule,
    DatabaseBackupModule,
    DefaultMetaModule,
    ProjectSecurityModule,
    MobilePagesConfigModule,
    AiModalModule,
    PwaModule

  ],
  exports:[GenerateMappingFileComponent],
  entryComponents:[GenerateMappingFileComponent]
  
})
export class ConfigureApprovalModule { }
