import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seo-dashboard',
  templateUrl: './seo-dashboard.component.html',
  styleUrls: ['./seo-dashboard.component.scss']
})
export class SeoDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
