import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SeoDashboardRoutingModule } from './seo-dashboard-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SeoDashboardRoutingModule
  ]
})
export class SeoDashboardModule { }
