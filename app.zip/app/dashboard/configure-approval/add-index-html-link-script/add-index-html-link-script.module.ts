import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddIndexHtmlLinkScriptRoutingModule } from './add-index-html-link-script-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AddIndexHtmlLinkScriptRoutingModule
  ]
})
export class AddIndexHtmlLinkScriptModule { }
