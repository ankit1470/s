import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';

@Component({
  selector: 'app-add-index-html-link-script',
  templateUrl: './add-index-html-link-script.component.html',
  styleUrls: ['./add-index-html-link-script.component.scss']
})
export class AddIndexHtmlLinkScriptComponent implements OnInit {
  addlistForm:FormGroup;
  constructor(private fb:FormBuilder,public ref: DynamicDialogRef, public config: DynamicDialogConfig) { }
  ngOnInit() {
    this.addlistForm = this.fb.group({
      filePath:['',Validators.required],
      fileName:['',Validators.required]
    })
  }

  addLi(){
    if(this.addlistForm.valid){
      this.addlistForm.value['color']='green'
      this.addlistForm.value['fileCount']=1
      const list = this.config.data.list
      const ind = this.config.data.index
      list.splice(ind + 1,0,this.addlistForm.value)
      this.ref.close(this.addlistForm.value) 
    }
    }
}
