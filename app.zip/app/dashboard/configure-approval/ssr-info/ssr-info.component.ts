import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { SagShareService } from 'src/app/services/sagshare.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { DialogService } from 'primeng/api';
import { ApiServiceService } from 'src/app/services/http/api-service.service';
import { ToastService } from 'src/app/core/services/toast.service';
declare var $: any;

@Component({
  selector: 'app-ssr-info',
  templateUrl: './ssr-info.component.html',
  styleUrls: ['./ssr-info.component.scss']
})
export class SsrInfoComponent implements OnInit, OnChanges {
  ssrStatus:any
  projectInfo: any = null
  isDiffEditorOpen = false;
  openHtmlFlag: boolean;
  compareToolDisplay: boolean;
  ssrTable = [
    "meta.config.ts",
    "meta.service.ts",
    "ErrorHandler.ts",
    "sitemap.xml",
    "Robots.txt",
    "server.ts",
    "main.server.ts",
    "app.module.server.ts",
    "angular.json",
    "index.html",
    "app.component.ts",
    "package.json",
    "tsconfig.app.json",
    "java-ssr"
  ]
  commonFiles : any = [
    "meta.service.ts",
    "ErrorHandler.ts",
    "server.ts",
    "main.server.ts",
    "app.module.server.ts",
    "angular.json",
    "app.component.ts",
    "package.json",
    "tsconfig.app.json"    
  ]
  usrFiles:any = [
    "meta.config.ts",
    "sitemap.xml",
    "Robots.txt",
    "index.html",
    "java-ssr"
  ]
  constructor(
    public dialogService: DialogService,
    private shareService: SagShareService,
    public studioDragDropService: CommonStudioDragDropService,
    private cdRef: ChangeDetectorRef,
    private apiServ: ApiServiceService,
    public toast: ToastService,
  ) { }

  ngOnInit() {
    this.projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    this.getSsrStatus()
  }
  ngOnChanges() {
  }
  modifiedStatus() {
    const activeNames = new Set(
      this.ssrStatus
        .filter(ele => ele.status === true)
        .map(ele => ele.name)
    );
    this.ssrStatus.forEach(ssrElement => {
      if (activeNames.has(ssrElement.name)) {
        ssrElement.status = "fa fa-check";
      } else {
        ssrElement.status = "fa fa-times";
      }
    });
  }


  async getCompareFileCode(fileName, filePath) {
    let projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    let version = this.shareService['data']['angversnObj']['angular']
    if(version !=""){
      const files = {
        "projectPath": projectInfo.awspace,
        "ngver": `${version.split(".")[0]}`,
        "fileName": fileName
      }
      this.shareService.getFileCompareData(files).subscribe(
        (response: any) => {
          if (response) {
            this.shareService.setDataprotool("leftSideCode", response.actcontent);
            this.shareService.setDataprotool("rightSideCode", response.defcontent);
            let file = filePath.replace(/\\/g, '/')
            this.shareService.setDataprotool("filePathEditorDiff", {
              path: file,
              projectpath: undefined
            });
            this.openHtmlFlag = false;
            this.compareToolDisplay = true;
  
            this.cdRef.detectChanges();
            this.compareToolDisplay ? $("#VscodecompareToolssrfilecompare").modal('show') : false;
  
          }
        })
    }else
    this.toastNotifications('alert', "add angular version to existing project")
  }
  saveFileData(fileName, filePath) {
    let file = filePath.replace(/\\/g, '/')
    let version = this.shareService['data']['angversnObj']['angular']
    if(version !=''){
      let saveModulePath = {
        "filePath": file,
        "ngver": `${version.split(".")[0]}`,
        "name": fileName
      }
      this.apiServ.saveModuleList(saveModulePath).subscribe(res => {
        if (res['status'] === 'success') {
          this.toastNotifications('success', res['msg'])
          this.getSsrStatus()
        }
        else this.toastNotifications('alert', res['msg'])
      })
    }else
    this.toastNotifications('alert', "add angular version to existing project")
  }

  async getSsrStatus() {
    let fileName = this.extarctFisrtCol()
    let version = this.shareService['data']['angversnObj']['angular']
    if(version !=''){
      const filesD = {
        "projectPath": this.projectInfo.awspace,
        "javaProjectPath": this.projectInfo.jwspace,
        "projectId": this.projectInfo.projectId,
        "ngver": `${version.split(".")[0]}`,
        // "files": fileName
        "cmnFiles":this.commonFiles,
        "usrFiles":this.usrFiles
      }
      const res= await  this.shareService.getSSrStatus(filesD).toPromise()
      this.ssrStatus = res
      this.modifiedStatus()
    }else
    this.toastNotifications('alert', "add angular version to existing project")
  }
  extarctFisrtCol() {
    const fileName = this.ssrTable.map(ele => ele)
    return fileName
  }
  toastNotifications(msgType, msg) {
    this.toast.launch_toast({
      type: msgType,
      position: 'bottom-right',
      message: msg
    })
  }
}
