import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SsrInfoRoutingModule } from './ssr-info-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SsrInfoRoutingModule
  ]
})
export class SsrInfoModule { }
