import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/primeng';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var $: any;
declare var SdmtGridT;
declare function alerts(m: any): any;
declare function success(m: any): any;
@Component({
  host: { class: "d-flex flex-column h-100 defaultmetapage" },
  selector: 'app-default-meta',
  templateUrl: './default-meta.component.html',
  styleUrls: ['./default-meta.component.scss']
})
export class DefaultMetaComponent implements OnInit {

  constructor(private _shareService:SagShareService, public modalRef: DynamicDialogRef, private shareService: SagShareService,public config: DynamicDialogConfig) { }
  fixedMetaData: any = []
  fixedMetaJson = [
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "og:title",
        "svalue": "This is a dummy title",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "og:description",
        "svalue": "This is a description for testing purpose",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "og:image",
        "svalue": "https://example.com/image.jpg",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "og:image:type",
        "svalue": "image.jpg",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "og:url",
        "svalue": "https://example.com",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "og:type",
        "svalue": "website",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "og:locale",
        "svalue": "en_US",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "twitter:card",
        "svalue": "summary_large_image",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "twitter:title",
        "svalue": "This is a dummy Twitter title",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "twitter:description",
        "svalue": "This is a Twitter description for testing purpose",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "twitter:image",
        "svalue": "https://example.com/twitter_image.jpg",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "twitter:url",
        "svalue": "https://example.com",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "twitter:creator",
        "svalue": "@username",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "robots",
        "svalue": "index, follow",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "description",
        "svalue": "This is a meta description for SEO purposes.",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "keywords",
        "svalue": "HTML, SEO, Meta Tags",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "author",
        "svalue": "John Doe",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "viewport",
        "svalue": "width=device-width, initial-scale=1.0",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "charset",
        "svalue": "UTF-8",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "robots",
        "svalue": "noarchive",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "canonical",
        "svalue": "https://example.com/canonical-url",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "property",
        "skey": "content",
        "fvalue": "og:site_name",
        "svalue": "Example Website",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "twitter:site",
        "svalue": "@examplewebsite",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "robots",
        "svalue": "noindex, nofollow",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "generator",
        "svalue": "WordPress 5.0",
        "delete": "",
        "sno": ""
    },
    {
        "fkey": "name",
        "skey": "content",
        "fvalue": "refresh",
        "svalue": "30",
        "delete": "",
        "sno": ""
    }
  ]
  ngOnInit() {
    // $('metamodal').modal('show')
    if(this.config.data == 'setMetaSchema'){
      this.getMetaDataFromSchema()
    } else {
      this.getMetaFromSchema();
    }
    this.fixedMetaData = [{ 'metaKey': '', 'metaValue': '' },{'metaKey': '', 'metaValue': ''}];
  }
  metaKeywordList: any = [
    {
      "label": "Select",
      "value": ""
    },
    {
      "label": "CHARSET",
      "value": "charset"
    },
    {
      "label": "CONTENT",
      "value": "content"
    },
    {
      "label": "HTTP-EQUIV",
      "value": "http-equiv"
    },
    {
      "label": "ID",
      "value": "id"
    },
    {
      "label": "ITEMPROP",
      "value": "itemprop"
    },
    {
      "label": "NAME",
      "value": "name"
    },
    {
      "label": "PROPERTY",
      "value": "property"
    },
    {
      "label": "SCHEME",
      "value": "scheme"
    },
    {
      "label": "URL",
      "value": "url"
    },

  ];


  // addRow(metaList) {
  //   let obj = {
  //     'metaKey': '',
  //     'metaValue': ''
  //   }
  //   metaList.push(obj)
  // }
  deleteRow(metaList, index) {
    if (index !== 0) metaList.splice(index, 1);
  }

  updateMetaKey1(event, meta) {
    meta.metaKey = event;
  }
  updateMetaValue1(event, meta) {
    meta.metaValue = event.target.value;
  }

  metaDataShowInGrid1(data) {
    let obj = {};

    // if (this.gridDynamicObj_metadata && false) {
    //   this.rowData_metadata = this.gridDynamicObj_metadata.getGridData()
    //   if (this.rowData_metadata.length > 0) {
    //     let lastIn = this.rowData_metadata.length - 1
    //     let met = parseInt(this.rowData_metadata[lastIn].meta.split('a')[1])
    //     obj["meta"] = `Meta${met + 1}`
    //   } else obj["meta"] = `Meta${this.rowData_metadata.length + 1}`
    // } else obj["meta"] = `Meta${this.rowData_metadata.length + 1}`
    // obj["details"] = []
    // for (let index = 0; index < data.length; index++) {
    //   const element = data[index];
    //   obj["details"].push(
    //     {
    //       "meta": index + 1,
    //       "metaKey": element.metaKey,
    //       "metaValue": element.metaValue,
    //       'dynamicCompName_Delete': 'label',
    //       'Delete': '',
    //     }
    //   )
      
    //   element.metaKey = '';
    //   element.metaValue = '';
    // }
    obj = {
      delete : '',
      sno : this.gridDynamicObj_metadata ? this.gridDynamicObj_metadata.sagGridObj.rowData.length + 1 : 1,
      fkey : data[0].metaKey,
      skey : data[1].metaKey,
      fvalue : data[0].metaValue,
      svalue : data[1].metaValue,
    }
    this.rowData_metadata.push(obj)
    this.fixedMetaData = [{ 'metaKey': '', 'metaValue': '' },{'metaKey': '', 'metaValue': ''}]
    this.metadata();
    // $('#metamodal').modal('hide')
  }


  gridData_metadata: any;
  gridDynamicObj_metadata: any;
  columnData_metadata:any = [
    {
      hidden: false,
      editable: "false",
      filter: false,
      search: true,
      component: "label",
      field: "sno",
      freezecol: "null",
      width: "50px",
      header: "S.No",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: false,
      search: true,
      component: "text",
      field: "fkey",
      freezecol: "null",
      width: "250px",
      header: "Key",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: false,
      search: true,
      component: "text",
      field: "fvalue",
      freezecol: "null",
      width: "250px",
      header: "Value",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: true,
      filter: false,
      search: true,
      component: "text",
      field: "skey",
      freezecol: "null",
      width: "250px",
      header: "Key",
      "text-align": "left",
    },
    // {
    //   hidden: false,
    //   editable: true,
    //   filter: false,
    //   search: true,
    //   component: "text",
    //   field: "svalue",
    //   freezecol: "null",
    //   width: "250px",
    //   header: "Value",
    //   "text-align": "left",
    // },
    {
      "hidden": false,
      "search": false,
      "cellHover": false,
      "text-align": "center",
      "editable": "false",
      "sort": false,
      "filter": false,
      "component": "dynamicComponent",
      "field": "svalue",
      "freezecol": "null",
      "width": "200px",
      "header": "Value",
      "cellRenderView": true,
    },
    {
      header: "Default",
      field: "defaultcol",
      hidden: false,
      search: false,
      cellHover: false,
      "text-align": "left",
      editable: "false",
      sort: false,
      filter: false,
      component: "select",
      freezecol: "null",
      width: "auto",
      cellRenderView: false,
    },
    {
      "header": "Delete",
      "field": "delete",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "rowDelete",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    }
  ]
  svalueJSON : any = [ { "key": "", "val": "-Select-" }, { "key" : "website", "val" : "website"}, { "key" : "article", "val" : "article"}, { "key" : "book", "val" : "book"}, { "key" : "profile", "val" : "profile"}, { "key" : "music.song", "val" : "music.song"}, { "key" : "music.album", "val" : "music.album"}, { "key" : "music.playlist", "val" : "music.playlist"}, { "key" : "music.radio_station", "val" : "music.radio_station"}, { "key" : "video.movie", "val" : "video.movie"}, { "key" : "video.episode", "val" : "video.episode"}, { "key" : "video.tv_show", "val" : "video.tv_show"}, { "key" : "video.other", "val" : "video.other"} ]
  rowData_metadata: any = [];
  validationmetadata: any = {}

  metadata(rowData?: any, colData?: any) {
    let self = this;

    this.gridData_metadata = {
      columnDef: colData ? colData : this.columnData_metadata,
      rowDef: rowData ? rowData : this.rowData_metadata,
      footer_hide: true,
      totalNoOfRecord_hide: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationmetadata,
      newPagination: false,
      recordPerPage: 10,
      ellipsisV: {},
      components: {},
      callBack: {
        "onRowDelete_delete": function (ele: any, param: any) {
          self.rowData_metadata.splice(param.rowIndex, 1);
          self.metadata()
        },
        "onCellClick": function (ele: any, param: any) {
          self.onmetadataCellClick();
        },
        "onRowClick": function () {
          self.onmetadataClick();
        },
        "onRowDbleClick": function () {
          self.onmetadatadblClick();
        }
      }
      ,

      rowCustomHeight: 20,
      dropDownJson_defaultcol: [{ "key": "", "val": "-Select-" }, {val : "Title", key : "title"}, {val : "Description", key : "description"}],
      plusButton_obj: {},
      dropDownJson_svalue: self.svalueJSON,
      // rowGrouping: {
      //   "enable": true,
      //   "allowClick": true,
      //   "groupType": "custome",
      //   "groupBy": "meta",
      // },



    };
    for (let i = 0; i < this.gridData_metadata.rowDef.length; i++) {
      const obj = this.gridData_metadata.rowDef[i];
      if(obj.fvalue == 'og:type') {
        obj.dynamicCompName_svalue = 'select';
        obj.dynamicCompCellRenderView_svalue = true;
      } else {
        obj.dynamicCompName_svalue = 'text';
        obj.dynamicCompCellRenderView_svalue = false;
      }
    }

    let sourceDiv = document.getElementById("metadata1");
    if (sourceDiv != null) this.gridDynamicObj_metadata = SdmtGridT(sourceDiv, this.gridData_metadata, true, true);
  }

  onmetadataCellClick() { }

  onmetadataClick() { }

  onmetadatadblClick() { }

  close() {
    this.modalRef.close();
  }

  async saveDefaultMeta() {
    // if(this.rowData_metadata.length > 0){
      const node = this.shareService.getDataprotool("selectedProjectChooseData");
      const finalPath = `${node.awspace}/src/app/config/metaschema.json`;
      const res = await this.shareService.writeFile(finalPath, new Blob([JSON.stringify(this.gridDynamicObj_metadata.sagGridObj.rowDef)], { type: "application/json" })).toPromise();
      success("Default meta saved successfully!");
      this.modalRef.close()
    // }else{
    //   alerts("Add Meta Tag in Grid")
    // }
  }
  getMetaDataFromSchema(){
    this.rowData_schemaMetadata = []   
    let proj=this._shareService.getDataprotool("selectedProjectChooseData")
    let obj:any={
      filePath:`${proj.awspace}/src/app/config/metaschema.json`
    }
    this._shareService.getDefaultMeta(obj).subscribe((res:any)=>{
      console.log(res)
      if(res && res.length){
        res.forEach(element => {
          element['checkbox'] = 0;
        });
        this.rowData_schemaMetadata = res;
        this.schemaMetadata()
      }
    })
  }

  getMetaFromSchema() {
    this.rowData_metadata = []   
    let proj=this._shareService.getDataprotool("selectedProjectChooseData")
    let obj:any={
      filePath:`${proj.awspace}/src/app/config/metaschema.json`
    }
    this._shareService.getDefaultMeta(obj).subscribe((res:any)=>{
      if(res){
        this.rowData_metadata = res;
        this.metadata()
      }
    })
  }

  // Schema Meta Data Grid
  gridData_schemaMetadata: any;
  gridDynamicObj_schemaMetadata: any;
  columnData_schemaMetadata: any = [
    
      {
        "header": "",
        "field": "checkbox",
        "filter": false,
        "width": "100px",
        "editable": "false",
        "text-align": "center",
        "search": false,
        "component": "headerCheckBox",
        "cellRenderView": true,
        "freezecol": "null",
        "hidden": false,
        "sort": false,
        "cellHover": false,
      },
      {
        hidden: false,
        editable: "false",
        filter: false,
        search: true,
        component: "label",
        field: "sno",
        freezecol: "null",
        width: "50px",
        header: "S.No",
        "text-align": "left",
      },
      {
        hidden: false,
        editable: false,
        filter: false,
        search: true,
        component: "label",
        field: "fkey",
        freezecol: "null",
        width: "250px",
        header: "Key",
        "text-align": "left",
      },
      {
        hidden: false,
        editable: false,
        filter: false,
        search: true,
        component: "label",
        field: "fvalue",
        freezecol: "null",
        width: "250px",
        header: "Value",
        "text-align": "left",
      },
      {
        hidden: false,
        editable: false,
        filter: false,
        search: true,
        component: "label",
        field: "skey",
        freezecol: "null",
        width: "250px",
        header: "Key",
        "text-align": "left",
      },
      {
        hidden: false,
        editable: false,
        filter: false,
        search: true,
        component: "label",
        field: "svalue",
        freezecol: "null",
        width: "250px",
        header: "Value",
        "text-align": "left", 
      }
    
  ];

  rowData_schemaMetadata: any = [];
  validationschemaMetadata: any = {}

  schemaMetadata(rowData?: any, colData?: any) {
    let self = this;

    this.gridData_schemaMetadata = {
      columnDef: colData ? colData : this.columnData_schemaMetadata,
      rowDef: rowData ? rowData : this.rowData_schemaMetadata,
      footer_hide: true,
      totalNoOfRecord_hide: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationschemaMetadata,
      newPagination: false,
      recordPerPage: 10,
      ellipsisV: {},
      components: {},
      callBack: {
        "onCellClick": function (ele: any, param: any) {
          self.onmetadataCellClick();
        },
        "onRowClick": function () {
          self.onmetadataClick();
        },
        "onRowDbleClick": function () {
          self.onmetadatadblClick();
        }
      }
      ,

      rowCustomHeight: 20,
      plusButton_obj: {},
      // rowGrouping: {
      //   "enable": true,
      //   "allowClick": true,
      //   "groupType": "custome",
      //   "groupBy": "meta",
      // },



    };

    let sourceDiv = document.getElementById("schemaMetaData");
    if (sourceDiv != null) this.gridDynamicObj_schemaMetadata = SdmtGridT(sourceDiv, this.gridData_schemaMetadata, true, true);
  }


  async saveMetaSchema(){
    // let grid = JSON.parse(JSON.stringify( this.gridDynamicObj_schemaMetadata.getGridData()))
    // if(grid.length > 0){
    //   grid.map((res:any)=>{
    //     res['details']=[{'metaKey' :'','metaValue' :''},{'metaKey' :'','metaValue' :''}]
    //     res['details'][0]['metaKey'] = res.metaKey1
    //     res['details'][0]['metaValue'] = res.metaValue1
    //     res['details'][1]['metaKey'] = res.metaKey2
    //     res['details'][1]['metaValue'] = res.metaValue2
    //     return res
    //   })
    //   const node = this.shareService.getDataprotool("selectedProjectChooseData");
    //   const finalPath = `${node.awspace}/src/app/config/metaschema.json`;
    //   const res = await this.shareService.writeFile(finalPath, new Blob([JSON.stringify(grid)], { type: "application/json" })).toPromise();
    //   let obj:any={}
    //   obj['type'] = 'setMetaSchema'
    //   obj['gridData'] = grid
      // this.modalRef.close(obj)
    // }else{
      //   alerts("Add default meta tag first")
      // }
         this.modalRef.close(this.gridDynamicObj_schemaMetadata.getCheckedDataParticularColumnWise())
  }
  selectedDefaultJson : any = [];
  saveJsonMeta() {
    if(this.selectedDefaultJson && this.selectedDefaultJson.length) {
      let loadCheck = false;
      this.selectedDefaultJson.forEach(element => {
          let objCheck = this.rowData_metadata.find(res => res.fvalue == element.fvalue);
          if(!objCheck) {
            loadCheck = true
            this.rowData_metadata.push(element);
          }
      });
      this.selectedDefaultJson = []
      loadCheck ? this.metadata() : '';
    }
  }
}
