import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DefaultMetaRoutingModule } from './default-meta-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DefaultMetaRoutingModule
  ]
})
export class DefaultMetaModule { }
