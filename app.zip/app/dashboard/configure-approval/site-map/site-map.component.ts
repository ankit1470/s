import {
  ChangeDetectorRef,
  Component,
  Input,
  OnChanges,
  OnInit,
  ViewChild,
} from "@angular/core";
import { DialogService, DynamicDialogRef } from "primeng/api";
import { Calendar } from "primeng/calendar";
import { ToastService } from "src/app/core/services/toast.service";
import { NotificationComponent } from "src/app/core/shared/components/notification/notification.component";
import { ApiServiceService } from "src/app/services/http/api-service.service";
import { SagShareService } from "src/app/services/sagshare.service";
import { SagStudioService } from "src/app/services/sagStudio/sag-studio.service";
import * as xml2js from "xml2js";
declare var $: any;

@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: "app-site-map",
  templateUrl: "./site-map.component.html",
  styleUrls: ["./site-map.component.scss"],
})
export class SiteMapComponent implements OnInit,OnChanges {
  seperateNum:any;
  totalRoutesAllowed:any | null
  isDupUrlExist = false;
  htmlSitemap: any;
  isSiteMapExist: any;
  selectedTags: any[] = [];
  columns: { name: string; value: string }[] = [];
  xml: string;
  filePath: any;
  checkedXML: boolean = false;
  calendarIndex = -1;
  previousDomain: any;
  isValidSiteMap = true;
  isCorrectSitemap = false;
  isEmptyCol = false;
  isDomainNameExist = true;
  invalidDomainName = [];
  protocol: string = "https://";
  isReload = false;
  sitemapData: any;
  rowWithoutColVal = [];
  dateTime = new Date();
  locUrl: any;
  addChild: boolean = false;
  showHtmlPaths: Boolean = false;
  htmlsiteMapData: [] = [];
  countPage = 0;
  htmlDomainName = "";
  tagOptions: any[] = [
    { name: "LASTMOD", value: "" },
    { name: "CHANGEFREQ", value: "" },
    { name: "PRIORITY", value: "" },
  ];
  domainName: string=''

  changeFreq = [
    "never",
    "yearly",
    "monthly",
    "weekly",
    "daily",
    "hourly",
    "always",
  ];
  priority = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
  isXmlSelected=true
  @ViewChild("calendar", { static: false }) private calendars: Calendar;
  siteMapRes:any
  projectInfo: any = null;
  isViewSelected: boolean = true
  @Input() isSeoTabClick:boolean
  siteMapFile:string=''
  sitemapUrls: string[] = []
  isSaveFileInfoCalled: boolean = false;

  constructor(
    private _shareService: SagShareService,
    private _apiService: ApiServiceService,
    public toast: ToastService,
    public modalRef: DynamicDialogRef,
    public sagStudioService: SagStudioService,
    public dialogService: DialogService,
    public cdref: ChangeDetectorRef
  ) {}
 
  ngOnInit() {
    this.projectInfo = this._shareService.getDataprotool("selectedProjectChooseData");
    if(this.isSeoTabClick)this.getSiteMap()
  }
  ngOnChanges(){}
  async getSiteMap(){
    let filePath = {
      filePath: `${this.projectInfo.awspace}/src/sitemap.xml`
    }
    const res= await this._shareService.getXml(filePath).toPromise()
    if(res['xmlstr'].includes("sitemapindex")){
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(res['xmlstr'], 'application/xml');
      const rootElement = xmlDoc.documentElement;  // <sitemapindex>
      const namespaceURI = rootElement.namespaceURI;  // Get the namespace URI
      const sitemapElements = xmlDoc.getElementsByTagNameNS(namespaceURI, 'sitemap');
      this.sitemapUrls = [];
      for (let i = 0; i < sitemapElements.length; i++) {
        const locElement = sitemapElements[i].getElementsByTagNameNS(namespaceURI, 'loc')[0];
        if (locElement) {
          const fullUrl = locElement.textContent || ''; // Get the full URL
          const fileName = this.extractFileName(fullUrl); // Extract the file name (e.g., 'sitemap1')
          this.sitemapUrls.push(fileName);  // Add the file name to the array
        }
      }
      let filePath = {
        filePath: `${this.projectInfo.awspace}/src/${this.sitemapUrls[0]}.xml`
      }
      const defaultFileRes = await this._shareService.getXml(filePath).toPromise()
      this.siteMapFile= this.sitemapUrls[0]
      this.siteMapRes = defaultFileRes
      this.getUrlSitemap();
    }
    else {
      this.siteMapRes = res
      this.getUrlSitemap();
    }
    this.isSiteMapExist = res['isfileexist']
  }
  extractFileName(url: string): string {
    const matches = url.match(/\/([^\/]+)\.xml/);
    return matches ? matches[1] : '';  // If match found, return the file name without '.xml'
  }
  showXml() {
    this.isXmlSelected=true
  }
  htmlTab() {
    this.isXmlSelected=false
    let reqJson = {
      device: "web",
      projectName: this.projectInfo.projectname,
    };
    this._shareService.getMenuJson(reqJson).subscribe((res: any) => {
      this.htmlSitemap = res[0].children;
    });
  }
  getUrlSitemap() {
    if (this.siteMapRes) {
      let id = {
        projectId: this.projectInfo.projectId,
      };
      this.isSiteMapExist = this.siteMapRes["isfileexist"];
      const parser = new xml2js.Parser({ strict: false, trim: true });
      parser.parseString(this.siteMapRes["xmlstr"], (err, result) => {
        this.xml = result;
        if (this.siteMapRes["xmlstr"] !== "") {
          this.sitemapData = result;
          let sitemap: [] = result["URLSET"]["URL"];
          let domain = result["URLSET"]["URL"][0].LOC[0];
          let returnSitMap = this.checkEmptyCol(sitemap);
          if (!this.isValidSiteMap) {
            let item = "A URL in your sitemap is not valid.";
            const refMethod = this.dialogService.open(NotificationComponent, {
              width: "30%",
              baseZIndex: 10000,
              rtl: true,
              styleClass: "customModal",
              data: { methodData: "siteMapAlert", item },
              showHeader: false,
            });
            refMethod.onClose.subscribe((res) => {
              if (res) {
                this.fetchingURL(id)
                  .then((url: any[]) => {
                    if (this.isReload) this.domainName = "";
                    this.locUrl = url;
                  })
                  .catch((error) => { });
              } else {
                this.getDomainName(returnSitMap, domain);
              }
            });
          } else {
            this.getDomainName(returnSitMap, domain);
          }
        } else {
          this.fetchingURL(id)
            .then((url: any[]) => {
              this.locUrl = url;
            })
            .catch((error) => { });
        }
      });
    }
  }
  fetchingURL(id) {
    this.locUrl = [];
    this.columns = [];
    this.selectedTags = [];
    return new Promise<any[]>((resolve, reject) => {
      this._shareService.getUrl(id).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.isCorrectSitemap = true;
            resolve(res);
          } else {
            resolve([]);
          }
        },
        (error) => {
          reject(error);
        }
      );
    });
  }
  getDomainName(siteMap, domain) {
    this.locUrl = siteMap["xmlData"];
    this.selectedTags = siteMap["selectedTags"];
    this.columns = this.selectedTags;
    this.isCorrectSitemap = true;
    for (const tag of this.locUrl) {
      this.columns.map((column) => {
        if (column && !tag.hasOwnProperty(column.name)) {
          tag[column.name] = column.value;
        }
      });
    }
    const hasProtocol =
      domain.startsWith("http://") || domain.startsWith("https://");
    if (hasProtocol) {
      const baseURL = new URL(domain).hostname;
      this.domainName = baseURL;
      this.previousDomain = baseURL;
    } else {
      if (domain.includes("/")) {
        this.domainName = domain.split("/")[0];
        this.previousDomain = this.domainName;
      }
    }
  }
  generateXmlSitemap() {
    this.invalidDomainName = [];
    let emptyColVal = [];
    let xmlString = "";
    let index = -1;
    let dupUrl = [];
    let isDuplicateURl = false;
    let duplicateUrlCount = 0;
    let duplicateUrlIndx = [];
    let totalCol = 0;
    let regx = /^(?!-)[A-Za-z0-9-]+([-\.]{1}[a-z0-9]+)*\.[A-Za-z]{2,6}$/;
    const columnNames = this.selectedTags.map((column) => column.name);
    if (this.domainName.includes("http:") || this.domainName.includes("https:"))
      regx =
        /^((http|https):\/\/)(www.)?(?!-)[A-Za-z0-9-]+([\-\.]{1}[a-z0-9]+)*\.[A-Za-z]{2,6}$/;
    if (this.domainName.length > 0 && regx.test(this.domainName)) {
      for (const row of this.locUrl) {
        let countEmptyCol = 0;
        if (row["LOC"].length > 0) {
          xmlString += "<url>";

          if (row["LOC"]) {
            index++;
            let domain;
            let url = Array.isArray(row["LOC"]) ? row["LOC"][0] : row["LOC"];
            const hasProtocol =
              url.startsWith("http://") || url.startsWith("https://");
            if (hasProtocol) {
              const parsedUrl = new URL(url);
              domain = parsedUrl.origin;
            } else domain = url.split("/")[0];
            if (regx.test(domain)) {
              if (dupUrl.includes(url)) {
                let i = dupUrl.indexOf(url);
                duplicateUrlCount++;
                duplicateUrlIndx.push(index, i);
              }
              dupUrl.push(url);
              xmlString += `<loc>${this.protocol}${row.LOC}</loc>`;
            } else {
              this.invalidDomainName.push(index);
            }
          }
          if (this.invalidDomainName.length === 0) {
            if (
              columnNames.includes("LASTMOD") &&
              row["LASTMOD"] !== undefined
            ) {
              let len = Array.isArray(row["LASTMOD"])
                ? row["LASTMOD"][0].length
                : row["LASTMOD"].length;
              if (len === 0) countEmptyCol++;
              if (!this.checkedXML || len > 0)
                xmlString += `<lastmod>${row["LASTMOD"]}</lastmod>`;
            }
            if (
              columnNames.includes("CHANGEFREQ") &&
              row["CHANGEFREQ"] != undefined
            ) {
              let len = Array.isArray(row["CHANGEFREQ"])
                ? row["CHANGEFREQ"][0].length
                : row["CHANGEFREQ"].length;
              if (len === 0) countEmptyCol++;
              if (!this.checkedXML || len > 0)
                xmlString += `<changefreq>${row["CHANGEFREQ"]}</changefreq>`;
            }
            if (
              columnNames.includes("PRIORITY") &&
              row["PRIORITY"] != undefined
            ) {
              let len = Array.isArray(row["PRIORITY"])
                ? row["PRIORITY"][0].length
                : row["PRIORITY"].length;
              if (len === 0) countEmptyCol++;
              if (!this.checkedXML || len > 0)
                xmlString += `<priority>${row["PRIORITY"]}</priority>`;
            }
            if (countEmptyCol > 0 && this.checkedXML) {
              emptyColVal.push(index), (totalCol = countEmptyCol);
            }
            xmlString += "</url>";
          }
        } else {
          if (this.checkedXML) {
            index++;
            emptyColVal.push(index);
          }
        }
      }
      if (totalCol === 0 && this.checkedXML && duplicateUrlCount > 0) {
        isDuplicateURl = true;
        this.isDupUrlExist = true;
        emptyColVal = [...duplicateUrlIndx];
      }
      if (this.invalidDomainName.length === 0) {
        let xmlIntoArr:any= xmlString.split('<url>')
        let ar= xmlIntoArr.filter(x => x != '')
        let newar= ar.map(res =>'<url>'+res)
        let a2:any=[]
        if (Number(this.totalRoutesAllowed) > 0) {
          this.seperateNum = Math.round(this.locUrl.length / Number(this.totalRoutesAllowed)).toString()
          let a1 = new Array(Number(this.seperateNum))
          for (let index = 0; index < a1.length; index++) {
            a2.push(newar.splice(0, Number(this.totalRoutesAllowed)).join(''))
          }
        }
        xmlString = `<?xml version="1.0" encoding="UTF-8"?>
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${xmlString}</urlset>`;
        let item = isDuplicateURl
          ? `Rows Marked In Red Contains Duplicates Url.`
          : `Rows Marked In Red Contains Missing Values.`;
        if (!this.checkedXML && duplicateUrlCount > 0) {
          this.rowWithoutColVal = [];
          emptyColVal = [...duplicateUrlIndx];
          this.rowWithoutColVal = emptyColVal;
          let msg = `Rows Marked In Red Contains Duplicates Url.`;
          this.toastNotification(msg);
        } else if (totalCol === 0 && this.checkedXML && duplicateUrlCount > 0) {
          emptyColVal = [...duplicateUrlIndx];
          this.rowWithoutColVal = emptyColVal;
          let msg = `Rows Marked In Red Contains Duplicates Url.`;
          this.toastNotification(msg);
        } else if (
          (emptyColVal.length > 0 && this.checkedXML) ||
          isDuplicateURl
        ) {
          this.rowWithoutColVal = [];
          this.rowWithoutColVal = emptyColVal;
          const refMethod = this.dialogService.open(NotificationComponent, {
            width: "30%",
            baseZIndex: 10000,
            rtl: true,
            styleClass: "customModal",
            data: { methodData: "siteMapAlert", item },
            showHeader: false,
          });
          refMethod.onClose.subscribe((res) => {
            if (res) {
              this.isEmptyCol = true;
            } else {
              if (duplicateUrlCount > 0) {
                this.isDupUrlExist = true;
                this.finduplicateUrl();
                let msg = `Rows Marked In Red Contains Duplicates Url.`;
                this.toastNotification(msg);
              } else {
                this.writeFile(xmlString, "sitemap", "xml");
              }
            }
          });
        } else {
          if (this.locUrl.length > 0 ) {
            this.isSaveFileInfoCalled=false
            const parser = new xml2js.Parser({ strict: false, trim: true });
            parser.parseString(xmlString, (err, result) => {
              this.sitemapData = result;
            })
            if (Number(this.totalRoutesAllowed) > 0 && a2.length > 0) {
              // this.writeFile(xmlString, "xml");
              let newXmlString:any
              let newXmlFileStringArr:any=[]
              for (let i = 0; i < a2.length; i++) {
                const element = a2[i];
                newXmlString =  `<?xml version="1.0" encoding="UTF-8"?>
                <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${element}</urlset>`
                newXmlFileStringArr.push(this.writeFile(newXmlString, `sitemap${i+1}`,"xml"))
              }
              if(newXmlFileStringArr && newXmlFileStringArr.length > 0){
                let genSitemapXml :any;
                genSitemapXml =`<sitemapindex xmlns="${this.protocol}${this.domainName}/schemas/sitemap/0.9">`  
                for (let j = 0; j < newXmlFileStringArr.length; j++) {
                  const xmlFileName = newXmlFileStringArr[j];
                  genSitemapXml +=`
                  <sitemap> <loc>${this.protocol}${this.domainName}/${xmlFileName}</loc>
                  <lastmod>2024-11-14T01:33:55+00:00</lastmod>
                  </sitemap>`
                }
                genSitemapXml+=`</sitemapindex>` 
                this.writeFile(genSitemapXml,'sitemap',"xml")
              }
            }
            else {
              if(this.siteMapFile && this.siteMapFile.length > 0){
                this.writeFile(xmlString, this.siteMapFile, "xml");
              }
              else this.writeFile(xmlString, "sitemap", "xml");
            }
          } else {
            let msg = `Please add url before generating sitemap.`;
            this.toastNotification(msg);
          }
        }
      } else {
        this.rowWithoutColVal = [...this.invalidDomainName];
        let msg = `Rows Marked In Red Contains Invalid Domain Name.`;
        this.toastNotification(msg);
      }
    } else {
      this.isDomainNameExist = false;
      if (this.domainName.length === 0) {
        let msg = `Please Enter Domain Name.`;
        this.toastNotification(msg);
      } else {
        let msg = `Invalid Domain Name.`;
        this.toastNotification(msg);
      }
    }
  }
  updateColumns(loc) {
    const updatedColumns = [];
    for (const tag of this.selectedTags) {
      const existingColumn = this.columns.find(
        (column) => column.name === tag.name
      );
      if (existingColumn) {
        updatedColumns.push(existingColumn);
      } else {
        updatedColumns.push({ name: tag.name, value: tag.value });
      }
    }
    this.columns = updatedColumns;
    for (const tag of loc) {
      this.columns.map((column) => {
        if (column && !tag.hasOwnProperty(column.name)) {
          tag[column.name] = column.value;
        }
      });
    }
  }
  checkEmptyCol(xmlData) {
    let maxLenObject = [];
    let compareKeys = [];
    xmlData = xmlData.filter((ele) => {
      let url = Array.isArray(ele["LOC"]) ? ele["LOC"][0] : ele["LOC"];

      if (ele.hasOwnProperty("LOC") && url.length > 0) {
        if (ele["CHANGEFREQ"] !== undefined) {
          let isFirstCapital: boolean =
            typeof ele["CHANGEFREQ"][0] === "string" &&
            ele["CHANGEFREQ"][0].charAt(0) ===
              ele["CHANGEFREQ"][0].charAt(0).toUpperCase();
          if (isFirstCapital)
            ele["CHANGEFREQ"] = Array.isArray(ele["CHANGEFREQ"])
              ? ele["CHANGEFREQ"][0].toLowerCase()
              : ele["CHANGEFREQ"].toLowerCase();
        }

        if (Array.isArray(ele.LASTMOD)) {
          var dateObject = new Date(ele.LASTMOD[0]);
          if (!isNaN(dateObject.getTime())) {
            var formattedDate = dateObject.toISOString().substring(0, 10);
            ele.LASTMOD = formattedDate;
          } else ele.LASTMOD = ele.LASTMOD[0];
        }
        if (url.includes("http:") || url.includes("https:")) {
          url = url.split("/");
          url = url.splice(2);
          ele.LOC = url.join("/");
        }

        const uniqueKeys = Object.keys(ele).filter(
          (item) => !compareKeys.includes(item)
        );
        maxLenObject.push(uniqueKeys);
        compareKeys.push(ele);
        return true;
      } else {
        this.isValidSiteMap = false;
        return false;
      }
    });
    const uniqueKeys = maxLenObject.reduce((keys, arr) => {
      arr.forEach((key) => {
        if (!keys.includes(key)) {
          keys.push(key);
        }
      });
      return keys;
    }, []);

    let selectedTags = this.tagOptions.filter((tag) =>
      uniqueKeys.includes(tag.name)
    );
    return {
      xmlData: xmlData,
      selectedTags: selectedTags,
    };
  }
  handleInput(event: any, item): void {
    const inputValue = event.target.value;
    if (inputValue.startsWith(this.domainName)) {
      item.LOC = item.LOC;
    }
  }

  onKeydown(event: KeyboardEvent) {
    const disallowedKeys = /[!@#$%^&*()+=[\]{};'"\\|,<>\/? `:_~]/;
    if (disallowedKeys.test(event.key)) {
      event.preventDefault();
    }
  }
  onDomainName(domainName: string) {
    const domainWithoutWww = domainName.replace(/^www\./, "");
    const startsOrEndsWithHyphen = /^-|-\./;
    const hasHyphenAfterCom = /\.com-/;
    this.isDomainNameExist = true;
    if (
      !startsOrEndsWithHyphen.test(domainWithoutWww) &&
      !hasHyphenAfterCom.test(domainWithoutWww)
    ) {
      this.locUrl = this.locUrl.map((ele) => {
        let name;
        let urlNode = Array.isArray(ele.LOC) ? ele.LOC[0] : ele.LOC;
        if (domainName.length > 0) {
          if (urlNode.includes("/") || urlNode.includes("-")) {
            if (
              this.previousDomain === undefined ||
              this.previousDomain.length <= 0
            ) {
              ele["LOC"] = domainName + "/" + urlNode;
            } else {
              try {
                const parsedUrl = new URL(
                  urlNode.includes("http:") || urlNode.includes("https:")
                    ? urlNode
                    : "http://" + urlNode
                );
                name = parsedUrl.pathname.substring(1);
                const queryParams = parsedUrl.search;
                const fragment = parsedUrl.hash;
                let fullPath = name;
                if (queryParams) {
                  fullPath += queryParams;
                }
                if (fragment) {
                  fullPath += fragment;
                }
                if (parsedUrl.pathname === "/") {
                  if (
                    this.previousDomain + "/" === urlNode ||
                    this.previousDomain !== urlNode
                  )
                    ele["LOC"] = domainName + "/";
                  else {
                    if (urlNode.includes("//")) {
                      let check = urlNode.split("//");
                      check.slice(1);
                      ele["LOC"] = domainName + check.slice(1);
                    }
                  }
                } else ele["LOC"] = domainName + "/" + fullPath;
              } catch (error) {
                let url = urlNode.split("/");
                url = url.splice(1);
                ele["LOC"] = domainName + "/" + url.join("/");
              }
            }
          } else if (!urlNode) ele["LOC"] = domainName + "/";
          else {
            ele["LOC"] = domainName + "/" + urlNode;
          }
        } else {
          if (urlNode.includes("/")) {
            if (
              this.previousDomain === undefined ||
              this.previousDomain.length <= 0
            ) {
              ele["LOC"] = urlNode;
            } else {
              try {
                const parsedUrl = new URL(
                  urlNode.includes("http:") || urlNode.includes("https:")
                    ? urlNode
                    : "http://" + urlNode
                );
                if (parsedUrl.pathname === "/") ele["LOC"] = "";
                else {
                  name = parsedUrl.pathname.substring(1);
                  const queryParams = parsedUrl.search;
                  const fragment = parsedUrl.hash;
                  let fullPath = name;
                  if (queryParams) {
                    fullPath += queryParams;
                  }
                  if (fragment) {
                    fullPath += fragment;
                  }
                  ele["LOC"] = fullPath;
                }
              } catch (error) {
                let url = urlNode.split("/");
                url = url.splice(1);
                ele["LOC"] = url.join("/");
              }
            }
          } else {
            ele["LOC"] = ele["LOC"];
          }
        }
        return ele;
      });
    }
    this.previousDomain = domainName;
  }

  removeValidation() {
    if (this.rowWithoutColVal.length > 0 && !this.checkedXML)
      this.rowWithoutColVal = [];
  }

  validateDomainName(domainName, rowsDoaminName?) {
    let regx;
    if (domainName.includes("http:") || domainName.includes("https:"))
      regx =
        /^((http|https):\/\/)(www.)?(?!-)[A-Za-z0-9-]+([\-\.]{1}[a-z0-9]+)*\.[A-Za-z]{2,6}$/;
    else regx = /^(?!-)[A-Za-z0-9-]+([-\.]{1}[a-z0-9]+)*\.[A-Za-z]{2,6}$/;
    if (regx.test(domainName)) {
      this.isDomainNameExist = true;
      if (rowsDoaminName) return true;
      else {
        if (this.invalidDomainName.length > 0) this.rowWithoutColVal = [];
      }
    } else {
      if (this.invalidDomainName.length > 0) return false;
      else {
        this.isDomainNameExist = false;
        let msg = `Invalid Domain Name `;
        this.toastNotification(msg);
      }
    }
  }

  reloadSitemap() {
    this.getUrlSitemap();
    this.isReload = true;
  }
  openCalendar(event: any, index) {
    this.calendarIndex = index;
    this.cdref.detectChanges();
    if (this.calendars) {
      this.calendars.showOverlay();
    }
    event.stopPropagation();
  }

  removeEntry(index: number) {
    if (index >= 0 && index < this.locUrl.length) {
      this.locUrl.splice(index, 1);
      this.seperateNum = Math.round(this.locUrl.length/Number(this.totalRoutesAllowed)).toString()
      if (this.rowWithoutColVal.length > 0) {
        this.rowWithoutColVal = this.rowWithoutColVal.filter(
          (i) => i !== index
        );
        if (this.isDupUrlExist || this.checkedXML === false)
          this.finduplicateUrl();
      }
    }
  }
  addEntry() {
    let columnsArr = [];
    this.isCorrectSitemap = true;
    this.columns.map((column) => {
      if (column && !columnsArr.hasOwnProperty(column.name)) {
        columnsArr[column.name] = column.value;
      }
    });

    if (this.domainName && this.domainName.length > 0) {
      this.locUrl.push({ LOC: this.domainName + "/", ...columnsArr });
    } else this.locUrl.push({ LOC: "", ...columnsArr });
  }
  checkRows(row: any, i: number) {
    if (this.rowWithoutColVal.length > 0) {
      let noEmptyCol = false;
      for (const key of Object.keys(row)) {
        let keys = Array.isArray(row[key]) ? row[key][0] : row[key];
        if (keys.length > 0) {
          noEmptyCol = true;
        } else {
          if (this.checkedXML === false && noEmptyCol) {
            this.rowWithoutColVal = this.rowWithoutColVal.filter(
              (ele) => ele !== i
            );
          }
          noEmptyCol = false;
          break;
        }
      }
      if (noEmptyCol) {
        this.rowWithoutColVal = this.rowWithoutColVal.filter(
          (ele) => ele !== i
        );
      }

      let url = Array.isArray(row["LOC"]) ? row["LOC"][0] : row["LOC"];
      let name = url.split("/")[0];
      if (this.checkedXML === false || (this.isDupUrlExist && noEmptyCol)) {
        if (this.invalidDomainName.length > 0) {
          let val = this.validateDomainName(name, "rowsDoaminName");
          if (val) {
            this.rowWithoutColVal = this.rowWithoutColVal.filter(
              (ele) => ele !== i
            );
            this.invalidDomainName = this.rowWithoutColVal;
          } else this.rowWithoutColVal = this.invalidDomainName;
        } else this.finduplicateUrl();
      } else if (
        (this.checkedXML === true && this.isDupUrlExist) ||
        this.invalidDomainName.length > 0
      ) {
        if (this.invalidDomainName.length > 0) {
          this.validateDomainName(name);
          if (this.isDomainNameExist)
            this.rowWithoutColVal = this.rowWithoutColVal.filter(
              (ele) => ele !== i
            );
        } else this.finduplicateUrl();
      }
    }
  }
  // ***************************************************************HTML SITEMAP****************************************************************
  generateHTMLSitemap(node) {
    let html = "";
    html += `<li class="lhead"> 
  <a href="${this.htmlDomainName}/${node.routerLink}">
  <span>${node.properties.name}</span></a></li>`;

    if (
      node.children &&
      node.children.length > 0 &&
      node.children[0].properties.name !== ""
    ) {
      html += '<li class="lpage last-page">';
      html += "<ul>";
      for (const childNode of node.children) {
        html += this.generateHTMLSitemap(childNode);
      }
      html += "</ul>";
      html += "</li>";
    } else {
      html += '<li class="lpage last-page">';
      html += "</li>";
    }
    this.countPage++;
    return html;
  }
  addChildEleRow(item) {
    this.addChild = true;
    item["children"].push({
      properties: {
        name: "",
      },
      children: [],
      collapsed: true,
      routerLink: "",
      routeLinkPath: "",
    });
  }
  updateRouterLink(item, event) {
    item.routeLinkPath = event.target.value;
  }
  deleteHTMLRow(item, index) {
    item.splice(index, 1);
  }

  showAllPaths() {
    this.showHtmlPaths = true;
  }
  saveHTMLSitemap() {
    if (
      (this.htmlDomainName.length > 0 &&
        this.htmlDomainName.includes("https://")) ||
      this.htmlDomainName.includes("http://")
    ) {
      this.htmlDomainName = this.htmlDomainName;
    } else {
      if (this.htmlDomainName.length > 0)
        this.htmlDomainName = "http://" + this.htmlDomainName;
    }
    const lastUpdatedString = this.getLastUpdatedString();
    let htmlstring = "";
    for (const node of this.htmlSitemap) {
      htmlstring += this.generateHTMLSitemap(node);
    }
    htmlstring = `<!DOCTYPE html>
      <html lang="en">
      <head>   
      <meta charset="utf-8">
      <title>${this.htmlDomainName} HTML SITE MAP</title>
      <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
      <style type="text/css">
        body {
          background-color: #fff;
          font-family: "Roboto", "Helvetica", "Arial", sans-serif;
          margin: 0;
        } 
        #top {
          background-color: #b1d1e8;
          font-size: 16px;
          padding-bottom: 40px;
        }
        nav {
          font-size: 24px;
          margin: 0px 30px 0px;
          border-bottom-left-radius: 6px;
          border-bottom-right-radius: 6px;
          background-color: #f3f3f3;
          color: #666;
          box-shadow: 0 10px 20px -12px rgba(0, 0, 0, 0.42), 0 3px 20px 0px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);
          padding: 10px 0;
          text-align: center;
          z-index: 1;
        }
  
        h3 {
          margin: auto;
          padding: 10px;
          max-width: 600px;
          color: #666;
        }
        h3 span {
          float: right;
        }
        h3 a {
          font-weight: normal;
          display: block;
        }
      #htmlsiteMap {
        position: relative;
        border-radius: 6px;
        box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);
        background: #f3f3f3;
        margin: -20px 30px 0px 30px;
        padding: 20px;
      }
      a{
        cursor: pointer;
      }
      a:link,
      a:visited {
        color: black;
        color: #0180AF;
        text-decoration: underline;
      }
      a:hover {
        color: #666;
      }
    ul {
        margin: 0px;
        padding: 0px;
        list-style: none;
    }
    li {
      margin: 0px;
    }
    li ul {
      margin-left: 20px;
    }
    .lhead {
      background: #ddd;
      padding: 10px;
        margin: 10px 0px;
    }
    .lpage {
      border-bottom: #ddd 1px solid;
      padding: 5px;
    }
    .last-page {
      border: none;
  }
    </style>
    </head>
    <body>
    <div id="top">
   <nav>${this.htmlDomainName.split("//")[1]} HTML Site Map</nav>
   <h3 >
    <span>${lastUpdatedString}<br> Total pages: ${this.countPage}</span>
    <a href="${this.htmlDomainName}" style="color: #0180AF;
    text-decoration: underline; cursor: pointer;">${
      this.htmlDomainName.split("//")[1]
    } Homepage</a>
    </h3>
    </div> 
    <div id="htmlsiteMap"><ul>${htmlstring}</ul></div>
  </body>
    </html> `;
    this.writeFile(htmlstring, "sitemap","html", );
  }
  getLastUpdatedString(): string {
    const currentDate = new Date();
    const formattedDate = currentDate.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    return `Last updated: ${formattedDate}`;
  }

  finduplicateUrl() {
    this.rowWithoutColVal = [];
    let dupURL = [];
    this.locUrl.filter((ele, indx) => {
      let loc = Array.isArray(ele["LOC"]) ? ele["LOC"][0] : ele["LOC"];
      if (dupURL.includes(loc)) {
        let i = dupURL.indexOf(loc);
        this.rowWithoutColVal.push(indx, i);
      }
      dupURL.push(loc);
    });
  }

  writeFile(xmlString, sitemap,extension) {
    this.rowWithoutColVal = [];
    let newPath = `${this.projectInfo.awspace}/src/${sitemap}.${extension}`;
    const blob = new Blob([xmlString], { type: "application/xml" });
    const writeFileOnServerData = new FormData();
    writeFileOnServerData.append("flag", "true");
    writeFileOnServerData.append("path", newPath);
    writeFileOnServerData.append("file", blob);
    this._apiService
      .writeFileOnserver(writeFileOnServerData)
      .subscribe((res) => {
        try {
          if (res) {
            const projectDetails = this._shareService.getDataprotool("selectedProjectChooseData");
            let obj={
              "projectPath": projectDetails['awspace'],
              "projectId": projectDetails.projectId,
              "filePath": `${projectDetails['awspace']}/src/sitemap.xml`,
              "fileName": "sitemap.xml",
              "usrId": projectDetails['userId']
            }
            if (!this.isSaveFileInfoCalled) {
            this._shareService.saveFileInfo(obj).subscribe((res:any)=>{})
            this.toast.launch_toast({
              type: "success",
              position: "bottom-right",
              message: res["msg"],
            });
            this.isSaveFileInfoCalled = true;
          }
          }
        } catch (error) {
          throw error;
        }
      });
      return `${sitemap}.${extension}`
  }
  toastNotification(msg) {
    this.toast.launch_toast({
      type: "alert",
      position: "bottom-right",
      message: msg,
    });
  }
  closeModal() {
    this.modalRef.close(false);
  }
  // *****************************SELECT URL FROM DB**************************
  projectLagData: any;
  getAllFileData: any;
  checkedURL = false
  selectedURLs: any[] = []
  selectAll = false
  urlFormDB


  addUrl() {
    let id = {
      projectId: this.projectInfo.projectId,
    };
    const res = new Promise<any[]>((resolve, reject) => {
      this._shareService.getUrl(id).subscribe(
        (res: any) => {
          if (res.length > 0) {
            this.isCorrectSitemap = true;
            resolve(res);
          } else {
            resolve([]);
          }
        },
        (error) => {
          reject(error);
        }
      );
    });
    res
      .then((urlData: any[]) => {
        this.urlFormDB=urlData
      })
      .catch((error) => {});
  }

  onChange(url: string, isChecked: boolean, index: number) {
    if (isChecked) {
      let domianURL = Array.isArray(url) ? url['LOC'][0] : url['LOC']
      if (this.domainName && this.domainName.length > 0) {
        let concatDomainName = JSON.parse(JSON.stringify(url))
        concatDomainName['LOC'] = this.domainName + '/' + domianURL
        this.selectedURLs.push(concatDomainName);
      } else this.selectedURLs.push(url);
    } else {
      this.selectedURLs.splice(index, 1);
    }
  }

  selectAllURL(url) {
    if (this.domainName.length && this.domainName.length > 0) {
      this.selectedURLs = url.map(ele => ({
        ...ele,
        LOC: this.domainName + '/' + ele.LOC
      }));
    } else {
      this.selectedURLs = [...url]
    }
  }
    bootstrap: any;
  saveSiteMapURL() {
    this.addDBUrlInSitemap(this.selectedURLs);
    $('#staticBackdrop').modal('hide')
  }
  closeModel() {
    this.modalRef.close(true);
  }
  addDBUrlInSitemap(selectedURLs){
    if (  selectedURLs !== undefined &&   selectedURLs.length > 0) {
      for (const tag of selectedURLs) {
        this.columns.map((column) => {
          if (column && !tag.hasOwnProperty(column.name)) {
            tag[column.name] = column.value;
          }
        });
      }
      selectedURLs =   selectedURLs.filter((ele) => {
        return !this.locUrl.some((url) => {
          let loc = Array.isArray(url["LOC"])
            ? url["LOC"][0]
            : url["LOC"];
          return loc === ele["LOC"];
        });
      });

      this.locUrl = this.locUrl.concat(selectedURLs);
    }
  }
  hideButtons(tabName: String) {
    if (tabName === 'code' || tabName === 'validation') this.isViewSelected = false
    else this.isViewSelected = true
  }
  async selectSiteMapFile(event: any) {
    let filePath = {
      filePath: `${this.projectInfo.awspace}/src/${event.target.value}.xml`
    }
    const res = await this._shareService.getXml(filePath).toPromise()
    this.siteMapRes = res
    this.getUrlSitemap()
  }
}
