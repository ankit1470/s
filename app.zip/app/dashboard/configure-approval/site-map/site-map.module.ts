import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SiteMapRoutingModule } from './site-map-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SiteMapRoutingModule
  ]
})
export class SiteMapModule { }
