import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-java-ssr-info',
  templateUrl: './java-ssr-info.component.html',
  styleUrls: ['./java-ssr-info.component.scss']
})
export class JavaSsrInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
