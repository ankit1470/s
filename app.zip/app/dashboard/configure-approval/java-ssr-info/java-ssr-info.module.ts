import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JavaSsrInfoRoutingModule } from './java-ssr-info-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    JavaSsrInfoRoutingModule
  ]
})
export class JavaSsrInfoModule { }
