import { AfterViewInit, Component, OnInit } from '@angular/core';
import { DynamicDialogConfig } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { SagShareService } from 'src/app/services/sagshare.service';
@Component({
  selector: 'app-temp-page-modal',
  templateUrl: './temp-page-modal.component.html',
  styleUrls: ['./temp-page-modal.component.scss']
})
export class TempPageModalComponent implements OnInit, AfterViewInit {
  htmlThemeData: any
  gridDynamicObj_: any;

  constructor(public config: DynamicDialogConfig, private _shareService: SagShareService, private toastSrv: ToastService) { }
  ngOnInit() { }

  ngAfterViewInit() {
    if (this.config.data['buttonMode'] == 'show') {
      this.getThemeHtmlData()
    }
  }
  getThemeHtmlData() {
    let post
    const id = document.getElementById('sectionRow');
    if (Array.isArray(this.config.data['item']) || typeof this.config.data['item'] === 'string') {
      if (this.config.data['item'].length === 0) { id.innerHTML = "" }
      else {
        let data = {themecss: (this.config.data['item'])}
        id.innerHTML = JSON.stringify(data.themecss)
      }
    }else if (typeof this.config.data['item'] === 'number') {
      post = {  pagemasterId:this.config.data['item']}
     }
    if(post !== undefined){
      if (post.pagemasterId) {
        this._shareService.getThemeHtmlData(post).subscribe((res: any) => {
          if (res) {
            id.innerHTML = JSON.stringify(res['htmlJson'])
          }
        })
    }
    }
}
saveThemeHtmlData() {
  const themeCss = {
    "css": this.htmlThemeData,
    "themecssdetId": this.config.data['themecssdetId'],
    "themecssId": this.config.data['themecssId'],
    "label": this.config.data['label'],
    "value": this.config.data['value']
  }
  this._shareService.updateThemeCss(themeCss).subscribe((res) => {
    if (res) {
      this.toastSrv.launch_toast({
        message: res['msg'],
      })
    }
  })


  // let post = {
  //   pagemasterId: Number(this.config.data['item']),
  //   htmlJson: JSON.parse(this.htmlThemeData)
  // }
  // this._shareService.modifyThemeHtmlData(post).subscribe((res: any) => {
  //   if (res) {
  //     console.log(res, "successfully modified")
  //   }
  // })
}

 



}
