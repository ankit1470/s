import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TempPageModalRoutingModule } from './temp-page-modal-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TempPageModalRoutingModule
  ]
})
export class TempPageModalModule { }
