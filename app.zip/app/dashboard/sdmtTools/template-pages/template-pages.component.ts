import { Component, OnInit } from "@angular/core";
import { SagShareService } from "src/app/services/sagshare.service";
import { Dropdown } from 'primeng/dropdown';
import { DialogService, DynamicDialogRef } from "primeng/api";
import { TempPageModalComponent } from "./temp-page-modal/temp-page-modal.component";
import { ToastService } from "src/app/core/services/toast.service";
declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var SagHeaderButton;
declare var _;
declare var ui;
declare var SagInsertImage;
declare var SagButton;
declare var circlr;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: "app-template-pages",
  templateUrl: "./template-pages.component.html",
  styleUrls: ["./template-pages.component.scss"],
})
export class TemplatePagesComponent implements OnInit {
  constructor(private _shareService: SagShareService,
    public dialogService: DialogService,
    public modalRef: DynamicDialogRef,
    private toastSrv: ToastService
  ) { }

  ngOnInit() {
    this._shareService.getModulesetList(true).subscribe(res => {
      // this.rowData_temPagesGrid = res['data'];
      this.temPagesGrid();
      this.modulesetList = res['data'].map(item => {
        let newItem = item;
        newItem['label'] = item.modulesetName,
          newItem['value'] = item.modulesetId
        return newItem;
      });


    });
  }

  // Opening modal for showing page template details with API @rohita arya
  openPageTemplate(pmId: any, btnMode: any) {
    const ref = this.dialogService.open(TempPageModalComponent, {
      header: '                       ',
      width: '90%',
      contentStyle: { "box-shdow": "none" },
      styleClass: "validation_comp_data theme-compdata",
      data: {
        item: pmId,
        buttonMode: btnMode
      }
    });
    ref.onClose.subscribe((res) => {
      if (res) {
        console.log("close Modal Data", res);
      }
    });
  }


  modulesetList: any = [];
  templateList: any = [{ "label": "All", "value": "-1" }];
  modulesetId: number;
  templateId: number;
  x: number = 2;
  gridData_temPagesGrid: any;
  gridDynamicObj_temPagesGrid: any;

  columnData_temPagesGrid: any = [
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "sno",
      freezecol: "null",
      width: "50px",
      header: "S.No",
      "text-align": "left",
    },
    {
      header: "NAME",
      field: "pmName",
      filter: true,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "PAGE MASTER ID",
      field: "pmPId",
      filter: true,
      width: "200px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "DESCRIPTION",
      field: "pmDescrip",
      filter: true,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "IMAGE PATH",
      field: "pmImage",
      filter: true,
      width: "150px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "PAGE LABEL",
      field: "pmLabel",
      filter: true,
      width: "150px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "TEMPLATE ID",
      field: "pTmId",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "APPROVED",
      field: "pmApprv",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "STATUS",
      field: "pmStatus",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "PAGECODE ID",
      field: "pageCodeId",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "DATA ROWS",
      field: "dataKeyNum",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "MASTER KEY",
      field: "masterKeyId",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "PAGE CODE MAP ID",
      field: "pageMapId",
      filter: true,
      width: "150px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      "header": "Action",
      "field": "show",
      "filter": true,
      "width": "80px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Show", "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },
    },
    {
      "header": "Action",
      "field": "update",
      "filter": true,
      "width": "80px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Update", "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },
    },
  ];

  // rowData_temPagesGrid: any = [{}, {}, {}, {}, {}, {}, {}, {}, {}];
  rowData_temPagesGrid: any = [];

  temPagesGrid(rowData?, colData?) {
    let self = this;

    this.gridData_temPagesGrid = {
      columnDef: colData ? colData : this.columnData_temPagesGrid,
      rowDef: rowData ? rowData : this.rowData_temPagesGrid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {
        "onButton_show": function (ele, param) {
          self.gridDynamicObj_temPagesGrid.selectedRowINdex = param.rowIndex
          let selectedRow = self.gridDynamicObj_temPagesGrid.getSeletedRowData();
          if (selectedRow !== null) {
            selectedRow.pmId = parseInt(selectedRow.pmId, 10);
            self.openPageTemplate(selectedRow.pmId, 'show');
          }
        },
        "onButton_update": function (ele) {
          let setRowSelected = self.gridDynamicObj_temPagesGrid.getSeletedRowData();
          self.openPageTemplate(setRowSelected.pmId, 'update');
        },
        onCellClick: function (ele) {
          self.ontemPagesGridCellClick();
        },
        onRowClick: function () {
          self.ontemPagesGridClick();
        },
        onRowDbleClick: function () {
          self.ontemPagesGriddblClick();
        },
      },
      rowCustomHeight: 30,
    };

    let sourceDiv = document.getElementById("temPagesGrid");
    this.gridDynamicObj_temPagesGrid = SdmtGridT(
      sourceDiv,
      this.gridData_temPagesGrid,
      true,
      true
    );
  }

  ontemPagesGridCellClick() { }

  ontemPagesGridClick() {
    this._shareService.setData['selectedTemplate']= this.gridDynamicObj_temPagesGrid.getSeletedRowData();
   }

  ontemPagesGriddblClick() { }

  getModulesetTemplates(event) {
    this.modulesetId = event.value
    let tmpObject = this.modulesetList.filter((obj) => {
      return obj.modulesetId == this.modulesetId;
    });
    this.templateList = [];
    this.templateList = tmpObject[0].templates.map(item => {
      let newItem = item;
      newItem['label'] = item.label,
        newItem['value'] = item.templateId
      return newItem;
    });
  }


  setTemplateId(event) {
    this.templateId = event.value;
  }

  showTemplatePages() {
    this._shareService.getTemplatePages(this.modulesetId, (this.templateId !== undefined) ? this.templateId : 0).subscribe(res => {
      this.rowData_temPagesGrid = res['data'];
      this.temPagesGrid();
    });
  }

  close() {
    this.modalRef.close(this._shareService.setData['selectedTemplate']);
  }

  deleteRow() {

    let selectedRow = this.gridDynamicObj_temPagesGrid.getSeletedRowData()
    const deleteRowData = {
      "pagetemplateId": selectedRow.pTmId,
      "pagemasterlabel": selectedRow.pmLabel
    }
    if (this.gridDynamicObj_temPagesGrid.selectedRowINdex == null) {
      alert("Please select atleast one item to delete");
    }
    else {
      let text = "Are you sure you want to delete this row?"
      if (confirm(text) == true) {
        this.gridDynamicObj_temPagesGrid.deleteRow(this.gridDynamicObj_temPagesGrid.selectedRowINdex);
        this._shareService.deleteTemplatePageRow(deleteRowData).subscribe(res => {
          this.toastSrv.launch_toast({
            type: res['status'],
            position: 'bottom-right',
            message: res['msg'],
          })
  
        })
      }
    }

  }
}