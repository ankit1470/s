import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TemplatePagesRoutingModule } from './template-pages-routing.module';
import { TemplatePagesComponent } from './template-pages.component';
import { DropdownModule } from 'primeng/dropdown';
import { TempPageModalComponent } from './temp-page-modal/temp-page-modal.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [TemplatePagesComponent, TempPageModalComponent],
  imports: [
    CommonModule,
    TemplatePagesRoutingModule,
    DropdownModule,
    FormsModule
  ]
})
export class TemplatePagesModule { }
