import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { DynamicDialogRef } from "primeng/primeng";
import { SagShareService } from "src/app/services/sagshare.service";
declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var SagHeaderButton;
declare var _;
declare var ui;
declare var SagInsertImage;
declare var SagButton;
declare var circlr;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: "app-templates",
  templateUrl: "./templates.component.html",
  styleUrls: ["./templates.component.scss"],
})
export class TemplatesComponent implements OnInit {

  templateForm: FormGroup;
  controlList: any = []
  moduleSetList: any = []
  backendToolList: any = []
  dropdowncreateMultiModelData = []
  gridData_templatesGrid: any;
  gridDynamicObj_templatesGrid: any;
  rowData_templatesGrid: any = [];
  columnData_templatesGrid: any = [
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "sno",
      freezecol: "null",
      width: "50px",
      header: "S.No",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "name",
      freezecol: "null",
      width: "250px",
      header: "Name",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "descr",
      freezecol: "null",
      width: "250px",
      header: "Description",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "cPanel",
      freezecol: "null",
      width: "150px",
      header: "CPanel",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "viewcolumn",
      freezecol: "null",
      width: "150px",
      header: "View Column",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "imgurl",
      freezecol: "null",
      width: "200px",
      header: "Image Url",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "templateorder",
      freezecol: "null",
      width: "100px",
      header: "Order",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "bkndcodetype",
      freezecol: "null",
      width: "200px",
      header: "Backend Code Type",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "toolid",
      freezecol: "null",
      width: "100px",
      header: "Tool Id",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "templateId",
      freezecol: "null",
      width: "100px",
      header: "Template Id",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "toolname",
      freezecol: "null",
      width: "150px",
      header: "Tool Name",
      "text-align": "left",
    },
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "ctrlId",
      freezecol: "null",
      width: "100px",
      header: "Ctrl Id",
      "text-align": "left",
    },
  ];

  constructor(
    public modalRef: DynamicDialogRef,
    private _shareService: SagShareService,
    private _formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.getTemplatesList()
    this.getModuleSetList();
    this.getBacktoolList()

    this.templateForm = this._formBuilder.group({
      templateId: [''],
      templateName: [''],
      description: [''],
      imgUrl: [''],
      ctrlId: [''],
      backendType: [''],
      backendTool: [''],
      moduleSet: [''],
      cpanel: [''],
      moduleSetIds: [[]]
    })

    this.controlAction()

    this.templateForm.controls['backendTool'].valueChanges.subscribe({
      next: (res: any) => {
        if (res) {
          this.templateForm.controls['backendType'].setValue('Z');
        } else {
          this.templateForm.controls['backendType'].setValue('');
        }
        this.controlAction()
      }
    })

  }

  controlAction() {
    this.templateForm.controls['backendType'].disable();
    this.templateForm.controls['backendType'].updateValueAndValidity();
  }

  templatesGrid(rowData?, colData?) {
    let self = this;

    this.gridData_templatesGrid = {
      columnDef: colData ? colData : this.columnData_templatesGrid,
      rowDef: rowData ? rowData : this.rowData_templatesGrid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {
        onCellClick: function (ele) {
          self.ontemplatesGridCellClick();
        },
        onRowClick: function () {
          self.ontemplatesGridClick();
        },
        onRowDbleClick: function () {
          self.ontemplatesGriddblClick();
        },
      },
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("templatesGrid");
    this.gridDynamicObj_templatesGrid = SdmtGridT(
      sourceDiv,
      this.gridData_templatesGrid,
      true,
      true
    );
  }

  // To get selected module set ids
  getSelectedModuleSetIds() {
    let idArr = this.templateForm.controls['moduleSetIds'].value;
    let set = this.templateForm.controls['moduleSet'].value;
    if (set.length) {
      idArr = idArr ? idArr : [];
      set.forEach((res) => {
        idArr.push(Number(res.modulesetId))
      })
      this.templateForm.controls['moduleSetIds'].setValue(idArr)
    }
  }

  // To get templates listing
  getTemplatesList() {
    this._shareService.getTemplatesList().subscribe(res => {
      this.rowData_templatesGrid = res['templateList'];
      this.controlList = res['ctrlList'];
      this.templatesGrid();
    });
  }

  // To get module set listing
  getModuleSetList() {
    this._shareService.getModulesetList(false).subscribe(res => {
      this.moduleSetList = res['data'];
    });
  }

  // To get backend tool listing
  getBacktoolList() {
    this._shareService.getBackendtoolList().subscribe(res => {
      this.backendToolList = res;
    });
  }

  // to modify the template row
  modifyTemplateForm() {
    let selectedRow = this.gridDynamicObj_templatesGrid.getSeletedRowData()
    if (!selectedRow) {
      alerts("Please select atleast one item to modify");
    } else {
      this.saveTemplatesForm()
    }
  }

  // to submit the template form
  saveTemplatesForm() {
    if (this.templateForm.valid) {
      this.getSelectedModuleSetIds()
      let obj = {
        templateId: this.templateForm.controls['templateId'].value,
        label: this.templateForm.controls['templateName'].value,
        desc: this.templateForm.controls['description'].value,
        ctrlId: Number(this.templateForm.controls['ctrlId'].value),
        cPanel: this.templateForm.controls['cpanel'].value ? 'Y' : 'N',
        imgurl: this.templateForm.controls['imgUrl'].value,
        toolId: Number(this.templateForm.controls['backendTool'].value),
        bkndcodetype: Number(this.templateForm.controls['backendTool'].value) ? 'Z' : '',
        moduleIds: this.templateForm.controls['moduleSetIds'].value,
      }
      this._shareService.saveTemplates(obj).subscribe((res: any) => {
        if (res) {
          let result = this._shareService.showToast(res);
          if (result) {
            this.getTemplatesList()
            this.templateForm.reset()
          }
        }
      })
    }
  }

  // to delete the template row
  async deleteTemplate() {
    let selectedRow = this.gridDynamicObj_templatesGrid.getSeletedRowData()
    if (!selectedRow) {
      alerts("Please select atleast one item to delete");
    }
    else {
      let text = "Are you sure you want to delete this row?"
      const deleteRowData = {
        "templateId": selectedRow.templateId
      }
      if (await ui.confirm(text)) {
        this._shareService.deleteTemplates(deleteRowData).subscribe(res => {
          let result = this._shareService.showToast(res);
          if (result) {
            this.getTemplatesList();
            this.templateForm.reset()
          }
        })
      }
    }
  }

  // get module set object from id
  getModuleSetObject(ids: any) {
    if (ids) {
      let moduleSetArr = this.moduleSetList.filter(res => ids.includes(Number(res.modulesetId)));
      return moduleSetArr;
    }
  }

  ontemplatesGridCellClick() { }

  ontemplatesGridClick() {
    let selectedRow = this.gridDynamicObj_templatesGrid.getSeletedRowData()

    this.templateForm.patchValue({
      templateId: selectedRow.templateId,
      templateName: selectedRow.name,
      description: selectedRow.descr,
      ctrlId: selectedRow.ctrlId,
      imgUrl: selectedRow.imgurl,
      cpanel: selectedRow.cPanel == 'Y' ? true : false,
      backendType: selectedRow.bkndcodetype,
      backendTool: selectedRow.toolid,
      moduleSetIds: selectedRow.moduleIds,
      moduleSet: this.getModuleSetObject(selectedRow.moduleIds)
    });
  }

  ontemplatesGriddblClick() { }
}
