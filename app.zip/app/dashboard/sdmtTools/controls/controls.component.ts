import { Component, OnInit } from '@angular/core';
import { ToastService } from 'src/app/core/services/toast.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { SagShareService } from 'src/app/services/sagshare.service';
@Component({
  selector: 'app-controls',
  templateUrl: './controls.component.html',
  styleUrls: ['./controls.component.scss']
})
export class ControlsComponent implements OnInit {
  controlsName: any = []
  controlType: any = []
  controlSubType: any = []
  properties: any = []
  selectCtrlTypeVal: any[] = []
  isPropName: boolean = false
  isSelected: boolean = false
  type: string
  subType: string
  propList: any[] = []
  constructor(private sagShareSrv: SagShareService,
    public studioDragDropSrv: CommonStudioDragDropService,
    public sagStudioService: SagStudioService,
    private toastSrv: ToastService
  ) { }

  ngOnInit() {
    this.sagShareSrv.getControlsName().subscribe(res => {
      this.controlsName = res
      this.controlType = Array.from(new Set(this.controlsName.map(obj => obj.type)));
    })
  }
  onSelectType(event) {
    this.controlSubType = []
    this.properties = []
    this.isPropName = false
    this.type = event.target.value
    this.controlsName.filter((ele) => {
      if (ele.hasOwnProperty('type') && ele.type === this.type) {
        this.controlSubType.push(ele.subtype)
      }
    })
  }
  onSelectSubType(event) {
    this.isPropName = true
    this.subType = event.target.value
    this.controlsName.filter((ele) => {
    if (ele.hasOwnProperty('subtype') && (ele.subtype === this.subType && this.type === ele.type)) {
      this.properties= ele.propname
     }
    })
  }
  
  updateControls() {
    const propData = {
      "type": this.type,
      "subType": this.subType,
      "propName": this.propList
    }
    this.sagShareSrv.updateControlsName(propData).subscribe(res => {
      if (res) {
        this.toastSrv.launch_toast({
          type: 'success',
          position: 'bottom-right',
          message: res['msg']
        })
      } else {
        this.toastSrv.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: res['msg'],
        });
      }
    })
  }
  onMovePosition(event, list, currIndex) {
    this.propList=[]
    if (event.data) {
      let index = list.findIndex((m) => m.id == event.data.id);
      if (index == -1) {
        return this.toastSrv.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: `DOESN'T MOVE OUT OF BLOCK`,
        });
      } else {
        list.splice(index, 1);
        (index > currIndex) ? list.splice(currIndex + 1, 0, event.data) : list.splice(currIndex, 0, event.data);
        list.forEach((element: any) => {
          this.propList.push(element.id)
        });
      }
    }
  }
}
