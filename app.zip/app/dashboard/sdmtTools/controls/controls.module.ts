import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ControlsRoutingModule } from './controls-routing.module';
import { ControlsComponent } from './controls.component';
import { DndModule } from 'ngx-drag-drop';


@NgModule({
  declarations: [ControlsComponent],
  imports: [
    CommonModule,
    ControlsRoutingModule,
    DndModule
  ]
})
export class ControlsModule { }
