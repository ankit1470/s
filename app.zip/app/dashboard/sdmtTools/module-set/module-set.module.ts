import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModuleSetRoutingModule } from './module-set-routing.module';
import { ModuleSetComponent } from './module-set.component';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [ModuleSetComponent],
  imports: [
    CommonModule,
    ModuleSetRoutingModule,
    ReactiveFormsModule
  ]
})
export class ModuleSetModule { }
