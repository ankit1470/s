import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { DynamicDialogRef } from "primeng/primeng";
import { SagShareService } from "src/app/services/sagshare.service";
declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var SagHeaderButton;
declare var _;
declare var ui;
declare var SagInsertImage;
declare var SagButton;
declare var circlr;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: "app-module-set",
  templateUrl: "./module-set.component.html",
  styleUrls: ["./module-set.component.scss"],
})
export class ModuleSetComponent implements OnInit {

  moduleSetForm: FormGroup;
  gridData_moduleSetGrid: any;
  gridDynamicObj_moduleSetGrid: any;
  rowData_moduleSetGrid: any = [];
  columnData_moduleSetGrid: any = [
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "sno",
      freezecol: "null",
      width: "50px",
      header: "S.No",
      "text-align": "center",
    },
    {
      header: "MODULESET NAME",
      field: "modulesetName",
      filter: true,
      width: "300px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "SUBTYPE",
      field: "subType",
      filter: true,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "IMAGE URL",
      field: "image",
      filter: true,
      width: "400px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "C-PANEL",
      field: "cPanel",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "STATUS",
      field: "status",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "TOOLBOX ID",
      field: "toolboxId",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    }
  ];

  constructor(
    private _shareService: SagShareService,
    public modalRef: DynamicDialogRef,
    public formBuilder: FormBuilder
  ) { }

  ngOnInit() {

    this.getModuleSetList()

    // Initializing module set form
    this.moduleSetForm = this.formBuilder.group({
      modulesetName: [''],
      image: [''],
      subType: ['']
    })

    this.moduleSetForm.controls['modulesetName'].valueChanges.subscribe({
      next: (res: any) => {
        this.moduleSetForm.controls['subType'].setValue(res);
      }
    })

  }

  moduleSetGrid(rowData?, colData?) {

    this.gridData_moduleSetGrid = {
      columnDef: colData ? colData : this.columnData_moduleSetGrid,
      rowDef: rowData ? rowData : this.rowData_moduleSetGrid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,
      components: {},
      callBack: {
        onCellClick: function (ele) {
          this.onbundlegridCellClick();
        },
        onRowClick: function () {
          this.onbundlegridClick();
        },
        onRowDbleClick: function () {
          this.onbundlegriddblClick();
        }
      },
      rowCustomHeight: 20
    }

    let sourceDiv = document.getElementById("moduleSetGrid");
    this.gridDynamicObj_moduleSetGrid = SdmtGridT(
      sourceDiv,
      this.gridData_moduleSetGrid,
      true,
      true
    );
  }

  onbundlegridCellClick() { }

  onbundlegridClick() { }

  onbundlegriddblClick() {

    let rowData = this.gridDynamicObj_moduleSetGrid.getSeletedRowData()

    this.moduleSetForm.patchValue({
      modulesetName: rowData.modulesetName,
      image: rowData.image,
      subType: rowData.subType
    })

  }

  // Function for get the module set list
  getModuleSetList() {
    this._shareService.getModulesetList(false).subscribe(res => {
      this.rowData_moduleSetGrid = res['data'];
      this.moduleSetGrid();
    });
  }

  // Function for submit the module set form
  saveModuleSetForm() {
    if (this.moduleSetForm.valid) {
      let moduleSetData = {
        "moduleset": this.moduleSetForm.value.modulesetName,
        // "image"         : `<img width=\"100%\" src=\"assets/images/toolBox/pages/${this.moduleSetForm.value.image}\">`,
        "imgurl": `<img width="" src="assets/images/toolBox/module/allpage.webp">`,
        // "subType"        : this.moduleSetForm.value.subType,
      }
      this._shareService.saveModuleSet(moduleSetData).subscribe((res: any) => {
        if (res) {
          let status = this._shareService.showToast(res);
          if(status) {
            this.getModuleSetList()
            this.moduleSetForm.reset()
          }
        }
      })
    } else {
      alerts('Kindly fill the required fields!')
    }
  }
}
