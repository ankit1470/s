import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
declare function success(m): any;
@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.scss']
})
export class CategoryListComponent implements OnInit {
  category:any;
  constructor(public ref: DynamicDialogRef, public config: DynamicDialogConfig, public sagShareService:SagShareService ) { }
  
  ngOnInit() {
  }

  addCategory(){
    debugger
    if(this.category !='' && this.category != undefined && this.category != null){
      let postData ={
        "ctrlName": this.category
      }
      this.sagShareService.saveCategoryList(postData).subscribe((res)=>{
        if(res['status']=='success'){
          let categoryData ={
            category:this.category,
            ctrlId:res['ctrlId']
          }
          this.ref.close(categoryData) 
          success(res['msg'])
        }
      })
    }
  }
}
