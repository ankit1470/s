import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { DialogService, DynamicDialogRef } from "primeng/api";
import { SagShareService } from "src/app/services/sagshare.service";
import { CategoryListComponent } from "./category-list/category-list.component";
declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var SagHeaderButton;
declare var _;
declare var ui;
declare var SagInsertImage;
declare var SagButton;
declare var circlr;
declare function success(m): any;
@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: "app-bundle",
  templateUrl: "./bundle.component.html",
  styleUrls: ["./bundle.component.scss"],
})
export class BundleComponent implements OnInit {
  bundleForm:FormGroup;
  categoryList:any=[]
  ctrlId:any;
  constructor(
    private _shareService: SagShareService,
    private formBuilder:FormBuilder,
    public dialogService: DialogService,
    public modalRef: DynamicDialogRef,) {}

  ngOnInit() {
    this.getBundleList()
      this.bundleForm = this.formBuilder.group({
        bundleName:[''],
        imgUrl:[''],
        category:['']
      })    
      //setTimeout(() => {
      //  this.bundlegrid();
    // }, 50);
    
  }

  close() {
    this.modalRef.close();
  }

  getBundleList(){
    this.categoryList=[];
    this._shareService.getBundleList().subscribe(res => {
      debugger
      if(res){
        res['data'].forEach(element => {
          
          // if(element.catId){
          //   this.ctrlId=element.catId 
          // }
          this.categoryList.push(element)

        });
        console.log(this.categoryList,"new Category added")

        this.rowData_bundlegrid = res['data'];
        this.bundlegrid();
      }
    });
  }
  gridData_bundlegrid: any;
  gridDynamicObj_bundlegrid: any;
  columnData_bundlegrid: any = [
    {
      hidden: false,
      editable: "false",
      filter: true,
      search: true,
      component: "label",
      field: "sno",
      freezecol: "null",
      width: "50px",
      header: "S.No",
      "text-align": "center",
    },
    {
      header: "BUNDLE NAME",
      field: "bundleName",
      filter: true,
      width: "300px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "IMAGE URL",
      field: "bundleImageUrl",
      filter: true,
      width: "400px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "C-PANEL",
      field: "cPanel",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
      {
      header: "CATEGORY NAME",
      field: "category",
      filter: true,
      width: "200px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },{
      header: "STATUS",
      field: "status",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "CONTROL ID",
      field: "catId",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: true,
      sort: false,
      cellHover: false,
    },{
      header: "BUNDLE ID",
      field: "bundleId",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: true,
      sort: false,
      cellHover: false,
    },

  ];

  rowData_bundlegrid: any = [{}, {}, {}, {}, {}];

  bundlegrid(rowData?, colData?) {
    let self = this;

    this.gridData_bundlegrid = {
      columnDef: colData ? colData : this.columnData_bundlegrid,
      rowDef: rowData ? rowData : this.rowData_bundlegrid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {
        onCellClick: function (ele) {
          self.onbundlegridCellClick();
        },
        onRowClick: function () {
          self.onbundlegridClick();
        },
        onRowDbleClick: function () {
          self.onbundlegriddblClick();
        },
      },
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("bundlegrid");
    this.gridDynamicObj_bundlegrid = SdmtGridT(
      sourceDiv,
      this.gridData_bundlegrid,
      true,
      true
    );
  }

  onbundlegridCellClick() {}

  onbundlegridClick() {}

  onbundlegriddblClick() {
    let rowData = this.gridDynamicObj_bundlegrid.getSeletedRowData()
    console.log("This is the rowData",rowData)
    this.bundleForm.patchValue({
      bundleName:rowData.bundleName,
      imgUrl:rowData.bundleImageUrl,
      category:rowData.catId
    })
  }

  openCategoryList(){
    const ref = this.dialogService.open(CategoryListComponent, {
      header: 'Category List',
      width: '25%',
      contentStyle:{"height": "170px"},
    });

    ref.onClose.subscribe((res) => {
      if(res){
        this.ctrlId=res['ctrlId']
        this.getBundleList()
      }
    });
  }

  saveCategoryList(){
    if(this.bundleForm.valid){
      let postBundleData={
        "bundleName" : this.bundleForm.value.bundleName,
        "imgPath"     : `<img width=\"100%\" src=\"assets/images/toolBox/pages/${this.bundleForm.value.imgUrl}\">`,
        "ctrlId"     : this.ctrlId ? Number(this.ctrlId) : Number(this.selectedCatgoryId),
      }
      console.log(this.bundleForm.value.category,"Save time category")
      this._shareService.saveBundle(postBundleData).subscribe((res:any)=>{
        if(res){
          success(res['msg'])
          this.getBundleList()
          this.bundleForm.reset()
        }
      })
    }

  }
  modifyCategoryList(){

  }
  selectedCatgoryId:any
  chooseCategory(event){
    this.selectedCatgoryId = event.target.value
    console.log(event.target.value,"This is the category")
  }
  // selectFile(eve:any){
  //   let filePath = eve.target.value.split('C:\\fakepath\\').join('')
  //   var myReader: FileReader = new FileReader();
  //   myReader.onload=(e)=>{}
  //   console.log(eve.target.value)
  //   this.bundleForm.get('imgUrl').patchValue(filePath)
  // }
  closeModal(){
    this.modalRef.close();
  }

}
