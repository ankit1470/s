import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BundleRoutingModule } from './bundle-routing.module';
import { BundleComponent } from './bundle.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CategoryListComponent } from './category-list/category-list.component';
import { CategoryAddModule } from 'src/app/modules/database/project-utility-tool/procompare-tool/acc/category-add/category-add.module';
import { CategoryListModule } from './category-list/category-list.module';


@NgModule({
  declarations: [BundleComponent],
  imports: [
    CommonModule,
    BundleRoutingModule,
    ReactiveFormsModule,
    CategoryListModule
  ]
})
export class BundleModule { }
