import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PropertiesRoutingModule } from './properties-routing.module';
import { PropertiesComponent } from './properties.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SaveLabelValueGridComponent } from './save-label-value-grid/save-label-value-grid.component';


@NgModule({
  declarations: [PropertiesComponent, SaveLabelValueGridComponent],
  imports: [
    CommonModule,
    PropertiesRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class PropertiesModule { }
