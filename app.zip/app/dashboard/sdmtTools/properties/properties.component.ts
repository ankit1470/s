import { Component, OnInit } from '@angular/core';
import { SagShareService } from 'src/app/services/sagshare.service';
import { TempPageModalComponent } from '../template-pages/temp-page-modal/temp-page-modal.component';
import { DialogService } from 'primeng/api';
import { FormBuilder, FormGroup, FormControlName } from '@angular/forms';
import { ToastService } from 'src/app/core/services/toast.service';
import { SaveLabelValueGridComponent } from './save-label-value-grid/save-label-value-grid.component';
declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var SagHeaderButton;
declare var _;
declare var ui;
declare var SagInsertImage;
declare var SagButton;
declare var circlr;
declare var SdmtGridT;
@Component({
  selector: 'app-properties',
  templateUrl: './properties.component.html',
  styleUrls: ['./properties.component.scss']
})
export class PropertiesComponent implements OnInit {
  gridData_tempmenuid: any;
  gridDynamicObj_tempmenuid: any;
  propCat: [] = []
  propGrp: [] = []
  propData: [] = []
  propGrpId: any
  propCatId: any
  controlTypeValue: any;
  optValue: [] = []
  isSelected: boolean = false
  isControlType: boolean = true
  isSaveProp = false
  controlType: [] = []
  propertiesform: FormGroup
  selectedPropGrpVal: string = ''
  selectControlVal: string = ''
  selectedPropCatVal: string = ''
 radioBtnVal:string
  constructor(
    private shareSrv: SagShareService,
    public dialogService: DialogService,
    private fb: FormBuilder,
    private toastSrv: ToastService
  ) { }

  ngOnInit() {
    this.shareSrv.getPropertiesList().subscribe((res) => {
      if (res) {
        this.propCat = res['propCat']
        this.propGrp = res['propgrp']
        this.propData = res['propData']
        this.controlType = res['fieldType']
        this.tempmenuid(this.propData)
      }
    })
    this.propertiesform = this.fb.group({
      name: [''],
      ngModel: [''],
      description: ['']
    })
  }

  ngAfterViewInit() {
    this.tempmenuid()
  }

  columnData_tempmenuid: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "Name",
      "field": "name",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Selected Class",
      "field": "selectedclasslist",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Ng Model",
      "field": "ngmodel",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "PropgrpId",
      "field": "propgrpId",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Level",
      "field": "level",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Disable",
      "field": "disable",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "PropId",
      "field": "propId",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "PropcatId",
      "field": "propcatId",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Description",
      "field": "description",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Field Type",
      "field": "fieldtype",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Option Value",
      "field": "show",
      "filter": true,
      "width": "144px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": {
        "cellValue": "",
        "visibility": true,
        "name": "Show",
        "classes": ["btn", "btn-primary", "w-70"],
        "attribute": "",
        "styles": ""
      },
    },
  ];

  rowData_tempmenuid: any = [
    {},
    {},
    {},
    {}
  ];

  tempmenuid(rowData?, colData?) {
    let self = this;

    this.gridData_tempmenuid = {
      columnDef: colData ? colData : this.columnData_tempmenuid,
      rowDef: rowData ? rowData : this.rowData_tempmenuid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,
      components: {},
      callBack: {
        "onButton_show": function (event: Event, params) {
          self.gridDynamicObj_tempmenuid.selectedRowINdex = params.rowIndex
          let selectedRow = self.gridDynamicObj_tempmenuid.getSeletedRowData();
          if (selectedRow !== null) {
            self.openPageTemplate(selectedRow.optionvalue, 'show');
          }
        },
        "onCellClick": function (ele) {
          self.ontempmenuidCellClick()
        },
        "onRowClick": function () {

          self.ontempmenuidClick()
        },
        "onRowDbleClick": function () {
          self.ontempmenuiddblClick();
        },

      }
      ,
      rowCustomHeight: 20,
    };
    let sourceDiv = document.getElementById("tempmenuid");
    this.gridDynamicObj_tempmenuid = SdmtGridT(sourceDiv, this.gridData_tempmenuid, true, true);
  }

  ontempmenuidCellClick() { }
  ontempmenuidClick() { }
  ontempmenuiddblClick() { }
  closeModal() {
    document.querySelector(".ui-dialog-titlebar-close").closest("p-dynamicdialog").remove();
  }
 
  openPageTemplate(optionValue: any, btnMode: String) {
    const ref = this.dialogService.open(TempPageModalComponent, {
      header: '                       ',
      width: '90%',
      contentStyle: { "box-shdow": "none" },
      styleClass: "validation_comp_data",
      data: {
        item: optionValue,
        buttonMode: btnMode,
      }
    });
    ref.onClose.subscribe((res) => {
      if (res) {
      }
    });
  }


  selectPropCatId(event) {
    if (event.target.value) this.propCatId = JSON.parse(event.target.value)
  }
  selectPropGrpId(event) {
    this.propGrpId = JSON.parse(event.target.value)
  }
  selectControlTypeValue(event) {
    if (event.target.value === "select" ) {
      this.isControlType = false
    }
    else  this.isControlType = true
    this.controlTypeValue = event.target.value
  }
  selectRadio(event){this.radioBtnVal=event.target.value}
  saveProperties() {
    const properties = {
      "propgrpId": this.propGrpId,
      "propcatId": this.propCatId,
      "fieldtype": this.controlTypeValue,
      "optval": this.optValue.length > 0 ? this.optValue : [{}],
      "ngmodel": this.propertiesform.value.ngModel,
      "name": this.propertiesform.value.name,
      "disable": this.radioBtnVal === "yes"?"true":"false",
      "desc": this.propertiesform.value.description
    }    
    if (properties !== null) {
      this.shareSrv.savePropertiesList(properties).subscribe((res) => {
        if (res) {
          this.toastSrv.launch_toast({
            type: 'success',
            position: 'bottom-right',
            message: res['msg']
          })
          // this.isSaveProp = true
          // this.selectedPropCatVal = ''
          // this.selectedPropGrpVal = ''
          // this.selectControlVal = ''
          // this.isSelected = false
          // this.isControlType = true
          // this.propertiesform.reset()
        } else {
          this.toastSrv.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: res['msg'],
          });
        }

      })
    }
  }
  addGrid() {
    const ref = this.dialogService.open(SaveLabelValueGridComponent, {
      header: '',
      width: '50%',
      contentStyle: { "box-shdow": "none", height: "500px" },
      styleClass: "validation_comp_data",
      data: {
        optValue: this.optValue,
        isSave: this.isSaveProp
      }
    });
    ref.onClose.subscribe((res) => {
      if (res) {
        this.isSelected = true
        this.optValue = res
      }
    })

 

  }
  resetProperties(){
     this.isSaveProp = true
     this.selectedPropCatVal = ''
     this.selectedPropGrpVal = ''
     this.selectControlVal = ''
     this.isSelected = false
     this.isControlType = true
     this.propertiesform.reset();
  }

}
