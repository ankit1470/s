import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var SagHeaderButton;
declare var _;
declare var ui;
declare var SagInsertImage;
declare var SagButton;
declare var circlr;
@Component({
  selector: 'app-save-label-value-grid',
  templateUrl: './save-label-value-grid.component.html',
  styleUrls: ['./save-label-value-grid.component.scss']
})
export class SaveLabelValueGridComponent implements OnInit {

  gridDynamicObj_: any;
  gridDynamicObj_propGrid: any;
  rowData_propGrid: any = [];

  constructor(public ref: DynamicDialogRef, public config: DynamicDialogConfig) { }

  ngOnInit() {
    if (this.config.data['isSave']) this.propGrid([])
    else{
      if (this.config.data['optValue']) {
        this.propGrid(this.config.data['optValue'])
      }else this.propGrid()
    }
  }
  columnData_propGrid: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "100px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "Label",
      "field": "label",
      "filter": true,
      "width": "250px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Value",
      "field": "value",
      "filter": true,
      "width": "250px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  propGrid(rowData?, colData?) {
    let self = this;
    this.gridDynamicObj_propGrid = {
      columnDef: colData ? colData : this.columnData_propGrid,
      rowDef: rowData ? rowData : this.rowData_propGrid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,
      components: {},
      callBack: {

        "onCellClick": function (ele) {
          $(ele).attr('contenteditable', 'true');
          self.onpropGridCellClick();
        },
        "onRowClick": function () {
          self.onpropGridClick();
        },
        "onRowDbleClick": function () {
          self.onpropGriddblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("prpgrid");
    this.gridDynamicObj_propGrid = SdmtGridT(sourceDiv, this.gridDynamicObj_propGrid, true, true);
  }
  addRowpropGrid() {
    // Get the index for the new row
    let index = this.gridDynamicObj_propGrid.sagGridObj.AllRowIndex.length;
    // Create a new row element
    let newRow = document.createElement('div');
    newRow.classList.add('row');
    newRow.id = 'row_' + index;
    // Append label column to the new row
    let label = document.createElement('div');
    label.classList.add('label');
    label.setAttribute('contenteditable', 'true');
    label.textContent = 'New Label';
    newRow.appendChild(label);
    // Append value column to the new row
    let value = document.createElement('div');
    value.classList.add('value');
    value.setAttribute('contenteditable', 'true');
    value.textContent = 'New Value';
    newRow.appendChild(value);
    this.gridDynamicObj_propGrid.addRow(index, newRow);
    this.gridDynamicObj_propGrid.rowData = newRow

  }


  deleteRowpropGrid() {
    this.getCellData()
    if (this.gridDynamicObj_propGrid.selectedRowINdex == null) {
      alert("For Delete Select Row");
    }
    else {
      this.gridDynamicObj_propGrid.deleteRow(this.gridDynamicObj_propGrid.selectedRowINdex);
      const originalArray = this.gridDynamicObj_propGrid.sagGridObj.originalRowData
      if (originalArray.length === 0) this.propGrid()
    }
  }

  onpropGridCellClick() { }

  onpropGridClick() { }

  onpropGriddblClick() { }


  getCellData() {
    const originalArray = this.gridDynamicObj_propGrid.sagGridObj.originalRowData
    // Gather information from editable cells
    let editableCells = document.querySelectorAll('div[contenteditable="true"]');
    editableCells.forEach(function (cell) {
      let rowId = cell.getAttribute("sag_g_index");
      let field = cell.getAttribute("sag_G_Key");
      let cellValue = (cell as HTMLElement).innerText;
      if (cellValue.trim() !== '') {
        let originalObject = originalArray.find(item => item.sag_G_Index == rowId);
        if (originalObject) {
          if (field === 'label') originalObject.label = cellValue;
          else originalObject.value = cellValue;
        }
      }
    });
  }

  saveGridDetails() {
    this.getCellData()
    const originalArray = this.gridDynamicObj_propGrid.sagGridObj.originalRowData
    const newArray = originalArray.map(item => {
      return {
        label: item.label,
        value: item.value,
      };
    });
    this.ref.close(newArray);
  }
}

