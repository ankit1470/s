import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SaveLabelValueGridRoutingModule } from './save-label-value-grid-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SaveLabelValueGridRoutingModule
  ]
})
export class SaveLabelValueGridModule { }
