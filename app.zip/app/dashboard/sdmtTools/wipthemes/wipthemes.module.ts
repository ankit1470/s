import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WipthemesRoutingModule } from './wipthemes-routing.module';
import { WipthemesComponent } from './wipthemes.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [WipthemesComponent],
  imports: [
    CommonModule,
    WipthemesRoutingModule,
    ReactiveFormsModule ,
    FormsModule
  ]
})
export class WipthemesModule { }
