import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DialogService } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { TempPageModalComponent } from '../template-pages/temp-page-modal/temp-page-modal.component';
import { ToastService } from 'src/app/core/services/toast.service';

declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var SagHeaderButton;
declare var _;
declare var ui;
declare var SagInsertImage;
declare var SagButton;
declare var circlr;
declare var SdmtGridT;
@Component({
  selector: 'app-wipthemes',
  templateUrl: './wipthemes.component.html',
  styleUrls: ['./wipthemes.component.scss']
})
export class WipthemesComponent implements OnInit {
  uiThemesData = []
  ctrlList: [] = []
  selectedThemeIndex: any = 0;
  themeForm: FormGroup
  ctrlId: Number
  // defaultValue: String
  constructor(
    private sagSrv: SagShareService,
    private fb: FormBuilder,
    public dialogService: DialogService,
    private toastSrv: ToastService) { }

  ngOnInit() {
    this.selectValues()
    this.themeForm = this.fb.group({
      themeName: [''],
      themeValue: [''],
      css: [''],
      device: ['']
    })
  }



  ngAfterViewInit() {
    this.workprogressgrid();
  }



  gridData_workprogressgrid: any;
  gridDynamicObj_workprogressgrid: any;

  columnData_workprogressgrid: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "Name",
      "field": "name",
      "filter": true,
      "width": "250px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "value",
      "field": "value",
      "filter": true,
      "width": "250px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "CSS",
      "field": "themecss",
      "filter": true,
      "width": "744px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      header: "STATUS",
      field: "status",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "SCREEN",
      field: "screen",
      filter: true,
      width: "100px",
      editable: "false",
      "text-align": "center",
      search: true,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      "header": "Action",
      "field": "show",
      "filter": true,
      "width": "80px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": {
        "cellValue": "",
        "visibility": true,
        "name": "Show",
        "classes": ["btn", "btn-primary", "w-70"],
        "attribute": "",
        "styles": ""
      },
    },
    {
      "header": "Action",
      "field": "update",
      "filter": true,
      "width": "80px",
      "editable": "false",
      "text-align": "left",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "cellValue": "", "visibility": true, "name": "Update", "classes": ["btn", "btn-primary", "w-70"], "attribute": "", "styles": "" },
    },
  ];

  rowData_workprogressgrid: any = [];

  workprogressgrid(rowData?, colData?) {
    let self = this;
    this.gridData_workprogressgrid = {
      columnDef: colData ? colData : this.columnData_workprogressgrid,
      rowDef: rowData ? rowData : this.rowData_workprogressgrid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {
        "onButton_show": function (ele, param) {
          self.gridDynamicObj_workprogressgrid.selectedRowINdex = param.rowIndex
          let selectedRow = self.gridDynamicObj_workprogressgrid.getSeletedRowData();
          if (selectedRow !== null) {
            self.openPageTemplate(selectedRow.themecss, 'show');
          }
        },
        "onButton_update": function (ele) {
          let setRowSelected = self.gridDynamicObj_workprogressgrid.getSeletedRowData();
          if (setRowSelected !== null) self.openPageTemplate("", 'update', setRowSelected.name, setRowSelected.themecssdetId, setRowSelected.themecssId, setRowSelected.value);
        },
        "onCellClick": function (ele) {
          self.onworkprogressgridCellClick();
        },
        "onRowClick": function () {
          self.onworkprogressgridClick();
        },
        "onRowDbleClick": function () {
          self.onworkprogressgriddblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("workprogressgrid");
    this.gridDynamicObj_workprogressgrid = SdmtGridT(sourceDiv, this.gridData_workprogressgrid, true, true);
  }

  onworkprogressgridCellClick() { }
  onworkprogressgridClick() { }
  onworkprogressgriddblClick() { }

  closeModal() {
    document.querySelector(".ui-dialog-titlebar-close").closest("p-dynamicdialog").remove();
  }
  openPageTemplate(themecss: any, btnMode: any, name?: any, themecssdetId?: any, themecssId?: any, value?: any) {
    const ref = this.dialogService.open(TempPageModalComponent, {
      header: '                       ',
      width: '90%',
      contentStyle: { "box-shdow": "none" },
      styleClass: "validation_comp_data modal-compdata",
      data: {
        item: themecss,
        buttonMode: btnMode,
        label: name,
        themecssdetId: themecssdetId,
        themecssId: themecssId,
        value: value
      }
    });
    ref.onClose.subscribe((res) => {
      if (res) { }
    });
  }

  selectValues() {
    const data = this.sagSrv.getUiThemeseData().subscribe((res) => {
      try {
        let nullObj = res['ctrlThemeList'].filter(res => !res.ctrlId);
        let valueObj = res['ctrlThemeList'].filter(res => res.ctrlId);
        let themesData = [...nullObj, ...valueObj];
        for (let i = 0; i < themesData.length; i++) {
          let duplicateStatus = false;
          for (let j = i + 1; j < themesData.length; j++) {
            if (themesData[i].ctrlId == themesData[j].ctrlId) {
              themesData[i].ctrlThemes.push(...themesData[j].ctrlThemes);
              this.uiThemesData.push(themesData[i]);
              duplicateStatus = true;
              themesData.splice(j, 1);
              j--;
              break;
            }
          }
          if (!duplicateStatus) {
            this.uiThemesData.push(themesData[i]);
          }
        }
        this.ctrlList = res['ctrlList']
        this.chooseTheme()
      } catch (error) { }
    })
  }
  chooseTheme() {
    if (Array.isArray(this.uiThemesData[this.selectedThemeIndex]['ctrlThemes'])) {
      this.workprogressgrid(this.uiThemesData[this.selectedThemeIndex]['ctrlThemes'])
    }
  }
  selectId(event) {
    this.selectedThemeIndex = JSON.parse(event.target.value)
  }
  selectCtrlId(event) {
    this.ctrlId = JSON.parse(event.target.value)
  }
  saveTheme() {
    if (this.themeForm.valid) {
      const uiTheme = {
        "ctrlId": this.ctrlId,
        "label": this.themeForm.value.themeName,
        "value": this.themeForm.value.themeValue,
        "css": this.themeForm.value.css,
        "device": this.themeForm.value.device,
      }
      this.sagSrv.savetUiThemeseData(uiTheme).subscribe((res) => {
        if (res) {
          let result = this.sagSrv.showToast(res);
          if (result) {
            this.themeForm.reset()
          }
        }
      })
    }
  }



}
