import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { LoginComponent } from "../modules/auth/login/login.component";
import { DashboardComponent } from "./dashboard.component";
import { ExcelImportExportViewComponent } from './import-export-mapping/excel-import-export-view/excel-import-export-view.component';
import { FormJsonImportViewComponent } from './import-export-mapping/form-json-import-view/form-json-import-view.component';

const routes: Routes = [
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full",
  },
  {
    path: "import-export-view",
    component: ExcelImportExportViewComponent,
  },
  {
    path: "form-json-import-view",
    component: FormJsonImportViewComponent,
  },
  {
    path: "dashboard",
    component: DashboardComponent,
    

    children: [
      // {
      //   path: "sagstudiodashboard",
      //   loadChildren: () =>
      //     import("../dashboard/sagstudio-dashboard/sagstudio-dashboard.module").then(
      //       (mod) => mod.SagstudioDashboardModule
      //     ),
      // },

      {
        path: "sagstudiodashboard",
        data: {
          preload: true, // TO ADD THIS MODULE AS PRELOADED STRATEGY
        },
        loadChildren: () =>
          import("../dashboard/sagstudio-dashboard/sagstudio-dashboard.module").then(
            (mod) => mod.SagstudioDashboardModule
          ),
      },
      {
        path: "studioprojectlist",
        loadChildren: () =>
          import("../dashboard/studio-project-list/studio-project-list.module").then(
            (mod) => mod.StudioProjectListModule
          ),
      },
      {
        path: "UIbuilder",
        data: {
          preload: true, // TO ADD THIS MODULE AS PRELOADED STRATEGY
        },
        loadChildren: () =>
          import("../modules/sag-studio/sag-studio.module").then(
            (mod) => mod.SagStudioModule
          ),
      },
      {
        path: "projectConfig",
        loadChildren: () =>
          import(
            "../modules/sag-studio/project-explorer/project-config/project-config.module"
          ).then((mod) => mod.ProjectConfigModule),
      },
      {
        path: "database",
        data: { kind: "database" },
        loadChildren: () =>
          import("../modules/database/database.module").then(
            (mod) => mod.DatabaseModule
          ),
      },
      
    
      // {
      //   path: "sageditor",
      //   loadChildren: () =>
      //     import("../dashboard/sageditor/sageditor.module").then(
      //       (mod) => mod.SageditorModule
      //     ),
      // },
      // {
      //   path : "pmt",
      //   loadChildren: () => import("../modules/database/project-utility-tool/procompare-tool/pmt/pmt.module").then(module => module.PmtModule)
      // },
    ],
  },

  {
    path: "login",
    component: LoginComponent,
  },
  {
    path: "dashboard/git-permission",
    loadChildren: () =>
      import("./git-permission/git-permission.module").then(
        (m) => m.GitPermissionModule
      ),
  },
  { path: 'reporting', loadChildren: () => import('./reporting/reporting.module').then(m => m.ReportingModule) },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule { }
