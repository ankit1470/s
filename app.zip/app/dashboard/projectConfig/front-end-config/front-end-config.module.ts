import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FrontEndConfigRoutingModule } from './front-end-config-routing.module';
import { FrontEndConfigComponent } from './front-end-config.component';


@NgModule({
  declarations: [FrontEndConfigComponent],
  imports: [
    CommonModule,
    FrontEndConfigRoutingModule
  ],
  exports:[FrontEndConfigComponent]
})
export class FrontEndConfigModule { }
