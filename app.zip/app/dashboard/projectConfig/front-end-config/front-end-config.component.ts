import { Component, OnInit, VERSION } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';

@Component({
  selector: 'app-front-end-config',
  templateUrl: './front-end-config.component.html',
  styleUrls: ['./front-end-config.component.scss']
})
export class FrontEndConfigComponent implements OnInit {

  frontEndRowData: any
  angularVersion : any;
  constructor(public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig) {
      this.frontEndRowData = this.config.data.rowDataElment;
      console.log(this.frontEndRowData)
     }

  ngOnInit() {
    
    this.angularVersion = VERSION.full;
  }
  

}
