import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FrontEndConfigComponent } from './front-end-config.component';


const routes: Routes = [
  {
    path : "",
    component : FrontEndConfigComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FrontEndConfigRoutingModule { }
