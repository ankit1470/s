import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { forkJoin } from 'rxjs';
import { GenerateHtmlService } from 'src/app/services/sagStudio/generate-html.service';
import { ToastService } from 'src/app/core/services/toast.service';
declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;


@Component({
  selector: 'app-git-svn',
  templateUrl: './git-svn.component.html',
  styleUrls: ['./git-svn.component.scss'],
  providers: [DialogService]
})
export class GitSvnComponent implements OnInit {
  importNewProjectForm: FormGroup;
  allProjectList: any;
  getAllProjectsData: any;
  forkJoinParams = []
  forkJoinParams1 = []
  getDataJson: any;
  selectRowData: any;
  checkProject = '';
  checkProjectSVN = '';
  repository: any;
  getUserWiseLocalProjectPathResponce: any;
  saveUserWiseLocalProjectPathresponce: any;
  repoPrjExist: boolean;
  checkgitFolder: boolean;
  checksvnFolder: boolean;
  afterCloneGitPrj: boolean = false;
  afterCloneSvnPrj: boolean = false;
  disAppearAfterTakingClone: boolean = true;
  disAppearAfterTakingCheckOut: boolean = true;
  techfgrp_id:any

  constructor(
    private _formBuilder: FormBuilder,
    public _sagStudioService: SagStudioService,
    private dbcomparetoolService: ProcomparetoolService,
    private procomparetoolService: ProcomparetoolService,
    private shareService: SagShareService,
    private cdRef: ChangeDetectorRef,
    private formbuilder: FormBuilder,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public modalRef: DynamicDialogRef,
    private _generateHtmlService: GenerateHtmlService,
    public toast: ToastService
  ) {
    this.selectRowData = this.config.data.rowdata

  }
  ngOnInit() {
    this.initializeForm();
    /* this.getprojectinfo(); */
    this.getAllProjectFrontBackend();
    const sessionLogindata = JSON.parse(sessionStorage.getItem('loginFormValue'));
    this.importNewProjectForm.get('userName').patchValue(sessionLogindata.username);
    this.importNewProjectForm.get('password').patchValue(sessionLogindata.password);
    if (this.config.data.rowdata.projectOnRepository) {
      this.repoPrjExist = true;
    } else {
      this.repoPrjExist = false;
    }
    this.checkPrjExistOrNot();
    this.checkSvnPrjExistOrNot();
    this.getFrontendTechnologyGroup(this.selectRowData.projectId.toString())
  }

  getFrontendTechnologyGroup(projectId){
    this.dbcomparetoolService.getFrontendTechnologyGroup(projectId).subscribe((res)=>{
    this.techfgrp_id = res['techfgrp_id'].toString();
    })
  }

  initializeForm() {
    this.importNewProjectForm = this._formBuilder.group({
      repositoryPath: ['', Validators.compose([Validators.required])],
      gitCloneProjectpath: ['', Validators.compose([Validators.required])],
      svnProjectpath: ['', Validators.compose([Validators.required])],
      repositoryPathGit: ['', Validators.compose([Validators.required])],
      userName: ['', Validators.compose([Validators.required])],
      password: ['', Validators.compose([Validators.required])],
    });
  }
  getprojectinfo() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.getprojectinfo({ userId: 1 }).subscribe(
      (response: any) => {
        if (response) {
          this.allProjectList = response;
        }
      }
    );
  }
  /* onSelectProject() {
    let item = this.allProjectList.find(el => el.url == this.importNewProjectForm.get('repositoryPath').value);
    this.importNewProjectForm.get('projectpath').patchValue(item.pLocalPath);

  } */
  async gitCloneClick() {
    const reqObj = {
      "projectName": this.importNewProjectForm.get('repositoryPath').value,
      "userName": this.importNewProjectForm.get('userName').value,
    }
    this.shareService.loading++;
    this.dbcomparetoolService.getProjectAlreadyAccessMemberList(reqObj).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response["status"] == 200) {
          this.CloneClick();
        }
        else if (response["status"] == 500) {
          alerts(response.message)
        }
        else if (response["status"] == 409) {
          alerts(response.message)
        }
      }, error => {
        this.shareService.loading--;
        alerts("Error While Fetching")
      }
    );


  }


  CloneClick() {
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    var matchingStr = this.importNewProjectForm.value.gitCloneProjectpath.slice(0, this.importNewProjectForm.value.gitCloneProjectpath.lastIndexOf("/"));
    const postdata = {
      "projectpath": this.importNewProjectForm.get('gitCloneProjectpath').value,
      /* "userName": sessionStoragedata.username,
      "password": sessionStoragedata.password, */
      //"projectpath": matchingStr,
      "userName": this.importNewProjectForm.get('userName').value,
      "password": this.importNewProjectForm.get('password').value,
      "repositoryPath": this.importNewProjectForm.get('repositoryPathGit').value,
      "userId": sessionStoragedata.data.clientInfo.usrId.toString(),
      "projectId": this.selectRowData.projectId.toString()
    }
    if ((postdata.repositoryPath != '' && postdata.userName != '' && postdata.password != '') &&
      (postdata.repositoryPath != null && postdata.userName != null && postdata.password != null)) {
      this.shareService.loading++;
      this.dbcomparetoolService.gitprojectclone(postdata).subscribe(
        (response: any) => {
          if (response["status"] == 200) {
            this.shareService.loading--;
            success("successFully Clone !!!...");
            this.checkPrjExistOrNot();
            this.disAppearAfterTakingClone = false
          }
          else if (response["status"] == 500) {
            this.shareService.loading--;
            alerts(response.msg)
          }

          // if (response.successfully) {

          // this.toast.launch_toast({
          //   type: 'success',
          //   position: 'bottom-right',
          //   message: 'successFully Clone !!!...',
          // });
          // }
          // else if (response['status'] == 500) {
          //   this.toast.launch_toast({
          //     type: 'alert',
          //     position: 'bottom-right',
          //     message: response['msg'],
          //   });
          // }
        },
        err => {
          this.shareService.loading--;
          console.error('err response');
        }
      );
    }
    else {
      alerts("Please Enter Required  Fields !!!")
      // this.toast.launch_toast({
      //   type: 'alert',
      //   position: 'bottom-right',
      //   message: 'Please Enter Required  Fields !!!',
      // });
    }

  }

  regenEnJson_Click() {
    const __prjDetails = this.shareService.getDataprotool("selectedProjectChooseData");
    const reqObj = {
      "projectId": __prjDetails['projectId'],
      "projectPath": __prjDetails['awspace'].replace('/' + __prjDetails['projectname'], ''),
      "projectName": __prjDetails['projectname']
    }
    this.procomparetoolService.regenEnJson(reqObj).subscribe(
      (response: any) => {
        if (response["status"] == "success") {
          success(response['message']);
        }
        else if (response["status"] == "failure") {
          alerts(response['message'])
        }
      }, error => {
        alerts("Error While right")
      }
    );
  }
  async svnCheckOutClick() {
    var matchingStr = this.importNewProjectForm.value.svnProjectpath.slice(0, this.importNewProjectForm.value.svnProjectpath.lastIndexOf("/"));
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    const projectDetails = this.shareService.getDataprotool("selectedProjectChooseData");
    const postdata = {
      //"checkoutPath": this.importNewProjectForm.get('projectpath').value,
      "checkoutPath": matchingStr,
      /* "username": sessionStoragedata.username,
      "password": sessionStoragedata.password, */
      "username": this.importNewProjectForm.get('userName').value,
      "password": this.importNewProjectForm.get('password').value,
      "repositoryPath": this.importNewProjectForm.get('repositoryPathGit').value,
      "userId": userid,
      "projectPath": projectDetails.jwspace,
      "projectId": projectDetails.projectId,
      "selectedPath": projectDetails.jwspace,
    }
    this.shareService.loading++;
    if ((postdata.repositoryPath != '' && postdata.username != '' && postdata.password != '') &&
      (postdata.repositoryPath != null && postdata.username != null && postdata.password != null)) {
      this.dbcomparetoolService.svnProjectChackOut(postdata).subscribe(
        (response: any) => {
          this.shareService.loading--;
          if (response['status'] == 200) {
            success("successfully CheckOut !!!...")
            // this.toast.launch_toast({
            //   type: 'success',
            //   position: 'bottom-right',
            //   message: 'successfully CheckOut !!!...',
            // });
            this.checkSvnPrjExistOrNot();
            this.disAppearAfterTakingCheckOut = false;
          }
          else if (response['status'] == 500) {
            alerts(response['message'])
            // this.toast.launch_toast({
            //   type: 'alert',
            //   position: 'bottom-right',
            //   message: response['msg'],
            // });
          }
        }
      );
      err => {
        this.shareService.loading--;
        console.error('err response');
      }

    } else {
      alerts("Please Enter Required  Fields !!!");
      // this.toast.launch_toast({
      //   type: 'alert',
      //   position: 'bottom-right',
      //   message: 'Please Enter Required  Fields !!!',
      // });
    }

  }

  async getAllProjectFrontBackend() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId
    this.shareService.loading++;
    await this.dbcomparetoolService.AllProjectFrontBackend(userid).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response) {
          this.getAllProjectsData = response["data"];
          // this.allProjectForm.get('projectName').patchValue(this.getAllProjects[0].projectId);
          this.repository = this.getAllProjectsData.find(ele => ele.projectId == this.selectRowData.projectId);

          if ((this.selectRowData.awspace && this.selectRowData.awspace.length > 1)
            && (this.selectRowData.jwspace && this.selectRowData.jwspace.length > 1)) {
            this.checkProject = 'gitClone';
            const ele = document.getElementById('Git') as HTMLInputElement;
            ele.checked = true;
            this.importNewProjectForm.get('gitCloneProjectpath').patchValue(this.selectRowData.awspace);
            this.importNewProjectForm.get('repositoryPath').patchValue(this.selectRowData.projectname);
            this.importNewProjectForm.get('repositoryPathGit').patchValue(this.repository.projectGitPath);
          } else if (this.selectRowData.awspace == null || this.selectRowData.awspace == '') {
            const ele = document.getElementById('Svn') as HTMLInputElement;
            ele.checked = true;
            const eleGit = document.getElementById('Git') as HTMLInputElement;
            eleGit.disabled = true;
            this.checkProjectSVN = 'svnCheckOut';
            this.importNewProjectForm.get('svnProjectpath').patchValue(this.selectRowData.jwspace);
            this.importNewProjectForm.get('repositoryPath').patchValue(this.selectRowData.projectname);
            this.importNewProjectForm.get('repositoryPathGit').patchValue(this.repository.projectSvnPath);
          } else if (this.selectRowData.jwspace == null || this.selectRowData.jwspace == '') {
            const ele = document.getElementById('Git') as HTMLInputElement;
            ele.checked = true;
            const eleGit = document.getElementById('Svn') as HTMLInputElement;
            eleGit.disabled = true;
            this.checkProject = 'gitClone';
            this.importNewProjectForm.get('gitCloneProjectpath').patchValue(this.selectRowData.awspace);
            this.importNewProjectForm.get('repositoryPath').patchValue(this.selectRowData.projectname);
            this.importNewProjectForm.get('repositoryPathGit').patchValue(this.repository.projectGitPath);
          }

        }
      },
      err => {
        this.shareService.loading--;
        console.error('err response');
      }
    );
  }
  /********* change by @ balshankar **********/
  changeProjectClone(event, val) {
    if (val == 'git') {
      this.checkProject = 'gitClone';
      this.importNewProjectForm.get('gitCloneProjectpath').patchValue(this.selectRowData.awspace);
      this.importNewProjectForm.get('repositoryPath').patchValue(this.selectRowData.projectname);
      this.importNewProjectForm.get('repositoryPathGit').patchValue(this.repository.projectGitPath);
      this.checkProjectSVN = '';
    } else {
      this.checkProjectSVN = 'svnCheckOut';
      this.importNewProjectForm.get('svnProjectpath').patchValue(this.selectRowData.jwspace);
      this.importNewProjectForm.get('repositoryPath').patchValue(this.selectRowData.projectname);
      this.importNewProjectForm.get('repositoryPathGit').patchValue(this.repository.projectSvnPath);
      this.checkProject = '';
    }
  }
  /********* Write Angular Project **********/
  // async writeAngularProject() {
  //   let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
  //   const postData = {
  //     projectId: selectedObj.projectname,
  //     fileId: selectedObj.projectname,
  //   }
  //   this.shareService.loading++;
  //   /* var matchingStr = this.importNewProjectForm.value.gitCloneProjectpath.slice(0, this.importNewProjectForm.value.gitCloneProjectpath.lastIndexOf("/"));
  //   let resp = await this.dbcomparetoolService.checkProjectPath({'projectPath': matchingStr}).toPromise(); */
  //   let resp = await this.dbcomparetoolService.checkProjectPath({ 'projectPath': this.importNewProjectForm.value.gitCloneProjectpath }).toPromise();
  //   if (resp['status'] == true) {
  //     this.dbcomparetoolService.GetsaveJsonData(postData).subscribe(
  //       async (response: any) => {
  //         if (response) {
  //           //this.saveUserWiseLocalProjectPath() // database update url
  //           this.getDataJson = response['data'];
  //           this.forkJoinParams = [];
  //           const getJsonDataRec = JSON.parse(response['data'].fileJson);
  //           await this.recursiveFun(getJsonDataRec, selectedObj.projectname, selectedObj.awspace);
  //           this._sagStudioService.sagWorkSpace.projectExplorerTree[0].children = await JSON.parse(this.getDataJson.fileJson);
  //           this.shareService.setDataprotool("sagStudioCsaveJsonData", this.getDataJson.fileJson);
  //           this.shareService.setDataprotool("sagStudioCExplorerFiles", this._sagStudioService.sagWorkSpace.projectExplorerTree[0].children);
  //           /*** Note : Static Project id as of now .. Later It will change*/
  //           this._sagStudioService.currentActiveProject = await this._sagStudioService.sagWorkSpace.projectList.find(item => item.id == 'defaultProject1618079400000');
  //           let resArr = await forkJoin(this.forkJoinParams).toPromise();
  //           this._sagStudioService.currentActiveProject.subDataArray = [];
  //           resArr.forEach(item => {
  //             if (item['data'] && item['data'].fileJson) {
  //               this._sagStudioService.currentActiveProject.subDataArray.push(JSON.parse(item['data'].fileJson));
  //             }
  //           });
  //           const wait = await this._generateHtmlService.generateDownloadJsonUri('writeProject');
  //         }
  //         //--
  //         this.shareService.loading--;
  //         this.toast.launch_toast({
  //           type: 'success',
  //           position: 'bottom-right',
  //           message: 'Write Successfully !!!...',
  //         });
  //       },
  //       (err) => {
  //         this.shareService.loading--;
  //         console.error('err response');
  //       }
  //     );
  //     this._sagStudioService.resetFileList();
  //     this._sagStudioService.getFilesList(this._sagStudioService.sagWorkSpace.projectExplorerTree);
  //   } else {
  //     this.shareService.loading--;
  //     this.toast.launch_toast({
  //       type: 'alert',
  //       position: 'bottom-right',
  //       message: 'There is already a project in the specified directory !!!...',
  //     });
  //   }
  //   this.modalRef.close(true);
  // }
  recursiveFun(getJsonDataRec, projName, projPath) {
    let self = this;
    getJsonDataRec.forEach((element) => {
      if (element.children.length > 0) {
        element['pLocalPath'] = `${projPath}/${element.projectPath}`;
        const param = {
          projectId: projName,
          fileId: element['matchableId'],
        }
        self.forkJoinParams.push(this.dbcomparetoolService.GetsaveJsonData(param));
        self.recursiveFun(element.children, projName, projPath);
      }
      else {
        element['pLocalPath'] = `${projPath}/${element.projectPath}`;
        const param = {
          projectId: projName,
          fileId: element['matchableId'],
        }
        self.forkJoinParams.push(this.dbcomparetoolService.GetsaveJsonData(param));
      }
    });
  }
  /********* Write java Project **********/
  async WriteJavaProjectClick() {
    const selectProjectPath = this.shareService.getDataprotool("selectedProjectChooseData");

    this.shareService.loading++;
    /* if (resp['status'] == true) { */
    var matchingStr = this.importNewProjectForm.value.svnProjectpath.slice(0, this.importNewProjectForm.value.svnProjectpath.lastIndexOf("/"));
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    if (sessionStoragedatauserId != undefined) {
      let userId = sessionStoragedatauserId.data.clientInfo.usrId;
      const postData = {
        projectName: selectProjectPath.projectname,
        path: this.importNewProjectForm.value.svnProjectpath,
        projectId: selectProjectPath.projectId,
        userId: userId,
        //path: selectProjectPath.jwspace
      }
      this.dbcomparetoolService.javaProjectCreate(postData).subscribe(
        (response: any) => {
          this.shareService.loading--;
          //this.saveUserWiseLocalProjectPath()
          if (response) {
            let status = response["data"];
            success("Write Successfully !!!...");
            // this.toast.launch_toast({
            //   type: 'success',
            //   position: 'bottom-right',
            //   message: 'Write Successfully !!!...',
            // });
          }
        },
        err => {
          this.shareService.loading--;
          console.error('err response');
        }
      );
    }


    /* }  else {
       this.shareService.loading--;
       this.toast.launch_toast({
         type: 'alert',
         position: 'bottom-right',
         message: 'There is already a project in the specified directory !!!...',
       });
     } */
    this.modalRef.close(true);
  }
  saveUserWiseLocalProjectPath() {
    let posttdata;
    /* var svnMatchingStr = this.importNewProjectForm.value.svnProjectpath.slice(0, this.importNewProjectForm.value.svnProjectpath.lastIndexOf("/"));
    var gitMatchingStr = this.importNewProjectForm.value.gitCloneProjectpath.slice(0, this.importNewProjectForm.value.gitCloneProjectpath.lastIndexOf("/")); */
    var svnMatchingStr = this.selectRowData.jwspace.slice(0, this.selectRowData.jwspace.lastIndexOf("/"));
    var gitMatchingStr = this.selectRowData.awspace.slice(0, this.selectRowData.awspace.lastIndexOf("/"));

    if (this.checkProject == 'gitClone') {
      const postData = [{
        "projectname": this.importNewProjectForm.value.repositoryPath,
        "jwspace": svnMatchingStr,
        "awspace": gitMatchingStr,
        "projectId": this.selectRowData.projectId,
        "usrprojId": this.selectRowData.usrprojId
      }];
      posttdata = { data: postData };
    } else {
      const postData = [{
        "projectname": this.importNewProjectForm.value.repositoryPath,
        "jwspace": svnMatchingStr,
        "awspace": gitMatchingStr,
        "projectId": this.selectRowData.projectId,
        "usrprojId": this.selectRowData.usrprojId
      }];
      posttdata = { data: postData };
    }
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.saveUserWiseLocalProjectPath(userId, posttdata).subscribe(
      (response: any) => {
        if (response['status'] == 200) {
          success("Successfully Updated !!!");
          // this.toast.launch_toast({
          //   type: 'success',
          //   position: 'bottom-right',
          //   message: 'Successfully Updated !!!',
          // });
          this.getUserWiseLocalProjectPath();
          this.saveUserWiseLocalProjectPathresponce = response['data']
        }
        else if (response['status'] == 406) {
          alerts(response['message']);
          // this.toast.launch_toast({
          //   type: 'alert',
          //   position: 'bottom-right',
          //   message: response['message'],
          // });
        }
      }
    );
  }

  getUserWiseLocalProjectPath() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
      (response: any) => {
        if (response) {
          this.getUserWiseLocalProjectPathResponce = response['data']
          // this.SagGridChooseProj(this.getUserWiseLocalProjectPathResponce)
          this.shareService.setDataprotool("getUserWiseLocalProjectPathResponce", response['data']);
        }
      }
    );
  }

  closeModel() {
    this.modalRef.close(true);
  }

  /***************************************************************************************************
   * parsed code here
   */ //save-angular-project
  async writeAngularProject() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId
    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    const postData = {
      destpath: selectedObj.awspace,
      projectname: selectedObj.projectname,
      projectId: selectedObj.projectId,
      userId: userId,
      techfgrp_id:this.techfgrp_id
    }//get-loadproject-json
    this.shareService.loading++;
    let resp = await this.dbcomparetoolService.writeNgProject(postData).toPromise();
    if (resp['status'] == 'success') {
      success("Successfully Write Your Project !!!");
      this.regenEnJson_Click();
      this.validationJsonWrite();
      this.regenImgJson_Click();
      // this.toast.launch_toast({
      //   type: 'success',
      //   position: 'bottom-right',
      //   message: 'Successfully Cloned Your Project !!!',
      // });
      // this.setPrjVersionObject(postData);
      this.setRepositoryInfoObject(postData)
      this.shareService.loading--;
    }
    else {
      this.shareService.loading--;
      alerts("There is already a project in the specified directory !!!...");
      // this.toast.launch_toast({
      //   type: 'alert',
      //   position: 'bottom-right',
      //   message: 'There is already a project in the specified directory !!!...',
      // });
    }
    this.modalRef.close(true);
  }
  async regenImgJson_Click(){
    const __prjDetails = this.shareService.getDataprotool("selectedProjectChooseData");
    let valwritePost = {
      "projectId"   : __prjDetails['projectId'] ,
      "projectPath" : __prjDetails.awspace.split(`/${__prjDetails['projectname']}`).join('') ,
      "projectName" : __prjDetails['projectname']
    }
    this.shareService.regen_Img_Json(valwritePost).subscribe(res => { });

  }
  async validationJsonWrite(){
    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    let writePost = {
      "projectId":selectedObj.projectId ,
      "destpath": selectedObj.awspace
    } 
    this.shareService.writevalidationJson(writePost).subscribe(res => { });
    //globalmsgList en json file write
    let valwritePost = {
      "projectId": selectedObj.projectId,
      "projectPath": selectedObj.awspace
    }
    this.shareService.writeValidationMssg(valwritePost).subscribe(res => { });

  }
  setPrjVersionObject(projectInfo) {
    if (projectInfo) {
      let data = {
        "projectPath": projectInfo.destpath ? projectInfo.destpath + `/projectVersion.json` : "",
        "confobj": JSON.parse(JSON.stringify(this._sagStudioService.versionControlInfo[0])),
      }
      this.shareService.savePrjConfObject(data).subscribe((res) => {
      });
    }
  }
  setRepositoryInfoObject(projectInfo) {
    if (projectInfo) {
      let repoInfoObj = {
        'projectName': projectInfo.projectname,
        'projectOnRepository': this.repoPrjExist,
      }
      let data = {
        "projectPath": projectInfo.destpath ? projectInfo.destpath + `/repositoryInfo.json` : "",
        "confobj": repoInfoObj,
      }
      this.shareService.savePrjConfObject(data).subscribe((res) => {
      });
    }
  }
  checkPrjExistOrNot() {
    const prj_Details = this.shareService.getDataprotool("selectedProjectChooseData");
    this.dbcomparetoolService.checkProjectPath({ 'projectPath': prj_Details.awspace }).subscribe((res) => {
      if (res) {
        this.checkgitFolder = res['status']
        if (res['count'] == '1') {
          this.afterCloneGitPrj = true;
        } else if (res['count'] == 'N') {
          this.regenEnJson_Click();
          this.afterCloneGitPrj = false;
        }
      }
    });

  }
  checkSvnPrjExistOrNot() {
    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    this.dbcomparetoolService.checkProjectPath({ 'projectPath': selectedObj.jwspace }).subscribe((res) => {
      if (res) {
        this.checksvnFolder = res['status']
        if (res['count'] == '1') {
          this.afterCloneSvnPrj = true;
        } else {
          this.afterCloneSvnPrj = false;
        }
      }
    });

  }
}
