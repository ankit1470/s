import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GitSvnRoutingModule } from './git-svn-routing.module';
import { GitSvnComponent } from './git-svn.component';
import { SharedModule } from 'src/app/core/shared/shared.module';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [GitSvnComponent],
  imports: [
    CommonModule,
    GitSvnRoutingModule,
    SharedModule,
    FormsModule, 
  ]
})
export class GitSvnModule { }
