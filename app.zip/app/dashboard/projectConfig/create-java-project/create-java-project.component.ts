/**
 * @author P A N K A J   S I N G H
 * @var  this is create java project 
 */


 import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
 import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
 import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
 import { SagShareService } from 'src/app/services/sagshare.service';
 import { FormBuilder, FormGroup, Validators } from '@angular/forms';
 import { DialogService, DynamicDialogRef } from 'primeng/api';
 
 declare var SagDatePicker;
 declare function alerts(m): any;
 declare function success(m): any;
 declare var sagGrid;
 declare var SagInputText;
 declare var SagCheckBox;
 declare var setGridHight;
 declare var SagGridMP;
 declare var SagGridMPT;
 declare var $: any;
 declare var ButtonComponent;
 declare var headerCheckBox;
 declare var SagDynamicComp;
 declare var SagSelectBox;
 declare var headerSelectBox;
 declare var SagToolTip;
 declare var _;
 declare var ui;
@Component({
  selector: 'app-create-java-project',
  templateUrl: './create-java-project.component.html',
  styleUrls: ['./create-java-project.component.scss']
})

export class CreateJavaProjectComponent implements OnInit {

  importNewProjectForm: FormGroup;
  allProjectList: any;
  getAllProjectsData: any;

  constructor(
    private _formBuilder: FormBuilder,
    public _sagStudioService: SagStudioService,
    private dbcomparetoolService: ProcomparetoolService,
    private shareService: SagShareService,
    private cdRef: ChangeDetectorRef,
    private formbuilder: FormBuilder,
    public dialogService: DialogService,
    public modalRef: DynamicDialogRef
  ) {

  }
  ngOnInit() {
    this.initializeForm();
    this.getprojectinfo();
    this.getAllProjectFrontBackend();
    const sessionLogindata = JSON.parse(sessionStorage.getItem('loginFormValue'));
    this.importNewProjectForm.get('userName').patchValue(sessionLogindata.username);
    this.importNewProjectForm.get('password').patchValue(sessionLogindata.password);
  }


  initializeForm() {
    this.importNewProjectForm = this._formBuilder.group({
      repositoryPath: ['', Validators.compose([Validators.required])],
      projectpath: ['', Validators.compose([Validators.required])],
      repositoryPathGit: ['', Validators.compose([Validators.required])],
      userName: ['', Validators.compose([Validators.required])],
      password: ['', Validators.compose([Validators.required])], 
    });
  }

  getprojectinfo() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.getprojectinfo({userId: 1}).subscribe(
      (response: any) => {
        if (response) {
          this.allProjectList = response;
        }
      }
    );
  }

  onSelectProject(){
    let item = this.allProjectList.find(el => el.url == this.importNewProjectForm.get('repositoryPath').value);
    this.importNewProjectForm.get('projectpath').patchValue(item.pLocalPath);
  }

  gitCloneClick() {
    
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'))
    const postdata = {
      // this.addFileChackBoxData.map((ele)=> ele.path).toString()
      "projectpath": this.importNewProjectForm.get('projectpath').value,
      "userName": sessionStoragedata.username,
      "password": sessionStoragedata.password,
      "repositoryPath":  this.importNewProjectForm.get('repositoryPathGit').value,
    }
    if(this.importNewProjectForm.valid){
      this.shareService.loading++;
    this.dbcomparetoolService.gitprojectclone(postdata).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response) {
          success('successFully Clone');
        }
        else if (response['status'] == 500) {
          alerts(response['msg']);
        }
      },
      err => {
        this.shareService.loading--;

        console.error('err response');
      }
    );
  }
  else{
    alerts('Please first form Fill')
  }
 

  }

  getAllProjectFrontBackend() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId
    this.shareService.loading++;
    this.dbcomparetoolService.AllProjectFrontBackend(userid).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response) {
          this.getAllProjectsData = response["data"];
          // this.allProjectForm.get('projectName').patchValue(this.getAllProjects[0].projectId);
        }
      },
      err => {
        this.shareService.loading--;

        console.error('err response');
      }
    );

  }

}

