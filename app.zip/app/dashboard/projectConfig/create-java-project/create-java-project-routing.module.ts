import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateJavaProjectComponent } from './create-java-project.component';


const routes: Routes = [
  {
    path:"",
    component:CreateJavaProjectComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreateJavaProjectRoutingModule { }
