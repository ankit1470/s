import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateJavaProjectRoutingModule } from './create-java-project-routing.module';
import { CreateJavaProjectComponent } from './create-java-project.component';
import { SharedModule } from 'src/app/core/shared/shared.module';


@NgModule({
  declarations: [ CreateJavaProjectComponent],
  imports: [
    CommonModule,
    CreateJavaProjectRoutingModule,
    SharedModule, 
  ],
  exports:[CreateJavaProjectComponent]
})
export class CreateJavaProjectModule { }
