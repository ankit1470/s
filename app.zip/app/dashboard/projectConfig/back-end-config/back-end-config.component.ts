import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-back-end-config',
  templateUrl: './back-end-config.component.html',
  styleUrls: ['./back-end-config.component.scss']
})
export class BackEndConfigComponent implements OnInit {
  backEndConfigForm: FormGroup;
  constructor(
    public config: DynamicDialogConfig,
    public formBuilder: FormBuilder,
    private modalRef: DynamicDialogRef
  ) {
    this.backEndConfigForm = this.formBuilder.group({
      projectname: [''],
      technology: ['java'],
      version: ['java8'],

    });

  }

  ngOnInit() {
    this.backEndConfigForm.patchValue(this.config.data);

  }

  save() {
    this.modalRef.close(true);
  }
  cancel() {
    this.modalRef.close(false);
  }



}
