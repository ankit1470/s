import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BackEndConfigComponent } from './back-end-config.component';


const routes: Routes = [
  {
    path : "",
    component : BackEndConfigComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BackEndConfigRoutingModule { }
