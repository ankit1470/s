import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BackEndConfigRoutingModule } from './back-end-config-routing.module';
import { BackEndConfigComponent } from './back-end-config.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/core/shared/shared.module';


@NgModule({
  declarations: [BackEndConfigComponent],
  imports: [
    CommonModule,
    BackEndConfigRoutingModule,
    SharedModule
  ], exports: [BackEndConfigComponent]
})
export class BackEndConfigModule { }
