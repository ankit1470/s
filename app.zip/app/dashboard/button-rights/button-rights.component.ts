import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DialogService } from 'primeng/api';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: 'app-button-rights',
  templateUrl: './button-rights.component.html',
  styleUrls: ['./button-rights.component.scss']
})
export class ButtonRightsComponent implements OnInit {
  buttonRightsObj: any;
  MenuJsonData: any;
  btnjsonData: any;
  userLists = []
  constructor(private formbuilder: FormBuilder,
    public dialogService: DialogService,
    public shareService: SagShareService,
    private buttonRightsServices: ProcomparetoolService) { }

  ngOnInit() {
    this.__getPageBtnJson();
    this._getUsersList();
  }
  __getPageBtnJson() {
    const _Value = this.shareService.getAccessRights();
    const __prjDetails = this.shareService.getDataprotool("selectedProjectChooseData");
    if (__prjDetails) {
      let reqJson = {
        "projectName": __prjDetails['projectname']
      };
      this.buttonRightsServices.getPageBtnJson(reqJson).subscribe(
        (response: any) => {
          if (response) {
            this.btnjsonData = response['btnjson'];
            let mappedResponse = this.btnjsonData.map(_item => {
              let newitem = _item;
              newitem['Kdetails'] = _item['children'];
              if (_item.children !== undefined) {
                _item.children
                this.__recursiveFunction(_item.children);
              }
              return newitem;
            })
            this.shareService.setDataprotool("projectMenuTreeFiles", this.btnjsonData);
            this.buttonRightsGrid(mappedResponse);
          }
        }
      );
    }
  }
  __recursiveFunction(param) {
    param.map(item => {
      let __newItem = item;
      __newItem['Kdetails'] = item['children'];
      if (item.children) {
        this.__recursiveFunction(item.children)
      }
      return __newItem
    })
  }
  _getUsersList() {
    this.buttonRightsServices.getUsrList().subscribe(
      (response: any) => {
        this.userLists = response.map(_item => {
          let _newItem = _item;
          _newItem['label'] = _item.userCode,
            _newItem['value'] = _item.userId
          return _newItem
        })
      }
    )
  }
  btnRights_Click() {
    const checkBoxValues = this.buttonRightsObj['sagGridObj']['checkselectArr']
    console.log(checkBoxValues)
  }
  ShowBtnRights_Click() {
    this.__getPageBtnJson();
  }
  buttonRightsGrid(rowsData) {
    const sourceDiv = document.getElementById("buttonRightsGridId");
    const columns = [


      {
        "header": "Sr.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        "component": "label",
        "cellRenderView": false,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",

      },
      {
        header: "Menu Name",
        field: "label",
        filter: true,
        width: "500px",
        "editable": false,
        "text-align": "left",
        search: true,
        "ng-dblclick": "dblClickSection()",
        "component": "rowGroupCheckbox",
        "cellRenderView": true,
      },

    ];
    var self = this;
    let components = {
    };
    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: {},
        //  components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.onRowSelectGrid(event);
          },
          "onRowDbleClick": function () {
            self.onSelectedRowDoubleClick(event);
          }
        },
        rowCustomHeight: 20,
      };
      this.buttonRightsObj = SdmtGridT(sourceDiv, gridData, true, true);
    }
  }

  onRowSelectGrid(event: Event) {
  }
  onSelectedRowDoubleClick(event: Event) {

  }

}
