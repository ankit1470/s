import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ButtonRightsRoutingModule } from './button-rights-routing.module';
import { ButtonRightsComponent } from './button-rights.component';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [ButtonRightsComponent],
  imports: [
    CommonModule,
    ButtonRightsRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    DropdownModule
  ],exports:[ButtonRightsComponent]
})
export class ButtonRightsModule { }
