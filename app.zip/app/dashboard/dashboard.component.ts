import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";

import { NavigationEnd, Router } from "@angular/router";
import { DialogService, DynamicDialogRef, MenuItem } from "primeng/api";
import { Subscription } from "rxjs";
import { ToastService } from "../core/services/toast.service";
import { CreateProjectComponent } from "../modules/database/project-utility-tool/procompare-tool/pmt/create-project/create-project.component";
import { ApiServiceService } from "../services/http/api-service.service";
import { ProcomparetoolFirststepService } from "../services/project-utility-tool/procomparetool-firststep.service";
import { ProcomparetoolService } from "../services/project-utility-tool/procomparetool.service";
import { CommonStudioDragDropService } from "../services/sagStudio/common-studio-drag-drop.service";
import { SagStudioService } from "../services/sagStudio/sag-studio.service";
import { SagShareService } from "../services/sagshare.service";
import { WriteNgFilesService } from "../services/writeStudio/write-ng-files.service";
import { AddModuleComponent } from "./add-module/add-module.component";
import { ChooseProjectComponent } from "./choose-project/choose-project.component";
import { DatabaseConnectionComponent } from "./database-connection/database-connection.component";
import { SaveAllFileComponent } from "./save-all-file/save-all-file.component";
import { filter } from "rxjs/operators";
import { MenuFileDataLinkingComponent } from "../modules/database/project-utility-tool/procompare-tool/project-type/menu-file-data-linking/menu-file-data-linking.component";
import { ModulesPackagesLinkComponent } from "../modules/database/project-utility-tool/procompare-tool/project-type/modules-packages-link/modules-packages-link.component";
import { WorkAssignComponent } from "../modules/database/project-utility-tool/procompare-tool/project-type/work-assign/work-assign.component";
import { ModulesDropComponent } from "../modules/sag-studio/modules-drop/modules-drop.component";
import { CodeGenStepperComponent } from "../modules/sag-studio/modules-drop/modules/code-gen-stepper/code-gen-stepper.component";
import { AutoJavacodeService } from "../modules/sag-studio/property-window/db-mapping/auto-javacode.service";
import { SdmtDashboardComponent } from "../modules/sdmt-dashboard/sdmt-dashboard.component";
import { ConfigureApprovalComponent } from "./configure-approval/configure-approval.component";
import { CreateProjectStepperComponent } from "./create-project-stepper/create-project-stepper.component";
import { GenerateApkComponent } from "./generate-apk/generate-apk.component";
import { GitPermissionComponent } from "./git-permission/git-permission.component";
import { ModuleOwnerComponent } from "./module-owner/module-owner.component";
import { PendingApprovalStatusComponent } from "./pending-approval-status/pending-approval-status.component";
import { SagstudioDashboardComponent } from "./sagstudio-dashboard/sagstudio-dashboard.component";
import { BundleComponent } from "./sdmtTools/bundle/bundle.component";
import { ControlsComponent } from "./sdmtTools/controls/controls.component";
import { ModuleSetComponent } from "./sdmtTools/module-set/module-set.component";
import { PropertiesComponent } from "./sdmtTools/properties/properties.component";
import { TemplatePagesComponent } from "./sdmtTools/template-pages/template-pages.component";
import { TemplatesComponent } from "./sdmtTools/templates/templates.component";
import { WipthemesComponent } from "./sdmtTools/wipthemes/wipthemes.component";
import { UserWorkVersionComponent } from "./user-work-version/user-work-version.component";
import { ModelTwoComponent } from "../modules/sag-studio/model-two/model-two.component";
import { BCreateProjectStepperComponent } from "./b-create-project-stepper/b-create-project-stepper.component";
import { apiConstant } from "../config/apiconfig";
import { boolean } from "SagCodeEditor/packages/core/shared/yargs";
import { ControlCopyComponent } from "./control-copy/control-copy.component";
import { AiFundamentalsComponent } from "../modules/sag-studio/ai-fundamentals/ai-fundamentals.component";
import { CreateProjectBackupComponent } from './create-project-backup/create-project-backup.component';
import { RegexGeneratorComponent } from "./regex-generator/regex-generator.component";

// import { ProjectExploralFileListComponent } from './project-exploral-file-list/project-exploral-file-list.component';
declare function alerts(m): any;
declare function success(m): any;
declare var SdmtGridT: any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
const projectinfourl = apiConstant.projectinfourl;
declare global {
  interface Window {
    checkClickOnLogout: boolean;
    currentActiveProjectName: any;
    ProjectAlldetails: any;
    isChangeProject: any;
    javaData: any;
    getOSName: any;
  }
}
@Component({
  host: {
    class: "d-flex flex-column h-100 sdmtDarkMode",
    id: "sdmtDarkModeId",
  },
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"],
  providers: [DialogService],
})
export class DashboardComponent implements OnInit, AfterViewInit, OnDestroy {
  tooltipTitle: any = "SagEditor";
  generatedHtmlViewContent: any;
  currentNodeNativePath: string = "";
  usrCode = "sag";
  role = "admin";
  customPortNumber: any = "";
  debugConfigPortNo: any = "";
  browserType: any = "chrome"
  hostIp: any = "localhost";
  invalidPort: boolean = false;
  showBar: any = false;
  selectedNavItem: string = "Home";
  sidebarAreaShow: any = false;
  selectedJsFile: any;
  isObfuscator: any;
  isAngular8: boolean = false;
  showModal: boolean = false;
  isDisablehostCheck: any = "";
  stopingPortNo: any = "54321";
  allowPortChange: boolean = false;
  navClick(navId) {
    this.selectedNavItem = navId;
  }

  items: MenuItem[] = [
    {
      label: "File",
      items: [
        { label: "Open", icon: "fas fa-file" },
        // { label: 'Save Multi File', icon: 'far fa-file', command: (event) => this.onBuild('write') },
        {
          label: "save File",
          icon: "far fa-file",
          command: (event) => this.saveHtmlFromJson("type"),
        },
        // { label: 'save Project', icon: 'far fa-folder-open', command: (event) => this.onBuild('writeProject') },
        // { label: 'Download Constant', icon: 'far fa-folder-open', command: (event) => this.downloadConstant() },
        { label: "Exit", icon: "fas fa-sign-out-alt" },
      ],
    },
    {
      label: "Edit",

      items: [
        { label: "Cut", icon: "far fa-file " },
        { label: "Copy", icon: "far fa-copy " },
        { label: "Paste", icon: "fas fa-paste" },
        { label: "Undo", icon: "fas fa-undo" },
      ],
    },

    {
      label: "Navigate",

      items: [
        { label: "GO To", icon: "fas fa-link" },
        { label: "Open Type", icon: "pi pi-fw pi-refresh" },
        { label: "Open Resource", icon: "pi pi-fw pi-refresh" },
      ],
    },

    // {
    //   label: 'Search',

    //   items: [
    //     { label: 'search', icon: 'fas fa-search' },
    //     { label: 'File', icon: 'far fa-file' },
    //     { label: 'Text', icon: 'fas fa-file-alt' }

    //   ]
    // },

    {
      label: "Project",

      items: [
        {
          label: "Load Project",
          icon: "fas fa-infinity",
          command: (event) => this.projectChangePath("uiBuilder"),
        },
        // {
        //   label: "Download Project",
        //   icon: "fas fa-download",
        //   command: (event) => this.onBuild("build"),
        // },
        // { label: 'Write Project', icon: 'far fa-folder-open', command: (event) => this.onBuild('writeProject') },
        // { label: 'Write Files', icon: 'far fa-file', command: (event) => this.onBuild('write') },
        // {
        //   label: "Create Project",
        //   icon: "far fa-file",
        //   command: (event) => this.createProject("createProject"),
        // },
        // {
        //   label: "Create Project Stepper old",
        //   icon: "far fa-file",
        //   command: (event) => this.OpenCrtPrjtStepperOld(),
        // },
        {
          label: "Create Project",
          icon: "far fa-file",
          command: (event) => this.OpenCrtPrjtStepper(),
        },
        // {
        //   label: "save Studio Files",
        //   icon: "far fa-copy",
        //   command: (event) => this.saveStudioFiles("saveStudioFiles"),
        // },
        // {
        //   label: "Add Module",
        //   icon: "far fa-file",
        //   command: (event) => this.addModulePopup(),
        // },
      ],
    },
    {
      label: "Run",

      items: [
        {
          label: "npm install --force",
          icon: "fab fa-instalod",
          command: (event) => this.runcmd(event, true),
        },
        // {
        //   label: `ng serve -o --port ${this._sagStudioService.customPortNo}`,
        //   icon: "fas fa-server",
        //   command: (event) => this.runcmd(event, false),
        // },
        {
          // label: "ng serve -o --port ${Your Port}",
          label: "ng serve --host 0.0.0.0 --port ${Your Port}",
          icon: "fas fa-server",
          command: (event) => this.customPort(event, false),
        },
        {
          label: "npm cache clean --force",
          icon: "fab fa-digital-ocean",
          command: (event) => this.runcmd(event, true),
        },
        {
          label: "stop-server",
          icon: "far fa-times-circle",
          items: [],
        },
        {
          label: "ng build --prod",
          icon: "fas fa-retweet",
          command: (event) => this.ngBuild(event, "buildProd"),
        },
        {
          label: "ng build ",
          icon: "fas fa-retweet",
          command: (event) => this.ngBuild(event, "build"),
        },
        // { label: 'run java project', icon: 'fas fa-server', command: (event) => this.startJavaProject(event, true) },
        // { label: 'stop java project', icon: 'far fa-times-circle', command: (event) => this.stopJavaProject(event, true) },
        //  { label: 'restart java project', icon: 'fas fa-server', command: (event) => this.restartJavaProject(event, true) },
        {
          label: "run java project",
          icon: "fas fa-server",
          command: (event) => this.startSpringBootJavaProject(event, true),
        },
        {
          label: "stop java project",
          icon: "far fa-times-circle",
          command: (event) => this.stopSpringBootJavaProject(event, true),
        },
        {
          label: "maven-clean",
          icon: "fab fa-digital-ocean",
          command: (event) => this.mavenClean(event, true),
        },
        {
          label: "create-jar",
          icon: "fab fa-instalod",
          command: (event) => this.mavenInstall(event, true, "jar"),
        },
        {
          label: "create-war",
          icon: "fab fa-instalod",
          command: (event) => this.mavenInstall(event, true, "war"),
        },

        {
          label: "run terminal commands",
          icon: "fas fa-server",
          items: [
            {
              label: "npm cache clean --force",
              icon: "fas fa-server",
              command: () =>
                this.run_Terminal_Commands("npm cache clean --force"),
            },
            {
              label: "npm install",
              icon: "fas fa-server",
              command: () => this.run_Terminal_Commands("npm install"),
            },
            {
              label: "npm install --force",
              icon: "fas fa-server",
              command: () => this.run_Terminal_Commands("npm install --force"),
            },
            {
              label: "ng build angular_8",
              icon: "fas fa-server",
              command: () =>
                this.run_Terminal_Commands(
                  "node --openssl-legacy-provider ./node_modules/@angular/cli/bin/ng build"
                ),
            },
            {
              label: "ng build",
              icon: "fas fa-server",
              command: () => this.run_Terminal_Commands("ng build"),
            },
            {
              label: "ng build --prod",
              icon: "fas fa-server",
              command: () => this.run_Terminal_Commands("ng build --prod"),
            },
            {
              label: "ng build --watch",
              icon: "fas fa-server",
              command: () => this.run_Terminal_Commands("ng build --watch"),
            },
          ],
        },

        {
          label: "run angular project",
          icon: "fas fa-server",
          command: () => this.runAngularProject(),
        },
        {
          label: "stop angular project",
          icon: "far fa-times-circle",
          command: () => this.stopAngularProject(),
        },
        {
          label: "css minify",
          icon: "fab fa-digital-ocean",
          command: () => this.checkJsList("css_Minify", ".css"),
        },
        {
          label: "js minify",
          icon: "fab fa-digital-ocean",
          command: () => this.checkJsList("js_Minify", ".js"),
        },
        {
          label: "js obfuscation",
          icon: "fab fa-digital-ocean",
          command: () => this.checkJsList("obfus_build", ".js"),
        },
        {
          label: "Download Archive",
          icon: "fas fa-server",
          command: () => this.downloadArchive(),
        },
        {
          label: "Download Log",
          icon: "fas fa-server",
          command: () => this.downloadLog(),
        },
        {
          label: "Create Backup",
          icon: "fas fa-server",
          command: () => this.projectBackup(),
        },
      ],
    },
    {
      label: "Window",

      items: [
        {
          label: "Project Explorer",
          command: (event) => this.addShowView("projectExplorer"),
        },
        { label: "Tools", command: () => this.addShowView("tools") },
        { label: "sagMode", command: () => this.addShowView("sagMode") },
        { label: "Task Bar", command: () => this.addShowView("taskBar") },
        {
          label: "Component Tray",
          command: () => this.addShowView("componentTray"),
        },
        {
          label: "project-utility-tool Explorer",
          command: () => this.projectutilityExplorerClick("menuSidebar"),
        },
        {
          label: "project-utility-tool Editor",
          command: () => this.projectutilityEditorClick("cntrContainer"),
        },
      ],
    },
    {
      label: "Help",

      items: [
        {
          label: "Report",
          icon: "pi pi-fw pi-plus",
          items: [{ label: "Project" }, { label: "Other" }],
        },
      ],
    },
    // =======================================pankajsingh=====================work==============
    {
      label: "Pmanagement",

      items: [
        {
          label: "PMT",
          icon: "fab fa-instalod",
          command: (event) =>
            this.ProjectInfoTool(
              "dashboard/database/projectToolFirst/newprojectinfo/pmt",
              true
            ),
        },
        {
          label: "PMT Configuration(Acc)",
          icon: "fas fa-server",
          command: (event) =>
            this.ProjectInfoTool(
              "dashboard/database/projectToolFirst/newprojectinfo/acc",
              false
            ),
        },
        //{ label: 'Module Package Link', icon: 'fas fa-server', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/module_package_link', false) },
        {
          label: "DB Configuration",
          icon: "fab fa-digital-ocean",
          command: (event) =>
            this.ProjectInfoTool("dashboard/database/dbcomparetool", "dbtool"),
        },
        {
          label: "DB Summary",
          icon: "far fa-times-circle",
          command: (event) =>
            this.ProjectInfoTool(
              "dashboard/database/projectToolFirst/newprojectinfo/database/dbcomparetool/dbfirst",
              true
            ),
        },
        {
          label: "DB Detail",
          icon: "far fa-times-circle",
          command: (event) =>
            this.ProjectInfoTool(
              "dashboard/database/projectToolFirst/newprojectinfo/database/dbcomparetool/head/dbtool",
              true
            ),
        },
        // { label: 'Assign(to be)', icon: 'fab fa-instalod', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/assign_toBe', true) },
        //{ label: 'Assigned Work', icon: 'fas fa-server', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/assigned_work', false) },
        // { label: 'Approval', icon: 'fas fa-server', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/documentation', false) },
        //{ label: 'Documentation', icon: 'fab fa-digital-ocean', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/documentation', true) },
        //{ label: 'Sag Version Control', icon: 'far fa-times-circle', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/documentation', true) },
        // { label: 'Problems', icon: 'far fa-times-circle', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/problems', true) },
        //{ label: 'History', icon: 'fas fa-server', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/History', false) },
        //{ label: 'Saggestions', icon: 'fab fa-digital-ocean', command: (event) => this.ProjectInfoTool('dashboard/database/projectToolFirst/newprojectinfo/History', true) },
        {
          label: " project Permission",
          icon: "fa fa-user",
          command: (event) => this.gitPermissionClick(),
        },
        {
          label: "Work Assign",
          icon: "fa fa-user",
          command: (event) => this.WorkAssign(),
        },
        {
          label: "Module Owner",
          icon: "fa fa-user",
          command: (event) => this.ModuleOwner(),
        },
        {
          label: "Module Package Link ",
          icon: "fa fa-user",
          command: (event) => this.ModulePackageLinkClick(),
        },
        {
          label: "Menu File Data Linking ",
          icon: "fas fa-server",
          command: (event) => this.menuFileDataLinkingClick(),
        },
        {
          label: "Change Project ",
          icon: "fa fa-user",
          command: (event) => this.beforeChangeProject(),
        },
      ],
    },
    {
      label: "Work in Progress",

      items: [
        {
          label: "BUNDLE",
          icon: "fab fa-instalod",
          command: (event) => this.bundle(),
        },
        {
          label: "MODULESET",
          icon: "fas fa-server",
          command: (event) => this.moduleSet(),
        },
        {
          label: "TEMPLATE_PAGES",
          icon: "fas fa-server",
          command: (event) => this.temPages(),
        },
        {
          label: "TEMPLATES",
          icon: "fab fa-digital-ocean",
          command: (event) => this.temPlates(),
        },
        {
          label: "THEMES",
          icon: "fab fa-digital-ocean",
          command: (event) => this.themes(),
        },
        {
          label: "PROPERTIES",
          icon: "fab fa-digital-ocean",
          command: (event) => this.properties(),
        },
        {
          label: "CONTROLS",
          icon: "fab fa-digital-ocean",
          command: (event) => this.controls(),
        },
        {
          label: "TEMPLATES COPY",
          icon: "fab fa-digital-ocean",
          command: (event) => this.controlCopy(),
        },
        {
          label: "REGEX ",
          icon: "fab fa-digital-ocean",
          command: (event) => this.regex(),
        },
      ],
    },
    // {
    //   label: "Dashboard",
    //   icon: '',
    //   command: (event) => this.sagStudioDashboard()

    // }
  ];

  // =======================================pankajsingh=====================work==============
  toolbar: MenuItem[] = [
    {
      icon: "pi pi-fw pi-file",
      items: [
        { label: "Open" },
        { label: "Quit" },
        {
          label: "New",
          icon: "pi pi-fw pi-plus",
          items: [{ label: "Project" }, { label: "Other" }],
        },
      ],
    },
    // {
    //   icon: 'pi pi-fw pi-save',
    //   command: (event) => this.saveHtmlFromJson('type')
    // },
    {
      icon: "pi pi-fw pi-save",
      // styleClass:"unSavedFile",
      // `${this._sagStudioService.unSavedFileList.length >0 ? 'unSavedFile' : '' }`,
      command: (event) => this.saveAllFileComponentOpen(event),
      title: "Save",
    },

    {
      icon: "pi pi-fw pi-user",
      items: [
        { label: "Delete", icon: "pi pi-fw pi-trash" },
        { label: "Refresh", icon: "pi pi-fw pi-refresh" },
      ],
    },
  ];
  username: any;
  runCommandData: any;

  subscription: Subscription;

  sagToolSelected: string = "";
  tooltipIcon: boolean = false;
  customUrl: any;
  angularPort: any = "54321";
  router2: string;
  pToggleVal: boolean;

  @HostListener("window:beforeunload")
  defaultConfirmation(): boolean {
    if (window["checkClickOnLogout"] == undefined) {
      return true;
    } else {
      if (window["checkClickOnLogout"]) {
        return true;
      } else {
        return false;
      }
    }
  }

  constructor(
    public _router: Router,
    public _sagStudioService: SagStudioService,
    public StudioDragDropService: CommonStudioDragDropService,
    public cdRef: ChangeDetectorRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public router: Router,
    private dbcomparetoolService: ProcomparetoolService,
    public firststepProjectService: ProcomparetoolFirststepService,
    private _ele: ElementRef,
    private _apiService: ApiServiceService,
    private _writeNgFile: WriteNgFilesService,
    public toast: ToastService,
    public autoJavacodeService: AutoJavacodeService,
    public sagStudioService: SagStudioService
  ) {
    this.getOSName();
    window["angularComponentRef"] = window["angularComponentRef"] || {};
    window["angularComponentRef"].logoutClick = this.logoutClick.bind(this);
    window["angularComponentRef"].changeProject = this.changeProject.bind(this);
    window["angularComponentRef"].goToHome = this.goToHome.bind(this);
    window["angularComponentRef"].getCheckClickOnLogout =
      this.getCheckClickOnLogout.bind(this);
    window["angularComponentRef"].setIsChangeProject =
      this.setIsChangeProject.bind(this);
    window["angularComponentRef"].getCheckActiveProjectName =
      this.getCheckActiveProjectName.bind(this);
    window["angularComponentRef"].setProjectAlldetails =
      this.setProjectAlldetails.bind(this);
    window["angularComponentRef"].getTreeData = this.getTreeData.bind(this);
    window["angularComponentRef"].stopJavaProjectTerminalIcon =
      this.stopSpringBootJavaProject.bind(this);
    window["getOSName"] = this.getostype.bind(this);
    window["angularComponentRef"].getAngularProjectPort = this.getAngularProjectPort.bind(this);
    let obj = {
      label: "Clean Workspace",
      icon: "",
      id: "CleanWorkspaceBtn",
      command: (event) => this.clearWorkSpaceStorage(),
    };
    let cleanWrkStrgPathCheck: any = [
      "/dashboard/sagstudiodashboard",
      "/dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
      "/dashboard/studioprojectlist"
    ];

    this._router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.router2 = event.url;
        if (event.url == "/dashboard/sagstudiodashboard") {
          this.pToggleVal = false;
          this.sidebarAreaShow = false;
        } else if (event.url == "/dashboard/studioprojectlist") {
          this.pToggleVal = true;
          this.sidebarAreaShow = true;
        } else if (event.url == "/dashboard/UIbuilder") {
          this.shareService.showEditor("hide");
          this.sidebarAreaShow = false;
        } else {
          //   this.sidebarAreaShow = false
        }
        let ele = document.getElementById("CleanWorkspaceBtn") as any;
        if (cleanWrkStrgPathCheck.includes(event.url)) {
          if (!this.items.includes(obj)) {
            this.items.push(obj);
          } else {
            ele ? (ele.style.display = "block") : "";
          }
        } else {
          ele ? (ele.style.display = "none") : "";
        }
      });

    this.router2 = _router.url;
    sessionStorage.setItem("isLocalhostOrIP", apiConstant.isLocalhostOrIP);
  }

  getTreeData(response: any) {
    self.javaData = response;
  }

  getOSName() {
    this.shareService.getOStype().subscribe((res: any) => {
      if (res["status"] == "success") {
        this.shareService.setDataprotool("getOStype", res["message"]);
      }
    });
  }

  getostype() {
    return this.shareService.getDataprotool("getOStype");
  }

  getCheckClickOnLogout(res: any) {
    self.checkClickOnLogout = res;
  }

  setIsChangeProject(res: any) {
    self.isChangeProject = res;
  }

  setProjectAlldetails(res: any) {
    self.ProjectAlldetails = res;
  }

  getCheckActiveProjectName(name: any) {
    self.currentActiveProjectName = name;
  }
  connection_data: any;
  ngOnInit() {

    

    const sessionStoragedata = JSON.parse(
      sessionStorage.getItem("loginFormValue")
    );
    this.username = sessionStoragedata ? sessionStoragedata.username : "";
    this.connection_data = this.shareService.getDatadbtool(
      "finalDataForConnection"
    );
    // this._sagStudioService.initSagWorkSpaceJSON("arg1", "arg2");
    this.subscription = this._sagStudioService.currentNodeForFileView.subscribe(
      (node) => {
        this.currentNodeNativePath = node.nativePath + "/" + node.label;
      }
    );

    this.callMethodSubscription =
      this._sagStudioService.dashboardComponent$.subscribe((resObj) => {
        this.callMethod(resObj);
      });
    this.shareService.showBar.subscribe((res) => {
      this.showBar = res;
    });
    this.shareService.sidebarAreaShow.subscribe((res) => {
      this.sidebarAreaShow = res;
    });
    this.shareService.$uIbuilderLoadProject.subscribe((res) => {
      this.onDashboardList("dashboard/UIbuilder", "UIbuilder");
    });
    // this.subMenuLoad();

  }
  dashBoardChange(event) {
    this.removeSelectedProjectData();
    if (!event.checked) {
      this.showBar = false;
      this.router.navigate(["dashboard/sagstudiodashboard"]);
      this.sidebarAreaShow = false;
      //   document.getElementById('sdmtDarkModeId').classList.contains('sdmtDarkMode') ?  document.getElementById('sdmtDarkModeId').classList.remove('sdmtDarkMode') : false;
    } else {
      document
        .getElementById("sdmtDarkModeId")
        .classList.contains("sdmtDarkMode")
        ? false
        : document
          .getElementById("sdmtDarkModeId")
          .classList.add("sdmtDarkMode");
      this.sidebarAreaShow = true;
      this.showBar = false;
      this.router.navigate(["dashboard/studioprojectlist"]);
    }
  }

  removeSelectedProjectData() {
    this.shareService.removeDataprotool("selectedProjectChooseData");
    this.shareService.removeDataprotool("selectedGridRowData");
    localStorage.removeItem("selectedProjectChooseData");
    this.shareService.removeDataprotool("projectNameValue");
    this.shareService.removeDataprotool("selectedAngularProject");
    this.shareService.removeDataprotool("dataType");
    localStorage.removeItem("checkProjectData");
  }

  // addScript(path) {
  //   var head = document.getElementsByTagName("head")[0];
  //   var s = document.createElement("script");
  //   s.type = "text/javascript";
  //   s.src = path;
  //   s.id = "scriptLoadID";
  //   head.appendChild(s);
  // }
  ngAfterViewInit(): void {
    let toggles = document.querySelectorAll(".toggless");

    toggles.forEach(function (toggless) {
      toggless.addEventListener("click", function (e) {
        e.preventDefault();
        let parentLi = this.parentElement;
        let submenu = this.nextElementSibling;

        let allToggleClass: any = document.querySelectorAll(".toggless");

        allToggleClass.forEach((x: any) => {
          if (x.parentElement == parentLi) {
            if (parentLi.classList.contains("active")) {
              parentLi.classList.remove("active");
              submenu.style.maxHeight = null;
            } else {
              parentLi.classList.add("active");
              submenu.style.maxHeight = submenu.scrollHeight + "px";
            }
          } else {
            if (x.parentElement.classList.contains("active")) {
              x.parentElement.classList.remove("active");
              submenu.style.maxHeight = null;
            }
          }
        });
      });
    });

    // if (!document.getElementById('scriptLoadID')) {
    //  this.addScript(this.shareService.editorLoadPath); //adding script dynamically
    // }
    this.toggleBtnClick();
    // this.aitoolmodaldesign();
  }

  clearWorkSpaceStorage() {
    let userCode:any=sessionStorage.getItem('userCode');
    let obj = {
      fileList: [`${userCode}/workspace-storage`],
    };
    this.shareService.cleanWorkSpaceStorage(obj).subscribe(
      (res: any) => {
        if (res["status"] == 200) {
          success(res.msg);
        } else {
          alerts(res.msg);
        }
      },
      (error: any) => {
        alerts(error.msg);
      }
    );
  }

  createProject(event: any) {
    const ref = this.dialogService.open(CreateProjectComponent, {
      header: "create Project",
      width: "100%",
      styleClass: "service_full_model ",
    });
    ref.onClose.subscribe((res) => {
      if (this.router2 == "/dashboard/studioprojectlist") {
        this.sidebarAreaShow = true;
        document.getElementById("dashSideBar").classList.add("d-none");
      } else if (this.router2 == "/dashboard/sagstudiodashboard") {
        this.sidebarAreaShow = false;
        document.getElementById("dashSideBar").classList.remove("d-none");
      } else {
        this.sidebarAreaShow = false;
        document.getElementById("dashSideBar").classList.add("d-none");
      }
      const __Value = window.location.href.substring(
        window.location.href.lastIndexOf("/") + 1
      );
      if (__Value == "project_configuracion") {
        window.location.reload();
      }
    });
  }

  OpenCrtPrjtStepperOld() {
    const ref = this.dialogService.open(CreateProjectStepperComponent, {
      header: "create Project",
      width: "100%",
      // contentStyle: { height: "70.5vh" },
      showHeader: false,
      styleClass: "service_full_model stappermain_modal",
    });
  }

  OpenCrtPrjtStepper() {
    const ref = this.dialogService.open(BCreateProjectStepperComponent, {
      header: "create Project",
      width: "60%",
      contentStyle: {
        height: "90vh",
        maxHeight: "100%",
        minHeight: "100%",
        overflow: "hidden",
        flexDirection: "column",
        display: "flex",
        backgroundColor: "unset",
      },
      showHeader: false,
      // styleClass: "service_full_model stappermain_modal",
    });
  }

  // saveStudioFiles(event: any) {
  //   const ref = this.dialogService.open(SaveStudioFilesComponent, {
  //     header: "save Studio files",
  //     width: "90%",
  //     contentStyle: { height: "500px" },
  //   });
  // }

  /////////////////////////////////////////////////////////////////////////

  onDashboardList(url, type) {
    /*****get role list */
    this.customUrl = url;
    if (type == "projectConfig") {
      this.getRoleList(); //calling for get role api
    }
    this._sagStudioService.footerTabBar = false;
    this.shareService.modeBoolean = false;
    this.shareService.setDataprotool("dataType", type);
    this.shareService.setDataprotool("dataTypeWorkSpace", "");
    this.firststepProjectService.pmtHeaderDisplay.next(true);
    this.showBar = true;
    this.sidebarAreaShow = false;
    //---------
    type == "pmt"
      ? this.firststepProjectService.pmtHeaderDisplay.next(false)
      : false;

    if (type == "UIbuilder") {
      document.getElementById("dashSideBar").classList.remove("d-none");
      this.tooltipIcon = true;
      let mainBody = document.querySelector("body");
      mainBody.classList.remove("theiaEditor");
      mainBody.classList.add("uiEditor");
      this.shareService.setDataprotool("acctiveTab", "UIbuilder");
      this.shareService.setDataprotool("UIbuilder", false);
      this.shareService.setDataprotool("UIbuilderFileShow", true);
      const chooseProjectPathID = this.shareService.getDataprotool(
        "selectedProjectChooseData"
      );
      chooseProjectPathID && chooseProjectPathID.awspace
        ? this._router.navigate([url])
        : this.openProjectsLoadProject();
    } else {
      if (type == "project_type") {
        let mainBody = document.querySelector("body");
        mainBody.classList.add("theiaEditor");
        if (!document.getElementById("scriptLoadID")) {
          this.shareService.loading++;

          const chooseProjectPathID = this.shareService.getDataprotool(
            "selectedProjectChooseData"
          );

          if (chooseProjectPathID && chooseProjectPathID.awspace) {
            this.shareService.modeBoolean = true;
            this.addScript(this.shareService.editorLoadPath);
          } else {
            this.shareService.loading--;
            this._router.navigate([
              "dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
            ]);
          }
        } else {
          document.querySelector("body").classList.remove("uiEditorNew");
          document.getElementById("dashSideBar").classList.add("d-none");
          const chooseProjectPathID = this.shareService.getDataprotool(
            "selectedProjectChooseData"
          );
          chooseProjectPathID && chooseProjectPathID.awspace
            ? this._router.navigate([url])
            : this._router.navigate([
              "dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
            ]);
        }
      } else {
        this.shareService.showEditor("hide");
        let mainBody = document.querySelector("body");
        mainBody.classList.remove("theiaEditor");
        mainBody.classList.remove("uiEditor");
        if (url == "dashboard/database/projectToolFirst/newprojectinfo/pmt") {
          this.showBar = false;
          document
            .getElementById("sdmtDarkModeId")
            .classList.contains("sdmtDarkMode")
            ? false
            : document
              .getElementById("sdmtDarkModeId")
              .classList.add("sdmtDarkMode");
        } else {
          this.showBar = true;
          document
            .getElementById("sdmtDarkModeId")
            .classList.contains("sdmtDarkMode")
            ? document
              .getElementById("sdmtDarkModeId")
              .classList.remove("sdmtDarkMode")
            : false;
        }
        this._router.navigate([url]);
      }
    }
  }

  addScript(path) {
    var head = document.getElementsByTagName("head")[0];
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = path;
    s.id = "scriptLoadID";
    head.appendChild(s);
  }

  newContact(route) {
    this.firststepProjectService.projectHeaderActiveTab.next(route);
  }

  theiaEditor(event: any) {
    let item = localStorage.getItem("openProject");
    let itemData = localStorage.getItem("projectUtility");
    let uiBuilderData = localStorage.getItem("UIBuilder");
    document.getElementById("dashSideBar").classList.add("d-none");
    document.querySelector("body").classList.remove("theiaEditor");
    if (this.shareService.projectUtility == true) {
      if (uiBuilderData == "true") {
        this.shareService.setDataprotool("loadDataTreeType", "projectType");
        // this.newContact('project_type');
        this.onDashboardList(
          "dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
          "project_type"
        );
        this.shareService.projectUtility = false;
        this.tooltipIcon = false;
      } else {
        this.onDashboardList(
          "dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
          "project_type"
        );
        this.shareService.projectUtility = false;
      }
    } else if (this.tooltipIcon == true && this.change == true) {
      if (item == "true") {
        this.onDashboardList(
          "dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
          ""
        );
        setTimeout(() => {
          this.onDashboardList(
            "dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
            ""
          );
        }, 50);
      } else {
        this.onDashboardList(
          "dashboard/database/projectToolFirst/newprojectinfo/project_type",
          ""
        );
        this.change = false;
      }
      this.tooltipIcon = false;
      this.shareService.projectUtility = false;
    } else if (this.tooltipIcon == true && this.change == false) {
      if (itemData == "true") {
        this.newContact("project_type");
        this.onDashboardList(
          "dashboard/database/projectToolFirst/newprojectinfo/project_type",
          ""
        );
      } else if (uiBuilderData == "true") {
        this.onDashboardList(
          "dashboard/database/projectToolFirst/newprojectinfo/project_type",
          ""
        );
      } else {
        this.onDashboardList(
          "dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
          ""
        );
      }
      this.tooltipIcon = false;
      this.shareService.projectUtility = false;
    } else {
      event.stopPropagation();
    }
  }

  pmt(project_type) {
    if (this.tooltipIcon == true) {
      this.onDashboardList(
        "dashboard/database/projectToolFirst/newprojectinfo/pmt",
        project_type
      );
      setTimeout(
        () =>
          this.onDashboardList(
            "dashboard/database/projectToolFirst/newprojectinfo/pmt",
            project_type
          ),
        50
      );
    } else
      this.onDashboardList(
        "dashboard/database/projectToolFirst/newprojectinfo/pmt",
        project_type
      );
  }

  menuFileDataLinkingClick() {
    const ref = this.dialogService.open(MenuFileDataLinkingComponent, {
      header: "Menu File Data Linking",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model menuFileData pmanagement_modal",
      // data: { defaultModelName: defaultModelName }
    });
    ref.onClose.subscribe((res) => { });
  }

  change: boolean = false;
  async changeProject() {
    await this.shareService.closeAllTerminalServers();

    if (window["angularComponentRef"].callStoreLayout) {
      await window["angularComponentRef"].callStoreLayout();
    }

    // localStorage.clear();
    // document.getElementById("dashSideBar").classList.add("d-none");
    this.change = true;
    localStorage.setItem("openProject", "true");
    this.onDashboardList(
      "dashboard/database/projectToolFirst/newprojectinfo/project_configuracion",
      ""
    );
    // setTimeout(() => { this.onDashboardList('dashboard/database/projectToolFirst/newprojectinfo/project_configuracion', ''); }, 50)
    this.shareService.projectUtility = false;
  }

  // check unsaved changes while ChangeProject from inside the project
  async beforeChangeProject() {
    if (window["angularComponentRef"].setIsChangeProject) {
      const callFunc = await window["angularComponentRef"].setIsChangeProject;
      callFunc("onChangeProject");
    }

    if (window["angularComponentRef"].onWillLogOut) {
      window["angularComponentRef"].onWillLogOut();
    } else {
      this.changeProject();
    }
  }

  // check unsaved changes while route to Home from inside the project
  async beforeRouteToHome() {
    if (window["angularComponentRef"].setIsChangeProject) {
      const callFunc = await window["angularComponentRef"].setIsChangeProject;
      callFunc("onHome");
    }

    if (window["angularComponentRef"].onWillLogOut) {
      window["angularComponentRef"].onWillLogOut();
    } else {
      this.goToHome();
    }
  }

  goToHome() {
    if (sessionStorage.getItem("newDashboard") == "false") {
      this.showBar = false;
      this.shareService.showBar.next(false);
      document
        .getElementById("sdmtDarkModeId")
        .classList.contains("sdmtDarkMode")
        ? document
          .getElementById("sdmtDarkModeId")
          .classList.remove("sdmtDarkMode")
        : false;
      this.shareService.projectUtility = true;
      this.router.navigate(["dashboard/sagstudiodashboard"]);
    } else if (sessionStorage.getItem("newDashboard") == "true") {
      this.showBar = false;
      this.shareService.showBar.next(false);
      this.shareService.projectUtility = true;
      document
        .getElementById("sdmtDarkModeId")
        .classList.contains("sdmtDarkMode")
        ? false
        : document
          .getElementById("sdmtDarkModeId")
          .classList.add("sdmtDarkMode");
      this.sidebarAreaShow = true;
      this.router.navigate(["dashboard/studioprojectlist"]);
    } else {
      this.showBar = false;
      this.shareService.projectUtility = true;
      this.shareService.showBar.next(false);
      document
        .getElementById("sdmtDarkModeId")
        .classList.contains("sdmtDarkMode")
        ? false
        : document
          .getElementById("sdmtDarkModeId")
          .classList.add("sdmtDarkMode");
      this.sidebarAreaShow = true;
      this.router.navigate(["dashboard/studioprojectlist"]);
    }
  }

  private removeListener: () => void;
  makeResizable() {
    let elem = this._ele.nativeElement.querySelector("#leftPanel_PrjExp");
    let currentPointer;
    function mouseMv(e) {
      if (e.x < currentPointer) {
        let leftBar = document.querySelector(".app-sidebar");
        (<HTMLElement>leftBar).style.minWidth = e.x + "px";
      } else {
        let leftBar = document.querySelector(".app-sidebar");
        (<HTMLElement>leftBar).style.minWidth = e.x + "px";
      }
    }

    elem.addEventListener("mousedown", (e) => {
      currentPointer = e.x;
      document.addEventListener("mousemove", mouseMv);
    });

    document.addEventListener("mouseup", (e) => {
      document.removeEventListener("mousemove", mouseMv);
    });
  }

  onCurrentViewMode(viewType) {
    this._sagStudioService.currentViewMode = viewType;
  }

  applyHeightHandler() {
    setTimeout(() => {
      let _scrollCon = document.querySelector("#scrollbarSidebarN");
      const topH = (<HTMLElement>_scrollCon).offsetTop;
      const winH = window.innerHeight;
      (<HTMLElement>_scrollCon).style.height = winH - topH + "px";
    }, 10);
  }

  // async onBuild(type) {
  //   //loadDataTreeType  use variable fot load Tree in WorkSpace working by pankajsingh
  //   this.shareService.setDataprotool("loadDataTreeType", "ProjectType");
  //   //loadDataTreeType  use variable fot load Tree in WorkSpace working by pankajsingh
  //   this.shareService.loading++;
  //   // const wait = await this._generateHtmlService.generateDownloadJsonUri(type);
  //   setTimeout(() => {
  //     this.shareService.loading--;
  //   }, 2000);
  // }

  //  pankaj work =======logout=============logout=============logout------------------logout pankaj work

  async logoutClick() {
    this.shareService.loading++;
    await this.shareService.closeAllTerminalServers();

    if (window["angularComponentRef"].callStoreLayout) {
      await window["angularComponentRef"].callStoreLayout();
    }
    this.firststepProjectService.logout().subscribe(
      (data) => {
        this.shareService.loading--;
        localStorage.clear();
        this.shareService.clearAllData();
        this.firststepProjectService.unAuthorizeCalllback();
      },

      (error) => {
        console.error("error logout detail", error);
      }
    );
  }

  async checkUnsavedChanges() {
    if (window["angularComponentRef"].getCheckClickOnLogout) {
      const checkClickOnLogout = await window["angularComponentRef"]
        .getCheckClickOnLogout;
      checkClickOnLogout(true);
    }

    if (window["angularComponentRef"].setIsChangeProject) {
      const callFunc = await window["angularComponentRef"].setIsChangeProject;
      callFunc("onlogout");
    }

    if (window["angularComponentRef"].onWillLogOut) {
      window["angularComponentRef"].onWillLogOut();
    } else {
      this.logoutClick();
    }
  }
  async getAngularProjectPort() {
    const sessionStoragedatauserId = JSON.parse(
      sessionStorage.getItem("loginFormValueUserID")
    );
    if (sessionStoragedatauserId) {
      let userId = sessionStoragedatauserId.data.clientInfo.usrId;
      let response: any = await this.dbcomparetoolService
        .getAngularProjectPort(userId)
        .toPromise();
      let data = response.data;
      if (response["status"] == 200 && response["isOnline"]) {
        this.debugConfigPortNo = data["angPort"];
        this.allowPortChange = true;
        this.hostIp = data["ip"];
      } else {
        this.debugConfigPortNo = "";
        this.allowPortChange = false;
        this.hostIp = "localhost";
      }
      this.invalidPort = false;
      $("#portAskingRunDebugModal").modal("show");
    }
  }

  writeFrontedDebugConfig() {
    if (
      !this.debugConfigPortNo.match(
        /^([1-9][0-9]{0,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$/
      )
    ) {
      this.invalidPort = true;
    } else {
      const chooseProjectPathID = this.shareService.getDataprotool(
        "selectedProjectChooseData"
      );
      this.invalidPort = false;
      $("#portAskingRunDebugModal").modal("hide");
      let obj: any = {
        "browserType": this.browserType,
        "host": this.hostIp,
        "port": this.debugConfigPortNo.trim(),
        "angPath": chooseProjectPathID.awspace
      }
      const fun = window["angularComponentRef"].editDebugConfiguration;
      fun(obj);
    }
  }


  async runAngularProject() {
    const sessionStoragedatauserId = JSON.parse(
      sessionStorage.getItem("loginFormValueUserID")
    );
    if (sessionStoragedatauserId) {
      let userId = sessionStoragedatauserId.data.clientInfo.usrId;
      let response: any = await this.dbcomparetoolService
        .getAngularProjectPort(userId)
        .toPromise();
      let data = response.data;
      if (response["status"] == 200 && response["isOnline"]) {
        this.isDisablehostCheck = " --disable-host-check";
        this.customPortNumber = data["angPort"];
        this.allowPortChange = true;
      } else {
        this.isDisablehostCheck = "";
        this.customPortNumber = "";
        this.allowPortChange = false;
      }
      this.invalidPort = false;
      let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
      let dataJson = {
        projectId: selectedObj.projectId
      }
      let res1: any = await this.shareService.getProjectVersion(dataJson).toPromise();
      if(res1 && res1['angular']){
        let angVersion: any = res1['angular'];
        angVersion.split('.')[0] == '8' ? this.isAngular8 = true : this.isAngular8 = false;
        $("#portAskingModal").modal("show");
      }else{
        alerts('Something went wrong');
      }
    
    }
  }

  run_Terminal_Commands(command: any) {
    if (
      window["angularComponentRef"] &&
      window["angularComponentRef"].runAngularProject
    ) {
      const fun = window["angularComponentRef"].runAngularProject;
      fun(command);
    } else {
      alerts("currently command is not available!");
    }
  }

  // downloadArchive() {

  //   const projectDetailsString = localStorage.getItem('selectedProjectChooseData');

  //   if (projectDetailsString) {
  //     // Parse the JSON string to an object
  //     const projectDetails = JSON.parse(projectDetailsString);

  //     let postData = {
  //       "projectPath": projectDetails.jwspace
  //     };

  //     this.dbcomparetoolService.downloadArchive(postData).subscribe((blob) => {
  //       // Create a new Blob object using the response data
  //       const url = window.URL.createObjectURL(blob);
  //       const a = document.createElement('a');
  //       a.href = url;
  //       // a.download = 'archive.zip'; // Set a default filename
  //       document.body.appendChild(a);
  //       a.click();
  //       document.body.removeChild(a);
  //       window.URL.revokeObjectURL(url);
  //     }, (error) => {
  //       console.error('Download error:', error);
  //       // Additional logging for debugging
  //       if (error.status === 404) {
  //         console.error('File not found on the server. Check the endpoint or the request parameters.');
  //       } else {
  //         console.error('An error occurred:', error);
  //       }
  //     });


  //   } else {
  //     alerts('No project details found in local storage.');
  //   }




  // }


  downloadArchive() {
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");

    let postData = {
      "projectPath": __project_Details.jwspace
    }

    this.dbcomparetoolService.downloadArchive(postData).subscribe((response) => {

      const url = `${projectinfourl}/download/get-archive/`+response['data'];
     
      if(response['data'] == null){
        alerts(response['message']);
      }else{
       
       success("Success Download File");
       window.open(url, '_blank');
      }
    },(err)=>{
      alerts(err.error.message);
    });

}

  





  downloadLog() {

    this.dbcomparetoolService.downloadLog().subscribe((blob) => {
      // Create a new Blob object using the response data
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'gencodex_logs.zip'; // The default filename for the download
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

    }, (error) => {
      alerts("Error while downloading log file");
     
    });


  }


  serveCustomPort() {
    if (
      !this.customPortNumber.match(
        /^([1-9][0-9]{0,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$/
      )
    ) {
      this.invalidPort = true;
    } else {
      this.invalidPort = false;
      $("#portAskingModal").modal("hide");
      let portNumber: any =
        this.customPortNumber.trim() + this.isDisablehostCheck;
      this.stopingPortNo = this.customPortNumber.trim();
      let command: any = this.isAngular8
        ? `node --openssl-legacy-provider ./node_modules/@angular/cli/bin/ng serve --host 0.0.0.0 --port ${portNumber}`
        : `ng serve --host 0.0.0.0 --port ${portNumber}`;
      this.run_Terminal_Commands(command);
    }
  }

  async stopAngularProject() {
    this.shareService.loading++;
    let serveCommand = `npx kill-port ${this.stopingPortNo}`;
    if (window["angularComponentRef"].stopAngularProject) {
      const fun = await window["angularComponentRef"].stopAngularProject;
      await fun(serveCommand);
    }
    setTimeout(() => {
      this.shareService.loading--;
      success(`port ${this.stopingPortNo} stop successfully`);
    }, 2000);
  }

  async convertCssMinify() {
    const chooseProjectPathID = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );
    let selectedFolderPath = this.shareService
      .getDataprotool("projectTreefileDataResponce")
      .path.replaceAll("\\", "/");

    let obj = {
      filePathCollection: this.selectedJsFile,
      folderPath: selectedFolderPath,
      projectPath: chooseProjectPathID.awspace,
    };
    this.shareService.runCssMinifyFile(obj).subscribe(
      (res: any) => {
        if (res["status"] == 200) {
          success(res.message);
        } else {
          alerts(res.message);
        }
      },
      (error) => {
        alerts("internal server error");
      }
    );
  }

  async convertJsMinify(buildFileListObj: any, isObfuscating) {
    let selectedFolderPath = this.shareService
      .getDataprotool("projectTreefileDataResponce")
      .path.replaceAll("\\", "/");
    const chooseProjectPathID = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );

    let obj = {
      filePathCollection: buildFileListObj,
      folderPath: selectedFolderPath,
      projectPath: chooseProjectPathID.awspace,
      isObfuscating: isObfuscating,
    };
    this.shareService.minifiedJsFile(obj).subscribe(
      (res) => {
        if (res["status"] == 200) {
          success(res.message);
        } else {
          alerts(res.message);
        }
      },
      (error) => {
        alerts("internal server error");
      }
    );
  }

  checkJsList(fromEvent, fileType: any) {
    this.isObfuscator = fromEvent;
    const eventdatalist = this.shareService.getDataprotool(
      "projectTreefileDataResponce"
    );
    if (eventdatalist && eventdatalist.type == "folder") {
      this.shareService.getJsFileList(eventdatalist.path, fileType).subscribe(
        (res: any) => {
          if (res["status"] == 200) {
            if (res.result.length > 0) {
              $("#jsFileListModal").modal("show");
              this.selectedJsFile = [];
              this.showJsFileList(res["result"]);
            } else {
              alerts(`folder doesn't have any ${fileType} file`);
            }
          } else {
            alerts(res["message"]);
          }
        },
        (error) => {
          alerts("internal server error");
        }
      );
    } else {
      alerts("Please Select Folder Path..!");
    }
  }
  //////////////////////////////////////////// pankaj work

  // ===============All Projects ================
  customPort(event: any, loaderFlag: boolean) {
    const sessionStoragedatauserId = JSON.parse(
      sessionStorage.getItem("loginFormValueUserID")
    );
    if (sessionStoragedatauserId != undefined) {
      let userId = sessionStoragedatauserId.data.clientInfo.usrId;

      this.dbcomparetoolService.getAngularProjectPort(userId).subscribe(
        (response: any) => {
          if (response["status"] == 200 && response["isOnline"]) {
            let data = response.data;
            let runHostCommand = data["runHostCommand"];
            let angPort = data["angPort"];
            this.startAngularProject(
              event,
              loaderFlag,
              angPort,
              runHostCommand
            );
          } else {
            this.startAngularProject(event, loaderFlag, null, null);
          }
        },
        (err) => {
          this.startAngularProject(event, loaderFlag, null, null);
          console.error("err response");
        }
      );
    } else {
      this.startAngularProject(event, loaderFlag, null, null);
    }
  }

  startAngularProject(event: any, loaderFlag: boolean, port, host) {
    let obj = {
      item: JSON.parse(JSON.stringify(event.item)),
    };
    this._sagStudioService.editAsPreview = false;
    let res;
    if (host) {
      let host1 = Number(prompt("Enter Your Custom Port", host.toString()));
      res = port;
    } else {
      res = Number(
        prompt(
          "Enter Your Custom Port",
          this._sagStudioService.customPortNo.toString()
        )
      );
    }

    if (res) {
      this._sagStudioService.customPortNo = res;
      if (host) {
        obj.item.label = `ng serve -o ${host}`;
      } else {
        // event.item.label = `ng serve -o --port ${res}`;
        obj.item.label = `ng serve --host 0.0.0.0 --port ${res}`;
      }

      if (this._sagStudioService.portsList.indexOf(res) == -1) {
        this._sagStudioService.portsList.push(res);
        this.items.forEach((e: any) => {
          if (e.label == "Run") {
            e["items"].find((innerEle) => {
              if (innerEle.label == "stop-server") {
                innerEle.items.push({
                  label: `stop port ${res}`,
                  icon: "far fa-times-circle",
                  command: (event) => this.stopPort(event, true, res),
                });
              }
            });
          }
        });
      }

      this.runcmd(obj, loaderFlag);
    } else {
      alerts("Please Enter Valid PORT Number !!!");
      return;
    }
  }

  runcmd(event: any, loaderFlag: boolean, isJsMinifyCall?) {
    debugger;
    const chooseProjectPathID = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );

    let path: any = chooseProjectPathID.awspace;
    let command: any = event.item.label;

    loaderFlag ? this.shareService.loading++ : false;
    this.dbcomparetoolService.runCommandApi(path, command).subscribe(
      (response: any) => {
        loaderFlag ? this.shareService.loading-- : false;
        if (response["status"] == 200) {
          this.runCommandData = response["data"];
          if (
            isJsMinifyCall == "callJsMinify" ||
            isJsMinifyCall == "callJsObfuscation"
          ) {
            const angProjectPath = path.replaceAll("/", "\\");
            let reqObj = {
              angProjectPath: angProjectPath,
              sourceFile: this.selectedJsFile,
            };
            this.shareService.get_Build_JsFileList(reqObj).subscribe(
              (res: any) => {
                if (res["status"] == 200) {
                  res.result.map((x) => {
                    delete x.fileName;
                  });
                  let arr = res.result;
                  if (isJsMinifyCall == "callJsObfuscation") {
                    this.convertJsMinify(arr, true);
                  } else {
                    this.convertJsMinify(arr, false);
                  }
                } else {
                  alerts(res["message"]);
                }
              },
              (error) => {
                alerts("internal server error");
              }
            );
          } else {
            success(response.msg);
          }
        }
      },
      (err) => {
        loaderFlag ? this.shareService.loading-- : false;

        console.error("err response");
      }
    );
  }

  stopPort(event, loaderFlag, port) {
    loaderFlag ? this.shareService.loading++ : false;
    this.dbcomparetoolService.runPortApi(port).subscribe(
      (response: any) => {
        loaderFlag ? this.shareService.loading-- : false;
        if (response) {
          this.runCommandData = response["data"];
          this.removePortFromList(port);
        }
      },
      (err) => {
        loaderFlag ? this.shareService.loading-- : false;
        console.error("err response");
      }
    );
  }
  // =======logout=============logout=============logout------------------logout

  // onFileChangeSagStudio(event) {
  //   let self = this;
  //   var file = event.srcElement.files[0];
  //   if (file) {
  //     let reader = new FileReader();

  //     reader.readAsText(file);

  //     reader.onload = function () {
  //       let importedJson = reader.result as string;
  //       self._sagStudioService.sagWorkSpace = parse(importedJson);
  //       self._sagStudioService.allValidationList =
  //         self._sagStudioService.sagWorkSpace.allValidationList;
  //       self._sagStudioService.projectConfig =
  //         self._sagStudioService.sagWorkSpace.projectConfig;
  //       self._sagStudioService.sagBootstrapComponents =
  //         self._sagStudioService.sagWorkSpace.sagBootstrapComponents;
  //       self.ngOnInit();
  //       alert(" File Imported Succeccfully");
  //     };

  //     reader.onerror = function () {};
  //   }
  // }

  // =======================Admin ======================Pankaj====================Wotk=========
  // ======================= ======================Faizan====================Work Start=========
  private dynamicDialogRef: DynamicDialogRef[] = [];
  // close previous open dialogs while opening another dialogs.
  private closePreviousDialog() {
    for (const dialogRef of this.dynamicDialogRef) {
      dialogRef.close();
    }
    this.dynamicDialogRef = [];
  }
  // bundle
  bundle() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(BundleComponent, {
      header: "Bundle",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model bundleTheme module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }
  // Module Set
  moduleSet() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(ModuleSetComponent, {
      header: "Module Set",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }
  // Template Pages
  temPages() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(TemplatePagesComponent, {
      header: "Template Pages",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }
  // Template Pages
  temPlates() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(TemplatesComponent, {
      header: "Templates",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }

  // properties page
  properties() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(PropertiesComponent, {
      header: "Properties",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }
  // Themes @rohitArya
  themes() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(WipthemesComponent, {
      header: "Templates",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }
  controls() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(ControlsComponent, {
      header: "Controls",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }
  controlCopy() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(ControlCopyComponent, {
      header: "Templates-Copy",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }
  // ======================= ======================Faizan====================Work End=========

 regex() {
    this.closePreviousDialog();
    const ref = this.dialogService.open(RegexGeneratorComponent, {
      header: "Regex",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
    this.dynamicDialogRef.push(ref);
  }

  gitPermissionClick() {
    const ref = this.dialogService.open(GitPermissionComponent, {
      header: "Permission",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model pmanagement_modal",
    });
    ref.onClose.subscribe((res) => { });
  }

  WorkAssign() {
    this.shareService.setDataprotool("taskId", null);
    const ref = this.dialogService.open(WorkAssignComponent, {
      header: "Work Assign",
      width: "70%",
      contentStyle: { height: "100%", overflow: "hidden", flexDirection: "column", display: "flex" },
      styleClass: "modal-fullscreen pmanagement_modal sdmtDarkMode",
    });
    ref.onClose.subscribe((res) => {
      this.dbcomparetoolService.createTaskDataHide = false;
    });
  }
  ModuleOwner() {
    const ref = this.dialogService.open(ModuleOwnerComponent, {
      header: "Module Assign",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model pmanagement_modal",
    });
    ref.onClose.subscribe((res) => { });
  }
  userWorkVersionClick() {
    const projectDetails = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );
    if (projectDetails) {
      this.userWorkVersion();
    } else {
      alerts("Please Select Project");
    }
  }
  userWorkVersion() {
    const ref = this.dialogService.open(UserWorkVersionComponent, {
      header: "User Wise working version",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model User_Wise_working",
    });
    ref.onClose.subscribe((res) => { });
  }
  ModulePackageLinkClick() {
    const ref = this.dialogService.open(ModulesPackagesLinkComponent, {
      header: "Module Package Link",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model pmanagement_modal page_link_mode",
    });
    ref.onClose.subscribe((res) => { });
  }
  taskPendingApprovalStatus() {
    const ref = this.dialogService.open(PendingApprovalStatusComponent, {
      header: "Task Pending Approval Status",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model module-all-sets",
    });
    ref.onClose.subscribe((res) => { });
  }

  configureApproval() {
    const __prjDetails = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );
    if (!__prjDetails) {
      alerts("Please Load  One Project ..!!!");
      return;
    }
    this.shareService.setDatadbtool("projectSummaryFlag", "projectSummary");
    const ref = this.dialogService.open(ConfigureApprovalComponent, {
      //header: `Configure project :  ${selectPro.projectname}`,
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model hide_configureapproval drop_modal_new",
    });
    ref.onClose.subscribe((res) => {
      this.sagStudioService.imageCollectionsFlag = true;
      this.shareService.setDatadbtool("projectSummaryFlag", "");
    });
  }

  ProjectInfoTool(url, type) {
    if (
      this.router2 == "/dashboard/studioprojectlist" ||
      this.router2 == "/dashboard/sagstudiodashboard"
    ) {
      alerts("Please Load One Project !");
      return;
    }
    // document.getElementById("dashSideBar").classList.remove("d-none");
    this.tooltipIcon = true;
    this.onDashboardList(url, type);
    // setTimeout(() => {
    //   this.onDashboardList(url, type);
    // }, 50);
    this.shareService.setDataprotool("dataType", type);
    this.shareService.setDataprotool("dataTypeWorkSpace", "");
    switch (url) {
      case "PMT": {
        this._router.navigate([url]);
        break;
      }
      case "PMTConfiguration(Acc)": {
        this._router.navigate([url]);
        break;
      }
      case "ModulePackageLink": {
        this._router.navigate([url]);
        break;
      }
      case "DBConfiguration": {
        this._router.navigate([url]);
        break;
      }
      case "DBSummary": {
        this._router.navigate([url]);
        break;
      }
      case "DBDetail": {
        this._router.navigate([url]);
        break;
      }
      case "Assign(to be)": {
        this._router.navigate([url]);
        break;
      }
      case "AssignedWork": {
        this._router.navigate([url]);
        break;
      }
      case "Approval": {
        this._router.navigate([url]);
        break;
      }
      case "Documentation": {
        this._router.navigate([url]);
        break;
      }
      case "SagVersionControl": {
        this._router.navigate([url]);
        break;
      }
      case "Problems": {
        this._router.navigate([url]);
        break;
      }
      case "History": {
        this._router.navigate([url]);
        break;
      }
      case "Saggestions": {
        this._router.navigate([url]);
        break;
      }
      default:
        break;
    }

    this._router.navigate([url]);
  }
  // =======================Admin ======================Pankaj====================Wotk=========
  addShowView(type) {
    this.StudioDragDropService.showViewNode[type] = true;
    this.cdRef.detectChanges();
  }

  // ==========================use workspace ======================createBy pankaj singh==========
  projectutilityExplorerClick(selector: any) {
    this._sagStudioService.pageDi["restoreSectionHandler"](selector);
  }
  projectutilityEditorClick(selector: any) {
    this._sagStudioService.pageDi["restoreSectionHandler"](selector);
  }
  // ==========================use workspace ======================createBy pankaj singh==========
  async projectChangePath(type: any) {
    let self = this;
    let url = this.router.url;
    this._sagStudioService.footerTabBar = false;
    this.shareService.modeBoolean = false;
    if (url != "/dashboard") {
      let conf = await ui.confirm("Do You Want To Change Project? ");
      if (conf == true) {
        if (type == "theiaEditor") {
          this.beforeChangeProject();
        } else {
          self.openProjectDialogBox();
        }
        // this.router.navigate(["/dashboard"]);
      }
    } else {
      self.openProjectDialogBox();
    }
  }

  openProjectDialogBox() {
    const ref = this.dialogService.open(ChooseProjectComponent, {
      header: "Choose Project",
      width: "80%",
      contentStyle: { height: "500px" },
      styleClass: "chooseproject_modal",
    });
    ref.onClose.subscribe((res) => {
      console.info(res);
      res == "projectLoaded"
        ? this.onDashboardList("dashboard/UIbuilder", "UIbuilder")
        : false;
    });
  }

  openProjectsLoadProject() {
    const ref = this.dialogService.open(ChooseProjectComponent, {
      header: "Choose Project",
      width: "80%",
      contentStyle: { height: "500px" },
      styleClass: this._sagStudioService.selectedProjectData
        ? "invisible"
        : " chooseproject_modal ",
      data: {
        skipLoading: this._sagStudioService.selectedProjectData ? true : false,
      },
    });
    ref.onClose.subscribe((res) => {
      res == "projectLoaded"
        ? this._router.navigate(["dashboard/UIbuilder"])
        : false;
    });
  }

  //addModule popup open
  addModulePopup() {
    const refs = this.dialogService.open(AddModuleComponent, {
      header: "Add Module",
      width: "60%",
      contentStyle: { height: "400px", overflow: "auto" },
    });
    refs.onClose.subscribe((res) => {
      console.info(res);
    });
  }

  ngOnDestroy() {
    this.subscription ? this.subscription.unsubscribe() : false;
    this.callMethodSubscription.unsubscribe();
  }

  /***user role list */
  getRoleList() {
    let roleName = "ALL";
    this._apiService.userRolePre(roleName).subscribe((res) => {
      this._sagStudioService.userRolePermission = JSON.parse(
        JSON.stringify(res[`roleRights`])
      );
      this._sagStudioService.roleUserProperties = JSON.parse(
        JSON.stringify(res[`roleProperties`])
      );
    });
  }

  async saveHtmlFromJson(type) {
    //loadDataTreeType  use variable for load Tree in WorkSpace working by pankajsingh
    this.shareService.setDataprotool("loadDataTreeType", "ProjectType");
    //loadDataTreeType  use variable for load Tree in WorkSpace working by pankajsingh
    const node = this._sagStudioService.getSagStudioData(
      "currentNodeForFileView"
    );
    const finalPath = node.projectPath;
    let projectSagJson = this._sagStudioService.sagWorkSpace.projectList.find(
      (item) =>
        item.id == this._sagStudioService.sagWorkSpace.currentActiveProjectId
    );
    let completeJsonWithContainer = projectSagJson.subDataArray.find(
      (item) => item.matchableId == node.matchableId
    );
    const allServiceList = projectSagJson.serviceList || [];
    this._sagStudioService.completeJsonWithContainer =
      completeJsonWithContainer;
    const filecontent = await this._writeNgFile.genJsonToCode(
      node,
      completeJsonWithContainer,
      allServiceList
    );
    const res = await this.shareService
      .writeFile(
        this.StudioDragDropService.getLocalFilePath(finalPath),
        new Blob([filecontent], { type: "application/html" })
      )
      .toPromise();
    // this._sagStudioService.writeStudioJsonInProject();
    success("Saved Succesfully !!!");
  }

  saveAllFileComponentDisable: boolean = false;
  saveAllFileComponentOpen(event: any) {
    this.saveAllFileComponentDisable = true;
    const refEle = this.dialogService.open(SaveAllFileComponent, {
      header: "Save All File",
      width: "80%",
      contentStyle: { height: "500px" },
    });
    refEle.onClose.subscribe((res) => {
      this.saveAllFileComponentDisable = false;
    });
  }
  async saveQuickAllFile() {
    const allRows = this._sagStudioService.unSavedFileList;
    let readrightsFiles = this.StudioDragDropService.onlyReadRightsOnfiles;
    if (readrightsFiles && readrightsFiles.length > 0) {
      let allNewRows = allRows.filter(
        (element) => !readrightsFiles.includes(element.path)
      );
      this._sagStudioService.unSavedFileList = [];
      await this._writeNgFile.saveUnSaveMethod(allNewRows);
    } else {
      await this._writeNgFile.saveUnSaveMethod(allRows);
    }
    if (this._sagStudioService.recondForIndexFile) {
      if (
        this._sagStudioService.recondForIndexFile.css &&
        this._sagStudioService.recondForIndexFile.css.length > 0
      ) {
        this._sagStudioService.recondForIndexFile.css.forEach((cssData) => {
          if (!cssData["fileInfo"]) {
            cssData["fileInfo"] = [];
            cssData["selected"] = false;
          }
          if (cssData["count"] == 0) {
            cssData["usedFileJson"] = [];
          }
        });
      }
      if (
        this._sagStudioService.recondForIndexFile.js &&
        this._sagStudioService.recondForIndexFile.js.length > 0
      ) {
        this._sagStudioService.recondForIndexFile.js.forEach((jsData) => {
          if (!jsData["fileInfo"]) {
            jsData["fileInfo"] = [];
            jsData["selected"] = false;
          }
          if (jsData["count"] == 0) {
            jsData["usedFileJson"] = [];
          }
        });
      }
    }
    let cssUsedCtrlsInFile = [];
    let jsUsedCtrlsInFile = [];
    let cssList = this._sagStudioService.recondForIndexFile.css;
    let jsList = this._sagStudioService.recondForIndexFile.js;

    for (let cs = 0; cs < cssList.length; cs++) {
      if (
        cssList[cs] &&
        cssList[cs].fileInfo &&
        cssList[cs].fileInfo.length > 0
      ) {
        cssList[cs].fileInfo.forEach((f) => {
          cssUsedCtrlsInFile.push(f.filePath);
        });
      }
    }
    for (let js = 0; js < jsList.length; js++) {
      if (jsList[js] && jsList[js].fileInfo && jsList[js].fileInfo.length > 0) {
        jsList[js].fileInfo.forEach((f) => {
          jsUsedCtrlsInFile.push(f.filePath);
        });
      }
    }
    cssUsedCtrlsInFile = [...new Set(cssUsedCtrlsInFile)];
    jsUsedCtrlsInFile = [...new Set(jsUsedCtrlsInFile)];

    let commonFileList = [...cssUsedCtrlsInFile, ...jsUsedCtrlsInFile];
    let noDuplicateFiles = [...new Set(commonFileList)];

    debugger;
    if (noDuplicateFiles && noDuplicateFiles.length > 0) {
      for (let ind = 0; ind < noDuplicateFiles.length; ind++) {
        this.saveIndexInformation(noDuplicateFiles[ind]);
      }
    }
  }
  async saveIndexInformation(filename) {
    let currentLtyList = JSON.parse(
      JSON.stringify(this._sagStudioService.recondForIndexFile)
    );
    let cssList = currentLtyList.css;
    let jsList = currentLtyList.js;

    for (let cs = 0; cs < cssList.length; cs++) {
      if (cssList[cs].fileInfo && cssList[cs].fileInfo.length > 0) {
        let getUsedFile = {};
        cssList[cs].fileInfo.forEach((getF) => {
          if (getF.filePath == filename) {
            getUsedFile = getF;
          }
        });
        cssList[cs].fileInfo = [];
        if (getUsedFile && getUsedFile["filePath"]) {
          cssList[cs].fileInfo.push(getUsedFile);
        }
      }
    }
    for (let js = 0; js < jsList.length; js++) {
      if (jsList[js].fileInfo && jsList[js].fileInfo.length > 0) {
        let getUsedFile = {};
        jsList[js].fileInfo.forEach((getF) => {
          if (getF.filePath == filename) {
            getUsedFile = getF;
          }
        });
        jsList[js].fileInfo = [];
        if (getUsedFile && getUsedFile["filePath"]) {
          jsList[js].fileInfo.push(getUsedFile);
        }
      }
    }

    await this.shareService
      .saveUsedCssJsProject(currentLtyList)
      .subscribe((res) => {
        debugger;
        // console.log(res)
      });
  }
  showDataBasepopup: boolean = false;
  databaseConnection() {
    if (this.showDataBasepopup == false) {
      const dbConnection = this.dialogService.open(
        DatabaseConnectionComponent,
        {
          header: "Database",
          width: "45%",
          transitionOptions: "00ms cubic-bezier(0.25, 0.8, 0.25, 1)",
          styleClass: "database_connection",
          contentStyle: { height: "200px", "background-color": "#faf0f0" },
        }
      );
      this.showDataBasepopup = true;

      dbConnection.onClose.subscribe((res) => {
        this.showDataBasepopup = false;
        this.connection_data = this.shareService.getDatadbtool(
          "finalDataForConnection"
        );
      });
    } else {
      /* this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: 'Window was just opened !!!...',
      }); */
    }
  }

  //-------------------------------------Java---------------------------------------------------
  consoleClear() {
    this.javaConsole = "";
    // $("#output").val("");
  }

  nIntervId = null;

  javaConsole = "";
  @ViewChild("javaProjectConsoleVal", { static: false, read: ElementRef })
  public javaProjectConsoleVal: ElementRef;

  _getReqObjForRunJavaProject() {
    let setProjectInfo = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );
    const sessionStoragedatauserId = JSON.parse(
      sessionStorage.getItem("loginFormValueUserID")
    );
    let userId = sessionStoragedatauserId.data.clientInfo.usrId;

    if (setProjectInfo != undefined) {
      let javaworkspace = setProjectInfo.jwspace;
      if (
        javaworkspace != undefined &&
        javaworkspace != null &&
        javaworkspace != ""
      ) {
        let reqObj = {
          javaworkspace: javaworkspace,
          userId: userId,
        };

        return reqObj;
      } else {
        alerts("java workspace not set");
        return null;
      }
    } else {
      alerts("java workspace not set");
      return null;
    }
  }

  mavenClean(event: any, loaderFlag: boolean) {
    let reqObj = this._getReqObjForRunJavaProject();
    if (reqObj != null) {
      $("#javaProjectConsole").modal("show");
      if (!this.nIntervId) {
        this.nIntervId = setInterval(this.getMavenLog.bind(this), 2000);
      }
      //   this.timerSubscription=timer(0, 2000).pipe(map(() => {
      //    this.getMavenLog();
      //   })
      // ).subscribe();
      this.autoJavacodeService.mavenClean(reqObj).subscribe(
        (res) => {
          if (res.status == 500) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          }
        },
        (Error) => {
          clearInterval(this.nIntervId);
          this.nIntervId = null;
          alerts("Error While Feching");
        }
      );
    }
  }

  mavenInstall(event: any, loaderFlag: boolean, packagingType) {
    let reqObj = this._getReqObjForRunJavaProject();

    if (reqObj != null) {
      reqObj["packagingType"] = packagingType;
      $("#javaProjectConsole").modal("show");
      if (!this.nIntervId) {
        this.nIntervId = setInterval(this.getMavenLog.bind(this), 2000);
      }

      this.autoJavacodeService.mavenInstall(reqObj).subscribe(
        (res) => {
          if (res.status == 500) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          } else {
            if (res.status == 200) {
              success(`Sucessfully generated <br> Location : ${res.data}`);
            }
          }
        },
        (Error) => {
          clearInterval(this.nIntervId);
          this.nIntervId = null;
          alerts("Error While Feching");
        }
      );
    }
  }

  startJavaProject(event: any, loaderFlag: boolean) {
    let reqObj = this._getReqObjForRunJavaProject();
    if (reqObj != null) {
      $("#javaProjectConsole").modal("show");
      if (!this.nIntervId) {
        this.nIntervId = setInterval(this.getProjectRunLog.bind(this), 2000);
      }

      this.autoJavacodeService.restartJavaProject(reqObj).subscribe(
        (res) => {
          if (res.status == 500) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          }
        },
        (Error) => {
          clearInterval(this.nIntervId);
          this.nIntervId = null;
          alerts("Error While Feching");
        }
      );
    }
  }

  stopJavaProject(event: any, loaderFlag: boolean) {
    let reqObj = this._getReqObjForRunJavaProject();
    if (reqObj != null) {
      this.autoJavacodeService.stopJavaProject(reqObj).subscribe(
        (res) => {
          if (res.status == 500) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          }
        },
        (Error) => {
          clearInterval(this.nIntervId);
          this.nIntervId = null;
          alerts("Error While Feching");
        }
      );
    }
  }

  restartJavaProject(event: any, loaderFlag: boolean) {
    let reqObj = this._getReqObjForRunJavaProject();
    if (reqObj != null) {
      $("#javaProjectConsole").modal("show");
      if (!this.nIntervId) {
        this.nIntervId = setInterval(this.getProjectRunLog.bind(this), 1000);
      }

      this.autoJavacodeService.restartJavaProject(reqObj).subscribe(
        (res) => {
          if (res.status == 500) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          }
        },
        (Error) => {
          clearInterval(this.nIntervId);
          this.nIntervId = null;
          alerts("Error While Feching");
        }
      );
    }
  }

  getMavenLog() {
    this.javaConsole = "";
    const sessionStoragedatauserId = JSON.parse(
      sessionStorage.getItem("loginFormValueUserID")
    );
    let userId = sessionStoragedatauserId.data.clientInfo.usrId;

    this.autoJavacodeService.getMavenLog(userId).subscribe(
      (res) => {
        if (res != null) {
          let log = res.log;
          this.javaConsole = log;
          this.setCursorInLast();
          if (res.flag) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          }
        }
      },
      (Error) => {
        clearInterval(this.nIntervId);
        this.nIntervId = null;
        alerts("Error While Feching");
      }
    );
  }
  getProjectRunLog() {
    //this.javaConsole="";
    const sessionStoragedatauserId = JSON.parse(
      sessionStorage.getItem("loginFormValueUserID")
    );
    let userId = sessionStoragedatauserId.data.clientInfo.usrId;

    this.autoJavacodeService.getProjectRunLog(userId).subscribe(
      (res) => {
        if (res != null) {
          let log = res.log;
          if (this.javaConsole != log) {
            this.javaConsole = log;

            setTimeout(() => {
              this.setCursorInLast();
            }, 5);
          }

          if (res.flag) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          }
        }
      },
      (Error) => {
        clearInterval(this.nIntervId);
        this.nIntervId = null;
        alerts("Error While Feching");
      }
    );
  }

  setCursorInLast() {
    this.javaProjectConsoleVal.nativeElement.scrollTop =
      this.javaProjectConsoleVal.nativeElement.scrollHeight;
  }

  startSpringBootJavaProject(event: any, loaderFlag: boolean) {
    let reqObj = this._getReqObjForRunJavaProject();
    if (reqObj != null) {
      $("#javaProjectConsole").modal("show");
      if (!this.nIntervId) {
        this.nIntervId = setInterval(this.getProjectRunLog.bind(this), 3000);
      }

      this.autoJavacodeService.startSpringBootJavaProject(reqObj).subscribe(
        (res) => {
          if (res.status == 500) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          }
        },
        (Error) => {
          clearInterval(this.nIntervId);
          this.nIntervId = null;
          alerts("Error While Feching");
        }
      );
    }
  }

  stopSpringBootJavaProject(event: any, loaderFlag: boolean) {
    let reqObj = this._getReqObjForRunJavaProject();
    if (reqObj != null) {
      this.autoJavacodeService.stopSpringBootJavaProject(reqObj).subscribe(
        (res) => {
          success("successfully stop java project");
          if (res.status == 500) {
            clearInterval(this.nIntervId);
            this.nIntervId = null;
          }
        },
        (Error) => {
          clearInterval(this.nIntervId);
          this.nIntervId = null;
          alerts("Error While Feching");
        }
      );
    }
  }

  npmInstallMethod() {
    const event = {
      originalEvent: {
        isTrusted: true,
      },
      item: {
        label: "npm install",
        icon: "fab fa-instalod",
      },
    };
    this.runcmd(event, true);
  }
  playMethod() {
    const event = {
      originalEvent: {
        isTrusted: true,
      },
      item: {
        label: `ng serve --host 0.0.0.0 --port ${this._sagStudioService.customPortNo}`,
        icon: "fas fa-server",
      },
    };
    this._sagStudioService.editAsPreview = true;
    this.customPort(event, false);
    // this.runcmd(event, false);
  }
  serverStopMethod() {
    const event = {
      originalEvent: {
        isTrusted: false,
      },
      item: {
        label: "stop-server",
        icon: "far fa-times-circle",
      },
    };
    this.stopPort(event, true, this._sagStudioService.customPortNo);
  }

  // Made by kawaljeet
  sagEditorToggle() {
    let a = document.getElementById("sagEditorchekboxid") as any;
    if (a.checked == true) {
      const style = document.createElement("style");
      style.type = "text/css";
      style.innerHTML = "p-dynamicdialog {display:none}";
      style.classList.add("style_to_hide_component");
      style.id = "style-tag";
      document.getElementsByTagName("head")[0].appendChild(style);
      this.tooltipTitle = "BackToPrevious";
      return;
    }
    if (a.checked == false) {
      const styleTag = document.getElementById("style-tag");
      if (!styleTag) return;
      document.getElementsByTagName("head")[0].removeChild(styleTag);
      this.tooltipTitle = "SagEditor";
      return;
    }
  }
  // Deepak Designer
  click_pro() {
    if (
      this._sagStudioService.pageDi["domElements"]["propSidebar"]["display"]
    ) {
      this._sagStudioService.pageDi["domElements"]["propSidebar"]["display"] =
        !this._sagStudioService.pageDi["domElements"]["propSidebar"]["display"];
    }
  }

  generateApk() {
    const generateapkfile = this.dialogService.open(GenerateApkComponent, {
      header: "Generate ",
      width: "45%",
      transitionOptions: "00ms cubic-bezier(0.25, 0.8, 0.25, 1)",
      styleClass: "generate_connection",
      contentStyle: { "background-color": "#faf0f0" },
    });

    generateapkfile.onClose.subscribe((res) => { });
  }

  /*  buildForMobile(){
     const buildMobApp = this.dialogService.open(BuildMobileAppComponent, {
       header: "Build Mobile App ",
       width: "45%",
       transitionOptions: "00ms cubic-bezier(0.25, 0.8, 0.25, 1)",
       styleClass: "generate_connection",
       contentStyle: { "background-color": "#faf0f0" },
     });
 
     buildMobApp.onClose.subscribe((res) => { });
 
   } */

  sagEditor() {
    this.shareService.loading++;

    this.shareService.showEditor("hide");
    let mainBody = document.querySelector("body");
    mainBody.classList.remove("theiaEditor");
    // this.loading = true;
    let DefaultString = `<html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Document</title></head><body><div><h1 style="padding-left: 400px;">Ready to Begin</h1></div></body></html>`;
    // sessionStorage.clear();
    sessionStorage.setItem("fileData", DefaultString);
    this.router.navigate(["dashboard/sageditor/wordFileUpload"]);
    this.shareService.loading--;
  }

  //tool box data update
  getToolBoxData() {
    this._sagStudioService.sagToolBoxData();
    this._sagStudioService.sagWindowProps();
  }

  moduelSetEvent = {
    data: {
      // moduleId: 71,
      sagToolSelected: "",
      moduleSubType: "GENERAL TEMPLATE",
    },
  };

  openModuleSets() {
    if (this.moduelSetEvent.data.sagToolSelected == "moduleSets") {
      this.toast.launch_toast({
        type: "alert",
        position: "bottom-right",
        message: "Module Set Already Opened !!...",
      });
    } else {
      this.moduelSetEvent = {
        data: {
          sagToolSelected: this.sagToolSelected,
          moduleSubType: "GENERAL TEMPLATE",
        },
      };
      this.onModulesSetDrop(this.moduelSetEvent, [], {}, 0);
    }
  }

  removePortFromList(port) {
    let inx = this._sagStudioService.portsList.indexOf(port);
    if (inx != -1) {
      this._sagStudioService.portsList.splice(inx, 1);
      this.items.forEach((e: any) => {
        if (e.label == "Run") {
          e["items"].find((innerEle) => {
            if (innerEle.label == "stop-server") {
              innerEle.items.splice(inx, 1);
              return;
            }
          });
        }
      });
    }
  }

  clearConsole() {
    this.javaConsole = "";
    const sessionStoragedatauserId = JSON.parse(
      sessionStorage.getItem("loginFormValueUserID")
    );
    let userId = sessionStoragedatauserId.data.clientInfo.usrId;
    if (userId) {
      this.autoJavacodeService.clearConsole(userId).subscribe((res) => { });
    }
  }

  ngBuild(event, build: any, isJsMinifyCall?) {
    const selectedProject = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );
    let name: any = selectedProject.projectname;
    var command = {
      item: {
        label:
          build == "buildProd"
            ? `${event.item.label} --base-href /${name}/`
            : `ng build`,
      },
    };

    this.runcmd(command, true, isJsMinifyCall);
  }

  sdmtDashboard() {
    const refMethod = this.dialogService.open(SdmtDashboardComponent, {
      width: "100%",
      //header: 'SagGrid Name',
      baseZIndex: 10000,
      rtl: true,
      styleClass: "service_full_model",
    });
    refMethod.onClose.subscribe((sagGridName) => { });
  }

  async onModulesSetDrop(event, list, item, index) {
    this._sagStudioService.deviceForWebOrMobile = "Modules Set";
    let resModuleId = await this.shareService
      .getModuleSetId(event.data.moduleSubType)
      .toPromise();
    const postData = {
      ctrlId: resModuleId["moduleId"],
      type: "templateList",
    };

    let resTemplates = await this.shareService
      .getPageTemplateData(postData)
      .toPromise();
    let pages =
      resTemplates["data"] && resTemplates["data"]["pages"]
        ? resTemplates["data"]["pages"]
        : false;
    // let pages = item.modules.filter(e => e.type == "predefinedNode");
    const refMethod = this.dialogService.open(ModulesDropComponent, {
      width: "30%",
      header: "Modules Set",
      data: {
        methodData: "Module Set",
        item: item,
        list: list,
        index: index,
        pages: pages,
        moduleId: resModuleId["moduleId"],
        from: "genFromModuleSet",
      },
      // baseZIndex: 1000,
      showHeader: false,
      rtl: true,
      styleClass: "service_full_model drop_modal_new",
    });
    refMethod.onClose.subscribe(async (finData) => {
      event.data.sagToolSelected = "I am closed";
    });
  }

  callMethodSubscription: Subscription;

  async callMethod(resObj) {
    const methodName = resObj.methodName;
    const args: {} = resObj.args;
    switch (methodName) {
      case "openDialogCodeGenStepper": {
        await this.openDialogCodeGenStepper(
          args["0"],
          args["1"],
          args["2"],
          args["3"]
        );
        break;
      }
      case "openNgSelectorCodeGenStepper": {
        await this.openNgSelectorCodeGenStepper(
          args["0"],
          args["1"],
          args["2"],
          args["3"]
        );
        break;
      }
      default:
        break;
    }
  }

  openDialogCodeGenStepper(item: any, list: any, index: any, selPageItem: any) {
    const refMethod = this.dialogService.open(CodeGenStepperComponent, {
      width: "30%",
      header: "Generate CRUD Code",
      data: {
        methodData: "genCRUDCode",
        item: item,
        list: list,
        index: index,
        selPageItem: selPageItem,
        from: "genCRUDCode",
      },
      baseZIndex: 1000,
      rtl: true,
      styleClass: "service_full_model",
    });
    refMethod.onClose.subscribe(async (finData) => {
      // await this.writeModules(finData,list,item,index);
      return;
    });
  }

  openNgSelectorCodeGenStepper(
    item: any,
    list: any,
    index: any,
    selPageItem: any
  ) {
    const refMethod = this.dialogService.open(CodeGenStepperComponent, {
      width: "30%",
      header: "Generate Angular Selector",
      data: {
        methodData: "genNgSelector",
        item: item,
        list: list,
        index: index,
        selPageItem: selPageItem,
        from: "genNgSelector",
      },
      baseZIndex: 1000,
      rtl: true,
      styleClass: "service_full_model",
    });
    refMethod.onClose.subscribe(async (finData) => {
      // await this.writeModules(finData,list,item,index);
      return;
    });
  }
  sagStudioDashboard() {
    const ref = this.dialogService.open(SagstudioDashboardComponent, {
      header: "Sagstudio Dashboard",
      width: "70%",
      contentStyle: { height: "575px" },
      styleClass: "service_full_model",
    });
    ref.onClose.subscribe((res) => {
      //this.dbcomparetoolService.createTaskDataHide = false;
    });
  }
  // openProjectFiles(){
  //   debugger
  //   const ref = this.dialogService.open(ProjectExploralFileListComponent, {
  //     header: "Project Files List",
  //     width: '80%',
  //     contentStyle: { "height": "600px", },
  //   });
  //   ref.onClose.subscribe((res) => {
  //     this.sagStudioService.imageCollectionsFlag = true;
  //   });

  // }

  async translateAgainCurrentPage() {
    const projectInfo = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );
    const currentNode =
      this._sagStudioService.currentActiveProject.currentActiveFileNode;
    let proPath = projectInfo.awspace
      .split("/")
      .slice(0, projectInfo.awspace.split("/").length - 1)
      .join("/");
    let obj = {
      matchableId: currentNode.matchableId,
      fName: currentNode.angularScemeticName,
      path: proPath + "/" + currentNode.projectPath,
      projectSubtype: currentNode.projectSubtype,
    };
    debugger;
    const sessionStoragedatauserId = JSON.parse(
      sessionStorage.getItem("loginFormValueUserID")
    );
    this._sagStudioService.englishLangFileData["projectId"] =
      projectInfo["projectId"];
    this._sagStudioService.englishLangFileData["userId"] =
      sessionStoragedatauserId.data.clientInfo.usrId;
    let projectSagJson = this._sagStudioService.sagWorkSpace.projectList.find(
      (item) =>
        item.id == this._sagStudioService.sagWorkSpace.currentActiveProjectId
    );
    let completeJsonWithContainer = projectSagJson.subDataArray.find(
      (item) => item.matchableId == obj.matchableId
    );
    const allServiceList =
    [...projectSagJson.sharedServiceList, ...projectSagJson.serviceList];
    await this._writeNgFile.genJsonToCodeByProjSubtype(
      obj.projectSubtype,
      completeJsonWithContainer,
      allServiceList
    );
    this.shareService
      .setLangCtrlJson(this._sagStudioService.englishLangFileData)
      .subscribe((res) => {
        if (res) {
          this._sagStudioService.languageJsonIcon = true;
          this._sagStudioService.setEngLangJson();
        }
      });
  }
  generateEnJson() {
    const __prjDetails = this.shareService.getDataprotool(
      "selectedProjectChooseData"
    );
    const reqObj = {
      projectId: __prjDetails["projectId"],
      projectPath: __prjDetails["awspace"].replace(
        "/" + __prjDetails["projectname"],
        ""
      ),
      projectName: __prjDetails["projectname"],
    };
    this.dbcomparetoolService.regenEnJson(reqObj).subscribe(
      (response: any) => {
        if (response["status"] == "success") {
          success(response["message"]);
        } else if (response["status"] == "failure") {
          alerts(response["message"]);
        }
      },
      (error) => {
        alerts("Error While right");
      }
    );
  }

  // for lightModeToggle
  isDarkModeMoon: any;
  isLightModeSun: any;

  // jsonToHtmlCode(){

  //   debugger
  //   let event = {}
  //   event['data'] = {}
  //   // this.StudioDragDropService.onDrop(event,'','','','',"")
  // }

  // subMenuLoad() {
  //   document.addEventListener("DOMContentLoaded", function () {
  //     let toggles = document.querySelectorAll(".toggless");

  //     toggles.forEach(function (toggless) {
  //       toggless.addEventListener("click", function (e) {
  //         e.preventDefault();
  //         let parentLi = this.parentElement;
  //         let submenu = this.nextElementSibling;

  //         if (parentLi.classList.contains("active")) {
  //           parentLi.classList.remove("active");
  //           submenu.style.maxHeight = null;
  //         } else {
  //           parentLi.classList.add("active");
  //           submenu.style.maxHeight = submenu.scrollHeight + "px";
  //         }
  //       });
  //     });
  //   });
  // }

  gridData_jsFileList: any;
  gridDynamicObj_jsFileList: any;
  columnData_jsFileList: any = [
    {
      header: "",
      field: "checkbox",
      filter: false,
      width: "50px",
      editable: "false",
      "text-align": "center",
      search: false,
      component: "headerCheckBox",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "S.No.",
      field: "sno",
      filter: false,
      width: "50px",
      editable: "false",
      "text-align": "left",
      search: true,
      component: "label",
      cellRenderView: true,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
    {
      header: "Name",
      field: "fileName",
      filter: false,
      width: "300px",
      editable: "false",
      "text-align": "left",
      search: false,
      component: "label",
      cellRenderView: false,
      freezecol: "null",
      hidden: false,
      sort: false,
      cellHover: false,
    },
  ];
  rowData_jsFileList: any = [{}, {}, {}, {}];

  showJsFileList(rowData?, colData?) {
    let self = this;

    this.gridData_jsFileList = {
      columnDef: colData ? colData : this.columnData_jsFileList,
      rowDef: rowData ? rowData : this.rowData_jsFileList,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: true,
      common_search_column: "all",
      common_filter: false,
      common_filter_column: "",
      exportBtn: false,
      validation: "",
      newPagination: false,
      recordPerPage: 10,
      commonSearchSelect_hide: true,
      components: {},
      callBack: {},
      rowCustomHeight: 25,
    };

    let sourceDiv = document.getElementById("jsFileList");
    this.gridDynamicObj_jsFileList = SdmtGridT(
      sourceDiv,
      this.gridData_jsFileList,
      true,
      true
    );
  }

  async continueWithBuild() {
    let selectedFl =
      this.gridDynamicObj_jsFileList.getCheckedDataParticularColumnWise();
    if (selectedFl && selectedFl.length > 0) {
      let event = {
        item: { label: "ng build " },
      };
      this.selectedJsFile = selectedFl.map((x) => x.filePath);
      let conf: any;
      switch (this.isObfuscator) {
        case "obfus_build":
          conf = await ui.confirm(
            "obfuscation will be done inside build, are you sure for creating builid ?"
          );
          conf ? this.ngBuild(event, "build", "callJsObfuscation") : "false";
          break;
        case "js_Minify":
          conf = await ui.confirm(
            "minification will be done inside build, are you sure for creating builid ?"
          );
          conf ? this.ngBuild(event, "build", "callJsMinify") : "false";
          break;
        case "css_Minify":
          conf = await ui.confirm(
            "minification will be done on selected files location, do you want to continue ?"
          );
          conf ? this.convertCssMinify() : "false";
          break;
        default:
          conf = await ui.confirm("do you want to continue ?");
      }
      conf ? $("#jsFileListModal").modal("hide") : "false";
    } else {
      alerts("please select at least one file..!");
    }
  }
  // showing pop up on click of create page using image
  modelTwo() {
    const currentPath = this._sagStudioService.currentActiveFilePath;
    if (currentPath.includes("component.html")) {
      this.showModal = currentPath.includes("sag.component.html");
    } else {
      this.showModal = true;
    }

    // Control the modal visibility based on the condition
    if (this.showModal) {
      // jQuery to show the Bootstrap modal
      ($ as any)("#myModal").modal("show");
    } else {
      // If using Angular dialog service
      this.closePreviousDialog();
      const height = this.showModal ? "300px" : "575px";
      const ref = this.dialogService.open(ModelTwoComponent, {
        header: "Select The Page",
        width: "30%",
        contentStyle: { height: height },
        data: { showModal: this.showModal },
        // baseZIndex: 99999999,
      });
      ref.onClose.subscribe((res) => { });
      this.dynamicDialogRef.push(ref);
    }
  }
  showSidebar: boolean = true;

  toggleBtnClick() {
    this.showSidebar = !this.showSidebar
    let sidebar = document.querySelector(".sidebarArea");
    if(sidebar) {
      sidebar.classList.add("d-none");
      if (this.showSidebar) {
        sidebar.classList.add("d-none");
      } else {
        sidebar.classList.remove("d-none");
      }
    }
    let btnSwth = document.querySelector('.swithBtn');
    if(btnSwth) {
      btnSwth.classList.toggle('active')
    }
  }
 
  aitoolmodaldesign() {
    let offset: any = {}
    let dom = document.getElementById("dragme");
    dom.addEventListener('dragstart', (ev: any) => {
      offset.x = ev.clientX - ev.target.getBoundingClientRect().x;
      offset.y = ev.clientY - ev.target.getBoundingClientRect().y;
    })
    dom.addEventListener('dragend', (ev: any) => {
      ev.target.style.top = (ev.clientY - offset.y) + 'px';
      ev.target.style.left = (ev.clientX - offset.x) + 'px';
      console.log(offset, ev.clientY - offset.y)
    })
  }


// onDragOver(ev){
//   let offset:any = {}
//   offset.x = ev.clientX - ev.target.getBoundingClientRect().x;
//   offset.y = ev.clientY - ev.target.getBoundingClientRect().y;
//   ev.target.style.top = (ev.clientY - offset.y) + 'px';
//   ev.target.style.left = (ev.clientX - offset.x) + 'px';
//   console.log(offset, ev.clientY - offset.y) 
// }
// onDragLeave(ev){
//   let offset:any = {}
//   ev.target.style.top = (ev.clientY - offset.y) + 'px';
//   ev.target.style.left = (ev.clientX - offset.x) + 'px';
//   // console.log(offset, ev.clientY - offset.y) 
// }
  // Open component on click of sagAI floating button menu tab changes by @AnkitSagar
  AiFundamentalsGenerate(type) {
    this.closePreviousDialog();
    const ref = this.dialogService.open(AiFundamentalsComponent, {
      header: 'Ai Fundamentals Generate',
      width: '60%',
      data: { type : type, properties:{label:''} },
      style: {"margin-left": "150px"},
       baseZIndex: 9999,
    });
    ref.onClose.subscribe((res) => {});
    this.dynamicDialogRef.push(ref);
  }

  projectBackup(){
   
    const ref = this.dialogService.open(CreateProjectBackupComponent, {
      header: 'Backup Management',
      contentStyle: { "margin-top": "0px", "height": "500px" },
      width: '700px',
      data: {},
      
      
    });
    ref.onClose.subscribe((res) => {});
    this.dynamicDialogRef.push(ref);
  }

}
