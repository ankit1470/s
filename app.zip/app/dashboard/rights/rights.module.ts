import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RightsRoutingModule } from './rights-routing.module';
import { TreeModule } from 'primeng/tree';
import { RightsComponent } from './rights.component';
import { SharedModule } from 'src/app/core/shared/shared.module';
import { DropdownModule } from 'primeng/dropdown';


@NgModule({
  declarations: [RightsComponent],
  imports: [
    CommonModule,
    RightsRoutingModule,
    TreeModule,
    SharedModule,
    DropdownModule,
  ],exports:[RightsComponent]
})
export class RightsModule { }
