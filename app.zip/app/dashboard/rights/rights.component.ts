import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DialogService, DynamicDialogRef } from 'primeng/primeng';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
  host: { class: "d-flex flex-column h-100" },
  selector: 'app-rights',
  templateUrl: './rights.component.html',
  styleUrls: ['./rights.component.scss']
})
export class RightsComponent implements OnInit {
  treeOptionsData = [];
  btnjsonData: any;
  controlsButtonObj: any;
  SelectedFile: any;
  userLists: any;
  btnRightsForm: any;
  SelectedNode: any;
  constructor(private formbuilder: FormBuilder,
    public shareService: SagShareService,
    public modalRef: DynamicDialogRef,
    private buttonRightsServices: ProcomparetoolService) { }

  ngOnInit() {
    this._initBtnRightsForm();
    this.__getPageBtnJson();
    this._getUsersList();
  }

  _initBtnRightsForm() {
    this.btnRightsForm = this.formbuilder.group({
      user: [null, Validators.required]
    });
  }
  __getPageBtnJson() {
    const __prjDetails = this.shareService.getDataprotool("selectedProjectChooseData");
    const __sessionInfo = JSON.parse(sessionStorage.getItem('loginFormValueUserID'));
    if (__prjDetails) {
      let reqJson = {
        "projectName": __prjDetails['projectname'],
        "userId": __sessionInfo['data']['clientInfo']['usrId']
      };
      this.buttonRightsServices.getPageBtnJson(reqJson).subscribe(
        (response: any) => {
          if (response) {
            this.btnjsonData = response['btnjson'];
            let mappedResponse = this.btnjsonData.map(_item => {
              let newitem = _item;
              newitem['Kdetails'] = _item['children'];
              if (_item.children !== undefined) {
                _item.children
                this.__recursiveFunction(_item.children);
              }
              return newitem;
            })
            this.shareService.setDataprotool("projectMenuTreeFiles", this.btnjsonData);
            this.treeOptionsData = mappedResponse;
          }
        }
      );
    }
  }
  __recursiveFunction(param) {
    param.map(item => {
      let __newItem = item;
      __newItem['Kdetails'] = item['children'];
      if (item['children']) {
        this.__recursiveFunction(item['children'])
      }
      return __newItem
    })
  }
  _getUsersList() {
    this.buttonRightsServices.getUsrList().subscribe(
      (response: any) => {
        this.userLists = response['data'].map(_item => {
          let _newItem = _item;
          _newItem['label'] = _item['userCode'],
            _newItem['value'] = _item['userId']
          return _newItem
        })
      }
    )
  }
  onNodeSelect(event) {
    if (event['node']['modId']) {
      this._getControlsButtonList(event['node']['modId']);
      this.SelectedNode = event['node']
      this.SelectedFile = event['node']['filePath']
    }
  }

  onNodeUnCheck(event) {

  }
  onNodeCheck(event) {

  }
  finalBtnJson = []
  srcfilectrlIdhide = [];
  srcfilectrlIdmsg = []
  saveBtnJson_Click() {
    this.finalBtnJson = [];
    this.srcfilectrlIdhide = [];
    this.srcfilectrlIdmsg = [];
    const usrId = this.btnRightsForm.controls['user'].value
    if (!usrId) {
      alerts('Please Select At Least One User ..!!!');
      return;
    }
    const _CheckedValue_ = this.controlsButtonObj['sagGridObj']['rowData'];
    if (_CheckedValue_.length == 0) {
      alerts('Please Select At Least One checkBox ..!!!');
      return;
    }
    _CheckedValue_.forEach(element => {
      if (element['hide']) {
        this.srcfilectrlIdhide.push(element['srcfilectrls'].toString());
      }
      if (element['msg']) {
        this.srcfilectrlIdmsg.push(element['srcfilectrls'].toString());
      }
    });
    const req = {
      "userId": this.btnRightsForm.controls['user'].value,
      "filectrlArr": {
        "hide": this.srcfilectrlIdhide,
        "msg": this.srcfilectrlIdmsg,
        "fileId": this.SelectedNode['ngsrcfileId'],
      }
    }
    this.buttonRightsServices.saveBtnRightsJson(req).subscribe(
      (response: any) => {
        if (response["status"] == "success") {
          success(response['message']);
        }
        else if (response["status"] == "failure") {
          alerts(response['message'])
        }
      }, error => {
        alerts("Error While right")
      }
    );
  }
  _getControlsButtonList(__modId) {
    const usrId = this.btnRightsForm.controls['user'].value
    if (!usrId) {
      alerts('Please Select At Least One User ..!!!');
      return;
    }
    let reqJson = {
      "ngmodId": __modId,
      "userId": this.btnRightsForm.controls['user'].value
    };
    this.buttonRightsServices.getControlsButtonList(reqJson).subscribe(
      (response: any) => {
        if (response) {
          this.controlsButtonListGrid(response['data']);
        }
      }
    );
  }

  CloseBtn_Click() {
    this.modalRef.close();
  }
  controlsButtonListGrid(rowsData) {
    const sourceDiv = document.getElementById("gridcontrols");
    const columns = [
      {
        "header": "Sr.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",

      },
      {
        header: "Hide Button",
        field: "hide",
        "editable": false,
        width: "131px",
        "text-align": "center",
        search: true,
        style: "background-color :  #F9E79F",
        "styles": {
          "background-color": " #F9E79F"
        },
        "cellRenderView": "checkbox1"
      },
      {
        header: "Msg Button",
        field: "msg",
        "editable": false,
        width: "131px",
        "text-align": "center",
        search: true,
        style: "background-color :  #F9E79F",
        "styles": {
          "background-color": " #F9E79F"
        },
        "cellRenderView": "checkbox2"
      },

      {
        "header": "Label",
        "field": "label",
        "filter": true,
        "width": "110px",
        "editable": "false",
        "textalign": "right",
        "search": true,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",

      },
      {
        "header": "Type",
        "field": "type",
        "filter": true,
        "width": "110px",
        "editable": "false",
        "textalign": "right",
        "search": true,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",

      },
      {
        "header": "Field Id",
        "field": "fieldId",
        "filter": true,
        "width": "190px",
        "editable": "false",
        "textalign": "right",
        "search": true,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",
        // component: "dbCtrl",

      },
      {
        "header": "Html Id",
        "field": "htmlId",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "right",
        "search": true,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",

      },
    ];
    var self = this;

    let components = {
      "checkbox1": new SagCheckBox({}, function () {
      }),
      "checkbox2": new SagCheckBox({}, function () {
      }),
      "headerCheckBox1": new headerCheckBox({}, function () {
      }),
      "headerCheckBox2": new headerCheckBox({}, function () {
      }),
    };



    let SagGridRowStatus = rowsData;
    for (let i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onRowClick": function () {
          },
          "onRowDbleClick": function () {
          },
          "onCellClick": function (event) {
            self.onCellSelectButtonRights(event)
          }
        }
      };
      this.controlsButtonObj = SagGridMPT(sourceDiv, gridData, true, true);

    }
  }
  onCellSelectButtonRights(event) {
    var self = this;
    let rowIndex = Number(this.controlsButtonObj.getSeletedCellData().rowIndex);
    let column = this.controlsButtonObj.getSeletedCellData().field;
    let rowData = this.controlsButtonObj.getRowData(rowIndex);
    switch (column) {
      case "hide":
        this.controlsButtonObj.updateCell(rowIndex, 'msg', false);
        if(rowData.hide == 0){
          rowData['hide'] = false;
        }else{
          rowData['hide'] = true;
        }
        break;
      case "msg":
        this.controlsButtonObj.updateCell(rowIndex, 'hide', false);
        if(rowData.msg == 0){
          rowData['msg'] = false;
        }else{
          rowData['msg'] = true;
        }
        
        break;
    }

  }
}
