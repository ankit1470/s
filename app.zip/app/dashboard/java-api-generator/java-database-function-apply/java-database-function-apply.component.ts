import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-java-database-function-apply',
  templateUrl: './java-database-function-apply.component.html',
  styleUrls: ['./java-database-function-apply.component.scss'],
  providers: [DialogService]
})
export class JavaDatabaseFunctionApplyComponent implements OnInit,OnDestroy {


functionApplyForm: FormGroup;
submittedFunctionApplyForm: boolean = false;
 
isApplyFunctioDisplay :boolean = true;

gridDynamicForConcateColumnList:any;
gridDynamicForAmtFormateList:any;
gridDynamicForDateFormateList:any;

entityColumnsDropdown  = [];

isConcateGridDisplay:boolean  = false;
isAmtFormateGridDisplay:boolean  = false;
isDateFormateGridDisplay:boolean  = false;

apiLabelField = [];
isModify:boolean  = false;
isSumCountDisplay :boolean = true;

durationUnit = [
 
  { "value": "Years", "label": "Years" },
  { "value": "Months", "label": "Months" },
  { "value": "Weeks", "label": "Weeks" },
  { "value": "Days", "label": "Days" },
  { "value": "Hours", "label": "Hours" },
  { "value": "Minutes", "label": "Minutes" },
  { "value": "Seconds", "label": "Seconds" },
  { "value": "Milliseconds", "label": "Milliseconds" },
 ];

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    public _sagStudioService: SagStudioService,
    private formBuilder: FormBuilder,
     ) { }

  ngOnInit() {
    this.initializeApplyFunction();
    this.concateGrid([]);
    this.amtFormateGrid([]);
    this.dateFormateGrid([]);
    
    this.functionApplyForm.reset();
    this.functionApplyForm.controls["functionType"].patchValue('');
  
     if(this.config.data && this.config.data.selectFields){
       
    
     this.apiLabelField =  JSON.parse(JSON.stringify(this.config.data.selectFields)); 

     this.apiLabelField.forEach(element => {
      let obj = {
        "labelName":element.labelName,
        "modelFieldName":element.modelFieldName,
        "tableName":element.tableName,
      }
      this.entityColumnsDropdown.push(obj);
     });
    }

     if(this.config.data && this.config.data.item){
      this.functionApplyForm.patchValue(this.config.data.item);
      this.isModify = true;

      this.functionApplyForm.controls['functionType'].disable();
       

      this.onChangeModifyFunctionType( this.functionApplyForm.controls['functionType'].value);
      if(this.functionApplyForm.controls['concateList'].value){
        this.concateGrid(this.functionApplyForm.controls['concateList'].value);
      }
      if(this.functionApplyForm.controls['amtFormateList'].value){
        this.amtFormateGrid(this.functionApplyForm.controls['amtFormateList'].value);
      }
      if(this.functionApplyForm.controls['dateFormateList'].value){
        this.dateFormateGrid(this.functionApplyForm.controls['dateFormateList'].value);
      }

      this.functionApplyForm.controls['entityColumns'].setValue(this.config.data.item.entityColumns);

     }

     if(this.config.data && this.config.data.callingType)
     if("db_tool"==this.config.data.callingType){
      this.isSumCountDisplay = false;
     }

     }

    
  


  initializeApplyFunction() {
    this.functionApplyForm = this.formBuilder.group({
      functionType: [{ value: '', disabled: false }, [Validators.required]],
      
      firstResult: [{ value: null, disabled: false }],
      maxResult: [{ value: null, disabled: false }],
      entityColumns: [{ value: null, disabled: false }],
      formate: [{ value: null, disabled: false }],
      functionDetails: [{ value: '', disabled: false }],
      concateList: [{ value:[], disabled: false }],
      amtFormateList: [{ value:[], disabled: false }],
      dateFormateList: [{ value:[], disabled: false }],
      concatKey:[{ value:[], disabled: false } ] ,
      startDate:[{ value:null, disabled: false } ],
      endDate:[{ value:null, disabled: false } ],
      dateDurationKeyName:[{ value:null, disabled: false}],
      dateDurationUnit:[{ value:[], disabled: false}]
      
    });
  
  }


 
  onChangeModifyFunctionType(functionType) {
    if(functionType== "Concat"){
      this.isConcateGridDisplay  = true;
      this.isAmtFormateGridDisplay  = false;
      this.isDateFormateGridDisplay  = false; 

      this.entityColumnsDropdown = [];

      this.apiLabelField.forEach(element => {
        if("string" == element.columnType || "varchar" == element.columnType.toLowerCase() ||  "all_type" == element.columnType.toLowerCase()){
          let obj = {
            "labelName":element.labelName,
            "modelFieldName":element.modelFieldName,
            "tableName":element.tableName,
            
          }
          this.entityColumnsDropdown.push(obj);
        }
      
       });
      

    }else if (functionType== "Amt Formate"){
      this.isConcateGridDisplay  = false;
      this.isAmtFormateGridDisplay  = true;
      this.isDateFormateGridDisplay  = false;
      
      this.entityColumnsDropdown = [];

      this.apiLabelField.forEach(element => {
        if("number" == element.columnType || "decimal" == element.columnType.toLowerCase() || "double" == element.columnType.toLowerCase() ||  "all_type" == element.columnType.toLowerCase()){
          let obj = {
            "labelName":element.labelName,
            "modelFieldName":element.modelFieldName,
            "tableName":element.tableName,
          }
          this.entityColumnsDropdown.push(obj);
        }
      
       });
       
    }else if(functionType== "Date Formate"){
      this.entityColumnsDropdown = [];
      this.isConcateGridDisplay  = false;
      this.isAmtFormateGridDisplay  = false;
      this.isDateFormateGridDisplay  = true; 
      
    }else if (functionType== "Sum"){
      this.isConcateGridDisplay  = false;
      this.isAmtFormateGridDisplay  = false;
      this.isDateFormateGridDisplay  = false; 

      this.entityColumnsDropdown = [];
         this.apiLabelField.forEach(element => {
        if("number" == element.columnType || "decimal" == element.columnType.toLowerCase() || "double" == element.columnType.toLowerCase() ||  "all_type" == element.columnType.toLowerCase()){
          let obj = {
            "labelName":element.labelName,
            "modelFieldName":element.modelFieldName,
            "tableName":element.tableName,
          }
          this.entityColumnsDropdown.push(obj);
        }
      
       });
       
    }else if (functionType== "Count"){
       this.isConcateGridDisplay  = false;
      this.isAmtFormateGridDisplay  = false;
      this.isDateFormateGridDisplay  = false; 
      
      this.entityColumnsDropdown = [];
         this.apiLabelField.forEach(element => {
          let obj = {
            "labelName":element.labelName,
            "modelFieldName":element.modelFieldName,
            "tableName":element.tableName,
          }
          this.entityColumnsDropdown.push(obj);
       });
    } else if (functionType== "Date Duration"){
      this.isConcateGridDisplay  = false;
     this.isAmtFormateGridDisplay  = false;
     this.isDateFormateGridDisplay  = false; 
     
     this.entityColumnsDropdown = [];
        this.apiLabelField.forEach(element => {
          if("date" == element.tableCoulmnType.toLowerCase() || "datetime" == element.tableCoulmnType.toLowerCase() || "time" == element.tableCoulmnType.toLowerCase() 
          || "timestamp" == element.tableCoulmnType.toLowerCase() ||  "all_type" == element.columnType){
            let obj = {
              "labelName":element.labelName,
              "modelFieldName":element.modelFieldName,
              "tableName":element.tableName,
              "tableColumnType":element.tableCoulmnType,
            }
            this.entityColumnsDropdown.push(obj);
          }
        
          
      });
   } 
    else{
      this.entityColumnsDropdown = [];
      this.isConcateGridDisplay  = false;
      this.isAmtFormateGridDisplay  = false;
      this.isDateFormateGridDisplay  = false; 
      
    }
  
    
   
  }

  onChangeFunctionType(functionType) {
    this.onChangeModifyFunctionType(functionType);
  
    this.functionApplyForm.controls["entityColumns"].setValue([]);
    if(functionType=="Amt Formate"){
      this.functionApplyForm.controls["formate"].setValue('2');
    }else if(functionType=="Date Formate"){
      this.functionApplyForm.controls["formate"].setValue('dd/mm/yyyy');
    }else{
      this.functionApplyForm.controls["formate"].setValue('');
    }
   
  }
  
  onChangeEntityColumns(event){
    let fieldArr = event.value;
    let functionType = this.functionApplyForm.controls["functionType"].value;
    
      if(functionType=="Concat"){
        this.concatRowManage(fieldArr);
      }
      if(functionType=="Amt Formate"){
        this.amtFormateRowManage(fieldArr);
      }
      if(functionType=="Date Formate"){
        this.dateFormateRowManage(fieldArr);
      }
  }
  
  concatRowManage(fieldArr){
    const gridDataArr1 = this.gridDynamicForConcateColumnList.getGridData();
  
    let addFieldArr = fieldArr.filter(o1 => !gridDataArr1.some(o2 => o1.modelFieldName === o2.modelFieldName));
  
    addFieldArr.forEach(ele => {
      this.addRowInConcatGrid(ele);
    });
  
    let deleteFieldArr = gridDataArr1.filter(o1 => !fieldArr.some(o2 => o1.modelFieldName === o2.modelFieldName));
    deleteFieldArr.forEach(ele => {
      this.deleteRowInConcatGrid(ele.sag_G_Index);
    });
  }
  
  addRowInConcatGrid(field) { 
    let concatKey = this.functionApplyForm.controls["concatKey"].value;
    if(!concatKey){
      alerts("please fill concate key");
     return ;
    }
    let index = this.gridDynamicForConcateColumnList.sagGridObj.AllRowIndex.length;

    this.gridDynamicForConcateColumnList.addRowByIndex(index, field);
  
  }
  deleteRowInConcatGrid(index) {
  
    this.gridDynamicForConcateColumnList.deleteRow(index);
    if (this.gridDynamicForConcateColumnList.sagGridObj
      && this.gridDynamicForConcateColumnList.sagGridObj.AllRowIndex.length == 0) {
      this.concateGrid([]);
    }
  }
  
  amtFormateRowManage(fieldArr){
    const gridDataArr1 = this.gridDynamicForAmtFormateList.getGridData();
  
    let addFieldArr = fieldArr.filter(o1 => !gridDataArr1.some(o2 => o1.modelFieldName === o2.modelFieldName));
  
    addFieldArr.forEach(ele => {
      this.addRowInAmtFormateGrid(ele);
    });
  
    let deleteFieldArr = gridDataArr1.filter(o1 => !fieldArr.some(o2 => o1.modelFieldName === o2.modelFieldName));
    deleteFieldArr.forEach(ele => {
      this.deleteRowInAmtFormateGrid(ele.sag_G_Index);
    });
  }
  
  addRowInAmtFormateGrid(field) { 
    let formate = this.functionApplyForm.controls["formate"].value;
    if(!formate){
      alerts("please fill amt formate");
     return ;
    }
  
    let index = this.gridDynamicForAmtFormateList.sagGridObj.AllRowIndex.length;

    let newField = JSON.parse(JSON.stringify(field))
    newField['amtFormate'] = formate,

    this.gridDynamicForAmtFormateList.addRowByIndex(index, newField);
  
  }
  deleteRowInAmtFormateGrid(index) {
  
    this.gridDynamicForAmtFormateList.deleteRow(index);
    if (this.gridDynamicForAmtFormateList.sagGridObj
      && this.gridDynamicForAmtFormateList.sagGridObj.AllRowIndex.length == 0) {
      this.amtFormateGrid([]);
    }
  }
  
  dateFormateRowManage(fieldArr){
    const gridDataArr1 = this.gridDynamicForDateFormateList.getGridData();
  
    let addFieldArr = fieldArr.filter(o1 => !gridDataArr1.some(o2 => o1.modelFieldName === o2.modelFieldName));
  
    addFieldArr.forEach(ele => {
      this.addRowInDateFormateGrid(ele);
    });
  
    let deleteFieldArr = gridDataArr1.filter(o1 => !fieldArr.some(o2 => o1.modelFieldName === o2.modelFieldName));
    deleteFieldArr.forEach(ele => {
      this.deleteRowInDateFormateGrid(ele.sag_G_Index);
    });
  }
  
  addRowInDateFormateGrid(field) { 
    let formate = this.functionApplyForm.controls["formate"].value;
  
    if(!formate){
      alerts("please fill date formate");
     return ;
    }
  
    let index = this.gridDynamicForDateFormateList.sagGridObj.AllRowIndex.length;
    
    field['amtFormate'] = formate,
    this.gridDynamicForDateFormateList.addRowByIndex(index, field);
  
  }
  
  deleteRowInDateFormateGrid(index) {
  
    this.gridDynamicForDateFormateList.deleteRow(index);
    if (this.gridDynamicForDateFormateList.sagGridObj
      && this.gridDynamicForDateFormateList.sagGridObj.AllRowIndex.length == 0) {
      this.dateFormateGrid([]);
    }
  }
  
  applyFunction() {
    this.submittedFunctionApplyForm = true;
    if (!this.functionApplyForm.valid) {
      alerts("Please fill all required fields");
      return;
    }
    let formData = this.functionApplyForm.getRawValue();
    if(formData.functionType =="Limit"){
      if(formData.firstResult == null || formData.maxResult ==null){
        alerts("Please fill all required fields");
        return;
      }
    }
  
    if("Date Duration" == formData.functionType ){
         if(!formData.startDate ||  !formData.endDate || !formData.dateDurationKeyName || !formData.dateDurationUnit){
          alerts("Please fill all required fields");
          return;
        }
    }

    this.submittedFunctionApplyForm = false;
    
    this._setFunctionDetails();
   
    this.modalRef.close(this.functionApplyForm.getRawValue());
    this.ngOnDestroy();
  }
  
  _setFunctionDetails(){
    let functionType =  this.functionApplyForm.controls["functionType"].value;
    if(functionType =="Limit"){
      let firstResult =  this.functionApplyForm.controls["firstResult"].value;
      let maxResult =  this.functionApplyForm.controls["maxResult"].value;
      this.functionApplyForm.controls["functionDetails"].setValue(firstResult + " - " + maxResult);
    }
    if(functionType =="Concat"){
      const gridDataArr = this.gridDynamicForConcateColumnList.getGridData();
      let selectFields="";
      gridDataArr.forEach(checked => {
        selectFields = selectFields + checked.labelName+",";
      });
       
      if(selectFields!=""){
        selectFields = selectFields.substring(0,selectFields.lastIndexOf(","));
      }
      this.functionApplyForm.controls["functionDetails"].setValue(selectFields);
      this.functionApplyForm.controls["concateList"].setValue(gridDataArr);
  
    }
    if(functionType =="Amt Formate"){
      const gridDataArr = this.gridDynamicForAmtFormateList.getGridData();
      let selectFields="";
      gridDataArr.forEach(checked => {
        selectFields = selectFields + checked.labelName+",";
      });
       
      if(selectFields!=""){
        selectFields = selectFields.substring(0,selectFields.lastIndexOf(","));
      }
      this.functionApplyForm.controls["functionDetails"].setValue(selectFields);
      this.functionApplyForm.controls["amtFormateList"].setValue(gridDataArr);
    }
    if(functionType =="Date Formate"){
      const gridDataArr = this.gridDynamicForDateFormateList.getGridData();
      let selectFields="";
      gridDataArr.forEach(checked => {
        selectFields = selectFields + checked.labelName+",";
      });
       
      if(selectFields!=""){
        selectFields = selectFields.substring(0,selectFields.lastIndexOf(","));
      }
      this.functionApplyForm.controls["functionDetails"].setValue(selectFields);
      this.functionApplyForm.controls["dateFormateList"].setValue(gridDataArr);
    } 
    if(functionType =="Sum" || functionType =="Count" ){
     let entityColumns = this.functionApplyForm.controls['entityColumns'].value;
     let selectFields="";
     if(entityColumns){
       entityColumns.forEach(checked => {
        selectFields = selectFields + checked.labelName+",";
      });
     }
      if(selectFields!=""){
        selectFields = selectFields.substring(0,selectFields.lastIndexOf(","));
      }
      this.functionApplyForm.controls["functionDetails"].setValue(selectFields);
      
    } 

    if("Date Duration" == functionType ){
      let startDate =  this.functionApplyForm.controls["startDate"].value.labelName;
      let endDate =  this.functionApplyForm.controls["endDate"].value.labelName;
      this.functionApplyForm.controls["functionDetails"].setValue(startDate + " - " + endDate);
     }
   
  
    }
  
  
  
  
    
  
  concateGrid(rowsData) {
    var sourceDiv = document.getElementById("concateGridId");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
  
      },
      {
        "header": "Column Name",
        "field": "labelName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Separator",
        "field": "separator",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'separatorComp',
     },
      
  
  
  
    ];
    let self = this;
    let components = {
      "separatorComp": new SagInputText({}, function () {
     
      }),
      
    };
  
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {}
  
  
      };
      this.gridDynamicForConcateColumnList = SagGridMPT(sourceDiv, gridData, true, true);
      return this.gridDynamicForConcateColumnList;
  
    }
  
  }
  amtFormateGrid(rowsData) {
    var sourceDiv = document.getElementById("amtFormateGridId");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
  
      },
      {
        "header": "Column Name",
        "field": "labelName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
       },
      {
        "header": "Amt Formate",
        "field": "amtFormate",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
  
      },
     
  
  
    ];
    let self = this;
     let components = {}
  
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {}
  
  
      };
      this.gridDynamicForAmtFormateList = SagGridMPT(sourceDiv, gridData, true, true);
      return this.gridDynamicForAmtFormateList;
  
    }
  
  }
  
  dateFormateGrid(rowsData) {
    var sourceDiv = document.getElementById("dateFormateGridId");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
  
      },
      {
        "header": "Column Name",
        "field": "modelFieldName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
       
      },
      {
        "header": "Date Formate",
        "field": "dateFormate",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
  
      },
     
    ];
    let self = this;
     let components = {}
  
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {}
  
  
      };
      this.gridDynamicForDateFormateList = SagGridMPT(sourceDiv, gridData, true, true);
      return this.gridDynamicForDateFormateList;
  
    }
  
  }
  








  ngOnDestroy() { }

  onClose() {
    this.modalRef.close();
    this.ngOnDestroy();
   }

}
