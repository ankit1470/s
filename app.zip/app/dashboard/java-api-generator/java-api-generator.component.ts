import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy, ViewChild, ElementRef, HostListener } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { ImportExportValidationComponent } from '../import-export-mapping/import-export-validation/import-export-validation.component';
import { GeneratedJavaFileListComponent } from 'src/app/modules/sag-studio/property-window/java-api/generated-java-file-list/generated-java-file-list.component';
import { HqlBreadcrumbComponent } from 'src/app/modules/database/dbcompare-tool/hql-generator/components/hql-breadcrumb/hql-breadcrumb.component';
import { JavaApiMappingComponent } from './java-api-mapping/java-api-mapping.component';
import { JavaApiManualCodeComponent } from './java-api-manual-code/java-api-manual-code.component';
import { Router } from '@angular/router';
import { Subscription, fromEvent } from 'rxjs';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { filter, take } from 'rxjs/operators';
import * as uuid from 'uuid';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $, Contextual, ContextualItem;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-java-api-generator',
  templateUrl: './java-api-generator.component.html',
  styleUrls: ['./java-api-generator.component.scss'],
  providers: [DialogService]
})
export class JavaApiGeneratorComponent implements OnInit,OnDestroy {
   
  isBackgroundDisable:boolean = false;

  isModifyApi : boolean  = false;
  

  /***Ellipsis **/
  copyPastEllipsisValue = null;
  isRecursionOff =false; 

  /*****Validation */
  validationList;
  dropdownValidationList = [];

    /***Table Info*/
  allTableList = [];
  tableListDropdownList = [{ "key": "", "val": "--Select--" }];
  tableFieldsMap = new Map();
  tableMasterDropdownForJavaApiFieldMapping = [];
  fillTableList

 /***Table Field Info*/
  tableFieldDropdownList = [];
  masterTableFieldDropdownList = [];
  masterTableFieldMap = new Map();

  /****Aliase**** */
  aliaseStartIndex = 0
  headerAliasObj = {};

  /***Grid*** */
  gridDynamicForApiMapping;
  

  /**** */
  gridDynamicAddMasterExtraColumn
  
  apiFieldColumnDropdown = [{ "key": "", "val": "--Select--" }]

  jsonGeneratedFileList = [];

 // formFieldList = []

  /*****Api Json */
   pageConfigurationJSON = {
    "tableRelations":[],
    "manualCodeList":[],
    "apiFieldList":[],
    "dataFindFrom":[],
    "isFileUpload":"N",
    "isValidationApply":"N",
    "isJsonImport":"N",
    "isImportUiCreate":"Y",
    "jsonMasterMapping":[],
     
    "documentSectionList":[],
    'isAIPoweredDocumentImport':"N",
    "OCRResultSendApiCreate":"Y"
 }

 oldPageConfigurationJSON ={};



  javaApiList = []

  formNameList = [];

  oldApiInfo = null;

  dataFindFrom = [
    { "key": "", "val": "--Select--" },
    { "key": "_sheet", "val": "JSON" },
    { "key": "client_side", "val": "Client Side" },
    { "key": "file", "val": "File" },
    { "key": "Formula", "val": "Formula" },
    { "key": "by_manual_method_with_aliase", "val": "Manual Method With Aliase" },
    { "key": "by_manual_method", "val": "Manual Method With static" },
    { "key": "static_value", "val": "Static Value" },
   ];


   dateFormateList = [];
   controllerMethodList = [];

   JAVA_KEYWORDS = [
    "abstract", "assert", "boolean", "break", "byte", "case",
    "catch", "char", "class", "const", "continue", "default", "do", "double", "else", "enum", "extends",
    "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface",
    "long", "native", "new", "package", "private", "protected", "public", "return", "short", "static",
    "strictfp", "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
    "volatile", "while", "true", "false", "null"
];
  
  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService,
    public _sagStudioService: SagStudioService,
    public _router: Router,
   
     ) { }

  ngOnInit() {
 
    this.getValidationList();
    this.getDateFormateList();
    this.getAllTableList();
    this.getHeaderAlias();

    this.javaApiFieldMappingGrid([]);
    this.javaApiGrid([]);
  
    let backEndProjectName = this.shareService.getDataprotool("selectedProjectChooseData");
    if (backEndProjectName) {
      this.sagStudioService.setSagStudioData("autoGeneretedProjectPath", backEndProjectName.jwspace);
    }
    else {
      alerts("please setPath in workspace Configuration");
      return
    }
    let projectName = backEndProjectName.jwspace.substring(backEndProjectName.jwspace.lastIndexOf("/") + 1, backEndProjectName.jwspace.length);
    this.initializeForm(projectName);
    
    if(this.config.data && this.config.data.apiId){
      this.isModifyApi = true;
       this.setModifyJavaApiGeneratedInfo(this.config.data.apiId);
     } else {
      this.setDefaultValueInDbMappingForm();
     }

     this.getAllPageFormConfigName();
   }


 

  getAllPageFormConfigName() {

    this.formNameList = [];

    let formApiConfigModel = {
      'ngsrcfilePath': this.dbMappingform.controls['ngsrcfilePath'].value,
      'projectId':this.dbMappingform.controls['projectId'].value,
    }

    this.autoJavacodeService.getAllPageFormConfigName(formApiConfigModel).subscribe(res => {
      if (res.status == 200) {
        this.formNameList = res.data;
      }

    }, Error => {
      alerts("Error While Fetching Data");
    });
  }



 
 
 
  newJavaModalDataWithJavaTypeNew = []
  PageMappingFinalGridJson = []
  dbMappingJsonJava: any;

 

  getFinaldbMappingJson() {
    this.PageMappingFinalGridJson = []
    const activeFile = this.sagStudioService.currentActiveProject.currentActiveFileNode;
    const __prjDetails = this.shareService.getDataprotool("selectedProjectChooseData");
    const Filepath = activeFile.projectPath.substring(activeFile.projectPath.lastIndexOf("src"));
    const reqJson = {
      projectId: __prjDetails["projectId"],
      filePath: Filepath,
    }
    this.autoJavacodeService.getPageMappingJson(reqJson).subscribe(res => {
      this.dbMappingJsonJava = res;
      let formFieldList = new Set();
      this.loadFormColumns("1001",formFieldList);
      this.setFormApiFields(formFieldList);
    });
  }

  loadFormColumns(pageModelDataId,formFieldList){
   
    if (this.sagStudioService.getSagStudioData('allLayerPageModelDataForJava')) {
      let allLayerPageModelDataForJava = this.sagStudioService.getSagStudioData('allLayerPageModelDataForJava');
      let breadCrumb = allLayerPageModelDataForJava.get(pageModelDataId); 
      let pageModalData = breadCrumb.activePageModalData;  
     
      const ModelListGridDataInFront = pageModalData;
  
      const newJavaModalData = ModelListGridDataInFront.map(item => {
        let newItem = item;
        newItem['activeData'] = true
        return newItem;
      })

      if (newJavaModalData == undefined) {
        formFieldList = new Set();
      } else {
        let newJavaModalDataWithJavaType = this.autoSetJavaModelFieldType(newJavaModalData);
        if (this.dbMappingJsonJava.length == 0) {
          newJavaModalDataWithJavaType.forEach(element => {
            formFieldList.add(element);
            if(element.nestLayer == true && element.nestData){
             let nestDataId =  element.nestData;
             let formFieldListDetails = new Set();
             element['details'] = formFieldListDetails;
             this.loadFormColumns(nestDataId,formFieldListDetails);
            }

          });
         
          
        } else {
          const _newMapArray = newJavaModalDataWithJavaType.map((ele) => {
            const _result = this.dbMappingJsonJava.find(_item => _item.inputId === ele.id);
            if (_result && _result.inputId == ele.id) {
              let _newItem = ele
              _newItem["varname"] = _result['varname']
              _newItem["vartype"] = _result['vartype']
              _newItem["tableName"] = _result['tableName']
              _newItem["tableCol"] = _result['tableCol']
              _newItem["filePath"] = _result['filePath']
              _newItem["coltype"] = _result['coltype']
              _newItem["colsize"] = _result['colsize']
              return _newItem
            }else{
              return ele;
            }
          });

          let _finalArray = [...new Set(_newMapArray)]

          _finalArray.forEach(element => {
            formFieldList.add(element);
            if(element['nestLayer'] == true && element['nestData']){
             let nestDataId =  element['nestData'];
             let formFieldListDetails = new Set();
             element['details'] = formFieldListDetails;
             this.loadFormColumns(nestDataId,formFieldListDetails);
            }

          });
        
         
        }

      }

    }

  }

  createLabelName(modelFieldName) {
    let res = "";
    for (let i = 0; i < modelFieldName.length; i++) {
        let ch = modelFieldName.charAt(i);
        if (i === 0) {
            res += ch.toUpperCase();
        } else {
            if (ch === ch.toUpperCase()) {
                res += " " + ch;
            } else {
                res += ch;
            }
        }
    }
    return res;
}

  setFormApiFields(formFieldList){
  
    this.pageConfigurationJSON.apiFieldList = [];

   
    let javaApiField = [];
    this.setFormApiFieldsRecursive(formFieldList,javaApiField);

    this.pageConfigurationJSON.apiFieldList = javaApiField;

    this.managePageConfigurationJSONForAiImport();
    
    this.loadData();
  }

  
  setFormApiFieldsRecursive(formFieldList,newList){
    if(formFieldList){

      formFieldList.forEach(ele => {

        let _newItem = {};
        if(ele['label']){
          _newItem["labelName"] = ele['label']
        } else if(ele['javaVName']){ 
          _newItem["labelName"] = this.createLabelName(ele['javaVName'])
        }
    
        _newItem["labelFormGroupName"] = ele['name']
        _newItem["modelFieldName"] = ele['javaVName']
        _newItem["tableName"] = ele['tableName']
        _newItem["colTypeSize"] = ele['colTypeSize']
        _newItem["tableField"] = ele['tableCol']
        _newItem["tableCoulmnType"] = ele['coltype']
        _newItem["tableCoulmnSize"] = ele['colsize']
        if("Y"==this.pageConfigurationJSON.isJsonImport){
          _newItem["dataFindFrom"] = "_sheet"
        }else{
          _newItem["dataFindFrom"] = "client_side"
        }
       
        _newItem["columnType"] = ele['subtype'] == 'text' ? "string" : ""
        _newItem["subtype"] = ele['subtype']
        _newItem["type"] = ele['type']
        _newItem["inputId"] = ele['id']
        _newItem["isDisplayColumn"] = true
        _newItem["isModifyColumn"] = true
       
        newList.push(_newItem);

        if(ele.details){
          _newItem['labelName'] = ele['javaVName'];
          _newItem['details'] = [];
          this.setFormApiFieldsRecursive(ele.details, _newItem['details']);
        }

       
      });

     
    }
  }



  setModifyJavaApiGeneratedInfo(apiId){
    if(apiId!=null && apiId!=undefined && apiId!=""){
      const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
      if(sessionStoragedatauserId!=undefined){
       let userId=sessionStoragedatauserId.data.clientInfo.usrId;
       
      this.autoJavacodeService.getJavaApiJsonByApiId(apiId,userId).subscribe(res => {
        if(res.status==200){
          let formApiConfigId = res.data.formApiConfigId;
          let apiData = res.data;

          let obj = {}; 
          obj["PageWindowName"] = apiData.pageName;
          obj["moduleName"] = apiData.moduleName;

          let backEndProjectName = this.shareService.getDataprotool("selectedProjectChooseData");
          if(backEndProjectName){
            let projectName = backEndProjectName.jwspace.substring(backEndProjectName.jwspace.lastIndexOf("/") + 1, backEndProjectName.jwspace.length);
            let projectPath =  backEndProjectName.jwspace     
            obj["projectName"] = projectName;
            obj["projectSourcePath"] = projectPath;
            obj["userwrokspace"] = projectPath;
            obj["projectId"] = backEndProjectName.projectId;
          }
          const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
          if(sessionStoragedatauserId!=undefined && sessionStoragedatauserId.data!=undefined){
            obj["userId"] = sessionStoragedatauserId.data.clientInfo.usrId;
            obj["userName"] = sessionStoragedatauserId.data.clientInfo.usrName;
          }
          this.dbMappingform.patchValue(obj);
          this.dbMappingform.controls["moduleName"].disable();
          this.dbMappingform.controls["PageWindowName"].disable();

          this.onModuleNameChange(obj["moduleName"],true);
          this.onPageChange(obj["PageWindowName"],true,formApiConfigId);
         
          
         
         }
      
      }, Error => {
        alerts("Error While Feching");
      });
    }else{
      alerts("User Not found");
    }
  }
    
  }


  /************On Load Method***************** */
  getHeaderAlias() {
  this.autoJavacodeService.getSheetHeaderAlias().subscribe(res => {
      if (res.status == 200) {
        this.headerAliasObj = res.data;
      }else{
        this.headerAliasObj = {}
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  autoSetJavaModelFieldType(newJavaModalData) {
    newJavaModalData.forEach(field => {
      if (field.colTypeSize && field.colTypeSize != null && field.colTypeSize != "") {
        let colTypeArr = field.colTypeSize.split("/");
        if (colTypeArr != undefined && colTypeArr != null && colTypeArr[0] != undefined) {
          field.tableCol = colTypeArr[0].trim();
        }
        if (colTypeArr != undefined && colTypeArr != null && colTypeArr[1] != undefined) {
          field.coltype = colTypeArr[1].trim();;
       }
        if (colTypeArr != undefined && colTypeArr != null && colTypeArr[2] != undefined) {
          field.colsize = colTypeArr[2].trim();
        }
        
      }
    });
    return newJavaModalData;
  }

  
  getValidationList() {
    this.dropdownValidationList = [];
    this.autoJavacodeService.getValidationList().subscribe(res => {
      if (res.status == 200) {
        this.validationList = res.data;
        this.getValidationDropdown(res.data);
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  getDateFormateList() {
    this.dateFormateList = [];
    this.autoJavacodeService.getDateFormateList().subscribe(res => {
      if (res.status == 200) {
        this.dateFormateList = res.data;
        
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  getValidationDropdown(validationList) {
    this.dropdownValidationList = []
    validationList.forEach((ele) => {
      let obj = {
        key: ele.validationCode,
        val: ele.validationName
      };
      this.dropdownValidationList.push(obj);
    })
  }

  getAllTableList() {
  
    this.tableListDropdownList = [];
    this.allTableList = [];

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
    }
    this._dbcomparetoolService.tblstrcturedrpdown(dbData).subscribe((res) => {
      if (res) {
        let masterdropdown = res['masterdropdown'];
        let mtbllist = masterdropdown.mtbllist.sort();
        this.allTableList = masterdropdown.mtbllist.sort();
        this.getTableDropdownName(mtbllist);
        this.getTableDropdownNameForMaster();
        
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }

  getTableDropdownNameForMaster() {
    this.tableMasterDropdownForJavaApiFieldMapping = [{ "key": "", "val": "--Select--" }];
  this.allTableList.forEach(table => {
    let obj = {
     "key":table,
     "val":table
    }
    this.tableMasterDropdownForJavaApiFieldMapping.push(obj);
  });
  }

  getTableDropdownName(mtbllist) {
    this.tableListDropdownList = [{ "key": "", "val": "--Select--" }];
    mtbllist.forEach(table => {
      let obj = {
        "key": table,
        "val": table
      }
      this.tableListDropdownList.push(obj);
    });
    if (this.gridDynamicForApiMapping && this.gridDynamicForApiMapping.sagGridObj.components['tableName']) {
      this.gridDynamicForApiMapping.sagGridObj.components['tableName'].setOption(this.tableListDropdownList);
    }
  }

  /***********Form Mapping************** */

  javaApiFieldMappingGrid(rowsData) {
    var sourceDiv = document.getElementById("javaApiFieldMappingGridId");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": false,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Label Name",
        "field": "labelName",
        "filter": false,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      {
        "header": "Name",
        "field": "modelFieldName",
        "filter": false,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      {
        "header": "Data Find From",
        "field": "dataFindFrom",
        "filter": false,
        "width": "170px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Header Alias",
        "field": "headerAlias",
        "filter": false,
        "width": "120px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      {
        "header": "Column Type",
        "field": "columnType",
        "filter": false,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Date Format",
        "field": "dateFormat",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Table Name",
        "field": "tableName",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "left",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Table Field",
        "field": "tableField",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Table Properties",
        "field": "tableProperties",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      {
        "header": "Is Master",
        "field": "isMaster",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "JSON Master",
        "field": "excelMaster",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
       {
        "header": "Table Master",
        "field": "tableMaster",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Display Master Column",
        "field": "masterColumnName",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Master Save And Duplicate Check",
        "field": "isMasterSaveAndDuplicateCheck",
        "filter": false,
        "width": "200px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'checkbox',
        "cellRenderView": true
      },
      {
        "header": "Formula/Static Value/Method Calling",
        "field": "formulaStaticValue",
        "filter": false,
        "width": "250px",
        "editable": "false",
        "text-align": "left",
        "search": true,
        "component": "dynamicComponent",
        "cellRenderView": true,
        "freezecol": "null",
        "hidden": false,
        "sort": false,
        "cellHover": false,
        "button": { "imgsrc": "", "iconclass": "", "iconPosition": "After", "name": "File Store Configuration", "classes": 
        ["btn", "btn-primary", "text-center", "w-100"], "attribute": "", "styles": "" },
      },
      //json start
      {
        "header": "Unique Constraint",
        "field": "uniqueConstraint",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'checkbox',
        "cellRenderView": true
      },
      {
        "header": "Import By",
        "field": "importBy",
        "filter": false,
        "width": "100px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'checkbox',
        "cellRenderView": true
      },
   
      {
        "header": "Group By",
        "field": "groupBy",
        "filter": false,
        "width": "100px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'checkbox',
        "cellRenderView": true
      },
      {
        "header": "Function",
        "field": "aggregateFunction",
        "filter": false,
        "width": "100px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      //json end
      {
        "header": "Validation",
        "field": "validationtfield",
        "filter": false,
        "width": "100px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'button',
        "cellRenderView": true,
        button:{"name":"Validation",visibility:true,classes: ['btn','btn-primary'],
        styles: { 'padding': '0px !important', 'font-size': '20px !important' }},
      },
      {
        "header": "AI Suggestion",
        "field": "aiSuggestionBtn",
        "filter": false,
        "width": "120px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'button',
        "cellRenderView": true,
        button:{"name":"AI Suggestion",visibility:true,classes: ['btn','btn-primary'],
        styles: { 'padding': '0px !important', 'font-size': '20px !important' }},
      }

    ];
 

    
let tableRow = {
  "header": "Table Row",
  "field": "tableRow",
  "filter": false,
  "width": "150px",
  "editable": "false",
  "textalign": "center",
  "search": true,
  "component": 'text',
  "cellRenderView": false
};

let aiPosibleValue = {
  "header": "Prospective value",
  "field": "excelMaster",
  "filter": false,
  "width": "150px",
  "editable": "false",
  "text-align": "center",
  "search": true,
  "component": 'select',
  "cellRenderView": false
}

if("N" == this.pageConfigurationJSON.isJsonImport){
  columns = _.filter(columns,ele=>{
    if(ele.field == "uniqueConstraint" 
    || ele.field == "importBy" 
    || ele.field == "groupBy"  
    || ele.field == "aggregateFunction"
    || ele.field == "excelMaster"
    //|| ele.field == "aiSuggestionBtn"
    ){
      return false;
    }
    return true;
  })
}

if("N" == this.pageConfigurationJSON.isAIPoweredDocumentImport){
  columns = _.filter(columns,ele=>{
    if(ele.field == "aiSuggestionBtn"){
      return false;
    }
    return true;
  })
}
if("Y" == this.pageConfigurationJSON.isAIPoweredDocumentImport && "N" == this.pageConfigurationJSON.isJsonImport){
  columns.push(aiPosibleValue);
}



if("Y" == this.pageConfigurationJSON.isJsonImport){
  columns = _.filter(columns,ele=>{
    if(ele.field == "modelFieldName" 
    || ele.field == "isMasterSaveAndDuplicateCheck"
    ){
      return false;
    }
    return true;
  })
}

if("fix_child_key_wise" == this.documentSectionObjForRef.jsonType){
  columns.splice(4, 0, tableRow);
}

if("client_details" == this.documentSectionObjForRef.jsonType){
 columns = _.filter(columns,ele=>{
   if(ele.field == "sno" 
   || ele.field == "name" 
   || ele.field == "description"  
   || ele.field == "dataFindFrom"
   || ele.field == "formulaStaticValue"){
     return true;
   }
   return false;
 })
}


    
    let fieldTypeList = [
      { "key": "", "val": "--Select--" },
      { "key": "number", "val": "Double" },
      { "key": "string", "val": "String" },
      { "key": "date", "val": "Date" },
      { "key": "integer", "val": "Integer" },
      { "key": "boolean", "val": "Boolean" },
      { "key": "object", "val": "Object" },
      { "key": "array", "val": "Array" },
      { "key": "blob", "val": "Blob" },
      
    
    ];
    
    let self = this;
    
    let isMaster = [
      { "key": "", "val": "--Select--" },
      { "key": "Y", "val": "Yes" },
      { "key": "N", "val": "No" },
     ];

     let exportTypeInEqualsList = [
      { "key": "", "val": "" },
      { "key": "equalsOperator", "val": "EQUAL" },
      { "key": "inOperator", "val": "IN" },
     ];

 

  
    
     let aggregateFunctionList = [
      { "key": "", "val": "--Select--" },
      { "key": "sum", "val": "SUM" },
      
     ];
    
    let components = {};
    this.setDynamicComponet(rowsData);

    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    this.setUniqeIdIfNoExist(rowsData);

    this.aliaseStartIndex = 0;
    this.setAliaseNameInGrid(rowsData);
    
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        frezzManager: { "sno": "left", "labelName": "left","modelFieldName": "left","headerAlias":"left"},
        rowCustomHeight :20,
        cellCustomPadding:5,
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        footer_hide: true,
        totalNoOfRecord_hide: false,
        sml_expandGrid_hide: false,
        exportXlsxPage_hide: false,
        exportXlsxAllPage_hide: false,
        exportPDFLandscape_hide: false,
        exportPDFPortrait_hide: false,
        ariaHidden_hide: false,
        disableAllSearch: false,
        wordBreak: false,
        wordBreakHeader: false,
        cellHover: false,
        rowHover: false,
        rowBorder_hide: false,
        columnBorder_hide: false,
        header_hide: false,
        gridbody_hide: false,
        rowLineSpace: 0,
        multiHeader: false,
        common_search: true,
        common_search_column: "all",
        common_filter: false,
        common_filter_column: "",
        exportBtn: false,
        newPagination: false,
        commonSearchSelect_hide:true, 
        totalNoOfRecord_position:'top',
        newExpandExportTotalRecord_hide: false,

        callBack: {
         
          "onTextChange_labelName": function (ele, params) {
            self.onChangeLabelName(ele.value,params);
          },

          "onChangeSelect_columnType": function (ele, params) {
            self.onChangeSheetColumnType(ele.value, params.rowIndex)
          },

          "onChangeSelect_isMaster": function (ele, params) {
            self.setDisableEnableMasterColumn(ele.value,params.rowIndex);
          },
         
          "onChangeSelect_tableName": function (ele, params) {
            let value = ele.value;
            ele.onkeydown = function (event) {
              if (event.keyCode == 13) {
                 self.fillTableNameSameValue(params, value);
              }
            }
            self.onChangeTable(ele.value, params.rowIndex,null);
            self.setTableRelation(ele.value);
           
          },
          "onChangeSelect_dataFindFrom": function (ele, params) {
            self.setColorByDataFindFrom(ele.value, params.rowIndex)
          },
          "onChangeSelect_tableField": function (ele, params) {
            self.onChangeTableField(ele.value, params);

            self.checkFileUploadInFileSystem(ele.value, params);

          },
          "onChangeSelect_tableMaster": function (ele, params) {
            self.gridDynamicForApiMapping.updateCell(params.rowIndex, "addDisplayMasterColumn", []);
            self.onChangeMasterTable(ele.value, params.rowIndex,null);
          },
    
          "onChangeSelect_masterColumnName": function (ele, params) {
            self.onChangeMasterTableField(ele.value, params.rowValue.tableMaster,params.rowIndex)
          },
       
       
    
           "onButton_validationtfield": function (ele, params) {
            self.onClickValidation(params);
          },
    
          "onButton_aiSuggestionBtn": function (ele, params) {
            self.onClickAiSuggestion(ele,params);
          },

          "onButtonIcon_formulaStaticValue": function (ele, params) {
            self.openFileStoreConfigurationModel(params);
          },
          "onChangeSelect_excelMaster": function (ele, params) {
            self.onChangeExcelMasterField(ele.value, params)
          },

          "cellCallBack": function (param) {
            let ele = param.ele;
              ele.addEventListener('contextmenu', event => {
                event.preventDefault();
                self.gridDynamicForApiMapping.setRowSelected(param.rowIndex);
                if("masterColumnName"==param.colKey){
                  //self.open1(event);

                  new Contextual({
                    isSticky: false,
                    items: [
                      new ContextualItem({ cssIcon:"fa fa-eye",  label: 'Select Master For Display', onClick: () => {self.openContextMenuForAddDisplayMaster(event,param) } }),
                      new ContextualItem({ cssIcon:"fa fa-plus",  label: 'Insert Row', onClick: () => {self.addRowEllipsis(param.rowIndex); } }),
                      new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Row', onClick: () => {self.deleteRowApiFieldMapping(param.rowIndex); } }),
                      new ContextualItem({cssIcon:"fa fa-copy",  label: 'Copy Row', onClick: () => { self.copyRow(ele,param) } }),
                      new ContextualItem({cssIcon:"fa fa-paste",  label: 'Paste Row', onClick: () => {  self.pasteRowApiFieldMapping(param.rowIndex) } }),
                      new ContextualItem({ cssIcon:"fa fa-child", label: 'Add Child Row', onClick: () => {  self.addChildRowSheetMapping(param.rowIndex); } }),
                      new ContextualItem({ cssIcon:"fa fa-plus-circle",  label: 'Add Master Extra Column', onClick: () => { self.addExtraMasterField(param.rowIndex); } }),
                      ]
                  });

                }else{
                  new Contextual({
                    isSticky: false,
                    items: [
                      new ContextualItem({ cssIcon:"fa fa-plus",  label: 'Insert Row', onClick: () => {self.addRowEllipsis(param.rowIndex); } }),
                      new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Row', onClick: () => {self.deleteRowApiFieldMapping(param.rowIndex); } }),
                      new ContextualItem({cssIcon:"fa fa-copy",  label: 'Copy Row', onClick: () => { self.copyRow(ele,param) } }),
                      new ContextualItem({cssIcon:"fa fa-paste",  label: 'Paste Row', onClick: () => {  self.pasteRowApiFieldMapping(param.rowIndex) } }),
                      new ContextualItem({ cssIcon:"fa fa-child", label: 'Add Child Row', onClick: () => {  self.addChildRowSheetMapping(param.rowIndex); } }),
                      new ContextualItem({ cssIcon:"fa fa-plus-circle",  label: 'Add Master Extra Column', onClick: () => { self.addExtraMasterField(param.rowIndex); } }),
                                 ]
                  });
                }
              
              });
            
          
          }

        },
     
        dropDownJson_field: [{ "key": "", "val": "--Select--" }],
        dropDownJson_isMaster: isMaster,
        dropDownJson_tableMaster: this.tableMasterDropdownForJavaApiFieldMapping,
        dropDownJson_masterColumnName: [{ "key": "", "val": "--Select--" }],
        dropDownJson_dateFormat:this.dateFormateList,
        dropDownJson_tableName: this.tableListDropdownList,
        dropDownJson_columnType: fieldTypeList,
        
        dropDownJson_tableField: [{ "key": "", "val": "--Select--" }],
        dropDownJson_dataFindFrom: this.pageConfigurationJSON['dataFindFrom'], 

        dropDownJson_exportTypeInEquals: exportTypeInEqualsList,
        dropDownJson_aggregateFunction:aggregateFunctionList,
        dropDownJson_excelMaster: this.excelMasterDropdownForSheetMapping,

        rowGrouping: {
          "enable": true,
          "groupType": "custome",
          "groupBy": "labelName",
          "expandRow": []
        },
        rowSelection: false,
        rowDataViewTotal: true,
      
        
      };
      this.gridDynamicForApiMapping = SdmtGridT(sourceDiv, gridData, true, true);
      this.setColorProperties(this.gridDynamicForApiMapping.getGridData());
      this.disableMasterCell(this.gridDynamicForApiMapping.getGridData());
      this.setValidationRowProperty(rowsData); 
      this.setRowColor(this.gridDynamicForApiMapping.getGridData());

      return this.gridDynamicForApiMapping;
    }
    }

  setUniqeIdIfNoExist(gridData) {

    gridData.forEach(rowData => {
      if (!rowData["_uniqeId"]) {
        rowData["_uniqeId"] = uuid.v4()
      }

      if (rowData.details) {
        this.setUniqeIdIfNoExist(rowData.details);
      }
    });

  }


    onChangeExcelMasterField(excelMaster, params){
      if("Y" == this.pageConfigurationJSON.isJsonImport){
        if(excelMaster){
          let item = _.find(this.pageConfigurationJSON.jsonMasterMapping, { "name": excelMaster });
          if(item){
            this.gridDynamicForApiMapping.updateCell(params.rowIndex, "tableMaster", item.tableName);
            this.onChangeMasterTable(item.tableName, params.rowIndex,item.nameTableColumn);
          }
         }
      }
     
      }

      mapMasterDropdownForSheetMapping(isSetOption){
        this.excelMasterDropdownForSheetMapping = [{ "key": "", "val": "--Select--" }];
        if(this.pageConfigurationJSON.jsonMasterMapping){
          this.pageConfigurationJSON.jsonMasterMapping.forEach(ele => {
            let obj = {
             "key":ele.name,
             "val":ele.name
            }
            this.excelMasterDropdownForSheetMapping.push(obj);
          });
        
          if(isSetOption){
            if(this.gridDynamicForApiMapping.sagGridObj.components['excelMaster']){
              this.gridDynamicForApiMapping.sagGridObj.components['excelMaster'].setOption(this.excelMasterDropdownForSheetMapping);
            }
          }
        }
      
      }

    checkFileUploadInFileSystem(value, params){
      let element = params.rowValue;
      if('file' == element.dataFindFrom && 'blob' == element.columnType && element.tableCoulmnType && 'varchar' == element.tableCoulmnType.toLowerCase()){
        this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
        this.gridDynamicForApiMapping.expandAll();
      }else if('blob' == element.columnType && element.tableCoulmnType && 'varchar' == element.tableCoulmnType.toLowerCase()){
        this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
        this.gridDynamicForApiMapping.expandAll();
      }

       

    }

    setDynamicComponet(rowsData){
     
      rowsData.forEach(element => {
        if(element.details){
          this.setDynamicComponet(element.details);
          element['dynamicCompName_formulaStaticValue'] = 'label';
          element.dynamicCompCellRenderView_formulaStaticValue = false;
        }else{
          if('file' == element.dataFindFrom && 'blob' == element.columnType && element.tableCoulmnType){
            element['dynamicCompName_formulaStaticValue'] = 'buttonIcon';
            element.dynamicCompCellRenderView_formulaStaticValue = true;
          } else {
            element['dynamicCompName_formulaStaticValue'] = 'text';
            element.dynamicCompCellRenderView_formulaStaticValue = false;
          }
        }

      });

    }

    setRowColor(gridData){
      gridData.forEach(rowData => {
       if(rowData.details){
          this.setRowColor(rowData.details);
        }else{
          this.setColorByDataFindFrom(rowData.dataFindFrom,rowData.sag_G_Index)
        }
     });
    }

  onChangeLabelName(value, params) {
    let rowIndex = params.rowIndex
    let modelFieldName = params.rowValue.modelFieldName;
    //if (!modelFieldName) {
      if (value) {
        let modelFieldName = this._getFieldNameFromCaptionName(value);
        this.gridDynamicForApiMapping.updateCell(rowIndex, "modelFieldName", modelFieldName);
      }
    //}
  }


    _getFieldNameFromCaptionName(captionName) {
      let words = captionName.split(/[\W_]+/);
      let builder = '';
      for (let i = 0; i < words.length; i++) {
        let word = words[i];
        if (i === 0) {
          word = word.length === 0 ? word : word.toLowerCase();
        } else {
          word = word.length === 0 ? word : word.charAt(0).toUpperCase() + word.substring(1).toLowerCase();
        }
        builder += word;
      }
      return builder;
    }

    setColorByDataFindFrom(dataFindFrom,sag_G_Index){ 
      if ("client_side" == dataFindFrom) {
        let colorProperty = { "background-color": "rgb(153, 235, 255)" }
        this.gridDynamicForApiMapping.setRowProperty(sag_G_Index, colorProperty);
      }
      if ("file" == dataFindFrom) {
        let colorProperty = { "background-color": "rgb(117 224 199)" }
        this.gridDynamicForApiMapping.setRowProperty(sag_G_Index, colorProperty);
      }
      
      if ("Formula" == dataFindFrom) {
        let colorProperty = { "background-color": "rgb(255, 255, 153)" }
        this.gridDynamicForApiMapping.setRowProperty(sag_G_Index, colorProperty);
      } if ("by_manual_method_with_aliase" == dataFindFrom || "by_manual_method" == dataFindFrom) {
        let colorProperty = { "background-color": "rgb(148, 184, 175)" }
        this.gridDynamicForApiMapping.setRowProperty(sag_G_Index, colorProperty);
      } if ("static_value" == dataFindFrom || "static_master_code" == dataFindFrom) {
        let colorProperty = { "background-color": "rgb(214, 194, 194)" }
        this.gridDynamicForApiMapping.setRowProperty(sag_G_Index, colorProperty);
      }
    }

    setValidationRowProperty(rowsData) {
    
      for (let i = 0; i < rowsData.length; i++) {
        const element = rowsData[i];
        if (element.isInvalid) {
          let colorProperty = { "background-color": "rgb(255, 204, 203)" }
          this.gridDynamicForApiMapping.setRowProperty(element.sag_G_Index, colorProperty);
          let errorResponse = element['toolTipMsg'];
          for (let key in errorResponse) {
            if (errorResponse.hasOwnProperty(key)) {
              let value = errorResponse[key];
              let cellColorProperty = { "background-color": "#dc3545" }
              this.gridDynamicForApiMapping.setColRowProperty(element.sag_G_Index, key, cellColorProperty);
            }
          }
        }
        if (element.details) {
          this.setValidationRowProperty(element.details);
        }
      }
  
    }

    setColorProperties(gridData){
 
      gridData.forEach(rowData => {
        // if(rowData.details){
        //   let colorProperty = {"background-color":"rgb(195 195 195)"}
        //   this.gridDynamicForApiMapping.disableRow( rowData.sag_G_Index);
        //   this.gridDynamicForApiMapping.setRowProperty(rowData.sag_G_Index,colorProperty);
        //   this.setColorProperties(rowData.details)
        // }
      });
    }
    
    disableMasterCell(gridData){
  
      gridData.forEach(rowData => {
    
        if(rowData.details){
          this.disableMasterCell(rowData.details)
        }else{
          if(rowData.isMaster == "Y"){
        this.gridDynamicForApiMapping.enableCell(rowData.sag_G_Index, "excelMaster"); 
        this.gridDynamicForApiMapping.enableCell(rowData.sag_G_Index, "tableMaster");
        this.gridDynamicForApiMapping.enableCell(rowData.sag_G_Index, "masterColumnName");
        this.gridDynamicForApiMapping.enableCell(rowData.sag_G_Index, "isMasterSaveAndDuplicateCheck");
        
      } else {
          this.gridDynamicForApiMapping.disableCell(rowData.sag_G_Index, "tableMaster");
         this.gridDynamicForApiMapping.disableCell(rowData.sag_G_Index, "masterColumnName");
         this.gridDynamicForApiMapping.disableCell(rowData.sag_G_Index, "isMasterSaveAndDuplicateCheck");

         if('Y' == this.pageConfigurationJSON.isJsonImport ){
          this.gridDynamicForApiMapping.disableCell(rowData.sag_G_Index, "excelMaster");
        }
      }
        }
    
       
      });
    }


    async fillTableNameSameValue(params, tableName){
 
      if (await ui.confirm('Do You Want To Fill Same Value In Next Remainig Row ?')) {
       let gridsize = this.gridDynamicForApiMapping.sagGridObj.AllRowIndex.length;
       for (let i = params.rowIndex; i < gridsize; i++) {
         this.gridDynamicForApiMapping.updateCell(i, "tableName", tableName);
         this.onChangeTable(tableName, i,null);
         this.setTableRelation(tableName);
       }
      }
     }

     onChangeTable(tableName, rowIndex,tableFieldBind) {
      if (tableName) {
    
        let dbData = {
          "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
          "targetDataSource": {},
          "operation": "COMPARESINGLE",
          "connectionRoleType": "admin",
          "dbtype": "master",
          "tableName": tableName
        }
        this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
          if (res) {
            this.setTableFieldDropdown(res, rowIndex,tableFieldBind,tableName);
          }
        }, Error => {
          alerts("Error While Fetching data");
        });
      }
    
    }

    setTableFieldDropdown(res, rowIndex,tableFieldBind,tableName) {
      this.tableFieldDropdownList = [{ "key": "", "val": "--Select--" }];;
      
    let tableFieldsInfo = this.getTableInfoWithCustomKeys(res,tableName);
 
    tableFieldsInfo.forEach(tableColumn => {
     
        let obj = {
          "key": tableColumn['columnName'],
          "val": tableColumn['columnName']
        }
        this.tableFieldDropdownList.push(obj);
      });
      this.tableFieldsMap.set(tableName, tableFieldsInfo);
      

      if (this.gridDynamicForApiMapping && this.gridDynamicForApiMapping.sagGridObj.components['tableField']) {
        this.gridDynamicForApiMapping.sagGridObj.components['tableField'].setOptionRow(this.tableFieldDropdownList, "tableField", rowIndex);
        if(tableFieldBind){ 
         this.gridDynamicForApiMapping.updateCell(rowIndex, "tableField", tableFieldBind);
    
         let tableFieldsList = this.tableFieldsMap.get(tableName);
         let item = _.find(tableFieldsList, { "columnName": tableFieldBind });
         if (item) {
           
          this.gridDynamicForApiMapping.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
          this.gridDynamicForApiMapping.updateCell(rowIndex, "tableCoulmnType", item.dataType);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "entityColumn", item.entityColumn);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "entityLable", item.entityLable);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "fkey", item.fkey);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "pkey", item.pkey);
           
         }
    
         let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
         if(pkObj){
          this.gridDynamicForApiMapping.updateCell(rowIndex, "primaryKey", pkObj.columnName);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
         }
    
        }
      }
    }

    onChangeTableField(tableField, params) {
      let rowIndex = params.rowIndex;
      if (tableField) {
        let tableName = params.rowValue.tableName;
      
        let tableFieldsList = this.tableFieldsMap.get(tableName);
        let item = _.find(tableFieldsList, { "columnName": tableField });
        if (item) {
          this.gridDynamicForApiMapping.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
          this.gridDynamicForApiMapping.updateCell(rowIndex, "tableCoulmnType", item.dataType);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "entityColumn", item.entityColumn);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "entityLable", item.entityLable);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "fkey", item.fkey);
          this.gridDynamicForApiMapping.updateCell(rowIndex, "pkey", item.pkey);
        }
        let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
        if(pkObj){
         this.gridDynamicForApiMapping.updateCell(rowIndex, "primaryKey", pkObj.columnName);
         this.gridDynamicForApiMapping.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
        }
    
      } else {
        this.gridDynamicForApiMapping.updateCell(rowIndex, "tableProperties", '');
        this.gridDynamicForApiMapping.updateCell(rowIndex, "tableCoulmnType", '');
        
      }
    }
    
    setTableRelation(tableName){
     let gridData = this.gridDynamicForApiMapping.getGridData();
     this.fillTableList = [];
     this._getAllFillTableList(gridData);
     this.fillTableList.push(tableName);
     let tableList = _.uniq(this.fillTableList);
   
     let relationList = [];
     tableList.forEach(element => {
       tableList.forEach(element1 => {
         if(element1 && element){
           let relatation =  _.find(this.tableFieldsMap.get(element) , {"parentTable":element1});
           if(relatation){
            relationList.push(relatation);
           }
         }
       });
     });

     this.pageConfigurationJSON['tableRelations'] = relationList;
 
      if ("N" == this.pageConfigurationJSON.isJsonImport) {
        let dataFindFrom = JSON.parse(JSON.stringify(this.dataFindFrom));
        dataFindFrom = _.filter(dataFindFrom, ele => { return ele.key != "_sheet" })
        this.pageConfigurationJSON['dataFindFrom'] = dataFindFrom;
      } else {
        this.pageConfigurationJSON['dataFindFrom'] = JSON.parse(JSON.stringify(this.dataFindFrom));
      }

     
     if(tableList){
       tableList.forEach(element => {
         if(element){
          this.pageConfigurationJSON['dataFindFrom'].push({
             "key": "pk_of_"+element, "val": "Pk of "+element
           });
         }
         
       });
     }
     if(this.gridDynamicForApiMapping && this.gridDynamicForApiMapping.sagGridObj.components['dataFindFrom']){
       this.gridDynamicForApiMapping.sagGridObj.components['dataFindFrom'].setOption(this.pageConfigurationJSON['dataFindFrom']);
     }

    this.fillTableList = [];
   }

   _getAllFillTableList(gridData){
    let tableList = _.map(gridData, 'tableName');
    tableList = _.uniq(tableList);
    if(tableList){
      tableList.forEach(element => {
        if(element){
          this.fillTableList.push(element);
        }
      });
    }
  
    gridData.forEach(element => {
      if(element.details){
        this._getAllFillTableList(element.details);
      }
    });
  }


  onChangeMasterTable(tableName, rowIndex,tableFieldBind) {
    if (tableName) {
  
      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName
      }
      this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
        if (res) {
         
          this.setMasterTableFieldDropdown(res, rowIndex,tableFieldBind,tableName);
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }else{
      if(this.gridDynamicForApiMapping.sagGridObj.components['masterColumnName']){
      this.gridDynamicForApiMapping.sagGridObj.components['masterColumnName'].setOptionRow([{ "key": "", "val": "--Select--" }], "masterColumnName", rowIndex);
    }
    }
  }
  
  setMasterTableFieldDropdown(res, rowIndex,tableFieldBind,tableName) {
    this.masterTableFieldDropdownList = [{ "key": "", "val": "--Select--" }];;
   
    let tableFieldsInfo = this.getTableInfoWithCustomKeys(res,tableName);
    tableFieldsInfo.forEach(tableColumn => {
        let obj = {
        "key": tableColumn['columnName'],
        "val": tableColumn['columnName']
      }
      this.masterTableFieldDropdownList.push(obj);
    });

    this.masterTableFieldMap.set(tableName, tableFieldsInfo);

    

    if (this.gridDynamicForApiMapping) {
      if(tableFieldsInfo.length > 0){
        this.gridDynamicForApiMapping.updateCell(rowIndex, "tableMasterEntityName", tableFieldsInfo[0]['entityName']);
      }
 
      if(this.gridDynamicForApiMapping.sagGridObj.components['masterColumnName']){
        this.gridDynamicForApiMapping.sagGridObj.components['masterColumnName'].setOptionRow(this.masterTableFieldDropdownList, "masterColumnName", rowIndex);
      }
      if(tableFieldBind){ 
       this.gridDynamicForApiMapping.updateCell(rowIndex, "masterColumnName", tableFieldBind);
       this.onChangeMasterTableField(tableFieldBind,tableName,rowIndex);
      }

    }
  }
  
  onChangeMasterTableField(tableField, tableName,rowIndex) {
  
    if (tableField) {
     let tableFieldsList = this.masterTableFieldMap.get(tableName);
      let item = _.find(tableFieldsList, { "columnName": tableField });
      if (item) {
        this.gridDynamicForApiMapping.updateCell(rowIndex, "masterEntityColumnName", item.entityColumn);
        this.gridDynamicForApiMapping.updateCell(rowIndex, "masterColumnDBDataType", item.dataType);
      }
      let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
      if(pkObj){
        this.gridDynamicForApiMapping.updateCell(rowIndex, "masterTablePrimaryKey", pkObj.columnName);
        this.gridDynamicForApiMapping.updateCell(rowIndex, "masterPrimarykeyDBDataType", pkObj.dataType);
      
      }
  
    }
  }

    setDisableEnableMasterColumn(value,rowIndex){
      if(value == "Y"){
        this.gridDynamicForApiMapping.enableCell(rowIndex, "tableMaster");
        this.gridDynamicForApiMapping.enableCell(rowIndex, "masterColumnName");
        this.gridDynamicForApiMapping.enableCell(rowIndex, "isMasterSaveAndDuplicateCheck");
        this.gridDynamicForApiMapping.enableCell(rowIndex, "excelMaster");
       
      
            
      } else {
        this.gridDynamicForApiMapping.updateCell(rowIndex, "tableMaster",'');
        this.gridDynamicForApiMapping.updateCell(rowIndex, "masterColumnName",'');
        this.gridDynamicForApiMapping.updateCell(rowIndex, "isMasterSaveAndDuplicateCheck",0);
        this.gridDynamicForApiMapping.updateCell(rowIndex, "addDisplayMasterColumn", []);
  

        this.gridDynamicForApiMapping.disableCell(rowIndex, "tableMaster");
        this.gridDynamicForApiMapping.disableCell(rowIndex, "masterColumnName");
        this.gridDynamicForApiMapping.disableCell(rowIndex, "isMasterSaveAndDuplicateCheck");
      
        if('Y' == this.pageConfigurationJSON.isJsonImport ){
          this.gridDynamicForApiMapping.updateCell(rowIndex, "excelMaster",'');
          this.gridDynamicForApiMapping.disableCell(rowIndex, "excelMaster");
        }

      }
    }

    
setAliaseNameInGrid (rowsData) {
  for (let index = 0; index < rowsData.length; index++) {
    let element = rowsData[index];
    if(element.details){
      this.aliaseStartIndex = this.aliaseStartIndex + 1;
      element["headerAlias"] =  this.headerAliasObj[this.aliaseStartIndex]
      this.setAliaseNameInGrid(element.details)
    } else {
      this.aliaseStartIndex = this.aliaseStartIndex + 1;
      element["headerAlias"] =  this.headerAliasObj[this.aliaseStartIndex]
    }
  }
}


  /**************************************Validation*********************************************************** */

  onClickValidation(params) {

    let index = params.rowIndex

    if (params.rowValue.columnType) {

      let columnType = params.rowValue.columnType;
      let validation = params.rowValue.validation

      const ref = this.dialogService.open(ImportExportValidationComponent, {
        header: "Validation",
        width: "100%",
        contentStyle: { "margin-top": "0px", "height": "100%" },
        styleClass: "service_full_model excel-demo-view",
        data: { "columnType": columnType, "validation": validation },

      });
      ref.onClose.subscribe((res) => {
        if (res) {
          this.gridDynamicForApiMapping.updateCell(index, "validation", res);
        }
      });
    }
    else{
      alerts("Please select first column type");
     }
  }


 



 
  addRecursionRowForElipsis(details,sag_G_Index,data){
    if(this.isRecursionOff){
      return;
    }
    if(details){
     for (let index = 0; index < details.length; index++) {
      if(this.isRecursionOff){
        break;
      }
       const rowData = details[index];
       if(rowData.sag_G_Index == sag_G_Index){
        details.splice(index+1, 0,data);
         
       let allSheetHeaderListSimpleFormat =   this._getApiFieldSimpleFormate(this.pageConfigurationJSON['apiFieldList']);

       this.autoSetFormula(rowData.sag_G_Index,this.pageConfigurationJSON['apiFieldList'],allSheetHeaderListSimpleFormat,"add");

        this.isRecursionOff = true;
        break;
      }else{
        this.addRecursionRowForElipsis(rowData.details,sag_G_Index,data)
      };
  
     }
    }
  }
  
 

  bindApiFieldDataForMasterExtraFields(){
    if(this.gridDynamicAddMasterExtraColumn){
     let gridData = this.gridDynamicAddMasterExtraColumn.getGridData();
     if(gridData){
       gridData.forEach(rowData => {
         if(rowData.tableName && rowData.tableField){
           this.onChangeTableForMasterExtraColumn(rowData.tableName, rowData.sag_G_Index,rowData.tableField);
         }
       });
     }
    }
  }



addRecursionRowForChildren(details,sag_G_Index){
  if(this.isRecursionOff){
    return;
  }
  if(details){
   for (let index = 0; index < details.length; index++) {
     if(this.isRecursionOff){
       break;
     }
     const rowData = details[index];
     if(rowData.details && rowData.details.length > 0){
      this.addRecursionRowForChildren(rowData.details,sag_G_Index)
    }else{
      if(rowData.sag_G_Index == sag_G_Index){
        let arr = [];
        arr.push(this.getEmptyObjForAddRow());
        rowData["details"] = arr;
        this.isRecursionOff = true;
        break;
      };
    }
   }
  }
}
    
  onChangeTableForMasterExtraColumn(tableName, rowIndex,tableFieldBind) {
    if (tableName) {
  
      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName
      }
      this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
        if (res) {
          this.setTableFieldDropdownForMasterExtraColumn(res, rowIndex,tableFieldBind,tableName);
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }
  
  }
  
  setTableFieldDropdownForMasterExtraColumn(res, rowIndex,tableFieldBind,tableName) {
    this.tableFieldDropdownList = [{ "key": "", "val": "--Select--" }];;
   let tableFieldsInfo =  this.getTableInfoWithCustomKeys(res,tableName);
   tableFieldsInfo.forEach(tableColumn => {
   
      let obj = {
        "key": tableColumn['columnName'],
        "val": tableColumn['columnName']
      }
    
      this.tableFieldDropdownList.push(obj);
    });
    this.tableFieldsMap.set(tableName, tableFieldsInfo);

    if (this.gridDynamicAddMasterExtraColumn && this.gridDynamicAddMasterExtraColumn.sagGridObj.components['tableField']) {
      this.gridDynamicAddMasterExtraColumn.sagGridObj.components['tableField'].setOptionRow(this.tableFieldDropdownList, "tableField", rowIndex);
      if(tableFieldBind){ 
       this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableField", tableFieldBind);
  
       let tableFieldsList = this.tableFieldsMap.get(tableName);
       let item = _.find(tableFieldsList, { "columnName": tableFieldBind });
       if (item) {
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties", this.getTableProperties(item));
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", item.dataType);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "entityColumn", item.entityColumn);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "entityLable", item.entityLable);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "fkey", item.fkey);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "pkey", item.pkey);
       }
  
       let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
       if(pkObj){
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKey", pkObj.columnName);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
       }
  
      }
    }
  }
  
  onChangeTableFieldForMasterExtraFields(tableField, params) {
    let rowIndex = params.rowIndex;
    if (tableField) {
      let tableName = params.rowValue.tableName;
     
      let tableFieldsList = this.tableFieldsMap.get(tableName);
      let item = _.find(tableFieldsList, { "columnName": tableField });
      if (item) {
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties",this.getTableProperties(item));
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", item.dataType);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "entityColumn", item.entityColumn);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "entityLable", item.entityLable);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "fkey", item.fkey);
        this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "pkey", item.pkey);
      
        
      }
      let pkObj = _.find(tableFieldsList, { "pkey": "Y" });
      if(pkObj){
       this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKey", pkObj.columnName);
       this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "primaryKeyType", pkObj.dataType);
      }
  
    }else{
      this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableProperties", '');
      this.gridDynamicAddMasterExtraColumn.updateCell(rowIndex, "tableCoulmnType", '');
    }
  }

 

  /******************Add Row Delete Row****************** */
  
  addRowApiFieldMapping(){
     let obj = this.getEmptyObjForAddRow();
     this.pageConfigurationJSON['apiFieldList'].push(obj);
     this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
     try {
      this.gridDynamicForApiMapping.expandAll();
     } catch (error) {
       
     }
  }

  async deleteRowApiFieldMapping(rowIndex){
  

    let aliaseUsageHeader = this.checkHeaderAliaseUsage();
  
    let isDeleteRow = false;
   
    if(aliaseUsageHeader){
      if (await ui.confirm('You use this row refrence in '+aliaseUsageHeader+" ! Do you want to delete this row ")) {
        isDeleteRow = true
      }
    } else{
      isDeleteRow = true;
    }
   
    if(isDeleteRow){
      this.deleteRowJsonMappingTree(rowIndex,  this.pageConfigurationJSON['apiFieldList'])
     let allSheetHeaderListSimpleFormat =   this._getApiFieldSimpleFormate(this.pageConfigurationJSON['apiFieldList']);
   
     this.autoSetFormula(rowIndex,this.pageConfigurationJSON['apiFieldList'],allSheetHeaderListSimpleFormat,"delete");
   
  
    this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
    this.gridDynamicForApiMapping.expandAll();
    }


   
   
  }
  
  deleteRowJsonMappingTree(sag_G_Index,array){
  
    for (let index = 0; index < array.length; index++) { 
      const element = array[index];
      if(element.details){
        this.deleteRowJsonMappingTree(sag_G_Index,element.details);
       }
       if(element.sag_G_Index == sag_G_Index){
        array.splice(index, 1)
       }
    }
  }


  /********************Add Master Extra Field****************************** */
  openAddMasterExtraColumnModal(){
    $('#addMasterExtraColumnModal').modal('show')
   }
   
   closeAddMasterExtraColumnModal(){
     $('#addMasterExtraColumnModal').modal('hide')
   }

   addMasterExtraColumnGrid(rowsData) {
    var sourceDiv = document.getElementById("addMasterExtraColumnGridId");
    var columns:any = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": false,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Label Name",
        "field": "labelName",
        "filter": false,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      {
        "header": "Name",
        "field": "modelFieldName",
        "filter": false,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      {
        "header": "Data Find From",
        "field": "dataFindFrom",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Refrence Column",
        "field": "apiFieldColumnReference",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Column Type",
        "field": "columnType",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Date Format",
        "field": "dateFormat",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Table Name",
        "field": "tableName",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "left",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Table Field",
        "field": "tableField",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Table Properties",
        "field": "tableProperties",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": true
      },
      
      {
        "header": "Duplicate Check",
        "field": "uniqueConstraint",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "text-align": "center",
        "search": true,
        "component": 'checkbox',
        "cellRenderView": true
      },
      {
        "header": "Formula/Static Value/Method Calling",
        "field": "formulaStaticValue",
        "filter": false,
        "width": "250px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      
    ];
  
    let self = this;
  
    let fieldTypeList = [
      { "key": "", "val": "--Select--" },
      { "key": "STRING", "val": "STRING" },
      { "key": "NUMERIC", "val": "NUMERIC" },
      { "key": "BOOLEAN", "val": "BOOLEAN" },
      { "key": "DATE", "val": "DATE" },
  
    ];
   
   
  
     let dataFindFrom = [
      { "key": "", "val": "--Select--" },
      { "key": "client_side", "val": "Client Side" },
      { "key": "by_manual_method", "val": "Manual Method With static" },
      { "key": "static_value", "val": "Static Value" },
     ];
  
  
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
      
    }
  
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        frezzManager: { "sno": "left", "name": "left","cellDesc":"left","cellRefrence":"left" },
        components: {},
        rowCustomHeight :20,
        cellCustomPadding:5,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        callBack: {
          "onChangeSelect_tableName": function (ele, params) {
            let value = ele.value;
            ele.onkeydown = function (event) {
              if (event.keyCode == 13) {
                self.fillTableNameSameValueForMasterExtraColumn(params, value);
                
              }
            }
            self.onChangeTableForMasterExtraColumn(ele.value, params.rowIndex,null);
            
          },
          "onChangeSelect_dataFindFrom": function (ele, params) {
           if("client_side"==ele.value){
            self.gridDynamicAddMasterExtraColumn.enableCell(params.rowIndex, "apiFieldColumnReference");
           
           }else{
            self.gridDynamicAddMasterExtraColumn.disableCell(params.rowIndex, "apiFieldColumnReference");
            self.gridDynamicAddMasterExtraColumn.updateCell(params.rowIndex, "apiFieldColumnReference","");
           }
          },
          "onChangeSelect_tableField": function (ele, params) {
            self.onChangeTableFieldForMasterExtraFields(ele.value, params)
          },
         
        },
     
        dropDownJson_columnType: fieldTypeList,
        dropDownJson_tableName: this.tableListDropdownList,
        dropDownJson_tableField: [{ "key": "", "val": "--Select--" }],
        dropDownJson_dataFindFrom: dataFindFrom, 
        dropDownJson_apiFieldColumnReference: this._getApiFieldColumnRefernce(), 
        dropDownJson_dateFormat:this.dateFormateList,
      };
    
  
      this.gridDynamicAddMasterExtraColumn = SdmtGridT(sourceDiv, gridData, true, true);
    
      this.disableApiFieldColumnRef();
      return this.gridDynamicAddMasterExtraColumn;
    }
  }

  disableApiFieldColumnRef(){
    let gridData =  this.gridDynamicAddMasterExtraColumn.getGridData();
    if(gridData){
      gridData.forEach(element => {
        if("client_side" == element.dataFindFrom){
          this.gridDynamicAddMasterExtraColumn.enableCell(element.sag_G_Index, "apiFieldColumnReference");
         } else{
          this.gridDynamicAddMasterExtraColumn.disableCell(element.sag_G_Index, "apiFieldColumnReference");
          this.gridDynamicAddMasterExtraColumn.updateCell(element.sag_G_Index, "apiFieldColumnReference","");
         }
      });
    }
  }

  async fillTableNameSameValueForMasterExtraColumn(params, tableName){
    if (await ui.confirm('Do You Want To Fill Same Value In Next Remainig Row ?')) {
     let gridsize = this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length;
     for (let i = params.rowIndex; i < gridsize; i++) {
       this.gridDynamicAddMasterExtraColumn.updateCell(i, "tableName", tableName);
       this.onChangeTableForMasterExtraColumn(tableName, i,null);
      
      
     }
    }
   }
  

  addRowMasterExtraColumn(){
      
    let selectedRowData = this.gridDynamicForApiMapping.getSeletedRowData();
    let tableMaster = selectedRowData.tableMaster
  
    let index = this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length;
    let obj = {
          "dataFindFrom":"",
          "name": "",
          "modelFieldName": "",
          "index": "",
          "tableName":tableMaster,
          "tableField":"",
          "tableProperties":"",
        
     }
  
     this.gridDynamicAddMasterExtraColumn.addRowByIndex(index, obj);
     setTimeout(() => {
      this.onChangeTableForMasterExtraColumn(tableMaster, index,null);
      
     }, 500);
     
  }
 
  deleteRowMasterExtraColumn(){
    let selectedRowData = this.gridDynamicAddMasterExtraColumn.getSeletedRowData();
    if(selectedRowData){
      this.gridDynamicAddMasterExtraColumn.deleteRow(selectedRowData.sag_G_Index);
      if (this.gridDynamicAddMasterExtraColumn.sagGridObj
        && this.gridDynamicAddMasterExtraColumn.sagGridObj.AllRowIndex.length == 0) {
        this.addMasterExtraColumnGrid([]); 
  }
    }
  
  }

  okMasterExtraColumn(){
    let selectedRowData = this.gridDynamicForApiMapping.getSeletedRowData();
    let gridData = this.gridDynamicAddMasterExtraColumn.getGridData();
    if(gridData){
      this.gridDynamicForApiMapping.updateCell(selectedRowData.sag_G_Index, "childMasterExtraFields",gridData);
    }else{
      this.gridDynamicForApiMapping.updateCell(selectedRowData.sag_G_Index, "childMasterExtraFields",[]);
    }
    
  
    this.closeAddMasterExtraColumnModal();
   }

  _getApiFieldColumnRefernce(){
  
    this.apiFieldColumnDropdown = [{ "key": "", "val": "--Select--" }];
  
  let selectedRowData =  this.gridDynamicForApiMapping.getSeletedRowData();
  let rowIndex = selectedRowData.sag_G_Index;
  
  let gridData =  this.gridDynamicForApiMapping.getGridData();
  this._getApiFieldColumnRefernceRecursion(gridData,rowIndex)
    
  return this.apiFieldColumnDropdown;
  
  }

  _getApiFieldColumnRefernceRecursion(gridData,rowIndex){
    if (gridData) {
      gridData.forEach(element => {
        if(element.details){
          this._getApiFieldColumnRefernceRecursion(element.details,rowIndex);
        } else{
          if (element.sag_G_Index <= rowIndex || "client_side" == element.dataFindFrom) {
            let obj = {
              "key": element.name,
              "val": element.name
            }
            this.apiFieldColumnDropdown.push(obj);
          }
        }
      });
    }
  }

  getEmptyObjForAddRow(){
    let obj = {
      "labelName":"",
      "modelFieldName":"",
      "dataFindFrom":"",
      "columnType":"",
      "dateFormat":"",
      "validation":[],
      "tableName":"",
      "tableField":"",
      "isMaster":"",
      "tableMaster":"",
      "masterColumnName":"",
      //"uniqueConstraint":0,
      "isMasterSaveAndDuplicateCheck":0,
      "formulaStaticValue":"",
      //"fetchBy":0,
      //"groupBy":0
      "isDisplayColumn":true,
      "isModifyColumn":true
  }
  return obj;
  }

  onChangeSheetColumnType(columnType, rowIndex){
 
    let textAlign = null;
    let decimalFormat = [];
    
    switch (columnType.toLowerCase()) {
      case "string":
          textAlign = "left";
          decimalFormat =  [];
        break;
      case "boolean":
          textAlign = "center";
          decimalFormat =  [];
        break;
      case "date":
          textAlign = "center";
          decimalFormat =  [];
        break;
      case "number":
          textAlign = "right";
          decimalFormat =  ["decimal_format"];
       case "integer":
          textAlign = "right";
          decimalFormat =  [];
         break;
    
      }
      this.gridDynamicForApiMapping.updateCell(rowIndex, "textAlign", textAlign);
      this.gridDynamicForApiMapping.updateCell(rowIndex, "decimalFormat", decimalFormat);
       
   }

  /********************Api JSON**************************** */
 

  loadData(){
   
   if(!this.pageConfigurationJSON['dataFindFrom'] || this.pageConfigurationJSON['dataFindFrom'].length == 0 ){
      if ("N" == this.pageConfigurationJSON.isJsonImport) {
        let dataFindFrom = JSON.parse(JSON.stringify(this.dataFindFrom));
        dataFindFrom = _.filter(dataFindFrom, ele => { return ele.key != "_sheet" })
        this.pageConfigurationJSON['dataFindFrom'] = dataFindFrom;
      } else {
        this.pageConfigurationJSON['dataFindFrom'] = JSON.parse(JSON.stringify(this.dataFindFrom));
      }
    }

    
   if ("Y" == this.pageConfigurationJSON.isJsonImport) {
      this.isJsonImportFlag = true;
   } else {
      this.isJsonImportFlag = false;
   }
   
    this.mapMasterDropdownForSheetMapping(false);

    this.javaApiGrid(this.javaApiList);

    this.javaApiFieldMappingGrid(this.pageConfigurationJSON.apiFieldList);

    setTimeout(() => {
      let gridData = this.gridDynamicForApiMapping.getGridData();
      this.bindTableFieldOnGridLoad(gridData);
    
    }, 500);
   
    try {
      this.gridDynamicForApiMapping.expandAll();
    } catch (error) {
      
    }
   

  }

  bindTableFieldOnGridLoad(gridData){
    if(this.gridDynamicForApiMapping){
     if(gridData){
       gridData.forEach(rowData => {
         if(rowData.details){
          this.bindTableFieldOnGridLoad(rowData.details);
         }
        
         if(rowData.tableName && rowData.tableField){
           this.onChangeTable(rowData.tableName, rowData.sag_G_Index,rowData.tableField);
           this.onChangeMasterTable(rowData.tableMaster, rowData.sag_G_Index,rowData.masterColumnName);
         }
       });
     }
    }
  }

/******************************File Upload********************************************** */

onChangeFileUpload(isFileUpload){
  if("Y"==isFileUpload){
    let rowData = this.getEmptyObjForAddRow();
    rowData["labelName"] = "MultipartFile";
    rowData["modelFieldName"] = "file";
    

    let arr = [];
    let fileNameObj = this.getEmptyObjForAddRow();
    fileNameObj["labelName"] = "File Name";
    fileNameObj["modelFieldName"] = "fileName";
    fileNameObj["columnType"] = "string";
    fileNameObj["dataFindFrom"] = "file";
    
    

    let fileDataObj = this.getEmptyObjForAddRow();
    fileDataObj["labelName"] = "File Data";
    fileDataObj["modelFieldName"] = "fileData";
    fileDataObj["columnType"] = "blob";
    fileDataObj["dataFindFrom"] = "file";

    arr.push(fileNameObj);
    arr.push(fileDataObj);
    
    rowData["details"] = arr;

    this.pageConfigurationJSON['apiFieldList'].splice(0, 0,rowData);

     this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
     this.gridDynamicForApiMapping.expandAll();
  } else {
    
    let multipartFile =  _.find(this.pageConfigurationJSON['apiFieldList'], {"labelName": "MultipartFile"});
    if(multipartFile){
      this.deleteRowJsonMappingTree(multipartFile.sag_G_Index ,  this.pageConfigurationJSON['apiFieldList'])
      this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
      this.gridDynamicForApiMapping.expandAll();
    }
  }
 
 }









  /******************************************Generate Java Api******************************************************************************** */
dbMappingform: FormGroup;
_rootPackagePath="com.sagipl" 

 


 

validateApiFieldData(javaApiInfo) {
  this.pageConfigurationJSON = javaApiInfo;
  this.oldPageConfigurationJSON = JSON.parse(JSON.stringify(this.pageConfigurationJSON));
  this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
  this.gridDynamicForApiMapping.expandAll();
}


initializeForm(projectName) {
 this.dbMappingform = this.formbuilder.group({
   projectName: [{ value: projectName, disabled: true }, [Validators.required]],
   moduleName: [{ value: '', disabled: false }, [Validators.required]],
   packageName: [{ value: '', disabled: true }, [Validators.required]],
   PageWindowName: [{ value: '', disabled: false }, [Validators.required]],
   controllerName: [{ value: '', disabled: false }, [Validators.required]],
   serviceName: [{ value: '', disabled: false }, [Validators.required]],
   serviceImplName: [{ value: '', disabled: false }, [Validators.required]],
   daoName: [{ value: '', disabled: false }, [Validators.required]],
   daoImplName: [{ value: '', disabled: false }, [Validators.required]],
   classLevelApiName: [{ value: '', disabled: false }, [Validators.required]],
   projectSourcePath: [{ value: this.sagStudioService.getSagStudioData("autoGeneretedProjectPath"), disabled: false }, [Validators.required]],
   userName: [],
   userId: [],
   projectId: [],
   projectname: [],
   userwrokspace: [],
   menuId: [],
   javaApiType: [],
   modelPackage:[],
   entityPackage:[],
   documentation:[],
   apiId:[{ value: null, disabled: false }],
   apijsonId:[{ value: null, disabled: false }],
   controllerMethodList:[{ value: null, disabled: false }],
   repositoryMethodList:[{ value: null, disabled: false }],
   ngsrcfilePath:[{ value: '', disabled: false }],
})
 
}

setDefaultValueInDbMappingForm(){
  let projectName=this.dbMappingform.controls["projectName"].value;
  projectName=this.convertProjectNameToPackageName(projectName);
  
  this.dbMappingform.controls["modelPackage"].setValue(`${this._rootPackagePath}.${projectName}.model`);
  this.dbMappingform.controls["entityPackage"].setValue(`${this._rootPackagePath}.${projectName}.entity`);

  const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
  if(sessionStoragedatauserId!=undefined){
    this.dbMappingform.controls["userName"].setValue(sessionStoragedatauserId.data.clientInfo.usrName);
    this.dbMappingform.controls["userId"].setValue(sessionStoragedatauserId.data.clientInfo.usrId);
   
  
  let setProjectInfo= this.shareService.getDataprotool("selectedProjectChooseData");
  if(setProjectInfo!=undefined){
    this.dbMappingform.controls["projectId"].setValue(setProjectInfo.projectId);
    this.dbMappingform.controls["projectname"].setValue(setProjectInfo.projectname);
    this.dbMappingform.controls["userwrokspace"].setValue(setProjectInfo.jwspace);
    let componentNode=  this._sagStudioService.getSagStudioData("currentNodeForFileView");
    if(componentNode){
      let projectPath=componentNode.projectPath;
      let uniqePath=projectPath.replace(setProjectInfo.projectname,"");
      if(uniqePath.startsWith('/')){
       uniqePath=uniqePath.replace('/',"");
      }
     this.dbMappingform.controls["ngsrcfilePath"].setValue(uniqePath);
    }
  }
  }else{
    alerts("user not found")
  }
   let menuId= this.shareService.getDatadbtool("ComponentMenuId");
   if(menuId && menuId!=null && menuId!="" ){
    this.dbMappingform.controls["menuId"].setValue(menuId);
   }else {
     alerts("menu not found")
   }
   
  let componentName = this._sagStudioService.completeJsonWithContainer.angular.componentName;

  let menuName= this.shareService.getDatadbtool("ComponentMenuName");
  if(menuName!=undefined && menuName!=null && menuName!=""){
    let moduleName= this.convertMenuNameToModuleName(menuName);
    this.dbMappingform.controls["moduleName"].setValue(moduleName);
    this.onModuleNameChange(moduleName,true);
  }else{
    if(componentName){
      this.dbMappingform.controls["moduleName"].setValue(this.convertMenuNameToModuleName(componentName));
      this.onModuleNameChange(componentName.toLowerCase(),true);
    }
  }

  if(componentName){
    this.dbMappingform.controls["PageWindowName"].setValue(componentName.substring(0, 1).toUpperCase()+componentName.substring(1));
    
    this.onPageChange(componentName.substring(0, 1).toUpperCase()+componentName.substring(1),false,null );
   
   
  }
 
}

onPageChange(pageName,isById,formApiConfigId) {
  this.jsonGeneratedFileList = [];
  if (pageName == "") {
    this.dbMappingform.patchValue({
      controllerName: "",
      serviceName: "",
      serviceImplName: "",
      daoName: "",
      daoImplName: "",
      classLevelApiName: "",
    })
  
    return;
  } else if (pageName != null) {
  
    this.dbMappingform.patchValue({
      controllerName: pageName + "Controller",
      serviceName: pageName + "Service",
      serviceImplName: pageName + "ServiceImpl",
      daoName: pageName + "Dao",
      daoImplName: pageName + "DaoImpl",
      classLevelApiName: pageName.toLowerCase(),
     
    })
  }

  if(pageName){
    this.dbMappingform.controls["PageWindowName"].setValue(pageName.substring(0, 1).toUpperCase()+pageName.substring(1));
    this.isValidUserAndFile(true);
    this.cheackMethodAlreadyExistInJavaController(pageName);
   
    if(isById){
      this.getFormApiConfigurationById(formApiConfigId);
    }else{
      this.getFormApiConfiguration();
    }

    this.getAllApiListPageFormWise();
  }

}

cheackMethodAlreadyExistInJavaController(pageName){
  this.controllerMethodList = [];
 
    let projectPath= this.dbMappingform.controls["projectSourcePath"].value;
    let packageName=this.dbMappingform.controls["packageName"].value;
   let controllerName=pageName+"Controller"

    let controllerClassFullyQulifiedName=packageName+".controller."+controllerName;

     let reqObj = {
       projectPath: projectPath,
       classPackage: controllerClassFullyQulifiedName,
       className:controllerName
     }
  
     this.autoJavacodeService.getControllerClassMethodList(reqObj).subscribe(res => {
       if (res.status == true) {
         let methodList=res.data
         if(methodList){
          this.controllerMethodList =  methodList;
         }
       
     
       } else {
         if (res.status == false) {
           //alerts(res.msg);
          }
       }
  
     }, Error => {
       alerts("Error While Generating");
     })
  

}

getAllApiListPageFormWise() {

  this.javaApiList = [];

  let formApiConfigModel = {
    'ngsrcfilePath': this.dbMappingform.controls['ngsrcfilePath'].value,
    'projectId': this.dbMappingform.controls['projectId'].value,
    "userId": this.dbMappingform.controls['userId'].value,
    "pageName": this.dbMappingform.controls['PageWindowName'].value,
    "moduleName": this.dbMappingform.controls['moduleName'].value,
  }

  this.autoJavacodeService.getAllApiListPageFormWise(formApiConfigModel).subscribe(res => {
    if (res.status == 200) {
      this.javaApiList = res.data;
      this.javaApiGrid(this.javaApiList);

    }

  }, Error => {
    alerts("Error While Fetching Data");
  });
}


getFormApiConfiguration() {
  
  let formApiConfigModel = {
    'ngsrcfilePath': this.dbMappingform.controls['ngsrcfilePath'].value,
    'formConfigName': this.dbMappingform.controls['PageWindowName'].value,
    'projectId':this.dbMappingform.controls['projectId'].value,
  }

  this.autoJavacodeService.getFormApiConfiguration(formApiConfigModel).subscribe(res => {
      if (res.status == 200 && res.data && res.data.apiFieldList && res.data.apiFieldList.length > 0) {
        this.pageConfigurationJSON = res.data;
        this.oldPageConfigurationJSON = JSON.parse(JSON.stringify(this.pageConfigurationJSON));
        this.managePageConfigurationJSONForAiImport();
        this.loadData();
        this.isValidUserAndFile(true);
      }else{
        this.getFinaldbMappingJson();
      }
    }, Error => {
      alerts("Error While Fetching Data");
    });
  }

  getFormApiConfigurationById(formApiConfigId) {
  
    this.autoJavacodeService.getFormApiConfigurationById(formApiConfigId).subscribe(res => {
        if (res.status == 200 && res.data && res.data.apiFieldList && res.data.apiFieldList.length > 0) {
          this.pageConfigurationJSON = res.data;
          this.oldPageConfigurationJSON = JSON.parse(JSON.stringify(this.pageConfigurationJSON));
          this.managePageConfigurationJSONForAiImport();
          this.loadData();
          this.isValidUserAndFile(true);
        } else {
          this.getFinaldbMappingJson();
        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
    }

 

  saveFormApiConfiguration() {
  
    let formApiConfigModel = {
      'ngsrcfilePath': this.dbMappingform.controls['ngsrcfilePath'].value,
      'formConfigName': this.dbMappingform.controls['PageWindowName'].value,
      'configJson':this.pageConfigurationJSON,
      'projectId':this.dbMappingform.controls['projectId'].value,
    }
  
    this.autoJavacodeService.saveFormApiConfiguration(formApiConfigModel).subscribe(res => {
        if (res.status == 200) {
        success(res.msg)
        }
      }, Error => {
        alerts("Error While Fetching Data");
      });
    }

convertProjectNameToPackageName(projectName){
  projectName=projectName.replace(/\s/g, "").toLowerCase();
  projectName=projectName.replace(/[^\w\s]/gi, '')
  return projectName;
}

convertMenuNameToModuleName(menuName){
 menuName=menuName.replace(/\s/g, "").toLowerCase();
 menuName=menuName.replace(/[^\w\s]/gi, '')
  
 if(this.JAVA_KEYWORDS.includes(menuName)){
   menuName = menuName+"1";
 }

 return menuName;
}

onModuleNameChange(filedName,isOnPageLoad) {
  
  if(filedName==""){
    this.dbMappingform.controls["packageName"].setValue("");
      return;
   }
  let projectName = this.dbMappingform.controls["projectName"].value;
  this.dbMappingform.controls["packageName"].setValue(this._rootPackagePath+"." + projectName.toLowerCase() + "." + filedName.toLowerCase());

  let PageWindowName=this.dbMappingform.controls["PageWindowName"].value;
  if(PageWindowName!=""){
    //this.onPageNameChange(PageWindowName);
  }
  if(!isOnPageLoad){
    this.isValidUserAndFile(true);
  }
 
  // this.setChildCompDataOnChangeModuleAndPage();

}


isAccessToCreateNewPackageGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Name",
    field: "packageName",
    filter: true,
    width: "300px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Path",
    field: "packagePath",
    filter: true,
    width: "300px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()",
  },
  
];

isCreateFileToAnotherUserGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Name",
    field: "srcFilePath",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "User Name",
    field: "userName",
    filter: true,
    width: "168px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()",
  },
  
];

isAccessToCreateNewFileGridColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "Package Name",
    field: "packageName",
    filter: true,
    width: "400px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
 
  
];
isAccessToCreateNewApiColmn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Name",
    field: "fileName",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
  
];
isAccessToModifyApiColumn = [
  {
    header: "Sr.No",
    field: "sno",
    "editable": false,
    width: "50px",
    "align": "center",
    "ng-dblclick": "dblClickSection()"
  },
  {
    header: "File Path",
    field: "srcfileUniqePath",
    filter: true,
    width: "500px",
    "editable": false,
    "text-align": "left",
    search: true,
    "ng-dblclick": "dblClickSection()"
  }
  
];

accessRightErrorMsg=""
gridDynamicapiAlreadyAssign:any
isUserValid : boolean = false;
isGeneratedFileValid:boolean = false;

isValidUserAndFile(flag) {
  let reqObj = this.dbMappingform.getRawValue();

   
  this.autoJavacodeService.isCreatedFileValid(reqObj,"all_api").subscribe(res => {
    this.isGeneratedFileValid = res.isValid;
    if (!res.isValid) {
      alerts(res.msg)
    } else{
      this.isUserValidToCreateApi(flag);
    }  
  }, Error => {
    alerts("Error While validate generated file");
  });



    
  
}



isUserValidToCreateApi(flag) {
  let reqObj = this.dbMappingform.getRawValue();
  this.autoJavacodeService.userValidToCreateApi(reqObj).subscribe(res => {
    if (res.isValid) {
      this.isUserValid = true;
    } else {
      this.isUserValid = false;
      if(flag){ 
       
        if(res.status == 401){
          this.accessRightErrorMsg = res.msg;
          $("#apiAlreadyAssignId").modal('show');
          this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewPackageGridColmn);
        } else  if(res.status == 402){
          this.accessRightErrorMsg = res.msg;
          $("#apiAlreadyAssignId").modal('show');
          this.apiAlreadyAssignGrid(res.data,this.isAccessToModifyApiColumn);
        }else if(res.status == 403){
          this.accessRightErrorMsg = res.msg;
          $("#apiAlreadyAssignId").modal('show');
          this.apiAlreadyAssignGrid(res.data,this.isAccessToCreateNewFileGridColmn);
        }else if(res.status == 404){
          this.accessRightErrorMsg = res.msg;
          $("#apiAlreadyAssignId").modal('show');
          this.apiAlreadyAssignGrid(res.data,this.isCreateFileToAnotherUserGridColmn);
        }
        else{
         alerts(res.msg)
        }
       }
     
    }
  }, Error => {
    alerts("Error While validate user");
  });
}

apiAlreadyAssignGrid(rowsData,columns) {
  const sourceDiv = document.getElementById("apiAlreadyAssignIdGrid");
  
  var self = this;

 

  let SagGridRowStatus = rowsData;
  for (let i = 0; i < SagGridRowStatus.length; i++) {
    SagGridRowStatus[i]["sno"] = i + 1;
  }

  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      components: {},
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
     
    };
    this.gridDynamicapiAlreadyAssign = SagGridMPT(sourceDiv, gridData, true, true);
    this.setColorOnGrid1();
  }
}

setColorOnGrid1() {
  let self = this;
  let gridRowsData = self.gridDynamicapiAlreadyAssign.sagGridObj.originalRowData;
  gridRowsData.forEach((ele, index) => {
    // change Row Color
    if (ele.apiName || ele.apiType || ele.assignTo || ele.assignBy) {
      self.gridDynamicapiAlreadyAssign.setColRowProperty(index, 'srcFilePath', { "background": "#fff8e1" });
      self.gridDynamicapiAlreadyAssign.setColRowProperty(index, 'userName', { "background": "#f8d7da" });
     
    }

    ;
  });

}




_getApiFieldSimpleFormate(apiFieldList) {
  const treeDetails = JSON.parse(JSON.stringify(apiFieldList)); 
  const simpleDetails = [];

  treeDetails.forEach(obj => {
    if (!Object.prototype.hasOwnProperty.call(obj, "details")) {
      simpleDetails.push(obj);
    } else if (Object.prototype.hasOwnProperty.call(obj, "details")) {
      const details = obj.details;
      this.convertDataTreeToList(simpleDetails, details);
    }
  });

  return simpleDetails;
}

convertDataTreeToList(simpleDetails, treeDetails) {
  treeDetails.forEach(obj => {
    if (!Object.hasOwnProperty.call(obj, "details")) {
      simpleDetails.push(obj);
    } else if (Object.hasOwnProperty.call(obj, "details")) {
      let details = obj.details;
      this.convertDataTreeToList(simpleDetails, details);
    }
  });
}

 

/**************************************Auto set Formula*********************************************************** */


autoSetFormula(rowIndex,gridData,allSheetHeaderListSimpleFormat,opName:String){ 
  //let  gridData =  this.jsonSchema['details'];

  for (let index = 0; index < gridData.length; index++) {
    
     const element = gridData[index];

     if(element.details){
      this.autoSetFormula(rowIndex,element.details,allSheetHeaderListSimpleFormat,opName);
     } else {
      if ("Formula" == element.dataFindFrom) {
        let formulaStaticValue = element.formulaStaticValue;
        if (formulaStaticValue) {
          let replaceValue = this._getCalculateValueBodyForDisplay(allSheetHeaderListSimpleFormat, formulaStaticValue, rowIndex,opName);
          gridData[index]["formulaStaticValue"] = replaceValue;
        }
      }
  
      if ("by_manual_method_with_aliase" == element.dataFindFrom) {
      
        let formulaStaticValue = element.formulaStaticValue;
      
        if (formulaStaticValue) {
          const argument = formulaStaticValue.substring(formulaStaticValue.indexOf("(") + 1, formulaStaticValue.indexOf(")"));
          let replaceArgument = this._getCalculateValueBodyForDisplay(allSheetHeaderListSimpleFormat, argument, rowIndex,opName);
          const methodName = formulaStaticValue.substring(0, formulaStaticValue.indexOf("("));
          const changeMethod = `${methodName}(${replaceArgument})`;
          gridData[index]["formulaStaticValue"] = changeMethod;
        }
      }
     }
  }
  }

  


  _getCalculateValueBodyForDisplay(sheetHeaderList, formulaStaticValue,rowIndex,opName:String) {
    let split = formulaStaticValue.split(/[^\w\s]/gi);
  
    let list = split.slice();

    list  = _.map(list,_.trim)

    list.sort((a, b) => b.length - a.length);
  
    let number = 0;
    for (let value of list) {
      if (this.isValidFormulaAliase(formulaStaticValue, value)) {
        let findAny = sheetHeaderList.find(ele => value === ele.headerAlias);
        if (findAny) {
          if(rowIndex < findAny.sag_G_Index){
            number++;
            formulaStaticValue = formulaStaticValue.replace(value, `%${number}$s`);
          }
         
        }
      }
    }
  
    let replaceNumber = 0;
    for (let value of list) {
      if (this.isValidFormulaAliase(formulaStaticValue, value)) {
        let findAny = sheetHeaderList.find(ele => value === ele.headerAlias);
        if (findAny) {
          if(rowIndex < findAny.sag_G_Index){
          replaceNumber++;
          let replaceIndex = findAny.sag_G_Index + 2;
          if("delete" == opName){
            /***sag_g_index not change because grid not load ***** */
            replaceIndex = findAny.sag_G_Index 
          } 

          let replaceValue = this.headerAliasObj[replaceIndex];
          formulaStaticValue = formulaStaticValue.replace(`%${replaceNumber}$s`, replaceValue);
          }
        }
      }
    }
    return formulaStaticValue;
  }
  
   isValidFormulaAliase(formula, value) {
    let isValid = this.isAlphabet(value);
    if (isValid) {
      if (formula.includes(`'${value}'`) || formula.includes(`"${value}"'`) || value.trim() === "null") {
        return false;
      }
    }
    return isValid;
  }
  
   isAlphabet(value) {
    return /^[a-zA-Z]+$/.test(value);
  }
  
   checkHeaderAliaseUsage(){
    let selectedRowData = this.gridDynamicForApiMapping.getSeletedRowData();
    let selectedRowHeaderAlias = selectedRowData.headerAlias;

    let useAliaseList = new Map(); 
    let gridData =  this.pageConfigurationJSON['apiFieldList'];

    this.fillAliaseUsageHeader(gridData,useAliaseList);

    let aliaseUsageHeader =   useAliaseList.get(selectedRowHeaderAlias);
 
    return aliaseUsageHeader;

  }

  fillAliaseUsageHeader(gridData,useAliaseList){
    gridData.forEach(element => {
   
       if(element.details){
        this.fillAliaseUsageHeader(element.details,useAliaseList);
       } else{
        if("Formula" == element.dataFindFrom){
          let formulaStaticValue = element.formulaStaticValue;
          if(formulaStaticValue){
            let split = formulaStaticValue.split(/[^\w\s]/gi);
            let list = split.slice();
            list  = _.map(list,_.trim)
            if(list){
              list.forEach(al => {
                useAliaseList.set(al, element['name']); 
              });
           }
          }
         }
     
         if("by_manual_method_with_aliase" == element.dataFindFrom){
          let formulaStaticValue = element.formulaStaticValue;
          if(formulaStaticValue){
            const argument = formulaStaticValue.substring(formulaStaticValue.indexOf("(") + 1, formulaStaticValue.indexOf(")"));
           
            let split = argument.split(/[^\w\s]/gi);
            let list = split.slice();
            list  = _.map(list,_.trim)
            if(list){
              list.forEach(al => {
                useAliaseList.set(al, element['name']);
              });
           }
          }
         }
       }
    });

     
  }

  onClose() {
    this.modalRef.close();
    this.ngOnDestroy();
   }

   ngOnDestroy() { }




  /********************Add Api Grid****************************** */

  gridDynamicAddApiGeneration:any

   javaApiGrid(rowsData) {
    var sourceDiv = document.getElementById("addApiGenerationGridId");
    var columns:any = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": false,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Api Name",
        "field": "apiName",
        "filter": false,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      
      {
        "header": "Api Type",
        "field": "apiType",
        "filter": false,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
       
      {
        "header": "Description",
        "field": "dataFindFrom",
        "filter": false,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'label',
        "cellRenderView": false
      },
      {
        "header": "Delete",
        "field": "delete",
        "filter": false,
        "width": "100px",
        "editable": "false",
        "text-align": "left",
        "search": true,
        "component": "buttonIcon",
        "cellRenderView": true,
        "freezecol": "null",
        "hidden": false,
        "sort": false,
        "cellHover": false,
        "button": { "imgsrc": "", "iconclass": "fas fa-trash", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-danger"], "attribute": "", "styles": "" },
      },
      {
        "header": "Modify",
        "field": "modify",
        "filter": false,
        "width": "100px",
        "editable": "false",
        "text-align": "left",
        "search": true,
        "component": "buttonIcon",
        "cellRenderView": true,
        "freezecol": "null",
        "hidden": false,
        "sort": false,
        "cellHover": false,
        "button": { "imgsrc": "", "iconclass": "fas fa-edit", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-info"], "attribute": "", "styles": "" },
      },

      {
        "header": "View",
        "field": "view",
        "filter": false,
        "width": "100px",
        "editable": "false",
        "text-align": "left",
        "search": true,
        "component": "buttonIcon",
        "cellRenderView": true,
        "freezecol": "null",
        "hidden": false,
        "sort": false,
        "cellHover": false,
        "button": { "imgsrc": "", "iconclass": "fas fa-eye", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-info"], "attribute": "", "styles": "" },
      },
      
    ];
  
    let self = this;
  
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }
  
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        frezzManager: {},
        components: {},
        rowCustomHeight :20,
        cellCustomPadding:5,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,

        footer_hide: false,
        totalNoOfRecord_hide: false,
        sml_expandGrid_hide: true,
        exportXlsxPage_hide: true,
        exportXlsxAllPage_hide: true,
        exportPDFLandscape_hide: true,
        exportPDFPortrait_hide: true,
        ariaHidden_hide: true,
        disableAllSearch: true,

        callBack: {
            "onButtonIcon_delete": function (ele, params) {
                self.removeJavaApi(params)
             },
             "onButtonIcon_modify": function (ele, params) {
                self.modifyJavaApi(params.rowValue);
             },
             "onButtonIcon_view": function (ele, params) {
              self.getSorceFileByApiId(params.rowValue.apiId);
           },
        },
      };
      this.gridDynamicAddApiGeneration = SdmtGridT(sourceDiv, gridData, true, true);
      this.setApiSelectedAndModifyApi();
      return this.gridDynamicAddApiGeneration;
    }
  }
 
  setApiSelectedAndModifyApi(){
    let gridData = this.gridDynamicAddApiGeneration.getGridData();
    if(this.config.data && this.config.data.apiId && gridData){
     let apiId =  this.config.data.apiId;
     let item = _.find(gridData, { "apiId": apiId });
     if(item){
        let sag_G_Index = item.sag_G_Index;
        gridData.forEach(element => {
          if(element.sag_G_Index != sag_G_Index){
            this.gridDynamicAddApiGeneration.disableRow(element.sag_G_Index);
          }
        });

        this.gridDynamicAddApiGeneration.setRowSelected(sag_G_Index);
        this.modifyJavaApi(item);
     }

    }

  }
  
  onClickAddApi(){
    if(!this.isUserValid || !this.isGeneratedFileValid){
      this.isValidUserAndFile(true);
      //alerts("You don't have permission to create api");
      return;
    }

    this.autoJavacodeService.isPageConfigurationJsonValid(this.pageConfigurationJSON).subscribe(res => {
     if(res.isValid){
      this.openAddApiComponent(false,null);
     }else {
        this.validateApiFieldData(res.javaApiInfo); 
     }
      
    }, Error => {
      alerts("Error While validate user");
    });
  }

  modifyJavaApi(rowValue) {
   let modifyApiData = rowValue;
   let apiId = modifyApiData.apiId;

    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    if (apiId) {
      if (sessionStoragedatauserId != undefined) {
        let userId = sessionStoragedatauserId.data.clientInfo.usrId;
        this.autoJavacodeService.userValidToModifyApi(apiId, userId).subscribe(res => {
          if (res.isValid) {
         
            this.autoJavacodeService.isPageConfigurationJsonValid(this.pageConfigurationJSON).subscribe(res => {
              if (res.isValid) {
                this.openAddApiComponent(true, rowValue);
              } else {
                this.validateApiFieldData(res.javaApiInfo);
              }

            }, Error => {
              alerts("Error While validate user");
            });

           
          } else {
            alerts(res.msg)
          }
        }, Error => {
          alerts("Error While validate user");
        });
      } else {
        alerts("user not found")
      }
    } else {
      alerts("Api Id not found")
    }
  }
  async removeJavaApi(params) {

    let modifyApiData = params.rowValue;
    let apiId = modifyApiData.apiId;

    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    let setProjectInfo= this.shareService.getDataprotool("selectedProjectChooseData");

      if(!setProjectInfo){
        alerts("User Project path not configure")
        return;
      }
    if (sessionStoragedatauserId != undefined) {
      let userId = sessionStoragedatauserId.data.clientInfo.usrId;
      this.autoJavacodeService.userValidToDeleteApi(apiId, userId).subscribe(async res => {
        if (res.isValid) {

          let projectId=setProjectInfo.projectId;
          let reqObj={
             "apiId":apiId,
             "userId":userId,
             "projectId":projectId,
             "projectPath":setProjectInfo.jwspace
           }

          if (await ui.confirm('Are you sure to delete api')) {
            this.autoJavacodeService.removeJavaApi(reqObj).subscribe(res => {
              if (res.status == 200) {
                success(res.msg)
                this.getAllApiListPageFormWise();
                let pageName =  this.dbMappingform.controls['PageWindowName'].value;
                this.cheackMethodAlreadyExistInJavaController(pageName);
              }
            }, Error => {
              alerts("Error While Delete api");
            });
          }
        } else {
          alerts(res.msg)
        }
      }, Error => {
        alerts("Error While validate user");
      });
    } else {
      alerts("User not found")
    }

  }

 




  openAddApiComponent(isModify,rowValue){
    let modifyApiData = null;
    if(isModify){
      modifyApiData = rowValue;
    }

    let gridData = this.gridDynamicForApiMapping.getGridData();
    let apiFieldSimpleFormate = this._getApiFieldSimpleFormate(gridData);

    this.isBackgroundDisable = true;
    const ref = this.dialogService.open(JavaApiMappingComponent, {
      header: "Api",
      contentStyle: { "margin-top": "0px", "height": "500px" },
      width: '700px',
      data: {
        'isModify':isModify,
        'apiFieldSimpleFormate':apiFieldSimpleFormate,
        'allTableList':this.allTableList,
        'modifyApiData':modifyApiData,
        'pageConfigurationJSON':this.pageConfigurationJSON,
        'apiClassInfo':this.dbMappingform.getRawValue(),
        'controllerMethodList' : this.controllerMethodList,
        'allPageApiList':this.javaApiList,
        'oldPageConfigurationJSON':this.oldPageConfigurationJSON
      },
  
    });
    ref.onClose.subscribe((res) => {
      this.isBackgroundDisable = false;
     if(res){
      this.oldPageConfigurationJSON = JSON.parse(JSON.stringify(this.pageConfigurationJSON));
      this.getAllApiListPageFormWise();
      let pageName =  this.dbMappingform.controls['PageWindowName'].value;
      this.cheackMethodAlreadyExistInJavaController(pageName);
     }
     
    });
 }

 
 /***********************Manual Code *************************** */

openManualCodeComponent(){
  
  let sheetNameList  = this._getAllSheetName();

  const ref = this.dialogService.open(JavaApiManualCodeComponent, {
    header: "Manual Code",
    width: "100%",
    contentStyle: { "margin-top": "0px", "height": "100%" },
    styleClass: "service_full_model excel-demo-view",
    data: {
      'manualMethodList': this.pageConfigurationJSON.manualCodeList,
      "isApiWiseManualCode":false,
      "isImportManualCode": "Y" == this.pageConfigurationJSON.isJsonImport,
      "apiFieldList" : this.pageConfigurationJSON.apiFieldList,
      "sheetNameList":sheetNameList
    },
 
  });
  ref.onClose.subscribe((res) => {
   if(res){
    this.pageConfigurationJSON.manualCodeList = res;
   }
   
  });
}
  
_getAllSheetName (){
  let sheetNameList = [ ];
  sheetNameList.push({ "key": "", "val": "--Select--" }); 

  if(this.pageConfigurationJSON.documentSectionList){
    this.pageConfigurationJSON.documentSectionList.forEach(element => {

      if(element['apiFieldList']!=undefined && element['apiFieldList'].length > 0){
        let obj = {
           "key":element['sectionName'],
           "val":element['sectionName']
        }
       sheetNameList.push(obj)
      }
   
    
   });
  }


 return sheetNameList;
}


/****************File Store Config******************/

labelListForDynamicFolder = [];

fileStoreConfig = {
  "rootPath" : "_rootPath/",
  "staticPath" : "",
  "dynamicFolder":[],
  "path":"_rootPath/",
}

resetFileConfigDetails(){
  this.fileStoreConfig = {
    "rootPath" : "_rootPath/",
    "staticPath" : "",
    "dynamicFolder":[],
    "path":"_rootPath/",
  }

}

openFileStoreConfigurationModel(params){
  this.setLabelListForDynamicFolder();
  let rowValue = params.rowValue;

  if(rowValue.fileStoreConfig){
    this.fileStoreConfig = rowValue.fileStoreConfig;
  } else {
    this.resetFileConfigDetails();
  }


  $('#fileStoreConfigurationModel').modal('show');
 }

 setLabelListForDynamicFolder(){
  this.labelListForDynamicFolder = [];
  let gridData = this.gridDynamicForApiMapping.getGridData();
  let apiFieldSimpleFormate = this._getApiFieldSimpleFormate(gridData);

  apiFieldSimpleFormate.forEach(element => {
    if ("file" != element.dataFindFrom) {
      let obj = {
        "labelName": element.labelName,
        "modelFieldName": element.modelFieldName,
        "headerAlias": element.headerAlias,
      };
      this.labelListForDynamicFolder.push(obj);
    }
  });

 }
 
 closeFileStoreConfigurationModel(){
   $('#fileStoreConfigurationModel').modal('hide');
 }

 okFileStoreConfigurationModel(){
  let selectedRowData = this.gridDynamicForApiMapping.getSeletedRowData();
  if(selectedRowData){
    this.gridDynamicForApiMapping.updateCell(selectedRowData.sag_G_Index, "fileStoreConfig",this.fileStoreConfig);
  }
  
  this.closeFileStoreConfigurationModel();
 }

 createFileStorePath(){
  let rootPath  = this.fileStoreConfig.rootPath;
  let staticPath  = this.fileStoreConfig.staticPath;
  let dynamicFolder  = this.fileStoreConfig.dynamicFolder;
  let dyanmicPath = "";

  if(dynamicFolder){
    dynamicFolder.forEach(element => {
      dyanmicPath = dyanmicPath+"${"+element.modelFieldName+"}/"
    });

  }

  if(staticPath && !staticPath.endsWith("/")){
    staticPath  = staticPath+"/";
  }

  let path = rootPath+""+staticPath + dyanmicPath;

  this.fileStoreConfig.path = path;
 }


/********************* Context Menu ***************************************** */
 
 

 

copyRow(ele,param){
  let rowValue = param.rowValue;
  this.copyPastEllipsisValue = JSON.parse(JSON.stringify(rowValue)); 
}

 

pasteRowApiFieldMapping(index){
 let data = this.copyPastEllipsisValue;
  if(data){
    let apiFieldList = this.pageConfigurationJSON['apiFieldList'];
    this.isRecursionOff = false;
    this.addRecursionRowForElipsis(apiFieldList,index,data);
    this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
    this.gridDynamicForApiMapping.expandAll();
  }
}
 
addRowEllipsis(index){
  let apiFieldList = this.pageConfigurationJSON['apiFieldList'];
  this.isRecursionOff = false;
  this.addRecursionRowForElipsis(apiFieldList,index,this.getEmptyObjForAddRow());

  this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);

  this.gridDynamicForApiMapping.expandAll();
}

addExtraMasterField(rowIndex){
  this.openAddMasterExtraColumnModal();
  let selectedRowData = this.gridDynamicForApiMapping.getSeletedRowData();

  let childMasterExtraFields = selectedRowData.childMasterExtraFields;
  if(childMasterExtraFields){
    this.addMasterExtraColumnGrid(childMasterExtraFields);
    setTimeout(() => {
      this.bindApiFieldDataForMasterExtraFields();
    }, 500);
    
  }else{
    this.addMasterExtraColumnGrid([]);
  }
}
 
  
addChildRowSheetMapping(index){
 
  let apiFieldList = this.pageConfigurationJSON['apiFieldList'];
  this.isRecursionOff = false;
  this.addRecursionRowForChildren(apiFieldList,index);
 
  this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
  this.gridDynamicForApiMapping.expandAll();

}

/**********************************JSON Import******************************************************************* */

importDataInsertType = [
  { "value": "import_only_non_existing_record", "label": "Import only non existing record" },
  { "value": "overwrite_the_exiting_record", "label": "Overwrite the exiting record" },
  { "value": "delete_all_exiting_record_then_import_all_record", "label": "Delete all exiting record then import all record"},
 ];

isJsonImportFlag:boolean  = false;
isImportUiCreateFlag:boolean = true;
excelMasterDropdownForSheetMapping = [];

onChangeJSONImport(isJsonImport){
  
  let pageWindowName = this.dbMappingform.controls["PageWindowName"].value

  if ("Y" == isJsonImport) {
    this.isJsonImportFlag = true;
    pageWindowName = pageWindowName+"Json";
    this.pageConfigurationJSON['dataFindFrom'] = [];
  } else {
    this.isJsonImportFlag = false;
    if(pageWindowName.includes("Json")){
      pageWindowName = pageWindowName.replaceAll("Json",""); 
    }
  }
  this.dbMappingform.controls["PageWindowName"].setValue(pageWindowName);
  this.onPageChange(pageWindowName,false,null);


}

onChangeImportUiCreate(isImportUiCreate){

  if ("Y" == isImportUiCreate) {
    this.isImportUiCreateFlag = true;
  } else {
    this.isImportUiCreateFlag = false;
  }
}

onChangeJSONType(type){
  //this.jsonMappingGrid(this.jsonSchema['details'],type);
 // this.gridDynamicForJsonMapping.expandAll();
}

/******OLD JSON COPY Code********* */
classLevelApiName="gstr1json"

excelImportExportView(){
  this.classLevelApiName = this.dbMappingform.controls["classLevelApiName"].value;
  const url = this._router.createUrlTree(['../form-json-import-view',{"api-name":this.classLevelApiName}])
  window.open(url.toString(), '_blank')

}

generateJavaCodeForImportJson(){
  if(!this.isUserValid){
    alerts("You don't have permission to create api");
    return;
  }

  this.autoJavacodeService.isPageConfigurationJsonValid(this.pageConfigurationJSON).subscribe(res => {
    if(res.isValid){
      this.generateJavaApiForJson();
    }else {
       this.validateApiFieldData(res.javaApiInfo); 
    }
     
   }, Error => {
     alerts("Error While validate user");
   });

}

generateJavaApiForJson() {
  this.jsonGeneratedFileList = [];
  this.classLevelApiName = this.dbMappingform.controls["classLevelApiName"].value;
  let apiMppingInfo = this.dbMappingform.getRawValue();
    
  this.pageConfigurationJSON['documentSectionList'] = this.documentSectionList;

 apiMppingInfo['pageConfigurationJSON'] = this.pageConfigurationJSON;
 
  let srcDataSource = null;
  let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
  if(dataForConnection && dataForConnection.srcDataSource){
    srcDataSource = dataForConnection.srcDataSource;
  }

  let reqObj = {
    apiCategory: 'form_json_import', 
    newApiInfoObj: apiMppingInfo,
    apiId: null,
    apijsonId: null,
    oldApiInfoObj: null,
    databaseConfig:srcDataSource
  }

 this.autoJavacodeService.generateJavaNewCode(reqObj).subscribe(res => {
   if (res.status == 200) {
     success(res["msg"]);

     let apiInfo = res.generatedJavaApiInfo
     this.jsonGeneratedFileList = res['generatedFileList'];
     let apiObj = {
       uniqId: `${new Date().getTime()}${1}`,
       baseUrl: 'apiConstant.projectBaseUrl',
       failedMsg: 'error',
       run: false,
       expand: false,
       numberOfReq: 1,
       excutionTime: 0,
       argument: '',
       methodName: '',
       apiType: `${apiInfo.apiType}`,
       request: '',
       response: '',
       successMsg: 'scccessfull fetch',
       url: `${apiInfo.apiName}`,
       fullUrl: '',
       apiList: [],
       expectedReq: ``,
       expectedRes: ``,
       desc: '',
       apiResType: null,
       errorCode: "",
       msg: "",
       apiId:apiInfo.apiId  
     };
   }else if (res.status == 400) {
    alerts(res.msg);
     
  } else {
    alerts(res.msg);
  }
 }, Error => {
   alerts("Error While Generating");
 })

}


/*******JSON DISPLAY CONFIG******/
gridDynamicForDisplayConfiguration:any;

onClickDisplayConfiguration(){
  this.openDisplayConfigurationModal();
  this.setCaptionName(this.pageConfigurationJSON.apiFieldList);
  this.displayConfigurationGrid(this.pageConfigurationJSON.apiFieldList); 
}

setCaptionName(gridData){
  gridData.forEach(rowData => {
    if(rowData.details){
      this.setColorPropertiesForDisplayConfig(rowData.details)
    } 
    if(!rowData.caption){
      rowData.caption = rowData.labelName;
    }

  });
  

}

displayConfigurationGrid(rowsData) {
  var sourceDiv = document.getElementById("displayConfigurationGridId");
  var columns = [
    {
      "header": "S.No",
      "field": "sno",
      "filter": false,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
    {
      "header": "Name",
      "field": "labelName",
      "filter": false,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": false
    },
    {
      "header": "Caption",
      "field": "caption",
      "filter": false,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    },
    {
      "header": "Show Column",
      "field": "isDisplayColumn",
      "filter": false,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": 'checkbox',
      "cellRenderView": true
    },
    {
      "header": "Modify Column",
      "field": "isModifyColumn",
      "filter": false,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": 'checkbox',
      "cellRenderView": true,
    },
    {
      "header": "Text Align",
      "field": "textAlign",
      "filter": false,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Sequence",
      "field": "columnSequence",
      "filter": false,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": 'select',
      "cellRenderView": false
    },
    {
      "header": "Decimal Format",
      "field": "decimalFormat",
      "filter": false,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": 'multiSelect',
      "cellRenderView": true
    },
    {
      "header": "Decimal Digit",
      "field": "decimalDigit",
      "filter": false,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    },
  ];
  let self = this;
  
  let components = {};
  let numberFormate = [
    { "key": "decimal_format", "val": "Decimal Format" },
    { "key": "round_number", "val": "Round Number" },
   
    
   ];
 
  let textAlignList = [
    { "key": "", "val": "--Select--" },
    { "key": "left", "val": "LEFT" },
    { "key": "right", "val": "RIGHT" },
    { "key": "center", "val": "CENTER" },
   ];
   let sequenceList = [
    { "key": "", "val": "--Select--" }
   ]
   for (i = 1; i <= 100; i++) {
    let obj = { "key": i+"", "val":i+"" }
    sequenceList.push(obj);
  }

  var SagGridRowStatus = rowsData;
  for (var i = 0; i < SagGridRowStatus.length; i++) {
    SagGridRowStatus[i]["sno"] = i + 1;
  }
 
  
  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      frezzManager: { "sno": "left", "name": "left","description":"left"},
      rowCustomHeight :20,
      cellCustomPadding:5,
      components: components,
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
      callBack: {},

      dropDownJson_textAlign: textAlignList,
      dropDownJson_columnSequence: sequenceList,
      multidropDownJson_decimalFormat: numberFormate,

      rowGrouping: {
        "enable": true,
        "groupType": "custome",
        "groupBy": "name",
        "expandRow": []
      },
      rowSelection: false,
      rowDataViewTotal: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      
    };
    this.gridDynamicForDisplayConfiguration = SdmtGridT(sourceDiv, gridData, true, true);
   
    this.setColorPropertiesForDisplayConfig(this.gridDynamicForDisplayConfiguration.getGridData());
    this.gridDynamicForDisplayConfiguration.expandAll();
    return this.gridDynamicForDisplayConfiguration;
  }
  }

  setColorPropertiesForDisplayConfig(gridData){
 
    gridData.forEach(rowData => {
      if(rowData.details){
        let colorProperty = {"background-color":"rgb(195 195 195)"}
        this.gridDynamicForDisplayConfiguration.disableRow( rowData.sag_G_Index);
        this.gridDynamicForDisplayConfiguration.setRowProperty(rowData.sag_G_Index,colorProperty);
        this.setColorPropertiesForDisplayConfig(rowData.details)
      }
    });
  }

  okDisplayConfigurationModal(){
    this.closeDisplayConfigurationModal();
   }

openDisplayConfigurationModal(){
  $('#displayConfigurationModal').modal('show')
 }

 closeDisplayConfigurationModal(){
   $('#displayConfigurationModal').modal('hide')
 }

 /***************************Master Mapping ************************************** */


 @ViewChild("editMasterTabName", { static: false }) editMasterTabName: ElementRef;
 displayContextMenuForMaster(event,item){
   if(this.excelMasterInfo['name'] != item.name){
     this.onClickMasterHeader(item, 1);
   }
   let self = this;
   event.preventDefault();
   new Contextual({
     isSticky: false,
     items: [
       new ContextualItem({ cssIcon:"fa fa-edit", label: 'Rename', onClick: () => { self.renameMasterName() } }),
       new ContextualItem({ cssIcon:"fa fa-plus", label: 'Add Master', onClick: () => { self.addMasterName() } }),
       new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete Master', onClick: () => { self.deleteMasterName() } }),
     ]
   });
 
 }

 renameMasterName(){
  this.excelMasterInfo['isRename'] = true;
}


 excelMasterInfo: { "tableName": "", "nameTableColumn": "", "codeTableColumn": "", "masterList":any,"masterMappingType":"map_with_table_data","isMasterManualCreate":false}
    gridDynamicForMasterMapping

    tableNameDropdownForMasterMapping = [];
    tableColumnDropdownForMasterMapping = [];
    tableFieldsMapForMasterMapping = new Map();
    tableDataListForMasterMapping = [];
    tableDataMapMasterMapping = new Map();
    tableDataDropdownMasterMapping = [{ "key": "", "val": "--Select--" }] ;

 getMasterMapping(isOpenModal){
  
  if(!this.pageConfigurationJSON.jsonMasterMapping){
    this.pageConfigurationJSON.jsonMasterMapping = [];
  }

  if(isOpenModal){
    this.getTableDropdownForMasterMapping();
  }

   
  if(isOpenModal){
    this.openMasterMappingModal();
  
    let item = _.find(this.pageConfigurationJSON.jsonMasterMapping, { active: true });
    if (item) {
      setTimeout(() => {
        this.onClickMasterHeader(item, 1);
      }, 100);
    }
  }
 
 }

 openMasterMappingModal(){
  $('#masterMappingModal').modal('show')
 }

 closeMasterMappingModal(){
   $('#masterMappingModal').modal('hide')
 }


 onClickMasterHeader(item: any, index) {
  this.excelMasterInfo = item;
  this.pageConfigurationJSON.jsonMasterMapping.forEach(itm => itm.active = false);
  this.pageConfigurationJSON.jsonMasterMapping.forEach(itm => itm.isRename = false);

  item['active'] = true;
  this.tableColumnDropdownForMasterMapping = [];
  this.tableDataDropdownMasterMapping      = [{ "key": "", "val": "--Select--" }];

  this.bindMasterMappingData();

}


bindMasterMappingData(){
  let tableName = this.excelMasterInfo["tableName"];
  let nameTableColumn = this.excelMasterInfo["nameTableColumn"];

  if(tableName == undefined || tableName == ""){
    if(this.excelMasterInfo['masterList']){
      this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
    }else{
      this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
    }
    return;
  }
  
  let tableFieldsInfo =  this.tableFieldsMapForMasterMapping.get(tableName);
  if(tableFieldsInfo!=undefined && tableFieldsInfo!=null && tableFieldsInfo.length > 0 ){
    this.getTableColumnDropdownForMasterMapping(tableFieldsInfo,tableName,true);
    if(nameTableColumn){
      let tableData =  this.tableDataMapMasterMapping.get(tableName);
      if(tableData){
        this.getTableDataDropdownForMasterMapping(tableData,nameTableColumn,true);
      }else{
        this.getTableDataForMasterMapping(tableName,true); 
      }
     
    }else{
      if(this.excelMasterInfo['masterList']){
       this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
       
      }else{
        this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
      }
    }
    

  }else{
    if(nameTableColumn){
      this.onChangeTableNameDropdownForMasterMapping(tableName,true);
    }else{
      if(this.excelMasterInfo['masterList']){
      
        this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
      }else{
        this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
      }
      this.onChangeTableNameDropdownForMasterMapping(tableName,false);
    }
    
  }
  if(this.excelMasterInfo["isFilterData"]){
    if(this.excelMasterInfo['query']){
      if(this.excelMasterInfo['query']){
        if(this.excelMasterInfo['query']['sql']){
          this.executeQuery(this.excelMasterInfo['query']['sql'],true);     
        }
       }
     }
  }

  this.gridDynamicForMasterMapping.expandAll();
}

onChangeTableNameDropdownForMasterMapping(tableName,isGridLoad){
  if (tableName) {
    this.getTableDataForMasterMapping(tableName,isGridLoad);
    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
      "dbtype": "master",
      "tableName": tableName
    }
    this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
      if (res) {
      
        this.getTableColumnDropdownForMasterMapping(res,tableName,false);
        
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }
 }

 getTableColumnDropdownForMasterMapping(res,tableName,isFetchFromCache){
  this.tableColumnDropdownForMasterMapping = [];;
 
  let tableFieldsInfo = [];

  if (isFetchFromCache) {
    tableFieldsInfo = res;
  } else {
    tableFieldsInfo = this.getTableInfoWithCustomKeys(res, tableName);
  }
 
  this.tableFieldsMapForMasterMapping.set(tableName, tableFieldsInfo);

  let pkObj = _.find(tableFieldsInfo, { "pkey": "Y" });
    if(pkObj){
        this.excelMasterInfo["primaryKeyEntityColumn"] = pkObj.entityColumn;
        this.excelMasterInfo["primaryKeyTableColumn"] = pkObj.columnName,
        this.excelMasterInfo["entityName"] = pkObj["entityName"];
  }

  tableFieldsInfo.forEach(tableColumn => {
    let obj = {
      "label": tableColumn['columnName'],
      "value": tableColumn['columnName']
    }
    
    this.tableColumnDropdownForMasterMapping.push(obj);
  });
 }
  
getTableDataForMasterMapping(tableName,isGridLoad){
if (tableName) {

  let dbData = {
    "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
    "targetDataSource": {},
    "operation": "COMPARESINGLE",
    "connectionRoleType": "admin",
    "dbtype": "master",
    "tableName": tableName,
    "details": {
      "columns": [],
      "software": [],
      "year": [],
      "client": [],
      "operation": "",
      "limitRows": "null"
  },
  }
  this._dbcomparetoolService.getAllTabTableData(dbData).subscribe((res) => {
    if (res) {
   
      this.tableDataMapMasterMapping.set(tableName,res);
      if(isGridLoad){
        this.getTableDataDropdownForMasterMapping(res,this.excelMasterInfo['nameTableColumn'],isGridLoad);
      }
     
    }
  }, Error => {
    alerts("Error While Fetching data");
  });
}
}


getTableDataDropdownForMasterMapping(res,nameTableColumn,isGridLoad){
this.tableDataDropdownMasterMapping = [{ "key": "", "val": "--Select--" }];
if(res.gridarray){
  if(nameTableColumn){
    res.gridarray.forEach(ele => {
      let obj = {
        "key": ele[nameTableColumn],
        "val": ele[nameTableColumn]
      }
      this.tableDataDropdownMasterMapping.push(obj);
    });
  }
}

if(!isGridLoad){
  if(this.gridDynamicForMasterMapping.sagGridObj.components['tableMasterName']){
  this.gridDynamicForMasterMapping.sagGridObj.components['tableMasterName'].setOption(this.tableDataDropdownMasterMapping);
}
}else{
  if(this.excelMasterInfo['masterList']){
   
    this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);
  }else{
    this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']);
  }
  this.gridDynamicForMasterMapping.expandAll();
}

}




 getTableDropdownForMasterMapping(){
  this.tableNameDropdownForMasterMapping = [];
  this.allTableList.forEach(table => {
    let obj = {
      "label": table,
      "value": table
    }
    this.tableNameDropdownForMasterMapping.push(obj);
  });
 }

 onChangeNameColumnDropdownForMasterMapping(nameColumn){

  let tableName =  this.excelMasterInfo['tableName'];
  if(tableName && nameColumn){
   let data =  this.tableDataMapMasterMapping.get(tableName);
   let tableFieldsInfo = this.tableFieldsMapForMasterMapping.get(tableName)
   if(tableFieldsInfo){
 
    let columnObj = _.find(tableFieldsInfo, { "columnName": nameColumn });
    if(columnObj){
     this.excelMasterInfo["nameEntityColumn"] = columnObj.entityColumn;
    }
   }
    this.getTableDataDropdownForMasterMapping(data,nameColumn,false);

    this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']);

    this.gridDynamicForMasterMapping.expandAll();
  }
}



checkDuplicateMasterMapping(){
  let isDuplicate:boolean = false;
  this.pageConfigurationJSON.jsonMasterMapping.forEach(element => {
    let sheetName = element["name"];
    let masterList = element['masterList'];
  
    if(isDuplicate){
        return;
      }
      if(masterList){
        let groupBy = _.chain(masterList).groupBy('tableMasterName').map((value, key) => ({ key,  value }))
        .value();
        groupBy.forEach(group => {
          if(group['key'] && group['value']){
            if(group['value'] && group['value'].length > 1){
              
              alerts(sheetName+ " have duplicate table master entry" );
              isDuplicate = true;
              return;
           };
          }
        });
      }
  
  });
  return isDuplicate;
}


filterMasterMappingData(){
this.getMasterTableDataWithParentTable(this.excelMasterInfo['tableName'],false)
}

resetFilter(){
this.excelMasterInfo['isFilterData'] = true;
this.excelMasterInfo['query'] = null;
this.bindMasterMappingData();
}

getMasterTableDataWithParentTable(tableName,isGridLoad){
if (tableName) {
  this.openFilterMasterMappingModal();
  let dbData = {
    "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
    "targetDataSource": {},
    "operation": "COMPARESINGLE",
    "connectionRoleType": "admin",
    "dbtype": "master",
    "tableName": tableName,
    "details": {
      "columns": [],
      "software": [],
      "year": [],
      "client": [],
      "operation": "",
      "limitRows": "null"
  },
  }
  this._dbcomparetoolService.getEnityHqlData(dbData).subscribe((res) => {
    if (res) {
      let arr = [];
      this.createMastersFilterData(arr,res);
      this.sagFilterMasterMappinGrid(arr);
     
    }
  }, Error => {
    alerts("Error While Fetching data");
  });
}
}


gridDynamicFilterMasterMappingGrid:any;
sagFilterMasterMappinGrid(rowsData) {
var sourceDiv = document.getElementById("filterMasterMappingGridId");
let columns : any =  [
  {
    "field": "checkBox",
    "filter": false,
    "editable": false,
    "sagGridResize": false,
    "width": "50px",
    "header": "All",
    "text-align": "center",
    "colType": "checkBox"
  },
 
  {
    "header": "S.No",
    "field": "sno",
    "filter": false,
    "width": "50px",
    "editable": "false",
    "textalign": "center",
    "search": true,
  },

  {
    "header": "Table Column",
    "field": "tablecolumn",
    "filter": false,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
  },
  {
    "header": "Value",
    "field": "tableValue",
    "filter": false,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": "tableValueComponent",
  },
 


];

 let self = this;
 let components = { 
   "tableValueComponent": new SagInputText({}, function () {
})
};
var SagGridRowStatus = rowsData;
if (undefined != sourceDiv) {
  var gridData = {
    columnDef: columns,
    rowDef: SagGridRowStatus,
    menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
    selection: "row",
    rowCustomHeight :20,
    cellCustomPadding:5,
    components: components,
    clientSidePagging: true,
    recordPerPage: 20,
    recordNo: true,
    callBack: {
      
    },
    rowGrouping: {
      "enable": true,
      "groupType": "custome",
      "groupBy": "tablecolumn",
      "expandRow": []
    },
    rowSelection: false,
    rowDataViewTotal: true,
    sml_expandGrid_hide: true,
    exportXlsxPage_hide: true,
    exportXlsxAllPage_hide: true,
    exportPDFLandscape_hide: true,
    exportPDFPortrait_hide: true,
    ariaHidden_hide: true,
  };
  this.gridDynamicFilterMasterMappingGrid = SagGridMPT(sourceDiv, gridData, true, true);
  
  return this.gridDynamicFilterMasterMappingGrid;

}

}

createMastersFilterData(arr,res){
let columns =res['columns'];
let jointable = res['jointable'];
let foreignkeycolumns =res['foreignkeycolumns'];
columns.forEach(column => {
  column['tablename'] = res['tablename'];
  column['entitytable'] = res['entitytable'];
  column['primarykey'] = res['primarykey'];
  let foreignObj =  _.find(foreignkeycolumns ,{"fkeycol":column.tablecolumn});

  if(foreignObj){
   let referencedtable = foreignObj['referencedtable'];
    let parentJoinTable =  _.find(jointable ,{"tablename":referencedtable});
    let obj = column;
    obj['details'] = []; 
    this.createMastersFilterDataRec(obj['details'],parentJoinTable)
    arr.push(obj); 
  }else {
    arr.push(column);
  }
 });
  
}

createMastersFilterDataRec(arr,res){
let columns =res['columns'];
let jointable = res['jointable'];
let foreignkeycolumns =res['foreignkeycolumns'];
columns.forEach(column => {
  column['tablename'] = res['tablename'];
  column['entitytable'] = res['entitytable'];
  column['primarykey'] = res['primarykey'];

  let foreignObj =  _.find(foreignkeycolumns ,{"fkeycol":column.tablecolumn});

  if(foreignObj){
   let referencedtable = foreignObj['referencedtable'];
    let parentJoinTable =  _.find(jointable ,{"tablename":referencedtable});
    let obj = column;
    obj['details'] = []; 
    this.createMastersFilterDataRec(obj['details'],parentJoinTable)
    arr.push(obj); 
  }else {
    arr.push(column);
  }
 });
  
}



onClickFilterMasterDataOk(){
let gridData  = this.gridDynamicFilterMasterMappingGrid.getGridData();
let sqlWhere = [];
let hqlWhere = [];

let join = new Set();
let hqljoin = new Set();

let sqlSelect = this.createSqlSelect();
let hqlSelect = this.createHqlSelect();

gridData.forEach(row => {
  if(row.details){
    this.createSql(join,sqlWhere,row);
    this.createHql(hqljoin,hqlWhere,row);
  }
});

let sqlWhereStr =  _.join(sqlWhere, [' and ']);
let hqlWhereStr =  _.join(hqlWhere, [' and ']);

join.forEach(value => {
sqlSelect = sqlSelect.concat(value+"");
});

hqljoin.forEach(value => {
hqlSelect = hqlSelect.concat(value+"");
});

sqlSelect = sqlSelect.concat(" where "+sqlWhereStr);
hqlSelect = hqlSelect.concat(" where "+hqlWhereStr);

if(!this.excelMasterInfo['query']){
this.excelMasterInfo['query'] = {}
}
this.excelMasterInfo['isFilterData'] = true;
this.excelMasterInfo['query'] = {
"hql":hqlSelect,
"sql":sqlSelect,
}

this.executeQuery(sqlSelect,true);



}

executeQuery(query,isGridLoad){
if (query) {
 
  let dbData = {
    "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
    "targetDataSource": {},
    "operation": "COMPARESINGLE",
    "connectionRoleType": "admin",
    "dbtype": "master",
    "details": {
      "sql": query,
      "queryType":"select"
  },
  }
  this._dbcomparetoolService.getexecuteSql(dbData).subscribe((res) => {
    if (res) {
      this.closeFilterMasterMappingModal();
      //this.tableDataMapMasterMapping.set(this.excelMasterInfo.tableName,res);
      this.getTableDataDropdownForMasterMapping(res,this.excelMasterInfo['nameTableColumn'],isGridLoad);
    }
  }, Error => {
    alerts("Error While Fetching data");
  });
}
}

createSqlSelect () {
let tableName = this.excelMasterInfo.tableName;
let nameTableColumn = this.excelMasterInfo.nameTableColumn;
let codeTableColumn = this.excelMasterInfo.codeTableColumn;
let primaryKeyTableColumn = this.excelMasterInfo["primaryKeyTableColumn"] ;

let sqlSelect = "select " ;
sqlSelect = sqlSelect + (tableName+"."+ primaryKeyTableColumn);
sqlSelect = sqlSelect + (","+tableName+"."+ nameTableColumn);
if(codeTableColumn!=""){
  sqlSelect = sqlSelect + (","+tableName+"."+ codeTableColumn);
}
sqlSelect = sqlSelect +(" from "+tableName);

return sqlSelect;
}

createHqlSelect () {
let entityName = this.excelMasterInfo['entityName'];
let nameEntityColumn = this.excelMasterInfo['nameEntityColumn'];
let primaryKeyEntityColumn = this.excelMasterInfo["primaryKeyEntityColumn"];
let aliase =  this._getAliase(entityName);
let sqlSelect = "select new map (" ;
sqlSelect = sqlSelect + (aliase+"."+primaryKeyEntityColumn +" as id ");
sqlSelect = sqlSelect + (","+ aliase+"."+nameEntityColumn + " as label");

sqlSelect = sqlSelect +(" ) from "+entityName +" as " +aliase);

return sqlSelect;
}

_getAliase(entityName:string){
 if(entityName){
  return entityName.substring(0, 1).toLowerCase()+entityName.substring(1); 
 }
return entityName;
}

isAnyFieldSelected;
createSql(join,sql,row){
 this.isAnyFieldSelected = false;
 this.getAnyFiledSelected(row.details);
if(this.isAnyFieldSelected){
  let firstRow = row.details[0];
  join.add(" inner join "+firstRow.tablename + " on " +row.tablename+"."+row.tablecolumn +" = " +firstRow.tablename +"."+firstRow.primarykey+" "); 
}
row.details.forEach(element => {
  if(element.checkBox){
    sql.push(" "+element.tablename+"."+element.tablecolumn+" ='"+element.tableValue+"' ");
  }
  if(element.details){
    this.createSql(join,sql,element);
  }
});

}

createHql(join,hql,row){
this.isAnyFieldSelected = false;
this.getAnyFiledSelected(row.details);
if(this.isAnyFieldSelected){
let firstRow = row.details[0];
let aliase =  this._getAliase(firstRow.entitytable); 
let aliase1 =  this._getAliase(row.entitytable);
 
let joinStr = " inner join "+firstRow.entitytable + " "+aliase+ " on " +aliase1+"."+row.entitylabel +" = " +aliase +"."+firstRow.entitylabel+" ";
// let joinStr =  " inner join "+aliase1+"."+row.entitylabel + " as " +aliase;
join.add(joinStr);



}
row.details.forEach(element => {
 if(element.checkBox){
  let aliase =  this._getAliase(element.entitytable);
  hql.push(" "+aliase+"."+element.entitylabel+" ='"+element.tableValue+"' ");
 }
 if(element.details){
   this.createHql(join,hql,element);
 }
});

}


getAnyFiledSelected (parentTableList){
 if(this.isAnyFieldSelected){
   return;
 }
let data = _.find(parentTableList,{checkBox:true})
if(data){
  this.isAnyFieldSelected = true;
}

if(!this.isAnyFieldSelected){
  parentTableList.forEach(element => {
    if(element.details){
      this.getAnyFiledSelected(element.details);
    }
  });
}

}

notMatchExcelMasterList = [];
notMatchTableMasterList = [];

onClickCheckMismatchMaster(){
this.notMatchTableMasterList = [];
let masterList = this.excelMasterInfo.masterList;
let gridData =  this.gridDynamicForMasterMapping.getGridData();
let tableDataDropdownMasterMapping = this.tableDataDropdownMasterMapping;

this.notMatchExcelMasterList =  masterList.filter(x => (!x['tableMasterName']));

let tableDataList = tableDataDropdownMasterMapping.filter(x => (x['key'])).map(ele => ele['key']);

tableDataList.forEach(field => {
  if(!_.find(gridData, { tableMasterName: field })){
    this.notMatchTableMasterList.push(field);
  }
});

this.openCheckMismatchMasterModalId();
}


addExcelMaster(){
  let obj = {
        "excelMaster":"",
        "tableMasterName": "",
        "tableMasterCode": "",
   }
   let sheetName = this.excelMasterInfo['name']
   if(sheetName){
   this.excelMasterInfo['masterList'].push(obj);
   this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']); 
   this.gridDynamicForMasterMapping.expandAll();
   }   
}

deleteExcelMaster(){
let sheetName = this.excelMasterInfo['name']
if(sheetName){
  let selectedRowData = this.gridDynamicForMasterMapping.getSeletedRowData();
  this.excelMasterInfo['masterList'].splice(selectedRowData.sag_G_Index, 1);
  this.gridDynamicForMasterMapping.deleteRow(selectedRowData.sag_G_Index);
          if (this.gridDynamicForMasterMapping.sagGridObj
            && this.gridDynamicForMasterMapping.sagGridObj.AllRowIndex.length == 0) {
              this.masterMappingGrid([],this.excelMasterInfo['masterMappingType']); 
          }
}

}

openCheckMismatchMasterModalId() {
$('#checkMismatchMasterModalId').modal('show')
}

closeCheckMismatchMasterModalId() {
$('#checkMismatchMasterModalId').modal('hide')
}

openFilterMasterMappingModal(){
$('#filterMasterMappingId').modal('show')
}

closeFilterMasterMappingModal(){
 $('#filterMasterMappingId').modal('hide')
}

onChangeMasterMappingType(masterMappingType){
if("map_with_table_data"!= masterMappingType){
  this.excelMasterInfo['tableName'] ="";
  this.excelMasterInfo['nameTableColumn'] ="";
  this.excelMasterInfo['codeTableColumn'] ="";
  this.excelMasterInfo['mappingType'] ="EXCEL_WISE";
  this.excelMasterInfo['sheetName'] ="";
 }
this.masterMappingGrid(this.excelMasterInfo['masterList'],masterMappingType);
this.gridDynamicForMasterMapping.expandAll();
}


 masterMappingGrid(rowsData,masterMappingType) {
  var sourceDiv = document.getElementById("masterMappingGridId");
  var columns = [
    {
      "header": "S.No",
      "field": "sno",
      "filter": false,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
    {
      "header": "Add Case",
      "field": "addCase",
      "filter": false,
      "width": "50px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "dynamicComponent",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "imgsrc": "", "iconclass": "fas fa-plus", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-info"], "attribute": "", "styles": "" },

    },  
    {
      "header": "JSON Master Data",
      "field": "excelMaster",
      "filter": false,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'text',
      "cellRenderView": false
    },
    

  ];
  let constantValue = {
    "header": "Table Value",
    "field": "tableMasterName",
    "filter": false,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  };
  let constantDisplayValue = {
    "header": "Display Value",
    "field": "tableMasterCode",
    "filter": false,
    "width": "450px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'text',
    "cellRenderView": false
  };
  let tableMasterName = {
    "header": "Table Data Name",
    "field": "tableMasterName",
    "filter": false,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'select',
    "cellRenderView": false
  };
  
  let tableMasterCode = {
    "header": "Display Value",
    "field": "tableMasterCode",
    "filter": false,
    "width": "200px",
    "editable": "false",
    "textalign": "center",
    "search": true,
    "component": 'label',
    "cellRenderView": true
  };

  if("map_with_constant_value" == masterMappingType){
    columns.push(constantValue);
    columns.push(constantDisplayValue);
  }else{
    columns.push(tableMasterName);
    columns.push(tableMasterCode);
  }

  let self = this;

  let components = {};

  var SagGridRowStatus = rowsData;
  for (var i = 0; i < SagGridRowStatus.length; i++) {
    SagGridRowStatus[i]["sno"] = i + 1;
     
    if(SagGridRowStatus[i].details){
     
      for (var j = 0; j < SagGridRowStatus[i].details.length; j++) {
        SagGridRowStatus[i].details[j]['dynamicCompName_addCase'] = 'label';
      }

      SagGridRowStatus[i]['dynamicCompName_addCase'] = 'buttonIcon';
     }else{
      SagGridRowStatus[i]['dynamicCompName_addCase'] = 'buttonIcon';
       
     }

   
  }

  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      rowCustomHeight :20,
      cellCustomPadding:5,
      components: components,
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
      callBack: {
        "onChangeSelect_tableMasterName": function (ele, params) {
          self.onChangetableMasterNameInGrid(ele.value, params.rowIndex)
        },
        "onButtonIcon_addCase": function (ele, params) {
          self.addCaseInMaster(params);

        },
      },
      dropDownJson_tableMasterName: this.tableDataDropdownMasterMapping,
      rowGrouping: {
        "enable": true,
        "groupType": "custome",
        "groupBy": "excelMaster",
        "expandRow": []
      },
      rowSelection: false,
      rowDataViewTotal: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
    };
    this.gridDynamicForMasterMapping = SdmtGridT(sourceDiv, gridData, true, true);

    this.disableExtraMasterValue();

    return this.gridDynamicForMasterMapping;
  }
}

disableExtraMasterValue() {
  let sagGridData = this.gridDynamicForMasterMapping.getGridData();

  if (sagGridData) {

    sagGridData.forEach(element => {
      if (element.details) {
        element.details.forEach(childEle => {
          this.gridDynamicForMasterMapping.disableCell(childEle.sag_G_Index, "addCase");
          this.gridDynamicForMasterMapping.disableCell(childEle.sag_G_Index, "tableMasterName");
          this.gridDynamicForMasterMapping.disableCell(childEle.sag_G_Index, "tableMasterCode");
        });
      }
    });
  }

}


addCaseInMaster(params){
     
  let sagGridData = this.gridDynamicForMasterMapping.getGridData();

  let rowIndex = 0;

  for (let index = 0; index < sagGridData.length; index++) {
    if (params.rowIndex == sagGridData[index].sag_G_Index) {
      rowIndex = index;
    }
  }

  let obj = {
        "excelMaster":"",
        "tableMasterName": params.rowValue.tableMasterName,
        "tableMasterCode": params.rowValue.tableMasterCode,
   }
  
   
   if(!this.excelMasterInfo['masterList'][rowIndex]['details']){
     this.excelMasterInfo['masterList'][rowIndex]['details'] = [];
   }
   this.excelMasterInfo['masterList'][rowIndex]['details'].push(obj);
   this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']); 
      
   this.gridDynamicForMasterMapping.expandAll();
}

onChangetableMasterNameInGrid(value,rowIndex){
  let tableName =  this.excelMasterInfo['tableName'];
  let nameTableColumn =  this.excelMasterInfo['nameTableColumn'];
  let data =  this.tableDataMapMasterMapping.get(tableName);
  let codeTableColumn =  this.excelMasterInfo['codeTableColumn'];
 if(codeTableColumn){
  let item =_.find(data.gridarray, function(obj) {
    return obj[nameTableColumn] === value;
});

  if(item){
    this.gridDynamicForMasterMapping.updateCell(rowIndex, "tableMasterCode", item[codeTableColumn]);
  }
 }
 
}


createMasterRow(data,isSubMasterAdd) {
    
  let nameTableColumn = this.excelMasterInfo['nameTableColumn'];
  let codeTableColumn = this.excelMasterInfo['codeTableColumn'];


  this.excelMasterInfo['masterList'] = [];
  data.gridarray.forEach(element => {
    let obj = {
      excelMaster: element[nameTableColumn],
      tableMasterName: element[nameTableColumn],
      tableMasterCode: element[codeTableColumn],
    }

    if (isSubMasterAdd) {
      let arr = [];
      arr.push({
        excelMaster: element[codeTableColumn],
        tableMasterName: element[nameTableColumn],
        tableMasterCode: element[codeTableColumn],
      })
      obj['details'] = arr;
    }
    this.excelMasterInfo['masterList'].push(obj);
  });

  return  this.excelMasterInfo['masterList'];
}

  masterName:String = "";
  addMasterName(){
    this.masterName = "";
    this.openMasterNameModal();
  }
  async deleteMasterName(){
    if (await ui.confirm('Do You Want To Delete Master ?')) {

      if(this.pageConfigurationJSON.jsonMasterMapping){
        for (let index = 0; index < this.pageConfigurationJSON.jsonMasterMapping.length; index++) {
          const element = this.pageConfigurationJSON.jsonMasterMapping[index];
          if(element['active']){
            this.pageConfigurationJSON.jsonMasterMapping.splice(index, 1);
          }
        }
       }
       if(this.pageConfigurationJSON.jsonMasterMapping && this.pageConfigurationJSON.jsonMasterMapping.length > 0 ){
        this.onClickMasterHeader(this.pageConfigurationJSON.jsonMasterMapping[0], 1);
      }else{
        this.masterMappingGrid([],"map_with_constant_value");
      }

      }
  }

  onClickAddMasterName(){
    if(!this.masterName){
     alerts("Master name not valid");
    }
    
   let find =  _.find(this.pageConfigurationJSON.jsonMasterMapping , {"name" : this.masterName});
   if(find){
     alerts(this.masterName+ " Already exist")
     return;
   }
    let obj = {
      "name": this.masterName,
      "tableName": "",
      "active": false,
      "nameTableColumn": "",
      "codeTableColumn": "",
      "masterList": [],
      'masterMappingType':"map_with_table_data",
      'excelMasterList': [],
      'isMasterManualCreate':true,
     
    };
   this.pageConfigurationJSON.jsonMasterMapping.push(obj);
   this.closeMasterNameModal();

  }

  openMasterNameModal(){
    $('#addMasterNameModal').modal('show')
   }
  
   closeMasterNameModal(){
     $('#addMasterNameModal').modal('hide')
   }

   async importTableDataFromDb(){
   
    let isSubMasterAdd = false
   if (await ui.confirm('Do You Want To Create Table Column Code is also master')) {
     isSubMasterAdd = true
   }

    let tableName = this.excelMasterInfo['tableName'];
    let data = this.tableDataMapMasterMapping.get(tableName);
    let isFilterData = this.excelMasterInfo["isFilterData"]

    if (isFilterData) {
      if (this.excelMasterInfo['query']) {
        if (this.excelMasterInfo['query']) {
          if (this.excelMasterInfo['query']['sql']) {
            let query = this.excelMasterInfo['query']['sql']
            let dbData = {
              "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
              "targetDataSource": {},
              "operation": "COMPARESINGLE",
              "connectionRoleType": "admin",
              "dbtype": "master",
              "details": {
                "sql": query,
                "queryType": "select"
              },
            }
            this._dbcomparetoolService.getexecuteSql(dbData).subscribe((res) => {
              if (res) {
                this.createMasterRow(res,isSubMasterAdd);
              
                this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']); 
                this.gridDynamicForMasterMapping.expandAll();
                
              }
            }, Error => {
              alerts("Error While Fetching data");
            });
          }
        }
      }
    } else {
      if (data) {
        this.createMasterRow(data,isSubMasterAdd);
        this.masterMappingGrid(this.excelMasterInfo['masterList'],this.excelMasterInfo['masterMappingType']); 
        this.gridDynamicForMasterMapping.expandAll();
      }
    }
    
  }

  onClickOkMasterMapping(){
    this.closeMasterMappingModal();
    this.mapMasterDropdownForSheetMapping(true);
  }
  
autoFillMaster() {
  let gridData = this.gridDynamicForMasterMapping.getGridData();
  gridData.forEach(element => {
    if ("map_with_constant_value" != this.excelMasterInfo['masterMappingType'] + "") {
      let excelMaster = element.excelMaster;
      let defaultPer = 50;
      this.tableDataDropdownMasterMapping.forEach(tableMaster => {
        let per = this.similarity(excelMaster, tableMaster.val);
        if (per >= defaultPer) {
          defaultPer = per;
          this.gridDynamicForMasterMapping.updateCell(element.sag_G_Index, "tableMasterName", tableMaster.val);
          this.onChangetableMasterNameInGrid(tableMaster.val, element.sag_G_Index)
        }
      });
    }
  });
}

similarity(s1, s2) {
  s1 = s1.toLowerCase();
  s2 = s2.toLowerCase();

  let words = s1.split(/[^\w]/gi);
  
  words = words.filter(function (el) {
    return el != null &&  el != "";
  });

  let count = 0;
  let list = s2.split(/[^\w]/gi);

  list = list.filter(function (el) {
    return el != null &&  el != "";
  });

  for (var i = 0; i < words.length; i++) {
    let word = words[i].trim();
    if (list.includes(word)) {
      count++;
    }
  }

  return (count / parseFloat(words.length)) * 100;

}

contextmenu = false;
contextmenuX = 0;
contextmenuY = 0;

addDisplayMasterColumn = [];

openContextMenuForAddDisplayMaster(event,param) {
  event.preventDefault();
  this.addDisplayMasterColumn = [];
 
  if(param.rowValue.addDisplayMasterColumn){
    this.addDisplayMasterColumn = param.rowValue.addDisplayMasterColumn
  } 
  
  let masterTableName = param.rowValue.tableMaster;
  if(masterTableName){
     let masterColumnData =  this.masterTableFieldMap.get(masterTableName);
     if(masterColumnData){
       
      masterColumnData.forEach(element => {
        if(element.columnName){
         if(!_.find(this.addDisplayMasterColumn ,{columnName:element.columnName})){
           let obj = element;
           obj['isSelect'] = false;
           obj['columnAliase'] = this._getFieldNameFromCaptionName(element.columnName); 
          this.addDisplayMasterColumn.push(obj);
         };
        }
      });
     }
  }
  this.contextmenuX = event.clientX+1
  this.contextmenuY = event.clientY
  this.contextmenu = true;
 

}


@ViewChild("addMasterContextMenu", { static: false }) addMasterContextMenu: ElementRef;
 
@HostListener('document:click', ['$event', '$event.target'])
public onClick(event: MouseEvent, targetElement: HTMLElement): void {
 
  
  if(this.addMasterContextMenu){
    const clickSheetTabName = this.addMasterContextMenu.nativeElement.contains(targetElement);
    if (!clickSheetTabName) {
       let selectedRowData = this.gridDynamicForApiMapping.getSeletedRowData();
       this.gridDynamicForApiMapping.updateCell(selectedRowData.sag_G_Index, "addDisplayMasterColumn", this.addDisplayMasterColumn);
       this.contextmenu = false;
    }
  }

  if(this.editSheetTabName){
    const clickSheetTabName = this.editSheetTabName.nativeElement.contains(targetElement);
    if (!clickSheetTabName) {
       this.documentSectionObjForRef['isRename'] = false;
    }
  }

}


sub: Subscription;
overlayRef: OverlayRef | null;

close() {
  this.sub && this.sub.unsubscribe();
  if (this.overlayRef) {
    this.overlayRef.dispose();
    this.overlayRef = null;
  }
}


getSorceFileByApiId(apiId) {
   
  let userwrokspace = this.dbMappingform.controls["userwrokspace"].value;
  let reqObj = {
   "apiId":apiId,
   "projectPath":userwrokspace
  }

  this.autoJavacodeService.getSorceFileByApiId(reqObj).subscribe(res => {
    if (res.status == 200) {
      let srcfileList = res.data;
      this.openGeneratedJavaFileList(srcfileList , false)
    }
  }, Error => {
    alerts("Error While Fetching Data");
  });
}

openGeneratedJavaFileList(fileList , flagView : boolean = undefined) {

  const ref = this.dialogService.open(GeneratedJavaFileListComponent, {
    header: `Genrate Files`,
    contentStyle: { "margin-top": "0px", "height": "600px" },
    width: '1400px',
    //styleClass: "service_full_model excel-demo-view",
    data: {
      fileList : fileList,
      flagView : flagView 
    }
  });
  ref.onClose.subscribe((res) => {

  });
}

viewJsonImportFile(){
  if(this.jsonGeneratedFileList){
    this.openGeneratedJavaFileList(this.jsonGeneratedFileList);
  }

}

/*****************TABLE FIELD WITH CUSTOM KEY ************************** */
getTableInfoWithCustomKeys(res, tableName) {
  let tableFields = [];

  if (res) {
    res.forEach(tableColumn => {
      let tableFieldInfo = {};
      tableFieldInfo['columnName'] = tableColumn['name'];
      tableFieldInfo['pkey'] = tableColumn['pkey'];
      tableFieldInfo['fkey'] = tableColumn['fkey'];
      tableFieldInfo['dataType'] = tableColumn['type'];
      tableFieldInfo['entityColumn'] = tableColumn['entitylabel'];
      tableFieldInfo['tableName'] = tableName;

      tableFieldInfo['parentTable'] = tableColumn['parenttbl'];
      tableFieldInfo['dbColumnSize'] = tableColumn['size'];
      tableFieldInfo['uniquecol'] = tableColumn['uniquecol'];
      tableFieldInfo['entityName'] = tableColumn['entityName'];
      tableFieldInfo['pkeyName'] = tableColumn['pkeyName'];

      tableFields.push(tableFieldInfo);
    });
  }
  return tableFields;
}

getTableProperties(item):String{
  if(item){
    return item.dataType+"("+item.dbColumnSize+")";
  }
 return ""
}




/**************AI SUGGESTION ********************* */

aiSuggestionText = "";

  onClickAiSuggestion(ele, params) {
    this.aiSuggestionText = "";
   
    this.aiSuggestionText = params.rowValue.aiSuggestionText;
    this.openAiSuggestionModal();
  }

  onClickApplyAiSuggestion(){
    let selectedRowData = this.gridDynamicForApiMapping.getSeletedRowData();
    this.gridDynamicForApiMapping.updateCell(selectedRowData.sag_G_Index, "aiSuggestionText", this.aiSuggestionText);
   
    this.closeAiSuggestionModal();
  }

  openAiSuggestionModal(){
    $('#addAiSuggestionModal').modal('show');
   }
  
   closeAiSuggestionModal(){
    this.aiSuggestionText = "";
     $('#addAiSuggestionModal').modal('hide');
   }



/***********************Document Section ***************************************** */

documentSectionObjForRef = {
  "sectionName" : "JSON" ,
  "apiFieldList":[],
  "recordDisplayType":"sequential_order",
  "duplicateRecordDisplayType":"mark_as_valid_record",
  "aiJsonDisplyOrderByFieldName":"",
  "aiJsonDisplyOrderType":"ascending",
  "jsonType":"dynamic",
  'isRename':false,
  'importDataInsertType':[],
 
};
 
documentSectionList = [];

managePageConfigurationJSONForAiImport(){

  if("Y" == this.pageConfigurationJSON.isJsonImport){
    if(!this.pageConfigurationJSON.documentSectionList || this.pageConfigurationJSON.documentSectionList.length == 0){
    this.pageConfigurationJSON.documentSectionList = [];
     let documentSectionObj = {
        "sectionName": "JSON",
        "apiFieldList": this.pageConfigurationJSON.apiFieldList,
        "recordDisplayType": this.pageConfigurationJSON['recordDisplayType'],
        "duplicateRecordDisplayType": this.pageConfigurationJSON['duplicateRecordDisplayType'],
        "aiJsonDisplyOrderByFieldName": this.pageConfigurationJSON['aiJsonDisplyOrderByFieldName'],
        "aiJsonDisplyOrderType": this.pageConfigurationJSON['aiJsonDisplyOrderType'],
        "jsonType": this.pageConfigurationJSON['jsonType'],
        'importDataInsertType':this.pageConfigurationJSON['importDataInsertType'],
        
        'isRename':false
      }

      this.pageConfigurationJSON.documentSectionList.push(documentSectionObj);
    }

    this.documentSectionList = this.pageConfigurationJSON.documentSectionList;
    
    this.pageConfigurationJSON.apiFieldList = [];

    let item = _.find(this.documentSectionList, { active: true });

    if(!item && this.documentSectionList.length > 0){
       item =  this.documentSectionList[0];
       item['active'] = true;
    }
 
    if(item){
      this.onClickJsonObject(item,0);
    }
    
  
  }
 

}


/********************* Context Menu ***************************************** */
 
@ViewChild("editSheetTabName", { static: false }) editSheetTabName: ElementRef;
displayContextMenu(event,item){
  if(this.documentSectionObjForRef['sectionName'] != item.name){
    this.onClickJsonObject(item, 1);
  }
  
  let self = this;
  event.preventDefault();
  new Contextual({
    isSticky: false,
    items: [
      new ContextualItem({ cssIcon:"fa fa-edit",label: 'Rename', onClick: () => { self.renameSheetName(item) } }),
      new ContextualItem({ cssIcon:"fa fa-trash", label: 'Delete', onClick: () => { self.deleteJsonSection() } }),
    ]
  });

}

  onClickJsonObject(item: any, index) {


    if(item){
      this.documentSectionObjForRef = item;
      for (var key of Object.keys(item)) {
          this.pageConfigurationJSON[key] = item[key]
      }
    }
    
   this.documentSectionList.forEach(itm => itm.active = false);
   this.documentSectionList.forEach(itm => itm.isRename = false);
   item['active'] = true;

    this.loadData();

  }


  renameSheetName(item){
    item['isRename'] = true;
    
  }

  async deleteJsonSection() {
    if (await ui.confirm('Do You Want To Delete Report Section ?')) {

      if (this.documentSectionList) {
        for (let index = 0; index < this.documentSectionList.length; index++) {
          const element = this.documentSectionList[index];
          if (element['active']) {
            this.documentSectionList.splice(index, 1);
          }
        }
      }
    }
  }

  sectionNameForAdd = ""

  addJsonSection(){
   
    this.sectionNameForAdd = "";

    this.cheackSectionAlreadyExist("JSON", true, 0, "JSON");

    let sectionName  = this.sectionNameForAdd;
 
    let documentSectionObj = {
      "sectionName" : sectionName,
      "apiFieldList":[],
      "recordDisplayType":"sequential_order",
      "duplicateRecordDisplayType":"mark_as_valid_record",
      "aiJsonDisplyOrderByFieldName":"",
      "aiJsonDisplyOrderType":"ascending",
      "jsonType":"dynamic",
      'isRename':false,
      'importDataInsertType':[],
       
    }
     
    this.documentSectionList.push(documentSectionObj);
   
  }
 
  
 
   cheackSectionAlreadyExist(sectionName: string, showAlert: boolean, index, tagsectionName) {
    if (this.documentSectionList) {
      if (this.documentSectionList && this.documentSectionList != null) {
        let find =  _.find(this.documentSectionList , {"sectionName" : sectionName });

        if (find) {
          index = index + 1;
          let newMethod = tagsectionName + index;
         
          this.cheackSectionAlreadyExist(newMethod, false, index, tagsectionName)
          } else {
            this.sectionNameForAdd = sectionName;
          }
      }
    }
    
  }


  onChangeAIPoweredDocumentImport(isAIPoweredDocumentImport){
    if("N"==isAIPoweredDocumentImport && "Y" == this.pageConfigurationJSON.isJsonImport){
      this.pageConfigurationJSON.isJsonImport = "N";
      this.onChangeJSONImport("N");
    }else{
      this.javaApiFieldMappingGrid(this.pageConfigurationJSON['apiFieldList']);
    }
  
  }


}
