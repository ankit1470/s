import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-java-api-manual-code',
  templateUrl: './java-api-manual-code.component.html',
  styleUrls: ['./java-api-manual-code.component.scss']
})
export class JavaApiManualCodeComponent implements OnInit,OnDestroy {

  manualCodeBody = "";
  gridDynamicForManualCode: any;
  manualMethodList=[];
  selectedRowManualMethod ="";
  
  gridDynamicForAutoCodeGrid:any
  
  isApiWiseManualCode:boolean = true;

  isImportManualCode:boolean  = false;
  apiFieldList = [];

  documentSectionList = [];
  sheetNameList = [];

  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    public _sagStudioService: SagStudioService,
    private formBuilder: FormBuilder,
     ) { }

  ngOnInit() {
 
    if(this.config.data){
      if(this.config.data.manualMethodList){
        this.manualMethodList = this.config.data.manualMethodList;
      }
      this.isApiWiseManualCode = this.config.data.isApiWiseManualCode
     
      if(this.config.data.isImportManualCode){
        this.isImportManualCode = this.config.data.isImportManualCode
      }
      if(this.config.data.apiFieldList){
        this.apiFieldList = this.config.data.apiFieldList
      }
      if(this.config.data.sheetNameList){
        this.sheetNameList = this.config.data.sheetNameList;
      }

      if(this.config.data.jsonSchemaList){
        this.documentSectionList = this.config.data.jsonSchemaList;
       }
      
    }
  
    this.manualCodeList(this.manualMethodList);
    this.setSelectedRowForManualCode(this.manualMethodList.length > 0); 

    if(this.isImportManualCode){
      let gridData = this.gridDynamicForManualCode.getGridData();
      setTimeout(() => {
        gridData.forEach(element => {
          if(("methodCall" == element.statementType || "statement" == element.statementType)  && "change_value_particular_column"== element.purpose){
            this.setJsonColumnNameDropdownValue(element.sag_G_Index,element.jsonColumnName);
          }
        });
      }, 1000);
     
    }

  }

 


  setManualBodyInGrid() {
    let seletedRowData = this.gridDynamicForManualCode.getSeletedRowData();
   this.gridDynamicForManualCode.updateCell(seletedRowData.sag_G_Index, 'manualCodeBody', this.manualCodeBody);
  }
  
  disableManualCodeAllRowCell(){
    let gridData = this.gridDynamicForManualCode.getGridData();
    gridData.forEach(rowData => {
      this.disableManualCodeRow(rowData.sag_G_Index,rowData.statementType);
    });
  }
  
  disableManualCodeRow(index,value){
  if("statement" == value){
    this.gridDynamicForManualCode.enableCell(index, "afterBeforeType");  
    this.gridDynamicForManualCode.enableCell(index, "purpose");
    this.gridDynamicForManualCode.enableCell(index, "jsonColumnName");
    this.gridDynamicForManualCode.enableCell(index, "sheetName");

  } else{
     this.gridDynamicForManualCode.updateCell(index, "afterBeforeType",'');
     this.gridDynamicForManualCode.disableCell(index, "afterBeforeType");

     this.gridDynamicForManualCode.updateCell(index, "purpose",'');
     this.gridDynamicForManualCode.disableCell(index, "purpose");
  
     this.gridDynamicForManualCode.updateCell(index, "jsonColumnName",'');
     this.gridDynamicForManualCode.disableCell(index, "jsonColumnName");

     this.gridDynamicForManualCode.updateCell(index, "sheetName",'');
     this.gridDynamicForManualCode.disableCell(index, "sheetName");

   }
  }
  
  setSelectedRowForManualCode(isNotEmpty){
  
    if (isNotEmpty) {
      if (this.selectedRowManualMethod) {
        let manualMethodList = this.gridDynamicForManualCode.getGridData();
        let index = 0;
        manualMethodList.forEach(element => {
          if(element.methodName){
            if (this.selectedRowManualMethod.includes(element.methodName)) {
              index = element.sag_G_Index;
           }
          }
        });
        this.gridDynamicForManualCode.setRowSelected(index);
        this.setManualMethodBody()
      }else{
        this.gridDynamicForManualCode.setRowSelected(0);
        this.setManualMethodBody()
      }
    }
  
  }
  
  addRowManualCode(){
    let index = this.gridDynamicForManualCode.sagGridObj.AllRowIndex.length;
    let obj = {
          "methodName":"",
          "classTypeName": "",
          "manualCodeBody": "",
     }
    this.gridDynamicForManualCode.addRowByIndex(index, obj);
    this.disableManualCodeRow(index,"")
     
  }
  
  deleteRowManualCode(){
    this.manualCodeBody = "";
    let selectedRowData = this.gridDynamicForManualCode.getSeletedRowData();
    this.gridDynamicForManualCode.deleteRow(selectedRowData.sag_G_Index);
            if (this.gridDynamicForManualCode.sagGridObj
              && this.gridDynamicForManualCode.sagGridObj.AllRowIndex.length == 0) {
                this.manualCodeList([]); 
            }else{
              this.gridDynamicForManualCode.setRowSelected(0);
              this.setManualMethodBody()
            }
            
  }
  
  
  onClickOkManualMethod(){
    this.manualMethodList = this.gridDynamicForManualCode.getGridData();
    this.modalRef.close(this.manualMethodList);
    this.ngOnDestroy();
  }

  setManualMethodBody() {
    let data = this.gridDynamicForManualCode.getSeletedRowData();
    this.manualCodeBody = data.manualCodeBody;
    
   }

  manualCodeList(rowsData) {
    var sourceDiv = document.getElementById("manualCodeGridId1");
    var columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "50px",
        "editable": "false",
        "textalign": "center",
        "search": true,
      },
      {
        "header": "Statement Type",
        "field": "statementType",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Class Type Name",
        "field": "classTypeName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Method Name",
        "field": "methodName",
        "filter": true,
        "width": "200px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'text',
        "cellRenderView": false
      },
      {
        "header": "Before/After",
        "field": "afterBeforeType",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Sheet Name",
        "field": "sheetName",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
      {
        "header": "Purpose",
        "field": "purpose",
        "filter": true,
        "width": "150px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "component": 'select',
        "cellRenderView": false
      },
    //   {
    //    "header": "Column Name",
    //    "field": "jsonColumnName",
    //    "filter": true,
    //    "width": "150px",
    //    "editable": "false",
    //    "textalign": "center",
    //    "search": true,
    //    "component": 'select',
    //    "cellRenderView": false
    //  } 
      
    ];
  
    


    let self = this;
    let statementType = [
      { "key": "", "val": "--Select--" },
      { "key": "method", "val": "Method" },
      { "key": "statement", "val": "Statement" },
      ];

    let classTypeList = [
      { "key": "", "val": "--Select--" },
      { "key": "service", "val": "Service" },
      { "key": "repository", "val": "Repository" },
     ];
   
     let afterBeforeType = [
      { "key": "", "val": "--Select--" },
      { "key": "before", "val": "Before" },
      { "key": "after", "val": "After" },
     ];
 
     if(!this.isApiWiseManualCode){
      columns = _.filter(columns,ele=>{
        if(ele.field == "afterBeforeType"){
          return false;
        }
        return true;
      })

      if(!this.isImportManualCode){
      statementType = _.filter(statementType,ele=>{
        if(ele.key == "method"){
          return true;
        }
        return false;
      })
    }
  }

   if(this.isImportManualCode){
    columns = _.filter(columns,ele=>{
      if(ele.field == "afterBeforeType" ){
        return false;
      }
      return true;
    })
    }else{
      columns = _.filter(columns,ele=>{
        if(ele.field == "purpose" || ele.field == "jsonColumnName" || ele.field == 'sheetName'){
          return false;
        }
        return true;
      })
    }

  
     let purpose = [
      { "key": "", "val": "--Select--" },
      { "key": "get_data_from_database", "val": "Get Data From Database" },
     // { "key": "change_value_particular_column", "val": "Change Value Particular Column"},
      { "key": "change_value_all_record", "val": "Change Value All Record"},
      { "key": "filter_sheet_data", "val": "Filter Sheet Data"},
      { "key": "custum_validate_excel_data", "val": "Custum Validate Excel Data"},
      { "key": "validate_excel", "val": "Validate Excel"},
      { "key": "read_data", "val": "Read Data"},
      { "key": "process_data", "val": "Process Data"},
      { "key": "save_data", "val": "Save Data"},
      { "key": "statement_after_save", "val": "Statement After Save"},
      { "key": "statement_before_save", "val": "Statement Before Save"},
     ]
  
  

   
    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }
  
    if (undefined != sourceDiv) {
      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        frezzManager: { "sno": "left", "statementType": "left" },
        components: {},
        clientSidePagging: true,
        recordPerPage: 20,
        rowCustomHeight :20,
        cellCustomPadding:5,
     
        recordNo: true,
        callBack: {
          "onRowClick": function () {
            self.setManualMethodBody();
          },
          "onChangeSelect_statementType": function (ele, params) {
            self.disableManualCodeRow(params.rowIndex,ele.value);
            if("statement" == ele.value){
              self.gridDynamicForManualCode.updateCell(params.rowIndex, "classTypeName",'service');
            }
          },
          "onChangeSelect_purpose": function (ele, params) {
            if( "change_value_particular_column"== ele.value){
              self.setJsonColumnNameDropdownValue(params.rowIndex,"");
            }
            self.disableSheetColumn(params.rowIndex,ele.value);
          },
        },
        dropDownJson_statementType: statementType,
        dropDownJson_classTypeName: classTypeList,
        dropDownJson_afterBeforeType: afterBeforeType,
        dropDownJson_sheetName: this.sheetNameList,
        dropDownJson_purpose: purpose,
        dropDownJson_jsonColumnName: [{ "key": "", "val": "--Select--" }],

      };
      this.gridDynamicForManualCode = SdmtGridT(sourceDiv, gridData, true, true);
  
      this.disableManualCodeAllRowCell();
  
      return this.gridDynamicForManualCode;
    }
  }

  disableSheetColumn(index,purpose){
    if( "change_value_particular_column"== purpose){
      this.gridDynamicForManualCode.enableCell(index, "jsonColumnName");  
    }else{
      this.gridDynamicForManualCode.updateCell(index, "jsonColumnName",'');
      this.gridDynamicForManualCode.disableCell(index, "jsonColumnName");  
    }
  }

  jsonColumnVar = [];
  setJsonColumnNameDropdownValue(rowIndex,fillValue){
    this.jsonColumnVar = [];
   
      
      if(this.apiFieldList){
        this.getAllSheetColumnName(this.apiFieldList);
        
       let jsonColumnName = [{ "key": "", "val": "--Select--" }];
        this.jsonColumnVar.forEach(ele => {
          let obj = {
            "key": ele,
            "val": ele
          }
          jsonColumnName.push(obj);
        });
  
        
        if (this.gridDynamicForManualCode && this.gridDynamicForManualCode.sagGridObj.components['jsonColumnName']) {
          this.gridDynamicForManualCode.sagGridObj.components['jsonColumnName'].setOptionRow(jsonColumnName, "jsonColumnName", rowIndex);
        }
        if(fillValue){
          this.gridDynamicForManualCode.updateCell(rowIndex, "jsonColumnName", fillValue);
  
        }
      }
    
     
  }

  getAllSheetColumnName(details){
    if(details){
      details.forEach(element => {
        if(element.details){
          this.getAllSheetColumnName(element.details);
        }else{
          this.jsonColumnVar.push(element.modelFieldName);
        }
        
      });
    }
  
  }


autoCodeGrid(rowsData) {
  var sourceDiv = document.getElementById("autoCodeGridId");
  var columns = [
    {
      "header": "S.No",
      "field": "sno",
      "filter": true,
      "width": "50px",
      "editable": "false",
      "textalign": "center",
      "search": true,
    },
    {
      "header": "File Type",
      "field": "classType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": false
    },
   
    {
      "header": "Method Name",
      "field": "methodName",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": false
    },
    {
      "header": "Method Signature",
      "field": "methodSignature",
      "filter": true,
      "width": "500px",
      "editable": "false",
      "textalign": "center",
      "search": true,
      "component": 'label',
      "cellRenderView": false
    },
    

  ];
  let self = this;

  let components = {};

  var SagGridRowStatus = rowsData;
  for (var i = 0; i < SagGridRowStatus.length; i++) {
    SagGridRowStatus[i]["sno"] = i + 1;
  }

  if (undefined != sourceDiv) {
    var gridData = {
      columnDef: columns,
      rowDef: SagGridRowStatus,
      menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
      selection: "row",
      rowCustomHeight :20,
      cellCustomPadding:5,
      components: components,
      clientSidePagging: true,
      recordPerPage: 20,
      recordNo: true,
      callBack: {
       
      }
    };
    this.gridDynamicForAutoCodeGrid = SdmtGridT(sourceDiv, gridData, true, true);
    return this.gridDynamicForAutoCodeGrid;
  }
}


  ngOnDestroy() { }

  onClose() {
    this.modalRef.close();
    this.ngOnDestroy();
   }


}
