import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DynamicDialogRef, DialogService, DynamicDialogConfig } from 'primeng/api';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';

import { HqlBreadcrumbComponent } from 'src/app/modules/database/dbcompare-tool/hql-generator/components/hql-breadcrumb/hql-breadcrumb.component';
import { JavaDatabaseFunctionApplyComponent } from '../java-database-function-apply/java-database-function-apply.component';
import { JavaApiManualCodeComponent } from '../java-api-manual-code/java-api-manual-code.component';
 


declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SdmtGridT;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;

@Component({ 
host: {
  class: "d-flex flex-column h-100",
},
  selector: 'app-java-api-mapping',
  templateUrl: './java-api-mapping.component.html',
  styleUrls: ['./java-api-mapping.component.scss'],
  providers: [DialogService]
})
export class JavaApiMappingComponent implements OnInit,OnDestroy  {

  apiFieldSimpleFormate = [];
  allTableList = [];
  fileUploadTableNameList = [];


  formTableList = [];
  allTableListDropdownForExtraApi = [];
  tableFieldsDropdownForExtraApi = [];

  pageConfigurationJSON = {}
  oldPageConfigurationJSON = {};

  oldJavaApiInfo = {};
  apiClassInfo;
  controllerMethodList = [];
  
  allPageApiList = [];


  
  apiTypeOptions = [
    { "value": "save", "label": "Save" },
    { "value": "update", "label": "Update" },
    { "value": "delete", "label": "Delete"},
    { "value": "get", "label": "Get Single Record"},
    { "value": "get-all", "label": "Get Multiple Record"},
    { "value": "save-all", "label": "Save Multiple Record"},
    // { "value": "is-exist-check", "label": "Is Exist Check"},
    { "value": "file-display", "label": "File Display"},
    { "value": "file-download", "label": "File Download"},
    { "value": "file-forward", "label": "File Forward"},
    { "value": "extra-api", "label": "Extra Api"},
    { "value": "ai_singlerecord_document_import", "label": "AI Document Import"},
    
   ];


  constructor(private formbuilder: FormBuilder,
    public sagStudioService: SagStudioService,
    public modalRef: DynamicDialogRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    public config: DynamicDialogConfig,
    public autoJavacodeService: AutoJavacodeService,
    private _dbcomparetoolService: DbcomparetoolService,
    public _sagStudioService: SagStudioService,
    private formBuilder: FormBuilder,
     ) { }



  ngOnInit() {
 
    if(this.config.data){
      this.isApiModify = this.config.data.isModify;
      this.apiFieldSimpleFormate = JSON.parse(JSON.stringify(this.config.data.apiFieldSimpleFormate)); 
      this.allTableList = this.config.data.allTableList;
      this.pageConfigurationJSON = JSON.parse(JSON.stringify(this.config.data.pageConfigurationJSON));  
      this.oldPageConfigurationJSON = JSON.parse(JSON.stringify(this.config.data.oldPageConfigurationJSON));
      this.apiClassInfo = JSON.parse(JSON.stringify(this.config.data.apiClassInfo));   
      this.controllerMethodList = JSON.parse(JSON.stringify(this.config.data.controllerMethodList));
      
      this.allPageApiList = JSON.parse(JSON.stringify(this.config.data.allPageApiList));
 
      if(this.isApiModify){
        let apiData = JSON.parse(JSON.stringify(this.config.data.modifyApiData)); 
        this.oldJavaApiInfo = JSON.parse(JSON.stringify(apiData));
        this.modifyApi(apiData);
      } else {
        this.onClickAddApi();
      }
     }  

  }

/********************Add Extra Api Grid****************************** */
isApiModify:boolean = false;
labelNameList = [];
tableFieldListWithLabelName = []
masterLabelList = [];


getAllFieldList = [];

dropdownProcedureList = [];
procedureList=[];


 javaApiInfo = {
   "apiType": "",
   "apiTypeDisplay": "",
   'apiJson': {
     "methodName":"", 

     "uniqeConstList": [{'uniqeConst':[]}],
     "tableNameList": [],
     'selectFieldList':[],
     "whereFieldList":[],
     "groupByFieldList": [],
     "orderByFieldList": [],
     "orderType": "",
     'updateColumnFieldList':[],
     'isFetchDropdownWithGetApi':"N",
     'masterDropdownList':[],
     'isMasterWithTransactionData':"N",
     'fileUploadTableName':"",
     
     'extraApiType' : '',
     'extraApiGenerationType':'',
     'extraApiTableName':'',
     'extraApiPrimaryKey':'',
     'extraApiPrimaryDBDataType':'',
     'procedureName':'',
     'procedureParameter':[],
     'procedureCallingType':"single",
     
     'nativeQuery':"",
     'dbToolJson':{},
     'applyFuntionList':[],
     
      "manualMethodList":[],

      "saveGroupByField":[],
   },
 };



emptyAddApiForm(){
  this.javaApiInfo = {
   "apiType": "",
   "apiTypeDisplay": "",
   'apiJson': {
     "methodName":"", 
 
     "uniqeConstList": [{'uniqeConst':[]}],
     "tableNameList": [],
     'selectFieldList':[],
     "whereFieldList":[],
     "groupByFieldList": [],
     "orderByFieldList": [],
     "orderType": "",
     'updateColumnFieldList':[],
     'isFetchDropdownWithGetApi':"N",
     'masterDropdownList':[],
     'isMasterWithTransactionData':"N",
     'fileUploadTableName':"",

     'extraApiType' : '',
     'extraApiGenerationType':'',
     'extraApiTableName':'',
     'extraApiPrimaryKey':'',
     'extraApiPrimaryDBDataType':"",
     'procedureName':'',
     'procedureParameter':[],
     'procedureCallingType':"single",

     'nativeQuery':"",
     'dbToolJson':{},
     'applyFuntionList':[],
     "manualMethodList":[],

     "saveGroupByField":[],
   },
 };

}

addUniqeConstCheck(){
 this.javaApiInfo.apiJson.uniqeConstList.push({'uniqeConst':[]});
}

deleteUniqeConstCheck(index){
 this.javaApiInfo.apiJson.uniqeConstList.splice(index, 1);
}

 
onClickAddApi(){
 this.fillLableNameList();
 this.fillTableNameListFromApiFiels();
 this.fillAllTableListForExtraApi();
 this.fillMasterLabelList();
 this.getProcedureList();
 this.emptyAddApiForm();
 this.fillFileUploadTableNameList();
 this.filterApiType();
}


modifyApi(modifyData){
 this.getProcedureList();
 this.fillLableNameList();
 this.fillTableNameListFromApiFiels();
 this.fillAllTableListForExtraApi();
 this.fillMasterLabelList();
 this.fillFileUploadTableNameList();
 this.filterApiType();  

 setTimeout(() => {
  this.javaApiInfo =  modifyData;
   
  if('delete' == this.javaApiInfo['apiType'] || 'get' == this.javaApiInfo['apiType'] || 'get-all' == this.javaApiInfo['apiType']){
      this.onChangeApiTableName(this.javaApiInfo.apiJson.tableNameList);
  }
    
  if('extra-api' == this.javaApiInfo.apiType && 'table'== this.javaApiInfo.apiJson.extraApiGenerationType){
      this.onChangeExtraApiTableName(this.javaApiInfo.apiJson.extraApiTableName); 
  }
 }, 100);
}


filterApiType(){
  this.apiTypeOptions = this.apiTypeOptions.filter(ele=>{
    if('N' == this.pageConfigurationJSON['isFileUpload']){
      if(ele.value == "file-display" || ele.value == "file-download" || ele.value == "file-forward"){
        return false;
      }
    }
    return true;
  })
}

fillMasterLabelList(){
 this.masterLabelList = [];
 
 let simpleFormate = this.apiFieldSimpleFormate;

 simpleFormate.forEach(ele => {
   if (this._isValid(ele["tableName"])
     && this._isValid(ele["tableField"]) && "Y" == ele["isMaster"]
     && !this.isBoolean(ele["isMasterSaveAndDuplicateCheck"])) {
     this.masterLabelList.push(ele);
   }

 });
}



fillFileUploadTableNameList(){
  this.fileUploadTableNameList = [];
  
  let simpleFormate = this.apiFieldSimpleFormate;

  let tableNameList = [];
 
  simpleFormate.forEach(ele => {
    if (this._isValid(ele["tableName"])
      && this._isValid(ele["tableField"])
      && this._isValid(ele["dataFindFrom"]) 
      && "FILE" == ele["dataFindFrom"].toUpperCase()
      ) {
        tableNameList.push(ele.tableName);
    }
   });

   tableNameList = _.uniq(tableNameList);
   tableNameList.forEach(tableName => {
    this.fileUploadTableNameList.push({ "value": tableName, "label": tableName });
  });

  

 }
 


fillLableNameList(){
 this.labelNameList = [];
 
 let simpleFormate = this.apiFieldSimpleFormate;

 simpleFormate.forEach(element => {
   this.labelNameList.push(element);
 });
}

fillTableNameListFromApiFiels(){
 this.formTableList = [];
 let simpleFormate = this.apiFieldSimpleFormate;
 let tableNameList = [];
 
 simpleFormate.forEach(element => {
   tableNameList.push(element.tableName);
 });

 let tableList = _.uniq(tableNameList);
 tableList.forEach(tableName => {
   this.formTableList.push({ "value": tableName, "label": tableName });
 });


}



setDisplayName(){
  
   let apiType = this.javaApiInfo['apiType'];

  let find = _.find(this.apiTypeOptions,{"value":apiType})
   if(find){
       this.javaApiInfo['apiTypeDisplay'] =  find.label
   } else{
       this.javaApiInfo['apiTypeDisplay'] =  apiType
   }
  
}


 onChangeApiTableName(tableNameList) {
   this.tableFieldListWithLabelName = [];
   this.tableFieldListWithLabelName = this.labelNameList.filter(ele => {
     return tableNameList.includes(ele.tableName);
   }).map(ele=>{
    let obj = {
      "value":  ele['_uniqeId'] ,
      "label": ele.labelName
    }

     return obj;
   });

 }


 onChangeExtraApiTableName(tableName){
   if (tableName) {
    this.createMethodByApiType();
     let dbData = {
       "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
       "targetDataSource": {},
       "operation": "COMPARESINGLE",
       "connectionRoleType": "admin",
       "dbtype": "master",
       "tableName": tableName
     }
     this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
       if (res) {
         this.setTableFieldsDropdownForExtraApi(res,tableName);
       }
     }, Error => {
       alerts("Error While Fetching data");
     });
   }
 
}


setTableFieldsDropdownForExtraApi(res,tableName){
   
  this.tableFieldsDropdownForExtraApi = this.getTableInfoWithCustomKeys(res,tableName);
 
  let pkObj = _.find(res, { "pkey": "Y" });

  if(pkObj){
    this.javaApiInfo.apiJson.extraApiPrimaryKey =  pkObj.name;
    this.javaApiInfo.apiJson.extraApiPrimaryDBDataType =  pkObj.dataType;
   }

}

  getTableInfoWithCustomKeys(res, tableName) {
    let tableFields = [];

    if (res) {
      res.forEach(tableColumn => {
        let tableFieldInfo = {};
        tableFieldInfo['columnName'] = tableColumn['name'];
        tableFieldInfo['pkey'] = tableColumn['pkey'];
        tableFieldInfo['fkey'] = tableColumn['fkey'];
        tableFieldInfo['dataType'] = tableColumn['type'];
        tableFieldInfo['entityColumn'] = tableColumn['entitylabel'];
        tableFieldInfo['tableName'] = tableName;

        tableFieldInfo['parentTable'] = tableColumn['parenttbl'];
        tableFieldInfo['dbColumnSize'] = tableColumn['size'];
        tableFieldInfo['uniquecol'] = tableColumn['uniquecol'];
        tableFieldInfo['entityName'] = tableColumn['entityName'];
        tableFieldInfo['pkeyName'] = tableColumn['pkeyName'];

        tableFields.push(tableFieldInfo);
      });
    }
    return tableFields;
  }



fillAllTableListForExtraApi(){
  this.allTableListDropdownForExtraApi = [];
  this.allTableList.forEach(table => {
    let obj = {
      "value": table,
      "label": table
    }
    this.allTableListDropdownForExtraApi.push(obj);
  });


}


getProcedureList(){
 let finalDataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
 let srcDataSource= finalDataForConnection.srcDataSource;

 let reqObj = {
   hostName: srcDataSource.hostName,
   portNumber: srcDataSource.portNumber,
   databaseName: srcDataSource.databaseName,
   userName: srcDataSource.userName,
   password: srcDataSource.password,
 }

 this.autoJavacodeService.getProcedureList(reqObj).subscribe(res => {
   if (res.sucess == true) {
     this.procedureList = res["data"];
     
     this.procedureList.forEach(ele => {
       this.dropdownProcedureList.push({ "value": ele.storedProcedureName, "label": ele.storedProcedureName });
     });
 


   } else {
     if (res.sucess == false) {
       alerts(res.msg);
     }
   }

 }, Error => {
   alerts("Error While fetch");
 })

}

onChangeProcedureName(storedProcedureName){

 this.javaApiInfo.apiJson.procedureParameter  = [];

 if(storedProcedureName && storedProcedureName!=''){
  this.createMethodByApiType();

   let finalDataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
   let srcDataSource= finalDataForConnection.srcDataSource;
 
   let reqObj = {
     hostName: srcDataSource.hostName,
     portNumber: srcDataSource.portNumber,
     databaseName: srcDataSource.databaseName,
     userName: srcDataSource.userName,
     password: srcDataSource.password,
     storedProcedureName:storedProcedureName
   }
 
   this.autoJavacodeService.getProcedureParameter(reqObj).subscribe(res => {
     if (res.sucess == true) {
       this.javaApiInfo.apiJson.procedureParameter =  res["data"];
     } else {
       if (res.sucess == false) {
         alerts(res.msg);
       }
     }
 
   }, Error => {
     alerts("Error While Fetch");
   })
  
 }
}





openDatabaseTool(){
 
 if (!this.javaApiInfo.apiJson.extraApiTableName) {
   alerts("Table Name Can Not Be Null");
   return;
 }

 let dbDataInfo = JSON.parse(JSON.stringify(this.shareService.getDatadbtool('finalDataForConnection')));
 dbDataInfo['dbtype'] = "master"; //  nikhil sir added here..
 dbDataInfo['tableName'] = this.javaApiInfo.apiJson.extraApiTableName

 if (this.javaApiInfo.apiJson.dbToolJson['json'] && this.javaApiInfo.apiJson.dbToolJson['json']['details']) {
   dbDataInfo['details'] = {
     queryType: this.javaApiInfo.apiJson.dbToolJson['json'].details.queryType,
     hqlData: this.javaApiInfo.apiJson.dbToolJson['json'].details.selectQuery ||
      this.javaApiInfo.apiJson.dbToolJson['json'].details.updateQuery || 
      this.javaApiInfo.apiJson.dbToolJson['json'].details.deleteQuery,
   }
 }else{
   this.javaApiInfo.apiJson.dbToolJson['tableName'] = dbDataInfo['tableName'];
   this.javaApiInfo.apiJson.dbToolJson['methodName'] = "test";
   
 }

 if (dbDataInfo) {
   this._dbcomparetoolService.tblstrcturedrpdown(dbDataInfo).subscribe(
     (response: any) => {
       if (response) {
         let sourceTableNameOptions = response['masterdropdown']['mtbllist'].map((item) => {
           let newItem = {};
           newItem['label'] = item;
           newItem['value'] = item;
           return newItem;
         });

         this.shareService.setDatadbtool("sourceTableNameOptions", sourceTableNameOptions);
         // Add  For new Entity Hql Structure
         this.shareService.setDatadbtool('hqlConnectionInfo', dbDataInfo);

         const ref = this.dialogService.open(HqlBreadcrumbComponent, {
           header: 'HqlBreadcrumbComponent ',
           width: '100%',
           styleClass: "service_full_model",
           contentStyle: { "height": "100%!important", "display": "flex", "flex-direction": "column", "overflow": "hidden" },
           data: this.javaApiInfo.apiJson.dbToolJson,
         });
         ref.onClose.subscribe((res) => {
           if (res) {
             this.javaApiInfo.apiJson.dbToolJson['javaMCode'] = res.javaMCode;
             this.javaApiInfo.apiJson.dbToolJson['accessspecifier'] = res.accessspecifier;
             this.javaApiInfo.apiJson.dbToolJson['returntype'] = res.returntype;
             this.javaApiInfo.apiJson.dbToolJson['json'] = res.json;
             this.javaApiInfo.apiJson.dbToolJson['tableName'] = res.json.details.selectQuery ? res.json.details.selectQuery.tbl.name :
             res.json.details.updateQuery ? res.json.details.updateQuery.tbl.name :
               res.json.details.deleteQuery ? res.json.details.deleteQuery.tbl.name : '';
        }
         });

       }
     },
     err => {
       console.error('err response');
     });
 }
}




/********************UTIL METHOD **************************** */

_isValid(val) {
 return val !== null && val.toString().trim() !== '';
}

isBoolean(value) {
 let val = String(value);
 let res = val.toLowerCase() === 'true' ? true : val === '1' ? true : false;
 return res;
}




  ngOnDestroy() { }

  onClose() {
    this.modalRef.close();
    this.ngOnDestroy();
   }



 /****************************************** GENERATE JAVA API ******************************************************************** */

 generateJavaApi() {

  let isValid = this.checkJavaApiInfoValidOrNot();
  if(!isValid){
    alerts("plase fill all required field");
    return;
  }

  let apiMppingInfo = JSON.parse(JSON.stringify(this.apiClassInfo));
    
  apiMppingInfo['pageConfigurationJSON'] = this.pageConfigurationJSON;
  apiMppingInfo['javaApiInfo'] = this.javaApiInfo;
  apiMppingInfo['allPageApiList'] = this.allPageApiList;
  
   let srcDataSource = null;
   let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
   if(dataForConnection && dataForConnection.srcDataSource){
     srcDataSource = dataForConnection.srcDataSource;
   }

   let reqObj = {
     apiCategory: 'all_api', 
     newApiInfoObj: apiMppingInfo,
     apiId: null,
     apijsonId: null,
     oldApiInfoObj: null,
     databaseConfig:srcDataSource
   }

   this.autoJavacodeService.generateJavaNewCode(reqObj).subscribe(res => {
    if (res.status == 200) {
       this.shareService.setDataprotool("dataType", "ProjectType");
       this.finalDbMappingSaveJava();
       
      success(res["msg"]);
      let apiList = this.sagStudioService.getAllApiList();

      let apiInfo = res.generatedJavaApiInfo;
      if(apiInfo){
          let apiObj = {
            uniqId: `${new Date().getTime()}${1}`,
            baseUrl: 'apiConstant.projectBaseUrl',
            argument: '',
            methodName: '',
            apiType: `${apiInfo.apiType}`,
            url: `${apiInfo.apiName}`,
            expectedReq: ``,
            expectedRes: ``,
            descr: '',
            apiId:apiInfo.apiId  
          }
          apiList.push(apiObj);
      }
 

      this.modalRef.close(this.javaApiInfo);
      this.ngOnDestroy();

    } else if (res.status == 400) {
      alerts(res.msg);
     
    } else {
      alerts(res.msg);
    }

   }, Error => {
     alerts("Error While Generating");
   })

}


modifyJavaApi() {

  let isValid = this.checkJavaApiInfoValidOrNot();
  if(!isValid){
    alerts("plase fill all required field");
    return;
  }

  let apiMppingInfo = JSON.parse(JSON.stringify(this.apiClassInfo));
    
  apiMppingInfo['pageConfigurationJSON'] = this.pageConfigurationJSON;
  apiMppingInfo['javaApiInfo'] = this.javaApiInfo;
  apiMppingInfo['allPageApiList'] = this.allPageApiList;


  let oldApiInfoObj = JSON.parse(JSON.stringify(this.apiClassInfo));
  oldApiInfoObj['pageConfigurationJSON'] = this.oldPageConfigurationJSON;
  oldApiInfoObj['javaApiInfo'] = this.oldJavaApiInfo;
  oldApiInfoObj['allPageApiList'] = this.allPageApiList;


   let srcDataSource = null;
   let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
   if(dataForConnection && dataForConnection.srcDataSource){
     srcDataSource = dataForConnection.srcDataSource;
   }

   let reqObj = {
     apiCategory: 'all_api', 
     newApiInfoObj: apiMppingInfo,
     apiId: this.oldJavaApiInfo['apiId'], 
     apijsonId: null,
     oldApiInfoObj: oldApiInfoObj,
     databaseConfig:srcDataSource
   }

   this.autoJavacodeService.modifyJavaApi(reqObj).subscribe(res => {
    if (res.status == 200) {
       this.shareService.setDataprotool("dataType", "ProjectType");
       this.finalDbMappingSaveJava();
       
      success(res["msg"]);
      let apiList = this.sagStudioService.getAllApiList();

      let apiInfo = res.generatedJavaApiInfo;
      if(apiInfo){
          let apiObj = {
            uniqId: `${new Date().getTime()}${1}`,
            baseUrl: 'apiConstant.projectBaseUrl',
            argument: '',
            methodName: '',
            apiType: `${apiInfo.apiType}`,
            url: `${apiInfo.apiName}`,
            expectedReq: ``,
            expectedRes: ``,
            descr: '',
            apiId:apiInfo.apiId  
          }
          apiList.push(apiObj);
      }
 
      this.modalRef.close(this.javaApiInfo);
      this.ngOnDestroy();

    } else if (res.status == 400) {
      alerts(res.msg);
    
    } else {
      alerts(res.msg);
    }

   }, Error => {
     alerts("Error While Generating");
   })

}


/***********************************SAVE PAGE DB MAPPING******************************************************* */

finalDbMappingSaveJava() {
   

  let simpleFormate = this.apiFieldSimpleFormate;

  if (simpleFormate) {
    let pageMappingDbJson = []

    const activeFile = this.sagStudioService.currentActiveProject.currentActiveFileNode;
    const __prjDetails = this.shareService.getDataprotool("selectedProjectChooseData");
    const Filepath = activeFile.projectPath.substring(activeFile.projectPath.lastIndexOf("src"));
    simpleFormate.forEach((_item) => {
      if(_item['inputId']){
        const _ValuesDbJson = {
          filePath: Filepath,
          moduleName: "",
          formName: "",
          labelName: _item['labelName'],
          inputId: _item['inputId'],
          inputType: _item['subtype'],
          inputLen: null,
          tableName: _item['tableName'],
          tableCol: _item['tableField'],
          coltype: _item['tableCoulmnType'],
          colsize: _item['tableCoulmnSize'],
          tblfkey: _item['fkey'],
          tblpkey: _item['pkey'],
          entity: _item['entityLable'],
          entityField: _item['entityColumn'],
          entityfieldType: this.getJavaWrapperDataTypeFromSqlDataType(_item['tableCoulmnType']),
          varname: "",
          vartype: ""
        }
        
      pageMappingDbJson.push(_ValuesDbJson)
      }
    

    })

    const reqJson = {
      projectId: __prjDetails["projectId"],
      filePath: Filepath,
      mappingtype: "JAVA",
      pageMap: pageMappingDbJson
    }

    this.autoJavacodeService.saveDbMappingJson(reqJson).subscribe(res => {
    

    });
  }
}






getJavaWrapperDataTypeFromSqlDataType(sqlDataType) {
  let javaType = "";
  if(!sqlDataType){
    return javaType;
  }
  switch (sqlDataType.toLowerCase()) {
    case "bit":
    case "tinyint":
      javaType = "Boolean";
      break;
    case "smallint":
      javaType = "Short";
      break;
    case "int":
      javaType = "Integer";
      break;
    case "real":
      javaType = "Float";
      break;
    case "bigint":
      javaType = "Long";
      break;
    case "float":
    case "double":
      javaType = "Double";
      break;
    case "char":
    case "varchar":
    case "text":
    case "longtext":
      javaType = "String";
      break;
    case "date":
      javaType = "Date";
      break;
    case "decimal":
    case "numeric":
      javaType = "Double";
      break;
    case "time":
      javaType = "Time";
      break;
    case "blob":
    case "longblob":
    case "tinyblob":
    case "mediumblob":
      javaType = "Uint8Array";
      break;
    default:
      javaType = sqlDataType;
      break;
  }
  return javaType;
}


/******************************************** METHOD NAME **************************************************************** */

onMethodNameChange(methodName){ 
  this.cheackMethodAlreadyExist(methodName, true, 0, methodName);
}

 //--------------------------------Method Duplicate Cheack-----
 cheackMethodAlreadyExist(methodName: string, showAlert: boolean, index, tagMethodName) {
  if (this.controllerMethodList) {
    if (this.controllerMethodList && this.controllerMethodList != null) {
     
      let flag = false;
      if (this.isApiModify) {
        let updatedMethodName = this.javaApiInfo.apiJson.methodName;
        if (methodName != updatedMethodName) {
          if (this.controllerMethodList.includes(methodName)) {
            flag = true;
          }
        } else {
          flag = false;
        }
      } else {
        if (this.controllerMethodList.includes(methodName)) {
          flag = true;
        } else {
          flag = false;
        }
      }
      if (flag) {
        if (showAlert) {
          alerts("Duplicate Method not allowed")
        }
        index = index + 1;
        let newMethod = tagMethodName + index;
        this.javaApiInfo.apiJson.methodName = newMethod;
       
        this.cheackMethodAlreadyExist(newMethod, false, index, tagMethodName)

      }

      //return flag;
    }
  }
  //  return false;
}

onChangeApiType(apiType){
if(apiType){

  this.createMethodByApiType();
  
 }
}

createMethodByApiType (){

  if(this.isApiModify){
    return;
  }

let apiType  = this.javaApiInfo.apiType;
let methodName = "";



if ("save" == apiType){
 methodName = "save";
} else if ("update" == apiType){
  methodName = "update"
} else if ("delete" == apiType){
  methodName = "delete"
} else if ("get" == apiType){
  methodName = "get"
} else if ("get-all" == apiType){
   methodName = "getAll"
} else if ("save-all" == apiType){
  methodName = "saveAll"
} else if  ("file-display" == apiType ){
  methodName = "fileDisplay"
  if(this.javaApiInfo.apiJson.fileUploadTableName){
    methodName = methodName + this._getSuffixMethodNameFromTable(this.javaApiInfo.apiJson.fileUploadTableName);
  }


} else if ("file-download" == apiType ){
  methodName = "fileDownload"
  if(this.javaApiInfo.apiJson.fileUploadTableName){
    methodName = methodName + this._getSuffixMethodNameFromTable(this.javaApiInfo.apiJson.fileUploadTableName);
  }
} else if ("file-forward" == apiType ){
  methodName = "fileForward"
  if(this.javaApiInfo.apiJson.fileUploadTableName){
    methodName = methodName + this._getSuffixMethodNameFromTable(this.javaApiInfo.apiJson.fileUploadTableName);
  }
}else if ("ai_singlerecord_document_import" == apiType ){
  methodName = "documentImport"
  if(this.javaApiInfo.apiJson.fileUploadTableName){
    methodName = methodName + this._getSuffixMethodNameFromTable(this.javaApiInfo.apiJson.fileUploadTableName);
  }
}else if ("extra-api" == apiType){
  let extraApiType = this.javaApiInfo.apiJson.extraApiType;
  let extraApiGenerationType = this.javaApiInfo.apiJson.extraApiGenerationType;
  
  if('extra-get' == extraApiType){
    methodName = "get";
  } else  if('extra-get-all' == extraApiType){
    methodName = "getAll";
  } else  if('extra-delete' == extraApiType){
    methodName = "delete";
  } else  if('extra-exist-check' == extraApiType){
    methodName = "existCheck";
  }
  else  if('extra-update' == extraApiType){
    methodName = "update";
  }

  if('table' == extraApiGenerationType){
     if(this.javaApiInfo.apiJson.extraApiTableName){
      methodName = methodName + this._getSuffixMethodNameFromTable(this.javaApiInfo.apiJson.extraApiTableName);
     }
  } else  if('db-tool' == extraApiType){
    if(this.javaApiInfo.apiJson.extraApiTableName){
       methodName = methodName + this._getSuffixMethodNameFromTable(this.javaApiInfo.apiJson.extraApiTableName);
     }

  } else  if('native-query' == extraApiType) {
    
  } else  if('stored-procedure' == extraApiType){
    if(this.javaApiInfo.apiJson.extraApiTableName){
      methodName = methodName + this._getSuffixMethodNameFromTable(this.javaApiInfo.apiJson.procedureName);
     }
  }



}

this.javaApiInfo.apiJson.methodName = methodName;
this.cheackMethodAlreadyExist(methodName, false, 0, methodName);

}


_getSuffixMethodNameFromTable(tableName) { 
  let words = tableName.split(/[\W_]+/);
  let builder = '';
  for (let i = 0; i < words.length; i++) {
    let word = words[i];
    word = word.length === 0 ? word : word.charAt(0).toUpperCase() + word.substring(1).toLowerCase();
    builder += word;
  }
  return builder;
}




/********************Apply Function********************************************* */





openApplyFunctionModel(item,index){
  
  //let selectFieldList = this.tableFieldListWithLabelName;

  let selectFieldList =  this.labelNameList.filter(ele => {
    return _.map(this.tableFieldListWithLabelName,"value").includes(ele._uniqeId);
  })

   let callingType = "custom";

  if("extra-api" == this.javaApiInfo.apiType){
    if('table' == this.javaApiInfo.apiJson.extraApiGenerationType){
     
      if (this.javaApiInfo.apiJson.selectFieldList) {
        selectFieldList = this.javaApiInfo.apiJson.selectFieldList.map(ele => {
          let obj = {
            "labelName": ele.columnName,
            "modelFieldName": ele.columnName,
            "tableName": ele.tableName,
            'columnType': ele.dataType,
            'tableCoulmnType': ele.dataType,
            
          };
          return obj;
        })
      }
    }
    if('db-tool' == this.javaApiInfo.apiJson.extraApiGenerationType){

      callingType = "db_tool"

      if ( this.javaApiInfo.apiJson.dbToolJson['json']) {
        let select = this.javaApiInfo.apiJson.dbToolJson['json'].details.selectQuery.select

        selectFieldList = select.map(ele => {
          let obj = {
            "labelName": ele.cAlias,
            "modelFieldName": ele.cAlias,
            "tableName": ele.tbl,
            'columnType': "all_type",
            'tableCoulmnType': "",
            
          };
          return obj;
        })
      }
    }

  }
  

  const ref = this.dialogService.open(JavaDatabaseFunctionApplyComponent, {
    header: "Api",
    contentStyle: { "margin-top": "0px", "height": "500px" },
    width: '700px',
    data: {
      'item':item,
      'selectFields': selectFieldList,
      "callingType":callingType
     },
 
  });
  ref.onClose.subscribe((res) => {
   if(res){
    if (index != undefined && index != null && index+"" != "") {
      this.javaApiInfo.apiJson.applyFuntionList.splice(index, 1, res);
    } else {
      this.javaApiInfo.apiJson.applyFuntionList.push(res);
    }
   }
   
  });
}

deleteApplyFunction(item, index) {
  this.javaApiInfo.apiJson.applyFuntionList.splice(index, 1);
}

editApplyFunction(item, index) {
  this.openApplyFunctionModel(item,index);
 }

/***********************Manual Code *************************** */

openManualCodeComponent(){
  
  const ref = this.dialogService.open(JavaApiManualCodeComponent, {
    header: "Manual Code",
    width: "100%",
    contentStyle: { "margin-top": "0px", "height": "100%" },
    styleClass: "service_full_model excel-demo-view",
    data: {
      'manualMethodList': this.javaApiInfo.apiJson.manualMethodList,
      "isApiWiseManualCode":true
    },
 
  });
  ref.onClose.subscribe((res) => {
   if(res){
    this.javaApiInfo.apiJson.manualMethodList = res;
   }
   
  });
}

checkJavaApiInfoValidOrNot(){
  let apiType =  this.javaApiInfo.apiType;
 let isValid = true;

 if(!apiType){
  isValid = false;
  return;
 }

  if ("save" == apiType){
    if(!this.javaApiInfo.apiJson.methodName){
      isValid = false;
    }

   } else if ("update" == apiType){
    if(!this.javaApiInfo.apiJson.methodName){
      isValid = false;
    }
   } else if ("delete" == apiType){
    if(!this.javaApiInfo.apiJson.methodName || !this.javaApiInfo.apiJson.tableNameList || this.javaApiInfo.apiJson.tableNameList.length == 0){
      isValid = false;
    }


   } else if ("get" == apiType){
    if(!this.javaApiInfo.apiJson.methodName || !this.javaApiInfo.apiJson.tableNameList || this.javaApiInfo.apiJson.tableNameList.length == 0){
      isValid = false;
    }
   } else if ("get-all" == apiType){
    if(!this.javaApiInfo.apiJson.methodName || !this.javaApiInfo.apiJson.tableNameList || this.javaApiInfo.apiJson.tableNameList.length == 0){
      isValid = false;
    }
   } else if ("save-all" == apiType){
    if(!this.javaApiInfo.apiJson.methodName){
      isValid = false;
    }
   } else if  ("file-display" == apiType ){
    if(!this.javaApiInfo.apiJson.methodName || !this.javaApiInfo.apiJson.fileUploadTableName){
      isValid = false;
    }
   } else if ("file-download" == apiType ){
    if(!this.javaApiInfo.apiJson.methodName || !this.javaApiInfo.apiJson.fileUploadTableName){
      isValid = false;
    }
   } else if ("file-forward" == apiType ){
    if(!this.javaApiInfo.apiJson.methodName || !this.javaApiInfo.apiJson.fileUploadTableName){
      isValid = false;
    }
   }else if ("extra-api" == apiType){ 
     let extraApiType = this.javaApiInfo.apiJson.extraApiType;
     let extraApiGenerationType = this.javaApiInfo.apiJson.extraApiGenerationType;
     
     if(!this.javaApiInfo.apiJson.methodName || !extraApiType || !extraApiGenerationType){
       isValid = false;
       return isValid;
     }

     if('table' == extraApiGenerationType || "db-tool" == extraApiGenerationType){
      if(!this.javaApiInfo.apiJson.extraApiTableName){
        isValid = false;
      }
     } 
     if('native-query' == extraApiGenerationType){
      if(!this.javaApiInfo.apiJson.nativeQuery){
        isValid = false;
      }
     } 
     if('stored-procedure' == extraApiGenerationType){
      if(!this.javaApiInfo.apiJson.procedureName){
        isValid = false;
      }
     } 
      

}
return isValid;
}
}

