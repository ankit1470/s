import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectSecuritySelectApiComponent } from './project-security-select-api.component';



@NgModule({
  declarations: [ProjectSecuritySelectApiComponent],
  imports: [
    CommonModule
  ]
})
export class ProjectSecuritySelectApiModule { }
