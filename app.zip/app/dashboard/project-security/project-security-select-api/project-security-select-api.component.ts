import { Component, OnInit, OnDestroy } from '@angular/core';
 
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
 
import { SagShareService } from 'src/app/services/sagshare.service';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/primeng';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
 
 


declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;

@Component({
  selector: 'app-project-security-select-api',
  templateUrl: './project-security-select-api.component.html',
  styleUrls: ['./project-security-select-api.component.scss']
})
export class ProjectSecuritySelectApiComponent implements OnInit,OnDestroy {
  
 
  userwrokspace
  buttonLabel="Set"
  oldSelectApi = []

  constructor(public shareService: SagShareService,
    public dialogService: DialogService,
    private service: AutoJavacodeService,
    private formbuilder: FormBuilder,
    public config: DynamicDialogConfig,
    public modalRef: DynamicDialogRef,
    
  ) {

  }

  ngOnInit() {
    if(this.config.data){
    if(this.config.data.userwrokspace){
      this.userwrokspace = this.config.data.userwrokspace;
    }

    if(this.config.data.oldSelectApi){
      this.oldSelectApi = this.config.data.oldSelectApi;
    }


    if(this.config.data.projectAllApiList){
      this.getProjectAllApi();
    }

    if(this.config.data.buttonLabel){
      this.buttonLabel = this.config.data.buttonLabel;
    }
   


    }
  }

  async getProjectAllApi() {
 
    let projectAllApiList = JSON.parse(JSON.stringify(this.config.data.projectAllApiList));
    if(this.oldSelectApi){
     projectAllApiList.forEach(allApi => {
       this.oldSelectApi.forEach(oldApi => {
         if(allApi.apiName == oldApi.apiName && allApi.controllerName == oldApi.controllerName && allApi.requestMethodType == oldApi.requestMethodType){
           allApi.checkBox = 1;
         }
       });
    });
 }
  
    this.projectSecurityGridForModal(projectAllApiList);
  
   }
 

   /************************************************ */
   rowData_projectsecuritygrid: any = [
    {},
    {},
    {},
    {}
  ];

  validationprojectsecuritygrid: any = {}
  gridDynamicObj_projectsecuritygrid:any
  gridData_projectsecuritygrid: any;
  columnData_projectsecuritygrid: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "hidden": false,
      "editable": false,
      "sort": false,
      "filter": false,
      "search": false,
      "component": "checkbox",
      "field": "checkBox",
      "freezecol": "null",
      "width": "40px",
      "header": "",
      "headerbuttoncomponent": "headerCheckBox",
      "cellHover": false,
      "text-align": "center",
      "cellRenderView": true
    },
    {
      "header": "Class Name",
      "field": "controllerName",
      "filter": true,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    {
      "header": "Api Name",
      "field": "apiName",
      "filter": true,
      "width": "400px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Request Type",
      "field": "requestMethodType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    
  ];


   projectSecurityGridForModal(rowData?: any, colData?: any) {
    this.gridData_projectsecuritygrid = {
      columnDef: colData ? colData : this.columnData_projectsecuritygrid,
      rowDef: rowData ? rowData : this.rowData_projectsecuritygrid,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationprojectsecuritygrid,
      newPagination: false,
      recordPerPage: 10,
      newExpandExportTotalRecord_hide: undefined,
      ellipsisV: {},
      gridCustomButtonsArr: "",
      cellCustomPadding: NaN,
      sml_expandGrid_position: "bottom",
      totalNoOfRecord_position: "bottom",
      toggleViewButton: false,
      gridConfigrationBtn: false,
      rowAutoSelection: false,
      gridRowAddDeleteButton: false,
      components: {},
      callBack: {
      },

      rowCustomHeight: 20,
      plusButton_obj: {},
    };

    let sourceDiv = document.getElementById("projectsecurityselectapiformodal");
    this.gridDynamicObj_projectsecuritygrid = SdmtGridT(sourceDiv, this.gridData_projectsecuritygrid, true, true);
  }


  ngOnDestroy(): void {
    
  }

  applyAPi(){
    let _checkSelected_Array = this.gridDynamicObj_projectsecuritygrid.getCheckedDataParticularColumnWise();
    this.modalRef.close(_checkSelected_Array);
    this.ngOnDestroy();
  }

  onClose() {
    this.modalRef.close();
    this.ngOnDestroy();
   }

}
