import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AccordionModule} from 'primeng/accordion';

import { ProjectSecurityRoutingModule } from './project-security-routing.module';
import { MessagesModule, OrganizationChartModule, DropdownModule } from 'primeng/primeng';
import { ProjectSecurityComponent } from './project-security.component';
import { SharedModule } from 'src/app/core/shared/shared.module';
 


@NgModule({
  declarations: [ProjectSecurityComponent],
  imports: [
    CommonModule,
    ProjectSecurityRoutingModule,AccordionModule ,MessagesModule,OrganizationChartModule,DropdownModule, SharedModule
  ],
  exports:[ProjectSecurityComponent]
})
export class ProjectSecurityModule { }
