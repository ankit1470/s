import { Component, OnInit, OnDestroy } from '@angular/core';
 
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
 
import { SagShareService } from 'src/app/services/sagshare.service';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/primeng';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';

declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;


@Component({
  selector: 'app-project-security-provider-configuration',
  templateUrl: './project-security-provider-configuration.component.html',
  styleUrls: ['./project-security-provider-configuration.component.scss']
})
export class ProjectSecurityProviderConfigurationComponent implements OnInit ,OnDestroy{

  oauthproviderConfigurationList  = [];
  securityOauth2ProviderFormGroup: FormGroup;
  submittedSecurityProviderForm:boolean = false;

  constructor(public shareService: SagShareService,
    public dialogService: DialogService,
    private service: AutoJavacodeService,
    private formbuilder: FormBuilder,
    public config: DynamicDialogConfig,
    public modalRef: DynamicDialogRef,
    
  ) {

  }

  ngOnInit() {
    this.initializeForm();
    if(this.config.data){
      if(this.config.data.oauthproviderConfigurationList){
        this.oauthproviderConfigurationList = this.config.data.oauthproviderConfigurationList;
      }
    }
    this.projectSecurityGridForModal();
  }


  initializeForm() {
    this.securityOauth2ProviderFormGroup = this.formbuilder.group({
      providerName: [{ value: '', disabled: true },[Validators.required]],
      registrationId: [{ value: '', disabled: true },[Validators.required]],
      clientName: [{ value: '', disabled: true },[Validators.required]],
      clientId: [{ value: '', disabled: true },[Validators.required]],
      clientSecret: [{ value: '', disabled: true },[Validators.required]],
      clientAuthenticationMethod: [{ value: '', disabled: true },[Validators.required]],
      authorizationGrantType: [{ value: '', disabled: true },[Validators.required]],
      redirectUri: [{ value: '', disabled: true },[Validators.required]],
      scope: [{ value: '', disabled: true },[Validators.required]],
      authorizationUri: [{ value: '', disabled: true },[Validators.required]],
      tokenUri: [{ value: '', disabled: true },[Validators.required]],
      usernfoUri: [{ value: '', disabled: true },[Validators.required]],
      usernameAttributeName: [{ value: '', disabled: true },[Validators.required]],
      jwkSetUri: [{ value: '', disabled: true },[Validators.required]],
      
     })

  }

   /************************************************ */

  validationprojectsecuritygrid: any = {}
  gridDynamicObj_projectsecuritygrid:any
  gridData_projectsecuritygrid: any;
  columnData_projectsecuritygrid: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    
    {
      "header": "Provider Name",
      "field": "providerName",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    {
      "header": "Registration Id",
      "field": "registrationId",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Client Name",
      "field": "clientName",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Client Id",
      "field": "clientId",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Client Secret",
      "field": "clientSecret",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Client Authentication Method",
      "field": "clientAuthenticationMethod",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Authorization Grant Type",
      "field": "authorizationGrantType",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Redirect Uri",
      "field": "redirectUri",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Scope",
      "field": "scope",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Authorization Uri",
      "field": "authorizationUri",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Token Uri",
      "field": "tokenUri",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Userinfo Uri",
      "field": "usernfoUri",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Username Attribute Name",
      "field": "usernameAttributeName",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "JWK Set Uri",
      "field": "jwkSetUri",
      "filter": true,
      "width": "150px",
      "editable": "false",
      "text-align": "center",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Modify",
      "field": "modify",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "buttonIcon",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "imgsrc": "", "iconclass": "fas fa-edit", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-primary"], "attribute": "", "styles": "" },
    },
    {
      "header": "Delete",
      "field": "delete",
      "filter": false,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "buttonIcon",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      "button": { "imgsrc": "", "iconclass": "fas fa-trash", "iconPosition": "After", "name": "", "classes": ["btn", "btn-default", "border-0", "lh-1", "p-0", "text-center", "w-100", "text-danger"], "attribute": "", "styles": "" },
    },
    
    
  ];


  projectSecurityGridForModal(rowData?: any, colData?: any) {

    let self = this;

    this.gridData_projectsecuritygrid = {
      columnDef: colData ? colData : this.columnData_projectsecuritygrid,
      rowDef: rowData ? rowData :  this.oauthproviderConfigurationList,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      gridbody_hide: false,
      rowLineSpace: 0,
      multiHeader: false,
      common_search: false,
      common_search_column: "",
      common_filter: false,
      common_filter_column: "",
      validation: this.validationprojectsecuritygrid,
      newPagination: false,
      recordPerPage: 10,
      newExpandExportTotalRecord_hide: undefined,
      ellipsisV: {},
      gridCustomButtonsArr: "",
      cellCustomPadding: NaN,
      sml_expandGrid_position: "bottom",
      totalNoOfRecord_position: "bottom",
      toggleViewButton: false,
      gridConfigrationBtn: false,
      rowAutoSelection: false,
      gridRowAddDeleteButton: false,
      components: {},
      callBack: {
        "onButtonIcon_delete": function (ele, params) {
            self.gridDynamicObj_projectsecuritygrid.deleteRow(params.rowIndex);
            if (self.gridDynamicObj_projectsecuritygrid.sagGridObj
              && self.gridDynamicObj_projectsecuritygrid.sagGridObj.AllRowIndex.length == 0) {
              self.projectSecurityGridForModal([]); 
            }
          
       },

       "onButtonIcon_modify": function (ele, params) {
        
          self.modifyProvider(params);
         
     },

     "onRowClick": function () {
      let selectedClientObj = self.gridDynamicObj_projectsecuritygrid.getSeletedRowData();
      self.securityOauth2ProviderFormGroup.patchValue(selectedClientObj);
    }

      },

      rowCustomHeight: 20,
      plusButton_obj: {},
    };

    let sourceDiv = document.getElementById("projectsecurityoauth2providerGridId");
    this.gridDynamicObj_projectsecuritygrid = SdmtGridT(sourceDiv, this.gridData_projectsecuritygrid, true, true);
  }

  
  setOauthprovider(){
    let gridData = this.gridDynamicObj_projectsecuritygrid.getGridData();
    this.modalRef.close(gridData);
    this.ngOnDestroy();
  }


  formStatus = "view" //edit,add
  modifyRowIndex;

  addProvider(){
     if(!this.securityOauth2ProviderFormGroup.valid){
       alerts("Please fill all required fields");
       this.submittedSecurityProviderForm = true;
       return;
     }
     this.submittedSecurityProviderForm = false;

    let index = this.gridDynamicObj_projectsecuritygrid.sagGridObj.AllRowIndex.length;
    let rawValue = this.securityOauth2ProviderFormGroup.getRawValue();
    this.gridDynamicObj_projectsecuritygrid.addRowByIndex(index, rawValue);

    this.formStatus = 'view'
    this.securityOauth2ProviderFormGroup.disable();
    this.gridDynamicObj_projectsecuritygrid.enableGrid();

    this.gridDynamicObj_projectsecuritygrid.setRowSelected(index);
  }

  editProvider(){
    if(!this.securityOauth2ProviderFormGroup.valid){
      alerts("Please fill all required fields");
      this.submittedSecurityProviderForm = true;
      return;
    }
    this.submittedSecurityProviderForm = false;

    let rawValue = this.securityOauth2ProviderFormGroup.getRawValue();
    this.gridDynamicObj_projectsecuritygrid.updateRow(this.modifyRowIndex, rawValue);

    this.formStatus = 'view'
    this.securityOauth2ProviderFormGroup.disable();
    this.gridDynamicObj_projectsecuritygrid.enableGrid();

    this.gridDynamicObj_projectsecuritygrid.setRowSelected(this.modifyRowIndex);

 }

  resetForm(){
    this.formStatus = 'add';
    this.securityOauth2ProviderFormGroup.enable();
    this.securityOauth2ProviderFormGroup.reset();
     this.gridDynamicObj_projectsecuritygrid.disableGrid();
  }

  modifyProvider(params){
   let selectedRowData =  params.rowValue;
   if(selectedRowData){
    this.formStatus = 'edit';
    this.modifyRowIndex = selectedRowData.sag_G_Index
    this.securityOauth2ProviderFormGroup.enable();
    this.securityOauth2ProviderFormGroup.patchValue(selectedRowData);
    this.gridDynamicObj_projectsecuritygrid.disableGrid();
   }
  
  }

  cancelProvider(){
    this.formStatus = "view";
    this.gridDynamicObj_projectsecuritygrid.enableGrid();
    this.securityOauth2ProviderFormGroup.disable();

    let gridData  = this.gridDynamicObj_projectsecuritygrid.getGridData();

    if (gridData && gridData.length > 0) {
   
      this.securityOauth2ProviderFormGroup.patchValue(JSON.parse(JSON.stringify(gridData[0])));
      this.gridDynamicObj_projectsecuritygrid.setRowSelected(0);
    } else {
    
      this.securityOauth2ProviderFormGroup.reset();
    }

  }

  onClose() {
    this.modalRef.close();
    this.ngOnDestroy();
   }

   ngOnDestroy(): void {
    
  }


}
