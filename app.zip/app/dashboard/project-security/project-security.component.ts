import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { CommonParseService } from 'src/app/services/parseStudio/common-parse.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { DialogService, MessageService, Message } from 'primeng/primeng';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import {TreeNode} from 'primeng/api';
import { ProjectSecuritySelectApiComponent } from './project-security-select-api/project-security-select-api.component';
import { DbcomparetoolService } from 'src/app/services/database/dbcomparetool.service';
import { ProjectSecurityProviderConfigurationComponent } from './project-security-provider-configuration/project-security-provider-configuration.component';
import * as uuid from 'uuid';


declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
declare var _;
declare var ui;
@Component({
  host: { class: 'd-flex flex-column h-100' },
  selector: 'app-project-security',
  templateUrl: './project-security.component.html',
  styleUrls: ['./project-security.component.scss'],
  providers: [MessageService],
  encapsulation: ViewEncapsulation.None
})
export class ProjectSecurityComponent implements OnInit {
 
  msgs: Message[] = [];

  projectStructure = [
    { "key": "frontend_backend_on_single_server", "label": "Frontend & Backend On Single Server" },
    { "key": "frontend_backend_on_different_server", "label": "Frontend & Backend On Different Server" }
  ]
  securityApplyFormGroup: FormGroup;
  publicAndPrivateApiRoleWiseApi ={} 
  publicAndPrivateApiRoleWiseApiDisplay :any
  securityTypeList: any;
  projectAllApiList :any;

  oauthproviderConfigurationList = [];

  constructor(public shareService: SagShareService,
    public dialogService: DialogService,
    private service: AutoJavacodeService,
    private formbuilder: FormBuilder,
    private _dbcomparetoolService: DbcomparetoolService,
    private messageService: MessageService
  ) {
 }
 submittedSecurityFeatureForm :boolean = false;

 isAlreadySecurityApply:boolean = false;

  ngOnInit() {

    this.getSecurityType("stateful");
    this.initializeForm();
    this.setDefaultValue();
    this.getSecurityJson();
    this.getProjectAllApi();
    this.getAllTableList();
     
  }



  initializeForm() {
    this.securityApplyFormGroup = this.formbuilder.group({
      userName: [],
      userId: [],
      projectId: [],
      userwrokspace: [],
      projectname:[],
      projectStructureType: [{ value: 'frontend_backend_on_single_server', disabled: false },[Validators.required]],
      securityType: [{ value: '', disabled: false },[Validators.required]],
      securityTypeCode: [{ value: '', disabled: false }],
      tokenAlgo: [{ value: 'SHA', disabled: false }],
      passwordEncoder: [{ value: 'bcrypt', disabled: false },[Validators.required]],
      sessionManagementAllow: [{ value: 'N', disabled: false }],
      maximumSessions: [{ value: -1, disabled: false }],
      maxSessionsPreventsLogin: [{ value: 'false', disabled: false }],
      customUserTableProvide: [{ value: 'N', disabled: false }],
      publicApiConfigType: [{ value: 'customize', disabled: false }],
      privateApiConfigType: [{ value: 'all_api_secure_except_public', disabled: false }],
      authorizationAllow: [{ value: 'N', disabled: false }],
      roleConfigure: [{ value: '', disabled: false }],
      applicationStateType:[{ value: 'stateful', disabled: false },[Validators.required]]

     })

  }

  setDefaultValue(){
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    if (sessionStoragedatauserId != undefined) {
      this.securityApplyFormGroup.controls["userName"].setValue(sessionStoragedatauserId.data.clientInfo.usrName);
      this.securityApplyFormGroup.controls["userId"].setValue(sessionStoragedatauserId.data.clientInfo.usrId);
    }
    let setProjectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
    if (setProjectInfo != undefined) {
      this.securityApplyFormGroup.controls["projectId"].setValue(setProjectInfo.projectId);
      this.securityApplyFormGroup.controls["projectname"].setValue(setProjectInfo.projectname);
      this.securityApplyFormGroup.controls["userwrokspace"].setValue(setProjectInfo.jwspace);
    }
   
  }
  
  async getProjectAllApi() {
    this.projectAllApiList = [];
    let postData = { 
      "projectPath": this.securityApplyFormGroup.controls["userwrokspace"].value
    }

    this.service.getProjectAllApi(postData).subscribe(res => {
      if (res) {
        this.projectAllApiList = res;
       }
      
    });
  }


  selectPublicApi() {

     let userwrokspace =  this.securityApplyFormGroup.controls["userwrokspace"].value;

     let oldSelectApi = [];
     if(this.publicAndPrivateApiRoleWiseApi && this.publicAndPrivateApiRoleWiseApi["public_api"] &&  this.publicAndPrivateApiRoleWiseApi["public_api"].apiList){
       oldSelectApi = this.publicAndPrivateApiRoleWiseApi["public_api"].apiList;
     }

      const ref = this.dialogService.open(ProjectSecuritySelectApiComponent, {
        header: "Select Public Api",
        width: "100%",
        contentStyle: { "margin-top": "0px", "height": "100%" },
        styleClass: "service_full_model excel-demo-view",
        data: {"userwrokspace":userwrokspace,"buttonLabel":"Set Public Api","oldSelectApi":oldSelectApi,"projectAllApiList":this.projectAllApiList},

      });
      ref.onClose.subscribe((res) => {
        if (res) {
          let obj={
            roleName:"public_api",
            roleDisplayName:"Public Api",
            apiList:res
          }
          this.publicAndPrivateApiRoleWiseApi["public_api"] = obj
          this.setPublicAndPrivateApiRoleWiseApiForDisplay();
        }
      });
     
  }

  selectSecureApi() {

    let userwrokspace =  this.securityApplyFormGroup.controls["userwrokspace"].value;

    let oldSelectApi = [];
    if(this.publicAndPrivateApiRoleWiseApi && this.publicAndPrivateApiRoleWiseApi["secure_api"] &&  this.publicAndPrivateApiRoleWiseApi["secure_api"].apiList){
      oldSelectApi = this.publicAndPrivateApiRoleWiseApi["secure_api"].apiList;
    }

     const ref = this.dialogService.open(ProjectSecuritySelectApiComponent, {
       header: "Select Secure Api",
       width: "100%",
       contentStyle: { "margin-top": "0px", "height": "100%" },
       styleClass: "service_full_model excel-demo-view",
       data: {"userwrokspace":userwrokspace,"buttonLabel":"Set Secure Api","oldSelectApi":oldSelectApi,"projectAllApiList":this.projectAllApiList},

     });
     ref.onClose.subscribe((res) => {
       if (res) {
         let obj={
           roleName:"secure_api",
           roleDisplayName:"Secure Api",
           apiList:res
         }
         this.publicAndPrivateApiRoleWiseApi["secure_api"] = obj
         this.setPublicAndPrivateApiRoleWiseApiForDisplay();
       }
     });
    
 }

 selectRoleWiseApi() {

  let userwrokspace =  this.securityApplyFormGroup.controls["userwrokspace"].value;
  let roleCode =  this.securityApplyFormGroup.controls["roleConfigure"].value;

  if(!roleCode){
    alerts("please select role");
    return ;
  }

  let selectedRole = _.find(this.roleConfigurationModal.roleList, { "roleCode": roleCode });
  if(!selectedRole){
    alerts("Role not found ");
    return ;
  }

  let oldSelectApi = [];
  if(this.publicAndPrivateApiRoleWiseApi && this.publicAndPrivateApiRoleWiseApi[roleCode] &&  this.publicAndPrivateApiRoleWiseApi[roleCode].apiList){
    oldSelectApi = this.publicAndPrivateApiRoleWiseApi[roleCode].apiList;
  }

   const ref = this.dialogService.open(ProjectSecuritySelectApiComponent, {
     header: `Select ${selectedRole.roleName} Api`,
     width: "100%",
     contentStyle: { "margin-top": "0px", "height": "100%" },
     styleClass: "service_full_model excel-demo-view",
     data: {"userwrokspace":userwrokspace,"buttonLabel":`Set ${selectedRole.roleName} Api`,"oldSelectApi":oldSelectApi,"projectAllApiList":this.projectAllApiList},

   });
   ref.onClose.subscribe((res) => {
     if (res) {
       let obj={
         roleName:roleCode,
         roleDisplayName:selectedRole.roleName+" Api",
         apiList:res
       }
       this.publicAndPrivateApiRoleWiseApi[roleCode] = obj
       this.setPublicAndPrivateApiRoleWiseApiForDisplay();
     }
   });
  
}

  setPublicAndPrivateApiRoleWiseApiForDisplay(){
    this.publicAndPrivateApiRoleWiseApiDisplay = [];

    for (let key in this.publicAndPrivateApiRoleWiseApi) {
     let api =  this.publicAndPrivateApiRoleWiseApi[key];
      this.publicAndPrivateApiRoleWiseApiDisplay.push(api);
    }
  }

  deleteSelectApi(item,index){
   
    if (index > -1) { 
      item.apiList.splice(index, 1);
    }
   
  }
 
  

applySecurity() {

    let formObj = this.securityApplyFormGroup.getRawValue();

    if(!this.securityApplyFormGroup.valid){
      this.submittedSecurityFeatureForm = true;
      alerts("Please fill all required fields")
      return;
    }

    this.submittedSecurityFeatureForm = false;

    if(this.publicAndPrivateApiRoleWiseApiDisplay){
      formObj["publicAndPrivateApiRoleWiseApiList"] = this.publicAndPrivateApiRoleWiseApiDisplay
    } else{
      formObj["publicAndPrivateApiRoleWiseApiList"] = []
    }
    
    if(this.roleConfigurationModal){
      formObj["roleConfigurationModal"] = this.roleConfigurationModal
    }  
    if(this.projectAllApiList){
      formObj["projectAllApiList"] = this.projectAllApiList
    }  

    if(this.customTableConfigurationInfo){
      formObj["customTableConfigurationInfo"] = this.customTableConfigurationInfo
    }  
    
    if(this.oauthproviderConfigurationList){
      formObj["oauthproviderConfigurationList"] = this.oauthproviderConfigurationList
    }  

    if(this.roleHierarchyData){
      formObj["roleHierarchyData"] = this.roleHierarchyData
    }
  
    this.service.applySecurity(formObj).subscribe(res => {
      if (res['status'] == 200) {
        this.getSecurityJson();
        success(res['message']);
      } else {
        alerts(res['message']);
      }
    })

  }

 

  getSecurityType(applicationType) {
    this.service.getSecurityType(applicationType).subscribe(res => {
      if(res){
        this.securityTypeList = res;
      }
    })
  }

  getSecurityJson() {
    let projectId =  this.securityApplyFormGroup.controls["projectId"].value;
     this.service.getSecurityJson(projectId).subscribe(res => {
      if(res){
        this.isAlreadySecurityApply = true;
          this.patchSecurityApplyFormGroup(res);
      }
     
    })
  }

 patchSecurityApplyFormGroup(securityFeatureDto){

  this.getSecurityType(securityFeatureDto.applicationStateType);

  this.securityApplyFormGroup.controls["projectStructureType"].setValue(securityFeatureDto.projectStructureType);
  this.securityApplyFormGroup.controls["securityType"].setValue(securityFeatureDto.securityType+"");
  this.securityApplyFormGroup.controls["securityTypeCode"].setValue(securityFeatureDto.securityTypeCode+"");
  this.securityApplyFormGroup.controls["tokenAlgo"].setValue(securityFeatureDto.tokenAlgo);
  this.securityApplyFormGroup.controls["passwordEncoder"].setValue(securityFeatureDto.passwordEncoder);
  this.securityApplyFormGroup.controls["sessionManagementAllow"].setValue(securityFeatureDto.sessionManagementAllow);
  this.securityApplyFormGroup.controls["maximumSessions"].setValue(securityFeatureDto.maximumSessions);
  this.securityApplyFormGroup.controls["maxSessionsPreventsLogin"].setValue(securityFeatureDto.maxSessionsPreventsLogin);

  this.securityApplyFormGroup.controls["customUserTableProvide"].setValue(securityFeatureDto.customUserTableProvide);
  this.securityApplyFormGroup.controls["publicApiConfigType"].setValue(securityFeatureDto.publicApiConfigType);
  this.securityApplyFormGroup.controls["privateApiConfigType"].setValue(securityFeatureDto.privateApiConfigType);
  this.securityApplyFormGroup.controls["authorizationAllow"].setValue(securityFeatureDto.authorizationAllow);
  this.securityApplyFormGroup.controls["roleConfigure"].setValue(securityFeatureDto.roleConfigure);
  this.securityApplyFormGroup.controls["applicationStateType"].setValue(securityFeatureDto.applicationStateType);

  if(securityFeatureDto.publicAndPrivateApiRoleWiseApiList){
    this.publicAndPrivateApiRoleWiseApiDisplay = securityFeatureDto.publicAndPrivateApiRoleWiseApiList;

    securityFeatureDto.publicAndPrivateApiRoleWiseApiList.forEach(element => {
      this.publicAndPrivateApiRoleWiseApi[element['roleName']] = element 
    });
  }
  if(securityFeatureDto.roleConfigurationModal){
    this.roleConfigurationModal = securityFeatureDto.roleConfigurationModal;
     if('already_created' == this.roleConfigurationModal.roleTable){
       this.onChangeRoleTableName(this.roleConfigurationModal.roleTableName,false);
     }
  }

  if(securityFeatureDto.oauthproviderConfigurationList){
    this.oauthproviderConfigurationList = securityFeatureDto.oauthproviderConfigurationList;
   }

   if(securityFeatureDto.roleHierarchyData){
    this.roleHierarchyData = securityFeatureDto.roleHierarchyData;
   }
 
  if(securityFeatureDto.customTableConfigurationInfo){
    this.customTableConfigurationInfo = securityFeatureDto.customTableConfigurationInfo;
    if(this.customTableConfigurationInfo.tableName){
      this.onChangeUserCredintialTableName(this.customTableConfigurationInfo.tableName,false);
    }
  }

 }
 
 onChangeSecurityType(securityType){
  let item = _.find(this.securityTypeList, { "sec_type_id": securityType });
  if(item){
    this.securityApplyFormGroup.controls["securityTypeCode"].setValue(item.sec_type_code);
  }

}




/**************************ROLE CONFIGURATION******************************************* */

roleConfigurationModal = {
"roleTable" :"no_created",

"roleList" : [],
"roleTableName":"",
"roleNameColumn":"",
"roleCodeColumn":"",
"roleTableColumnInfo":[]

}

openRoleConfigurationModal(){
 if(!this.roleConfigurationModal.roleList || this.roleConfigurationModal.roleList.length == 0 ){
  this.roleConfigurationModal.roleList = [] 
 }
 
  $('#roleConfigurationModal').modal('show');
}

closeRoleConfigurationModal(){
  $('#roleConfigurationModal').modal('hide');
}

addRoleInRoleConfiguration(){
  this.roleConfigurationModal.roleList.push({
    "roleName":"",
    "roleCode":"",
    "row_index":this.roleConfigurationModal.roleList.length +1
  });
}

deleteRoleInRoleConfiguration(roleList,index){
  if (index > -1) { 
    let roleInfo = roleList[index];
    delete this.publicAndPrivateApiRoleWiseApi[roleInfo.roleCode];
    this.setPublicAndPrivateApiRoleWiseApiForDisplay();

    roleList.splice(index, 1);
  }
}

async removeSecurity(){
 
  if (await ui.confirm("Do You Want To Remove Security ? ")) {
     
    let reqObj = {
        userId:  this.securityApplyFormGroup.controls["userId"].value,
        projectId:  this.securityApplyFormGroup.controls["projectId"].value,
        userwrokspace: this.securityApplyFormGroup.controls["userwrokspace"].value
  }
 
    this.service.removeSecurity(reqObj).subscribe(res => {
      if (res['status'] == 200) {
        success(res['message']);
      } else {
        alerts(res["message"]);
      }
    
   })
  }
 
}

onChangeAuthorizationAllowType(value){
 if("N" == value){

  this.publicAndPrivateApiRoleWiseApiDisplay.forEach(element => {
    if("secure_api" != element.roleName && "public_api" != element.roleName){
      delete this.publicAndPrivateApiRoleWiseApi[element.roleName];
    }
 });
  this.setPublicAndPrivateApiRoleWiseApiForDisplay();
 }
}

onChangeRoleTableType(){
  this.roleConfigurationModal.roleList = [];
}

/****************TABLE INFO******************** */

allTableList = [];
tableListDropdownList = [];
roleTableFieldDropdownList = [];

getAllTableList() {
  
  this.tableListDropdownList = [];
  this.allTableList = [];

  let dbData = {
    "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
    "targetDataSource": {},
    "operation": "COMPARESINGLE",
    "connectionRoleType": "admin",
  }
  this._dbcomparetoolService.tblstrcturedrpdown(dbData).subscribe((res) => {
    if (res) {
      let masterdropdown = res['masterdropdown'];
      let mtbllist = masterdropdown.mtbllist.sort();
      this.allTableList = masterdropdown.mtbllist.sort();
      this.getTableDropdownName(mtbllist);
      
      
    }
  }, Error => {
    alerts("Error While Fetching data");
  });
}

getTableDropdownName(mtbllist) {
  this.tableListDropdownList = [];
  mtbllist.forEach(table => {
    let obj = {
      "value": table,
      "label": table
    }
    this.tableListDropdownList.push(obj);
  });
  
}



onChangeRoleTableName(tableName,isDataClear) {

  if (tableName) {
     if(isDataClear){
      this.roleConfigurationModal.roleNameColumn = "",
      this.roleConfigurationModal.roleCodeColumn = "",
      this.roleConfigurationModal.roleTableColumnInfo = []
       this.roleClear();
     }

    let dbData = {
      "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
      "targetDataSource": {},
      "operation": "COMPARESINGLE",
      "connectionRoleType": "admin",
      "dbtype": "master",
      "tableName": tableName
    }
    this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
      if (res) {
        this.setTableFieldDropdown(res, tableName);
      }
    }, Error => {
      alerts("Error While Fetching data");
    });
  }

}

roleClear(){
  this.roleConfigurationModal.roleList = [];
  this.onChangeAuthorizationAllowType('N');

}

  setTableFieldDropdown(res,tableName) {
    this.roleTableFieldDropdownList = [];;

    let tableFieldsInfo = this.getTableInfoWithCustomKeys(res, tableName);
    this.roleConfigurationModal.roleTableColumnInfo = tableFieldsInfo;

    tableFieldsInfo.forEach(tableColumn => {

      let obj = {
        "value": tableColumn['columnName'],
        "label": tableColumn['columnName']
      }
      this.roleTableFieldDropdownList.push(obj);
    });

  }

  getTableInfoWithCustomKeys(res, tableName) {
    let tableFields = [];
  
    if (res) {
      res.forEach(tableColumn => {
        let tableFieldInfo = {};
        tableFieldInfo['columnName'] = tableColumn['name'];
        tableFieldInfo['pkey'] = tableColumn['pkey'];
        tableFieldInfo['fkey'] = tableColumn['fkey'];
        tableFieldInfo['dataType'] = tableColumn['type'];
        tableFieldInfo['entityColumn'] = tableColumn['entitylabel'];
        tableFieldInfo['tableName'] = tableName;
  
        tableFieldInfo['parentTable'] = tableColumn['parenttbl'];
        tableFieldInfo['dbColumnSize'] = tableColumn['size'];
        tableFieldInfo['uniquecol'] = tableColumn['uniquecol'];
        tableFieldInfo['entityName'] = tableColumn['entityName'];
        tableFieldInfo['pkeyName'] = tableColumn['pkeyName'];
  
        tableFields.push(tableFieldInfo);
      });
    }
    return tableFields;
  }

  getTableDataForMasterMapping(){

    let tableName = this.roleConfigurationModal.roleTableName

    if (tableName && this.roleConfigurationModal.roleNameColumn && this.roleConfigurationModal.roleCodeColumn) {
    
      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName,
        "details": {
          "columns": [],
          "software": [],
          "year": [],
          "client": [],
          "operation": "",
          "limitRows": "null"
      },
      }
      this._dbcomparetoolService.getAllTabTableData(dbData).subscribe((res) => {
        if (res) {
          this.setRoleData(res);
         
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }
    }

  setRoleData(res) {
    if (res) {
      let gridarray = res.gridarray;
      if (gridarray) {
        gridarray.forEach(element => {
          let obj = {
            "roleName": element[this.roleConfigurationModal.roleNameColumn],
            "roleCode": element[this.roleConfigurationModal.roleCodeColumn],
            "row_index": this.roleConfigurationModal.roleList.length + 1

          }
          this.roleConfigurationModal.roleList.push(obj);
        });
      }
    }
  }



  /**************** Custom Configuration Table ********************************** */

 customTableColumnList = [];


  customTableConfigurationInfo = {
    "tableName": "",
    "tableColumnInfo": [],
    "userCredentialColumnList": [
      { row_index: 1, "userCredentialColumnName": "username", "userCredentialColumnDisplayName": "Username", "customTableColumnName": "" },
      { row_index: 2, "userCredentialColumnName": "password", "userCredentialColumnDisplayName": "Password", "customTableColumnName": "" },
      { row_index: 3, "userCredentialColumnName": "email", "userCredentialColumnDisplayName": "Email", "customTableColumnName": "" },
      { row_index: 4, "userCredentialColumnName": "role", "userCredentialColumnDisplayName": "Role", "customTableColumnName": "" },
      { row_index: 5, "userCredentialColumnName": "accountNonExpired", "userCredentialColumnDisplayName": "Account Non Expired", "customTableColumnName": "" },
      { row_index: 6, "userCredentialColumnName": "accountNonLocked", "userCredentialColumnDisplayName": "Account Non Locked", "customTableColumnName": "" },
      { row_index: 7, "userCredentialColumnName": "credentialsNonExpired", "userCredentialColumnDisplayName": "Credentials Non Expired", "customTableColumnName": "" },
      { row_index: 8, "userCredentialColumnName": "enabled", "userCredentialColumnDisplayName": "Enabled", "customTableColumnName": "" },
      { row_index: 9, "userCredentialColumnName": "providerName", "userCredentialColumnDisplayName": "Provider Name", "customTableColumnName": "" },
   ]
  };

  
  openCustomTableConfigurationModal(){
    $('#customTableConfigurationModal').modal('show');
    let securityTypeCode =  this.securityApplyFormGroup.controls["securityTypeCode"].value;

    if("oauth2_login" != securityTypeCode){
      this.customTableConfigurationInfo.userCredentialColumnList.splice(8,1);
    } else{
     let find =  _.find(this.customTableConfigurationInfo.userCredentialColumnList,{userCredentialColumnName:'providerName'});
     if(find){
      this.customTableConfigurationInfo.userCredentialColumnList.push(
        { row_index: 9, "userCredentialColumnName": "providerName", "userCredentialColumnDisplayName": "Provider Name", "customTableColumnName": "" }
      )
     }

    }
   }
  
  closeCustomTableConfigurationModal(){
    $('#customTableConfigurationModal').modal('hide');
  }
  
  onChangeUserCredintialTableName(tableName,isDataClear) {

    if (tableName) {
       if(isDataClear){
          this.clearUserCredintialTableData(tableName);
       }
  
      let dbData = {
        "srcDataSource": this.shareService.getDatadbtool("finalDataForConnection") ? this.shareService.getDatadbtool("finalDataForConnection").srcDataSource : false,
        "targetDataSource": {},
        "operation": "COMPARESINGLE",
        "connectionRoleType": "admin",
        "dbtype": "master",
        "tableName": tableName
      }
      this._dbcomparetoolService.setTableMappingJson(dbData).subscribe((res) => {
        if (res) {
          this.setTableFieldDropdownForUserCredential(res, tableName);
        }
      }, Error => {
        alerts("Error While Fetching data");
      });
    }
  
  }
  

  setTableFieldDropdownForUserCredential(res,tableName) {
    this.customTableColumnList = [];;

    let tableFieldsInfo = this.getTableInfoWithCustomKeys(res, tableName);
    this.customTableConfigurationInfo.tableColumnInfo = tableFieldsInfo;

    tableFieldsInfo.forEach(tableColumn => {

      let obj = {
        "value": tableColumn['columnName'],
        "label": tableColumn['columnName']
      }
      this.customTableColumnList.push(obj);
    });

  }


  clearUserCredintialTableData(tableName){
    this.customTableConfigurationInfo = {
      "tableName": tableName,
      "tableColumnInfo": [],
      "userCredentialColumnList": [
        { row_index: 1, "userCredentialColumnName": "username", "userCredentialColumnDisplayName": "Username", "customTableColumnName": "" },
        { row_index: 2, "userCredentialColumnName": "password", "userCredentialColumnDisplayName": "Password", "customTableColumnName": "" },
        { row_index: 3, "userCredentialColumnName": "email", "userCredentialColumnDisplayName": "Email", "customTableColumnName": "" },
        { row_index: 4, "userCredentialColumnName": "role", "userCredentialColumnDisplayName": "Role", "customTableColumnName": "" },
        { row_index: 5, "userCredentialColumnName": "accountNonExpired", "userCredentialColumnDisplayName": "Account Non Expired", "customTableColumnName": "" },
        { row_index: 6, "userCredentialColumnName": "accountNonLocked", "userCredentialColumnDisplayName": "Account Non Locked", "customTableColumnName": "" },
        { row_index: 7, "userCredentialColumnName": "credentialsNonExpired", "userCredentialColumnDisplayName": "Credentials Non Expired", "customTableColumnName": "" },
        { row_index: 8, "userCredentialColumnName": "enabled", "userCredentialColumnDisplayName": "Enabled", "customTableColumnName": "" },
        { row_index: 9, "userCredentialColumnName": "providerName", "userCredentialColumnDisplayName": "Provider Name", "customTableColumnName": "" },
      ]
    }
  }

  onChangeProjectStructure(){
    let projectStructureType =  this.securityApplyFormGroup.controls['projectStructureType'].value;
   let applicationStateType =  this.securityApplyFormGroup.controls['applicationStateType'].value;

   if("frontend_backend_on_different_server" == projectStructureType && 'stateful' == applicationStateType){
    this.showWarnForStatelessApplication();
   }

  }

  onChangeApplicationType(){
   let projectStructureType =  this.securityApplyFormGroup.controls['projectStructureType'].value;
   let applicationStateType =  this.securityApplyFormGroup.controls['applicationStateType'].value;

   if("frontend_backend_on_different_server" == projectStructureType && 'stateful' == applicationStateType){
    this.showWarnForStatelessApplication();
   }

   if('stateless' == applicationStateType){
    this.securityApplyFormGroup.controls['sessionManagementAllow'].setValue('N');
   }
    
   this.getSecurityType(applicationStateType);

  }
  showWarnForStatelessApplication() {
    this.msgs = [];
    this.msgs.push({ severity: 'warn', summary: '',
     detail: 'Session state is not synchronized between backend and frontend servers. Ensure proper session management, such as using shared session storage ' });
  }


  onClickAddOauth2Provider(){
    
    this.openOaauth2ProviderConfiguration();
  }

  closeOuth2providerConfigurationModal(){
    $('#outh2providerConfigurationModal').modal('hide');
  }
  

  openOaauth2ProviderConfiguration(){
      
      const ref = this.dialogService.open(ProjectSecurityProviderConfigurationComponent, {
        header: "Oauth2 Provider Configuration",
        width: "100%",
        contentStyle: { "margin-top": "0px", "height": "100%" },
        styleClass: "service_full_model excel-demo-view",
        data: {"oauthproviderConfigurationList" : this.oauthproviderConfigurationList},

      });
      ref.onClose.subscribe((res) => {
        if (res) {
          this.oauthproviderConfigurationList = res;
        }
      });
  }


/************ROLE CHART*************** */

roleHierarchyData : TreeNode[] = [{
  label: '',
  type: 'role',
  styleClass: 'ui-person',
  expanded: true,
  data: {},
  children: [],
  'key':uuid.v4()
}];

selectedNode: TreeNode;

openRoleChartModal(){
   $('#roleChartModal').modal('show');

   if(!this.roleHierarchyData  || this.roleHierarchyData.length == 0){
    this.roleHierarchyData   = [{
      label: '',
      type: 'role',
      styleClass: 'ui-person',
      expanded: true,
      data: {},
      children: [],
      'key':uuid.v4()
    }];
   }
 }

 onClickAddRoleHeraricy(event){
   event.children.push({
    label: '',
    type: 'role',
    styleClass: 'ui-person',
    expanded: true,
    data: {},
    children: [],
    'key':uuid.v4()
  });
  }

  onClickRemoveRoleHeraricy(event){
    this.removeRecursion(event.key ,this.roleHierarchyData);
   }

   removeRecursion(uniqeId,array){ 
    for (let index = 0; index < array.length; index++) { 
      const element = array[index];
     
      if(element.key == uniqeId){
        array.splice(index, 1)
        break;
      } else if (element.children){
        this.removeRecursion(uniqeId,element.children);
       }
      
    }

   }


 onNodeSelect(event) {
 // this.messageService.add({severity: 'success', summary: 'Node Selected', detail: event.node.label});
 }
 
 closeroleChartModal(){
   $('#roleChartModal').modal('hide');
 }

}

