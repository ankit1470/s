import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NewupdateRoutingModule } from './newupdate-routing.module';
import { NewupdateComponent } from './newupdate.component';


@NgModule({
  declarations: [NewupdateComponent],
  imports: [
    CommonModule,
    NewupdateRoutingModule
  ],
  exports:[NewupdateComponent]
  
})
export class NewupdateModule { }
