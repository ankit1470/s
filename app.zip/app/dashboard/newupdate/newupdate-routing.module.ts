import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewupdateComponent } from './newupdate.component';


const routes: Routes = [
  {
    path:"",
    component:NewupdateComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NewupdateRoutingModule { }
