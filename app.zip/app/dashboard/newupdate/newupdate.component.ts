import { Component, OnInit } from '@angular/core';
import { DynamicDialogRef } from 'primeng/primeng';

@Component({
  selector: 'app-newupdate',
  templateUrl: './newupdate.component.html',
  styleUrls: ['./newupdate.component.scss']
})
export class NewupdateComponent implements OnInit {

  constructor(
    public modalRef: DynamicDialogRef,
  ) {
    
   }

  ngOnInit() {
  }

  closeNewupdateModel() {
    this.modalRef.close();
    if (document.querySelector(".close_newupdate")) {
      document.querySelector(".close_newupdate").closest("p-dynamicdialog").remove();
    }

  }

}
