import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DialogService, DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';

import { ToastService } from 'src/app/core/services/toast.service';
import { GitSvnComponent } from '../projectConfig/git-svn/git-svn.component';
import { ProcomparetoolFirststepService } from 'src/app/services/project-utility-tool/procomparetool-firststep.service';
import { VersionControlMappingComponent } from '../version-control-mapping/version-control-mapping.component';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
// this is sag grid declaration
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
@Component({
  host: {
    class: 'd-flex flex-column h-100'
  },
  selector: 'app-choose-project',
  templateUrl: './choose-project.component.html',
  styleUrls: ['./choose-project.component.scss'],
  providers: [DialogService]
})


export class ChooseProjectComponent implements OnInit {
  getprjFromStepper:any
  getDefaultProj: any
  showSetDefaultButton: boolean
  setAngularButtonDisplay: boolean = false;
  UpdateButtonDisplay: boolean = false;
  saveProjectButtonDisplay: boolean = false;
  getUserWiseLocalProjectPathResponce: any;
  gridDynamicForChooseProject: any;
  saveUserWiseLocalProjectPathresponce: any;
  getAllProjects: any;
  ChooseProjectForm: any;
  getDataJson: any;
  getSaveJson: any;
  getSaveProjectJson: any;
  responceFileContect: any;
  isDisabled: boolean = true;
  isProjectOnlineFlag:boolean = false;
  constructor(public _sagStudioService: SagStudioService,
    private dbcomparetoolService: ProcomparetoolService,
    private shareService: SagShareService,
    private formbuilder: FormBuilder,
    public dialogService: DialogService,
    public modalRef: DynamicDialogRef,
    public toast: ToastService,
    public firststepProjectService: ProcomparetoolFirststepService,
    public config: DynamicDialogConfig,
    public commonStudioDragDropservice: CommonStudioDragDropService
  ) {

  }

  ngOnInit() {
    this.isProjectOnline();
    this.getAllProjectFrontBackend();
    this.initializeForm();
    if (this.config.data && this.config.data.skipLoading && this._sagStudioService.selectedProjectData) {
      this.getLocalProject(true);
    } else {

      this.shareService.addPrjFromStepper.subscribe(user => this.getprjFromStepper = user)
      this.getUserWiseLocalProjectPath();
    }
    this.commonStudioDragDropservice.onlyReadRightsOnfiles = [];

 this.getControlsListOfFileId()
  }
  isProjectOnline(){
    this.dbcomparetoolService.isProjectOnline().subscribe(
      (response: any) => {
        this.isProjectOnlineFlag = response['isOnline'];
      },
    );
  }
  getControlsListOfFileId(){
    this.shareService.filesUsedInIndexhtml().subscribe((res)=>{
      this._sagStudioService.fileCodeListOfControlsResp =  res
   })
  }

  /**
  * Initializing form here
  */
  initializeForm() {
    this.ChooseProjectForm = this.formbuilder.group({
      projectName: ""
    })
  }
  getUserWorkSpacePath() {
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'));
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId
    let selectedObjPro = this.gridDynamicForChooseProject.getSeletedRowData();

    if(selectedObjPro.awspace || selectedObjPro.jwspace){
      this.gitSvnChackOutClone();
    }else{
      this.dbcomparetoolService.getUserWorkSpacePath(userid,selectedObjPro.projectId,sessionStoragedata.username).subscribe(
        (response: any) => {
         if(response.status == 200){
          this.gridDynamicForChooseProject.updateCell(selectedObjPro['sag_G_Index'], "jwspace",response.javaWorkspace);
          this.gridDynamicForChooseProject.updateCell(selectedObjPro['sag_G_Index'], "awspace",response.angWorkspace);
        }
        this.gitSvnChackOutClone();
        },
        err => {
          this.gitSvnChackOutClone();
        }
      );
    }
  };

  gitSvnChackOutClone(){
    let selectedObj = this.gridDynamicForChooseProject.getSeletedRowData();
    if (((selectedObj.awspace != null || selectedObj.jwspace != null) && (selectedObj.awspace != '' || selectedObj.jwspace != '') &&
      (selectedObj.awspace != null || selectedObj.jwspace != '') && (selectedObj.awspace != '' || selectedObj.jwspace != '') && (selectedObj.awspace != selectedObj.jwspace))) {
      this.setPathButtonClick();
      const ref = this.dialogService.open(GitSvnComponent, {
        header: 'Import Project',
        width: '40%',
        contentStyle: { "height": "316px" },
        data: { rowdata: this.shareService.getDataprotool("selectedProjectChooseData") }
      });
      ref.onClose.subscribe((res) => {
        console.info(res);
      });
    } else if ((selectedObj.awspace == selectedObj.jwspace)
      && (selectedObj.awspace != '' || selectedObj.jwspace != '')
      && (selectedObj.awspace != null || selectedObj.jwspace != null)) {
      alerts("Frontend & Backend path can't be same..!!");
    }
    else {
      alerts("Please Specify At Least One  Path..!");
    }
  }
  async GitCloneNewProj() {
    let selectedObj = this.gridDynamicForChooseProject.getSeletedRowData();
    if (((selectedObj.awspace != null || selectedObj.jwspace != null) && (selectedObj.awspace != '' || selectedObj.jwspace != '') &&
      (selectedObj.awspace != null || selectedObj.jwspace != '') && (selectedObj.awspace != '' || selectedObj.jwspace != '') && (selectedObj.awspace != selectedObj.jwspace))) {
      await this.setPathButtonClick();
      const ref = this.dialogService.open(GitSvnComponent, {
        header: 'Import Project',
        width: '40%',
        contentStyle: { "height": "316px" },
        data: { rowdata: this.shareService.getDataprotool("selectedProjectChooseData") }
      });
      ref.onClose.subscribe((res) => {
        console.info(res)
      });
    } else if ((selectedObj.awspace == selectedObj.jwspace)
      && (selectedObj.awspace != '' || selectedObj.jwspace != '')
      && (selectedObj.awspace != null || selectedObj.jwspace != null)) {
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `Frontend & Backend path can't be same..!!`,
      });
    }
    else {
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: "Please Specify At Least One  Path..!"
      });
    }
  };


  // ===============create Project ================
  getAllProjectFrontBackend() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId
    this.shareService.loading++;
    this.dbcomparetoolService.AllProjectFrontBackend(userid).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response) {
          this.getAllProjects = response["data"];
        }
      },
      err => {
        this.shareService.loading--;
      }
    );

  }

  getUserWiseLocalProjectPath() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
      (response: any) => {
        if (response) {
          this.getUserWiseLocalProjectPathResponce = response['data']
          if(this.getprjFromStepper.length !=0){
            this.SagGridChooseProj(this.getprjFromStepper)
          }else{
            this.SagGridChooseProj(this.getUserWiseLocalProjectPathResponce)
            this.shareService.setDataprotool("getUserWiseLocalProjectPathResponce", response['data']);
          }
        }
      }
    );
  }
  async getLocalProject(setDefault?) {
  
    await this.setPathButtonClick(setDefault);
    this.shareService.setDataprotool('modeTreeData', []);
    this.shareService.setDataprotool('lockUnlockData', []);
    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
   
    if (window['angularComponentRef'].setProjectAlldetails) {
      const callFun = window['angularComponentRef'].setProjectAlldetails;
      callFun(selectedObj);
    }
    this.getDefaultProj = this.shareService.getDataprotool("selectedProjectChooseData")
    if (selectedObj) {
      const postData = {
        destpath: selectedObj.awspace,
        projectname: selectedObj.projectname,
      }
      this.shareService.loading++;
      const resSagStudioJson = await this.dbcomparetoolService.loadProjectJson(postData).toPromise();
      this.shareService.setData('ctrlopType',resSagStudioJson[0]['projectList'][0]['ctrlsOptType'])
      this.shareService.loading--;
      // this._sagStudioService.projectExploralFileList = resSagStudioJson
      this._sagStudioService.sagWorkSpace = resSagStudioJson[0];
  
  

      if (this._sagStudioService.sagWorkSpace && this._sagStudioService.sagWorkSpace !== undefined) {
        this.getDbConnObj(selectedObj.awspace + `/prjconn.json`);
        await this.getPrjConfObj(selectedObj.projectId);
        await this.projectPathReplaceProjectWise()
        this.getpStylesScss();
        this.getFontFamily(selectedObj.awspace);
        this.shareService.setDataprotool('UIBuilder', 'true');
        localStorage.setItem('UIBuilder', 'true');
      } else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Something went Wrong !!!',
        });
      }
   
      this.shareService.propertyWindowJsonData().subscribe(jsonData => {
        this._sagStudioService.propertyWindowJson = jsonData["data"];
      })
      if(window['angularComponentRef'].generateJSON){
        window['angularComponentRef'].generateJSON();
      }
      /** save through normal save button **/
      this._sagStudioService.saveThroughLanguage = false;
    }

    if(this.getDefaultProj && this.getDefaultProj.projectId){
      let getResData;
      let obj={
        "projectId":this.getDefaultProj.projectId
      }
       this.shareService.getUsedCssJsProject(obj).subscribe(getRes=>{
        getResData = getRes
        if(getResData && getResData != undefined && getResData != null){
          let recordListOfIndex = {
            "css":[],
            "js":[],
            "projectId":this.getDefaultProj.projectId
          };
          for(let res = 0; res<getResData.length;res++){
            if(getResData[res].type == 'CSS'){
              let cssObj={
                "fileCode":getResData[res].fileCode,
                "count":getResData[res].fileCount,
                // "usedFileJson":getResData[res].usedFileJson
              }
              recordListOfIndex["css"].push(cssObj);
            }
            if(getResData[res].type == 'JS'){
              let jsObj={
                "fileCode":getResData[res].fileCode,
                "count":getResData[res].fileCount,
                // "usedFileJson":getResData[res].usedFileJson
              }
              recordListOfIndex["js"].push(jsObj);
            }
          }
          this._sagStudioService.recondForIndexFile = recordListOfIndex;
        }
      })
     }
    this._sagStudioService.getImagesFromJsonFile()
  }
  
  // ==============================pankaj singh==============================================
  projectPathReplaceProjectWise() {
    const ProjectPath = this.shareService.getDataprotool("selectedProjectChooseData");
    const reqObj = {
      javaworkspace: ProjectPath.jwspace,
      angworkspace: ProjectPath.awspace,
    }
    this.shareService.loading++;
    this.dbcomparetoolService.projectPathReplace(reqObj).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response['status'] == 200) {
        }
        else if (response['status'] == 500) {
          alerts(response.msg);
        }
      }, error => {
      }
    );
  }
  close(res) {
    this.modalRef.close(res);
  }

  forkJoinParams = []
  recursiveFun(getJsonDataRec, projName, projPath) {
    let self = this;
    getJsonDataRec.forEach((element) => {
      if (element.children.length > 0) {
        element['pLocalPath'] = `${projPath}/${element.projectPath}`;
        const param = {
          projectId: projName,
          fileId: element['matchableId'],
        }
        self.forkJoinParams.push(this.dbcomparetoolService.GetsaveJsonData(param));
        self.recursiveFun(element.children, projName, projPath);
      }
      else {
        element['pLocalPath'] = `${projPath}/${element.projectPath}`;
        const param = {
          projectId: projName,
          fileId: element['matchableId'],
        }
        self.forkJoinParams.push(this.dbcomparetoolService.GetsaveJsonData(param));
      }
    });

  }

  saveUserWiseLocalProjectPath() {
    let selectedObj = this.gridDynamicForChooseProject.getSeletedRowData();
    let posttdata = { data: [selectedObj] };
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.saveUserWiseLocalProjectPath(userId, posttdata).subscribe(
      (response: any) => {
        if (response['status'] == 200) {
          this.toast.launch_toast({
            type: 'success',
            position: 'bottom-right',
            message: 'Successfully Updated !!!',
          });
          this.getUserWiseLocalProjectPath();
          this.saveUserWiseLocalProjectPathresponce = response['data']
          // this.shareService.setDataprotool("getProgrammersNameListData", response["result"]);
        }
        else if (response['status'] == 406) {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: response['message'],
          });
        }
      }
    );
  }

  // parse from project api call
  parsefromprojectClick() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.setPathButtonClick();
    const ProjectDataJsonId = this.shareService.getDataprotool("selectedProjectChooseData");
    this.dbcomparetoolService.getTreeData(userid, ProjectDataJsonId.projectId).subscribe(
      (response: any) => {
        if (response) {
          this.getDataJson = response.angularProject.data;
          this.recursivepparseFun(this.getDataJson);
        }
      },
      (err) => {
        console.error('err response');
      }
    );
    // this._sagStudioService.resetFileList();
    // this._sagStudioService.getFilesList(this._sagStudioService.sagWorkSpace.projectExplorerTree);
  }
  parseForkJoin = [];
  recursivepparseFun(getDataparseJson) {
    const ProjectDataJsonId = this.shareService.getDataprotool("selectedProjectChooseData");
    let self = this;
    if (getDataparseJson && getDataparseJson.length > 0) {
      getDataparseJson.forEach(element => {
        console.log(element)
      });
    }
    console.log(getDataparseJson)


  }


  // ===========================Grid start============================================
  SagGridChooseProj(rowsData) {
    const sourceDiv = document.getElementById("projectconfiguracionGridId");
    const columns = [
      {
        "header": "S.No",
        "field": "sno",
        "filter": true,
        "width": "60px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",

      },
      {
        "header": "Project Name",
        "field": "projectname",
        "filter": true,
        "width": "450px",
        "editable": "false",
        "textalign": "center",
        "search": true,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",
        //"component":"textInputObj",

      },
      {
        "header": "Backend Path",
        "field": "jwspace",
        "filter": true,
        "width": "350px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",
        "component": "textInputObj1",

      },
      {
        "header": "Frontend Path",
        "field": "awspace",
        "filter": true,
        "width": "350px",
        "editable": "false",
        "textalign": "center",
        "search": false,
        "ngclick": "selectRowImport($event)",
        "ngdblclick": "selectRowImportDblClick($event)",
        "component": "textInputObj2",

      },
    ];
    let self = this;
    let components = {
      "textInputObj1": new SagInputText({}, function () {
      }),
      "textInputObj2": new SagInputText({}, function () {
      }),
      // "backendSettingChange": new ButtonComponent({
      //   "visibility": true, buttonValue: 'Change', classes: ['btn', 'btn-primary'],
      //   styles: { 'width': '70px', 'padding': '0px !important', 'font-size': '11px !important', 'margin-left': '36px' }
      // }, function (ele, params) {
      //   ele.onclick = function (evnt) { }
      // }),
      // "frontendSettingChange": new ButtonComponent({
      //   "visibility": true, buttonValue: 'Change', classes: ['btn', 'btn-primary'],
      //   styles: { 'width': '70px', 'padding': '0px !important', 'font-size': '11px !important', 'margin-left': '36px' }
      // }, function (ele, params) {
      //   ele.onclick = function (evnt) {
      //   }
      // }),

    };


    var SagGridRowStatus = rowsData;
    for (var i = 0; i < SagGridRowStatus.length; i++) {
      SagGridRowStatus[i]["sno"] = i + 1;
    }

    if (undefined != sourceDiv) {


      var gridData = {
        columnDef: columns,
        rowDef: SagGridRowStatus,
        menu: { fontFamily: true, fontSize: true, underline: true, left: true, center: true, right: true, selectionType: true, columnDraggable: true },
        selection: "row",
        components: components,
        clientSidePagging: true,
        recordPerPage: 20,
        recordNo: true,
        RowCustomHeight: 40,
        callBack: {
          "onRowClick": function () {
            let rawInd = self.gridDynamicForChooseProject.selectedCellData.rowIndex;
            let selectedProject = self.getUserWiseLocalProjectPathResponce[rawInd];
            self.getDefaultProj = JSON.parse(JSON.stringify(self._sagStudioService.selectedProjectData))
            if (selectedProject['projectname'] == self.getDefaultProj['projectname']) {
              self.showSetDefaultButton = true;

            }
            else {
              self.showSetDefaultButton = false;

            }
            if (((selectedProject.awspace != "") || (selectedProject.jwspace != ""))
              && ((selectedProject.awspace != null) || (selectedProject.jwspace != null))
              && ((selectedProject.awspace != "") || (selectedProject.jwspace != null))
              && ((selectedProject.awspace != null) || (selectedProject.jwspace != ""))) {
              self.isDisabled = false;
            } else {
              self.isDisabled = true;
            }

          },
          "onRowDbleClick": function () {

          },
          "onCellClick": function (event) {
          }
        },
        rowCustomHeight: 40,
          header: {
          style: {"background-color":"#ffffff","border":"1px solid #ffffff","text-shadow":"0px 0px 0px #ffffff","color":"#000000","font-weight":"700","float":"none","text-align":"left"},
          filter: false,
          },
          totalNoOfRecord_hide: true,
          sml_expandGrid_hide: true,
          exportXlsxPage_hide: true,
          exportXlsxAllPage_hide: true,
          exportPDFLandscape_hide: true,
          exportPDFPortrait_hide: true,
          ariaHidden_hide: true,
          dragDropCol_hide: true,
          footer_hide: true,
          disableAllSearch: false,
          wordBreak: false,
          wordBreakHeader: false,
          rowBorder_hide: false,
          columnBorder_hide: true,
          header_hide: false,
          common_search: false,
          common_search_column: "",
          gridbody_hide: false,
          rowLineSpace: 0,
      };
      this.gridDynamicForChooseProject = SagGridMPT(sourceDiv, gridData, true, true);
      if(this.isProjectOnlineFlag){
        this.gridDynamicForChooseProject.disableColumn("jwspace");
        this.gridDynamicForChooseProject.disableColumn("awspace");
      }
      return this.gridDynamicForChooseProject;

    }


  }

  // onCellSelectFn(event) {
  //   if (true) {
  //     let self = this;
  //     let rowIndex = Number(self.gridDynamicForChooseProject.getSeletedCellData().rowIndex);
  //     let column = self.gridDynamicForChooseProject.getSeletedCellData().field;
  //     let rowData = self.gridDynamicForChooseProject.getRowData(rowIndex);
  //     let cellData = self.gridDynamicForChooseProject.getSeletedCellData();
  //     let allColsArray = self.gridDynamicForChooseProject.sagGridObj.colData;
  //     //---Adding validators in tblStructure Tab
  //     if (column == 'javabutton') {
  //       this.backendSetting(rowData, cellData, rowIndex)
  //     } else if (column == 'angularbutton') {
  //       this.frontendSetting(rowData, cellData, rowIndex)
  //     }
  //   }
  // }

  // frontendSetting(rowData, cellData, rowIndex) {
  //   const ref = this.dialogService.open(FrontEndConfigComponent, {
  //     header: 'FrontEnd',
  //     width: '60%',
  //     contentStyle: { "height": "500px" },
  //     data: { rowDataElment: rowData }
  //   });
  //   ref.onClose.subscribe((res) => {

  //   });
  // }

  // backendSetting(rowData, cellData, rowIndex) {
  //   const ref = this.dialogService.open(BackEndConfigComponent, {
  //     header: 'Project Info',
  //     width: '70%',
  //     contentStyle: { "height": "400px", },
  //     data: { ...rowData }
  //   });
  //   ref.onClose.subscribe((res) => {

  //   })

  // }

  // onRowChooseProGrid(event: Event) {
  // }
  // onRowDblChooseProGrid(event: Event) {
  // }

  setPathButtonClick(setDefault?) {
    let selectedObj: any;
    let pm: any;
    return pm = new Promise((res, rej) => {
      if (setDefault && this._sagStudioService.selectedProjectData) {
        const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
        const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
        this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
          async (response: any) => {
            if (response) {
              this.getUserWiseLocalProjectPathResponce = await response['data'];
              await this.SagGridChooseProj(this.getUserWiseLocalProjectPathResponce)
              this.shareService.setDataprotool("getUserWiseLocalProjectPathResponce", response['data']);

              if (this.getUserWiseLocalProjectPathResponce.find((e) => e.projectname == this._sagStudioService.selectedProjectData.projectname)) {
                selectedObj = JSON.parse(JSON.stringify(this._sagStudioService.selectedProjectData));
                selectedObj.awspace ? selectedObj.awspace = `${selectedObj.awspace}/${selectedObj.projectname}` : false;
                selectedObj.jwspace ? selectedObj.jwspace = `${selectedObj.jwspace}/${selectedObj.projectname}` : false;
                //Projects avalable on Repository auther@CP
                if (selectedObj && selectedObj.projectGitPath && (selectedObj.projectGitPath != null) && (selectedObj.projectGitPath != '')
                  && (selectedObj.projectGitPath != null) && (selectedObj.projectSvnPath != '')) {
                  selectedObj['projectOnRepository'] = true;
                } else {
                  selectedObj['projectOnRepository'] = false;
                }
                this.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj)));
                localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj));
                this.shareService.setDatadbtool("projectNameValue", selectedObj.projectId);
                this.shareService.setDataprotool("selectedAngularProject", selectedObj.awspace);
                return res(true);
              } else {
                this.config.styleClass = "visible";
                return res(false);
              }
            }
          }
        );
      } else {
        const checkSelectedArray = this.gridDynamicForChooseProject.getSeletedRowData();
        if (checkSelectedArray.length == 0) {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: `Please Select At Least One File..!`,
          });
          return rej(false);

        }
        selectedObj = this.gridDynamicForChooseProject.getSeletedRowData();
        selectedObj = JSON.parse(JSON.stringify(selectedObj));
        selectedObj.awspace ? selectedObj.awspace = `${selectedObj.awspace}/${selectedObj.projectname}` : false;
        selectedObj.jwspace ? selectedObj.jwspace = `${selectedObj.jwspace}/${selectedObj.projectname}` : false;
        //Projects avalable on Repository auther@CP
        if (selectedObj && selectedObj.projectGitPath && (selectedObj.projectGitPath != null) && (selectedObj.projectGitPath != '')
          && (selectedObj.projectGitPath != null) && (selectedObj.projectSvnPath != '')) {
          selectedObj['projectOnRepository'] = true;
        } else {
          selectedObj['projectOnRepository'] = false;
        }
        this.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj)));
        localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj));
        this.shareService.setDatadbtool("projectNameValue", selectedObj.projectId);
        this.shareService.setDataprotool("selectedAngularProject", selectedObj.awspace);
        res(true);
      }
    });
  }

  closeModel() {
    this.modalRef.close(true);
  }

  getDbConnObj(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getPrjConfObject(dataJson).subscribe((res) => {
      if (res['status'] == 'success') {
        let dbInfo = res['confobj'];
        dbInfo['operation'] = 'COMPARESINGLE';
        dbInfo['targetDataSource'] = {};
        dbInfo['details'] = {
          software: [],
          year: [],
          client: [],
          columns: [],
          operation: ['']
        }
        this.shareService.setDatadbtool('finalDataForConnection', dbInfo);
      }
    });
  }
  // get project conf Object
  getPrjConfObj(path) {
    let dataJson = {
      projectId: path
    }
    this.shareService.getProjectVersion(dataJson).subscribe(async (res) => {
      this.shareService.setData('angversnObj',res)
      let versionControl = this._sagStudioService.versionObject(res);
      if (res['status'] == 'success' && !ObjectCompare(versionControl[0], res)) {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: "PROJECT JSON VERSION  MISMATCH",
        });
        let conf = await ui.confirm("Do You Want To Update Project JSON Version? ");
        if (conf == true) {
          await this.openVersionCheckMappingModal(res);
        }
        // log out code
        else {
          this.firststepProjectService.logout().subscribe(
            (data) => {
              this.close('projectLoaded');
              localStorage.clear();
              this.shareService.clearAllData();
              this.firststepProjectService.unAuthorizeCalllback();
            }
          );
        }
      }
      // project loaded successfull
      else {
        this.toast.launch_toast({
          type: 'success',
          position: 'bottom-right',
          message: 'Successfully Loaded Your Project !!!',
        });
        document.querySelector('body').classList.add('uiEditorNew');
        document.querySelector('body').classList.remove('uiEditor');
        this._sagStudioService.currentActiveProject = this._sagStudioService.sagWorkSpace.projectList.find(item => item.id == 'defaultProject1618079400000');
        this._sagStudioService.initSagWorkSpaceJSON("arg1", "arg2");
        // this.onGetMobileTheme();
        this._sagStudioService.getAvailModsList();
        this.close('projectLoaded');
      }
    });

    function ObjectCompare(o1, o2) {

      if (typeof o1 !== 'object' || typeof o2 !== 'object') {
        return false; // we compare objects only!
      }
      // when one object has more attributes than the other - they can't be eq
      if (Object.keys(o1).length !== Object.keys(o2).length) {
        return false;
      }
      for (let k of Object.keys(o1)) {
        if (o1[k] !== o2[k]) {
          return false;
        }
      }
      return true;
    }
  }


  openVersionCheckMappingModal(data) {
    const ref = this.dialogService.open(VersionControlMappingComponent, {
      header: "Version Control",
      width: "80%",
      contentStyle: { height: "500px" },
      data: data
    });

    ref.onClose.subscribe((res) => {

    });
  }

  async getpStylesScss() {
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    const fullPath = this._sagStudioService.getLocalFilePath("/src/styles.scss");
    const postData = {
      "destpath": fullPath,
      "projectName": `${selectedProjectChooseData.projectname}`,
      "projectSubtype": "scss"
    };
    this.shareService
      .getPageJson(postData)
      .subscribe((respJson) => {
        this._sagStudioService.currentActiveProject.subDataArray.push(...respJson['data']);
        const styleScssObj = this._sagStudioService.currentActiveProject
          .subDataArray
          .find(e => e["matchableId"] == `customfile~${selectedProjectChooseData.projectname}$src$styles.scss`)
        this._sagStudioService.pStylesScss = styleScssObj;
      });
  }

  onGetMobileTheme() {
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    const postData = {
      "projectName": `${selectedProjectChooseData.projectname}`,
    };
    this.shareService
      .getMobileTheme(postData)
      .subscribe(res => {
        if (res) {
          this._sagStudioService.mobileAppTheme = res["mobileTheme"];
          // this.toast.launch_toast({
          //   type:   res["status"] == "success" ? "success" :"alert",
          //   position: 'bottom-right',
          //   message: res["msg"]
          // });
        }
      });
  }
  defaultPrj(name: any) {
    if (name == 'setDefault') {
      let selectedPrj = this.gridDynamicForChooseProject.getSeletedRowData();
      const loginUserInfo = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
      if (selectedPrj && loginUserInfo) {
        const userId = Number(loginUserInfo.data.clientInfo.usrId);
        let setDefaultPrjConn = {
          "projectinfo": {
            "jwspace": selectedPrj.jwspace,
            "awspace": selectedPrj.awspace,
            "projectname": selectedPrj.projectname,
            "projectId": selectedPrj.projectId,
            "usrprojId": selectedPrj.usrprojId,
            "projectSvnPath": selectedPrj.projectSvnPath,
            "projectGitPath": selectedPrj.projectGitPath,
            "userId": userId,
            "loading": "UIbuilder"
          }
        }
        this.shareService.setDefaultPrjInfo(setDefaultPrjConn).subscribe((res) => {
          if (res['status'] == 'success') {
            this.showSetDefaultButton = true
            this._sagStudioService.selectedProjectData = this.gridDynamicForChooseProject.getSeletedRowData()
            this.toast.launch_toast({
              type: 'success',
              position: 'bottom-right',
              message: `${res['msg']}`,
            });
          }
        });
      }
    }
    if (name == 'unsetDefault') {
      let selectedDefProject = this.gridDynamicForChooseProject.getSeletedRowData()['projectname']
      let alreadyGetDefProj = JSON.parse(JSON.stringify(this._sagStudioService.selectedProjectData))['projectname']
      if (selectedDefProject == alreadyGetDefProj) {
        this.shareService.getUnsetdefaultroject().subscribe((res: any) => {
          if (res['status'] == 'success') {
            this._sagStudioService.selectedProjectData =false
            this.showSetDefaultButton = false
            this.toast.launch_toast({
              type: 'success',
              position: 'bottom-right',
              message: `${res['msg']}`,
            });
          }
        })
      }
    }


  }

   // get Font FamilyList in  project
   getFontFamily(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getFontFamilyList(dataJson).subscribe(async (res) => {
      this._sagStudioService.fontFamilyList=res || [];

    });


  }

}

