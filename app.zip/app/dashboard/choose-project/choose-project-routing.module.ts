import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChooseProjectComponent } from './choose-project.component';


const routes: Routes = [
  {
    path:"",
    component:ChooseProjectComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChooseProjectRoutingModule { }
