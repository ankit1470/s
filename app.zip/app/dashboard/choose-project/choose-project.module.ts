import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChooseProjectRoutingModule } from './choose-project-routing.module';
import { ChooseProjectComponent } from './choose-project.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/core/shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { TableModule } from 'src/app/modules/database/project-utility-tool/procompare-tool/table/table.module';


@NgModule({
  declarations: [ChooseProjectComponent],
  imports: [
    CommonModule,
    ChooseProjectRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    HttpClientModule,
    TableModule,
    
  ],
  exports:[ChooseProjectComponent]
})
export class ChooseProjectModule { }
