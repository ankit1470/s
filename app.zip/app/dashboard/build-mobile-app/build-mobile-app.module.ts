import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BuildMobileAppRoutingModule } from './build-mobile-app-routing.module';
import { BuildMobileAppComponent } from './build-mobile-app.component';
import { SharedModule } from 'src/app/core/shared/shared.module';


@NgModule({
  declarations: [BuildMobileAppComponent],
  imports: [
    CommonModule,
    BuildMobileAppRoutingModule,
    SharedModule,
  ]
})
export class BuildMobileAppModule { }
