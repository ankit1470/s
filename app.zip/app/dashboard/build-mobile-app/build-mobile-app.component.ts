import { AfterViewInit, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { DialogService } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { CommonParseService } from 'src/app/services/parseStudio/common-parse.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';

@Component({
  selector: 'app-build-mobile-app',
  templateUrl: './build-mobile-app.component.html',
  styleUrls: ['./build-mobile-app.component.scss']
})
export class BuildMobileAppComponent implements OnInit, AfterViewInit {

  progressData = {
    width: 0,
    content: ''
  }

  buildMobAppForm: FormGroup;
  runCommandData: any;
  isReadOnly: boolean=false;
  constructor(
    public _router: Router,
    public _sagStudioService: SagStudioService,
    public StudioDragDropService: CommonStudioDragDropService,
    public cdRef: ChangeDetectorRef,
    public shareService: SagShareService,
    public dialogService: DialogService,
    private toast: ToastService,
    private _fb: FormBuilder,
    private procomparetoolService: ProcomparetoolService,
  ) { }

  ngOnInit() {
    this.initFormCall();
  }

  initFormCall() {
    this.buildMobAppForm = this._fb.group({
      mobilePath: [""],
      port: [null]
    })
  }

  async ngAfterViewInit() {
    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    const mobPath = `${selectedObj.awspace.substring(0, selectedObj.awspace.lastIndexOf("/"))}/mobile_${selectedObj.projectname}`
    this.buildMobAppForm.patchValue({
      mobilePath: mobPath,

    });
    
    let serverAllPort = await this.getServerPort();
    if (serverAllPort['status'] == 200 && serverAllPort['isOnline']) {
      this.isReadOnly=true;
      this._sagStudioService.mobileAppPort = serverAllPort['data']['mobilePort'] ? parseInt(serverAllPort['data']['mobilePort']) : this._sagStudioService.mobileAppPort;
    } else {
      this._sagStudioService.mobileAppPort = this._sagStudioService.customPortNo ? this._sagStudioService.customPortNo + 111 : this._sagStudioService.mobileAppPort;
    }
    // this._sagStudioService.mobileAppPort = this._sagStudioService.customPortNo ? this._sagStudioService.customPortNo + 111 : this._sagStudioService.mobileAppPort;
  }

  async getServerPort() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    if (sessionStoragedatauserId) {
      let userId = sessionStoragedatauserId.data.clientInfo.usrId;
     const response= await this.shareService.getAllServerPort(userId).toPromise();
     return response;
    }
  }

  async onBuildApk() {
    let userItem = {"path" : "mobile"};
    const modalItem = {
      methodName : "mobileVariablefile",
      args : {
        '0' : [userItem],
        '1' : 'from'
      }
    }
    this._sagStudioService.commonParseService$.next(modalItem)

    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    const postData = {
      angwrkpath: selectedObj.awspace.substring(0, selectedObj.awspace.lastIndexOf("/")),
      projectName: selectedObj.projectname,
      mobilePath: this.buildMobAppForm.get("mobilePath").value,
      port: this._sagStudioService.mobileAppPort
    };
    this.shareService.loading++;
    this.shareService
      .buildMobileApp(postData)
      .subscribe(async res => {
        this.shareService.loading--;
        if (res && res["status"] == "failure") {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: res["msg"]
          });
          await this.procomparetoolService.runPortApi(this._sagStudioService.mobileAppPort).toPromise();
          this.toast.launch_toast({
            type: 'info',
            position: 'bottom-right',
            message: "Please Try Again Now"
          });
        } else {
          this.toast.launch_toast({
            type: "success",
            position: 'bottom-right',
            message: res["msg"]
          });
          await this.addClassOnApp();
          this.mobileThemesEnv()
        }

        //  await this.StudioDragDropService.addMobileAppClass(finalPath,declareVarName,`@HostBinding("class") classes = ""`); 
      },
        err => {
          console.log(err);
          this.shareService.loading--;
        }
      )
    // buildMobileApp
    
  }

  progressFn() {
    if (this.progressData.width == 100) {
      this.progressData.content = 'Apk Generated Successfully !!!';
    } else {
      setTimeout(() => {
        this.progressData.content = `Building Modules....${this.progressData.width}%`;
        this.progressData.width++;
        this.progressFn();
      }, 100);
    }
  }

  // async onWeb() {
  //   let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
  //   const postData = {
  //     angwrkpath: selectedObj.awspace.substring(0, selectedObj.awspace.lastIndexOf("/")),
  //     projectName: selectedObj.projectname,
  //   };
  //   const finalPath = `${selectedObj.projectname}/src/app/app.component.ts`;
  //   const declareVarName = `classes`;

  //   await this.StudioDragDropService.addMobileAppClass(finalPath, declareVarName, `@HostBinding("class") classes = ""`);
  // }

  async addClassOnApp() {
    const finalPath = `${this.buildMobAppForm.get("mobilePath").value}/src/app/app.component.ts`;
    const declareVarName = `classes`;
    // native class add on formdesign
    // const content = `@HostBinding("class") classes = "${this._sagStudioService.mobileAppTheme}"`; 

    const content = `@HostBinding("class") classes = "formdesign"`;
    try {
      await this.StudioDragDropService.addMobileAppClass(finalPath, declareVarName, content);
    } catch {
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: "Error While Parsing Data"
      });
    }
    const command = `ng serve --port ${this._sagStudioService.mobileAppPort} --disable-host-check`;
    this.toast.launch_toast({
      type: 'success',
      position: 'bottom-right',
      message: "Please Wait For A While"
    });
    this.procomparetoolService.runCommandApi(this.buildMobAppForm.get("mobilePath").value, command).subscribe(
      (res: any) => {
        console.log(res);
      },
    );

  }
  _stopServer_Click() {
    const port = this._sagStudioService.mobileAppPort
    this.procomparetoolService.runPortApi(port).subscribe((response: any) => {
      if (response) {
        this.runCommandData = response["data"];
      }
    },
      (err) => {
        console.error("err response");
      });
  }

  mobileThemesEnv(){
    let postData = {
      "projectPath" : this.buildMobAppForm.get("mobilePath").value,
      "env" : "mobile"
    }
    this.shareService.envSetData(postData).subscribe(res => {
      console.log(res)
    })
  }
}
