import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DatabaseConnectionRoutingModule } from './database-connection-routing.module';
import { DatabaseConnectionComponent } from './database-connection.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [DatabaseConnectionComponent],
  imports: [
    CommonModule,
    DatabaseConnectionRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class DatabaseConnectionModule { }
