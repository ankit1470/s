import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { DbcomparetoolFirststepService } from 'src/app/services/database/dbcomparetool-firststep.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';

@Component({
  selector: 'app-database-connection',
  templateUrl: './database-connection.component.html',
  styleUrls: ['./database-connection.component.scss']
})
export class DatabaseConnectionComponent implements OnInit {
  databaseConnForm: any;
  creationTable: any;
  creationTableForm: any;
  readonlyInput: boolean=false;
  constructor(private formbuilder: FormBuilder,
    public firststepDbcompareService: DbcomparetoolFirststepService,
    public toast: ToastService,
    private shareService: SagShareService,
    public dialogService: DialogService,
    public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public autoJavacodeService:AutoJavacodeService) {
     
  }

  ngOnInit() { 
    this.initDbConnectionForms(); 
    this.creationTable = this.config.data && this.config.data.tableCreation;
    if(this.creationTable == 'creationTable'){
      /* this.databaseConnForm.disable();
      this.databaseConnForm.get('vendor').enable(); */
    }
    //----------------
    if(this.creationTable != 'creationTable'){
      let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
      if(dataForConnection && dataForConnection.srcDataSource){
        this.databaseConnForm.setValue(dataForConnection.srcDataSource);
      }
    }
    
  }
  //  F O R M   I N I T I A L I Z E D    H E R E
  initDbConnectionForms() {
    this.databaseConnForm = this.formbuilder.group({
      vendor: ['MySQL'],
      databaseName: [''],
      hostName: ['localhost'],
      portNumber: ['3306'],
      userName: ['root'],
      password: ['root'],
    });
  }

  testConnection() {
    const finalDataForConnection = {
      "srcDataSource": this.databaseConnForm.value,
      "operation": "TEST",
      "connectionRoleType": 'admin'
    }
    this.firststepDbcompareService.testConnectionByPost(finalDataForConnection).subscribe((res) => {
      if (res['src'] == true) {
       let projectInfo = this.shareService.getDataprotool("selectedProjectChooseData");
       if(projectInfo){
        let setConn={
          "projectPath": projectInfo ?projectInfo.awspace+`/prjconn.json` :"" ,
          "confobj":JSON.parse(JSON.stringify(finalDataForConnection)),
        }
        this.setDbConnnectionObj(setConn);
       }
      
     
        finalDataForConnection['operation'] = 'COMPARESINGLE';
        finalDataForConnection['targetDataSource']  = {};
        finalDataForConnection['details'] = {
          software: [],
          year: [],
          client: [],
          columns: [],
          operation: ['']
        }
        this.shareService.setDatadbtool('finalDataForConnection', finalDataForConnection);
        this.modalRef.close(true);
      } 
      else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Test Connection : Fail !!!...',
        });
      }
    })
  }

  Close(){
    this.modalRef.close(true);
  }

  setDatabaseConfiguration(){
    let setProjectInfo= this.shareService.getDataprotool("selectedProjectChooseData");
    if(setProjectInfo!=undefined){
      let javaworkspace=setProjectInfo.jwspace;
      if(javaworkspace!=undefined && javaworkspace!=null && javaworkspace!=""){

        let reqObj =this.databaseConnForm.value
        reqObj["projectPath"]=javaworkspace;
    
        this.autoJavacodeService.setDatabaseConfiguration(reqObj).subscribe(res => {
          if(res.status==200){ 
            this.toast.launch_toast({
              type: 'success',
              position: 'bottom-right',
              message: res.msg,
            });
            this.testConnection()
          }else{
            this.toast.launch_toast({
              type: 'alert',
              position: 'bottom-right',
              message: res.msg,
            });
          }
        
        }, Error => {
        
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: 'Set Database Configuration : Fail !!!...',
          });
        });
      }
    }else{
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: 'java workspace not set',
      });
    }

  
  }

  dBCreationConnection(){
   // this.databaseConnForm.disable();
   const finalDataDBCreation = {
    "srcDataSource": this.databaseConnForm.value,
    "connectionRoleType": "admin",
    "operation": "COMPARESINGLE"
   }
   this.shareService.setDBCreation('dbCreationTable', finalDataDBCreation);
   this.modalRef.close(true);
  }
  

  async setDbConnnectionObj(data){
   await this.shareService.savePrjConfObject(data).subscribe((res)=>{
      if(res['status']=='success'){
        this.toast.launch_toast({
          type: 'success',
          position: 'bottom-right',
          message: 'Test Connection : Success !!!...',
        });
      }
    });
  }
}
