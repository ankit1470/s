import { Component, Input, OnInit } from '@angular/core';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/api';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { WriteNgFilesService } from 'src/app/services/writeStudio/write-ng-files.service';
declare var SdmtGridT;
@Component({
  selector: 'app-project-exploral-file-list',
  templateUrl: './project-exploral-file-list.component.html',
  styleUrls: ['./project-exploral-file-list.component.scss']
})
export class ProjectExploralFileListComponent implements OnInit {
  @Input() item;

  listOfFiles:any = [];
  srcStructure:any;
  fileNotWorkWith = [
    // 'favicon.ico',
    // 'admindata.share.service.ts',
    // 'app-routing.module.ts',
    // 'app.component.ts',
    // 'app.component.html',
    // 'app.component.scss',
    // 'app.module.ts',
    // "test.ts",
    // "styles.scss",
    // "polyfills.ts",
    // "main.ts",
    // "index.html",
    // "projdata.share.service.ts",
    // "interceptor.ts",
    // "meta.service.ts",
    // "translang.ts",
    // "sag-routing.module.ts",
    // "sag.component.html",
    // "sag.component.scss",
    // "sag.component.ts",
    // "sag.module.ts",
    // "language.service.ts",
    // "admindata.share.service.ts",
    // "admin-routing.module.ts",
    // "admin.component.html",
    // "admin.component.scss",
    // "admin.component.ts",
    // "admin.module.ts"
  ]
  unsavedFiles:boolean = false;

notWorkWith = [];

  constructor(
    public studioDragDropService: CommonStudioDragDropService,
    public procomparetoolService: ProcomparetoolService,
    public sagStudioService: SagStudioService,
    private _shareService: SagShareService,
    public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private _writeNgFile: WriteNgFilesService,
  ) { 
    // this.item = this.config.data.item || [];
  }

  ngOnInit() {
    this.updatedProjectJson()
    
    setTimeout(()=>{
      this.filelist();
    },1000)
  }
  async updatedProjectJson(){
    this.sagStudioService.restrictFileOpen = false;
    let selectedObj = this._shareService.getDataprotool("selectedProjectChooseData");
    if (selectedObj) {
      const postData = {
        destpath: selectedObj.awspace,
        projectname: selectedObj.projectname,
      }
      this._shareService.loading++;
      const resSagStudioJson = await this.procomparetoolService.loadProjectJson(postData).toPromise();
      this._shareService.loading--;
      // this.sagStudioService.projectExploralFileList = resSagStudioJson
      let seletedObj = this._shareService.getDataprotool("selectedProjectChooseData");
      let proPath = seletedObj.awspace.split('/').slice(0,seletedObj.awspace.split('/').length-1).join('/')
      let projectTree = resSagStudioJson[0].projectExplorerTree[0].children[0];
      this.getSrcFolderStructure(projectTree)
      if(this.srcStructure !=undefined){
        this.collectAllFilesFromProject(this.srcStructure,proPath);
      }
    }
    debugger
    if(this.listOfFiles && this.listOfFiles.length > 0){
      for (let index = 0; index < this.listOfFiles.length; index++) {
        const element = this.listOfFiles[index];
        setTimeout(async ()=>{
          let selectedPageFileNode = await this.studioDragDropService.getExplorerNodeByProjectPath(element.projectPath, 'from');
          await this.studioDragDropService.fileShow(selectedPageFileNode, '', '');
        },100)
      }
    }
    this.rowData_filelist = this.listOfFiles
  }
  getSrcFolderStructure(project){
    if(project.angularScemeticName == "src"){
      this.srcStructure = project;
    }
    if(project && project.children && project.children.length > 0){
      project.children.forEach(pro=>{
        this.getSrcFolderStructure(pro)
      })
    }
  }
  
  async collectAllFilesFromProject(list,propath){
    if(list.type == 'file' && !this.fileNotWorkWith.includes(list.label)){
      let obj ={
        'fName':list.label,
        'path':`${propath}/${list.projectPath}`,
        'matchableId':list.matchableId,
        'projectSubtype':list.projectSubtype,
        'projectPath':list.projectPath
      }

      this.listOfFiles.push(obj)
    }
    if(!this.notWorkWith.includes(list.angularScemeticName)){
     
      if(list && list.children && list.children.length > 0 ){
        list.children.forEach(child=>{
          this.collectAllFilesFromProject(child,propath)
        })
      }
    }
  }
  gridData_filelist: any;
  gridDynamicObj_filelist: any;
  columnData_filelist: any = [
    {
      "header": "",
      "field": "selectedRow",
      "filter": false,
      "width": "30px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "headerCheckBox",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false
    },
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "File name",
      "field": "fName",
      "filter": true,
      "width": "400px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "File path",
      "field": "path",
      "filter": true,
      "width": "600px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_filelist: any = [
    {},
    {},
    {},
    {}
  ];

  filelist(rowData?, colData?) {
    let self = this;

    this.gridData_filelist = {
      columnDef: colData ? colData : this.columnData_filelist,
      rowDef: rowData ? rowData : this.rowData_filelist,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onfilelistCellClick();
        },
        "onRowClick": function () {
          self.onfilelistClick();
        },
        "onRowDbleClick": function () {
          self.onfilelistdblClick();
        }
      }
      ,


      rowCustomHeight: 20,




    };

    let sourceDiv = document.getElementById("filelist");
    this.gridDynamicObj_filelist = SdmtGridT(sourceDiv, this.gridData_filelist, true, true);
  }

  onfilelistCellClick() {

  }

  onfilelistClick() {

  }

  onfilelistdblClick() {

  }
  closeModal(flag) {
    this.sagStudioService.restrictFileOpen = true;
    this.modalRef.close(flag);
  }
  async saveModified(){
    debugger
    this.saveSelectedRowFile();
    }
    async saveSelectedRowFile(){
      this.listOfFiles = []
      this.rowData_filelist.forEach(dataRow=>{
        if(dataRow.selectedRow == 1){
          this.listOfFiles.push(dataRow)
        }
      })
      await this._writeNgFile.saveUnSaveMethod(this.listOfFiles); 
      // this.closeModal(true);
    }
}
