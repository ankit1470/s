import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectExploralFileListRoutingModule } from './project-exploral-file-list-routing.module';
import { ProjectExploralFileListComponent } from './project-exploral-file-list.component';


@NgModule({
  declarations: [ProjectExploralFileListComponent],
  imports: [
    CommonModule,
    ProjectExploralFileListRoutingModule
  ],
  exports:[ProjectExploralFileListComponent]
})
export class ProjectExploralFileListModule { }
