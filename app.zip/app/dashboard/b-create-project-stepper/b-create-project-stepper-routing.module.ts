import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BCreateProjectStepperComponent } from './b-create-project-stepper.component';


const routes: Routes = [
  {
    path : "",
    component : BCreateProjectStepperComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BCreateProjectStepperRoutingModule { }
