import { Component, OnInit, } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { AutoJavacodeService } from 'src/app/modules/sag-studio/property-window/db-mapping/auto-javacode.service';
import { DbcomparetoolFirststepService } from 'src/app/services/database/dbcomparetool-firststep.service';
import { ProcomparetoolFirststepService } from 'src/app/services/project-utility-tool/procomparetool-firststep.service';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { SagShareService } from 'src/app/services/sagshare.service';
import { VersionControlMappingComponent } from '../version-control-mapping/version-control-mapping.component';
declare function alerts(m): any;
declare function success(m): any;
declare var ui;

@Component({
  host: {
    class: "d-flex flex-column h-100",
  },
  selector: 'app-b-create-project-stepper',
  templateUrl: './b-create-project-stepper.component.html',
  styleUrls: ['./b-create-project-stepper.component.scss'],
  providers: [DialogService]
})
export class BCreateProjectStepperComponent implements OnInit {
  // database configuration variables
  databaseConnForm: any;
  creationTable: any;
  creationTableForm: any;
  readonlyInput: boolean = false;
  isDarkModeMoon: any = 'darkmodeMoon'
  steps = 1
  getUserWiseLocalProjectPathResponce: any;
  createProjLoad: any = {}
  createProjectInfo: any;
  saveUserWiseLocalProjectPathresponce: any;
  SecurityType = [{ key: "jwt", value: "JWT" }, { key: "simple", value: "SIMPLE" }]
  projectCreationForm: any;
  backEndConfigForm: any;
  comparingProjInfo: any;
  selectedTab: string;
  isProjectOnlineFlag: any
  theme: any = {
    "section_name": "Other Button",
    "section_fields": [
      { "label": "Default BG", "id": "custom28", "inputType": "color", "--value": "rgb(238, 238, 238)", "name": "defaultBgClr" },
      { "label": "Default Text", "id": "custom29", "inputType": "color", "--value": "rgb(238, 238, 111)", "name": "defaultTxtClr" },
      { "label": "Primary BG", "id": "custom30", "inputType": "color", "--value": "rgb(238, 121, 111)", "name": "primaryBgClr" },
      { "label": "Primary Text", "id": "custom31", "inputType": "color", "--value": "rgb(111, 242, 111)", "name": "primaryTxtClr" },
      { "label": "Success Bg", "id": "custom32", "inputType": "color", "--value": "rgb(123, 232, 145)", "name": "successBgClr" },
      { "label": "Success Text", "id": "custom33", "inputType": "color", "--value": "rgb(300, 122, 222)", "name": "successTxtClr" },
      { "label": "Danger BG", "id": "custom34", "inputType": "color", "--value": "rgb(222, 054, 111)", "name": "dangerBgClr" },
      { "label": "Danger Text", "id": "custom35", "inputType": "color", "--value": "rgb(33, 238, 111)", "name": "dangerTxtClr" },
      { "label": "Info BG", "id": "custom36", "inputType": "color", "--value": "rgb(238, 44, 111)", "name": "infoBgClr" },
      { "label": "Info Text", "id": "custom37", "inputType": "color", "--value": "rgb(238, 55, 22)", "name": "infoTxtClr" },
      { "label": "Warning BG", "id": "custom38", "inputType": "color", "--value": "rgb(66, 238, 111)", "name": "warningBgClr" },
      { "label": "Warning Text", "id": "custom39", "inputType": "color", "--value": "rgb(238, 77, 77)", "name": "warningTxtClr" },
      { "label": "Secondary BG", "id": "custom40", "inputType": "color", "--value": "rgb(238, 66, 111)", "name": "secondaryBgClr" },
      { "label": "Secondary Text", "id": "custom41", "inputType": "color", "--value": "rgb(238, 238, 77)", "name": "secondaryTxtClr" },
    ]

  }

  stepperItems: any[]
  activeStepId: string = "projNameDetails";
  projectPathResponce = 815;
  projectId: any
  gitRepoPath: any;
  svnRepoPath: any;
  sessionStoragedata: any;
  getDefaultProj: any
  constructor(
    public _router: Router,
    private formbuilder: FormBuilder,
    public dialogService: DialogService,
    public firststepDbcompareService: DbcomparetoolFirststepService,
    private shareService: SagShareService,
    public _sagStudioService: SagStudioService,
    private dbcomparetoolService: ProcomparetoolService,
    public toast: ToastService,
    public StudioDragDropService: CommonStudioDragDropService,
    public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public firststepProjectService: ProcomparetoolFirststepService,
    public autoJavacodeService: AutoJavacodeService) {

  }

  ngOnInit() {
    document.querySelector('.ui-dialog-mask-scrollblocker').classList.add('sdmtDarkModeModal')
    window['angularComponentRef'] = window['angularComponentRef'] || {};
    window['angularComponentRef'].newFunc = this.newFunc.bind(this);
    // this.activeStepId = 'projNameDetails' 
    this.sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'))
    this.isProjectOnline();
    this.initDbConnectionForms();
    this.initalizeEditForm();
    this.frontenedGroup()
    this.backenedGroup()
    this.projectCreationForm.patchValue({
      frntEndUsrname: this.sessionStoragedata.username,
      frntEndPasswd: this.sessionStoragedata.password,
      backEndUsrname: this.sessionStoragedata.username,
      backEndPasswd: this.sessionStoragedata.password,
    })
    this.projectCreationForm.controls["SecretKey"].disable();
    if (this.creationTable != 'creationTable') {
      let dataForConnection = this.shareService.getDatadbtool('finalDataForConnection');
      if (dataForConnection && dataForConnection.srcDataSource) {
        this.databaseConnForm.setValue(dataForConnection.srcDataSource);
      }
    }
    this.getuserWrkSpacePath()


  }

  frontenedGroupData: any
  backendGroupData: any
  frontenedFrameworkData: any
  backendFrameworkData: any

  frontenedGroupDatalength:any;
  frontenedGroupDataId:any;
  frontenedGroup() {
    this.dbcomparetoolService.getFrontenedGroup().subscribe((res: any) => {
      if (res) {
          this.frontenedGroupDatalength = res['data'].length - 1;
          res['data'].map((ele: any, ind: any) => {
            if (this.frontenedGroupDatalength == ind) {
              // newRowJson['months'] = ind + 1;
              this.frontenedGroupDataId = ele['techfgrp_id'];
            }
          })
        this.frontenedGroupData = res['data']
      }
    })
  }

  backenedGroupDatalength:any;
  backenedGroupDataId:any;
  backenedGroup() {
    this.dbcomparetoolService.getBackendGroup().subscribe((res: any) => {
      if (res) {
        this.backenedGroupDatalength = res['data'].length - 1;
          res['data'].map((ele: any, ind: any) => {
            if (this.backenedGroupDatalength == ind) {
              // newRowJson['months'] = ind + 1;
              this.backenedGroupDataId = ele['techgrp_id'];
            }
          })
        this.backendGroupData = res['data']
      }
    })
  }

  saveFrontenedTechVersion(data) {
    this.dbcomparetoolService.saveFrontenedTechVersion(data).subscribe((res: any) => {

    })
  }

  getFrontenedFrameworks(event) {
    this.frontenedFrameworkData = ''
    let value:any;
    if(event.target == undefined){
      value = event;
    }else{
      value = Number(event.target.value);
    }
    if (typeof(value) == 'number') {
      this.dbcomparetoolService.getFrontenedFrameworks(value).subscribe((res: any) => {
        this.frontenedFrameworkData = res['data']
      })
    }
  }

  getBackendFrameworks(event) {
    this.backendFrameworkData = ''
    let value:any;
    if(event.target == undefined){
      value = event;
    }else{
      value = Number(event.target.value);
    }
    if (typeof(value) == 'number') {
      this.dbcomparetoolService.getBackendFrameworks(value).subscribe((res: any) => {
        this.backendFrameworkData = res['data'];
      })
    }
   
  }

  isProjectOnline() {
    this.dbcomparetoolService.isProjectOnline().subscribe(
      (response: any) => {
        this.isProjectOnlineFlag = response['isOnline'];
        this.stepperItems = [
          {
            label: "Name Of Project",
            value: "projNameDetails",
            id: "projNameDetails",
            step: 1
          },
          {
            label: 'Theme',
            value: 'theme',
            id: 'theme',
            step: 2
          },
          {
            label: 'Project Setup',
            value: 'projectSetup',
            id: 'projectSetup',
            step: 3
          },
          {
            label: "Work Space Path",
            value: "lclWrkSpace",
            id: "lclWrkSpace",
            step: this.isProjectOnlineFlag ? '' : 4
          },
          {
            label: "Technology Stack",
            value: "techStack",
            id: "techStack",
            step: this.isProjectOnlineFlag ? 4 : 5
          },
          {
            label: "Database Configuration",
            value: "dbConfig",
            id: "dbConfig",
            step: this.isProjectOnlineFlag ? 5 : 6
          },
          {
            label: "Team & Roles",
            value: "teamNRoles",
            id: "teamNRoles",
            step: this.isProjectOnlineFlag ? 6 : 7
          },
        ];
        this.isProjectOnlineFlag ? this.stepperItems.splice(3, 1) : ''
      },
    );
  }



  //  F O R M   I N I T I A L I Z E D    H E R E
  initDbConnectionForms() {
    this.databaseConnForm = this.formbuilder.group({
      vendor: ['MySQL'],
      databaseName: [''],
      hostName: ['localhost'],
      portNumber: ['3306'],
      userName: ['root'],
      password: ['root'],
    });
  }

  testConnection() {
    const finalDataForConnection = {
      "srcDataSource": this.databaseConnForm.value,
      "operation": "TEST",
      "connectionRoleType": 'admin'
    }
    this.firststepDbcompareService.testConnectionByPost(finalDataForConnection).subscribe((res) => {
      if (res['src'] == true) {
        const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
        let awpace = `${newProj[0].awspace}/${newProj[0].projectname}`
        if (newProj[0]) {
          let setConn = {
            "projectPath": newProj[0] ? awpace + `/prjconn.json` : "",
            "confobj": JSON.parse(JSON.stringify(finalDataForConnection)),
          }
          this.setDbConnnectionObj(setConn);
        }

        finalDataForConnection['operation'] = 'COMPARESINGLE';
        finalDataForConnection['targetDataSource'] = {};
        finalDataForConnection['details'] = {
          software: [],
          year: [],
          client: [],
          columns: [],
          operation: ['']
        }
        this.shareService.setDatadbtool('finalDataForConnection', finalDataForConnection);
        // this.modalRef.close(true);
      }
      else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Test Connection : Fail !!!...',
        });
      }
    })
  }


  setDatabaseConfiguration() {
    let setProjectInfo = this.shareService.getDataprotool("selectedProjectChooseData");

    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    let javaworkspace = `${newProj[0].jwspace}/${newProj[0].projectname}`;

    if (javaworkspace != undefined && javaworkspace != null && javaworkspace != "") {

      let reqObj = this.databaseConnForm.value
      reqObj["projectPath"] = javaworkspace;

      this.autoJavacodeService.setDatabaseConfiguration(reqObj).subscribe(res => {
        if (res.status == 200) {
          this.toast.launch_toast({
            type: 'success',
            position: 'bottom-right',
            message: res.msg,
          });

        } else {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: res.msg,
          });
        }

      }, Error => {

        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Set Database Configuration : Fail !!!...',
        });
      });
    }

  }

  async setDbConnnectionObj(data) {
    await this.shareService.savePrjConfObject(data).subscribe((res) => {
      if (res['status'] == 'success') {
        this.setDatabaseConfiguration()
        this.toast.launch_toast({
          type: 'success',
          position: 'bottom-right',
          message: 'Test Connection : Success !!!...',
        });
      }
    });
  }

  initalizeEditForm() {
    this.projectCreationForm = this.formbuilder.group({
      projectName: ["", Validators.required],
      web: ["web"],
      desktop: ["desktop"],
      appMobile: ["appmobile"],
      projectStartDate: [new Date()],
      tentativeEndDate: [new Date()],
      SecretKey: ["", Validators.required],
      angularVersion: ["17", Validators.required],
      SecurityType: ["SIMPLE", Validators.required],
      chackBoxValue: [true],
      projectDesc: [""],
      gitRepoPath: [""],
      svnRepoPath: [""],
      awspace: [""],
      frntEndUsrname: [""],
      frntEndPasswd: [""],
      jwspace: [""],
      backEndUsrname: [""],
      backEndPasswd: [""],
      frontenedGroupId:[''],
      backendGroupId:[''],
    });
    this.backEndConfigForm = this.formbuilder.group({
      projectname: [''],
      technology: ['java'],
      version: ['java8'],

    });
  }

  getuserWrkSpacePath() {
    this.shareService.getUserWrkSpacePath(this.sessionStoragedata.username).subscribe((res: any) => {
      if (res['status'] == '200') {
        let awId = document.getElementById('aw')
        let jwId = document.getElementById('jw')
        if (res['angWorkspace'] != '' && res['javaWorkspace'] != '') {
          awId.setAttribute('disabled', 'true')
          jwId.setAttribute('disabled', 'true')
        }
        else {
          awId.removeAttribute('disabled')
          jwId.removeAttribute('disabled')
        }
        this.projectCreationForm.patchValue({
          awspace: res['angWorkspace'],
          jwspace: res['javaWorkspace']
        })
      }
    })
  }

  createProject(prjLoadOrnOt: any, platForm: any) {
    this.createProjLoad['prjLoad'] = prjLoadOrnOt
    this.createProjLoad['platForm'] = platForm
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'))
    const chackBoxValue = this.projectCreationForm.value.chackBoxValue
    if (chackBoxValue == true) {
      if (this.projectCreationForm.valid) {
        this.shareService.loading++;
        if (this.projectCreationForm.value.awspace == this.projectCreationForm.value.jwspace && (this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != '') && (this.projectCreationForm.value.awspace != null || this.projectCreationForm.value.jwspace != null)) {
          alerts("Frontend and Backend path should not be same")
          this.shareService.loading--;
          let ele = document.getElementById('btn-lclWrkSpace')
          ele.classList.add('active')
          this.activeStepId = 'lclWrkSpace'
          return
        }
        else if (this.projectCreationForm.value.awspace == '' && this.projectCreationForm.value.jwspace == '') {
          alerts("Please specify atleast one path!!")
          this.shareService.loading--;
          let ele = document.getElementById('btn-lclWrkSpace')
          ele.classList.add('active')
          this.activeStepId = 'lclWrkSpace'
          return
        }
        else {
          this.shareService.loading--;
          this.isRunning_Git_Svn_Server();

        }

      } else if (this.projectCreationForm.invalid) {
        alerts("Please Enter Project Name");
        let ele = document.getElementById('btn-projNameDetails')
        ele.classList.add('active')
        this.activeStepId = 'projNameDetails'
      }
    }
    else {
      this.createProjectWithOutRepo();
    }

  }

  // =========================Project Create ==============================================
  repoPrjExst: boolean;
  createProjectDb(gitRepoPath, svnRepoPath) {

    const postData = {
      projectName: this.projectCreationForm.value.projectName,
      gitrepopath: gitRepoPath,
      svnrepopath: svnRepoPath,
      securityType: this.projectCreationForm.value.SecurityType,
      secretKey: this.projectCreationForm.value.SecretKey
    };
    this.shareService.loading++;
    this.dbcomparetoolService.createProjectDbData(postData).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response['status'] == 200) {
          this.projectId = response['pId']
          const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
          const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
          this.saveUserWiseLocalProjectPath(gitRepoPath, svnRepoPath, true)
          let jsonData = {
            projectId:this.projectId,
            userId:userId,
            techfgrp_id:this.projectCreationForm.value.frontenedGroupId,
            techgrp_id:this.projectCreationForm.value.backendGroupId,
            flag:'0',
            techfgrp_name: this.frontenedGroupData.find((x:any) => x.techfgrp_id == this.projectCreationForm.value.frontenedGroupId).techfgrp_name,
            techgrp_name: this.backendGroupData.find((x:any) => x.techgrp_id == this.projectCreationForm.value.backendGroupId).techgrp_name,
          }
          this.saveFrontenedTechVersion(jsonData);
        }
        if (response['status'] == 500) {
          alerts(response.msg);
        }
      },
      err => {
        this.shareService.loading--;
        alerts("Error While Fetching")
      }
    )
  }
  createProjectPmt() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const postData = {
      projectName: this.projectCreationForm.value.projectName,
      userId: sessionStoragedatauserId.data.clientInfo.usrId
    };
    this.shareService.loading++;
    this.dbcomparetoolService.createProjectPmtData(postData).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response['status'] == 200) {
          // success("Successfully create Project ");
        }
        if (response['status'] == 500) {
          this.shareService.loading++;
          alerts(response.msg);
        }
      },
      (err) => {
        this.shareService.loading--;
      }
    )
  }
  createProjectWithOutRepo() {
    if (this.projectCreationForm.valid) {
      const postData = {
        projectName: this.projectCreationForm.value.projectName,
        gitrepopath: "",
        svnrepopath: "",
        securityType: this.projectCreationForm.value.SecurityType,
        secretKey: this.projectCreationForm.value.SecretKey
      };
      this.shareService.loading++;
      if (this.projectCreationForm.value.awspace == this.projectCreationForm.value.jwspace && (this.projectCreationForm.value.awspace != '' || this.projectCreationForm.value.jwspace != '') && (this.projectCreationForm.value.awspace != null || this.projectCreationForm.value.jwspace != null)) {
        alerts("Frontend and Backend path should not be same")
        this.shareService.loading--;
        let ele = document.getElementById('btn-lclWrkSpace')
        ele.classList.add('active')
        this.activeStepId = 'lclWrkSpace'
        return
      }
      else if (this.projectCreationForm.value.awspace == '' && this.projectCreationForm.value.jwspace == '') {
        alerts("Please Specify At Least One Path..!")
        this.shareService.loading--;
        let ele = document.getElementById('btn-lclWrkSpace')
        ele.classList.add('active')
        this.activeStepId = 'lclWrkSpace'
        return
      }
      else {
        this.dbcomparetoolService.createProjectDbData(postData).subscribe(
          (response: any) => {
            this.shareService.loading--;
            if (response['status'] == 200) {
              this.projectId = response['pId']
              const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
              const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
              let jsonData = {
                projectId:this.projectId,
                userId:userId,
                techfgrp_id:this.projectCreationForm.value.frontenedGroupId,
                techgrp_id:this.projectCreationForm.value.backendGroupId,
                flag:'0',
                techfgrp_name: this.frontenedGroupData.find((x:any) => x.techfgrp_id == this.projectCreationForm.value.frontenedGroupId).techfgrp_name,
                techgrp_name: this.backendGroupData.find((x:any) => x.techgrp_id == this.projectCreationForm.value.backendGroupId).techgrp_name,
              }
              this.saveFrontenedTechVersion(jsonData);
              this.saveUserWiseLocalProjectPath("", "", false)
            }
            if (response['status'] == 500) {
              alerts(response.msg);
            }
          },
          (err) => {
            this.shareService.loading--;
          }
        )
      }
    }
    else if (this.projectCreationForm.invalid) {
      alerts("Please Enter Project Name");
      let ele = document.getElementById('btn-projNameDetails')
      ele.classList.add('active')
      this.activeStepId = 'projNameDetails'
    }
  }
  SecurityTypeChack(event) {
    if (event == "JWT") {
      this.projectCreationForm.controls["SecretKey"].enable();
    } else if (event == "SIMPLE") {
      this.projectCreationForm.controls["SecretKey"].disable();
    }
  }

  // code functionality @rohit 

  async getUserWiseLocalProjectPath() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
      (response: any) => {
        if (response) {
          this.getUserWiseLocalProjectPathResponce = response['data']
          this.shareService.addPrjFromStepper.next(this.getUserWiseLocalProjectPathResponce)
          this.shareService.setDataprotool("getUserWiseLocalProjectPathResponce", response['data']);
          if (this.getUserWiseLocalProjectPathResponce) {
            this.getUserWiseLocalProjectPathResponce.filter((prjName: any) => {
              if (prjName.projectname == this.projectCreationForm.value.projectName) {
                this.comparingProjInfo = prjName
                this.prjPath = `/${this.comparingProjInfo['projectname']}`;
              }
            })
            this.awSpace = this.comparingProjInfo['awspace'].concat(this.prjPath)
            this.jwSpace = this.comparingProjInfo['jwspace'].concat(this.prjPath)
            const checkBoxValue = this.projectCreationForm.value.chackBoxValue
            if (checkBoxValue == true) {
              if (this.comparingProjInfo['awspace']) {
                this.gitCloneClick()
              }
              if (this.comparingProjInfo['jwspace']) {
                this.svnCheckOutClick()
              }
            }
            else {
              this.checkPrjExist()
            }
          }
        }
      }
    );
  }


  saveUserWiseLocalProjectPath(gitRepoPath: any, svnrepopath: any, prjOnrepo) {
    this.repoPrjExst = prjOnrepo
    let postdata = { data: [] };
    let projInfoObj = {
      awspace: this.projectCreationForm.value.awspace ? this.projectCreationForm.value.awspace : '',
      jwspace: this.projectCreationForm.value.jwspace ? this.projectCreationForm.value.jwspace : '',
      projectGitPath: gitRepoPath != '' ? gitRepoPath : '',
      projectId: this.projectId,
      projectSvnPath: svnrepopath != '' ? svnrepopath : '',
      projectname: this.projectCreationForm.value.projectName,
      sag_G_Index: this.projectPathResponce,
      sno: this.projectPathResponce + 1,
      usrprojId: null
    }
    postdata['data'].push(projInfoObj)
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    this.dbcomparetoolService.saveUserWiseLocalProjectPath(userId, postdata).subscribe(
      (response: any) => { 
        if (response['status'] == 200) {
          this.getUserWiseLocalProjectPath();
          this.saveUserWiseLocalProjectPathresponce = response['data']
        }
        else if (response['status'] == 406) {
          alerts(response['message'])
          let ele = document.getElementById('btn-lclWrkSpace')
          ele.classList.add('active')
          this.activeStepId = 'lclWrkSpace'

        }
      }
    );
  }


  closeModel() {
    this.modalRef.close();
    if (document.querySelector(".close-project-creation")) {
      document.querySelector(".close-project-creation").closest("p-dynamicdialog").remove();
    }

  }

  onClickStepper(stepItem: any, stepperId: any) {
    this.activeStepId = stepperId;
    if (this.activeStepId == 'theme') {
      if (this.projectCreationForm.value.projectName == '') {
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }
    }
    if (this.activeStepId == 'projectSetup') {
      if (this.projectCreationForm.value.projectName == '') {
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }
    }
    if (this.activeStepId == 'techStack') {
      if (this.projectCreationForm.value.projectName == '') {
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }
    }
    if (this.activeStepId == 'lclWrkSpace') {
      if (this.projectCreationForm.value.projectName == '') {
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }
    }
    if (this.activeStepId == 'dbConfig') {
      if (this.projectCreationForm.value.projectName == '') {
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }
    }
    if (this.activeStepId == 'teamNRoles') {
      if (this.projectCreationForm.value.projectName == '') {
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
        return
      }
    }
  }

  pathCreated: boolean
  activeStep = 1
  onPrevNext(activeStepId, type) {
    // if (type == 'prev') {
    //   if (this.activeStepId == 'teamNRoles') {
    //     activeStepId = 'dbConfig'
    //   }
    // }

    let findInd = this.stepperItems.findIndex(elm => elm.id == activeStepId);
    this.activeStep = (type == "next") ? this.stepperItems[findInd + 1]["step"] : this.stepperItems[findInd - 1]["step"];
    this.activeStepId = (type == "next") ? this.stepperItems[findInd + 1]["id"] : this.stepperItems[findInd - 1]["id"];
  

    if (this.activeStepId == 'theme') {
      if (this.projectCreationForm.value.projectName == '') {
        this.activeStepId = 'projNameDetails'
        alerts('Please Enter Project Name')
      }
    }

    if (this.activeStepId == 'dbConfig') {
      if(this.projectCreationForm.value.frontenedGroupId == ''){
        this.activeStepId  = "techStack";
        alerts('Please Select Version');
      }
      if(this.projectCreationForm.value.frontenedGroupId == '--Select--'){
        this.activeStepId  = "techStack";
        alerts('Please Select Version');
      }
      if(this.projectCreationForm.value.backendGroupId == ''){
        this.activeStepId  = "techStack";
        alerts('Please Select Version');
      }
      if(this.projectCreationForm.value.backendGroupId == '--Select--'){
        this.activeStepId  = "techStack";
        alerts('Please Select Version');
      }
    }

    if (this.activeStepId == 'techStack') {
      this.projectCreationForm.controls['backendGroupId'].patchValue(this.backenedGroupDataId);
      this.projectCreationForm.controls['frontenedGroupId'].patchValue(this.frontenedGroupDataId);
      this.getFrontenedFrameworks(this.frontenedGroupDataId);
      this.getBackendFrameworks(this.backenedGroupDataId);
      if (this.projectCreationForm.value.chackBoxValue == true) {
        if (this.pathCreated == true) {
          return;
        }
        else {
          if (this.projectCreationForm.valid) {
            // this.isRunning_Git_Svn_Server();
          } else {
            this.activeStepId = 'projNameDetails'
            alerts('Please Enter Project Name')
          }
        }

      }
    }
  }

  // check angular and java both path exists or not
  angProj: boolean
  javProj: boolean
  prjPath: any
  awSpace: any
  jwSpace: any
  checkPrjExistOrNot() {
    if (this.comparingProjInfo['awspace']) {
      this.dbcomparetoolService.checkProjectPath({ 'projectPath': this.awSpace, }).subscribe((res) => {
        if (res) {
          if (res['count'] == '0') {
            if (((this.awSpace != null || this.jwSpace != null) && (this.awSpace != '' || this.jwSpace != '') &&
              (this.awSpace != null || this.jwSpace != '') && (this.awSpace != '' || this.jwSpace != '') && (this.awSpace != this.jwSpace))) {
              this.writeAngularProject(this.comparingProjInfo)
            }
          }
          else if (res['count'] == '1') {
            if (((this.awSpace != null || this.jwSpace != null) && (this.awSpace != '' || this.jwSpace != '') &&
              (this.awSpace != null || this.jwSpace != '') && (this.awSpace != '' || this.jwSpace != '') && (this.awSpace != this.jwSpace))) {
              this.writeAngularProject(this.comparingProjInfo)
            }
          }
          else if (res['count'] == 'N') {
            alerts(res['msg'])
            return
          }
        }
      });
    }

  }
  checkSvnPrjExistOrNot() {
    if (this.comparingProjInfo['jwspace']) {
      this.dbcomparetoolService.checkProjectPath({ 'projectPath': this.comparingProjInfo['jwspace'].concat(this.prjPath) }).subscribe((res) => {
        if (res) {
          if (res['count'] == '0') {
            this.WriteJavaProjectClick(this.comparingProjInfo)
          } else if (res['count'] == '1') {
            this.WriteJavaProjectClick(this.comparingProjInfo)
          }

          else if (res['count'] == 'N') {
            alerts(res['msg'])
            return
          }
        }
      });
    }

  }
  checkPrjExist() {
    this.checkPrjExistOrNot()
    this.checkSvnPrjExistOrNot()
  }

  createTaskCategoryManual(projectId){
    this.dbcomparetoolService.createTaskCategoryManual(projectId).subscribe((res)=>{
    })
  }



  //save-angular-project
  async writeAngularProject(selectedObj: any) {
    let angPrjPath = `/${selectedObj['projectname']}`
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userId = sessionStoragedatauserId.data.clientInfo.usrId
    const postData = {
      destpath: selectedObj['awspace'].concat(angPrjPath),
      projectname: selectedObj.projectname,
      projectId: selectedObj.projectId,
      userId: userId,
      // ngprojectversion: this.projectCreationForm.value.frontenedGroupId == 2 ? '17' : '8',
      techfgrp_id:this.projectCreationForm.value.frontenedGroupId.toString(),
    }
    this.shareService.loading++;
    let resp = await this.dbcomparetoolService.writeNgProject(postData).toPromise();
    if (resp['status'] == 'success') {
      document.querySelector('.sidebarArea') ?document.querySelector('.sidebarArea').classList.add('d-none'):''
      this.shareService.showBar.next(true)
      success("Successfully created your project");
      this.validationJsonWrite();
      this.regenImgJson_Click(selectedObj);
      if (this.createProjLoad['prjLoad'] == false) {
        this.closeModel()
      }
      if (this.projectCreationForm.value.chackBoxValue ) {
        this.dbcomparetoolService.getProjectIdByName(selectedObj.projectname).subscribe((res) => {
          this.createTaskCategoryManual(res['data'][0]['projectId']);
        })
      }
      this.setPrjVersionObject(postData);
      this.setRepositoryInfoObject(postData)
      this.testConnection()
      if (this.createProjLoad['prjLoad'] == true && this.createProjLoad['platForm'] == 'uiBuilder') {
        this.getLocalProject();
      }
      if (this.createProjLoad['prjLoad'] == true && this.createProjLoad['platForm'] == 'theiaEditor') {
        this.getLocalProjectForTheia()
      }
      
      this.shareService.loading--;
    }
    else {
      this.shareService.loading--;
      alerts("There is already a project in the specified directory !!!...");
    }
  }


  /********* Write java Project **********/
  async WriteJavaProjectClick(selectProjectPath: any) {
    let javaPrjPath = `/${selectProjectPath['projectname']}`
    this.shareService.loading++;
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    if (sessionStoragedatauserId != undefined) {
      let userId = sessionStoragedatauserId.data.clientInfo.usrId;
      const postData = {
        projectName: selectProjectPath.projectname,
        path: selectProjectPath['jwspace'].concat(javaPrjPath),
        projectId: selectProjectPath.projectId,
        userId: userId,

      }
      this.dbcomparetoolService.javaProjectCreate(postData).subscribe(
        (response: any) => {
          this.shareService.loading--;

          if (response) {
            let status = response["data"];
            if (this.comparingProjInfo['awspace'] == '') {
              success('Successfully created your project')
            }
          }
        },
        err => {
          this.shareService.loading--;
        }
      );
    }
  }


  setPrjVersionObject(projectInfo) {
    let angversion: any = this._sagStudioService.versionControlInfo.filter((x: any) => {
      let ang = x['angular'].split('.')
      if (projectInfo['ngprojectversion'] == ang[0]) {
        return x
      }
    })
    if (projectInfo) {
      let data = {
        "projectPath": projectInfo.destpath ? projectInfo.destpath + `/projectVersion.json` : "",
        "confobj": angversion[0],
      }
      this.shareService.savePrjConfObject(data).subscribe((res) => {
      });
    }
  }
  setRepositoryInfoObject(projectInfo) {
    if (projectInfo) {
      let repoInfoObj = {
        'projectName': projectInfo.projectname,
        'projectOnRepository': this.repoPrjExst,
      }
      let data = {
        "projectPath": projectInfo.destpath ? projectInfo.destpath + `/repositoryInfo.json` : "",
        "confobj": repoInfoObj,
      }
      this.shareService.savePrjConfObject(data).subscribe((res) => {
      });
    }
  }

  //  git clone functionality
  async gitCloneClick() {
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValue'))

    const reqObj = {
      "projectName": this.projectCreationForm.value.projectName,
      "userName": sessionStoragedata.username,
    }
    this.shareService.loading++;
    this.dbcomparetoolService.getProjectAlreadyAccessMemberList(reqObj).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response["status"] == 200) {
          this.CloneClick();
        }
        else if (response["status"] == 500) {
          alerts(response.message)
        }
        else if (response["status"] == 409) {
          alerts(response.message)
        }
      }, error => {
        this.shareService.loading--;
        alerts("Error While Fetching")
      }
    );

  }

  // git clone for angular (frontend)
  CloneClick() {
    const sessionStoragedata = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const usersessionStorageData = JSON.parse(sessionStorage.getItem('loginFormValue'))
    const postdata = {
      "projectpath": this.awSpace,
      "userName": usersessionStorageData.username,
      "password": usersessionStorageData.password,
      "repositoryPath": this.gitRepoPath,
      "userId": sessionStoragedata.data.clientInfo.usrId.toString(),
      "projectId": this.projectId
    }
    if ((postdata.repositoryPath != '' && postdata.userName != '' && postdata.password != '') &&
      (postdata.repositoryPath != null && postdata.userName != null && postdata.password != null)) {
      this.shareService.loading++;
      this.dbcomparetoolService.gitprojectclone(postdata).subscribe(
        (response: any) => {
          if (response["status"] == 200) {
            this.shareService.loading--;
            this.checkPrjExistOrNot();
           this.validationJsonWrite();
           
          }
          else if (response["status"] == 500) {
            this.shareService.loading--;
            alerts(response.msg)
          }

        },
        err => {
          this.shareService.loading--;
        }
      );
    }
    else {
      alerts("Please Enter Required  Fields !!!")
    }

  }
  async regenImgJson_Click(selectedObj){
    let valwritePost = {
      "projectId"   : selectedObj['projectId'] ,
      "projectPath" : selectedObj.awspace.split(`/${selectedObj['projectname']}`).join('') ,
      "projectName" : selectedObj['projectname']
    }
   await this.shareService.regen_Img_Json(valwritePost).subscribe(res => { });

  }
  async validationJsonWrite(){
    let writePost = {
      "projectId": this.projectId,
      "destpath": this.awSpace
    } 
    this.shareService.writevalidationJson(writePost).subscribe(res => { });
    //globalmsgList en json file write
    let valwritePost = {
      "projectId": this.projectId,
      "projectPath": this.awSpace
    }
    this.shareService.writeValidationMssg(valwritePost).subscribe(res => { });

  }
  //svn clone for java (backend) and java functionality
  async svnCheckOutClick() {
    const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
    const userid = sessionStoragedatauserId.data.clientInfo.usrId.toString()
    const usersessionStorageData = JSON.parse(sessionStorage.getItem('loginFormValue'))
    const postdata = {
      "checkoutPath": this.comparingProjInfo['jwspace'],
      "username": usersessionStorageData.username,
      "password": usersessionStorageData.password,
      "repositoryPath": this.svnRepoPath,
      "userId": userid,
      "projectPath": this.jwSpace,
      "projectId": this.projectId,
      "selectedPath": this.jwSpace,
    }
    this.shareService.loading++;
    if ((postdata.repositoryPath != '' && postdata.username != '' && postdata.password != '') &&
      (postdata.repositoryPath != null && postdata.username != null && postdata.password != null)) {
      this.dbcomparetoolService.svnProjectChackOut(postdata).subscribe(
        (response: any) => {
          this.shareService.loading--;
          if (response['status'] == 200) {
            if (this.comparingProjInfo['awspace'] == '') {
              success("successfully CheckOut !!!...")
            }
            this.checkSvnPrjExistOrNot()
          }
          else if (response['status'] == 500) {
            alerts(response['message'])
          }
        }
      );
      err => {
        this.shareService.loading--;
      }

    } else {
      alerts("Please Enter Required  Fields !!!");
    }

  }


  async getLocalProject() {
    this.closeModel()
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    await this.setPathButtonClick();
    if (newProj[0]) {
      const postData = {
        destpath: `${newProj[0].awspace}/${newProj[0].projectname}`,
        projectname: newProj[0].projectname,
      }
      this.shareService.loading++;
      const resSagStudioJson = await this.dbcomparetoolService.loadProjectJson(postData).toPromise();
      this.shareService.setData('ctrlopType', resSagStudioJson[0]['projectList'][0]['ctrlsOptType'])
      this.shareService.loading--;
      this._sagStudioService.sagWorkSpace = resSagStudioJson[0];

      if (this._sagStudioService.sagWorkSpace && this._sagStudioService.sagWorkSpace !== undefined) {
        let path = `${newProj[0].awspace}/${newProj[0].projectname}`
        this.getDbConnObj(newProj[0].awspace + `/prjconn.json`);
        await this.getPrjConfObj(newProj[0].projectId);
        await this.projectPathReplaceProjectWise()
        this.getpStylesScss();
        this.getFontFamily(path);
        this.shareService.setDataprotool('UIBuilder', 'true');
        localStorage.setItem('UIBuilder', 'true');
      } else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Something went Wrong !!!',
        });
      }

      this.shareService.propertyWindowJsonData().subscribe(jsonData => {
        this._sagStudioService.propertyWindowJson = jsonData["data"];
      })
      if (window['angularComponentRef'].generateJSON) {
        window['angularComponentRef'].generateJSON();
      }
    }

    if (newProj[0] && newProj[0].projectId) {
      let getResData;
      let obj = {
        "projectId": newProj[0].projectId
      }
      this.shareService.getUsedCssJsProject(obj).subscribe(getRes => {
        getResData = getRes
        if (getResData && getResData != undefined && getResData != null) {
          let recordListOfIndex = {
            "css": [],
            "js": [],
            "projectId": newProj[0].projectId
          };
          for (let res = 0; res < getResData.length; res++) {
            if (getResData[res].type == 'CSS') {
              let cssObj = {
                "fileCode": getResData[res].fileCode,
                "count": getResData[res].fileCount,
              }
              recordListOfIndex["css"].push(cssObj);
            }
            if (getResData[res].type == 'JS') {
              let jsObj = {
                "fileCode": getResData[res].fileCode,
                "count": getResData[res].fileCount,
              }
              recordListOfIndex["js"].push(jsObj);
            }
          }
          this._sagStudioService.recondForIndexFile = recordListOfIndex;
        }
      })
    }
    let mainBody = document.querySelector("body");
    mainBody.classList.add("uiEditorNew");
    this._router.navigate(['dashboard/UIbuilder'])
  }

  setPathButtonClick(setDefault?) {
    let selectedObj: any;
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    let pm: any;
    return pm = new Promise((res, rej) => {
      if (setDefault && this._sagStudioService.selectedProjectData) {
        const sessionStoragedatauserId = JSON.parse(sessionStorage.getItem('loginFormValueUserID'))
        const userId = sessionStoragedatauserId.data.clientInfo.usrId.toString()
        this.dbcomparetoolService.getUserWiseLocalProjectPath(userId).subscribe(
          async (response: any) => {
            if (response) {
              this.getUserWiseLocalProjectPathResponce = await response['data'];
              this.shareService.setDataprotool("getUserWiseLocalProjectPathResponce", response['data']);

              if (this.getUserWiseLocalProjectPathResponce.find((e) => e.projectname == this._sagStudioService.selectedProjectData.projectname)) {
                selectedObj = JSON.parse(JSON.stringify(newProj));
                selectedObj[0].awspace ? selectedObj[0].awspace = `${selectedObj[0].awspace}/${selectedObj[0].projectname}` : false;
                selectedObj[0].jwspace ? selectedObj[0].jwspace = `${selectedObj[0].jwspace}/${selectedObj[0].projectname}` : false;
                //Projects avalable on Repository auther@CP
                if (selectedObj[0] && selectedObj[0].projectGitPath && (selectedObj[0].projectGitPath != null) && (selectedObj[0].projectGitPath != '')
                  && (selectedObj[0].projectGitPath != null) && (selectedObj[0].projectSvnPath != '')) {
                  selectedObj[0]['projectOnRepository'] = true;
                } else {
                  selectedObj[0]['projectOnRepository'] = false;
                }
                this.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj[0])));
                localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj[0]));
                this.shareService.setDatadbtool("projectNameValue", selectedObj[0].projectId);
                this.shareService.setDataprotool("selectedAngularProject", selectedObj[0].awspace);
                return res(true);
              } else {
                this.config.styleClass = "visible";
                return res(false);
              }
            }
          }
        );
      } else {
        const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
        if (newProj.length == 0) {
          this.toast.launch_toast({
            type: 'alert',
            position: 'bottom-right',
            message: `Please Select At Least One File..!`,
          });
          return rej(false);

        }
        selectedObj = JSON.parse(JSON.stringify(newProj));
        selectedObj[0].awspace ? selectedObj[0].awspace = `${selectedObj[0].awspace}/${selectedObj[0].projectname}` : false;
        selectedObj[0].jwspace ? selectedObj[0].jwspace = `${selectedObj[0].jwspace}/${selectedObj[0].projectname}` : false;
        //Projects avalable on Repository auther@CP
        if (selectedObj[0] && selectedObj[0].projectGitPath && (selectedObj[0].projectGitPath != null) && (selectedObj[0].projectGitPath != '')
          && (selectedObj[0].projectGitPath != null) && (selectedObj[0].projectSvnPath != '')) {
          selectedObj[0]['projectOnRepository'] = true;
        } else {
          selectedObj[0]['projectOnRepository'] = false;
        }
        this.shareService.setDataprotool("selectedProjectChooseData", JSON.parse(JSON.stringify(selectedObj[0])));
        localStorage.setItem("selectedProjectChooseData", JSON.stringify(selectedObj[0]));
        this.shareService.setDatadbtool("projectNameValue", selectedObj[0].projectId);
        this.shareService.setDataprotool("selectedAngularProject", selectedObj[0].awspace);
        res(true);
      }
    });
  }

  getDbConnObj(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getPrjConfObject(dataJson).subscribe((res) => {
      if (res['status'] == 'success') {
        let dbInfo = res['confobj'];
        dbInfo['operation'] = 'COMPARESINGLE';
        dbInfo['targetDataSource'] = {};
        dbInfo['details'] = {
          software: [],
          year: [],
          client: [],
          columns: [],
          operation: ['']
        }
        this.shareService.setDatadbtool('finalDataForConnection', dbInfo);
      }
    });
  }
  // get project conf Object
  getPrjConfObj(path) {
    let dataJson = {
      projectId: path
    }
    this.shareService.getProjectVersion(dataJson).subscribe(async (res) => {
      this.shareService.setData('angversnObj', res)
      let versionControl = this._sagStudioService.versionObject(res)
      if (res['status'] == 'success' && !ObjectCompare(versionControl[0], res)) {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: "PROJECT JSON VERSION  MISMATCH",
        });
        let conf = await ui.confirm("Do You Want To Update Project JSON Version? ");
        if (conf == true) {
          await this.openVersionCheckMappingModal(res);
        }
        // log out code
        else {
          this.firststepProjectService.logout().subscribe(
            (data) => {
              localStorage.clear();
              this.shareService.clearAllData();
              this.firststepProjectService.unAuthorizeCalllback();
            }
          );
        }
      }
      // project loaded successfull
      else {
        this.toast.launch_toast({
          type: 'success',
          position: 'bottom-right',
          message: 'Successfully Loaded Your Project !!!',
        });
        this._sagStudioService.currentActiveProject = this._sagStudioService.sagWorkSpace.projectList.find(item => item.id == 'defaultProject1618079400000');
        this._sagStudioService.initSagWorkSpaceJSON("arg1", "arg2");
        this.onGetMobileTheme();
        this._sagStudioService.getAvailModsList();
        // this.close('projectLoaded');
      }
    });

    function ObjectCompare(o1, o2) {

      if (typeof o1 !== 'object' || typeof o2 !== 'object') {
        return false; // we compare objects only!
      }
      // when one object has more attributes than the other - they can't be eq
      if (Object.keys(o1).length !== Object.keys(o2).length) {
        return false;
      }
      for (let k of Object.keys(o1)) {
        if (o1[k] !== o2[k]) {
          return false;
        }
      }
      return true;
    }
  }



  projectPathReplaceProjectWise() {
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    const reqObj = {
      javaworkspace: `${newProj[0].jwspace}/${newProj[0].projectname}`,
      angworkspace: `${newProj[0].awspace}/${newProj[0].projectname}`,
    }
    this.shareService.loading++;
    this.dbcomparetoolService.projectPathReplace(reqObj).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response['status'] == 200) {
        }
        else if (response['status'] == 500) {
          alerts(response.msg);
        }
      }, error => {
      }
    );
  }
  projectPathReplaceProjectWiseForTheia() {
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    const reqObj = {
      javaworkspace: `${newProj[0].jwspace}/${newProj[0].projectname}`,
      angworkspace: `${newProj[0].awspace}/${newProj[0].projectname}`,
    }
    this.shareService.loading++;
    this.dbcomparetoolService.projectPathReplace(reqObj).subscribe(
      (response: any) => {
        this.shareService.loading--;
        if (response['status'] == 200) {
          this.shareService.loading++;
          this.shareService.setDataprotool("loadDataTreeType", "projectType");
          if (!document.getElementById('scriptLoadID')) {
            localStorage.setItem('editorLoading', 'true');
            this.addScript(this.shareService.editorLoadPath);
          } else {
            this.showEditor('show');
          }

          localStorage.setItem('openProject', 'false');
          localStorage.setItem('projectUtility', 'true');

        }
        else if (response['status'] == 500) {
          alerts(response.msg);
        }
      }, error => {
      }
    );
  }

  showEditor(type) {
    if (type == "hide" && document.getElementById('theia-app-shell')) {
      document.getElementById('theia-app-shell').style.visibility = "hidden";
      document.getElementById('theia-left-right-split-panel').style.visibility = "hidden";
      document.getElementById('theia-left-content-panel').style.visibility = "hidden";
      document.getElementById('theia-bottom-split-panel').style.visibility = "hidden";
      document.getElementById('theia-main-content-panel').style.visibility = "hidden";
      document.getElementById('theia-right-content-panel').style.visibility = "hidden";
      let leftBar = document.querySelector("#theia-left-content-panel .theia-app-sidebar-container");
      if (leftBar)
        (<HTMLElement>leftBar).style.visibility = 'hidden';

      this.shareService.hideEditorAreia();
    } else if (document.getElementById('theia-app-shell')) {
      document.getElementById('theia-app-shell').style.visibility = "visible";
      document.getElementById('theia-left-right-split-panel').style.visibility = "visible";
      document.getElementById('theia-left-content-panel').style.visibility = "visible";
      document.getElementById('theia-bottom-split-panel').style.visibility = "visible";
      document.getElementById('theia-main-content-panel').style.visibility = "visible";
      document.getElementById('theia-right-content-panel').style.visibility = "visible";
      let leftBar = document.querySelector("#theia-left-content-panel .theia-app-sidebar-container");
      if (leftBar)
        (<HTMLElement>leftBar).style.visibility = 'visible';

      this.shareService.showEditorAriea();
    }
  }


  addScript(path) {
    var head = document.getElementsByTagName("head")[0];
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = path;
    s.id = "scriptLoadID";
    var script = document.getElementById('scriptLoadID');
    if (script != null) {
      head.removeChild(script);
    }
    head.appendChild(s);
  }

  async newFunc(): Promise<void> {
    //  setTimeout( () => {
    document.querySelector('body').classList.remove('uiEditorNew');
    document.getElementById('sdmtDarkModeId').classList.contains('sdmtDarkMode') ? document.getElementById('sdmtDarkModeId').classList.remove('sdmtDarkMode') : false;
    // await this.shareService.getAccessRights();
    this.newContact('project_type');
    this.shareService.loading--;
    success("Project Loaded Successfully !!!...");
    localStorage.setItem('editorLoading', 'false');
    // }, 4500);
  }

  newContact(route) {
    this.selectedTab = route;
    this.firststepProjectService.projectHeaderActiveTab.next(route);
    this._router.navigate(["dashboard/database/projectToolFirst/newprojectinfo/project_type"]).then(() => {
      this.closeModel()

    });
  }
  theiaProjectLoad() {

    this.createProject(true, 'theiaEditor');

  }

  async getpStylesScss() {
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    const fullPath = this._sagStudioService.getLocalFilePath("/src/styles.scss");
    const postData = {
      "destpath": `${newProj[0].awspace}/${newProj[0].projectname}/src/styles.scss`,
      "projectName": `${newProj[0].projectname}`,
      "projectSubtype": "scss"
    };
    this.shareService
      .getPageJson(postData)
      .subscribe((respJson) => {
        this._sagStudioService.currentActiveProject.subDataArray.push(...respJson['data']);
        const styleScssObj = this._sagStudioService.currentActiveProject.subDataArray.find(e => e["matchableId"] == `customfile~${newProj[0].projectname}$src$styles.scss`)
        this._sagStudioService.pStylesScss = styleScssObj;
      });
  }


  // get Font FamilyList in  project
  getFontFamily(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getFontFamilyList(dataJson).subscribe(async (res) => {
      this._sagStudioService.fontFamilyList = res || [];

    });


  }
  onGetMobileTheme() {
    const newProj = this.getUserWiseLocalProjectPathResponce.filter(ele => ele.projectname == this.projectCreationForm.value.projectName)
    const postData = {
      "projectName": `${newProj[0].projectname}`,
    };
    this.shareService
      .getMobileTheme(postData)
      .subscribe(res => {
        if (res) {
          this._sagStudioService.mobileAppTheme = res["mobileTheme"];
        }
      });
  }
  openVersionCheckMappingModal(data) {
    const ref = this.dialogService.open(VersionControlMappingComponent, {
      header: "Version Control",
      width: "80%",
      contentStyle: { height: "500px" },
      data: data
    });
  }

  browseFile(event: any, langName: any) {
    if (langName == 'setAngular') {
      console.log(event.target.files.webkitRelativePath, "event targetter files")
    }
    if (langName == 'setJava') { }
  }


  async isRunning_Git_Svn_Server() {
    let res_checkGitServer: any = await this.dbcomparetoolService.checkRemoteGitServer().toPromise().catch((err) => { this.shareService.loading--; alerts("Error While Fetching") });
    if (res_checkGitServer['status'] == 200) {
      let res_checkSvnServer: any = await this.dbcomparetoolService.checkRemoteSvnServer().toPromise().catch((err) => { this.shareService.loading--; alerts("Error While Fetching") });
      if (res_checkSvnServer['status'] == 200) {
        this.createGit_SvnRepoServer();
      } else if (res_checkSvnServer['status'] == 500) {
        alerts(res_checkSvnServer['message']);
      }
    } else if (res_checkGitServer['status'] == 500) {
      alerts(res_checkGitServer['message']);
    }

  }

  async createGit_SvnRepoServer() {
    var id = document.getElementById(`btn-${this.activeStepId}`)
    const gitpostData = {
      "userName": this.sessionStoragedata.username,
      "projectName": this.projectCreationForm.value.projectName
    };
    const svnpostData = {
      "repoName": this.projectCreationForm.value.projectName,
      "username": this.sessionStoragedata.username,
    };

    let res_createGitRepo: any = await this.dbcomparetoolService.createGitRepoServer(gitpostData).toPromise().catch(err => { this.shareService.loading--; alerts("Error While Fetching") });
    if (res_createGitRepo['status'] == 200) {

      let res_createSvnRepo: any = await this.dbcomparetoolService.createSvnRepoServer(svnpostData).toPromise().catch(err => { this.shareService.loading--; alerts("Error While Fetching") });
      if (res_createSvnRepo['status'] == 200) {
        this.gitRepoPath = res_createGitRepo.gitRepoPath;
        this.svnRepoPath = res_createSvnRepo.svnRepoPath;

        this.projectCreationForm.patchValue({
          gitRepoPath: this.gitRepoPath,
          svnRepoPath: this.svnRepoPath
        })
        this.pathCreated = true;
        this.createProjectDb(this.gitRepoPath, this.svnRepoPath);
        this.createProjectPmt();

      } else if (res_createSvnRepo['status'] == 500 || res_createSvnRepo['status'] == 409 || res_createSvnRepo['status'] == 204) {
        alerts(res_createSvnRepo['msg']);
      }
    }
    else if (res_createGitRepo['status'] == 500 || res_createGitRepo['status'] == 409) {
      alerts(res_createGitRepo['msg']);
    }

  }


  createBlnkProj() {
    var id = document.getElementById(`btn-${this.activeStepId}`)
    if (this.projectCreationForm.valid) {
      const postData = {
        projectName: this.projectCreationForm.value.projectName,
        gitrepopath: this.gitRepoPath,
        svnrepopath: this.svnRepoPath,
        securityType: this.projectCreationForm.value.SecurityType,
        secretKey: this.projectCreationForm.value.SecretKey
      };
      this.shareService.loading++;
      this.dbcomparetoolService.createProjectDbData(postData).subscribe(
        (response: any) => {
          this.shareService.loading--;
          if (response['status'] == 200) {
            // this.projectId =response['pId']
            success(response.msg);
          }
          if (response['status'] == 500) {
            alerts(response.msg);
          }
        },
        err => {
          this.shareService.loading--;
          alerts("Error While Fetching")
        }
      )
    }
    else {
      this.activeStepId = 'projNameDetails'
      alerts('Please Enter Project Name')
    }
  }

  async getLocalProjectForTheia() {
    await this.setPathButtonClick();
    this.shareService.setDataprotool('modeTreeData', []);
    this.shareService.setDataprotool('lockUnlockData', []);
    let selectedObj = this.shareService.getDataprotool("selectedProjectChooseData");
    this.shareService.modeBoolean = true;
    if (window['angularComponentRef'].setProjectAlldetails) {
      const callFun = window['angularComponentRef'].setProjectAlldetails;
      callFun(selectedObj);
    }
    await this.shareService.getAccessRights();
    if (selectedObj) {
      const postData = {
        destpath: selectedObj.awspace,
        projectname: selectedObj.projectname,
      }
      this.shareService.loading++;
      const resSagStudioJson = await this.dbcomparetoolService.loadProjectJson(postData).toPromise();
      this.shareService.setData('ctrlopType', resSagStudioJson[0]['projectList'][0]['ctrlsOptType'])
      this.shareService.loading--;
      this._sagStudioService.sagWorkSpace = resSagStudioJson[0];
      if (this._sagStudioService.sagWorkSpace || this._sagStudioService.sagWorkSpace == undefined) {
        this.getDbConnObj(selectedObj.awspace + `/prjconn.json`);
        await this.getPrjConfObj(selectedObj.projectId);
        this.getpStylesScssforTheia();
        this.getFontFamilyforTheia(selectedObj.awspace);
        this.selectedTab = 'project_type';
        this.projectPathReplaceProjectWiseForTheia();
      } else {
        this.toast.launch_toast({
          type: 'alert',
          position: 'bottom-right',
          message: 'Something went Wrong !!!',
        });
      }
      this.shareService.propertyWindowJsonData().subscribe(jsonData => {
        this._sagStudioService.propertyWindowJson = jsonData["data"];
      })
    }
  }
  async getpStylesScssforTheia() {
    const selectedProjectChooseData = this.shareService.getDataprotool("selectedProjectChooseData");
    const fullPath = this._sagStudioService.getLocalFilePath("/src/styles.scss");
    const postData = {
      "destpath": fullPath,
      "projectName": `${selectedProjectChooseData.projectname}`,
      "projectSubtype": "scss"
    };
    this.shareService
      .getPageJson(postData)
      .subscribe((respJson) => {
        this._sagStudioService.currentActiveProject.subDataArray.push(...respJson['data']);
        const styleScssObj = this._sagStudioService.currentActiveProject
          .subDataArray
          .find(e => e["matchableId"] == `customfile~${selectedProjectChooseData.projectname}$src$styles.scss`)
        this._sagStudioService.pStylesScss = styleScssObj;
      });
  }
  getFontFamilyforTheia(path) {
    let dataJson = {
      projectPath: path
    }
    this.shareService.getFontFamilyList(dataJson).subscribe(async (res) => {
      this._sagStudioService.fontFamilyList = res || [];
    });
  }

  //select angular version
  selectVersion(event: any) {
    this.projectCreationForm.value.angularVersion = event.target.value
  }
}
