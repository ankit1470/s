import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BCreateProjectStepperRoutingModule } from './b-create-project-stepper-routing.module';
import { ColorPickerModule } from 'ngx-color-picker';
import { SharedModule } from 'src/app/core/shared/shared.module';
import { BCreateProjectStepperComponent } from './b-create-project-stepper.component';



@NgModule({
  declarations: [BCreateProjectStepperComponent],
  imports: [
    CommonModule,
    BCreateProjectStepperRoutingModule,
    SharedModule,
    ColorPickerModule
  ]
})
export class BCreateProjectStepperModule { }
