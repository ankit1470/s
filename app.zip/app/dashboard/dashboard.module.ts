import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MonacoEditorModule } from 'ngx-monaco-editor';
import { SharedModule } from '../core/shared/shared.module';
import { CreateProjectComponent } from '../modules/database/project-utility-tool/procompare-tool/pmt/create-project/create-project.component';
import { ProjectCreationComponent } from '../modules/database/project-utility-tool/procompare-tool/pmt/create-project/project-creation/project-creation.component';
import { TaskProgressComponent } from '../modules/database/project-utility-tool/procompare-tool/pmt/task-progress/task-progress.component';
import { TestCasePopComponent } from '../modules/database/project-utility-tool/procompare-tool/pmt/test-case/test-case-pop/test-case-pop.component';
import { AngularFileRightsComponent } from '../modules/database/project-utility-tool/procompare-tool/project-type/angular-file-rights/angular-file-rights.component';
import { FileRightComponent } from '../modules/database/project-utility-tool/procompare-tool/project-type/file-rights/file-right/file-right.component';
import { FileRightsModule } from '../modules/database/project-utility-tool/procompare-tool/project-type/file-rights/file-rights.module';
import { JavaAngRelatedfilesComponent } from '../modules/database/project-utility-tool/procompare-tool/project-type/java-ang-relatedfiles/java-ang-relatedfiles.component';
import { LinkFilePageComponent } from '../modules/database/project-utility-tool/procompare-tool/project-type/menu-file-data-linking/link-file-page/link-file-page.component';
import { MenuFileDataLinkingComponent } from '../modules/database/project-utility-tool/procompare-tool/project-type/menu-file-data-linking/menu-file-data-linking.component';
import { ModulesPackagesLinkComponent } from '../modules/database/project-utility-tool/procompare-tool/project-type/modules-packages-link/modules-packages-link.component';
import { WorkAssignComponent } from '../modules/database/project-utility-tool/procompare-tool/project-type/work-assign/work-assign.component';
import { MenuMappingComponent } from '../modules/sag-studio/modules-drop/modules/menu-mapping/menu-mapping.component';
import { MappingControlsComponent } from '../modules/sag-studio/property-window/mapping-controls/mapping-controls.component';
import { ThemeGeneratorComponent } from '../modules/sag-studio/theme-generator/theme-generator.component';
import { SdmtDashboardModule } from '../modules/sdmt-dashboard/sdmt-dashboard.module';
import { AddModuleComponent } from './add-module/add-module.component';
import { BuildMobileAppComponent } from './build-mobile-app/build-mobile-app.component';
import { ChooseProjectComponent } from './choose-project/choose-project.component';
import { AddIndexHtmlLinkScriptComponent } from './configure-approval/add-index-html-link-script/add-index-html-link-script.component';
import { ConfigureApprovalComponent } from './configure-approval/configure-approval.component';
import { CreateProjectStepperComponent } from './create-project-stepper/create-project-stepper.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { DatabaseConnectionComponent } from './database-connection/database-connection.component';
import { GenerateApkComponent } from './generate-apk/generate-apk.component';
import { GitPermissionComponent } from './git-permission/git-permission.component';
import { ModuleOwnerComponent } from './module-owner/module-owner.component';
import { PendingApprovalFilesComponent } from './pending-approval-status/pending-approval-files/pending-approval-files.component';
import { PendingApprovalStatusComponent } from './pending-approval-status/pending-approval-status.component';
import { BackEndConfigComponent } from './projectConfig/back-end-config/back-end-config.component';
import { CreateJavaProjectComponent } from './projectConfig/create-java-project/create-java-project.component';
import { FrontEndConfigComponent } from './projectConfig/front-end-config/front-end-config.component';
import { GitSvnComponent } from './projectConfig/git-svn/git-svn.component';
import { SaveAllFileComponent } from './save-all-file/save-all-file.component';
import { SaveStudioFilesComponent } from './save-studio-files/save-studio-files.component';
import { BundleComponent } from "./sdmtTools/bundle/bundle.component";
import { CategoryListComponent } from './sdmtTools/bundle/category-list/category-list.component';
import { ModuleSetComponent } from "./sdmtTools/module-set/module-set.component";
import { TempPageModalComponent } from './sdmtTools/template-pages/temp-page-modal/temp-page-modal.component';
import { TemplatePagesComponent } from "./sdmtTools/template-pages/template-pages.component";
import { TemplatesComponent } from './sdmtTools/templates/templates.component';
import { AngUpdateVersionFileComponent } from './user-work-version/ang-update-version-file/ang-update-version-file.component';
import { JavaUpdateVersionFileComponent } from './user-work-version/java-update-version-file/java-update-version-file.component';
import { UserWorkVersionComponent } from './user-work-version/user-work-version.component';
import { VersionControlMappingComponent } from './version-control-mapping/version-control-mapping.component';
import { RightsComponent } from './rights/rights.component';
import { WipthemesComponent } from './sdmtTools/wipthemes/wipthemes.component';
import { PropertiesComponent } from './sdmtTools/properties/properties.component';
import { ProjectOperationsComponent } from './project-operations/project-operations.component';
import { MappingControlsModule } from '../modules/sag-studio/property-window/mapping-controls/mapping-controls.module';
import { ControlsComponent } from './sdmtTools/controls/controls.component';
import { GlobalPropertysComponent } from './global-propertys/global-propertys.component';
import { SaveLabelValueGridComponent } from './sdmtTools/properties/save-label-value-grid/save-label-value-grid.component';
import { LdvComponent } from '../modules/sag-studio/ldv/ldv.component';
import { ImportExportMappingComponent } from './import-export-mapping/import-export-mapping.component';
import { FileImportExportMappingComponent } from './import-export-mapping/file-import-export-mapping/file-import-export-mapping.component';
import { ExcelSheetImportExportMappingComponent } from './import-export-mapping/excel-sheet-import-export-mapping/excel-sheet-import-export-mapping.component';
import { JsonImportExportMappingComponent } from './import-export-mapping/json-import-export-mapping/json-import-export-mapping.component';
import { ExcelImportExportViewComponent } from './import-export-mapping/excel-import-export-view/excel-import-export-view.component';
import { CopyContentComponent } from './configure-approval/copy-content/copy-content.component';
import { ImportExportVarriableComponent } from './import-export-mapping/import-export-varriable/import-export-varriable.component';
import { ExportReportMappingComponent } from './import-export-mapping/export-report-mapping/export-report-mapping.component';
import { ImportExportValidationComponent } from './import-export-mapping/import-export-validation/import-export-validation.component';
import { ImportExportManualCodeComponent } from './import-export-mapping/import-export-manual-code/import-export-manual-code.component';
import { JavaApiGeneratorComponent } from './java-api-generator/java-api-generator.component';
import { JavaApiMappingComponent } from './java-api-generator/java-api-mapping/java-api-mapping.component';
import { JavaDatabaseFunctionApplyComponent } from './java-api-generator/java-database-function-apply/java-database-function-apply.component';
import { JavaApiManualCodeComponent } from './java-api-generator/java-api-manual-code/java-api-manual-code.component';
import { NewupdateComponent } from './newupdate/newupdate.component';

import { StudioProjectListComponent } from './studio-project-list/studio-project-list.component';
import { StudioProjectListModule } from './studio-project-list/studio-project-list.module';
import {ToggleButtonModule} from 'primeng/togglebutton';
import { BCreateProjectStepperComponent } from './b-create-project-stepper/b-create-project-stepper.component';
import { ModelTwoComponent } from '../modules/sag-studio/model-two/model-two.component';
import { UpdateJavaFileComponent } from './update-java-version/update-java-file/update-java-file.component';
import { JavaApiRegenerateComponent } from './update-java-version/java-api-regenerate/java-api-regenerate.component';
import { MetaDataComponent } from './configure-approval/meta-data/meta-data.component';
import { SiteMapComponent } from './configure-approval/site-map/site-map.component';
import { RobotsTxtGeneratorComponent } from './configure-approval/robots-txt-generator/robots-txt-generator.component';
import { SsrInfoComponent } from './configure-approval/ssr-info/ssr-info.component';
import { MetaDataGridComponent } from './configure-approval/meta-data-grid/meta-data-grid.component';
import { JavaSsrInfoComponent } from './configure-approval/java-ssr-info/java-ssr-info.component';
import { EditorDiffChangeComponent } from '../modules/database/project-utility-tool/procompare-tool/project-type/sag-editor/editor-diff-change/editor-diff-change.component';
import { ProjectCommonFileComponent } from './configure-approval/project-common-file/project-common-file.component';
import { VoiceControlComponent } from '../modules/sag-studio/voice-control/voice-control.component';
import { DbScriptComponent } from './configure-approval/db-script/db-script.component';
import { FileTemplateMappingComponent } from './template-mapping/file-template-mapping/file-template-mapping.component';
import { ControlCopyComponent } from './control-copy/control-copy.component';
import { DefaultMetaComponent } from './configure-approval/default-meta/default-meta.component';
 
import { ImagePreviewComponent } from './configure-approval/meta-data/image-preview/image-preview.component';
import { ProjectSecuritySelectApiComponent } from './project-security/project-security-select-api/project-security-select-api.component';
import { CreateProjectBackupComponent } from './create-project-backup/create-project-backup.component';
import { ProjectSecurityProviderConfigurationComponent } from './project-security/project-security-provider-configuration/project-security-provider-configuration.component';
import { ProjectSecurityComponent } from './project-security/project-security.component';
import { ImgMappingComponent } from './generate-mapping-file/img-mapping/img-mapping.component';
 
import { RegexGeneratorComponent } from './regex-generator/regex-generator.component';
import { LangContentMappingComponent } from './generate-mapping-file/lang-content-mapping/lang-content-mapping.component';



@NgModule({
  declarations: [DashboardComponent, UserWorkVersionComponent, ProjectOperationsComponent,ImgMappingComponent, LangContentMappingComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    SharedModule,
    SdmtDashboardModule,
    MonacoEditorModule,
    ReactiveFormsModule,
    FileRightsModule,
    MappingControlsModule,
    StudioProjectListModule,
    ToggleButtonModule
  ],
  entryComponents: [
    ChooseProjectComponent,
    JavaAngRelatedfilesComponent,
    CreateProjectComponent,
    SaveStudioFilesComponent,
    BackEndConfigComponent,
    FrontEndConfigComponent,
    AddModuleComponent,
    CreateJavaProjectComponent,
    ProjectCreationComponent,
    GitSvnComponent,
    SaveAllFileComponent,
    DatabaseConnectionComponent,
    TestCasePopComponent,
    GenerateApkComponent,
    GitPermissionComponent,
    WorkAssignComponent,
    ModuleOwnerComponent,
    ModulesPackagesLinkComponent,
    PendingApprovalStatusComponent,
    PendingApprovalFilesComponent,
    VersionControlMappingComponent,
    UserWorkVersionComponent,
    JavaUpdateVersionFileComponent,
    AngUpdateVersionFileComponent,
    BuildMobileAppComponent,
    ThemeGeneratorComponent,
    ConfigureApprovalComponent,
    MappingControlsComponent,
    CreateProjectStepperComponent,
    BCreateProjectStepperComponent,
    MenuMappingComponent,
    MenuFileDataLinkingComponent,
    LinkFilePageComponent,
    AddIndexHtmlLinkScriptComponent,
    BundleComponent,
    ModuleSetComponent,
    TemplatePagesComponent,
    TemplatesComponent,
    CategoryListComponent,
    TempPageModalComponent,
    FileRightComponent,
    AngularFileRightsComponent,
    TaskProgressComponent,
    RightsComponent,
    WipthemesComponent,
    PropertiesComponent,
    ControlsComponent,
    GlobalPropertysComponent,
    SaveLabelValueGridComponent,
    LdvComponent,
    JsonImportExportMappingComponent,
    ImportExportMappingComponent,
    FileImportExportMappingComponent,
    ExcelSheetImportExportMappingComponent,
    ExcelImportExportViewComponent ,CopyContentComponent,
    ImportExportVarriableComponent,
    ExportReportMappingComponent,
    ImportExportValidationComponent,
    ImportExportManualCodeComponent,
    JavaApiGeneratorComponent,
    JavaApiMappingComponent,
    JavaDatabaseFunctionApplyComponent,
    JavaApiManualCodeComponent,
    NewupdateComponent,
    ModelTwoComponent,
    UpdateJavaFileComponent,
    JavaApiRegenerateComponent,
    MetaDataComponent,
    SiteMapComponent,
    RobotsTxtGeneratorComponent,
    SsrInfoComponent,
    MetaDataGridComponent,
    JavaSsrInfoComponent,
    EditorDiffChangeComponent,
    ProjectCommonFileComponent,
    VoiceControlComponent,
    DbScriptComponent,
    ExportReportMappingComponent,
    FileTemplateMappingComponent,
    ControlCopyComponent,
    DefaultMetaComponent,
    ImagePreviewComponent,
    ProjectSecuritySelectApiComponent,
    CreateProjectBackupComponent,
    ProjectSecurityProviderConfigurationComponent,
    ProjectSecurityComponent,
    RegexGeneratorComponent
  ],

  exports: [DashboardComponent, ProjectOperationsComponent,ImgMappingComponent,LangContentMappingComponent]

})
export class DashboardModule { }
