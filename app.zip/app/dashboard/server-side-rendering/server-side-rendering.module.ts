import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServerSideRenderingRoutingModule } from './server-side-rendering-routing.module';
import { ServerSideRenderingComponent } from './server-side-rendering.component';


@NgModule({
  declarations: [ServerSideRenderingComponent],
  imports: [
    CommonModule,
    ServerSideRenderingRoutingModule
  ],
  exports:[ServerSideRenderingComponent]
})
export class ServerSideRenderingModule { }
