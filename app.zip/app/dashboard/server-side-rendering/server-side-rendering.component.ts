import { Component, OnInit } from '@angular/core';
import { ProcomparetoolService } from 'src/app/services/project-utility-tool/procomparetool.service';
import { SagShareService } from 'src/app/services/sagshare.service';
declare var SdmtGridT;
declare function alerts(m): any;
declare function success(m): any;
declare var $: any;
@Component({
  selector: 'app-server-side-rendering',
  templateUrl: './server-side-rendering.component.html',
  styleUrls: ['./server-side-rendering.component.scss']
})
export class ServerSideRenderingComponent implements OnInit {
  gridDynamicObj_ssrgenerate:any;
  gridData_ssrgenerate:any;
  gridDynamicObj_packageAccessSSR:any;
  gridData_packageAccessSSR:any;
  gridData_fileAccessSSR:any;
  gridDynamicObj_fileAccessSSR:any;
  accessKey:any = "";
  accessMessage:string ="";
  constructor(public shareService: SagShareService,
              private ProCompareToolService: ProcomparetoolService,
  ) { }

  ngOnInit() {
    this.getGenerateRenderApiList();
  }
  columnData_ssrgenerate: any = [
    {
      "header": "S.No",
      "field": "sno",
      "width": "50px",
      "hidden": false,
      "editable": "false",
      "filter": false,
      "search": true,
      "component": "label",
      "freezecol": "null",
      "text-align": "center"
    },
    {
      "hidden": false,
      "search": false,
      "cellHover": false,
      "text-align": "center",
      "editable": "false",
      "sort": false,
      "filter": false,
      "component": "headerCheckBox",
      "field": "isSSREnable",
      "freezecol": "null",
      "width": "100px",
      "header": "",
      "cellRenderView": true,

    },
   
    {
      "header": "Meta Route Name",
      "field": "routes_name",
      "filter": false,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Route Path",
      "field": "routes_path",
      "filter": false,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },

  ];
  rowData_ssrgenerate: any = [
    {},
    {},
    {},
    {}
  ];

  ssrgenerateGrid(rowData?, colData?) {
    let self = this;

    this.gridData_ssrgenerate = {
      columnDef: colData ? colData : this.columnData_ssrgenerate,
      rowDef: rowData ? rowData : this.rowData_ssrgenerate,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          //self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          // self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          // self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("ssrgenerateGridId");
    if (sourceDiv != null) {
      this.gridDynamicObj_ssrgenerate = SdmtGridT(sourceDiv, this.gridData_ssrgenerate, true, true);
    }
  }

  getGenerateRenderApiList(){
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");

    this.ProCompareToolService.getSSRroutingList(__project_Details.projectId).subscribe((res)=>{
      console.log(res["data"]);
      if(res["status"] == 200){
        this.ssrgenerateGrid(res["data"]);
      }else{
        this.ssrgenerateGrid();
      }
    })
  }
  generateRenderApi(){
    let routingList =[];
    const __project_Details = this.shareService.getDataprotool("selectedProjectChooseData");
     this.gridDynamicObj_ssrgenerate.sagGridObj["originalRowData"].map(ele =>{
      let obj = ele;
      if(ele["isSSREnable"] == 1 || ele["isSSREnable"] == true){
        routingList.push(obj);
      }
    });
    let postObj = {
      "projectId": __project_Details.projectId,
      "projectPath": __project_Details.jwspace,
      "userId": __project_Details.userId,
      "routingList": routingList,
    };

    this.ProCompareToolService.generateServerSideRendering(postObj).subscribe((res)=>{
      if(res["status"] == 200){
        success(res["msg"]);
        this.getGenerateRenderApiList();
      }
      else if(res["status"] == 401){
         this.accessMessage = res["message"];
        this.accessKey = "package";
        $("#ssrPackageAccessId").modal('show');
        setTimeout(()=>{this.packageAccessSSRGrid(res["data"]);},20)
        
      }
      else if(res["status"] == 402){
        this.accessMessage = res["message"];
        $("#ssrPackageAccessId").modal('show');
        this.accessKey = "file";
        setTimeout(()=>{this.fileAccessSSRGrid(res["data"]);},20)
       }
      else{
        alerts(res["msg"])
      }
    });
  }

  columnData_packageAccessSSR: any = [
    {
      "header": "S.No",
      "field": "sno",
      "width": "50px",
      "hidden": false,
      "editable": "false",
      "filter": false,
      "search": true,
      "component": "label",
      "freezecol": "null",
      "text-align": "center"
    },
       
    {
      "header": "Package Name",
      "field": "packageName",
      "filter": false,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Package Path",
      "field": "packagePath",
      "filter": false,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },

  ];
  rowData_packageAccessSSR: any = [
    {},
    {},
    {},
    {}
  ];

  packageAccessSSRGrid(rowData?, colData?) {
    let self = this;

    this.gridData_packageAccessSSR = {
      columnDef: colData ? colData : this.columnData_packageAccessSSR,
      rowDef: rowData ? rowData : this.rowData_packageAccessSSR,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          //self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          // self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          // self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("packageAccessSSRGridId");
    if (sourceDiv != null) {
      this.gridDynamicObj_packageAccessSSR = SdmtGridT(sourceDiv, this.gridData_packageAccessSSR, true, true);
    }
  }

  columnData_fileAccessSSR: any = [
    {
      "header": "S.No",
      "field": "sno",
      "width": "50px",
      "hidden": false,
      "editable": "false",
      "filter": false,
      "search": true,
      "component": "label",
      "freezecol": "null",
      "text-align": "center"
    },
       
    {
      "header": "File Path",
      "field": "srcfileUniqePath",
      "filter": false,
      "width": "300px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    // {
    //   "header": "Package Path",
    //   "field": "packagePath",
    //   "filter": false,
    //   "width": "300px",
    //   "editable": "false",
    //   "text-align": "left",
    //   "search": true,
    //   "component": "label",
    //   "cellRenderView": false,
    //   "freezecol": "null",
    //   "hidden": false,
    //   "sort": false,
    //   "cellHover": false,

    // },

  ];
  rowData_fileAccessSSR: any = [
    {},
    {},
    {},
    {}
  ];

  fileAccessSSRGrid(rowData?, colData?) {
    let self = this;

    this.gridData_fileAccessSSR = {
      columnDef: colData ? colData : this.columnData_fileAccessSSR,
      rowDef: rowData ? rowData : this.rowData_fileAccessSSR,
      footer_hide: false,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          //self.onavailableinprojectCellClick();
        },
        "onRowClick": function () {
          // self.onavailableinprojectClick();
        },
        "onRowDbleClick": function () {
          // self.onavailableinprojectdblClick();
        }
      }
      ,
      rowCustomHeight: 20,
    };

    let sourceDiv = document.getElementById("fileAccessSSRGridId");
    if (sourceDiv != null) {
      this.gridDynamicObj_fileAccessSSR = SdmtGridT(sourceDiv, this.gridData_fileAccessSSR, true, true);
    }
  }
}
