import { Component, OnInit } from '@angular/core';
import { SagShareService } from 'src/app/services/sagshare.service';
import { DynamicDialogRef } from 'primeng/primeng';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';

declare function alerts(m): any;
declare function success(m): any;
declare var SdmtGridT;
@Component({
  host: { class: 'd-flex flex-column h-100' },
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.scss']
})
export class AuthenticationComponent implements OnInit {
  pageRightsTree: any = [];
  selectedFilesMenuRightsTree: any = [];
  selectedFilesData: any = [];
  pageRightsMenuId: any = [];
  srcFileId: any = [];
  projectPath: any
  srcFilePath: any = [];
  authActive: number = 0;
  treeMenuListData: any = [];
  constructor(public shareService: SagShareService,
    public studioDragDropService: CommonStudioDragDropService,
    public modalRef: DynamicDialogRef,
  ) {
    this.projectPath = this.shareService.getDataprotool("selectedProjectChooseData");
  }

  async ngOnInit() {
    await this.getFileMenuTree();
    this.getTreeMenuList();
    this.getTreePageList();
  }

  getToolData(){
    if(this.authActive == 1){
      let data = {
        "toolName" : ["AUTHENTICATION", "AUTH LEVEL", "REJECT LIST", "AUTH CONFIGURATION"]
      }
      this.shareService.getToolData(data).subscribe(res=>{})
    }
  }

  async getFileMenuTree() {
    if (this.projectPath) {
      const reqObj = {
        "projectName": this.projectPath.projectname,
        "mode": "RELATEDFILE"
      }
      let res = await this.shareService.getFileMenuTree(reqObj).toPromise();
      this.pageRightsTree = res['data'];
    }
  }

  getTreeMenuList() {
    this.shareService.getTreeMenuList(this.projectPath.projectId).subscribe(res => {
      this.treeSelectfunc(res['data']);
      this.treeMenuListData = res['data']['srcfileIds'];
    });
  }

  getTreePageList() {
    this.shareService.getTreePageList(this.projectPath.projectId).subscribe(res => {
      let gridData = res['data'].filter(ele => ele.menuPath != "");
      let result = gridData.filter(element => this.treeMenuListData.includes(element.ngsrcfileId));
      this.pageList(
        gridData.map(ele => {
          let obj = {
            ...ele,
            authAvl: result.some(item => item.ngsrcfileId === ele.ngsrcfileId) ? 'Y' : 'N'
          };
          return obj
        })
      )
    });
  }

  treeSelectfunc(response) {
    let self = this;
    for (let index = 0; index < this.pageRightsTree.length; index++) {
      let ele = this.pageRightsTree[index];
      ele.menudetId ? response['menudtlIds'].filter(item => item == ele['menudetId'] ? this.selectedFilesData.push(ele) : false) : false;
      function rec(param) {
        for (let i = 0; i < param.length; i++) {
          let ele1 = param[i];
          ele1.menudetId ? response['menudtlIds'].filter(item => item == ele1['menudetId'] ? self.selectedFilesData.push(ele1) : false) : false;
          ele1.ngsrcfileId ? response['srcfileIds'].filter(item => item == ele1['ngsrcfileId'] ? self.selectedFilesData.push(ele1) : false) : false;
          if (ele1.children) {
            rec(ele1.children)
          }
        }
      }
      if (ele.children) { rec(ele.children) }
    }
    this.selectedFilesMenuRightsTree = this.selectedFilesData;
  }

  // saveStatus() {
  //   if (this.selectedFilesMenuRightsTree.length <= 0) {
  //     alerts("Please select the tree data");
  //     return;
  //   }
  //   this.pageRecData(this.selectedFilesMenuRightsTree);
  //   let pageRightsMenuId = this.pageRightsMenuId.filter((item, index) => {
  //     return this.pageRightsMenuId.indexOf(item) === index
  //   })
  //   let srcFileId = this.srcFileId.filter((item, index) => {
  //     return this.srcFileId.indexOf(item) === index
  //   })
  //   let data = {
  //     menudtlIds: pageRightsMenuId,
  //     srcfileIds: srcFileId,
  //     projectId: this.projectPath.projectId
  //   }
  //   this.shareService.saveTreeMenuList(data).subscribe(res => {
  //     res['status'] == "success" ? success("Data Saved Successfully") : alerts(res['status']);
  //   })
  // }

  isGridView: any = "gridView";
  isTableView: any;
  taskTableDataList: any;


  gridData_pagelist: any;
  gridDynamicObj_pagelist: any;
  columnData_pagelist: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": false,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "left",

    },
    {
      "header": "Form Name",
      "field": "uniqename",
      "filter": true,
      "width": "250px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Menu Name",
      "field": "menuPath",
      "filter": true,
      "width": "450px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Auth Avl",
      "field": "authAvl",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Action",
      "field": "view",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "center",
      "search": false,
      "component": "button",
      "cellRenderView": true,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
      button: {
        cellValue: "",
        visibility: true,
        name: "View",
        classes: ["btn", "btn-primary", "btn-sm"],
        attribute: "",
        styles: "",
      },
    },
  ];

  rowData_pagelist: any = [];

  pageList(rowData?, colData?) {
    let self = this;
    this.gridData_pagelist = {
      columnDef: colData ? colData : this.columnData_pagelist,
      rowDef: rowData ? rowData : this.rowData_pagelist,
      footer_hide: true,
      totalNoOfRecord_hide: false,
      sml_expandGrid_hide: false,
      exportXlsxPage_hide: false,
      exportXlsxAllPage_hide: false,
      exportPDFLandscape_hide: false,
      exportPDFPortrait_hide: false,
      ariaHidden_hide: false,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,
      rowLineSpace: 0,
      components: {},
      callBack: {
        "onButton_view": function (ele, params) {
          params.rowValue.authAvl == "N" ? self.fileOpen(params.rowValue.path) : alerts("Authentication already applied")
        },
        "onCellClick": function (ele) {
          // self.onpagelistCellClick();
        },
        "onRowClick": function () {
          // self.onpagelistClick();
        },
        "onRowDbleClick": function () {
          // self.onpagelistdblClick();
        }
      },
      rowCustomHeight: 20,
    };
    let sourceDiv = document.getElementById("pageList");
    this.gridDynamicObj_pagelist = SdmtGridT(sourceDiv, this.gridData_pagelist, true, true);
  }

  async fileOpen(path) {
    let firstpath = window['editorComponentRef'].editorRef.firstRootStore[1].id
    const fullPath: any = firstpath + '/' + path
    window['angularComponentRef'].openFileEditor(fullPath);
    this.modalRef.close(true);
    let fileUriPath = fullPath && fullPath.replaceAll('/', '\\');
    const selectProjectData = this.shareService.getDataprotool("selectedProjectChooseData");
    const projectPath = fileUriPath.substring(fileUriPath.indexOf(selectProjectData.projectname))
    this.shareService.setDataprotool("nodeSelectPath", projectPath);
    window['angularComponentRef'].selectedModulePath = fileUriPath;
    const selNode = await this.studioDragDropService.getExplorerNodeByProjectPath(projectPath.replaceAll('\\', '/'), 'from');
    this.studioDragDropService.fileShow(selNode, 'customfile');
  }

  proceed() {
    if (this.selectedFilesMenuRightsTree.length <= 0) {
      alerts("Please select the tree data");
      return;
    }
    this.pageRecData(this.selectedFilesMenuRightsTree);
    let srcFilePath = this.srcFilePath.filter((obj1, i, arr) =>
      arr.findIndex(obj2 =>
        JSON.stringify(obj2) === JSON.stringify(obj1)
      ) === i
    )
    if (this.treeMenuListData.length > 0) {
      srcFilePath = srcFilePath.filter((val) => {
        return this.treeMenuListData.indexOf(val.ngsrcfileId) == -1;
      });
    }
    if (srcFilePath.length > 1) {
      alerts("You cannot proceed more than one file");
      return;
    }
    this.fileOpen(srcFilePath[0]['path']);
  }

  pageRecData(response) {
    this.srcFilePath = [];
    for (let index = 0; index < response.length; index++) {
      let ele = response[index];
      ele.ngsrcfileId ? this.srcFilePath.push({ path: ele.path, ngsrcfileId: ele.ngsrcfileId }) : false;
      let rec = (param) => {
        for (let i = 0; i < param.length; i++) {
          let ele1 = param[i];
          ele1.ngsrcfileId ? this.srcFilePath.push({ path: ele1.path, ngsrcfileId: ele1.ngsrcfileId }) : false;
          if (ele1.children) {
            rec(ele1.children)
          }
        }
      }
      if (ele.children) { rec(ele.children) }
    }
  }

}
