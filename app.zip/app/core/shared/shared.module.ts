import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UiFeaturedModule } from '../ui-featured/ui-featured.module';
import { PipesModule } from '../pipes/pipes.module';
import { DirectivesModule } from '../directives/directives.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DndModule } from 'ngx-drag-drop';
import { MonacoEditorModule } from 'ngx-monaco-editor'; 


@NgModule({
  imports: [
    CommonModule,
    UiFeaturedModule,
    PipesModule,
    DirectivesModule,
    FormsModule,
    DndModule,
    ReactiveFormsModule,
    MonacoEditorModule
    // SagMonacoEditorModule.forRoot(),
  ],
  exports :[
    UiFeaturedModule,
    PipesModule,
    DirectivesModule,
    FormsModule, 
    ReactiveFormsModule,
    DndModule,
    MonacoEditorModule
    
  ]
})
export class SharedModule { }
