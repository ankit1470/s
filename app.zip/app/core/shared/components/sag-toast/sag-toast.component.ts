import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ToastService } from 'src/app/core/services/toast.service';

@Component({
  selector: 'app-sag-toast',
  templateUrl: './sag-toast.component.html',
  styleUrls: ['./sag-toast.component.scss'],
})
export class SagToastComponent implements OnInit, OnDestroy {
  subscription: Subscription;
  textMessage: string = '';
  textType: string = '';
  textPosition: string = '';
  toastingTime?: number = 3000; // 4 second
  isPaused?: boolean = false;

  constructor(
    public toast: ToastService,
    private _cdRef: ChangeDetectorRef) { }

  ngOnInit() {

    this.subscription = this.toast.toastMSG.subscribe((res) => {
      this._cdRef.detectChanges();
      let progressBar: any;
      progressBar = document.querySelector('.swiper-progress');
      progressBar.style.width = "0%";
      let toastEle = document.getElementById('ujx_toast');

      if (res.message !== "" && res.type != "") {

        let start = 0;
        let end = 100;
        let frameRate = 100;    // In milliseconds (divide by 1000 to get seconds).
        let toAdd = ((end - start) * frameRate) / this.toastingTime;
        let interval = setInterval((el) => {
          if (!this.isPaused) {
            let currentValue = parseFloat(progressBar.style.width.split("%")[0]) || 0;
            if (currentValue >= end) {
              toastEle.className = toastEle.className.replace("ujx_show", "");
              toastEle.style.minWidth = "0px";
              clearInterval(interval);
              return;
            }
            progressBar.style.width = (!isNaN(currentValue) == true ? currentValue + toAdd : toAdd) + "%";
          }
        }, frameRate, false);


        this.textMessage = res.message;
        this.textPosition = res.position;
        this.textType = res.type;

        toastEle.className = 'ujx_show';
        toastEle.style.minWidth = "350px";
        toastEle.addEventListener('mouseover', (e) => {
          this.isPaused = true;
        });
        toastEle.addEventListener('mouseout', (e) => {
          this.isPaused = false;
        });

      }
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}


