import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { DialogService, DynamicDialogConfig, DynamicDialogRef } from 'primeng/api';
import { Subscription } from 'rxjs';
import { ToastService } from 'src/app/core/services/toast.service';
declare var SdmtGridT;
@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {
  dialogBoxInfo: any;
  subscription: Subscription;
  itemName: any;
  // @HostBinding('class') type: string;
  constructor(
    public _sagStudioService: SagStudioService,
    public dialogService: DialogService,
    public modalRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public toast: ToastService
  ) {
    this.itemName = this.config.data;
  }

  ngOnInit() {
    if (this.itemName.methodData == 'folderDelete' && this.itemName.pagelinkData.length > 0) {
      setTimeout(() => {
        this.pageUseDetails(this.itemName.pagelinkData)
      }, 0);
    }

  }

  /*  ngOnDestroy() {
     this.subscription.unsubscribe();
   } */

  close() {
    this.modalRef.close(true);
  }
  continue(){
    this.modalRef.close(false)
  }
  imageCollectionFromJson = this._sagStudioService.completeJsonWithContainer.imageCollection;
  indexOfImgsNotUsed = [];
  deletefiled() {
    if (this.config.data.list.children && this.config.data.list.children.find(ele => ele.name == this.config.data.item.name)) {
      const index = this.config.data.list.children.indexOf(this.config.data.item);
      this.config.data.list.children.splice(index, 1);
      this.modalRef.close(true);
    } else {
      const index = this.config.data.list.indexOf(this.config.data.item);
      this.config.data.list.splice(index, 1);
      this.modalRef.close(true);
      if (this.config.data.type == 'sagGridArea') {
        this.config.data.item[this.config.data.type].splice(this.config.data.type.index, 1);
      } else if (this.config.data.item.type == 'bootstrapModals') {
        let indx = this._sagStudioService.completeJsonWithContainer.angular.forms.componentTray.findIndex((ele) => ele.id == this.config.data.item.id);
        if (indx != -1) {
          this._sagStudioService.completeJsonWithContainer.angular.forms.componentTray.splice(indx, 1);
        }
      }
    }

    this.methodForDecreaseCountInCtrl(this.config.data.item)
    // deleting from img.json  file
    this.searchForImg(this.itemName.item)
    // deleteImgFromCurrentPage
    this.deleteImgFromCurrentPage(this.itemName.item);
    
    if(this.indexOfImgsNotUsed && this.indexOfImgsNotUsed.length > 0){
      for (let index = 0; index < this.indexOfImgsNotUsed.length; index++) {
        this.imageCollectionFromJson[this.indexOfImgsNotUsed[index]] = ''
      }
      this._sagStudioService.completeJsonWithContainer.imageCollection =  this.imageCollectionFromJson.filter(x => x != '')
    }
  }
  
  deleteImgFromCurrentPage(item){
    debugger
   this.getAllDeleteImages(item)
    for (let ind = 0; ind < this.imageCollectionFromJson.length; ind++) {
      const elem = this.imageCollectionFromJson[ind];
      this.deleteImagesFromPage(elem,item,ind)
      if(this.imageCollectionFromJson && this.imageCollectionFromJson[ind]['usedBy'] && this.imageCollectionFromJson[ind]['usedBy'].length == 0){
        this.indexOfImgsNotUsed.push(ind);
      }
    }
    
  }
  getAllDeleteImages(item){
    debugger
    if(item.subtype == 'image'){
      if(item.properties && item.properties.srcType && item.properties.srcType == 'assets'){
        let fileNameExist=false;
        if(this._sagStudioService.imagesDeletedFromProject.length > 0){
          for (let index = 0; index < this._sagStudioService.imagesDeletedFromProject.length; index++) {
            const element = this._sagStudioService.imagesDeletedFromProject[index];
            if(element.name == item.properties.src.split('images/')[1]){
              fileNameExist = true
            }
          }
        }
        if(!fileNameExist){
          this._sagStudioService.imagesDeletedFromProject.push({
            "name": item.properties.src.split('images/')[1],
            "mode": 'D'
          })
        }
      }
    }
    if(item && item.subDataArray && item.subDataArray.length > 0){
      for (let sub = 0; sub < item.subDataArray.length; sub++) {
        const subData = item.subDataArray[sub];
        this.getAllDeleteImages(subData)
      }
    }
    if(item && item.children && item.children.length > 0){
      for (let child = 0; child < item.children.length; child++) {
        const childData = item.children[child];
        this.getAllDeleteImages(childData)
      }
    }
  }
  deleteImagesFromPage(elem,item,ind){
    if(item.subtype == 'image' && elem.src == item.properties.src){
      if(elem && elem['usedBy'] && elem['usedBy'].length > 0){
        let getIdIndex ;
        for (let index = 0; index < elem['usedBy'].length; index++) {
          const ctrlId = elem['usedBy'][index];
          if(ctrlId == item.id){
              getIdIndex = index
          }
          
        }
        if(getIdIndex != undefined){
          elem['usedBy'].splice(getIdIndex,1)
        }
      }
    }
    
    if(item && item.children && item.children.length > 0 ){
      for (let index = 0; index < item.children.length; index++) {
        const childElement = item.children[index];
        this.deleteImagesFromPage(elem,childElement,ind)
      }
    }
    if(item && item.subDataArray && item.subDataArray.length > 0 ){
      for (let index = 0; index < item.subDataArray.length; index++) {
        const subElement = item.subDataArray[index];
        this.deleteImagesFromPage(elem,subElement,ind)
      }
    }
  }
  searchForImg(item){
    if(item.subtype == 'image' || item.subtype == 'magnifyZoomImgChild'){
      let fileId = this._sagStudioService.completeJsonWithContainer.fileId;
      if(this._sagStudioService.imgFileData[fileId] && this._sagStudioService.imgFileData[fileId][item.id]){
        delete this._sagStudioService.imgFileData[fileId][item.id]
      }
    }
    if(item && item.subDataArray && item.subDataArray.length > 0){
      for (let index = 0; index < item.subDataArray.length; index++) {
        const element = item.subDataArray[index];
        this.searchForImg(element)
      }
    }
    if(item && item.children && item.children.length > 0){
      for (let index = 0; index < item.children.length; index++) {
        const element = item.children[index];
        this.searchForImg(element)
      }
    }
  }

  methodForDecreaseCountInCtrl(control) {
    let getFilecode;
    if(this._sagStudioService.fileCodeListOfControlsResp && this._sagStudioService.fileCodeListOfControlsResp.length > 0){
      this._sagStudioService.fileCodeListOfControlsResp.forEach(contrl => {
        if ((control.type == contrl.type) && (control.subtype == contrl.subtype)) {
          getFilecode = contrl
        }
      })
    }
    if (getFilecode && getFilecode.js && getFilecode.js.length > 0) {
      if (this._sagStudioService.recondForIndexFile && this._sagStudioService.recondForIndexFile.js) {
        let jsFileCodeList = this._sagStudioService.recondForIndexFile.js
        for (let fjs = 0; fjs < getFilecode.js.length; fjs++) {
          this.decreaseFileCount(getFilecode.js[fjs], jsFileCodeList, 'js')
        }
      }
    }
    if (getFilecode && getFilecode.css && getFilecode.css.length > 0) {
      if (this._sagStudioService.recondForIndexFile && this._sagStudioService.recondForIndexFile.css) {
        let cssFileCodeList = this._sagStudioService.recondForIndexFile.css;
        for (let fcss = 0; fcss < getFilecode.css.length; fcss++) {
          this.decreaseFileCount(getFilecode.css[fcss], cssFileCodeList, 'css')
        }
      }
    }


    //Nested in SubDataArray
    if (control && control.subDataArray && control.subDataArray.length > 0) {
      control.subDataArray.forEach(innerCtrl => {
        this.methodForDecreaseCountInCtrl(innerCtrl)
      })
    }
    //Nested in Children
    if (control && control.children && control.children.length > 0) {
      control.children.forEach(innerCtrl => {
        this.methodForDecreaseCountInCtrl(innerCtrl)
      })
    }
  }

  decreaseFileCount(ctrl, record, type) {
    if (record && record.length > 0) {
      let alreadyExistFileCode = false;
      let changeInCountingOfFileCount = {};
      for (let file = 0; file < record.length; file++) {
        if (record[file].fileCode == ctrl) {
          alreadyExistFileCode = true;
          changeInCountingOfFileCount = record[file]
        }
      }
      if (alreadyExistFileCode == true && changeInCountingOfFileCount) {
        changeInCountingOfFileCount['count']--;
      }
    }
  }

  yes(val) {
    this.modalRef.close(val);
  }


  gridData_pageUseDetails: any;
  gridDynamicObj_pageUseDetails: any;
  columnData_pageUseDetails: any = [
    {
      "hidden": false,
      "editable": "false",
      "filter": true,
      "search": true,
      "component": "label",
      "field": "sno",
      "freezecol": "null",
      "width": "50px",
      "header": "S.No",
      "text-align": "center",

    },
    {
      "header": "Type",
      "field": "type",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Menu",
      "field": "menu",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,
    },
    {
      "header": "Caller",
      "field": "caller",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Callee",
      "field": "callee",
      "filter": true,
      "width": "100px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
    {
      "header": "Navigate Url",
      "field": "navigateUrl",
      "filter": true,
      "width": "200px",
      "editable": "false",
      "text-align": "left",
      "search": true,
      "component": "label",
      "cellRenderView": false,
      "freezecol": "null",
      "hidden": false,
      "sort": false,
      "cellHover": false,

    },
  ];

  rowData_pageUseDetails: any = [];

  pageUseDetails(rowData?, colData?) {
    let self = this;

    this.gridData_pageUseDetails = {
      columnDef: colData ? colData : this.columnData_pageUseDetails,
      rowDef: rowData ? rowData : this.rowData_pageUseDetails,
      footer_hide: false,
      totalNoOfRecord_hide: true,
      sml_expandGrid_hide: true,
      exportXlsxPage_hide: true,
      exportXlsxAllPage_hide: true,
      exportPDFLandscape_hide: true,
      exportPDFPortrait_hide: true,
      ariaHidden_hide: true,
      disableAllSearch: false,
      wordBreak: false,
      wordBreakHeader: false,
      cellHover: false,
      rowHover: false,
      rowBorder_hide: false,
      columnBorder_hide: false,
      header_hide: false,
      common_search: false,
      common_search_column: "",
      gridbody_hide: false,

      components: {},
      callBack: {

        "onCellClick": function (ele) {

          self.onpageUseDetailsCellClick();
        },
        "onRowClick": function () {
          self.onpageUseDetailsClick();
        },
        "onRowDbleClick": function () {
          self.onpageUseDetailsdblClick();
        }
      }
      ,


      rowCustomHeight: 20,




    };

    let sourceDiv = document.getElementById("pageUseDetails");
    this.gridDynamicObj_pageUseDetails = SdmtGridT(sourceDiv, this.gridData_pageUseDetails, true, true);
  }

  onpageUseDetailsCellClick() {

  }

  onpageUseDetailsClick() {

  }

  onpageUseDetailsdblClick() {

  }

  confirmationDelete: boolean = false
  delete() {
    this.confirmationDelete = true;
    /* if (this.itemName.pagelinkData.find(ele => ele.type == "menu") && this.itemName.pagelinkData.length == 1) {
      this.confirmationDelete = true;
    } else {
      this.confirmationDelete = true
      this.toast.launch_toast({
        type: 'alert',
        position: 'bottom-right',
        message: `D'not effect the file the symlink points to`,
      });
    } */
   
  }

  masterPageStr = {}
  masterData(){   
    this.masterPageStr['master'] = "Yes";
    this.masterPageStr['controlInput'] = "Yes";
    this.modalRef.close(this.masterPageStr);
  }
  masterClosebtn(){
    this.masterPageStr['master'] = "No";
    this.masterPageStr['controlInput'] = "Yes";
    this.modalRef.close(this.masterPageStr);
  }
}
