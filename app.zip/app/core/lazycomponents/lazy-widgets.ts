import { NgModuleFactory, Type } from '@angular/core';

export const lazyWidgets: { path: string, loadChildren: () => Promise<NgModuleFactory<any> | Type<any>> }[] = [
  {
    path: 'addService',
    loadChildren: () => import('../../modules/sag-studio/api-integration/api-integration.module').then(m => m.ApiIntegrationModule)
  },

  {
    path: 'addMethod',
    loadChildren: () => import('../../modules/sag-studio/add-method/add-method.module').then(m => m.AddMethodModule)
  },
  {
    path: 'javaAPi',
    loadChildren: () => import('../../modules/sag-studio/java-tool/java-tool.module').then(m => m.JavaToolModule)
  },

  {
    path: 'dashboard',
    loadChildren: () => import('../../dashboard/dashboard.module').then(m => m.DashboardModule)
  }


];

export function lazyArrayToObj() {
  const result = {};
  for (const w of lazyWidgets) {
    result[w.path] = w.loadChildren;
  }
  return result;
}

