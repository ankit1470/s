import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ToastService {

    constructor() { }

    expactedToast: any = {
        type: '',
        message: '',
        id: '',
        className: '',
        time:0,
    };

    public toastMSG = new BehaviorSubject<any>(this.expactedToast)

    launch_toast(expObj) {
        this.toastMSG.next(expObj);
    }

}
