// /**!
//  * @description 
//  * To provide preloading strategy in project
//  * @usageNotes
//  * For example, for the following `Routes Array`
//  * 
//  * 
//  *  [
//  *   {
//         path: "UIbuilder",
//           data: {
//           preload: true, 
//         },
//         loadChildren: () =>
//           import("../modules/sag-studio/sag-studio.module").then(
//             (mod) => mod.SagStudioModule
//           ),
//       },
//     ]
//  * 
//  * Need to pass `preload : true` in data object
//  * It can be provided to `routes` array as above example
//  * 
//  */
// import { Injectable } from '@angular/core';
// import { PreloadingStrategy, Route } from '@angular/router';
// import { Observable, of } from 'rxjs';


// @Injectable({
//   providedIn: 'root'
// })
// export class CustomPreloadingStrategyService implements PreloadingStrategy {
//   constructor() { }
//   preload(route: Route, fn: () => Observable<any>): Observable<any> {
//     if (route.data && route.data.preload) {
//       return fn();
//     }
//     return of(null);
//   } 
// }


