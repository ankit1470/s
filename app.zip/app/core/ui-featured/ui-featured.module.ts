import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MultiSelectModule} from 'primeng/multiselect'
import { TreeModule } from 'primeng/tree';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CalendarModule } from 'primeng/calendar';
import {TooltipModule} from 'primeng/tooltip';
import { MenubarModule, AccordionModule, ChipsModule,InputMaskModule,TriStateCheckboxModule} from 'primeng/primeng';
import { DynamicDialogModule } from 'primeng/components/dynamicdialog/dynamicdialog';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { ToastModule } from 'primeng/toast';
import {StepsModule} from 'primeng/steps';
import {CaptchaModule} from 'primeng/captcha';
import {RatingModule} from 'primeng/rating';
import { TreeModule as SagTreeModule } from 'projects/uikit/tree'; 
import { InputnumberModule as SagInputnumberModule} from 'projects/uikit/inputnumber';
import { SliderModule } from 'primeng/slider';
import {EditorModule} from 'primeng/editor';
import { PickListModule } from 'primeng/picklist';
import { DragDropModule } from '@angular/cdk/drag-drop';
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InputTextModule,
    MultiSelectModule,
    AutoCompleteModule,
    CalendarModule,
    DropdownModule,
    TableModule,
    TreeModule,
    TooltipModule,
    MenubarModule,
    DynamicDialogModule,
    AccordionModule,
    MessagesModule,
    MessageModule,
    ToastModule,
    StepsModule,
    InputMaskModule,
    TriStateCheckboxModule,
    CaptchaModule,
    SagTreeModule,
    SagInputnumberModule,
    RatingModule,
    SliderModule,
    EditorModule,
    PickListModule,
    DragDropModule
  ],
  exports :[
    InputTextModule,
    MultiSelectModule,
    AutoCompleteModule,
    CalendarModule,
    DropdownModule,
    TableModule,
    TreeModule,
    TooltipModule,
    MenubarModule,
    DynamicDialogModule,
    AccordionModule,
    MessagesModule,
    MessageModule,
    ToastModule,
    ChipsModule,
    StepsModule,
    InputMaskModule,
    TriStateCheckboxModule,
    CaptchaModule,
    SagTreeModule,
    RatingModule,
    SagInputnumberModule,
    SliderModule,
    EditorModule,
    PickListModule,
    DragDropModule
  ]
})
export class UiFeaturedModule { }
