import { Directive, Input, HostListener, ElementRef, Renderer2, HostBinding } from '@angular/core';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
import { CommonStudioDragDropService } from 'src/app/services/sagStudio/common-studio-drag-drop.service';

@Directive({
  selector: '[sagResizableNode]'
})
export class SagResizableNodeDirective {

  public DebounceTime = 400;
  @Input() public ctrlItem: any = {};
  @Input() public hText: any = "";
  @Input() moveInfo?: any = [];
  @Input() copyInfo?: any = [];
  @Input() editClickInfo?: any = [];
  @Input() delClickInfo?: any = [];
  @Input() expandInfo?: any = [];
  @Input() addInfo?: any = [];
  @Input() addTag?: any = [];
  @Input() aiInfo?: any = [];
  @Input() pasteInfo?: any = [];

  //new code 08 - 04 - 2024
  @Input() checkstatusClickInfo? : any = [];
  @Input() updateClickInfo? : any = [];


  @Input() isResizeDisabled: boolean = false;
  boundary: string | HTMLElement;
  @Input() ctrlPostion?: any ='afterbegin';// 'beforebegin';



  @Input() set resizeBoundary(boundary: string | HTMLElement) {
    this.boundary = boundary;
  }
  @Input() dblClickEvtFire: boolean = true;

  @HostListener('mousedown', ['$event'])
  @HostListener('click', ['$event'])
  // @HostListener('blur', ['$event'])
  onEvent(event: any) {
    event.stopPropagation();
    if (event.type == 'click') {
      // event.preventDefault(); /**commented due to checkbox click default behavior not working */
      event.stopPropagation();
      this.mouseDownClickFun(event);
      if (event.target.contentEditable == 'true') {
        event.target.focus();
        event.target.addEventListener('blur', (e) => {

          this.ctrlItem.properties.label = event.target.innerText;

          this.studioDragDropService.changesDetectedInFile();
        });
      }
    }
    else if (event.type == 'mousedown' && !this.isResizeDisabled) {
      event.preventDefault();
      event.stopPropagation();
      this.resizeNode(this.elementRef.nativeElement, this.boundary);
    }


  }



  constructor(
    private readonly elementRef: ElementRef<HTMLElement>,
    private readonly renderer: Renderer2,
    private sagStudio: SagStudioService,
    private studioDragDropService: CommonStudioDragDropService, ) {
  }




  // on mouse re-click Remove Node or css Class
  removeExitingDom(e: any) {
    e.stopPropagation();
    let sagCtrlClick = document.querySelector(".sag_r_Click_Ctrl");
    let wrapperEle = document.querySelector(".resizable");
    if (this.sagStudio.lastDomClickInfo) {
      if (!!sagCtrlClick) {
        this.renderer.removeChild(this.sagStudio.lastDomClickInfo, sagCtrlClick);
      }
      if (!!wrapperEle) {
        this.renderer.removeClass(this.sagStudio.lastDomClickInfo, 'resizable');
      } else {
        this.renderer.removeClass(this.sagStudio.lastDomClickInfo, 'nodeSelected');
      }
    }
  }

  // mouse right click event Handler
  mouseDownClickFun(e: any) {
    e.stopPropagation();
    let self = this;
    let isDrag = false;
    let activeElement = self.elementRef.nativeElement; // current active node selected
    let ulNode: HTMLElement;

    this.removeExitingDom(e);
    createCtrlBtn();

    //create control Btn div block
    function createCtrlBtn() {
      if (!self.isResizeDisabled) {
        self.renderer.addClass(self.elementRef.nativeElement, "resizable");
      } else {
        self.renderer.addClass(self.elementRef.nativeElement, "nodeSelected");


      }

      let clickDiv = document.createElement('div');
      clickDiv.setAttribute('class', "sag_r_Click_Ctrl");

      ulNode = document.createElement('ul');

      ctrlName();
      self.moveInfo && self.moveInfo.length > 0 ? mvBtnCtrl() : false;
      self.copyInfo && self.copyInfo.length > 0 ? cpBtnCtrl() : false;
      self.pasteInfo && self.pasteInfo.length && self.studioDragDropService.duplicateData != null ? pasteBtnCtrl() : false;
      self.expandInfo && self.expandInfo.length > 0 ? expandBtnCtrl() : false;
      self.addInfo && self.addInfo.length > 0 ? addBtnCtrl() : false;
      self.addTag && self.addTag.length > 0 ? addTagBtnCtrl() : false;
      self.aiInfo && self.aiInfo.length > 0 ? aiBtnCtrl() : false;
      self.editClickInfo && self.editClickInfo.length > 0 ? editBtnCtrl() : false;
      self.delClickInfo && self.delClickInfo.length > 0 ? deleteBtnCtrl() : false;
      //new code 08 - 04 - 2024
      
      self.checkstatusClickInfo && self.checkstatusClickInfo.length > 0 ? checkstatusBtnCtrl() : false;
      if (self.ctrlItem.updatemaster == "Y") { 
        self.ctrlItem['_domElement'] = 'd-none'       
        self.updateClickInfo && self.updateClickInfo.length > 0 ? updateBtnCtrl() : false;
      }
      


      clickDiv.appendChild(ulNode);

      activeElement.insertAdjacentElement(self.ctrlPostion, clickDiv);
      self.sagStudio.lastDomClickInfo = activeElement as HTMLElement;
      if (self.dblClickEvtFire) {
        e.stopPropagation();
        self.renderer.listen(clickDiv, 'dblclick', (evt) => {
          evt.stopPropagation();
          self.studioDragDropService[self.editClickInfo[0]](self.editClickInfo[1], self.editClickInfo[2], self.editClickInfo[3], self.editClickInfo[4]);
        });
        self.renderer.listen(activeElement, 'dblclick', (evt) => {
          evt.stopPropagation();
          self.studioDragDropService[self.editClickInfo[0]](self.editClickInfo[1], self.editClickInfo[2], self.editClickInfo[3], self.editClickInfo[4]);
        });
         // single click property window object update
        self.renderer.listen(activeElement, 'click', (evt) => {
          evt.stopPropagation();
          if (self.dblClickEvtFire && self.sagStudio.pageDi && self.sagStudio.pageDi.domElements.propSidebar.display) {
          self.studioDragDropService[self.editClickInfo[0]](self.editClickInfo[1], self.editClickInfo[2], self.editClickInfo[3], self.editClickInfo[4]);
          }
        });
      }


    }


    // control Name create here
    function ctrlName() {
      let name = document.createElement('li');
      name.setAttribute('id', "ctrlId");
      name.innerHTML = self.ctrlItem ? (self.hText) : 'T';
      ulNode.appendChild(name);
    }

    // move control button
    function mvBtnCtrl() {
      let mvNode = document.createElement('li');
      self.renderer.addClass(mvNode, 'sag-ctrl-li');
      self.renderer.addClass(mvNode, 'ctrl-move');

      self.renderer.listen(mvNode, 'mousedown', (eventI) => {
        eventI.stopPropagation();
        isDrag = true;
        startDragging(self.elementRef.nativeElement, self.boundary, eventI);
      });

      self.renderer.listen(mvNode, 'mouseup', (eventI) => {
        eventI.stopPropagation();
        isDrag = false;
        stopDragging(self.boundary);
      });

      let spanNode = document.createElement('span');
      spanNode.setAttribute('id', "text-label");

      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "fa fa-arrows-alt");
      self.renderer.setAttribute(iNode, 'title', "Move");
      spanNode.appendChild(iNode);


      spanNode.appendChild(iNode);
      mvNode.appendChild(spanNode);
      ulNode.appendChild(mvNode);
    }


    // copy control button
    function cpBtnCtrl() {
      let copyNode = document.createElement('li');
      self.renderer.addClass(copyNode, 'sag-ctrl-li');
      self.renderer.addClass(copyNode, 'ctrl-copy');

      self.renderer.listen(copyNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        self.studioDragDropService[self.copyInfo[0]](self.copyInfo[1], self.copyInfo[2], self.copyInfo[3]);
      });

      let liSpanNode = document.createElement('span');
      liSpanNode.setAttribute('id', "text-label");
      liSpanNode.innerHTML = "";
      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "fa fa-clone");
      self.renderer.setAttribute(iNode, 'title', "Copy");

      liSpanNode.appendChild(iNode);

      copyNode.appendChild(liSpanNode);
      ulNode.appendChild(copyNode);

    }

    // Expand Control button
    function expandBtnCtrl() {
      let expLiNode = document.createElement('li');
      self.renderer.addClass(expLiNode, 'sag-ctrl-li')
      self.renderer.addClass(expLiNode, 'ctrl-expand');

      self.renderer.listen(expLiNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        if (self.expandInfo[5]) {
          self.expandInfo[5][self.expandInfo[0]](self.expandInfo[1], self.expandInfo[2], self.expandInfo[3], self.expandInfo[4]);
        } else {
          self.studioDragDropService[self.expandInfo[0]](self.expandInfo[1], self.expandInfo[2], self.expandInfo[3], self.expandInfo[4]);
        }
        // self.ctrlItem.toggle = !self.ctrlItem.toggle;
      });


      let sNode = document.createElement('span');
      sNode.setAttribute('id', "text-label");

      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "fa fas fa-expand ");
      self.renderer.setAttribute(iNode, 'title', "Expand");
      sNode.appendChild(iNode);
      expLiNode.appendChild(sNode);
      ulNode.appendChild(expLiNode);
    }

    // Edit Control button
    function editBtnCtrl() {

      let editNode = document.createElement('li');
      self.renderer.addClass(editNode, 'sag-ctrl-li')
      self.renderer.addClass(editNode, 'ctrl-edit');


      self.renderer.listen(editNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        self.studioDragDropService[self.editClickInfo[0]](self.editClickInfo[1], self.editClickInfo[2], self.editClickInfo[3], self.editClickInfo[4]);
      });


      let liSpanNode = document.createElement('span');
      liSpanNode.setAttribute('id', "text-label");

      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "fa fas fa-pen-square");
      self.renderer.setAttribute(iNode, 'title', "Edit");
      liSpanNode.appendChild(iNode);

      editNode.appendChild(liSpanNode);
      ulNode.appendChild(editNode);

    }

    // delete Control button
    function deleteBtnCtrl() {
      let delNode = document.createElement('li');
      self.renderer.addClass(delNode, 'sag-ctrl-li');
      self.renderer.addClass(delNode, 'ctrl-delete');

      self.renderer.listen(delNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        if (self.delClickInfo[5]) {
          self.delClickInfo[5][self.delClickInfo[0]](self.delClickInfo[1], self.delClickInfo[2], self.delClickInfo[3], self.delClickInfo[4]);
        }
        else {
          self.studioDragDropService[self.delClickInfo[0]](self.delClickInfo[1], self.delClickInfo[2], self.delClickInfo[3], self.delClickInfo[4]);
        }
      });

      let spanNode = document.createElement('span');
      spanNode.setAttribute('id', "text-label");
      let iDNode = document.createElement('i');
      self.renderer.setAttribute(iDNode, 'class', "fa fa-trash");
      self.renderer.setAttribute(iDNode, 'title', "Delete");
      spanNode.appendChild(iDNode);

      delNode.appendChild(spanNode);
      ulNode.appendChild(delNode);

    }

    //Add Control button
    function addBtnCtrl() {
      let addNode = document.createElement('li');
      self.renderer.addClass(addNode, 'sag-ctrl-li')
      self.renderer.addClass(addNode, 'ctrl-add');


      self.renderer.listen(addNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        if (self.addInfo[5]) {
          self.addInfo[5][self.addInfo[0]](self.addInfo[1], self.addInfo[2], self.addInfo[3], self.addInfo[4]);
        } else {

          self.studioDragDropService[self.addInfo[0]](self.addInfo[1], self.addInfo[2], self.addInfo[3], self.addInfo[4]);
        }
      });


      let liSpanNode = document.createElement('span');
      liSpanNode.setAttribute('id', "text-label");

      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "fa fa-plus");
      self.renderer.setAttribute(iNode, 'title', "Add");
      liSpanNode.appendChild(iNode);

      addNode.appendChild(liSpanNode);
      ulNode.appendChild(addNode);
    }
    //Add Control button
    function addTagBtnCtrl() {
      let addNode = document.createElement('li');
      self.renderer.addClass(addNode, 'sag-ctrl-li')
      self.renderer.addClass(addNode, 'ctrl-add');


      self.renderer.listen(addNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        if (self.addTag[5]) {
          self.addTag[5][self.addTag[0]](self.addTag[1], self.addTag[2], self.addTag[3], self.addTag[4]);
        } else {

          self.studioDragDropService[self.addTag[0]](self.addTag[1], self.addTag[2], self.addTag[3], self.addTag[4]);
        }
      });


      let liSpanNode = document.createElement('span');
      liSpanNode.setAttribute('id', "text-label");

      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "far fa-plus-square");
      self.renderer.setAttribute(iNode, 'title', "Add");
      liSpanNode.appendChild(iNode);

      addNode.appendChild(liSpanNode);
      ulNode.appendChild(addNode);
    }
  //Ai Control button
  function aiBtnCtrl() {
    let aiNode = document.createElement('li');
    self.renderer.addClass(aiNode, 'sag-ctrl-li')
    self.renderer.addClass(aiNode, 'ctrl-add');


    self.renderer.listen(aiNode, 'click', (evt) => {
      evt.preventDefault();
      evt.stopPropagation();
     // $("#textReplaceId").modal('show');
      self.studioDragDropService[self.aiInfo[0]](self.aiInfo[1], self.aiInfo[2], self.aiInfo[3], self.aiInfo[4],'Ai');
    });


    let liSpanNode = document.createElement('span');
    liSpanNode.setAttribute('id', "text-label");

    let iNode = document.createElement('i');
    self.renderer.setAttribute(iNode, 'class', "fas fa-drafting-compass");
    self.renderer.setAttribute(iNode, 'title', "Ai Text");
    liSpanNode.appendChild(iNode);

    aiNode.appendChild(liSpanNode);
    ulNode.appendChild(aiNode);
  }
    // paste Control Button
    function pasteBtnCtrl() {
      let pasteNode = document.createElement('li');
      self.renderer.addClass(pasteNode, 'sag-ctrl-li')
      self.renderer.addClass(pasteNode, 'ctrl-paste');

      self.renderer.listen(pasteNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        self.studioDragDropService[self.pasteInfo[0]](self.pasteInfo[1], self.pasteInfo[2], self.pasteInfo[3], self.pasteInfo[4]);

      });


      let liSpanNode = document.createElement('span');
      liSpanNode.setAttribute('id', "text-label");

      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "fa fas fa-paste");
      self.renderer.setAttribute(iNode, 'title', "Paste");
      liSpanNode.appendChild(iNode);

      pasteNode.appendChild(liSpanNode);
      ulNode.appendChild(pasteNode);

    }

    //Start  Dragging  here

    function startDragging(divId: any, container: any, evt: any) {
      let parentNode = document.querySelector(container) as HTMLElement;
      evt = evt || window.event;
      let posX = evt.clientX,
        posY = evt.clientY,
        divTop = divId.style.top,
        divLeft = divId.style.left,
        eWi = divId.getBoundingClientRect().width,
        eHe = divId.getBoundingClientRect().height,
        cWi = parentNode.getBoundingClientRect().width,
        cHe = parentNode.getBoundingClientRect().height;
      parentNode.style.cursor = 'move';
      divTop = divTop.replace('px', '');
      divLeft = divLeft.replace('px', '');


      let diffX = posX - divLeft,
        diffY = posY - divTop;
      if (isDrag) {
        document.onmousemove = function (evt: any) {
          evt = evt || window.event;
          let posX = evt.clientX,
            posY = evt.clientY,
            aX = posX - diffX,
            aY = posY - diffY;
          if (aX < 0) aX = 0;
          if (aY < 0) aY = 0;
          if (aX + eWi > cWi) aX = cWi - eWi;
          if (aY + eHe > cHe) aY = cHe - eHe;

          move(divId, aX, aY);
        }

        document.onmouseup = function () {
          stopDragging(self.boundary);
        }
      }
    }

    // Stop Dragging
    function stopDragging(container: any) {
      isDrag = false;
      let cont = document.querySelector(container) as HTMLElement;
      cont.style.cursor = 'default';
      document.onmousemove = function () { }
    }

    // move Node Here.
    function move(divId: any, xpos: any, ypos: any) {
      let innerStyleObj = self.ctrlItem.properties.innerStyles || {};

      innerStyleObj.left = xpos + 'px';
      innerStyleObj.top = ypos + 'px';
    }

    //new code 08 - 04 - 2024
    function updateBtnCtrl() {
      let editNode = document.createElement('li');
      self.renderer.setAttribute(editNode, 'class', `${self.ctrlItem._domElement}`);
      self.renderer.addClass(editNode, 'ctrl-update');
      self.renderer.addClass(editNode, 'sag-ctrl-li')
      self.renderer.addClass(editNode, 'bg-danger');
      self.renderer.addClass(editNode, 'text-white');
      //self.renderer.addClass(editNode, `${self.ctrlItem._domElement}`);
      self.renderer.listen(editNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        self.studioDragDropService[self.updateClickInfo[0]](self.updateClickInfo[1], self.updateClickInfo[2], self.updateClickInfo[3], self.updateClickInfo[4]);
      });


      let liSpanNode = document.createElement('span');
      liSpanNode.setAttribute('id', "text-label");

      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "fab fa-centercode");
      self.renderer.setAttribute(iNode, 'title', "Update");
      liSpanNode.appendChild(iNode);

      editNode.appendChild(liSpanNode);
      ulNode.appendChild(editNode);
    }

    function checkstatusBtnCtrl() {
      
      let editNode = document.createElement('li');
      self.renderer.addClass(editNode, 'sag-ctrl-li')
      self.renderer.addClass(editNode, 'ctrl-checkstatus');
      self.renderer.addClass(editNode, 'bg-warning');      
      self.renderer.listen(editNode, 'click', (evt) => {
        evt.preventDefault();
        evt.stopPropagation();
        self.studioDragDropService[self.checkstatusClickInfo[0]](self.checkstatusClickInfo[1], self.checkstatusClickInfo[2], self.checkstatusClickInfo[3], self.checkstatusClickInfo[4]);
      });
      let liSpanNode = document.createElement('span');
      liSpanNode.setAttribute('id', "text-label");
      let iNode = document.createElement('i');
      self.renderer.setAttribute(iNode, 'class', "fas fa-lightbulb");
      self.renderer.setAttribute(iNode, 'title', "Check Status");
      liSpanNode.appendChild(iNode);
      editNode.appendChild(liSpanNode);
      ulNode.appendChild(editNode);
    }

  }

  // Resize node by edges
  resizeNode(element: HTMLElement, container: any) {
    let self = this;
    let pc = document.querySelector(container).getBoundingClientRect();
    const resizers = element.querySelectorAll('div' + '.resizer');
    const minimum_size = 20;
    let original_width = 0;
    let original_height = 0;
    let original_x = 0;
    let original_y = 0;
    let original_mouse_x = 0;
    let original_mouse_y = 0;
    let innerStyleObj = self.ctrlItem.properties.innerStyles || {};
    for (let i = 0; i < resizers.length; i++) {
      const currentResizer = resizers[i];
      currentResizer.addEventListener('mousedown', function (e: any) {
        e.preventDefault();
        e.stopPropagation();
        original_width = element.getBoundingClientRect().width;
        original_height = element.getBoundingClientRect().height;
        original_x = element.getBoundingClientRect().left - pc.left;
        original_y = element.getBoundingClientRect().top - pc.top;
        original_mouse_x = e.pageX;
        original_mouse_y = e.pageY;
        window.addEventListener('mousemove', resize);
        window.addEventListener('mouseup', stopResize);
      });

      function resize(e: any) {


        if (currentResizer.classList.contains('bottom-right')) {
          const width = original_width + (e.pageX - original_mouse_x);
          const height = original_height + (e.pageY - original_mouse_y)
          if (width > minimum_size) {
            innerStyleObj.width = (width / pc.width) * 100 + '%'
          }
          if (height > minimum_size) {
            innerStyleObj.height = height + 'px'
          }
        }
        else if (currentResizer.classList.contains('bottom-left')) {
          const height = original_height + (e.pageY - original_mouse_y)
          const width = original_width - (e.pageX - original_mouse_x)
          if (height > minimum_size) {
            innerStyleObj.height = height + 'px'
          }
          if (width > minimum_size) {
            innerStyleObj.width = (width / pc.width) * 100 + '%'
            innerStyleObj.left = original_x + (e.pageX - original_mouse_x) + 'px'
          }
        }
        else if (currentResizer.classList.contains('top-right')) {
          const width = original_width + (e.pageX - original_mouse_x)
          const height = original_height - (e.pageY - original_mouse_y)
          if (width > minimum_size) {
            innerStyleObj.width = (width / pc.width) * 100 + '%'
          }
          if (height > minimum_size) {
            innerStyleObj.height = height + 'px'
            innerStyleObj.top = original_y + (e.pageY - original_mouse_y) + 'px'
          }
        }
        else {
          const width = original_width - (e.pageX - original_mouse_x)
          const height = original_height - (e.pageY - original_mouse_y)
          if (width > minimum_size) {
            innerStyleObj.width = (width / pc.width) * 100 + '%'
            innerStyleObj.left = original_x + (e.pageX - original_mouse_x) + 'px'
          }
          if (height > minimum_size) {
            innerStyleObj.height = height + 'px'
            innerStyleObj.top = original_y + (e.pageY - original_mouse_y) + 'px'

          }

        }
        innerStyleObj.position = "absolute"; //  added by laveshsir regard to css
      }

      function stopResize() {
        window.removeEventListener('mousemove', resize);
        self.studioDragDropService.changesDetectedInFile();
      }

    }
  }






}
