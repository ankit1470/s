import { Directive, OnInit, HostListener, AfterViewInit } from '@angular/core';
// import { style } from '@angular/animations';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';
declare const $: any;
@Directive({
  selector: '[appGetheight]'
})
export class GetheightDirective implements OnInit, AfterViewInit{


  constructor(private _sagStudioService: SagStudioService) {


  }

  autogetHgt = () => {
    // debugger;
    setTimeout(() => {
      let winHeight = window.innerHeight;
      let top_main_container = document.querySelector(".top_main_container");
      let tool_bar_menu = document.querySelector(".tool_bar_menu");
      let page_header = document.querySelector(".page-header");
      let tab_pane = document.querySelector(".tab-pane")
      // let getFullHgt = document.querySelector(".getFullHgt");
      let footer_bootam = document.querySelector(".footer_bootam");
      let proceed = document.querySelector(".proceed_bar")
      let page_footer = document.querySelector(".page-footer");
      let rowdata = document.querySelector(".rowdata");
      let sechdr = document.querySelector(".secHeader");
      let f1hgt = (top_main_container) ? $(top_main_container)[0].offsetHeight : 0;
      let f2hgt = (tool_bar_menu) ? $(tool_bar_menu)[0].offsetHeight : 0;
      let f3hgt = (page_header) ? $(page_header)[0].offsetHeight : 0;
      let f4hgt = (tab_pane) ? $(tab_pane)[0].offsetHeight : 0;
      let f5hgt = (page_footer) ? $(page_footer)[0].offsetHeight : 0;
      let f6hgt = (proceed) ? $(proceed)[0].offsetHeight : 0;
      let f8hgt = (footer_bootam) ? $(footer_bootam)[0].offsetHeight : 0; 
      let f9hgt = (sechdr) ? $(sechdr)[0].offsetHeight : 0; 
      let addallElem = f1hgt + f2hgt + f3hgt + f4hgt + f5hgt + f6hgt + f8hgt + f9hgt + 15;
      let getfinalhgt = (winHeight - addallElem) + "px";
      
      $($(rowdata)[0]).css({"height": getfinalhgt, "overflowY": "auto" });
      this._sagStudioService.pageDi['domElements']['menuSidebar']['height'] = winHeight - addallElem;
    }, 50);
  }
  ngOnInit(): void {
    // this.autogetHgt()
  }

  ngAfterViewInit(){
    this.autogetHgt()
  }

  @HostListener('window:resize')
  onresize() {
    this.autogetHgt();
  }

  iconList = [
    { "html": "fa-ico fab fa-html5" },
    { "java": "fa-ico fab fa-java" },
    { "css": "fa-ico fab fa-js-square" },
    { "json": "fa-ico fad fa-file-alt" },
    { "js": "fa-ico fab fa-js" },
    { "mdb": "fa-ico fab fa-readme" },
    { "doc": "fa-ico far fa-file-spreadsheet" },
    { "git": "fa-ico fab fa-git-alt" },
    { "editor": "fa-ico fal fa-user-edit" },
    { "borwserList": "fa-ico fad fa-list" },
  ]
}
