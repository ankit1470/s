import { Directive, OnInit, AfterViewInit, ElementRef, Renderer2, ViewChild } from '@angular/core';
declare const $: any;
@Directive({
  selector: '[appCustomControlPngModel]'
})


export class CustomControlPngModelDirective implements AfterViewInit {
  cruntModel: ElementRef;
  constructor(private elementRef: ElementRef, private renderer: Renderer2) {
    // console.log(elementRef.nativeElement)
    this.cruntModel = elementRef.nativeElement;

  }

  iconFinder() {
    let modalOuterContainer = $(this.cruntModel).closest('.ui-dialog')[0];

    let minimizeHandler = () => {
      this.renderer.addClass(modalOuterContainer, "set-small-size");
      this.renderer.removeClass(modalOuterContainer, 'active-minus');
      this.renderer.addClass(modalOuterContainer, 'active-plus');
    }

    const maximizeHandler = () => {
      this.renderer.removeClass(modalOuterContainer, "set-small-size");
      this.renderer.removeClass(modalOuterContainer, 'active-plus');
      this.renderer.addClass(modalOuterContainer, 'active-minus');
    }
    // debugger;
    let modelCloseElem = $(this.cruntModel).closest('.ui-dialog')[0].querySelector('.ui-dialog-titlebar-close');

    // create minimize Element --------------------  start */
    const buttonMinimize = this.renderer.createElement("a");
    this.renderer.addClass(buttonMinimize, 'ui-dialog-titlebar-icon');
    this.renderer.addClass(buttonMinimize, 'ui-corner-all');
    this.renderer.addClass(buttonMinimize, 'minus-btn');

    // create minimize Element icon
    const iconMinimize = this.renderer.createElement("i");
    this.renderer.addClass(iconMinimize, 'far');
    this.renderer.addClass(iconMinimize, 'fa-window-minimize');

    // add event on minimize Element 
    this.renderer.listen(buttonMinimize, 'click', minimizeHandler)
    this.renderer.appendChild(buttonMinimize, iconMinimize);
    // create minimize Element --------------------  end */



    // create maxiMize Element ------------------------- start */
    const buttonMiximize = this.renderer.createElement("a");
    this.renderer.addClass(buttonMiximize, 'ui-dialog-titlebar-icon');
    this.renderer.addClass(buttonMiximize, 'ui-corner-all');
    this.renderer.addClass(buttonMiximize, 'plus-btn');

    // create maxMize Element icon
    const iconMaximize = this.renderer.createElement("i");
    this.renderer.addClass(iconMaximize, 'fas');
    this.renderer.addClass(iconMaximize, 'fa-expand');
 
    // add event on maxMize Element 
    this.renderer.listen(buttonMiximize, 'click', maximizeHandler)
    this.renderer.appendChild(buttonMiximize, iconMaximize);
    // create maxMize Element ------------------------- end */
    
    this.renderer.addClass(modalOuterContainer, 'active-minus');
    

    $(modelCloseElem).after(buttonMinimize);
    $(modelCloseElem).after(buttonMiximize);
  }


  ngAfterViewInit() {
    this.iconFinder();
  }


}
