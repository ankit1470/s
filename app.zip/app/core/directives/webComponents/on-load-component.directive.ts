import { AfterViewInit, Directive, ElementRef, Input, ChangeDetectorRef } from '@angular/core';

declare var SagDatePicker;
declare function alerts(m): any;
declare function success(m): any;
declare var sagGrid;
declare var SagInputText;
declare var SagCheckBox;
declare var setGridHight;
declare var SagGridMP;
declare var SagGridMPT;
declare var $: any;
declare var ButtonComponent;
declare var headerCheckBox;
declare var SagDynamicComp;
declare var SagSelectBox;
declare var headerSelectBox;
declare var SagToolTip;
declare var _;
declare var ui;
    
@Directive({
  selector: '[onLoadComponent]'
})
export class OnLoadComponentDirective implements AfterViewInit {
  
  @Input() webCompType : any;
  @Input() webCompData :any;
  constructor(
    private el :ElementRef,
    private cdRef :ChangeDetectorRef
    ) {
    
   }
   
   ngAfterViewInit(){ 
    this.loadWebComp(this.webCompType)
   }

   loadWebComp(webCompType){
   switch (webCompType) {
     case 'lightbox':
       this.lightBox();
       break;
   
     case 'owlCarousal':
       this.owlCarousal();
       break;

     case 'sagTree':
       this.sagTree();
       break;
   
     case 'megnifyZoom':
       this.onMegnifyZoom();
       break;
   
       
     default:
       break;
   }
   }

   lightBox() {
    $(document).ready(function () {
      $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
      });
  
      $(".zoom").hover(function () {
  
        $(this).addClass('transition');
      }, function () {
  
        $(this).removeClass('transition');
      });
    });
  }

  owlCarousal(){ 
    const obj = {
      loop: false, 
    }
       !this.webCompData['loop'] ? obj.loop = false : false;
    console.log(obj); 
    const elem = $(`${this.webCompData['class']}`);
    this.cdRef.detectChanges();
    console.log(elem);
    elem.owlCarousel(obj);
    
  }

  onMegnifyZoom(){ 
      setTimeout(() =>{
        this.zoomMethod();
        this.zoomPrevNext();
      },100)    
      
  }

  zoomMethod() {
    
    (function () {
      $(document).ready(function () {
        $('.xzoom, .xzoom-gallery').xzoom({ zoomWidth: 400, title: true, tint: '#333', Xoffset: 15 ,lensShape:"circle",position:"left"});
        $('.xzoom2, .xzoom-gallery2').xzoom({ position: '#xzoom2-id', tint: '#ffa200' });
        $('.xzoom3, .xzoom-gallery3').xzoom({ position: 'lens', lensShape: 'circle', sourceClass: 'xzoom-hidden' });
        $('.xzoom4, .xzoom-gallery4').xzoom({ tint: '#006699', Xoffset: 15 });
        $('.xzoom5, .xzoom-gallery5').xzoom({ tint: '#006699', Xoffset: 15 });

        //Integration with hammer.js
        var isTouchSupported = 'ontouchstart' in window;

        if (isTouchSupported) {
          //If touch device
          $('.xzoom, .xzoom2, .xzoom3, .xzoom4, .xzoom5').each(function () {
            var xzoom = $(this).data('xzoom');
            xzoom.eventunbind();
          });

          $('.xzoom, .xzoom2, .xzoom3').each(function () {
            var xzoom = $(this).data('xzoom');
            $(this).hammer().on("tap", function (event) {
              event.pageX = event.gesture.center.pageX;
              event.pageY = event.gesture.center.pageY;
              var s = 1, ls;

              xzoom.eventmove = function (element) {
                element.hammer().on('drag', function (event) {
                  event.pageX = event.gesture.center.pageX;
                  event.pageY = event.gesture.center.pageY;
                  xzoom.movezoom(event);
                  event.gesture.preventDefault();
                });
              }

              xzoom.eventleave = function (element) {
                element.hammer().on('tap', function (event) {
                  xzoom.closezoom();
                });
              }
              xzoom.openzoom(event);
            });
          });

          $('.xzoom4').each(function () {
            var xzoom = $(this).data('xzoom');
            $(this).hammer().on("tap", function (event) {
              event.pageX = event.gesture.center.pageX;
              event.pageY = event.gesture.center.pageY;
              var s = 1, ls;

              xzoom.eventmove = function (element) {
                element.hammer().on('drag', function (event) {
                  event.pageX = event.gesture.center.pageX;
                  event.pageY = event.gesture.center.pageY;
                  xzoom.movezoom(event);
                  event.gesture.preventDefault();
                });
              }

              var counter = 0;
              xzoom.eventclick = function (element) {
                element.hammer().on('tap', function () {
                  counter++;
                  if (counter == 1) setTimeout(openfancy, 300);
                  event.gesture.preventDefault();
                });
              }

              function openfancy() {
                if (counter == 2) {
                  xzoom.closezoom();
                  $.fancybox.open(xzoom.gallery().cgallery);
                } else {
                  xzoom.closezoom();
                }
                counter = 0;
              }
              xzoom.openzoom(event);
            });
          });

          $('.xzoom5').each(function () {
            var xzoom = $(this).data('xzoom');
            $(this).hammer().on("tap", function (event) {
              event.pageX = event.gesture.center.pageX;
              event.pageY = event.gesture.center.pageY;
              var s = 1, ls;

              xzoom.eventmove = function (element) {
                element.hammer().on('drag', function (event) {
                  event.pageX = event.gesture.center.pageX;
                  event.pageY = event.gesture.center.pageY;
                  xzoom.movezoom(event);
                  event.gesture.preventDefault();
                });
              }

              var counter = 0;
              xzoom.eventclick = function (element) {
                element.hammer().on('tap', function () {
                  counter++;
                  if (counter == 1) setTimeout(openmagnific, 300);
                  event.gesture.preventDefault();
                });
              }

              function openmagnific() {
                if (counter == 2) {
                  xzoom.closezoom();
                  var gallery = xzoom.gallery().cgallery;
                  var i, images = new Array();
                  for (i in gallery) {
                    images[i] = { src: gallery[i] };
                  }
                  $.magnificPopup.open({ items: images, type: 'image', gallery: { enabled: true } });
                } else {
                  xzoom.closezoom();
                }
                counter = 0;
              }
              xzoom.openzoom(event);
            });
          });

        } else {
          //If not touch device

          //Integration with fancybox plugin
          $('#xzoom-fancy').bind('click', function (event) {
            var xzoom = $(this).data('xzoom');
            xzoom.closezoom();
            $.fancybox.open(xzoom.gallery().cgallery, { padding: 0, helpers: { overlay: { locked: false } } });
            event.preventDefault();
          });

          //Integration with magnific popup plugin
          $('#xzoom-magnific').bind('click', function (event) {
            var xzoom = $(this).data('xzoom');
            xzoom.closezoom();
            var gallery = xzoom.gallery().cgallery;
            var i, images = new Array();
            for (i in gallery) {
              images[i] = { src: gallery[i] };
            }
            $.magnificPopup.open({ items: images, type: 'image', gallery: { enabled: true } });
            event.preventDefault();
          });
        }
      });
    })();
  }
  zoomPrevNext() {
    let topPrevBtn = document.querySelector(".zoomContainerBottom");
    let bottomNextBtn = document.querySelector(".zoomContainerTop");
    // let leftPrevBtn = document.querySelector(".zoomContainerLeft");
    // let rightNextBtn = document.querySelector(".zoomContainerRight");

    if (topPrevBtn != null || bottomNextBtn != null) {
      let prevBtn = document.querySelector("#prevId");
      let nextBtn = document.querySelector("#nextId");
      let bottomGalleryClientWidth = document.querySelector(".bottom_gallary").clientWidth;
      let bottomGalleryScrollWidth = document.querySelector(".bottom_gallary").scrollWidth;
      let bottomGalleryImg = document.getElementsByClassName("xzoom-gallery")[0]['offsetWidth'];
      let bottomGallery = document.querySelector(".bottom_gallary");
      if (bottomGalleryClientWidth < bottomGalleryScrollWidth) {
        prevBtn.addEventListener("click", function () {
          bottomGallery.scrollLeft -= bottomGalleryImg;
        })
        nextBtn.addEventListener("click", function () {
          bottomGallery.scrollLeft += bottomGalleryImg;
        })
      }
    } else {
      const xzoomDefault = document.getElementById('xzoom-default').clientHeight;
      const getXzoomDefaultgallery = document.querySelector<HTMLElement>(".xzoom-thumbs");
      getXzoomDefaultgallery.style.height = xzoomDefault + "px"
      let getXzoomContainer = document.querySelector<HTMLElement>(".xzoom-container");
      getXzoomContainer.style.display = 'flex';

      let prevBtn = document.querySelector("#prevId");
      let nextBtn = document.querySelector("#nextId");
      let bottomGalleryClientHeight = document.querySelector(".bottom_gallary").clientHeight;
      let bottomGalleryScrollHeight = document.querySelector(".bottom_gallary").scrollHeight;
      let bottomGalleryImg = document.getElementsByClassName("xzoom-gallery")[0]['offsetHeight'];
      let bottomGallery = document.querySelector(".bottom_gallary");
      if (bottomGalleryClientHeight < bottomGalleryScrollHeight) {
        prevBtn.addEventListener("click", function () {
          bottomGallery.scrollTop += bottomGalleryImg;
        })
        nextBtn.addEventListener("click", function () {
          bottomGallery.scrollTop -= bottomGalleryImg;
        })
      }
    }
  }

  sagTree(){
    var toggler = document.getElementsByClassName("caret");
    var i;

    for (i = 0; i < toggler.length; i++) {
        toggler[i].addEventListener("click", function () {
            this.parentElement.querySelector(".nested").classList.toggle("active");
            this.classList.toggle("caret-down");
        });
    }
  }

}
