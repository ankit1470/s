import { Directive, OnInit, Input, ElementRef, Renderer, ViewContainerRef } from '@angular/core';
// declare var GridStack: any; 

@Directive({
    selector: '[dynamic-comp]',
  })
export class DynamicCompDirective implements OnInit {
    // @Input() w: number;
    // @Input() animate: boolean;

    constructor(public viewContainerRef: ViewContainerRef) { }

    ngOnInit() {}

    // ngOnInit() {
    //     let renderer = this.renderer;
    //     let nativeElement = this.el.nativeElement;
    //     let animate: string = this.animate ? "yes" : "no";

    //     renderer.setElementAttribute(nativeElement, "data-gs-width", String(this.w));
    //     if (animate == "yes") {
    //         renderer.setElementAttribute(nativeElement, "data-gs-animate", animate);
    //     }

    //     let options = {
    //         cellHeight: 80,
    //         verticalMargin: 10
    //     };

    //     // TODO: listen to an event here instead of just waiting for the time to expire
    //     setTimeout(function () {
    //         GridStack.init(nativeElement);
    //     }, 1000);
    // }

}