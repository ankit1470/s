import { 
  Directive, 
  ElementRef, 
  Renderer2, 
  OnInit,
  HostListener,
  HostBinding,
  Input } from '@angular/core';

@Directive({
  selector: '[appOnhover]'
})
export class OnhoverDirective {
 
  constructor(
    private elementRef:ElementRef, 
    private renderer:Renderer2) { }
    
    @Input() elemItem ;
 
  ngOnInit()   { 
    this.elemItem =  this.elemItem
  }

    @HostListener('mouseover')
    onMouseOver() {
     console.log(this.elementRef.nativeElement);
     console.log(this.elemItem);
      // this.renderer.setStyle(this.elementRef.nativeElement, 'background-color', '#FCF3CF');
    }
  
    @HostListener('mouseout')
    onMouseOut() {
      console.log(this.elemItem);
      console.log(this.elementRef.nativeElement);
      // this.renderer.setStyle(this.elementRef.nativeElement, 'background-color', '#fff'); 
    }
}
