import { GetheightDirective } from './getheight.directive';

describe('GetheightDirective', () => {
  it('should create an instance', () => {
    const directive = new GetheightDirective();
    expect(directive).toBeTruthy();
  });
});
