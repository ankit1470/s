/****
 * Auto-Suggestion 
 * 
 * eg:<input type="text" autoSuggestion (getValue)="value=$event" [(ngModel)]="value" />
 * 
 */

import { Directive, Renderer2, Output, EventEmitter } from "@angular/core";
import { ElementRef } from "@angular/core";
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';

@Directive({
  selector: "[autoSuggestion][ngModel]",
  host: {
    "(keydown)": "handleKeydown( $event )",
  },
})
export class AutoSuggestionDirective {
  @Output() getValue = new EventEmitter(); //For re-set ngModel binding in main page
  


  // I initialize the ng-model-suggestions value accessor and directive.
  constructor(
    public elementRef: ElementRef,
    public _sagStudioService: SagStudioService,
    public renderer: Renderer2) { }


  // I determine if the given keyboard event on space(32) represents a desire currently active suggestion.
  private isAcceptSuggestionEvent(event: KeyboardEvent): boolean {
    return ((event.keyCode === 32));
  }

  // I handle the keydown event on the Input element.
  public handleKeydown(event: KeyboardEvent): void {
    //  It Check the (space) Keyboard key press or not
    if (this.isAcceptSuggestionEvent(event)) {
      event.preventDefault();

      // Save the Input value back into our internal "source of truth" value.
      if (this.elementRef.nativeElement.value[this.elementRef.nativeElement.value.length - 1] === '.') {
        this.clearActiveSuggestion();
        let splitedArr = this.elementRef.nativeElement.value.split(".");
        let filteredKey = splitedArr[splitedArr.length - 2];

        let matCard = this.renderer.createElement('div');
        this.renderer.addClass(matCard, "suggestions-card");
        let pos = this.elementRef.nativeElement.getBoundingClientRect();
 
        let selectEle = this.renderer.createElement('select');

        selectEle.addEventListener('focusout', () => {
          this.clearActiveSuggestion();
        });

        selectEle.addEventListener('change', (evt) => {

          this.updateValue(evt.target.value, true);
          selectEle.parentNode.removeChild(selectEle);
          this.clearActiveSuggestion();
        });
        let optionEle = this.renderer.createElement("option");
        this.renderer.appendChild(optionEle, document.createTextNode("Choose Here."))
        this.renderer.appendChild(selectEle, optionEle);
            console.log(this._sagStudioService.suggestions);
        for (let index = 0; index < this._sagStudioService.suggestions[filteredKey].length; index++) {
          const suggObj = this._sagStudioService.suggestions[filteredKey][index];
          let optionEle = this.renderer.createElement("option");

          this.renderer.appendChild(optionEle, document.createTextNode(suggObj.name))
          this.renderer.appendChild(selectEle, optionEle);
        }
        
        this.renderer.setStyle(selectEle, 'width', `${pos.width}px`);
        this.renderer.appendChild(matCard, selectEle);
        this.renderer.setStyle(matCard, 'top', `${pos.top+pos.height}px`);
        this.renderer.setStyle(matCard, 'left', `${pos.left}px`);
        this.renderer.setStyle(matCard, 'width', `${pos.width}px`);
        this.renderer.setStyle(matCard, 'z-index', `99999999`);
        this.renderer.setStyle(matCard, 'position', `absolute`);
        this.renderer.appendChild(document.body, matCard);


      } else {
        return alert("Add prefix .(Dot) For Suggestions");
      }


      // Any other key should remove the active suggestion entirely.
    } else {
      this.clearActiveSuggestion();
    }
  }


  // I remove any active suggestion .
  clearActiveSuggestion(): void {
    document.querySelector(".suggestions-card") ? document.querySelector(".suggestions-card").remove() : false;
  }
  // I Update the Value of Element
  updateValue(value, concate?) {
    let currentSelItem = null;
     !concate ? true : currentSelItem = this._sagStudioService.suggestions[this.elementRef.nativeElement.value.replace('.','')].find(item => item.name == value );
    debugger
    let val = concate ? this.elementRef.nativeElement.value + currentSelItem.value : this.elementRef.nativeElement.value;
    this.renderer.setProperty(this.elementRef.nativeElement, 'value', `${val}`);
    this.renderer.setProperty(this.elementRef.nativeElement, 'innerText', `${val}`);
    this.getValue.emit(val);
  }
}
