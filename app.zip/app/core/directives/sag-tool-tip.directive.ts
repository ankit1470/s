/***
 * SagTool-Tip
 *
 * Developed By : SAG
 *
 *
*/


import { Directive, Input, ElementRef, HostListener, Renderer2, Output, } from '@angular/core';
import { SagStudioService } from 'src/app/services/sagStudio/sag-studio.service';

@Directive({
  selector: '[sagtooltip]'
})
export class SagToolTipDirective {

  @Input() tooltipTitle: any;
  @Input() placement: 'top' | 'bottom' | 'left' | 'right' = 'bottom';
  @Input() tooltipEvent: string;
  @Input() tooltipStyle: any;
  @Input() tooltipClass: any;
  @Input() addIcon: boolean = false;
  @Input() validation_msg: any;
  @Input() form_control: any;

  tooltip: HTMLElement;
  offset = 10;
  delay: number = 50;


  @HostListener('mouseenter', ['$event'])
  @HostListener('mouseleave', ['$event'])
  @HostListener('click', ['$event'])
  @HostListener('keyup', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.type == this.tooltipEvent && this.tooltipEvent == 'click') {
      this.onClickEvent();
    }
    else if (event.type == 'mouseenter' && this.tooltipEvent != 'click') {
      this.mouseOver();
    }
    else if (event.type == 'mouseleave' && this.tooltipEvent != 'click') {
      this.mouseLeave();
    }
    else if (event.type == 'keyup' && this.validation_msg != undefined) {
      this.ngClassSet();
    }
    else if (event.type == 'click' && this.tooltipEvent != 'click') {
      this.mouseLeave();
    }

  }
 


  constructor(private el: ElementRef, private renderer: Renderer2,
    private studioService: SagStudioService) {


  }


  mouseOver() {
    if (!this.tooltip) { this.show(); }
  }


  mouseLeave() {
    if (this.tooltip) { this.hide(); }
  }


  onClickEvent() {
    if (!this.tooltip) { this.show(); }
    else if (this.tooltip) { this.hide(); }
  }


  // Show Tooltip On Screen
  show() {

    // for Normal tool tip
    if (this.validation_msg === undefined) {
      this.create();
      this.setPosition();
      this.renderer.addClass(this.tooltip, 'sag-tooltip-show');
    }

    // In form - Validation case
    else if (this.form_control.errors != null && this.validation_msg != undefined) {
      this.validation_msg.split("#").forEach((ele) => {
        const key = ele.split("~")[0];
        const value = ele.split("~")[1];

        if (this.form_control.errors && Object.keys(this.form_control.errors).includes(key)) {
          this.studioService.currentActiveProject.msgList.find((msgList) => {
            if (msgList.id == value) {
              return this.tooltipTitle = msgList.msg;
            }
          });
        }
      });

      this.create();
      this.setPosition();
      this.renderer.addClass(this.tooltip, 'sag-tooltip-show');

    }


  }

  // Hide From Screen

  hide() {
    this.renderer.removeClass(this.tooltip, 'sag-tooltip-show');
    window.setTimeout(() => {
      if (this.tooltip) {
        this.renderer.removeChild(document.body, this.tooltip);
        this.tooltip = null;
      }
    }, this.delay);
  }

  // Create Toottip Span Here....
  create() {
    this.tooltip = this.renderer.createElement('span');
    if (this.tooltip) {
      // /**  when create custom Icon*/
      // if (this.addIcon) {

      //   /* Mobile code here */
      //   var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      //   if (isMobile) {
      //     let span = document.createElement('span');
      //     span.innerHTML = `<i class="fa fa-user"></i>`;
      //     this.el.nativeElement.parentNode.appendChild(span);
      //   }
      // }

      this.renderer.appendChild(
        this.tooltip,
        this.renderer.createText(this.tooltipTitle) // Here is add text of tool tips
      );

      this.renderer.appendChild(document.body, this.tooltip);
      if(this.tooltipTitle == ''){
        this.renderer.addClass(this.tooltip, 'd-none');
      }
      this.renderer.addClass(this.tooltip, 'sag-tooltip');
      this.renderer.addClass(this.tooltip, `sag-tooltip-${this.placement}`);
      this.renderer.setStyle(this.tooltip, '-webkit-transition', `opacity ${this.delay}ms`);
      this.renderer.setStyle(this.tooltip, '-moz-transition', `opacity ${this.delay}ms`);
      this.renderer.setStyle(this.tooltip, '-o-transition', `opacity ${this.delay}ms`);
      this.renderer.setStyle(this.tooltip, 'transition', `opacity ${this.delay}ms`);
      this.renderer.setStyle(this.tooltip, 'z-index', `999999`);


      // External Style Add
      if (this.tooltipStyle) {
        let styleObj = JSON.parse(this.tooltipStyle);
        for (const key in styleObj) {
          if (styleObj.hasOwnProperty(key)) {
            const styleVal = styleObj[key];
            this.renderer.setStyle(this.tooltip, key, styleVal);
            if (key == 'background-color' || key == 'background') {
              this.tooltip.style.setProperty('--tooltip-color', styleVal);
              // this.renderer.setStyle(this.tooltip, `sag-tooltip-${this.placement}`, styleVal);
            }
          }
        }
      }
      // External Class Add In toolTip
      if (this.tooltipClass) {
        this.renderer.addClass(this.tooltip, this.tooltipClass);
        let bgColor = getComputedStyle(document.querySelector(`.${this.tooltipClass}`)).backgroundColor;
        this.tooltip.style.setProperty('--tooltip-color', bgColor);
      }

    }

  }
  // Set Postion Of Tooltip
  setPosition() {
    const hostPos = this.el.nativeElement.getBoundingClientRect();
    const tooltipPos = this.tooltip.getBoundingClientRect();

    const scrollPos = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

    let top, left;

    if (this.placement === 'top') {
      top = hostPos.top - tooltipPos.height - this.offset;
      left = hostPos.left + (hostPos.width - tooltipPos.width) / 2;
    }

    if (this.placement === 'bottom') {
      top = hostPos.bottom + this.offset;
      left = hostPos.left + (hostPos.width - tooltipPos.width) / 2;
    }

    if (this.placement === 'left') {
      top = hostPos.top + (hostPos.height - tooltipPos.height) / 2;
      left = hostPos.left - tooltipPos.width - this.offset;
    }

    if (this.placement === 'right') {
      top = hostPos.top + (hostPos.height - tooltipPos.height) / 2;
      left = hostPos.right + this.offset;
    }

    this.renderer.setStyle(this.tooltip, 'top', `${top + scrollPos}px`);
    this.renderer.setStyle(this.tooltip, 'left', `${left}px`);

  }


  // Error Class Set On Tooltip Ele Div i.e appled Div
  ngClassSet() {
    if (this.form_control && this.form_control.errors != null) {
      this.renderer.removeClass(this.el.nativeElement, 'is-valid');
      this.renderer.addClass(this.el.nativeElement, 'is-invalid');
    }
    else {
      this.renderer.removeClass(this.el.nativeElement, 'is-invalid');
      this.renderer.addClass(this.el.nativeElement, 'is-valid');
    }
  }

}


