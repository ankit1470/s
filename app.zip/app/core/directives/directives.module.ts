import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OnhoverDirective } from './onhover.directive';
import { SagToolTipDirective } from './sag-tool-tip.directive';
import { ResizableDirective } from './resizable.directive'
import { DraggableDirective } from './draggable/draggable.directive';
import { MovableDirective } from './moveable/moveable.directive';
import { DraggableHelperDirective } from './draggable/draggable-helper.directive';
import { SplitAreaDirective } from '../shared/components/splitter/split-area.directive';
import { DynamicCompDirective } from './dynamic-comp.directive';
import { AutoSuggestionDirective } from './auto-suggestion.directive';
import { GetheightDirective } from './getheight.directive';
import { NavbarManagerDirective } from './navbar-manager.directive';
import { CustomControlPngModelDirective } from './custom-control-png-model.directive';
import { OnLoadComponentDirective } from './webComponents/on-load-component.directive';
import { SagResizableNodeDirective } from './sag-resizable-node.directive';
import { FullmodalstudioDirective } from './fullmodalstudio.directive';

@NgModule({
  declarations: [
    OnhoverDirective,
     SagToolTipDirective,
    ResizableDirective,
    DraggableDirective,
    MovableDirective,
    DraggableHelperDirective, 
    SplitAreaDirective,
    DynamicCompDirective,
    AutoSuggestionDirective,
    GetheightDirective,
    NavbarManagerDirective,
    CustomControlPngModelDirective,
    OnLoadComponentDirective,
    SagResizableNodeDirective,
    FullmodalstudioDirective,
  ],
  imports: [
    CommonModule
  ],
  exports: [
    OnhoverDirective,
    SagToolTipDirective,
    ResizableDirective,
    DraggableDirective,
    MovableDirective,
    DraggableHelperDirective,
    SplitAreaDirective,
    DynamicCompDirective,
    AutoSuggestionDirective,
    GetheightDirective,
    NavbarManagerDirective,
    CustomControlPngModelDirective,
    OnLoadComponentDirective,
    SagResizableNodeDirective,
    FullmodalstudioDirective,
  ]
})
export class DirectivesModule { }
