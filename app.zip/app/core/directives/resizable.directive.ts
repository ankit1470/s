/*** 
 * Sag Resizable 
 * 
 * Developed By : Ujagar Singh
 * 
 * pageDi = {}
 * 
 * 
*/

import { Directive, ElementRef, OnInit, Input, HostListener, Renderer2, AfterViewInit } from '@angular/core';
import { SagStudioService } from '../../services/sagStudio/sag-studio.service';
declare const $: any;

@Directive({
  selector: '[sagresizable]' // Attribute selector
})

export class ResizableDirective implements OnInit, AfterViewInit {


  @Input() resizableGrabWidth = 6;
  @Input() resizableMinWidth = 5;
  dragging = false;

  constructor(private el: ElementRef, public _sagStudioService: SagStudioService, 
    private rd: Renderer2) { }

  ngOnInit(): void {
  }
  
  
  @HostListener('window:resize')
  onresize() {
    this.resetParametersHandler();
  }
  ngAfterViewInit() {
    this.sagresizableHandler();
  }

  sagresizableHandler(){
     
    const LDB = "leftBar"; // LEFT DRAG BAR
    const CDB = "contentArea"; // CENTER DRAG BAR
    const PDB = "propertyDown"; // CENTER DRAG BAR
    const LSB = "leftScrollTab"; // LEFT SCROLL BAR ID
    const CSB = "centerScrollTab"; // CENTER  SCROLL BAR ID

    const _di = this._sagStudioService.pageDi;
    const _sw0 = $("#dashSideBar").outerWidth() ? $("#dashSideBar").outerWidth() : 0;
    const _sw1 = $("#dashSideBar2").outerWidth() ? $("#dashSideBar2").outerWidth() : 0;
    
    // debugger;
    _di['domElements']['sideBar1']['width'] = _sw0;
    _di['domElements']['sideBar2']['width'] = _sw1;
    _di['domElements']['cntrContainer']['width'] = _di['domElements']['windowDi']['width'] - (_sw0 + _di['domElements']['sideBar2']['width'] + _di['domElements']['menuSidebar']['width']);
    _di['domElements']['appendControls']['width'] = _di['domElements']['windowDi']['width'] - (_sw0 + _di['domElements']['sideBar2']['width'] + _di['domElements']['menuSidebar']['width']);
    _di['domElements']['bootpillsSize']['width'] = _di['domElements']['windowDi']['width'] - (_sw0 + _di['domElements']['sideBar2']['width'] + _di['domElements']['menuSidebar']['width']);
    _di['domElements']['bootModelsSize']['width'] = _di['domElements']['windowDi']['width'] - (_sw0 + _di['domElements']['sideBar2']['width'] + _di['domElements']['menuSidebar']['width']);
    _di['domElements']['leftmenuSizeFullScreen']['width'] = _di['domElements']['windowDi']['width'] - (_sw0 + _di['domElements']['sideBar2']['width'] + _di['domElements']['menuSidebar']['width']);
    _di['domElements']['sagGridFullscreen']['width'] = _di['domElements']['windowDi']['width'] - (_sw0 + _di['domElements']['sideBar2']['width'] + _di['domElements']['menuSidebar']['width']);
    
    _di['setDimensionHandler'] = function (elem){
      const propObj = _di['domElements'][elem];
      const _elemId = '#'+propObj['id'];
      const _dtype = (propObj['display']) ? "flex" : "none";
      $(_elemId).css({"width" : propObj.width+"px", "left" : propObj.left+"px", "display" : _dtype})
      $(_elemId).closest('.secCover').css({"display" : _dtype})
    } 
    

    _di['dragMouseDown'] = (elemId : any, parentElem : any) => {
      const _elemId = '#'+elemId;
      const _sidebarWidth = _di['domElements']['sideBar1']['width'];
      
      $(_elemId).mousedown(function(e){
          const _domObj = _di['domElements'];
          let _sidebar2Width = _domObj['sideBar2']['width'];
          let _menuWidth = _domObj['menuSidebar'].width;
          let _cntrWidth = _domObj['cntrContainer'].width;
          // e.preventDefault();
          if(e.target.id){
            $(document).mousemove(function(e){
              if(parentElem === LSB){
                // left panel

                // center panel
                let propWidth = 0;
                // debugger
                propWidth = (_domObj['propSidebar']['display']) ? _domObj['propSidebar']['width'] : 0 ;

                
                let mPointerX = null;
                if(e.pageX < (250 + _domObj['sideBar1']['width'])){
                  mPointerX = (250 + _domObj['sideBar1']['width']);
                } else if (e.pageX > (_domObj['windowDi']['width'] - (propWidth + 350))){
                  mPointerX = (_domObj['windowDi']['width'] - (propWidth + 350));
                } else {
                  mPointerX = e.pageX 
                }

                if(mPointerX >= (_domObj['sideBar1']['width'] + 250)){
                  _domObj['menuSidebar']['width'] = mPointerX - _sidebarWidth;
                  _domObj['cntrContainer']['width'] = Math.abs(_cntrWidth + _menuWidth + _domObj['sideBar1']['width'] - mPointerX);
                  // $('#'+CDB).css("width", Math.abs(_cntrWidth + _menuWidth + 20 - pageX ));
                  
                }else {
                  _domObj['menuSidebar']['width'] = 250;
                  _domObj['cntrContainer']['width'] = _domObj['windowDi']['width'] - (250 + 350 + _domObj['sideBar1']['width']);
                  _di['stopMouseDragHandler']();
                }
                _di['setDimensionHandler']('menuSidebar'); 

                _di['setDimensionHandler']('cntrContainer');
              } else {
                // center panel
                let propWidth = 0;
                // debugger
                propWidth = (_domObj['propSidebar']['display']) ? _domObj['propSidebar']['width'] : 0 ;

                let mPointerX = null;
                if(e.pageX < (_domObj['menuSidebar']['width'] + 350 + _domObj['sideBar1']['width'])){
                  mPointerX = (_domObj['menuSidebar']['width'] + 350 + _domObj['sideBar1']['width']);
                } else if (e.pageX > (_domObj['windowDi']['width'] - 250)){
                  mPointerX = _domObj['windowDi']['width'] - 250;
                } else {
                  mPointerX = e.pageX 
                }
                
                // (_domObj.propSidebar.position === 'split') && 
                if(mPointerX <= (_domObj['windowDi']['width'] - propWidth)){
                  if(_domObj['propSidebar']['display'] && _domObj['cntrContainer']['width'] >= 700){
                    _domObj['cntrContainer']['width'] = (mPointerX - (_domObj['menuSidebar']['width'] + _sidebarWidth + _sidebar2Width));
                    _domObj['propSidebar']['width'] = (_domObj['windowDi']['width'] - mPointerX );
                  }
                }else {
                  _domObj['propSidebar']['width'] = 250;
                  _domObj['cntrContainer']['width'] = _domObj['windowDi']['width'] - (250 + 350 + _domObj['sideBar1']['width']);
                  _di['stopMouseDragHandler']();
                }
                _di['setDimensionHandler']('cntrContainer');
              
                _di['setDimensionHandler']('propSidebar');
              }

              _di['showCurrentState']();
            })
          }
      });

      _di['stopMouseDragHandler']();
    }
    
    _di['stopMouseDragHandler'] = () => {
      $(document).mouseup(function(e:any){ 
         $(document).unbind('mousemove');
      });
    }

    _di['createSidebar'] = () => {
      if(!_di['domElements']['menuSidebar']['scrollBar']){
        let leftBar = $('<div>').addClass('dragLeft')
        .css({"height": "100%", "width": "5px", "border-right": "1px solid #ccc", "right": "0", "position": "absolute", "zIndex": "99", "top": "0", "cursor": "w-resize"})
        .attr('id', LSB)

        $('#'+LDB)
        .css({"position": "relative", "minWidth" : "unset", "maxWidth": "unset", "height": "inherit", "padding-right": "8px"})
        .prepend(leftBar);
          
        _di['dragMouseDown'](LDB, LSB);
        _di['domElements']['menuSidebar']['scrollBar'] = true;
      }
      // --------------------------------------------------
      if(!_di['domElements']['cntrContainer']['scrollBar']){
        let contentBar = $('<div>').addClass('dragCenter')
        .css({"height": "100%", "width": "5px", "border-right": "1px solid #ccc", "right": "0", "position": "absolute", "zIndex": "99", "top": "0", "cursor": "w-resize"})
        .attr('id', CSB);
        
        $('#'+CDB)
        .css({"position": "relative", "left": "0px", "height": "inherit", "padding-right": "8px"})
        .prepend(contentBar);
        
        _di['dragMouseDown'](CDB, CSB);
        _di['domElements']['cntrContainer']['scrollBar'] = true;
      }
    }
    
    // right click to set center width
    // set Center and Right width together
    _di['setCenterWithRightHandler'] = function (propWindosFlag :any){
      // const _display = !_di['domElements']['propSidebar']["display"];
      const _position = (_di['domElements']['propSidebar']["display"] && _di['domElements']['propSidebar']["position"] == "split") ? "right" : "split";

      _di['domElements']['propSidebar']['position'] = _position;
      // debugger;
      if(propWindosFlag){
        _di['domElements']['propSidebar']['display'] = true;
      } 

      const _crntUsedWidth = _di['domElements']['cntrContainer']['width']+_di['domElements']['menuSidebar']['width']+_di['domElements']['sideBar1']['width'];
      const _propSidebarWidth = (_di['domElements']['propSidebar']['display']) ? 250 : 0;
      const _aspectedWidth = _di['domElements']['windowDi']['width'] - _propSidebarWidth;
      
      if(_crntUsedWidth <= _aspectedWidth){
          const _cntrWidth = _di['domElements']['windowDi']['width'] - 
                              (_propSidebarWidth + _di['domElements']['menuSidebar']['width'] + _di['domElements']['sideBar1']['width']);
          _di['domElements']['cntrContainer']['width'] = _cntrWidth;
          _di['domElements']['propSidebar']['width'] = 250;
        } else {
          const _cntrWidth = _aspectedWidth - (_di['domElements']['menuSidebar']['width']+_di['domElements']['sideBar1']['width']);
          _di['domElements']['cntrContainer']['width'] = _cntrWidth;
      }

      _di['setDimensionHandler']('cntrContainer')
      
      _di['setDimensionHandler']('propSidebar')

    }
    // show/hide domElement Handler
    _di['showHideDomElementHandler'] = function (){
      const domKeys = Object.keys(_di['domElements']);
      const _domKeys = domKeys.filter((el) => _di['domElements'][el]['display'] === false);
      if(_domKeys.length > 1){
       _di['domElements']['sideBar2']['display'] = true;
      //  _di['domElements']['sideBar2']['width'] = 33;
      } else {
        _di['domElements']['sideBar2']['display'] = false;
        // _di['domElements']['sideBar2']['width'] = 0;
      }

      const _val = (_di['domElements']['sideBar2']['display']) ? "flex" : "none";
      const _elemR = '#'+_di['domElements']['sideBar2']['id'];
      $(_elemR).css({"display" : _val})
    }

    _di['miniMizeSectionHandler'] = (selector : any) => {
      // debugger;
      const _elem = _di['domElements'][selector];
      _elem['display'] = false;
      _di['resetAllComponent']( selector);
      return 0
    }
    
    _di['maximizeSectionHandler'] = (selector : any) => {
      // debugger;
      const _elem = _di['domElements'][selector];
      _elem['display'] = true;
      _di['resetAllComponent']( selector);
      return 0
    }

    _di['closeSectionHandler'] = (selector : any) => {
      // debugger;
      const _elem = _di['domElements'][selector];
      _elem['display'] = false;
      _di['resetAllComponent']( selector);
      return 0
    }
    
    _di['restoreSectionHandler'] = (selector : any) => {
      // debugger;
      const _elem = _di['domElements'][selector];
      if(!_elem['display']){
        _elem['display'] = true;
        _di['resetAllComponent']( selector);
      }
      return 0
    }

    _di['resetAllComponent'] = (selector : any) => {
      if(selector === 'menuSidebar'){
        const menuDisplay = _di['domElements']['menuSidebar']['display']
        if(!menuDisplay){
          _di['domElements']['cntrContainer']['width'] += _di['domElements']['menuSidebar']['width']
        } else {
          _di['domElements']['cntrContainer']['width'] -= _di['domElements']['menuSidebar']['width']
        }
      }
      
      _di['setDimensionHandler']('menuSidebar')
      
      _di['setDimensionHandler']('cntrContainer')
      
      _di['setDimensionHandler']('propSidebar');

    }

    
     
    /** onload function calling start */

    this._sagStudioService.pageDi['setDimensionHandler']('menuSidebar'); 

    this._sagStudioService.pageDi['setDimensionHandler']('cntrContainer')
    
    _di['createSidebar']();
    // _di['setAnxMainHeaderHandler']();
    /** onload function calling start */

    $(document).mouseup(function(e){
      $(document).unbind('mousemove');
    });
    // http://jsfiddle.net/gaby/Bek9L/
    
    _di['showCurrentState'] = () => {
      console.log('DOM CurentState ++++++++++++++++++++++++++++++++++++++++++');
      console.log(this._sagStudioService.pageDi);
    }
  }

  resetParametersHandler(){
    const _di = this._sagStudioService.pageDi;

    _di['setDimensionHandler']('menuSidebar')
    
    _di['setDimensionHandler']('cntrContainer')
    
    _di['setDimensionHandler']('propSidebar');
  }
}


// monitorEvents(document.body); // logs all events on the body

// monitorEvents(document.body, 'mouse'); // logs mouse events on the body

// monitorEvents(document.body.querySelectorAll('input')); // logs all events on inputs