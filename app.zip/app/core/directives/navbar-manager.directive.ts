import { Directive, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
// import { element } from 'protractor';

@Directive({
  selector: '[appNavbarManager]'
})
export class NavbarManagerDirective implements AfterViewInit {

  constructor(private el:ElementRef, private renderer:Renderer2 ) { 
  }


  // @ViewChild('topHeaderTemplateRef', {static:false}) topHeaderElem : ElementRef;
 
  ngAfterViewInit(): void {
    // debugger;
     this.manageNavBarHandler();
  }
  extraBtnCounter : number;

  manageNavBarHandler(){
    setTimeout(()=>{
        const _parent = this.el.nativeElement.parentElement;
        let usedWidth = 160;
        let ulElem = _parent.getElementsByClassName('extraBtnManger-con')[0];
        let _parentWidth = _parent.offsetWidth;
        const _allLI = Array.prototype.slice.call(this.el.nativeElement.children);
        _allLI.map((elm:any)=>{
          const _val = elm.offsetWidth + 1;
          const _appliedWidth = Number(elm.dataset.width);
          if(!_appliedWidth){
            this.setAttrHandler(elm, [{"data-width" : _val}]);
          }
          usedWidth += _val;
          if(usedWidth >= _parentWidth){
            if(!ulElem){
              this.addNewButton();
            }
            ulElem = _parent.getElementsByClassName('extraBtnManger-con')[0];
            ulElem.append(elm);
          }
        })
        const _ulElem = _parent.getElementsByClassName('extraBtnManger-con')[0];
        if(_ulElem){
          this.updateExtraCounter();
        }
      },10)
  }


  removeNavBarHandler(){
    setTimeout(()=>{
      const _parent = this.el.nativeElement.parentElement;

      let ulElem = _parent.getElementsByClassName('extraBtnManger-con')[0];
      let _parentWidth = _parent.offsetWidth -  
                          _parent.parentElement.getElementsByClassName('controll_group')[0].offsetWidth;
      
      if(ulElem){
        
        // debugger;
        const _childCount = ulElem.childElementCount;
        if(_childCount > 0){
          const _childLi = Array.prototype.slice.call(ulElem.children);
          let _elWidth = this.el.nativeElement.offsetWidth + 
                          _parent.parentElement.getElementsByClassName('extraBtnManger-btn')[0].offsetWidth;
          _childLi.map((elm:any) => {
            const _val = (Number(elm.dataset.width)) ? Number(elm.dataset.width) : 150;
            _elWidth += _val;
            if(_elWidth < _parentWidth){
              this.el.nativeElement.append(elm);
            } 
          })
        }

        const _childCount_1 = ulElem.childElementCount;
        if(_childCount_1 === 0){
          this.removeNewButton();
        } else {
          this.updateExtraCounter();
        }
      }
    },10);
  }


  addNewButton():void {
    
    const hostElem = this.renderer.createElement('div');
    this.addClassHandler(hostElem, ["extraBtnManger-btn","btn-group"]);
    
    const childElem = this.renderer.createElement('div');
    this.addClassHandler(childElem, ["dropdown-menu"]);

    const ulElem = this.renderer.createElement('ul');
    this.addClassHandler(ulElem, ["extraBtnManger-con", "nav", "nav-pills", "nav-one"]);
    
    const button = this.renderer.createElement('button');
    const buttonText = this.renderer.createText('more...');
    const span = this.renderer.createElement('span');
    this.addClassHandler(span, ["child-counter"]);
    this.renderer.appendChild(button, buttonText);
    this.renderer.appendChild(button, span);
    this.addClassHandler(button, ["btn", "btn-sm", "btn-secondary", "dropdown-toggle", "dropdown-toggle-split", "extra-toggle-btn"]);
    this.setAttrHandler(button, [{"data-toggle" : "dropdown"}, {"aria-haspopup" : "true"}, {"aria-expanded" : "false"}]);
    
    this.renderer.appendChild(hostElem, button);
    this.renderer.appendChild(hostElem, childElem);
    this.renderer.appendChild(childElem, ulElem);
    
    this.renderer.appendChild(this.el.nativeElement.parentElement, hostElem); // use this.el.nativeElement to insert into template root
    // this.renderer.listen(button, 'click', () => this.addNewButton());
    // return ulElem
    // <div class="btn-group ml-auto">
    //   <button type="button" class="btn btn-sm btn-secondary dropdown-toggle dropdown-toggle-split"
    //     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    //     <span class="sr-only">Toggle Dropdown</span>
    //   </button>
    //   <div class="dropdown-menu" id="anxExtraBtn">
    //     <ul class="nav nav-pills nav-one" #anxExtraBtnCover>
    //     </ul>
    //   </div>
    // </div>
  }

  addClassHandler(elem : ElementRef, clsName : any) {
    clsName.forEach((element : string) => {
      this.renderer.addClass(elem, element);
    });
  }
  setAttrHandler(elem : ElementRef, attrList : any) {
    attrList.forEach((element:any) => {
      //  debugger;
      const _key = Object.keys(element)[0];
      this.renderer.setAttribute(elem, _key, element[_key])
    });
  }
  
  removeNewButton(){
    const _elem = this.el.nativeElement.parentElement.getElementsByClassName('extraBtnManger-btn')[0];
    _elem.remove();
  }

  
  updateExtraCounter(){
    const _parent = this.el.nativeElement.parentElement;
    let counterElem = _parent.getElementsByClassName('child-counter')[0];
    let conuner = _parent.getElementsByClassName('extraBtnManger-con')[0].childElementCount;
    counterElem.innerHTML = conuner;
  }

}
