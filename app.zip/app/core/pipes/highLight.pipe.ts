

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'highlight'
})
export class HighLightPipe implements PipeTransform {

    transform(item: any, searchText: any): any[] {
        if(!item) return [];
        if(!searchText) return item;

        searchText = searchText.toLowerCase();
        const re = new RegExp(searchText, 'gi');
        return item.toLowerCase().replace(searchText, `<span class='yellow'>${searchText}</span>`);
        
    }
}



