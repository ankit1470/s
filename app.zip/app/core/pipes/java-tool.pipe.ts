import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'javaTool'
})
export class JavaToolPipe implements PipeTransform {
  transform(items: any, searchJavaToolText: string): any[] {
    if (!items) return [];
    if (!searchJavaToolText) return items;
    searchJavaToolText = searchJavaToolText.toLowerCase();
    return items.filter(item => {
    return item.toolName.toLowerCase().includes(searchJavaToolText);
    });
  }
}
