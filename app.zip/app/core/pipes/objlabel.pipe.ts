import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterObjectLbl'
})
export class FilterObjectLblPipe implements PipeTransform {

  transform(items: any, searchText: string): any[] {
    if(!items) return [];
    if(!searchText) return items;

    searchText = searchText.toLowerCase();

    return items.filter( item => {
      return item.label.toLowerCase().includes(searchText);
    });
  }

}