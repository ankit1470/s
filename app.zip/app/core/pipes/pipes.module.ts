import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SafeHtmlPipe } from './safe-html.pipe';
import { FilterPipe } from './filter.pipe';
import { FilterObjectLblPipe } from './objlabel.pipe';
import { JavaToolPipe } from './java-tool.pipe';
import { HighLightPipe } from './highLight.pipe';

@NgModule({
  declarations: [SafeHtmlPipe, FilterPipe,FilterObjectLblPipe, JavaToolPipe,HighLightPipe],
  imports: [
    CommonModule, 
  ],
  exports : [
    SafeHtmlPipe, FilterPipe , FilterObjectLblPipe,JavaToolPipe,HighLightPipe
  ]
})
export class PipesModule { }
