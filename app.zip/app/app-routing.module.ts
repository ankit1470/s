import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { AppComponent } from './app.component';
//import { CustomPreloadingStrategyService } from './core/services/custom-preloading-strategy.service';


const routes: Routes = [
  
  {
    path: "",
    loadChildren: () => import('./dashboard/dashboard.module').then(mod => mod.DashboardModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{
    //  preloadingStrategy : CustomPreloadingStrategyService 
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
